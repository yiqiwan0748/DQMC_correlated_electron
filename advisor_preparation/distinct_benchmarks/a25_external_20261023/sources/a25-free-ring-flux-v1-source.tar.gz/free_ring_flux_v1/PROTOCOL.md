# A25 source-only candidate protocol

This candidate is **unfrozen and unexecuted**. The original revision2 proposal,
its independent theory review, catalogue row and native files are retained.
Scientific gates are copied from that proposal; additional norm/Hermiticity
checks qualify the new observers. No pilot/full data or scientific credit exists.

The new adapter constructs an actual one-dimensional ring, with no invocation
of the native square-torus constructor. Its even-dimensional Hermitian K enters
the unchanged generic `TwoOrbitalTwistedClusterED.sector_hamiltonian`, at U=h=0,
and actual `ground_state_observables(method=:dense,return_eigenvectors=true)`.
The module's orbital-normalized magnetic observables are not used to infer ring
physics. Only total many-body energy, residuals and the balanced complete vector
are used. No arbitrary-flux DQMC API is claimed.

## Fixtures, exact roles and complete grid

L4/N2 has balanced(1,1) and integer occupied mode0; L6/N6 has balanced(3,3)
and modes−1,0,1. Every total-N spin sector is mandatory:3 sectors for L4,
7 for L6. Hopping t=1, spin independent, U=h=0. All fluxes are dimensionless,
with hbar=e=1. Centers are−2.4,−1,−.25,0,.25,1,2.4. Fixed derivative steps
are .08 and .04. Their exact integer-unit stencil union is
center+{−.16,−.08,−.04,0,.04,.08,.16}. No step, center, gauge or size selection.
Full mode has196 point/gauge rows and980 native sector solves. The excluded
pilot uses only L6/center.25, every stencil point/gauge/sector:14 rows,98 solves.

Zero-based forward j→(j+1)%L has K[j+1,j]=−t exp(−iPhi/L) in uniform gauge.
Boundary gauge has real interior hoppings and forward seam−t exp(−iPhi).
The fixed transformation is Kb=G Ku G†, Gjj=exp(+ijPhi/L). Both explicit
constructions retain conjugate reverse bonds; there is no two-site parallel-edge
ambiguity at L4/L6. Nonzero imaginary native hopping is mandatory away from0.

The independent Python stdlib reference does not read/import target/raw data.
It uses exp(+i2pi*n*j/L)/sqrtL plane waves, epsilon_n=−2t cos((2pi*n+Phi)/L),
and spectral reconstruction of K, rather than the native edge loop. Boundary
vectors are G times uniform vectors. Small determinant products provide the
balanced many-body Slater vector, with ascending occupied-site rows and fixed
occupied-mode columns. Native up/down masks form a bijection to that independently
constructed vector, respecting up-creators before down-creators and down-fast
product enumeration. Full-vector phase-invariant fidelity catches complex
conjugation or basis mistakes invisible to even-in-flux energies. No fitted
phase or gauge is used. Its norm and independent Fock action are qualified.

Each native sector energy is compared with independent ordered one-body level
occupation sums. The balanced fixed branch and analytic shell/global fixed-N
gap must qualify at every point. Native and reference total energies, current,
curvature and D=(L/2)curvature retain their distinct units and meanings. This is
a finite free-ring response; no interacting or thermodynamic Drude weight claim.

## Derivatives and error eligibility

E(Phi)=−4t sum_occ cos((2pi*n+Phi)/L). Current is−Eprime. Use both standard
five-point centered stencils. The reference returns exact analytic I, Esecond
and D, plus conservative global bounds M5=4t*nocc/L^5, M6=4t*nocc/L^6.
Truncation allowances are h^4*M5/30 and h^4*M6/90, respectively.

For EACH point entering EACH stencil, the input allowance is
5e−13+64*epsilon64*max(1,abs(Eanalytic)). Multiply by absolute stencil
coefficients and sum, dividing by12h or12h². Add the analytic truncation bound
and64epsilon64*max(1,abs(exact derivative)). Separately include floating-point
stencil formation: gamma32*sum(abs(q*E_native))/abs(denominator), with
gamma_n=n*u/(1−n*u),u=epsilon64/2. Add gamma16*abs(observed derivative) for
denominator/division arithmetic. Each named positive component and their sum
is recorded with `nextafter` toward positive infinity. Multiply the FULL curvature
allowance by L/2 for stiffness, adding gamma16*abs(observed stiffness) for the
final scaling arithmetic. This pre-data certificate completion leaves every
scientific1e−8 gate, input allowance, step, fixture and arm unchanged; the initial
unexecuted comparator is retained under `reviews/`. Every response allowance must
be≤1e−8 independently, and the actual discrepancy must fit both this allowance
and1e−8. Both-step consistency is an extra check, never the eligibility test.
These are conditional binary64 budgets, not directed-rounding interval proofs.
Unqualified budgets/incomplete grids are UNRESOLVED; qualified disagreement is
FAIL. No diagnostic can earn an energy-only pass.

## Source, runtime and resource boundaries

All producers require an actual source freeze/SHA list and Slurm allocation.
The native three-file closure is checked before native includes. The wrapper
and Python roles verify the installed expected runtime file hashes before
numerical work; wrapper verifies again afterward. `runtime_pins.json` was obtained
by read-only stdlib file discovery/ldd/hash metadata, without math/cmath imports,
Julia execution or copying binaries. It binds Python3.11.11, Julia1.12.1, actual
math/cmath/libm/libc, Julia image/libjulia/BLAS and LinearAlgebra sources.
The native role additionally requires loaded OpenBLAS and libblastrampoline,
then exports `BLAS.get_config().loaded_libs`; every configured provider must
match the complete pinned OpenBLAS/ILP64 set, with one actual BLAS thread. The
comparator checks those actual provider records as well as the119-file map.

All three processes run serially on1CPU/3500MB. GNU time records each process's
wall and peak RSS, with original stdout/stderr and a scientific-only execution
receipt retaining failures/timeouts and output hashes. Pilot wall cap15min;
full30min. No time estimate is claimed measured before the pilot.

The resource assessor is excluded from science. Its fixed empirical forecast is
2*(entire cold native wall+980*maximum warm sector wall)+
2*14*(reference wall+comparison wall)+30seconds; peak is
2*(observed peakMiB+64). It must fit1500sec/2800MiB and the native producer
timeout minus30sec. L4 sector dimensions are below the measured L6 maximum;
all98 pilot solves are retained. Warm candidates are every91 solve after the
first complete seven-sector point; both gauges, all seven spin sectors and
maximum dimension400 must be represented, or eligibility is unresolved. The
whole cold native process wall separately retains all compilation/serialization
overhead. This definition was corrected with root approval before any data,
and its initial candidate and correction note are retained under `reviews/`.
All L6 sectors/gauges/stencil points are measured. This remains an engineering
forecast rather than a guarantee. A separate independent pilot audit and exact
source-bound root review are required; full mode rejects absent/mismatched guards.
The wrapper neither submits jobs nor queries/changes scheduling or automation.

Missing source closure, runtime disagreement, timeouts, lost vectors or failed
precision qualification remain unresolved. All original raw/failure receipts
must remain intact. Only an audited complete full grid can supply one A25 credit.
