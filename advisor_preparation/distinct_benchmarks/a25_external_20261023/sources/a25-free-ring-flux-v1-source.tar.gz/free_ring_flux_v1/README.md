# A25 free-ring flux: unexecuted candidate

Source only; **not frozen, not run, zero completion credit**. No native code was
modified. The new one-dimensional complex-ring and Slater adapters use the
existing generic complex many-body Hamiltonian and native dense ground API.
The square-torus constructor is unused. The independent reference uses Python
stdlib analytic band sums and determinant products, with no native/raw imports.

Both L4/N2 and L6/N6, both explicit gauges, all fixed-total-N spin sectors,
all seven centers and both complete fixed stencils are mandatory. Current,
curvature and L/2 stiffness require pointwise propagated precision/truncation
budgets. Balanced full-vector Slater fidelity qualifies the gauge/basis phase.
See [PROTOCOL.md](PROTOCOL.md) and the exact copied revision2 [proposal](proposal.json).

The source-only preparation includes119 expected runtime file hashes; binaries
are not copied. A15/J20/J21 square-torus work is not relabeled or counted here.
This does not test an existing arbitrary-flux one-band DQMC API, interacting
current or bulk stiffness. Original user native sources and approved proposal
are verbatim; new adapters/wrappers are explicitly attributed in their files.

Before any execution, independent source review and root freeze are required.
The excluded L6 timing pilot measures all98 sector solves. Its fixed resource
projection can only request a separate root full review; it cannot authorize
or launch the full campaign. No submission or automatic resume is implemented.
