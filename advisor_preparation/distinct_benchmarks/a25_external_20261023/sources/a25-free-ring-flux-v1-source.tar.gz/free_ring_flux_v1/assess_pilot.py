#!/usr/bin/env python3
"""Fixed conservative engineering projection only; never a scientific completion."""
import argparse, math, tomllib
from pathlib import Path
from io_contract import HERE,contract,load,sha,write
def main():
 p=argparse.ArgumentParser();p.add_argument('--raw',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();c,source=contract();r=a.raw/'results';e=load(r/'execution.json');v=load(r/'comparison.json');n=tomllib.loads((r/'native.toml').read_text());res=c['resources']
 if e['schema']!='A25_SCIENTIFIC_EXECUTION_V1' or e['mode']!='pilot' or e['status']!='PROCESSES_COMPLETE' or e['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or e['source_sha256']!=source or e['runtime_before_sha256']!=e['runtime_after_sha256']:raise ValueError('Incomplete source-bound pilot receipt')
 for name,spec in e['outputs'].items():
  if sha(r/name)!=spec['sha256'] or (r/name).stat().st_size!=spec['bytes']:raise ValueError('Pilot raw changed')
 if v['mode']!='pilot' or v['status']!='PASS' or v['scientific_completions']!=0 or not v['pilot_excluded'] or v['sector_solves']!=res['pilot_native_sector_solves'] or not v['checks'] or not all(row['passed'] for row in v['checks']):raise ValueError('Pilot qualification/gates incomplete')
 if v['input_sha256']!={'native':sha(r/'native.toml'),'reference':sha(r/'reference.json')}:raise ValueError('Pilot comparison inputs changed')
 processes={x['label']:x for x in e['processes']}
 if set(processes)!={'native','reference','comparison'} or len(e['processes'])!=3 or any(x['exit_code']!=0 or x['timed_out'] or not math.isfinite(x['wall_seconds']) or x['wall_seconds']<=0 or x.get('max_rss_kib',0)<=0 for x in processes.values()):raise ValueError('Missing process/resource measurements')
 times=[s['elapsed_seconds'] for p in n['points'] for s in p['spin_sectors']]
 if len(times)!=res['pilot_native_sector_solves'] or any(not math.isfinite(t) or t<=0 for t in times):raise ValueError('Missing all sector timings')
 if len(n['points'])!=14 or n['points'][0]['timing_phase']!='cold_first_complete_point' or any(p['timing_phase']!='warm_after_first_complete_point' for p in n['points'][1:]):raise ValueError('Missing first-complete-point timing classification')
 if any(s['timing_phase']!=p['timing_phase'] for p in n['points'] for s in p['spin_sectors']):raise ValueError('Changed per-sector timing phase')
 warm=[(p,s) for p in n['points'][1:] for s in p['spin_sectors']]
 if len(warm)!=91 or {p['gauge'] for p,s in warm}!=set(c['gauges']) or {(s['Nup'],s['Ndown']) for p,s in warm}!={(nu,6-nu) for nu in range(7)} or max(s['dimension'] for p,s in warm)!=400:raise ValueError('Incomplete mandatory warm coverage')
 warm_times=[s['elapsed_seconds'] for p,s in warm]
 # Every full dense sector is no larger than a measured pilot L6 sector.
 # An empirical upper envelope, not a theorem or a scientific error estimate.
 native_forecast=res['projection_safety_factor']*(processes['native']['wall_seconds']+res['full_native_sector_solves']*max(warm_times))
 total=native_forecast+res['projection_safety_factor']*14*(processes['reference']['wall_seconds']+processes['comparison']['wall_seconds'])+res['projection_startup_guard_seconds']
 peak=res['projection_safety_factor']*(max(x['max_rss_kib'] for x in processes.values())/1024+res['projection_extra_memory_mib'])
 eligible=total<=res['full_projection_limit_seconds'] and peak<=res['full_projection_limit_mib'] and native_forecast<=res['production_target_timeout_seconds']-res['termination_guard_seconds']
 write(a.output,dict(schema='A25_EXCLUDED_PILOT_RESOURCE_ASSESSMENT_V1',source_freeze_sha256=sha(HERE/'source_freeze.json'),input_sha256={'execution':sha(r/'execution.json'),'comparison':sha(r/'comparison.json'),'native':sha(r/'native.toml')},formula='2*(entire cold pilot native wall+980*max of all91 warm sector walls after first complete point)+2*14*(reference wall+comparison wall)+30sec; peak2*(observed peakMiB+64)',warm_sector_count=len(warm),cold_sector_count=7,warm_maximum_dimension=400,native_forecast_seconds=native_forecast,full_forecast_seconds=total,full_forecast_mib=peak,limits=dict(seconds=res['full_projection_limit_seconds'],MiB=res['full_projection_limit_mib'],native_seconds=res['production_target_timeout_seconds']-res['termination_guard_seconds']),eligible_for_root_full_review=bool(eligible),full_execution_authorized=False,independent_audit_and_root_review_still_required=True,scientific_completions=0,catalogue_status='NOT_RUN',scope='Measured excluded pilot supports only an empirical bounded-resource projection; no full scientific result or automatic submission'))
if __name__=='__main__':main()
