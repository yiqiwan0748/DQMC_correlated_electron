"""Source/role/runtime contract only; no target/reference scientific formulas."""
import hashlib, json, os, platform, sys, tomllib
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,x):
 p=Path(p)
 with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def contract(compute=False):
 c=tomllib.loads((HERE/'manifest.toml').read_text())
 if not (HERE/'source_freeze.json').is_file():raise ValueError('Unfrozen candidate; no evaluation')
 pins={}
 for line in (HERE/'SHA256SUMS').read_text().splitlines():
  h,n=line.split('  ',1)
  if sha(HERE/n)!=h:raise ValueError('Changed source '+n)
  pins[n]=h
 if sha(HERE/'proposal.json')!=c['proposal_sha256'] or sha(HERE/'proposal_review.json')!=c['proposal_review_sha256']:raise ValueError('Approved proposal identity changed')
 for n,h in c['native_source_sha256'].items():
  if sha(HERE/'source_snapshot'/n)!=h:raise ValueError('Changed native source')
 if compute and not os.getenv('SLURM_JOB_ID'):raise ValueError('Scientific producer requires Slurm compute allocation')
 if platform.python_version()!=c['python_version']:raise ValueError('Pinned Python required')
 return c,pins
def runtime_contract():
 d=load(HERE/'runtime_pins.json')
 if d['schema']!='A25_EXPECTED_RUNTIME_FILE_PINS_V1' or platform.python_version()!=d['python_version'] or str(Path(sys.executable).resolve())!=d['python_executable_realpath']:raise ValueError('Runtime identity differs')
 observed={}
 for n,spec in d['files'].items():
  p=Path(n)
  if str(p.resolve())!=spec['realpath'] or p.stat().st_size!=spec['bytes'] or sha(p)!=spec['sha256']:raise ValueError('Changed runtime file '+n)
  observed[n]=spec['sha256']
 return observed
def point_specs(c,mode):
 fs=[f for f in c['fixtures'] if mode=='production' or f['L']==c['pilot_L']]
 centers=c['centers_units'] if mode=='production' else [c['pilot_center_units']]
 return [(f,center,center+off,gauge) for f in fs for center in centers for off in c['stencil_union_offsets_units'] for gauge in c['gauges']]
def point_id(L,center,flux,gauge):return f'L{L}/center{center}/flux{flux}/{gauge}'
