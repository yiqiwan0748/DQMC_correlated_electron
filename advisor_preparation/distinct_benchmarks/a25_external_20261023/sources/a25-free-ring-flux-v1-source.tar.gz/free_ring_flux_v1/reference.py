#!/usr/bin/env python3
"""Independent stdlib plane waves, occupation sums and determinant products."""
import argparse, cmath, itertools, math, os, platform, time
from pathlib import Path
from io_contract import HERE,contract,runtime_contract,point_specs,point_id,sha,write

def determinant(a):
 """Small pivoted elimination, never native eigenvectors or target operators."""
 a=[list(row) for row in a];n=len(a);answer=1+0j
 for j in range(n):
  pivot=max(range(j,n),key=lambda i:abs(a[i][j]))
  if a[pivot][j]==0:return 0j
  if pivot!=j:a[j],a[pivot]=a[pivot],a[j];answer=-answer
  z=a[j][j];answer*=z
  for i in range(j+1,n):
   ratio=a[i][j]/z
   for k in range(j+1,n):a[i][k]-=ratio*a[j][k]
 return answer

def one_point(f,center,units,gauge,c):
 L=f['L'];N=f['N'];phi=units/c['flux_units_denominator'];t=c['t'];occ=f['occupied_integer_modes']
 wave=lambda n,j:cmath.exp(2j*math.pi*n*j/L)/math.sqrt(L)*(cmath.exp(1j*j*phi/L) if gauge=='boundary_seam' else 1)
 energies=[-2*t*math.cos((2*math.pi*n+phi)/L) for n in range(L)]
 # Spectral reconstruction is independent of the native edge-loop adapter.
 K=[[sum(energies[n]*wave(n,a)*wave(n,b).conjugate() for n in range(L)) for b in range(L)] for a in range(L)]
 ordered=sorted(energies);sectors=[dict(Nup=nu,Ndown=N-nu,energy=math.fsum(ordered[:nu])+math.fsum(ordered[:N-nu])) for nu in range(max(0,N-L),min(L,N)+1)]
 E=-4*t*math.fsum(math.cos((2*math.pi*n+phi)/L) for n in occ)
 current=-(4*t/L)*math.fsum(math.sin((2*math.pi*n+phi)/L) for n in occ)
 curvature=(4*t/L**2)*math.fsum(math.cos((2*math.pi*n+phi)/L) for n in occ)
 branch=set(n%L for n in occ);by_index=sorted(range(L),key=lambda n:energies[n]);p=len(occ)
 shellgap=ordered[p]-ordered[p-1];other_sector_gaps=[s['energy']-E for s in sectors if s['Nup']!=f['Nup']]
 globalgap=min([shellgap]+other_sector_gaps)
 masks=[sum(1<<j for j in positions) for positions in itertools.combinations(range(L),p)]
 amp={mask:determinant([[wave(n,j) for n in occ] for j in range(L) if mask>>j&1]) for mask in masks}
 vector=[amp[u]*amp[d] for u in masks for d in masks]
 return dict(id=point_id(L,center,units,gauge),L=L,N=N,center_units=center,flux_units=units,gauge=gauge,phi=phi,
  K_real=[[z.real for z in row] for row in K],K_imag=[[z.imag for z in row] for row in K],
  energy=E,current=current,curvature=curvature,stiffness=L*curvature/2,
  max_E5=4*t*p/L**5,max_E6=4*t*p/L**6,one_body_energies=energies,
  shell_gap=shellgap,global_gap=globalgap,closed_shell_branch_matches=set(by_index[:p])==branch,
  spin_sectors=sectors,balanced_basis_up_masks=[u for u in masks for d in masks],balanced_basis_down_masks=[d for u in masks for d in masks],
  slater_real=[z.real for z in vector],slater_imag=[z.imag for z in vector],slater_norm=math.fsum(abs(z)**2 for z in vector))

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('output',type=Path);a=p.parse_args()
 c,source=contract(compute=True);runtime=runtime_contract();start=time.monotonic()
 points=[one_point(f,center,units,g,c) for f,center,units,g in point_specs(c,a.mode)]
 write(a.output,dict(schema='A25_STDLIB_ANALYTIC_RAW_V1',backend='independent_stdlib_reference',mode=a.mode,
  job_id=os.environ['SLURM_JOB_ID'],python_version=platform.python_version(),source_sha256=source,
  source_freeze_sha256=sha(HERE/'source_freeze.json'),runtime_pins_sha256=sha(HERE/'runtime_pins.json'),runtime_file_sha256=runtime,
  target_raw_imported=False,scientific_completions=0,points=points,elapsed_seconds=time.monotonic()-start))
if __name__=='__main__':main()
