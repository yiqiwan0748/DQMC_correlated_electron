#!/usr/bin/env python3
"""Full mandatory A25 grids and separately qualified finite-difference budgets."""
import argparse, cmath, math, os, sys, tomllib
from pathlib import Path
from io_contract import HERE,contract,runtime_contract,point_specs,point_id,sha,load,write

class Gates:
 def __init__(self):self.rows=[]
 def check(self,name,value,relation,bound,kind='qualification'):
  if relation=='eq':passed=value==bound
  elif not math.isfinite(value):passed=False
  else:passed=value<=bound if relation=='le' else value>=bound
  self.rows.append(dict(name=name,value=value,relation=relation,bound=bound,kind=kind,passed=bool(passed)))
 def error(self,name,value,bound,kind='comparison'):self.check(name,float(value),'le',bound,kind)

def complex_matrix(re,im):
 if len(re)!=len(im) or any(len(a)!=len(b) for a,b in zip(re,im)):raise ValueError('Complex matrix shape')
 return [[complex(x,y) for x,y in zip(a,b)] for a,b in zip(re,im)]
def max_matrix_error(A,B):
 if len(A)!=len(B) or any(len(a)!=len(b) for a,b in zip(A,B)):raise ValueError('Incomplete matrix')
 return max((abs(a-b) for ar,br in zip(A,B) for a,b in zip(ar,br)),default=0.)
def fidelity(a,b):
 if len(a)!=len(b):raise ValueError('Incomplete vector')
 na=math.fsum(abs(z)**2 for z in a);nb=math.fsum(abs(z)**2 for z in b)
 return abs(sum(x.conjugate()*y for x,y in zip(a,b)))**2/(na*nb)
def labels(up,dn):
 x=list(zip(up,dn))
 if len(x)!=len(set(x)):raise ValueError('Duplicate occupation labels')
 return x
def fock_action(K,ls,v):
 """Independent explicit Fock action, used only to qualify analytic Slater states."""
 where={pair:i for i,pair in enumerate(ls)};out=[0j]*len(v);L=len(K)
 for col,(u,d) in enumerate(ls):
  for spin,bits in enumerate((u,d)):
   for source in range(L):
    if not bits>>source&1:continue
    removed=bits^(1<<source)
    for dest in range(L):
     if removed>>dest&1 or K[dest][source]==0:continue
     parity=(bits&((1<<source)-1)).bit_count()+(removed&((1<<dest)-1)).bit_count()
     changed=removed|(1<<dest);pair=(changed,d) if spin==0 else (u,changed)
     out[where[pair]]+=(-1 if parity%2 else 1)*K[dest][source]*v[col]
 return out

def compare(native,ref,c):
 g=Gates();mode=ref['mode'];lim=c['gates'];expected={point_id(f['L'],ctr,u,ga):(f,ctr,u,ga) for f,ctr,u,ga in point_specs(c,mode)}
 nt={p['id']:p for p in native['points']};rt={p['id']:p for p in ref['points']}
 if len(nt)!=len(native['points']) or len(rt)!=len(ref['points']) or set(nt)!=set(expected) or set(rt)!=set(expected):raise ValueError('Incomplete/duplicate full point/gauge grid')
 energies={};reference_points={};point_metrics=[]
 for key,(f,ctr,units,gauge) in expected.items():
  a,b=nt[key],rt[key];L=f['L'];N=f['N'];tag=key
  for row in (a,b):
   if (row['L'],row['N'],row['center_units'],row['flux_units'],row['gauge'])!=(L,N,ctr,units,gauge) or row['phi']!=units/c['flux_units_denominator']:raise ValueError('Changed point metadata')
  K=complex_matrix(a['K_real'],a['K_imag']);Kr=complex_matrix(b['K_real'],b['K_imag'])
  if len(K)!=L or any(len(row)!=L for row in K):raise ValueError('Incomplete native K')
  g.error(tag+'/all complex K entries',max_matrix_error(K,Kr),lim['K_abs'])
  g.error(tag+'/native K Hermiticity',a['K_hermiticity_abs'],lim['hermiticity_abs'],'qualification')
  if units:g.check(tag+'/nonzero native imaginary hopping',a['maximum_imaginary_hopping'],'ge',lim['imaginary_hopping_min'])
  g.check(tag+'/fixed closed shell',b['closed_shell_branch_matches'],'eq',True);g.check(tag+'/analytic shell gap',b['shell_gap'],'ge',lim['analytic_gap_min']);g.check(tag+'/analytic global fixedN gap',b['global_gap'],'ge',lim['analytic_gap_min'])
  wanted={(nu,N-nu) for nu in range(max(0,N-L),min(L,N)+1)};sa={(s['Nup'],s['Ndown']):s for s in a['spin_sectors']};sr={(s['Nup'],s['Ndown']):s for s in b['spin_sectors']}
  if len(sa)!=len(a['spin_sectors']) or len(sr)!=len(b['spin_sectors']) or set(sa)!=wanted or set(sr)!=wanted:raise ValueError('Missing/duplicate totalN spin sector')
  for pair,s in sa.items():
   st=tag+'/sector'+str(pair);nu,nd=pair
   if s['dimension']!=math.comb(L,nu)*math.comb(L,nd) or s['method']!='dense' or not s['converged'] or not s['ground_subspace_resolved']:raise ValueError('Changed actual native solver/sector')
   g.error(st+'/independent occupation ground energy',abs(s['energy']-sr[pair]['energy']),lim['sector_energy_abs'])
   g.error(st+'/reported residual',s['reported_residual'],lim['native_residual_max'],'qualification');g.error(st+'/fresh native H residual',s['fresh_residual'],lim['native_residual_max'],'qualification')
  balanced=a['balanced'];pair=(f['Nup'],f['Ndown']);E=balanced['energy'];g.error(tag+'/balanced analytic totalE',abs(E-b['energy']),lim['energy_abs']);g.error(tag+'/global totalN groundE',abs(min(s['energy'] for s in sa.values())-b['energy']),lim['energy_abs'])
  if balanced['ground_dimension']!=1 or sa[pair]['ground_dimension']!=1:raise ValueError('Balanced ground not unique; no ensemble substitute')
  ls=labels(balanced['basis_up_masks'],balanced['basis_down_masks']);rls=labels(b['balanced_basis_up_masks'],b['balanced_basis_down_masks']);where={p:i for i,p in enumerate(rls)}
  if len(ls)!=math.comb(L,f['Nup'])**2 or set(ls)!=set(rls):raise ValueError('Incomplete ground-state mask map')
  vr=complex_matrix(balanced['vectors_real'],balanced['vectors_imag'])
  if len(vr)!=len(ls) or any(len(row)!=1 for row in vr):raise ValueError('Incomplete native balanced vector')
  v=[row[0] for row in vr];sv=[complex(x,y) for x,y in zip(b['slater_real'],b['slater_imag'])]
  if len(sv)!=len(rls):raise ValueError('Incomplete independent Slater vector')
  mapped=[sv[where[p]] for p in ls];fid=fidelity(v,mapped)
  g.error(tag+'/native norm',abs(math.fsum(abs(z)**2 for z in v)-1),lim['normalization_abs'],'qualification');g.error(tag+'/independent Slater norm',abs(b['slater_norm']-1),lim['normalization_abs'],'qualification');g.error(tag+'/independent full-vector Slater fidelity',abs(1-fid),lim['balanced_fidelity_error_max'])
  action=fock_action(Kr,rls,sv);sres=math.sqrt(math.fsum(abs(x-b['energy']*y)**2 for x,y in zip(action,sv)))
  g.error(tag+'/independent Slater fullFock residual',sres,lim['slater_residual_max'],'qualification')
  energies[L,ctr,units,gauge]=E;reference_points[L,ctr,units,gauge]=b
  point_metrics.append(dict(id=key,energy_error=abs(E-b['energy']),fidelity=fid,reference_slater_residual=sres,sectors=len(sa)))
 # Both explicit gauges must transform by the fixed pre-data diagonal phases.
 for f,ctr,units,ga in point_specs(c,mode):
  if ga!='uniform':continue
  L=f['L'];phi=units/c['flux_units_denominator'];a=nt[point_id(L,ctr,units,'uniform')];b=nt[point_id(L,ctr,units,'boundary_seam')];K=complex_matrix(a['K_real'],a['K_imag']);Kb=complex_matrix(b['K_real'],b['K_imag']);phase=[cmath.exp(1j*j*phi/L) for j in range(L)]
  transformed=[[phase[i]*K[i][j]*phase[j].conjugate() for j in range(L)] for i in range(L)]
  g.error(f'L{L}/ctr{ctr}/flux{units}/gauge K relation',max_matrix_error(Kb,transformed),lim['K_abs']);g.error(f'L{L}/ctr{ctr}/flux{units}/gauge energy',abs(a['balanced']['energy']-b['balanced']['energy']),lim['gauge_energy_abs'])
 responses=[];eps=sys.float_info.epsilon
 fs=[f for f in c['fixtures'] if mode=='production' or f['L']==c['pilot_L']];centers=c['centers_units'] if mode=='production' else [c['pilot_center_units']]
 for f in fs:
  L=f['L']
  for ctr in centers:
   for gauge in c['gauges']:
    previous=None
    for step in c['steps_units']:
     h=step/c['flux_units_denominator'];offsets=[-2,-1,0,1,2];Es=[energies[L,ctr,ctr+k*step,gauge] for k in offsets];bs=[reference_points[L,ctr,ctr+k*step,gauge] for k in offsets];middle=bs[2]
     first_coeff=[1,-8,0,8,-1];second_coeff=[-1,16,-30,16,-1];current=-math.fsum(q*e for q,e in zip(first_coeff,Es))/(12*h);curvature=math.fsum(q*e for q,e in zip(second_coeff,Es))/(12*h*h);D=L*curvature/2
     allowance=[lim['energy_abs']+64*eps*max(1,abs(b['energy'])) for b in bs]
     Iinput=math.fsum(abs(q)*de for q,de in zip(first_coeff,allowance))/(12*h);Cinput=math.fsum(abs(q)*de for q,de in zip(second_coeff,allowance))/(12*h*h)
     Itrunc=h**4*middle['max_E5']/30;Ctrunc=h**4*middle['max_E6']/90
     Ib=Iinput+Itrunc+64*eps*max(1,abs(middle['current']));Cb=Cinput+Ctrunc+64*eps*max(1,abs(middle['curvature']));Db=L*Cb/2
     tag=f'L{L}/ctr{ctr}/{gauge}/h{step}';vals=[('current',current,middle['current'],Ib,lim['current_abs']),('curvature',curvature,middle['curvature'],Cb,lim['curvature_abs']),('stiffness',D,middle['stiffness'],Db,lim['stiffness_abs'])]
     for name,observed,exact,budget,margin in vals:
      g.check(tag+'/'+name+' full error budget eligibility',budget,'le',margin);g.error(tag+'/'+name+' exact derivative',abs(observed-exact),margin);g.error(tag+'/'+name+' conditional propagated enclosure',abs(observed-exact),budget)
     row=dict(L=L,center_units=ctr,gauge=gauge,step_units=step,current=current,curvature=curvature,stiffness=D,current_budget=Ib,curvature_budget=Cb,stiffness_budget=Db,current_input=Iinput,curvature_input=Cinput,current_truncation=Itrunc,curvature_truncation=Ctrunc)
     if previous:
      for name in ['current','curvature','stiffness']:g.error(tag+'/'+name+' both-fixed-step consistency',abs(row[name]-previous[name]),row[name+'_budget']+previous[name+'_budget'])
     previous=row;responses.append(row)
 failure=any(not r['passed'] for r in g.rows);quality=any(not r['passed'] and r['kind']=='qualification' for r in g.rows);status='UNRESOLVED' if quality else ('FAIL' if failure else 'PASS')
 return dict(status=status,checks=g.rows,points=point_metrics,responses=responses,sector_solves=sum(len(p['spin_sectors']) for p in native['points']))

def main():
 p=argparse.ArgumentParser();p.add_argument('--native',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();c,source=contract();runtime=runtime_contract();n=tomllib.loads(a.native.read_text());r=load(a.reference);mode=r['mode']
 out=dict(schema='A25_COMPARISON_V1',catalogue_id='A25',mode=mode,scientific_completions=0,catalogue_status='NOT_RUN')
 try:
  if mode not in ('pilot','production') or n['mode']!=mode or n['schema']!='A25_NATIVE_COMPLEX_ED_RAW_V1' or r['schema']!='A25_STDLIB_ANALYTIC_RAW_V1' or n['backend']!='actual_native_complex_ED' or r['backend']!='independent_stdlib_reference' or n['job_id']!=r['job_id']:raise ValueError('Wrong raw role/mode/job')
  for d in (n,r):
   if d['source_sha256']!=source or d['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or d['runtime_pins_sha256']!=sha(HERE/'runtime_pins.json') or d['scientific_completions']!=0:raise ValueError('Changed source/runtime binding')
  if n['julia_version']!=c['julia_version'] or n['threads']!=1 or n['native_source_sha256']!=c['native_source_sha256'] or n['runtime_file_sha256']!=runtime or r['python_version']!=c['python_version'] or r['runtime_file_sha256']!=runtime or r['target_raw_imported']:raise ValueError('Changed native/reference runtime/scope')
  if not n['loaded_native_providers'] or any(p not in runtime for p in n['loaded_native_providers']):raise ValueError('Unpinned actual Julia/BLAS provider')
  if not any('libopenblas' in Path(p).name for p in n['loaded_native_providers']) or not any('libblastrampoline' in Path(p).name for p in n['loaded_native_providers']):raise ValueError('Mandatory loaded OpenBLAS/trampoline missing')
  bp=n['blas_config_providers'];expected_blas={p for p in runtime if 'libopenblas' in Path(p).name}
  if not bp or {p['path'] for p in bp}!=expected_blas or any(p['interface']!='ilp64' or p['path'] not in runtime for p in bp):raise ValueError('Actual configured BLAS provider/interface differs')
  out.update(compare(n,r,c));out.update(catalogue_status=out['status'] if mode=='production' else 'NOT_RUN',scientific_completions=int(mode=='production' and out['status']=='PASS'),pilot_excluded=mode=='pilot')
 except Exception as ex:out.update(status='UNRESOLVED',reason=type(ex).__name__+': '+str(ex),checks=[],catalogue_status='NOT_RUN' if mode=='pilot' else 'UNRESOLVED')
 out.update(source_freeze_sha256=sha(HERE/'source_freeze.json'),input_sha256={'native':sha(a.native),'reference':sha(a.reference)},scope='One free closed-shell 1D ring flux response through NEW K/Slater adapters and actual unchanged native complex ED; no arbitrary-flux DQMC/interacting/bulk stiffness claim')
 write(a.output,out);print(out['status']);raise SystemExit({'PASS':0,'FAIL':1,'UNRESOLVED':2}[out['status']])
if __name__=='__main__':main()
