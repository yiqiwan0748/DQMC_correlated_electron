#!/usr/bin/env python3
"""Serial source-closed producers; no scheduler submission or automatic full admission."""
import argparse, datetime, json, os, signal, subprocess, sys, time
from pathlib import Path
from io_contract import HERE,contract,runtime_contract,load,sha,write

def resources(path):
 text=Path(path).read_text();out={}
 for line in text.splitlines():
  if 'Maximum resident set size (kbytes):' in line:out['max_rss_kib']=int(line.rsplit(':',1)[1])
 return out
def run(label,argv,out,timeout):
 start=time.time();prefix=out/label;stdout=prefix.with_suffix('.stdout.txt');stderr=prefix.with_suffix('.stderr.txt');timelog=prefix.with_suffix('.time.txt')
 with stdout.open('x') as so,stderr.open('x') as se:
  p=subprocess.Popen(['/usr/bin/time','-v','-o',str(timelog),*argv],stdout=so,stderr=se,start_new_session=True)
  timed_out=False
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(p.pid,signal.SIGTERM)
   try:code=p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 return dict(label=label,argv=argv,exit_code=code,timed_out=timed_out,started_unix=start,finished_unix=time.time(),wall_seconds=time.time()-start,**resources(timelog),stdout=stdout.name,stderr=stderr.name,time=timelog.name)

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('--output',type=Path,required=True);p.add_argument('--pilot-assessment',type=Path);p.add_argument('--root-full-review',type=Path);p.add_argument('--expected-root-review-sha256');a=p.parse_args()
 for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','JULIA_NUM_THREADS']:os.environ[n]='1'
 c,source=contract(compute=True);before=runtime_contract()
 if os.environ.get('SLURM_CPUS_PER_TASK')!='1':raise ValueError('One CPU allocation required')
 if os.environ.get('SLURM_MEM_PER_NODE')!=str(c['resources']['memory_mb']):raise ValueError('Exactly3500MB allocation required; no absent/default memory admission')
 guard=None
 if a.mode=='production':
  if not(a.pilot_assessment and a.root_full_review and a.expected_root_review_sha256):raise ValueError('Full execution blocked pending separate reviewed pilot')
  assessment=load(a.pilot_assessment);review=load(a.root_full_review)
  if assessment.get('schema')!='A25_EXCLUDED_PILOT_RESOURCE_ASSESSMENT_V1' or not assessment.get('eligible_for_root_full_review') or assessment['scientific_completions']!=0 or assessment['source_freeze_sha256']!=sha(HERE/'source_freeze.json'):raise ValueError('Pilot does not qualify this source')
  if sha(a.root_full_review)!=a.expected_root_review_sha256 or review.get('schema')!='A25_ROOT_FULL_EXECUTION_REVIEW_V1' or review.get('approved') is not True or review.get('scope')!='A25 full frozen grid only' or review.get('pilot_assessment_sha256')!=sha(a.pilot_assessment) or review.get('source_freeze_sha256')!=sha(HERE/'source_freeze.json'):raise ValueError('Missing source-bound independent/root full review')
  if not review.get('independent_pilot_audit_sha256'):raise ValueError('Independent pilot audit required')
  guard=dict(pilot_assessment_sha256=sha(a.pilot_assessment),root_review_sha256=sha(a.root_full_review),independent_pilot_audit_sha256=review['independent_pilot_audit_sha256'])
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False);(out/'results').mkdir();r=out/'results';runtime=load(HERE/'runtime_pins.json');julia=str(Path(runtime['julia_root_realpath'])/'bin/julia')
 receipt=dict(schema='A25_SCIENTIFIC_EXECUTION_V1',mode=a.mode,job_id=os.environ['SLURM_JOB_ID'],source_freeze_sha256=sha(HERE/'source_freeze.json'),source_sha256=source,runtime_pins_sha256=sha(HERE/'runtime_pins.json'),runtime_before_sha256=before,threads=1,scientific_completions=0,full_review=guard,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='UNRESOLVED',processes=[])
 try:
  for label,argv,timeout in [
   ('native',[julia,'--startup-file=no','--threads=1',str(HERE/'target.jl'),a.mode,str(r/'native.toml')],c['resources'][a.mode+'_target_timeout_seconds']),
   ('reference',[sys.executable,str(HERE/'reference.py'),a.mode,str(r/'reference.json')],c['resources'][a.mode+'_reference_timeout_seconds']),
   ('comparison',[sys.executable,str(HERE/'compare.py'),'--native',str(r/'native.toml'),'--reference',str(r/'reference.json'),'--output',str(r/'comparison.json')],c['resources'][a.mode+'_compare_timeout_seconds'])]:
   row=run(label,argv,r,timeout);receipt['processes'].append(row)
   if row['exit_code']!=0 or row['timed_out']:raise ValueError('Process did not complete: '+label)
  receipt['status']='PROCESSES_COMPLETE'
 except Exception as ex:receipt['reason']=type(ex).__name__+': '+str(ex)
 finally:
  try:receipt['runtime_after_sha256']=runtime_contract()
  except Exception as ex:receipt.update(status='UNRESOLVED',runtime_after_error=type(ex).__name__+': '+str(ex))
  receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['outputs']={p.relative_to(r).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(r.iterdir()) if p.is_file()};write(r/'execution.json',receipt)
 print(receipt['status']);raise SystemExit(0 if receipt['status']=='PROCESSES_COMPLETE' else 2)
if __name__=='__main__':main()
