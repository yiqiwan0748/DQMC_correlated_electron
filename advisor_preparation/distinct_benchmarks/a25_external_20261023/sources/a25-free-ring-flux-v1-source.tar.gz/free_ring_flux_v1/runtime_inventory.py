#!/usr/bin/env python3
"""Read-only runtime file metadata; no math/cmath/Julia numerical imports."""
import hashlib, importlib.util, json, os, platform, re, subprocess, sys
from pathlib import Path

def main():
    if len(sys.argv)!=2: raise SystemExit('JULIA_ROOT argument required')
    jr=Path(sys.argv[1]).resolve(); paths=set(); traces={}
    paths.add(Path(sys.executable).resolve())
    for name in ['math','cmath','_json','_hashlib','_struct','resource','tomllib','tomllib._parser','json','json.encoder','json.decoder','json.scanner','pathlib','hashlib','platform','subprocess','statistics']:
        spec=importlib.util.find_spec(name)
        if spec and spec.origin and spec.origin not in ('built-in','frozen'): paths.add(Path(spec.origin).resolve())
    paths.add(jr/'bin/julia')
    for pattern in ['lib/libjulia.so*','lib/julia/libjulia*.so*','lib/julia/sys.so','lib/julia/libopenblas*.so*','lib/julia/libblastrampoline.so*']:
        paths.update(p.resolve() for p in jr.glob(pattern) if p.is_file())
    la=jr/'share/julia/stdlib/v1.12/LinearAlgebra'
    paths.update(p.resolve() for p in la.rglob('*.jl') if p.is_file())
    for p in sorted(paths.copy()):
        if p.suffix=='.jl' or p.suffix=='.py':continue
        r=subprocess.run(['ldd',str(p)],capture_output=True,text=True,check=False)
        traces[str(p)]=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
        for line in r.stdout.splitlines():
            match=re.search(r'=>\s+(/\S+)',line) or re.match(r'\s*(/\S+)',line)
            if match:
                q=Path(match.group(1)).resolve()
                if q.is_file():paths.add(q)
    files={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),realpath=str(p.resolve())) for p in sorted(paths)}
    print(json.dumps(dict(schema='A25_EXPECTED_RUNTIME_FILE_PINS_V1',python_version=platform.python_version(),python_executable_realpath=str(Path(sys.executable).resolve()),julia_root_realpath=str(jr),julia_version='1.12.1',files=files,ldd_traces=traces,metadata_only=True,no_numerical_modules_imported=True,no_binaries_copied=True),indent=2))
if __name__=='__main__':main()
