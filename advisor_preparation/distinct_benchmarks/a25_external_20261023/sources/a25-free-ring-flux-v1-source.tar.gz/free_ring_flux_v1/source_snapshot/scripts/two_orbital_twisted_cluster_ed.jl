#!/usr/bin/env julia

module TwoOrbitalTwistedClusterED

using LinearAlgebra
import LinearAlgebra: mul!

# This file is intentionally self contained.  It consumes the repository's
# validated hopping convention without changing the package API.
module ValidatedKinetic
include(joinpath(@__DIR__, "..", "src", "noninteracting.jl"))
include(joinpath(@__DIR__, "..", "src", "realspace_kinetic.jl"))
end

const ModelParameters = ValidatedKinetic.ModelParameters
const DEFAULT_PARAMETERS = ValidatedKinetic.DEFAULT_PARAMETERS

export ModelParameters,
       DEFAULT_PARAMETERS,
       SectorBasis,
       SectorHamiltonian,
       twisted_cluster_kinetic_matrix,
       large_gauge_unitary,
       c4_single_particle_unitary,
       twist_symmetry_orbit,
       sector_basis,
       sector_hamiltonian,
       dense_sector_hamiltonian,
       ground_state_observables,
       canonical_ground_state,
       spin_flip_error,
       canonical_twist_orbit_scan,
       scan_u_twist_orbit

const DEFAULT_MAX_BASIS_DIMENSION = 100_000
const DEFAULT_MAX_DENSE_BYTES = 512 * 1024^2
const DEFAULT_MAX_KRYLOV_BYTES = 512 * 1024^2

function _checked_lattice_size(L::Integer)
    L isa Bool && throw(ArgumentError("L must be an integer lattice size"))
    L >= 2 || throw(ArgumentError("twisted cluster ED requires L >= 2"))
    return try
        Int(L)
    catch
        throw(ArgumentError("L must fit in an Int"))
    end
end

function _checked_finite_real(value::Real, name::AbstractString)
    value isa Bool && throw(ArgumentError("$name must be a real number"))
    isfinite(value) || throw(ArgumentError("$name must be finite"))
    return value
end

@inline _mode_index(x::Int, y::Int, orbital::Int, L::Int) =
    2 * (x + L * y) + orbital

"""
    twisted_cluster_kinetic_matrix(L=2, theta_x=0, theta_y=0,
                                   parameters=DEFAULT_PARAMETERS)

Construct the Hermitian one-spin kinetic matrix on an `L`-by-`L` torus with
boundary twists `(theta_x,theta_y)`.  The orbital-fast basis is
`(d_xz,d_yz)` in each cell.  In the boundary gauge, a hopping which crosses a
boundary receives `exp(i theta dot winding)`.  It is gauge equivalent to a
uniform Peierls phase `exp(i theta dot d/L)`, so the allowed Bloch momenta are
shifted by `theta/L`.

The four positive-displacement hopping blocks are exactly the repository
blocks for `t1`, `t2`, `t3`, and `t4`; the reverse hopping is their Hermitian
conjugate.  At zero twist this function is exactly the validated periodic
real-space constructor (converted to complex storage).  In this boundary-gauge
representation, shifting either twist by `2pi` returns the same matrix
elementwise, up to floating-point phase evaluation.
"""
function twisted_cluster_kinetic_matrix(
    L::Integer=2,
    theta_x::Real=0,
    theta_y::Real=0,
    parameters::ModelParameters=DEFAULT_PARAMETERS,
)
    lattice_size = _checked_lattice_size(L)
    _checked_finite_real(theta_x, "theta_x")
    _checked_finite_real(theta_y, "theta_y")
    number_of_modes = 2 * lattice_size^2
    number_of_modes <= 64 || throw(ArgumentError(
        "bit-basis ED supports at most 64 spatial modes (L <= 5)",
    ))

    R = promote_type(
        typeof(float(parameters.t1)),
        typeof(float(theta_x)),
        typeof(float(theta_y)),
    )
    CT = Complex{R}
    converted_parameters = ModelParameters(
        convert(R, parameters.t1),
        convert(R, parameters.t2),
        convert(R, parameters.t3),
        convert(R, parameters.t4),
    )
    tx = convert(R, theta_x)
    ty = convert(R, theta_y)
    kinetic = zeros(CT, number_of_modes, number_of_modes)

    for y in 0:(lattice_size - 1), x in 0:(lattice_size - 1)
        for (dx, dy, block) in
            ValidatedKinetic._positive_displacement_blocks(converted_parameters)
            destination_x = mod(x + dx, lattice_size)
            destination_y = mod(y + dy, lattice_size)
            winding_x = div(x + dx - destination_x, lattice_size)
            winding_y = div(y + dy - destination_y, lattice_size)
            phase = cis(tx * winding_x + ty * winding_y)
            for source_orbital in 1:2, destination_orbital in 1:2
                hopping = convert(R, block[source_orbital, destination_orbital])
                iszero(hopping) && continue
                source = _mode_index(x, y, source_orbital, lattice_size)
                destination = _mode_index(
                    destination_x,
                    destination_y,
                    destination_orbital,
                    lattice_size,
                )
                amplitude = hopping * phase
                kinetic[source, destination] += amplitude
                kinetic[destination, source] += conj(amplitude)
            end
        end
    end
    return kinetic
end

twisted_cluster_kinetic_matrix(;
    L::Integer=2,
    theta_x::Real=0,
    theta_y::Real=0,
    parameters::ModelParameters=DEFAULT_PARAMETERS,
) = twisted_cluster_kinetic_matrix(L, theta_x, theta_y, parameters)

"""
    large_gauge_unitary(L, winding_x=1, winding_y=0)

Return the (trivial) large-gauge unitary in the boundary gauge.  Boundary-gauge
matrices are themselves elementwise periodic under
`theta -> theta + 2pi*(winding_x,winding_y)`, so this is the identity.  The
integer arguments are retained to make that convention explicit at call sites.
"""
function large_gauge_unitary(
    L::Integer,
    winding_x::Integer=1,
    winding_y::Integer=0,
)
    lattice_size = _checked_lattice_size(L)
    number_of_modes = 2 * lattice_size^2
    Int(winding_x)
    Int(winding_y)
    return Diagonal(ones(ComplexF64, number_of_modes))
end

function _boundary_gauge_unitary(
    L::Int,
    theta_x::Real,
    theta_y::Real,
)
    R = promote_type(typeof(float(theta_x)), typeof(float(theta_y)))
    tx, ty = convert(R, theta_x), convert(R, theta_y)
    phases = Vector{Complex{R}}(undef, 2L^2)
    for y in 0:(L - 1), x in 0:(L - 1), orbital in 1:2
        phases[_mode_index(x, y, orbital, L)] =
            cis((tx * x + ty * y) / convert(R, L))
    end
    return Diagonal(phases)
end

"""
    c4_single_particle_unitary(L, theta_x=0, theta_y=0)

Return the one-particle representation of a counterclockwise `C4` rotation.
Cells transform as `(x,y)->(-y,x)` modulo `L`, while the real orbitals obey
`d_xz -> d_yz` and `d_yz -> -d_xz`.  The optional twists include the gauge
phases required by the boundary-gauge cuts.  With this convention,
`C(theta)*K(theta_x,theta_y)*C(theta)' = K(-theta_y,theta_x)`.
"""
function c4_single_particle_unitary(
    L::Integer,
    theta_x::Real=0,
    theta_y::Real=0,
)
    lattice_size = _checked_lattice_size(L)
    _checked_finite_real(theta_x, "theta_x")
    _checked_finite_real(theta_y, "theta_y")
    number_of_modes = 2 * lattice_size^2
    R = promote_type(typeof(float(theta_x)), typeof(float(theta_y)))
    bare_rotation = zeros(Complex{R}, number_of_modes, number_of_modes)
    for y in 0:(lattice_size - 1), x in 0:(lattice_size - 1)
        rotated_x = mod(-y, lattice_size)
        rotated_y = mod(x, lattice_size)
        old_xz = _mode_index(x, y, 1, lattice_size)
        old_yz = _mode_index(x, y, 2, lattice_size)
        new_xz = _mode_index(rotated_x, rotated_y, 1, lattice_size)
        new_yz = _mode_index(rotated_x, rotated_y, 2, lattice_size)
        bare_rotation[new_yz, old_xz] = 1
        bare_rotation[new_xz, old_yz] = -1
    end
    original_gauge = _boundary_gauge_unitary(
        lattice_size,
        theta_x,
        theta_y,
    )
    rotated_gauge = _boundary_gauge_unitary(
        lattice_size,
        -theta_y,
        theta_x,
    )
    return rotated_gauge * bare_rotation * adjoint(original_gauge)
end

"""Return a twist and its time-reversal/C4 partners without reducing angles."""
function twist_symmetry_orbit(theta_x::Real, theta_y::Real)
    tx = _checked_finite_real(theta_x, "theta_x")
    ty = _checked_finite_real(theta_y, "theta_y")
    return (
        (label=:identity, theta_x=tx, theta_y=ty),
        (label=:time_reversal, theta_x=-tx, theta_y=-ty),
        (label=:c4, theta_x=-ty, theta_y=tx),
        (label=:time_reversal_c4, theta_x=ty, theta_y=-tx),
    )
end

"""Bit basis for one fixed `(Nup,Ndown)` sector."""
struct SectorBasis
    nmodes::Int
    Nup::Int
    Ndown::Int
    up_states::Vector{UInt64}
    down_states::Vector{UInt64}
    up_indices::Dict{UInt64,Int}
    down_indices::Dict{UInt64,Int}
end

Base.length(basis::SectorBasis) = length(basis.up_states) * length(basis.down_states)
Base.size(basis::SectorBasis) = (length(basis),)

function _fixed_weight_states(nmodes::Int, particles::Int)
    states = UInt64[]
    function append_states!(first_mode::Int, remaining::Int, state::UInt64)
        if iszero(remaining)
            push!(states, state)
            return
        end
        for mode in first_mode:(nmodes - remaining + 1)
            append_states!(
                mode + 1,
                remaining - 1,
                state | (UInt64(1) << (mode - 1)),
            )
        end
    end
    append_states!(1, particles, UInt64(0))
    return states
end

function _sector_dimension(nmodes::Int, Nup::Int, Ndown::Int)
    return binomial(big(nmodes), Nup) * binomial(big(nmodes), Ndown)
end

function sector_basis(
    nmodes::Integer,
    Nup::Integer,
    Ndown::Integer;
    max_basis_dimension::Integer=DEFAULT_MAX_BASIS_DIMENSION,
)
    nmodes isa Bool && throw(ArgumentError("nmodes must be an integer"))
    modes = Int(nmodes)
    1 <= modes <= 64 || throw(ArgumentError("nmodes must lie in 1:64"))
    (Nup isa Bool || Ndown isa Bool) && throw(ArgumentError(
        "Nup and Ndown must be particle counts",
    ))
    0 <= Nup <= modes || throw(ArgumentError("Nup must lie in 0:nmodes"))
    0 <= Ndown <= modes || throw(ArgumentError("Ndown must lie in 0:nmodes"))
    maximum_dimension = Int(max_basis_dimension)
    maximum_dimension > 0 || throw(ArgumentError(
        "max_basis_dimension must be positive",
    ))
    nup, ndown = Int(Nup), Int(Ndown)
    dimension = _sector_dimension(modes, nup, ndown)
    dimension <= maximum_dimension || throw(ArgumentError(
        "sector dimension $dimension exceeds max_basis_dimension=$maximum_dimension",
    ))
    up_states = _fixed_weight_states(modes, nup)
    down_states = _fixed_weight_states(modes, ndown)
    return SectorBasis(
        modes,
        nup,
        ndown,
        up_states,
        down_states,
        Dict(state => index for (index, state) in enumerate(up_states)),
        Dict(state => index for (index, state) in enumerate(down_states)),
    )
end

function sector_basis(
    kinetic::AbstractMatrix,
    Nup::Integer,
    Ndown::Integer;
    kwargs...,
)
    size(kinetic, 1) == size(kinetic, 2) || throw(DimensionMismatch(
        "kinetic matrix must be square",
    ))
    return sector_basis(size(kinetic, 1), Nup, Ndown; kwargs...)
end

@inline function _basis_state(basis::SectorBasis, index::Int)
    number_of_down_states = length(basis.down_states)
    up_index = div(index - 1, number_of_down_states) + 1
    down_index = mod(index - 1, number_of_down_states) + 1
    return basis.up_states[up_index], basis.down_states[down_index]
end

@inline function _basis_index(
    basis::SectorBasis,
    up_state::UInt64,
    down_state::UInt64,
)
    return (basis.up_indices[up_state] - 1) * length(basis.down_states) +
           basis.down_indices[down_state]
end

@inline _occupied(state::UInt64, mode::Int) =
    !iszero(state & (UInt64(1) << (mode - 1)))

@inline function _hop(state::UInt64, destination::Int, source::Int)
    source_bit = UInt64(1) << (source - 1)
    iszero(state & source_bit) && return nothing
    intermediate = state ⊻ source_bit
    destination_bit = UInt64(1) << (destination - 1)
    !iszero(intermediate & destination_bit) && return nothing
    parity = count_ones(state & (source_bit - UInt64(1))) +
             count_ones(intermediate & (destination_bit - UInt64(1)))
    return intermediate | destination_bit, (iseven(parity) ? 1 : -1)
end

"""Matrix-free complex Hermitian Hubbard Hamiltonian in one spin sector."""
struct SectorHamiltonian{T<:AbstractFloat}
    basis::SectorBasis
    kinetic::Matrix{Complex{T}}
    U::T
    h::T
    diagonal::Vector{T}
    oalm_values::Vector{T}
    double_occupancies::Vector{T}
    column_pointers::Vector{Int}
    row_indices::Vector{Int}
    hopping_values::Vector{Complex{T}}
end

Base.size(hamiltonian::SectorHamiltonian) =
    (length(hamiltonian.basis), length(hamiltonian.basis))
Base.size(hamiltonian::SectorHamiltonian, dimension::Integer) =
    size(hamiltonian)[dimension]
Base.eltype(::Type{SectorHamiltonian{T}}) where {T} = Complex{T}
Base.eltype(::SectorHamiltonian{T}) where {T} = Complex{T}

"""
    sector_hamiltonian(K, U, Nup, Ndown; h=0, max_basis_dimension=100_000)

Build `K + U sum_a (n_a_up-1/2)(n_a_down-1/2) - h*Oalm`, with
`Oalm = 1/2 sum_cell[(n_x_up-n_x_down)-(n_y_up-n_y_down)]`.
"""
function sector_hamiltonian(
    kinetic::AbstractMatrix{<:Number},
    U::Real,
    Nup::Integer,
    Ndown::Integer;
    h::Real=0,
    max_basis_dimension::Integer=DEFAULT_MAX_BASIS_DIMENSION,
)
    size(kinetic, 1) == size(kinetic, 2) || throw(DimensionMismatch(
        "kinetic matrix must be square",
    ))
    nmodes = size(kinetic, 1)
    iseven(nmodes) || throw(ArgumentError(
        "the two-orbital kinetic dimension must be even",
    ))
    nmodes <= 64 || throw(ArgumentError("at most 64 spatial modes are supported"))
    ishermitian(kinetic) || throw(ArgumentError("kinetic matrix must be Hermitian"))
    _checked_finite_real(U, "U")
    _checked_finite_real(h, "h")
    U >= 0 || throw(ArgumentError("U must be nonnegative"))
    R = promote_type(
        typeof(float(real(zero(eltype(kinetic))))),
        typeof(float(U)),
        typeof(float(h)),
    )
    converted_kinetic = Matrix{Complex{R}}(kinetic)
    interaction = convert(R, U)
    field = convert(R, h)
    basis = sector_basis(
        nmodes,
        Nup,
        Ndown;
        max_basis_dimension=max_basis_dimension,
    )
    dimension = length(basis)
    diagonal = zeros(R, dimension)
    oalm_values = zeros(R, dimension)
    double_occupancies = zeros(R, dimension)
    column_pointers = Vector{Int}(undef, dimension + 1)
    row_indices = Int[]
    hopping_values = Complex{R}[]
    sizehint!(row_indices, dimension * min(4nmodes, nmodes^2))
    sizehint!(hopping_values, dimension * min(4nmodes, nmodes^2))
    half = inv(convert(R, 2))
    quarter = inv(convert(R, 4))

    maximum_diagonal_imaginary = maximum(abs ∘ imag, diag(converted_kinetic))
    maximum_diagonal_imaginary <= 64eps(R) * max(one(R), maximum(abs, converted_kinetic)) ||
        throw(ArgumentError("Hermitian kinetic matrix has a non-real diagonal"))

    for column in 1:dimension
        column_pointers[column] = length(row_indices) + 1
        up_state, down_state = _basis_state(basis, column)
        double_count = count_ones(up_state & down_state)
        double_occupancies[column] = convert(R, double_count)
        oalm_integer = 0
        one_body_diagonal = zero(R)
        for mode in 1:nmodes
            up_occupied = _occupied(up_state, mode)
            down_occupied = _occupied(down_state, mode)
            orbital_sign = isodd(mode) ? 1 : -1
            oalm_integer += orbital_sign * (up_occupied - down_occupied)
            occupation = up_occupied + down_occupied
            one_body_diagonal += occupation * real(converted_kinetic[mode, mode])
        end
        oalm = convert(R, oalm_integer) * half
        oalm_values[column] = oalm
        centered_interaction = interaction * (
            convert(R, double_count) -
            convert(R, basis.Nup + basis.Ndown) * half +
            convert(R, nmodes) * quarter
        )
        diagonal[column] = one_body_diagonal + centered_interaction - field * oalm

        for spin in 1:2
            state = spin == 1 ? up_state : down_state
            for source in 1:nmodes, destination in 1:nmodes
                source == destination && continue
                hopping = converted_kinetic[destination, source]
                iszero(hopping) && continue
                result = _hop(state, destination, source)
                result === nothing && continue
                final_spin_state, sign = result
                final_up = spin == 1 ? final_spin_state : up_state
                final_down = spin == 2 ? final_spin_state : down_state
                push!(row_indices, _basis_index(basis, final_up, final_down))
                push!(hopping_values, sign * hopping)
            end
        end
    end
    column_pointers[end] = length(row_indices) + 1
    return SectorHamiltonian(
        basis,
        converted_kinetic,
        interaction,
        field,
        diagonal,
        oalm_values,
        double_occupancies,
        column_pointers,
        row_indices,
        hopping_values,
    )
end

function mul!(
    output::AbstractVector,
    hamiltonian::SectorHamiltonian,
    input::AbstractVector,
)
    length(input) == size(hamiltonian, 2) || throw(DimensionMismatch(
        "input vector has the wrong length",
    ))
    length(output) == size(hamiltonian, 1) || throw(DimensionMismatch(
        "output vector has the wrong length",
    ))
    source_vector = Base.mightalias(output, input) ? copy(input) : input
    fill!(output, zero(eltype(output)))
    @inbounds for column in eachindex(hamiltonian.diagonal)
        coefficient = source_vector[column]
        output[column] += hamiltonian.diagonal[column] * coefficient
        for pointer in hamiltonian.column_pointers[column]:(
            hamiltonian.column_pointers[column + 1] - 1
        )
            output[hamiltonian.row_indices[pointer]] +=
                hamiltonian.hopping_values[pointer] * coefficient
        end
    end
    return output
end

function Base.:*(hamiltonian::SectorHamiltonian, input::AbstractVector)
    T = promote_type(eltype(hamiltonian), eltype(input))
    output = zeros(T, size(hamiltonian, 1))
    return mul!(output, hamiltonian, input)
end

function dense_sector_hamiltonian(
    hamiltonian::SectorHamiltonian;
    max_dense_bytes::Integer=DEFAULT_MAX_DENSE_BYTES,
)
    dimension = size(hamiltonian, 1)
    required_bytes = big(dimension)^2 * sizeof(eltype(hamiltonian))
    required_bytes <= max_dense_bytes || throw(ArgumentError(
        "dense sector needs $required_bytes bytes, exceeding max_dense_bytes=$max_dense_bytes",
    ))
    dense = zeros(eltype(hamiltonian), dimension, dimension)
    for column in eachindex(hamiltonian.diagonal)
        dense[column, column] = hamiltonian.diagonal[column]
        for pointer in hamiltonian.column_pointers[column]:(
            hamiltonian.column_pointers[column + 1] - 1
        )
            dense[hamiltonian.row_indices[pointer], column] +=
                hamiltonian.hopping_values[pointer]
        end
    end
    return dense
end

Base.Matrix(hamiltonian::SectorHamiltonian) = dense_sector_hamiltonian(hamiltonian)

function _dense_ground(
    hamiltonian::SectorHamiltonian{T};
    degeneracy_tolerance::Real,
    max_dense_bytes::Integer,
) where {T}
    dense = dense_sector_hamiltonian(
        hamiltonian;
        max_dense_bytes=max_dense_bytes,
    )
    decomposition = eigen(Hermitian(dense))
    energy = decomposition.values[1]
    tolerance = convert(T, degeneracy_tolerance) * max(one(T), abs(energy))
    ground_dimension = searchsortedlast(decomposition.values, energy + tolerance)
    vectors = copy(decomposition.vectors[:, 1:ground_dimension])
    residual = zero(T)
    work = zeros(Complex{T}, size(hamiltonian, 1))
    for vector in eachcol(vectors)
        mul!(work, hamiltonian, vector)
        residual = max(residual, norm(work - energy * vector))
    end
    return (
        energy=energy,
        vectors=vectors,
        residual=residual,
        iterations=1,
        converged=true,
        method=:dense,
        ground_subspace_dimension=ground_dimension,
        ground_subspace_resolved=true,
    )
end

function _deterministic_start(::Type{T}, dimension::Int) where {T<:AbstractFloat}
    vector = Vector{Complex{T}}(undef, dimension)
    irrational_scale = sqrt(convert(T, 2))
    for index in eachindex(vector)
        argument = convert(T, index)
        vector[index] = complex(
            sin(argument) + cos(irrational_scale * argument),
            cos(argument / irrational_scale) - sin(irrational_scale * argument),
        )
    end
    vector ./= norm(vector)
    return vector
end

function _operator_scale(hamiltonian::SectorHamiltonian{T}) where {T}
    bound = zero(T)
    for column in eachindex(hamiltonian.diagonal)
        column_sum = abs(hamiltonian.diagonal[column])
        for pointer in hamiltonian.column_pointers[column]:(
            hamiltonian.column_pointers[column + 1] - 1
        )
            column_sum += abs(hamiltonian.hopping_values[pointer])
        end
        bound = max(bound, column_sum)
    end
    return max(bound, one(T))
end

function _lanczos_ground(
    hamiltonian::SectorHamiltonian{T};
    atol::Real,
    rtol::Real,
    maxiter::Integer,
    max_krylov_bytes::Integer,
    require_convergence::Bool,
) where {T}
    dimension = size(hamiltonian, 1)
    iterations_limit = min(Int(maxiter), dimension)
    iterations_limit > 0 || throw(ArgumentError("maxiter must be positive"))
    required_bytes = big(dimension) * iterations_limit * sizeof(Complex{T})
    required_bytes <= max_krylov_bytes || throw(ArgumentError(
        "Krylov basis needs $required_bytes bytes, exceeding max_krylov_bytes=$max_krylov_bytes",
    ))
    absolute_tolerance = convert(T, _checked_finite_real(atol, "atol"))
    relative_tolerance = convert(T, _checked_finite_real(rtol, "rtol"))
    absolute_tolerance >= 0 || throw(ArgumentError("atol must be nonnegative"))
    relative_tolerance >= 0 || throw(ArgumentError("rtol must be nonnegative"))

    krylov = Matrix{Complex{T}}(undef, dimension, iterations_limit)
    diagonal = Vector{T}(undef, iterations_limit)
    off_diagonal = Vector{T}(undef, max(0, iterations_limit - 1))
    previous = zeros(Complex{T}, dimension)
    current = _deterministic_start(T, dimension)
    work = similar(current)
    scale = _operator_scale(hamiltonian)
    best_value = zero(T)
    best_coefficients = ones(T, 1)
    completed = 0
    converged = false

    for iteration in 1:iterations_limit
        completed = iteration
        view(krylov, :, iteration) .= current
        mul!(work, hamiltonian, current)
        iteration > 1 && (work .-= off_diagonal[iteration - 1] .* previous)
        diagonal[iteration] = real(dot(current, work))
        work .-= diagonal[iteration] .* current
        active_basis = view(krylov, :, 1:iteration)
        for _ in 1:2
            coefficients = adjoint(active_basis) * work
            work .-= active_basis * coefficients
        end
        next_norm = norm(work)
        tridiagonal = SymTridiagonal(
            diagonal[1:iteration],
            off_diagonal[1:max(0, iteration - 1)],
        )
        decomposition = eigen(tridiagonal, 1:1)
        best_value = decomposition.values[1]
        best_coefficients = copy(decomposition.vectors[:, 1])
        threshold = absolute_tolerance + relative_tolerance * max(abs(best_value), scale)
        ritz_residual = next_norm * abs(best_coefficients[end])
        if ritz_residual <= threshold || next_norm <= eps(T) * scale
            converged = true
            break
        end
        iteration == iterations_limit && break
        off_diagonal[iteration] = next_norm
        previous .= current
        current .= work ./ next_norm
    end

    vector = view(krylov, :, 1:completed) * best_coefficients
    vector ./= norm(vector)
    mul!(work, hamiltonian, vector)
    energy = real(dot(vector, work))
    residual = norm(work - energy * vector)
    threshold = absolute_tolerance + relative_tolerance * max(abs(energy), scale)
    converged = converged && residual <= 8threshold
    if require_convergence && !converged
        throw(ErrorException(
            "Lanczos ground solve did not converge in $completed iterations " *
            "(residual=$residual, threshold=$threshold)",
        ))
    end
    return (
        energy=energy,
        vectors=reshape(vector, :, 1),
        residual=residual,
        iterations=completed,
        converged=converged,
        method=:lanczos,
        ground_subspace_dimension=1,
        ground_subspace_resolved=false,
    )
end

"""
    ground_state_observables(H; method=:auto, dense_cutoff=256, ...)

Return the sector ground energy, residual, `Oalm`, `Oalm^2`, and double
occupancy.  Dense solves average the complete numerically degenerate ground
subspace.  Matrix-free Lanczos resolves one ground vector and reports
`ground_subspace_resolved=false`; it is intended for energies and nondegenerate
diagnostics on larger blocks.
"""
function ground_state_observables(
    hamiltonian::SectorHamiltonian{T};
    method::Symbol=:auto,
    dense_cutoff::Integer=256,
    degeneracy_tolerance::Real=1.0e-10,
    atol::Real=1.0e-11,
    rtol::Real=1.0e-10,
    maxiter::Integer=min(size(hamiltonian, 1), 300),
    max_dense_bytes::Integer=DEFAULT_MAX_DENSE_BYTES,
    max_krylov_bytes::Integer=DEFAULT_MAX_KRYLOV_BYTES,
    require_convergence::Bool=true,
    return_eigenvectors::Bool=false,
) where {T}
    dense_cutoff >= 0 || throw(ArgumentError("dense_cutoff must be nonnegative"))
    _checked_finite_real(degeneracy_tolerance, "degeneracy_tolerance")
    degeneracy_tolerance >= 0 || throw(ArgumentError(
        "degeneracy_tolerance must be nonnegative",
    ))
    selected_method = method == :auto ?
        (size(hamiltonian, 1) <= dense_cutoff ? :dense : :lanczos) : method
    solution = if selected_method == :dense
        _dense_ground(
            hamiltonian;
            degeneracy_tolerance=degeneracy_tolerance,
            max_dense_bytes=max_dense_bytes,
        )
    elseif selected_method == :lanczos
        _lanczos_ground(
            hamiltonian;
            atol=atol,
            rtol=rtol,
            maxiter=maxiter,
            max_krylov_bytes=max_krylov_bytes,
            require_convergence=require_convergence,
        )
    else
        throw(ArgumentError("method must be :auto, :dense, or :lanczos"))
    end

    probabilities = vec(sum(abs2, solution.vectors; dims=2))
    probabilities ./= sum(probabilities)
    oalm = dot(probabilities, hamiltonian.oalm_values)
    oalm2 = dot(probabilities, abs2.(hamiltonian.oalm_values))
    double_occupancy = dot(probabilities, hamiltonian.double_occupancies)
    number_of_cells = div(hamiltonian.basis.nmodes, 2)
    centered_interaction = hamiltonian.U * (
        double_occupancy -
        (hamiltonian.basis.Nup + hamiltonian.basis.Ndown) / 2 +
        hamiltonian.basis.nmodes / 4
    )
    field_energy = -hamiltonian.h * oalm
    result = (
        energy=solution.energy,
        Nup=hamiltonian.basis.Nup,
        Ndown=hamiltonian.basis.Ndown,
        N=hamiltonian.basis.Nup + hamiltonian.basis.Ndown,
        Sz=(hamiltonian.basis.Nup - hamiltonian.basis.Ndown) / 2,
        dimension=length(hamiltonian.basis),
        oalm=oalm,
        oalm2=oalm2,
        oalm_variance=max(zero(T), oalm2 - abs2(oalm)),
        # `double_occupancy` is retained as a compatibility alias for the
        # total over all spatial orbitals. New callers should use one of the
        # two explicitly normalized fields below.
        double_occupancy=double_occupancy,
        double_occupancy_total=double_occupancy,
        double_occupancy_per_cell=double_occupancy / number_of_cells,
        kinetic_energy=solution.energy - centered_interaction - field_energy,
        centered_interaction_energy=centered_interaction,
        field_energy=field_energy,
        residual=solution.residual,
        iterations=solution.iterations,
        converged=solution.converged,
        method=solution.method,
        ground_subspace_dimension=solution.ground_subspace_dimension,
        ground_subspace_resolved=solution.ground_subspace_resolved,
    )
    return return_eigenvectors ? merge(result, (eigenvectors=solution.vectors,)) : result
end

function ground_state_observables(
    kinetic::AbstractMatrix{<:Number},
    U::Real,
    Nup::Integer,
    Ndown::Integer;
    h::Real=0,
    max_basis_dimension::Integer=DEFAULT_MAX_BASIS_DIMENSION,
    kwargs...,
)
    hamiltonian = sector_hamiltonian(
        kinetic,
        U,
        Nup,
        Ndown;
        h=h,
        max_basis_dimension=max_basis_dimension,
    )
    return ground_state_observables(hamiltonian; kwargs...)
end

function _allowed_spin_sectors(nmodes::Int, N::Int)
    minimum_up = max(0, N - nmodes)
    maximum_up = min(nmodes, N)
    return [(Nup, N - Nup) for Nup in minimum_up:maximum_up]
end

function spin_flip_error(rows)
    isempty(rows) && throw(ArgumentError("rows must not be empty"))
    energies = Dict((row.Nup, row.Ndown) => row.energy for row in rows)
    errors = Float64[]
    for row in rows
        partner = (row.Ndown, row.Nup)
        haskey(energies, partner) || throw(ArgumentError(
            "missing spin-flipped sector $partner",
        ))
        push!(errors, abs(Float64(row.energy - energies[partner])))
    end
    return maximum(errors)
end

"""
    canonical_ground_state(K, U, N; h=0, spin_sectors=nothing, ...)

Solve every requested `(Nup,Ndown)` block at fixed canonical `N` and identify
the global ground sectors. If every internal ground subspace is resolved, its
states are averaged with equal weight. Otherwise the canonical observables are
`missing`; explicitly named `unresolved_estimate_*` fields retain the
single-vector Lanczos estimates for diagnostics only. At zero field,
`spin_flip_error` is a numerical symmetry audit, not an order parameter.
"""
function canonical_ground_state(
    kinetic::AbstractMatrix{<:Number},
    U::Real,
    N::Integer;
    h::Real=0,
    spin_sectors=nothing,
    degeneracy_tolerance::Real=1.0e-10,
    kwargs...,
)
    nmodes = size(kinetic, 1)
    size(kinetic, 2) == nmodes || throw(DimensionMismatch(
        "kinetic matrix must be square",
    ))
    N isa Bool && throw(ArgumentError("N must be a particle count"))
    0 <= N <= 2nmodes || throw(ArgumentError("N must lie in 0:2nmodes"))
    particle_number = Int(N)
    requested = spin_sectors === nothing ?
        _allowed_spin_sectors(nmodes, particle_number) :
        [(Int(pair[1]), Int(pair[2])) for pair in spin_sectors]
    isempty(requested) && throw(ArgumentError("at least one spin sector is required"))
    length(unique(requested)) == length(requested) || throw(ArgumentError(
        "spin_sectors contains a duplicate",
    ))

    sector_rows = NamedTuple[]
    for (Nup, Ndown) in requested
        Nup + Ndown == particle_number || throw(ArgumentError(
            "each spin sector must sum to N",
        ))
        result = ground_state_observables(
            kinetic,
            U,
            Nup,
            Ndown;
            h=h,
            degeneracy_tolerance=degeneracy_tolerance,
            kwargs...,
        )
        push!(sector_rows, result)
    end
    ground_energy = minimum(row.energy for row in sector_rows)
    tolerance = degeneracy_tolerance * max(1.0, abs(Float64(ground_energy)))
    ground_rows = [row for row in sector_rows if row.energy <= ground_energy + tolerance]
    weights = [row.ground_subspace_dimension for row in ground_rows]
    total_weight = sum(weights)
    weighted_estimate(name) = sum(
        weights[index] * getproperty(row, name)
        for (index, row) in enumerate(ground_rows)
    ) / total_weight
    observables_exact = all(row.ground_subspace_resolved for row in ground_rows)
    oalm_estimate = weighted_estimate(:oalm)
    oalm2_estimate = weighted_estimate(:oalm2)
    double_occupancy_total_estimate =
        weighted_estimate(:double_occupancy_total)
    number_of_cells = div(nmodes, 2)
    return (
        U=U,
        h=h,
        N=particle_number,
        ground_energy=ground_energy,
        ground_degeneracy_lower_bound=total_weight,
        ground_subspace_resolved=observables_exact,
        ground_observables_exact=observables_exact,
        ground_sectors=[(row.Nup, row.Ndown) for row in ground_rows],
        # Returning `missing` is deliberate: a one-vector Lanczos result can
        # miss other vectors in the same degenerate sector, so averaging it as
        # though it were the complete canonical ensemble is not exact.
        oalm=observables_exact ? oalm_estimate : missing,
        oalm2=observables_exact ? oalm2_estimate : missing,
        oalm_variance=observables_exact ?
            max(0.0, oalm2_estimate - abs2(oalm_estimate)) : missing,
        double_occupancy=observables_exact ?
            double_occupancy_total_estimate : missing,
        double_occupancy_total=observables_exact ?
            double_occupancy_total_estimate : missing,
        double_occupancy_per_cell=observables_exact ?
            double_occupancy_total_estimate / number_of_cells : missing,
        unresolved_estimate_oalm=oalm_estimate,
        unresolved_estimate_oalm2=oalm2_estimate,
        unresolved_estimate_oalm_variance=
            max(0.0, oalm2_estimate - abs2(oalm_estimate)),
        unresolved_estimate_double_occupancy_total=
            double_occupancy_total_estimate,
        unresolved_estimate_double_occupancy_per_cell=
            double_occupancy_total_estimate / number_of_cells,
        max_residual=maximum(row.residual for row in sector_rows),
        spin_flip_error=iszero(h) ? spin_flip_error(sector_rows) : missing,
        sector_results=sector_rows,
    )
end

"""
    canonical_twist_orbit_scan(U, N, theta_x, theta_y; L=2, ...)

Solve the canonical ground state for a twist and its time-reversal and `C4`
partners.  This is the symmetry-safe unit for twist averaging.  It computes
ground diagnostics only; a full interacting Lehmann `A(k,omega)` is outside
this small extension because it requires complete `N+/-1` eigensystems at
every twist.  The reported symmetry errors are zero-field audits; when `h` is
nonzero, `symmetry_audit_valid` is false because the source transforms too.
"""
function canonical_twist_orbit_scan(
    U::Real,
    N::Integer,
    theta_x::Real,
    theta_y::Real;
    L::Integer=2,
    parameters::ModelParameters=DEFAULT_PARAMETERS,
    h::Real=0,
    kwargs...,
)
    rows = NamedTuple[]
    for point in twist_symmetry_orbit(theta_x, theta_y)
        kinetic = twisted_cluster_kinetic_matrix(
            L,
            point.theta_x,
            point.theta_y,
            parameters,
        )
        result = canonical_ground_state(kinetic, U, N; h=h, kwargs...)
        push!(rows, merge(point, (
            ground_energy=result.ground_energy,
            ground_degeneracy_lower_bound=result.ground_degeneracy_lower_bound,
            ground_subspace_resolved=result.ground_subspace_resolved,
            ground_observables_exact=result.ground_observables_exact,
            ground_sectors=result.ground_sectors,
            oalm=result.oalm,
            oalm2=result.oalm2,
            double_occupancy=result.double_occupancy,
            double_occupancy_total=result.double_occupancy_total,
            double_occupancy_per_cell=result.double_occupancy_per_cell,
            unresolved_estimate_oalm=result.unresolved_estimate_oalm,
            unresolved_estimate_oalm2=result.unresolved_estimate_oalm2,
            unresolved_estimate_double_occupancy_total=
                result.unresolved_estimate_double_occupancy_total,
            unresolved_estimate_double_occupancy_per_cell=
                result.unresolved_estimate_double_occupancy_per_cell,
            max_residual=result.max_residual,
            spin_flip_error=result.spin_flip_error,
            sector_results=result.sector_results,
        )))
    end
    energies = [row.ground_energy for row in rows]
    observables_exact = all(row.ground_observables_exact for row in rows)
    return (
        L=Int(L),
        U=U,
        N=Int(N),
        h=h,
        theta_x=theta_x,
        theta_y=theta_y,
        rows=rows,
        symmetry_audit_valid=iszero(h),
        symmetry_energy_spread=maximum(energies) - minimum(energies),
        time_reversal_energy_error=abs(energies[1] - energies[2]),
        c4_energy_error=abs(energies[1] - energies[3]),
        ground_observables_exact=observables_exact,
        twist_averaged_oalm=observables_exact ?
            sum(row.oalm for row in rows) / length(rows) : missing,
        twist_averaged_oalm2=observables_exact ?
            sum(row.oalm2 for row in rows) / length(rows) : missing,
        twist_averaged_double_occupancy=observables_exact ?
            sum(row.double_occupancy_total for row in rows) / length(rows) : missing,
        twist_averaged_double_occupancy_total=observables_exact ?
            sum(row.double_occupancy_total for row in rows) / length(rows) : missing,
        twist_averaged_double_occupancy_per_cell=observables_exact ?
            sum(row.double_occupancy_per_cell for row in rows) / length(rows) : missing,
        twist_averaged_unresolved_estimate_oalm=
            sum(row.unresolved_estimate_oalm for row in rows) / length(rows),
        twist_averaged_unresolved_estimate_oalm2=
            sum(row.unresolved_estimate_oalm2 for row in rows) / length(rows),
        twist_averaged_unresolved_estimate_double_occupancy_total=sum(
            row.unresolved_estimate_double_occupancy_total for row in rows
        ) / length(rows),
        twist_averaged_unresolved_estimate_double_occupancy_per_cell=sum(
            row.unresolved_estimate_double_occupancy_per_cell for row in rows
        ) / length(rows),
        spectral_function_computed=false,
    )
end

"""Run [`canonical_twist_orbit_scan`](@ref) for a collection of `U` values."""
function scan_u_twist_orbit(
    U_values,
    N::Integer,
    theta_x::Real,
    theta_y::Real;
    kwargs...,
)
    interactions = collect(U_values)
    isempty(interactions) && throw(ArgumentError("U_values must not be empty"))
    all(U -> U isa Real && !(U isa Bool) && isfinite(U) && U >= 0, interactions) ||
        throw(ArgumentError("all U_values must be finite nonnegative reals"))
    return [
        canonical_twist_orbit_scan(U, N, theta_x, theta_y; kwargs...)
        for U in interactions
    ]
end

end # module
