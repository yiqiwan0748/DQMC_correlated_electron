#!/usr/bin/env julia
# NEW explicit one-dimensional ring adapter; unchanged native complex ED kernel.
const ENTRY=time()
using LinearAlgebra,TOML,SHA,Libdl
BLAS.set_num_threads(1)
const HERE=@__DIR__
const C=TOML.parsefile(joinpath(HERE,"manifest.toml"))
sha(p)=bytes2hex(sha256(read(p)))
function source_contract()
 isfile(joinpath(HERE,"source_freeze.json")) || error("Unfrozen; no numerical evaluation")
 out=Dict{String,String}()
 for line in eachline(joinpath(HERE,"SHA256SUMS"))
  h,n=split(line,"  ";limit=2);sha(joinpath(HERE,n))==h || error("Changed source");out[n]=h
 end
 for (n,h) in C["native_source_sha256"];sha(joinpath(HERE,"source_snapshot",n))==h || error("Changed native source");end
 sha(joinpath(HERE,"proposal.json"))==C["proposal_sha256"] || error("Changed proposal")
 out
end
haskey(ENV,"SLURM_JOB_ID") || error("Compute allocation required")
string(VERSION)==C["julia_version"] || error("Pinned Julia required")
const SOURCE=source_contract()
function runtime_contract()
 d=TOML.parsefile(joinpath(HERE,"runtime_pins.toml"));d["schema"]=="A25_NATIVE_RUNTIME_FILE_PINS_V1" || error("Runtime schema")
 observed=Dict{String,String}()
 for spec in d["files"]
  p=spec["path"];realpath(p)==spec["realpath"] && stat(p).size==spec["bytes"] && sha(p)==spec["sha256"] || error("Changed runtime file")
  observed[p]=spec["sha256"]
 end
 loaded=String[]
 for p in Libdl.dllist()
  if any(occursin(s,basename(p)) for s in ("libopenblas","libblastrampoline","libjulia"))
   q=realpath(p);haskey(observed,q) || error("Unpinned loaded Julia/BLAS provider");push!(loaded,q)
  end
 end
 any(occursin("libopenblas",basename(p)) for p in loaded) || error("Pinned OpenBLAS not actually loaded")
 any(occursin("libblastrampoline",basename(p)) for p in loaded) || error("Pinned BLAS trampoline not actually loaded")
 providers=Dict{String,String}[]
 for lib in BLAS.get_config().loaded_libs
  isabspath(lib.libname) || error("BLAS provider must have an absolute pinned path")
  q=realpath(lib.libname);haskey(observed,q) || error("Unpinned actual configured BLAS provider")
  occursin("libopenblas",basename(q)) && lib.interface==:ilp64 || error("Unexpected configured BLAS provider/interface")
  push!(providers,Dict("path"=>q,"interface"=>string(lib.interface),"suffix"=>lib.suffix))
 end
 expected=Set(p for p in keys(observed) if occursin("libopenblas",basename(p)))
 !isempty(providers) && Set(p["path"] for p in providers)==expected || error("Configured BLAS provider set differs from expected")
 BLAS.get_num_threads()==1 || error("Actual BLAS thread count differs")
 observed,loaded,providers
end
const RUNTIME,LOADED_PROVIDERS,BLAS_PROVIDERS=runtime_contract()
include(joinpath(HERE,"source_snapshot/scripts/two_orbital_twisted_cluster_ed.jl"))
const ED=TwoOrbitalTwistedClusterED
plain(x)=x
plain(x::AbstractMatrix)=[collect(x[i,:]) for i in axes(x,1)]
plain(x::AbstractVector)=[plain(v) for v in x]
plain(x::AbstractDict)=Dict(k=>plain(v) for (k,v) in x)
function ring(L,phi,gauge)
 K=zeros(ComplexF64,L,L)
 for j in 0:L-1
  angle=gauge=="uniform" ? -phi/L : (j==L-1 ? -phi : 0.)
  value=-C["t"]*cis(angle);a=mod(j+1,L)+1;b=j+1
  K[a,b]+=value;K[b,a]+=conj(value)
 end
 K
end
function one_point(f,center,units,gauge)
 start=time();L=f["L"];N=f["N"];phi=units/C["flux_units_denominator"];K=ring(L,phi,gauge);rows=Dict{String,Any}[];balanced=Dict{String,Any}()
 for nu in max(0,N-L):min(L,N)
  nd=N-nu;clock=time();H=ED.sector_hamiltonian(K,C["U"],nu,nd;h=C["h"])
  r=ED.ground_state_observables(H;method=:dense,return_eigenvectors=true,degeneracy_tolerance=C["native_degeneracy_tolerance"],max_dense_bytes=128*1024^2)
  v=r.eigenvectors;fresh=maximum(norm(H*view(v,:,j)-r.energy*view(v,:,j)) for j in axes(v,2))
  push!(rows,Dict("Nup"=>nu,"Ndown"=>nd,"dimension"=>r.dimension,"energy"=>r.energy,"reported_residual"=>r.residual,"fresh_residual"=>fresh,"method"=>string(r.method),"converged"=>r.converged,"ground_dimension"=>r.ground_subspace_dimension,"ground_subspace_resolved"=>r.ground_subspace_resolved,"elapsed_seconds"=>time()-clock))
  if nu==f["Nup"]
   ups=UInt64[];dns=UInt64[]
   for up in H.basis.up_states,dn in H.basis.down_states;push!(ups,up);push!(dns,dn);end
   balanced=Dict("basis_up_masks"=>Int.(ups),"basis_down_masks"=>Int.(dns),"vectors_real"=>real.(v),"vectors_imag"=>imag.(v),"energy"=>r.energy,"ground_dimension"=>r.ground_subspace_dimension,"fresh_residual"=>fresh)
  end
 end
 Dict("id"=>"L$(L)/center$(center)/flux$(units)/$(gauge)","L"=>L,"N"=>N,"center_units"=>center,"flux_units"=>units,"phi"=>phi,"gauge"=>gauge,"K_real"=>real.(K),"K_imag"=>imag.(K),"K_hermiticity_abs"=>maximum(abs,K-K'),"maximum_imaginary_hopping"=>maximum(abs,imag.(K)),"spin_sectors"=>rows,"balanced"=>balanced,"elapsed_seconds"=>time()-start)
end
function main()
 length(ARGS)==2 || error("MODE OUTPUT");mode,output=ARGS;mode in ("pilot","production") || error("Mode");ispath(output) && error("No overwrite")
 fixtures=mode=="production" ? C["fixtures"] : filter(f->f["L"]==C["pilot_L"],C["fixtures"])
 centers=mode=="production" ? C["centers_units"] : [C["pilot_center_units"]]
 points=[one_point(f,center,center+off,gauge) for f in fixtures for center in centers for off in C["stencil_union_offsets_units"] for gauge in C["gauges"]]
 for (i,p) in enumerate(points)
  phase=mode=="production" ? "production" : (i==1 ? "cold_first_complete_point" : "warm_after_first_complete_point")
  p["timing_phase"]=phase
  for row in p["spin_sectors"];row["timing_phase"]=phase;end
 end
 raw=Dict("schema"=>"A25_NATIVE_COMPLEX_ED_RAW_V1","backend"=>"actual_native_complex_ED","mode"=>mode,"job_id"=>ENV["SLURM_JOB_ID"],"julia_version"=>string(VERSION),"threads"=>1,"source_sha256"=>SOURCE,"source_freeze_sha256"=>sha(joinpath(HERE,"source_freeze.json")),"runtime_pins_sha256"=>sha(joinpath(HERE,"runtime_pins.json")),"runtime_file_sha256"=>RUNTIME,"loaded_native_providers"=>LOADED_PROVIDERS,"blas_config_providers"=>BLAS_PROVIDERS,"native_source_sha256"=>C["native_source_sha256"],"new_adapter"=>"explicit1D Peierls ring K + export observer; native sector_hamiltonian and dense ground unchanged; torus constructors unused","scientific_completions"=>0,"points"=>points,"elapsed_since_program_entry"=>time()-ENTRY)
 open(output,"w") do io;TOML.print(io,plain(raw));end
end
main()
