#!/usr/bin/env python3
"""Saved original A25 full audit; same-agent authorship disclosed, one question maximum."""
import argparse,cmath,datetime,hashlib,itertools,json,math,os,platform,re,signal,subprocess,sys,tarfile,time,tomllib
from pathlib import Path,PurePosixPath
HERE=Path(__file__).resolve().parent
PLAN_SHA256='7e780dd3c3b6a5101c2c76a66e349b909a20a6d6adeaa66de75454f4dd0c88fd'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def read(p):
 p=Path(p);return tomllib.loads(p.read_text()) if p.suffix=='.toml' else json.loads(p.read_text())
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
class Audit:
 def __init__(self):self.checks=[];self.inputs={}
 def need(self,name,ok,**details):self.checks.append(dict(name=name,passed=bool(ok),**details))
 def require(self,name,ok):
  self.need(name,ok)
  if not ok:raise ValueError(name)
 def upper(self,name,value,bound):
  value=float(value);self.need(name,math.isfinite(value) and 0<=value<=bound,value=value if math.isfinite(value) else None,lower_bound=0,bound=bound)
 def bind(self,p):
  p=Path(p).resolve();self.inputs[str(p)]=sha(p);return self.inputs[str(p)]
def complex_rows(re,im):
 if len(re)!=len(im) or any(len(x)!=len(y) for x,y in zip(re,im)):raise ValueError('Incomplete complex rows')
 return [[complex(a,b) for a,b in zip(x,y)] for x,y in zip(re,im)]
def csum(v):
 v=list(v);return complex(math.fsum(z.real for z in v),math.fsum(z.imag for z in v))
def leibniz(matrix):
 """Independent small determinant via permutations, no elimination/eigensolver."""
 total=[];n=len(matrix)
 for p in itertools.permutations(range(n)):
  z=complex(-1 if sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))%2 else 1)
  for i in range(n):z*=matrix[i][p[i]]
  total.append(z)
 return csum(total)

def closure(args,plan,a):
 packet=args.packet;source=packet/'source';raw=packet/'results/results';a.require('exact original canonical source/archive',a.bind(args.archive)==plan['source_archive_sha256'] and a.bind(args.freeze)==plan['source_freeze_sha256'] and a.bind(source/'source_freeze.json')==plan['source_freeze_sha256']);freeze=read(args.freeze);prefix=freeze['prefix'].rstrip('/')+'/';seen=set()
 with tarfile.open(args.archive,'r:gz') as t:
  for m in t:
   a.require('safe source member/'+m.name,m.isfile() and not m.issym() and not m.islnk() and m.name.startswith(prefix) and '..' not in PurePosixPath(m.name).parts);name=m.name[len(prefix):];a.require('unique expected source member/'+name,name not in seen and name in freeze['files']);seen.add(name);a.require('exact unchanged source/'+name,hashlib.sha256(t.extractfile(m).read()).hexdigest()==freeze['files'][name]==a.bind(source/name))
 a.require('all30 original scientific source members',len(seen)==30 and seen==set(freeze['files']))
 before=read(packet/'transfer_before.json');after=read(packet/'transfer_after.json');a.bind(packet/'transfer_before.json');a.bind(packet/'transfer_after.json');b={row['local']:row for row in before['files']};z={row['local']:row for row in after['files']};a.require('full original stable transfer membership',len(b)==len(before['files']) and len(z)==len(after['files']) and set(b)==set(z) and before['job_id']==after['job_id']==plan['job_id'] and after['status']=='PASS')
 for name,row in b.items():
  path=packet/name;p=PurePosixPath(name);a.require('safe original transferred file/'+name,not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name and path.is_file() and not path.is_symlink());stamp=row.get('after_read',row.get('before',{}));a.require('full original bytes/stats retained/'+name,a.bind(path)==row['sha256']==z[name]['sha256'] and path.stat().st_size==row['bytes']==z[name]['bytes'] and all(stamp.get(k)==z[name].get(k) for k in ['inode','mtime_ns']))
 runtime=read(source/'runtime_pins.json');mapping={name:row['sha256'] for name,row in runtime['files'].items()};a.require('119runtime maps stable',len(mapping)==119 and before['runtime_files']==after['runtime_files'] and before['runtime_critical_file_sha256']==after['runtime_critical_file_sha256']==mapping)
 for name,row in runtime['files'].items():
  observed=before['runtime_files'][name];path=Path(name);a.require('original119runtime metadata/'+name,observed['sha256']==row['sha256'] and observed['bytes']==row['bytes'] and observed['realpath']==row['realpath']);a.require('actual119runtime bytes before math/'+name,str(path.resolve())==row['realpath'] and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'])
 a.require('actual pinned Python executable',str(Path(sys.executable).resolve())==runtime['python_executable_realpath'])
 account=packet/'sacct_fresh.txt';a.bind(account);jobs=[line.split('|') for line in account.read_text().splitlines() if line.startswith(plan['job_id']+'|')];a.require('original full1CPU3500MB30min COMPLETED0:0',len(jobs)==1 and len(jobs[0])==11 and jobs[0][2:5]==['COMPLETED','0:0','1'] and jobs[0][5] in plan['required_original_reqmem'] and jobs[0][10]==plan['required_original_timelimit'])
 e=read(raw/'execution.json');a.bind(raw/'execution.json');a.require('actual full original execution source/role',e['schema']=='A25_SCIENTIFIC_EXECUTION_V1' and e['mode']=='production' and e['job_id']==plan['job_id'] and e['source_freeze_sha256']==plan['source_freeze_sha256'] and e['threads']==1 and e['scientific_completions']==0 and e['status']=='PROCESSES_COMPLETE')
 a.require('original full three complete roles',[p['label'] for p in e['processes']]==['native','reference','comparison'] and all(p['exit_code']==0 and not p['timed_out'] and math.isfinite(p['wall_seconds']) and p['wall_seconds']>0 for p in e['processes']) and all((raw/name).is_file() for name in ['native.toml','reference.json','comparison.json']))
 guard=e['full_review'];a.require('full original pilot evidence admission retained',isinstance(guard,dict) and guard['pilot_assessment_sha256']==plan['pilot_resource_assessment_sha256'] and guard['independent_pilot_audit_sha256']==plan['pilot_math_audit_sha256'] and guard['root_review_sha256']==plan['root_full_review_sha256'])
 for name,spec in e['outputs'].items():a.require('execution-bound full output/'+name,a.bind(raw/name)==spec['sha256'] and (raw/name).stat().st_size==spec['bytes'])
 a.require('original execution actual119runtime maps',e['runtime_before_sha256']==e['runtime_after_sha256']==mapping and e['runtime_pins_sha256']==sha(source/'runtime_pins.json'))
 return source,raw,e,runtime,mapping

def audit_math(source,raw,plan,a,mapping):
 c=read(source/'manifest.toml');g=c['gates'];n=read(raw/'native.toml');r=read(raw/'reference.json');old=read(raw/'comparison.json');sourcehash={name:digest for digest,name in (line.split('  ',1) for line in (source/'SHA256SUMS').read_text().splitlines())}
 a.require('actual unchanged native vs independent analytic roles',n['schema']=='A25_NATIVE_COMPLEX_ED_RAW_V1' and n['backend']=='actual_native_complex_ED' and r['schema']=='A25_STDLIB_ANALYTIC_RAW_V1' and r['backend']=='independent_stdlib_reference' and not r['target_raw_imported'])
 for name,d in [('native',n),('reference',r)]:a.require(name+'/source/runtime/full-role',d['source_sha256']==sourcehash and d['source_freeze_sha256']==sha(source/'source_freeze.json') and d['mode']=='production' and d['job_id']==plan['job_id'] and d['scientific_completions']==0 and d['runtime_pins_sha256']==sha(source/'runtime_pins.json') and d['runtime_file_sha256']==mapping)
 a.require('actual native source/version/thread qualification',n['native_source_sha256']==c['native_source_sha256'] and n['julia_version']==c['julia_version'] and n['threads']==1 and r['python_version']==c['python_version'])
 loaded=n['loaded_native_providers'];a.require('actual mandatory pinned JuliaOpenBLAStrampoline providers',bool(loaded) and all(path in mapping for path in loaded) and any('libopenblas' in Path(path).name for path in loaded) and any('libblastrampoline' in Path(path).name for path in loaded));expected_blas={path for path in mapping if 'libopenblas' in Path(path).name};a.require('actual configured pinnedILP64 provider list',bool(n['blas_config_providers']) and {p['path'] for p in n['blas_config_providers']}==expected_blas and all(p['interface']=='ilp64' for p in n['blas_config_providers']))
 expected=[(f,center,center+offset,gauge) for f in c['fixtures'] for center in c['centers_units'] for offset in c['stencil_union_offsets_units'] for gauge in c['gauges']];metadata=[(f['L'],center,units,gauge) for f,center,units,gauge in expected]
 for name,d in [('native',n),('reference',r)]:a.require(name+'/complete ordered196point grid',len(d['points'])==196 and [(p['L'],p['center_units'],p['flux_units'],p['gauge']) for p in d['points']]==metadata)
 energies={};references={};native_vectors={};details=[]
 for (f,center,units,gauge),p,q in zip(expected,n['points'],r['points']):
  L=f['L'];N=f['N'];count=f['Nup'];occ=f['occupied_integer_modes'];phi=units/c['flux_units_denominator'];tag=p['id'];a.require(tag+'/exact fixture metadata',p['N']==q['N']==N and p['id']==q['id']==f'L{L}/center{center}/flux{units}/{gauge}' and p['phi']==q['phi']==phi)
  wave=lambda mode,site:cmath.exp(2j*math.pi*mode*site/L)/math.sqrt(L)*(cmath.exp(1j*site*phi/L) if gauge=='boundary_seam' else 1)
  levels=[-2*c['t']*math.cos((2*math.pi*mode+phi)/L) for mode in range(L)];ordered=sorted(levels);E=-4*c['t']*math.fsum(math.cos((2*math.pi*mode+phi)/L) for mode in occ);I=-(4*c['t']/L)*math.fsum(math.sin((2*math.pi*mode+phi)/L) for mode in occ);C=4*c['t']/L**2*math.fsum(math.cos((2*math.pi*mode+phi)/L) for mode in occ)
  for field,expected_value in [('energy',E),('current',I),('curvature',C),('stiffness',L*C/2),('max_E5',4*c['t']*count/L**5),('max_E6',4*c['t']*count/L**6)]:a.upper(tag+'/independent analytic reference '+field,abs(q[field]-expected_value),64*sys.float_info.epsilon*max(1,abs(expected_value)))
  K=[[0j]*L for i in range(L)]
  for site in range(L):
   dest=(site+1)%L;phase=cmath.exp(-1j*phi/L) if gauge=='uniform' else cmath.exp(-1j*phi) if site==L-1 else 1+0j;K[dest][site]+=-c['t']*phase;K[site][dest]+=-c['t']*phase.conjugate()
  for backend,row in [('native',p),('reference',q)]:
   actual=complex_rows(row['K_real'],row['K_imag']);a.require(tag+'/'+backend+'completeKshape',len(actual)==L and all(len(v)==L for v in actual));a.upper(tag+'/'+backend+'independent directK',max(abs(actual[i][j]-K[i][j]) for i in range(L) for j in range(L)),g['K_abs'])
  sectors={(s['Nup'],s['Ndown']):s for s in p['spin_sectors']};refs={(s['Nup'],s['Ndown']):s for s in q['spin_sectors']};wanted={(nu,N-nu) for nu in range(max(0,N-L),min(L,N)+1)};a.require(tag+'/every fixed-totalN spinsector',len(p['spin_sectors'])==len(q['spin_sectors'])==len(wanted) and set(sectors)==set(refs)==wanted)
  for pair,s in sectors.items():
   nu,nd=pair;analytic=math.fsum(ordered[:nu]+ordered[:nd]);st=tag+'/sector'+str(pair);a.require(st+'/actual complete dense sector',s['method']=='dense' and s['converged'] and s['ground_subspace_resolved'] and s['dimension']==math.comb(L,nu)*math.comb(L,nd));a.upper(st+'/native occupation energy',abs(s['energy']-analytic),g['sector_energy_abs']);a.upper(st+'/independent reference sector energy',abs(refs[pair]['energy']-analytic),g['sector_energy_abs']);a.upper(st+'/reported residual',s['reported_residual'],g['native_residual_max']);a.upper(st+'/fresh residual',s['fresh_residual'],g['native_residual_max'])
  shell=ordered[count]-ordered[count-1];global_gap=min([shell]+[math.fsum(ordered[:nu]+ordered[:nd])-E for nu,nd in wanted if nu!=count]);a.require(tag+'/independent closed-shell branch andgap',set(sorted(range(L),key=lambda index:levels[index])[:count])=={mode%L for mode in occ} and shell>=g['analytic_gap_min'] and global_gap>=g['analytic_gap_min'] and q['closed_shell_branch_matches'] is True);a.upper(tag+'/reference shellgap',abs(q['shell_gap']-shell),64*sys.float_info.epsilon*max(1,abs(shell)));a.upper(tag+'/reference globalfixedN gap',abs(q['global_gap']-global_gap),64*sys.float_info.epsilon*max(1,abs(global_gap)))
  b=p['balanced'];a.require(tag+'/unique balanced ground',b['ground_dimension']==sectors[f['Nup'],f['Ndown']]['ground_dimension']==1);a.upper(tag+'/balanced actualenergy',abs(b['energy']-E),g['energy_abs']);a.upper(tag+'/global fixedtotalN groundenergy',abs(min(s['energy'] for s in sectors.values())-E),g['energy_abs']);a.upper(tag+'/balanced fresh residual',b['fresh_residual'],g['native_residual_max'])
  masks=[sum(1<<site for site in positions) for positions in itertools.combinations(range(L),count)];labels=list(zip(b['basis_up_masks'],b['basis_down_masks']));wanted_labels={(u,d) for u in masks for d in masks};a.require(tag+'/complete balanced occupation basis',len(labels)==math.comb(L,count)**2 and set(labels)==wanted_labels)
  amplitudes={mask:leibniz([[wave(mode,site) for mode in occ] for site in range(L) if mask>>site&1]) for mask in masks};sv=[amplitudes[u]*amplitudes[d] for u,d in labels];vrows=complex_rows(b['vectors_real'],b['vectors_imag']);a.require(tag+'/complete actual balanced vector',len(vrows)==len(labels) and all(len(row)==1 for row in vrows));v=[row[0] for row in vrows];norm=math.fsum(abs(z)**2 for z in v);snorm=math.fsum(abs(z)**2 for z in sv);fid=abs(csum(x.conjugate()*y for x,y in zip(v,sv)))**2/(norm*snorm);a.upper(tag+'/actual vector norm',abs(norm-1),g['normalization_abs']);a.upper(tag+'/independent Leibniz Slater norm',abs(snorm-1),g['normalization_abs']);a.upper(tag+'/independent Slater fullvector fidelity',abs(fid-1),g['balanced_fidelity_error_max'])
  ref_labels=list(zip(q['balanced_basis_up_masks'],q['balanced_basis_down_masks']));rv=[complex(x,y) for x,y in zip(q['slater_real'],q['slater_imag'])];a.require(tag+'/complete independent reference basis',len(ref_labels)==len(rv)==len(labels) and set(ref_labels)==wanted_labels);a.upper(tag+'/independent Leibniz reference amplitudes',max(abs(z-amplitudes[u]*amplitudes[d]) for z,(u,d) in zip(rv,ref_labels)),g['normalization_abs'])
  energies[L,center,units,gauge]=b['energy'];references[L,center,units,gauge]=q;native_vectors[L,center,units,gauge]=(labels,v);details.append(dict(id=tag,analytic_energy=E,independent_Leibniz_fidelity=fid,spin_sectors=len(wanted)))
 a.require('all980full-sector timings retained with productionphase',sum(len(p['spin_sectors']) for p in n['points'])==980 and all(p['timing_phase']=='production' and math.isfinite(p['elapsed_seconds']) and p['elapsed_seconds']>0 and all(s['timing_phase']=='production' and math.isfinite(s['elapsed_seconds']) and s['elapsed_seconds']>0 for s in p['spin_sectors']) for p in n['points']))
 for f,center,units,gauge in expected:
  if gauge!='uniform':continue
  L=f['L'];lu,vu=native_vectors[L,center,units,'uniform'];lb,vb=native_vectors[L,center,units,'boundary_seam'];where={pair:i for i,pair in enumerate(lu)};phi=units/c['flux_units_denominator'];transformed=[]
  for u,d in lb:
   exponent=sum(site for site in range(L) if u>>site&1)+sum(site for site in range(L) if d>>site&1);transformed.append(cmath.exp(1j*phi*exponent/L)*vu[where[u,d]])
  fidelity=abs(csum(x.conjugate()*y for x,y in zip(vb,transformed)))**2/(math.fsum(abs(z)**2 for z in vb)*math.fsum(abs(z)**2 for z in transformed));a.upper(f'L{L}/ctr{center}/flux{units}/independent fullmanybody gauge fidelity',abs(1-fidelity),g['balanced_fidelity_error_max'])
 a.require('original complete full scientific comparison1question',old['schema']=='A25_COMPARISON_V1' and old['mode']=='production' and old['status']=='PASS' and old['catalogue_status']=='PASS' and old['scientific_completions']==1 and not old['pilot_excluded'] and old['source_freeze_sha256']==sha(source/'source_freeze.json') and old['sector_solves']==980 and len(old['points'])==196 and bool(old['checks']) and all(x['passed'] for x in old['checks']) and old['input_sha256']=={'native':sha(raw/'native.toml'),'reference':sha(raw/'reference.json')})
 response_details=audit_responses(c,old['responses'],energies,references,a)
 return details,response_details

def audit_responses(c,rows,energies,references,a):
 expected=[(f,center,gauge,step) for f in c['fixtures'] for center in c['centers_units'] for gauge in c['gauges'] for step in c['steps_units']];a.require('all56 mandatory fixed response arms',len(rows)==56 and [(r['L'],r['center_units'],r['gauge'],r['step_units']) for r in rows]==[(f['L'],center,gauge,step) for f,center,gauge,step in expected]);up=lambda x:math.nextafter(float(x),math.inf);eps=sys.float_info.epsilon;u=eps/2;gamma32=up(32*u/(1-32*u));gamma16=up(16*u/(1-16*u));previous={};details=[];g=c['gates']
 for (f,center,gauge,step),row in zip(expected,rows):
  L=f['L'];h=step/c['flux_units_denominator'];offsets=(-2,-1,0,1,2);Es=[energies[L,center,center+i*step,gauge] for i in offsets];refs=[references[L,center,center+i*step,gauge] for i in offsets];middle=refs[2];q1=(1,-8,0,8,-1);q2=(-1,16,-30,16,-1);den1=12*h;den2=12*h*h;I=-math.fsum(q*e for q,e in zip(q1,Es))/den1;C=math.fsum(q*e for q,e in zip(q2,Es))/den2;D=L*C/2;allowance=[g['energy_abs']+64*eps*max(1,abs(p['energy'])) for p in refs]
  pieces=dict(current_input=up(math.fsum(abs(q)*d for q,d in zip(q1,allowance))/den1),curvature_input=up(math.fsum(abs(q)*d for q,d in zip(q2,allowance))/den2),current_truncation=up(h**4*middle['max_E5']/30),curvature_truncation=up(h**4*middle['max_E6']/90),current_formation=up(gamma32*math.fsum(abs(q*e) for q,e in zip(q1,Es))/abs(den1)),curvature_formation=up(gamma32*math.fsum(abs(q*e) for q,e in zip(q2,Es))/abs(den2)),current_division=up(gamma16*abs(I)),curvature_division=up(gamma16*abs(C)),current_reference=up(64*eps*max(1,abs(middle['current']))),curvature_reference=up(64*eps*max(1,abs(middle['curvature']))),stiffness_scaling=up(gamma16*abs(D)),unit_roundoff=u,gamma32=gamma32,gamma16=gamma16)
  pieces['current_budget']=up(math.fsum(pieces['current_'+suffix] for suffix in ['input','truncation','formation','division','reference']));pieces['curvature_budget']=up(math.fsum(pieces['curvature_'+suffix] for suffix in ['input','truncation','formation','division','reference']));pieces['stiffness_budget']=up(L*pieces['curvature_budget']/2+pieces['stiffness_scaling']);tag=f'L{L}/ctr{center}/{gauge}/h{step}'
  for name,value in pieces.items():
   tolerance=32*max(math.ulp(value),math.ulp(row[name]));a.upper(tag+'/independent full arithmetic component '+name,abs(row[name]-value),tolerance);a.require(tag+'/nonnegative finite component '+name,math.isfinite(row[name]) and row[name]>=0)
  a.require(tag+'/conditional arithmetic attribution',row['positive_bounds_recording']=='nextafter toward positive infinity; conditional binary64 scope')
  for name,value,exact in [('current',I,middle['current']),('curvature',C,middle['curvature']),('stiffness',D,middle['stiffness'])]:
   a.upper(tag+'/saved finite difference '+name,abs(row[name]-value),32*max(math.ulp(value),math.ulp(row[name])));a.upper(tag+'/predeclared full budget eligibility '+name,pieces[name+'_budget'],g[name+'_abs']);a.upper(tag+'/unchanged fixed exact margin '+name,abs(value-exact),g[name+'_abs']);a.upper(tag+'/conditional propagated error '+name,abs(value-exact),pieces[name+'_budget'])
  key=(L,center,gauge)
  if key in previous:
   before=previous[key]
   for name in ['current','curvature','stiffness']:a.upper(tag+'/both fixed steps no selection '+name,abs(row[name]-before[name]),row[name+'_budget']+before[name+'_budget'])
  previous[key]=row;details.append(dict(L=L,center_units=center,gauge=gauge,step_units=step,independently_rebuilt_budget_components=pieces))
 return details

def replay(source,raw,output,e,c,a):
 dest=output/'frozen_replay';dest.mkdir();cmd=[sys.executable,'-B',str(source/'compare.py'),'--native',str(raw/'native.toml'),'--reference',str(raw/'reference.json'),'--output',str(dest/'comparison.json')];start=time.monotonic();timed_out=False
 with (dest/'comparison.stdout.txt').open('x') as so,(dest/'comparison.stderr.txt').open('x') as se:
  process=subprocess.Popen(cmd,stdout=so,stderr=se,start_new_session=True)
  try:code=process.wait(timeout=120)
  except subprocess.TimeoutExpired:timed_out=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
 a.require('unchanged full frozen comparator replay exit0',code==0 and not timed_out);a.require('exact entire original full comparator JSON',read(raw/'comparison.json')==read(dest/'comparison.json'))
 resources={};caps={'native':c['resources']['production_target_timeout_seconds'],'reference':c['resources']['production_reference_timeout_seconds'],'comparison':c['resources']['production_compare_timeout_seconds']}
 for p in e['processes']:
  text=(raw/p['time']).read_text();match=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text);a.require('original successful GNUtime/resource '+p['label'],match is not None and 'Exit status: 0' in text and int(match[1])==p['max_rss_kib'] and 0<p['max_rss_kib']<=3500*1024 and 0<p['wall_seconds']<=caps[p['label']]);resources[p['label']]=dict(wall_seconds=p['wall_seconds'],peak_RSS_KiB=p['max_rss_kib'],original_cap_seconds=caps[p['label']])
 return dict(argv=cmd,exit_code=code,timed_out=timed_out,elapsed_seconds=time.monotonic()-start,comparison_sha256=sha(dest/'comparison.json'),exact_JSON_equal=True),resources

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--packet',type=Path,required=True);parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--freeze',type=Path,required=True);parser.add_argument('--expected-auditor-sha256',required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 if sha(HERE/'plan.json')!=PLAN_SHA256 or sha(__file__)!=args.expected_auditor_sha256:raise SystemExit('Reviewed full auditor/plan differs')
 plan=read(HERE/'plan.json')
 if not os.getenv('SLURM_JOB_ID') or os.getenv('SLURM_JOB_ID')==plan['job_id'] or os.getenv('SLURM_CPUS_PER_TASK')!='1' or os.getenv('SLURM_MEM_PER_NODE')!='3500' or platform.python_version()!=plan['python_version']:raise SystemExit('Separate ROOT-reviewed exact1CPU3500MB/pinned3.11.11 analysis allocation required')
 for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','JULIA_NUM_THREADS']:os.environ[name]='1'
 for name in ['packet','archive','freeze','output']:setattr(args,name,getattr(args,name).resolve())
 args.output.mkdir(parents=True,exist_ok=False);a=Audit();a.bind(__file__);a.bind(HERE/'plan.json');details=[];responses=[];replayed=None;resources={};error=None
 try:
  source,raw,e,runtime,mapping=closure(args,plan,a);details,responses=audit_math(source,raw,plan,a,mapping);replayed,resources=replay(source,raw,args.output,e,read(source/'manifest.toml'),a)
  for name,digest in list(a.inputs.items()):a.require('all original full inputs immutable/'+name,sha(name)==digest)
  for name,spec in runtime['files'].items():a.require('actual119runtime after unchanged/'+name,sha(name)==spec['sha256'])
 except Exception as exception:error=type(exception).__name__+': '+str(exception);a.need('full saved-data audit completed',False,error=error)
 status='PASS' if error is None and all(row['passed'] for row in a.checks) else 'UNRESOLVED';report=dict(schema='A25_FULL_SAVED_DATA_AUDIT_V1',audit_status=status,integrity_status=status,catalogue_id='A25',catalogue_status='PASS' if status=='PASS' else 'UNRESOLVED',scientific_completions=int(status=='PASS'),pilot_scientific_completions=0,original_job=plan['job_id'],analysis_job=os.environ['SLURM_JOB_ID'],authorship=plan['authorship'],auditor_sha256=sha(__file__),audit_plan_sha256=sha(HERE/'plan.json'),preserved_pilot_auditor_sha256=plan['pilot_auditor_sha256'],source_archive_sha256=plan['source_archive_sha256'],source_freeze_sha256=plan['source_freeze_sha256'],input_sha256=a.inputs,checks=a.checks,check_count=len(a.checks),point_details=details,response_details=responses,frozen_full_comparator_replay=replayed,original_full_resources=resources,error=error,source_kernel_or_gate_changes=False,producer_eigensolver_sampler_or_reference_rerun=False,new_fixture_or_job_submitted=False,full_ledger_or_publication_mutated=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope=plan['scope'])
 write(args.output/'audit.json',report);print(status);return 0 if status=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
