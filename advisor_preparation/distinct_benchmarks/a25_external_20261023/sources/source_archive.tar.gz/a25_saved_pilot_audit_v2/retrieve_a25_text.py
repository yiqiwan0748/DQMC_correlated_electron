#!/usr/bin/env python3
"""Remote read-only collector: scientific text/source archives and metadata only."""
import hashlib, io, json, stat, subprocess, sys, tarfile, time
from pathlib import Path
ROOT=Path('/lustre/isaac24/scratch/ywang287/advisor-validation-20261022')
SOURCE=ROOT/'source/free_ring_flux_v1'
RAW=ROOT/'results/a25_free_ring_flux_pilot_20261023T1918Z'
JOB='6466533'
ARCHIVE_SHA='76be7b3b22ee26da1ae91dde516ed458446aa6a0c6c2a4ef7e86759d5ec921ec'
FREEZE_SHA='9ce63aad259c091a40bf2af4668213b7c446df74c0aa93e73a70a16a65216ba7'
def digest(b):return hashlib.sha256(b).hexdigest()
def stamp(p):
 s=p.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,inode=s.st_ino)
def main():
 freeze=json.loads((SOURCE/'source_freeze.json').read_text())
 assert digest((SOURCE/'source_freeze.json').read_bytes())==FREEZE_SHA
 pins=json.loads((SOURCE/'runtime_pins.json').read_text())
 def runtime():
  out={}
  for n,row in pins['files'].items():
   p=Path(n);assert str(p.resolve())==row['realpath'];s=stamp(p)
   h=hashlib.sha256()
   with p.open('rb') as stream:
    for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
   assert h.hexdigest()==row['sha256'] and s['bytes']==row['bytes'] and stamp(p)==s
   out[n]=dict(path=str(p),realpath=str(p.resolve()),sha256=h.hexdigest(),**s)
  assert len(out)==119
  return out
 before_runtime=runtime();files={}
 for n in freeze['files']:files['source/'+n]=SOURCE/n
 files['source/source_freeze.json']=SOURCE/'source_freeze.json';files['release_freeze.json']=SOURCE/'source_freeze.json'
 for p in sorted(RAW.rglob('*')):
  if p.is_file() and not p.is_symlink() and p.suffix.lower() in {'.json','.toml','.txt','.log','.csv'}:files['results/'+p.relative_to(RAW).as_posix()]=p
 log=ROOT/f'results/a25_free_ring_flux_pilot_{JOB}.log'
 if log.is_file():files['outer_logs/'+log.name]=log
 candidates=[]
 for directory in [ROOT/'source',ROOT/'source_releases',ROOT]:
  if directory.is_dir():candidates.extend(p for p in directory.iterdir() if p.is_file() and ('a25' in p.name or 'free_ring_flux' in p.name) and p.name.endswith('.tar.gz'))
 found=[p for p in candidates if digest(p.read_bytes())==ARCHIVE_SHA]
 if found:files['source_archive.tar.gz']=found[0]
 bodies={};before=[]
 for n,p in sorted(files.items()):
  assert not p.is_symlink() and stat.S_ISREG(p.stat().st_mode)
  s=stamp(p);b=p.read_bytes();t=stamp(p);assert s==t
  if not n.endswith('.tar.gz'):b.decode('utf8')
  bodies[n]=b;before.append(dict(local=n,remote=str(p),sha256=digest(b),bytes=len(b),before=s,after_read=t))
 after=[]
 for n,p in sorted(files.items()):
  b=p.read_bytes();s=stamp(p);after.append(dict(local=n,sha256=digest(b),**s));assert digest(b)==digest(bodies[n])
 after_runtime=runtime();assert before_runtime==after_runtime
 bdoc=dict(schema='A25_SCIENTIFIC_REMOTE_TRANSFER_BEFORE_V1',job_id=JOB,created_unix=time.time(),files=before,runtime_critical_file_sha256={n:v['sha256'] for n,v in before_runtime.items()},runtime_files=before_runtime,runtime_binaries_transferred=False,archive_found_remotely=bool(found))
 adoc=dict(schema='A25_SCIENTIFIC_REMOTE_TRANSFER_AFTER_V1',job_id=JOB,status='PASS',created_unix=time.time(),files=after,runtime_critical_file_sha256={n:v['sha256'] for n,v in after_runtime.items()},runtime_files=after_runtime,runtime_binaries_transferred=False)
 bodies['transfer_before.json']=(json.dumps(bdoc,indent=2)+'\n').encode();bodies['transfer_after.json']=(json.dumps(adoc,indent=2)+'\n').encode()
 q=subprocess.run(['sacct','-n','-P','-j',JOB,'--format=JobIDRaw,JobName,State,ExitCode,AllocCPUS,Start,End,Elapsed,MaxRSS,Timelimit'],capture_output=True,check=True);bodies['sacct_fresh.txt']=q.stdout
 with tarfile.open(fileobj=sys.stdout.buffer,mode='w|') as tar:
  for n,b in sorted(bodies.items()):
   t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
if __name__=='__main__':main()
