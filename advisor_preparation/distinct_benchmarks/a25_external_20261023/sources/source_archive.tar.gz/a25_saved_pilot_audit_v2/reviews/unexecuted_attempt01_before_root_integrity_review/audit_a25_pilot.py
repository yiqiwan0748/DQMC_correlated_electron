#!/usr/bin/env python3
"""Saved original A25 pilot audit; same-agent authorship disclosed, always zero credit."""
import argparse,cmath,datetime,hashlib,itertools,json,math,os,platform,re,subprocess,sys,tarfile,time,tomllib
from pathlib import Path,PurePosixPath
HERE=Path(__file__).resolve().parent
PLAN_SHA256='19e85beac3d80680b32d91e903a0b3fb9b070c7f7fbf35a69d2e36998b59c63c'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def read(p):
 p=Path(p);return tomllib.loads(p.read_text()) if p.suffix=='.toml' else json.loads(p.read_text())
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
class Audit:
 def __init__(self):self.checks=[];self.inputs={}
 def need(self,name,ok,**details):self.checks.append(dict(name=name,passed=bool(ok),**details))
 def require(self,name,ok):
  self.need(name,ok)
  if not ok:raise ValueError(name)
 def upper(self,name,value,bound):
  value=float(value);self.need(name,math.isfinite(value) and value<=bound,value=value if math.isfinite(value) else None,bound=bound)
 def bind(self,p):
  p=Path(p).resolve();self.inputs[str(p)]=sha(p);return self.inputs[str(p)]
def complex_rows(re,im):
 if len(re)!=len(im) or any(len(x)!=len(y) for x,y in zip(re,im)):raise ValueError('Incomplete complex rows')
 return [[complex(a,b) for a,b in zip(x,y)] for x,y in zip(re,im)]
def csum(v):
 v=list(v);return complex(math.fsum(z.real for z in v),math.fsum(z.imag for z in v))
def leibniz(matrix):
 """Independent small determinant via permutations, no elimination/eigensolver."""
 total=[];n=len(matrix)
 for p in itertools.permutations(range(n)):
  z=complex(-1 if sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))%2 else 1)
  for i in range(n):z*=matrix[i][p[i]]
  total.append(z)
 return csum(total)
def closure(args,plan,a):
 packet=args.packet;source=packet/'source';raw=packet/'results/results'
 a.require('exact canonical source archive',a.bind(args.archive)==plan['source_archive_sha256']);a.require('exact source freeze',a.bind(args.freeze)==plan['source_freeze_sha256']);a.require('actual remote original freeze marker',a.bind(source/'source_freeze.json')==plan['source_freeze_sha256'])
 freeze=read(args.freeze);seen=set()
 with tarfile.open(args.archive,'r:gz') as t:
  for m in t:
   a.require('safe original source member/'+m.name,m.isfile() and not m.issym() and not m.islnk() and m.name.startswith(freeze['prefix']) and '..' not in PurePosixPath(m.name).parts)
   name=m.name[len(freeze['prefix']):];a.require('unique expected source member/'+name,name not in seen and name in freeze['files']);seen.add(name)
   a.require('exact original source byte/'+name,hashlib.sha256(t.extractfile(m).read()).hexdigest()==freeze['files'][name]==a.bind(source/name))
 a.require('all30original source members',seen==set(freeze['files']) and len(seen)==plan['source_members'])
 before=read(packet/'transfer_before.json');after=read(packet/'transfer_after.json');a.bind(packet/'transfer_before.json');a.bind(packet/'transfer_after.json')
 b={x['local']:x for x in before['files']};z={x['local']:x for x in after['files']};a.require('complete stable transfer membership',len(b)==len(before['files']) and len(z)==len(after['files']) and set(b)==set(z) and before['job_id']==after['job_id']==plan['job_id'] and after['status']=='PASS')
 for name,row in b.items():
  path=packet/name;p=PurePosixPath(name);a.require('safe regular transferred file/'+name,not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name and not path.is_symlink())
  a.require('original remote file retained/'+name,a.bind(path)==row['sha256']==z[name]['sha256'] and path.stat().st_size==row['bytes']==z[name]['bytes'] and row['before']==row['after_read'] and all(row['after_read'][k]==z[name][k] for k in ['inode','mtime_ns']))
 a.require('stable119runtime metadata maps',len(before['runtime_files'])==plan['runtime_files'] and before['runtime_files']==after['runtime_files'])
 runtime=read(source/'runtime_pins.json');mapping={n:v['sha256'] for n,v in runtime['files'].items()}
 a.require('exact119runtime hashes before-after',before['runtime_critical_file_sha256']==after['runtime_critical_file_sha256']==mapping)
 for name,spec in runtime['files'].items():
  row=before['runtime_files'][name];a.require('original119runtime metadata/'+name,row['sha256']==spec['sha256'] and row['bytes']==spec['bytes'] and row['realpath']==spec['realpath'])
 accounting=(packet/'sacct_fresh.txt').read_text();a.bind(packet/'sacct_fresh.txt');rows=[x.split('|') for x in accounting.splitlines() if x.strip()];job=[x for x in rows if x[0]==plan['job_id']]
 a.require('original terminalCOMPLETED0:0oneCPU',len(job)==1 and len(job[0])==10 and job[0][2:5]==['COMPLETED','0:0','1'])
 e=read(raw/'execution.json');a.bind(raw/'execution.json');a.require('original scientific execution source/pilot/zero-credit',e['schema']=='A25_SCIENTIFIC_EXECUTION_V1' and e['mode']=='pilot' and e['scientific_completions']==0 and e['job_id']==plan['job_id'] and e['source_freeze_sha256']==plan['source_freeze_sha256'] and e['threads']==1 and e['full_review'] is None)
 a.require('all3 original processes completed before any math',[x['label'] for x in e['processes']]==['native','reference','comparison'] and all(x['exit_code']==0 and not x['timed_out'] for x in e['processes']) and e['status']=='PROCESSES_COMPLETE' and all((raw/n).is_file() for n in ['native.toml','reference.json','comparison.json']))
 for name,spec in e['outputs'].items():a.require('original execution output/'+name,a.bind(raw/name)==spec['sha256'] and (raw/name).stat().st_size==spec['bytes'])
 a.require('original execution runtime119',e['runtime_before_sha256']==e['runtime_after_sha256']==mapping and e['runtime_pins_sha256']==sha(source/'runtime_pins.json'))
 for name,spec in runtime['files'].items():
  path=Path(name);a.require('actual currently pinned119runtime bytes/'+name,str(path.resolve())==spec['realpath'] and path.stat().st_size==spec['bytes'] and sha(path)==spec['sha256'])
 a.require('actual pinned Python executable',str(Path(sys.executable).resolve())==runtime['python_executable_realpath'])
 return source,raw,e,runtime,mapping

def audit_math(source,raw,plan,a,mapping):
 c=read(source/'manifest.toml');lim=c['gates'];n=read(raw/'native.toml');r=read(raw/'reference.json');old=read(raw/'comparison.json');a.bind(raw/'native.toml');a.bind(raw/'reference.json');a.bind(raw/'comparison.json')
 source_sha={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (source/'SHA256SUMS').read_text().splitlines()}
 a.require('same frozen full source mapping in allscientific roles',n['source_sha256']==r['source_sha256']==source_sha and n['source_freeze_sha256']==r['source_freeze_sha256']==sha(source/'source_freeze.json'))
 a.require('actual native vs independent analytic role',n['schema']=='A25_NATIVE_COMPLEX_ED_RAW_V1' and n['backend']=='actual_native_complex_ED' and r['schema']=='A25_STDLIB_ANALYTIC_RAW_V1' and r['backend']=='independent_stdlib_reference' and not r['target_raw_imported'])
 a.require('original mode/job/runtime/version/zero-credit',all(d['mode']=='pilot' and d['job_id']==plan['job_id'] and d['scientific_completions']==0 and d['runtime_file_sha256']==mapping and d['runtime_pins_sha256']==sha(source/'runtime_pins.json') for d in [n,r]) and n['julia_version']==c['julia_version'] and n['threads']==1 and r['python_version']==c['python_version'])
 expected=[(6,c['pilot_center_units'],c['pilot_center_units']+offset,gauge) for offset in c['stencil_union_offsets_units'] for gauge in c['gauges']]
 for name,data in [('native',n),('reference',r)]:a.require(name+'/complete ordered14point grid',[(p['L'],p['center_units'],p['flux_units'],p['gauge']) for p in data['points']]==expected and len(data['points'])==plan['points'])
 fixture=next(f for f in c['fixtures'] if f['L']==6);L=6;N=6;occ=fixture['occupied_integer_modes'];energies={};details=[]
 for (L,center,units,gauge),p,q in zip(expected,n['points'],r['points']):
  tag=p['id'];phi=units/c['flux_units_denominator'];a.require(tag+'/exact metadata',p['N']==q['N']==6 and p['id']==q['id']==f'L6/center{center}/flux{units}/{gauge}' and p['phi']==q['phi']==phi)
  wave=lambda mode,site:cmath.exp(2j*math.pi*mode*site/L)/math.sqrt(L)*(cmath.exp(1j*site*phi/L) if gauge=='boundary_seam' else 1)
  one=[-2*c['t']*math.cos((2*math.pi*mode+phi)/L) for mode in range(L)];ordered=sorted(one);E=2*math.fsum(one[mode%L] for mode in occ)
  K=[[0j for j in range(L)] for i in range(L)]
  for site in range(L):
   dest=(site+1)%L;phase=cmath.exp(-1j*phi/L) if gauge=='uniform' else cmath.exp(-1j*phi) if site==L-1 else 1+0j
   K[dest][site]+=-c['t']*phase;K[site][dest]+=-c['t']*phase.conjugate()
  for backend,row in [('native',p),('reference',q)]:
   actual=complex_rows(row['K_real'],row['K_imag']);a.require(tag+'/'+backend+'completeKshape',len(actual)==L and all(len(v)==L for v in actual));a.upper(tag+'/'+backend+'direct edge K',max(abs(actual[i][j]-K[i][j]) for i in range(L) for j in range(L)),lim['K_abs'])
  sectors={(s['Nup'],s['Ndown']):s for s in p['spin_sectors']};refs={(s['Nup'],s['Ndown']):s for s in q['spin_sectors']};wanted={(nu,N-nu) for nu in range(7)}
  a.require(tag+'/all7spinsectors',len(p['spin_sectors'])==len(q['spin_sectors'])==7 and set(sectors)==set(refs)==wanted)
  for pair,row in sectors.items():
   nu,nd=pair;analytic=math.fsum(ordered[:nu]+ordered[:nd]);st=tag+'/sector'+str(pair)
   a.require(st+'/actual dense solver qualification',row['method']=='dense' and row['converged'] and row['ground_subspace_resolved'] and row['dimension']==math.comb(L,nu)*math.comb(L,nd))
   a.upper(st+'/native occupation sumE',abs(row['energy']-analytic),lim['sector_energy_abs']);a.upper(st+'/reference occupation sumE',abs(refs[pair]['energy']-analytic),lim['sector_energy_abs']);a.upper(st+'/reportedresidual',row['reported_residual'],lim['native_residual_max']);a.upper(st+'/freshresidual',row['fresh_residual'],lim['native_residual_max'])
  balanced=p['balanced'];a.require(tag+'/uniquebalancedground',balanced['ground_dimension']==1 and sectors[3,3]['ground_dimension']==1);a.upper(tag+'/nativebalancedE',abs(balanced['energy']-E),lim['energy_abs']);a.upper(tag+'/referencebalancedE',abs(q['energy']-E),lim['energy_abs']);a.upper(tag+'/globalfixedNE',abs(min(s['energy'] for s in sectors.values())-E),lim['energy_abs'])
  masks=[sum(1<<j for j in sites) for sites in itertools.combinations(range(L),3)];expected_labels={(u,d) for u in masks for d in masks};labels=list(zip(balanced['basis_up_masks'],balanced['basis_down_masks']));a.require(tag+'/complete400maskbasis',len(labels)==400 and set(labels)==expected_labels)
  amps={mask:leibniz([[wave(mode,site) for mode in occ] for site in range(L) if mask>>site&1]) for mask in masks};analytic_vector=[amps[u]*amps[d] for u,d in labels];actual=complex_rows(balanced['vectors_real'],balanced['vectors_imag']);a.require(tag+'/completebalancedvector',len(actual)==400 and all(len(row)==1 for row in actual));v=[row[0] for row in actual]
  norm=math.fsum(abs(z)**2 for z in v);snorm=math.fsum(abs(z)**2 for z in analytic_vector);fid=abs(csum(x.conjugate()*y for x,y in zip(v,analytic_vector)))**2/(norm*snorm)
  a.upper(tag+'/nativevectornorm',abs(norm-1),lim['normalization_abs']);a.upper(tag+'/LeibnizSlaternorm',abs(snorm-1),lim['normalization_abs']);a.upper(tag+'/independentLeibniznativefidelity',abs(1-fid),lim['balanced_fidelity_error_max'])
  rlabels=list(zip(q['balanced_basis_up_masks'],q['balanced_basis_down_masks']));a.require(tag+'/referencemaskbasis',len(rlabels)==400 and set(rlabels)==expected_labels);rv=[complex(x,y) for x,y in zip(q['slater_real'],q['slater_imag'])];a.require(tag+'/referencevectorcomplete',len(rv)==400);a.upper(tag+'/Leibniz-referenceamplitudes',max(abs(z-amps[u]*amps[d]) for z,(u,d) in zip(rv,rlabels)),lim['normalization_abs'])
  energies[units,gauge]=balanced['energy'];details.append({'id':tag,'Leibniz_fidelity':fid,'analytic_energy':E,'allsectors':7})
 a.require('all98native timings andonecoldpoint retained',sum(len(p['spin_sectors']) for p in n['points'])==98 and n['points'][0]['timing_phase']=='cold_first_complete_point' and all(p['timing_phase']=='warm_after_first_complete_point' for p in n['points'][1:]) and all(s['timing_phase']==p['timing_phase'] and math.isfinite(s['elapsed_seconds']) and s['elapsed_seconds']>0 for p in n['points'] for s in p['spin_sectors']))
 warm=[(p,s) for p in n['points'][1:] for s in p['spin_sectors']];a.require('all91warmcoveragebothgauges7sectorsdim400',len(warm)==91 and {p['gauge'] for p,s in warm}==set(c['gauges']) and {(s['Nup'],s['Ndown']) for p,s in warm}=={(nu,6-nu) for nu in range(7)} and max(s['dimension'] for p,s in warm)==400)
 a.require('recordedall518frozengatespilot0credit',old['status']=='PASS' and old['mode']=='pilot' and old['catalogue_status']=='NOT_RUN' and old['scientific_completions']==0 and old['pilot_excluded'] and len(old['checks'])==518 and all(row['passed'] for row in old['checks']) and old['sector_solves']==98 and old['input_sha256']=={'native':sha(raw/'native.toml'),'reference':sha(raw/'reference.json')})
 a.require('all4responsearmsmandatory',[(x['gauge'],x['step_units']) for x in old['responses']]==[(ga,h) for ga in c['gauges'] for h in c['steps_units']])
 for response in old['responses']:
  gauge=response['gauge'];step=response['step_units'];h=step/100;E5=[energies[c['pilot_center_units']+i*step,gauge] for i in (-2,-1,0,1,2)];I=-math.fsum(q*e for q,e in zip((1,-8,0,8,-1),E5))/(12*h);C=math.fsum(q*e for q,e in zip((-1,16,-30,16,-1),E5))/(12*h*h);D=3*C
  for field,value in [('current',I),('curvature',C),('stiffness',D)]:a.upper(gauge+'/h'+str(step)+'/savedFD'+field,abs(response[field]-value),1e-12)
  for field,gate in [('current','current_abs'),('curvature','curvature_abs'),('stiffness','stiffness_abs')]:a.upper(gauge+'/h'+str(step)+'/unchangedbudget'+field,response[field+'_budget'],lim[gate])
 return details

def replay(source,raw,output,e,c,a):
 out=output/'frozen_replay';out.mkdir();commands=[('comparison',[sys.executable,'-B',str(source/'compare.py'),'--native',str(raw/'native.toml'),'--reference',str(raw/'reference.json'),'--output',str(out/'comparison.json')]),('assessment',[sys.executable,'-B',str(source/'assess_pilot.py'),'--raw',str(raw.parent),'--output',str(out/'assessment.json')])];receipts=[]
 for label,cmd in commands:
  start=time.monotonic()
  with (out/(label+'.stdout.txt')).open('x') as so,(out/(label+'.stderr.txt')).open('x') as se:result=subprocess.run(cmd,stdout=so,stderr=se,check=False,timeout=120)
  receipts.append({'label':label,'argv':cmd,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start});a.require('unchangedfrozen'+label+'exit0',result.returncode==0)
 a.require('exactoriginalcomparatorJSONreplay',read(raw/'comparison.json')==read(out/'comparison.json'))
 assessment=read(out/'assessment.json');a.require('sourceboundassessor0credit',assessment['schema']=='A25_EXCLUDED_PILOT_RESOURCE_ASSESSMENT_V1' and assessment['source_freeze_sha256']==sha(source/'source_freeze.json') and assessment['scientific_completions']==0 and assessment['catalogue_status']=='NOT_RUN' and not assessment['full_execution_authorized'] and assessment['independent_audit_and_root_review_still_required'])
 proc={x['label']:x for x in e['processes']};native=read(raw/'native.toml');warm=[s['elapsed_seconds'] for p in native['points'][1:] for s in p['spin_sectors']];res=c['resources']
 for label,row in proc.items():
  text=(raw/row['time']).read_text();m=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text);a.require('originalGNUtimematches'+label,m is not None and int(m[1])==row['max_rss_kib'] and row['max_rss_kib']>0 and math.isfinite(row['wall_seconds']) and row['wall_seconds']>0)
 projected_native=2*(proc['native']['wall_seconds']+980*max(warm));projected_total=projected_native+28*(proc['reference']['wall_seconds']+proc['comparison']['wall_seconds'])+30;projected_mib=2*(max(x['max_rss_kib'] for x in proc.values())/1024+64)
 for field,expected in [('native_forecast_seconds',projected_native),('full_forecast_seconds',projected_total),('full_forecast_mib',projected_mib)]:a.upper('independentfixedresourceformula/'+field,abs(assessment[field]-expected),1e-12)
 eligible=projected_total<=res['full_projection_limit_seconds'] and projected_mib<=res['full_projection_limit_mib'] and projected_native<=res['production_target_timeout_seconds']-res['termination_guard_seconds'];a.require('exactoriginalresourceeligibilityBoolean',assessment['eligible_for_root_full_review']==eligible)
 return receipts,assessment

def main():
 p=argparse.ArgumentParser();p.add_argument('--packet',type=Path,required=True);p.add_argument('--archive',type=Path,required=True);p.add_argument('--freeze',type=Path,required=True);p.add_argument('--expected-auditor-sha256',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 if sha(HERE/'audit_plan.json')!=PLAN_SHA256 or sha(__file__)!=args.expected_auditor_sha256:raise SystemExit('Reviewedauditor/planSHA differs')
 plan=read(HERE/'audit_plan.json')
 if not os.getenv('SLURM_JOB_ID') or os.getenv('SLURM_JOB_ID')==plan['job_id'] or os.getenv('SLURM_CPUS_PER_TASK')!='1' or os.getenv('SLURM_MEM_PER_NODE')!='3500' or platform.python_version()!=plan['python_version']:raise SystemExit('SeparateROOTanalysisallocationexact1CPU3500MB/pinned3.11.11 required; nologin/localversionbypass')
 for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','JULIA_NUM_THREADS'):os.environ[key]='1'
 for name in ('packet','archive','freeze','output'):setattr(args,name,getattr(args,name).resolve())
 args.output.mkdir(parents=True,exist_ok=False);a=Audit();a.bind(__file__);a.bind(HERE/'audit_plan.json');details=[];replays=[];assessment=None;error=None
 try:
  source,raw,e,runtime,mapping=closure(args,plan,a);details=audit_math(source,raw,plan,a,mapping);replays,assessment=replay(source,raw,args.output,e,read(source/'manifest.toml'),a)
  for name,digest in list(a.inputs.items()):a.require('allboundinputbytesunchanged/'+name,sha(name)==digest)
  for name,spec in runtime['files'].items():a.require('actualruntimeafterunchanged/'+name,sha(name)==spec['sha256'])
 except Exception as exception:error=type(exception).__name__+': '+str(exception);a.need('saved-dataauditfinished',False,error=error)
 status='PASS' if error is None and all(row['passed'] for row in a.checks) else 'UNRESOLVED'
 report={'schema':'A25_SAVED_DATA_PILOT_AUDIT_V1','audit_status':status,'integrity_status':status,'original_job':plan['job_id'],'analysis_job':os.environ['SLURM_JOB_ID'],'catalogue_status':'NOT_RUN','scientific_completions':0,'pilot_excluded':True,'authorship':plan['authorship'],'source_archive_sha256':plan['source_archive_sha256'],'source_freeze_sha256':plan['source_freeze_sha256'],'auditor_sha256':sha(__file__),'audit_plan_sha256':sha(HERE/'audit_plan.json'),'input_sha256':a.inputs,'checks':a.checks,'check_count':len(a.checks),'point_details':details,'frozen_replays':replays,'resource_assessment':assessment,'full_execution_authorized':False,'new_producer_or_eigensolver_or_sampling':False,'new_job_submitted':False,'error':error,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 write(args.output/'audit.json',report);print(status);return 0 if status=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
