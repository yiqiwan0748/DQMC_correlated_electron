# L48 Bethe/DMRG resource pilot — prepared for review

This unfrozen proposal follows the independently audited L32 pilot 6458711.
It has not been submitted or executed. It cannot complete A18, A19 or A20:
the native target and mathematical summarizer retain zero scientific credit.
The original source releases, failed/cancelled attempts and October 22 stop
records stay unchanged. The human explicitly resumed the campaign October 23;
the old audit itself grants no new execution permission.

The fixture is one open 48-site Hubbard chain at t=1, U=4 and physical mu=0.
Half-filled, one-electron-removed and one-electron-added sectors each receive
the same two arms as L24/L32: chi 256/512, 18/24 sweeps and cutoffs 1e-12/1e-13.
Every variance, truncation, normalization, particle-number, particle-hole and
coarse/refined stability threshold is unchanged in pilot.toml. The actual user
hubbard_mpo, Project/Manifest and Julia/ITensor versions remain byte-pinned;
ITensorMPS supplies the optimizer. The target and independent Lieb–Wu oracle
are byte-identical to L32. The summarizer changes one planning sentence only.

Before numerical work, the wrapper checks the exact 177-check L32 audit and
the original public engineering anchor. It requires elapsed time at most 1800s
and the larger of process/batch RSS at most 2300 MiB. The measured L32 values
are 1316 s, batch 1735276 KiB and process 1740640 KiB; both conditions hold. These
are resource prerequisites, not thermodynamic accuracy or a timing guarantee.
The historical anchor proposed L24 to L32 only; applying its same thresholds
to L32 to L48 is this new engineering proposal, not historical preauthorization.

Request one CPU and 3500 MB, with a 60-minute allocation and 55-minute target cap.
The empirical runtime estimate is 30–55 minutes after start, excluding queue
delay. Fixed-chi length scaling gives 1316×48/32=1974 s (32m54s) before further
allowance; linear peak scaling gives 2610960 KiB. Entanglement, effective QN
blocks, contractions and filesystem delays can change either estimate.
Incomplete arms and resource failures must remain recorded. No larger size
or automatic subsequent job is embedded. Root must independently review this
source, inspect the current whole-user queue, announce a checkpoint and admit
any execution separately, preserving the two-total-running-job limit.

This pilot compares finite-chain diagnostics with the bulk oracle without
requiring finite/infinite equality. It performs no extrapolation. The original
full proposal still fixes training lengths 16/24/32/40/48 and untouched held-out
lengths 56/64; no size, fit or margin is changed here. Any later scientific
executor must explicitly declare pilot reuse before analysis and implement
the original uncertainty, held-out and fit-stability gates. L48 alone gives
zero catalogue completions and establishes no L56/L64 resource eligibility.
