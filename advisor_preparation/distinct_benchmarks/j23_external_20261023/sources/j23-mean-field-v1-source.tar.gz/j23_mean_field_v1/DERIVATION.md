# J23 proposal: an occupancy-qualified Appendix D comparison

This proposal is not frozen, implemented or executed. J23 remains NOT_RUN. The source is the author preprint [Giuli, Mejuto-Zaera and Capone, Appendix D](https://arxiv.org/html/2410.00909v1#A4). Its momentum-wise two-lowest-band argument must not be treated as a proof of energetic ordering at an arbitrary doped global Fermi sea.

A bounded implementation can use the same Appendix D occupancy prescription at canonical density two electrons per cell. Set the fixed exchange magnitude m=12 or16 and U=2m, with the published diagonal hoppings and small registered t4. Parallel trial density is [[1,0],[1,0]], antiparallel is [[1,0],[0,1]]. Actual unchanged HFCompetition.evaluate generates the corresponding centered spin potentials and computes the physical Hartree-Fock functional using its resulting local density. New grid assembly supplies unchanged native bloch_hamiltonian at each momentum. No iterative SCF claim follows.

The evaluator uses T=.001 only as an API carrier. It must yield occupations exactly0or1, zero entropy and a common occupied/unoccupied gap of at least1; otherwise the declared pure-Slater test is UNRESOLVED rather than silently changed to thermal mean field. A new observer must explicitly certify these conditions from every eigenvalue and occupation. The same density and energy convention apply to both orientations.

For an independent reference, write e=(epsilon_x-epsilon_y)/2, a=(epsilon_x+epsilon_y)/2, g=-4sin(kx)sin(ky), h=t4*g. The two spin blocks have scalar mean a and vectors (h,0,e+s*m) in the antiparallel case. Their occupied projectors are [I-(h*sigma_x+(e+s*m)*sigma_z)/sqrt((e+s*m)^2+h^2)]/2. The parallel state fills both bands of one spin block. Analytic projectors give the kinetic expectation, while Wick contraction of the momentum-averaged local densities gives U*sum_alpha(n_alpha_up-.5)*(n_alpha_down-.5). This is the physical trial energy; the occupied auxiliary band sum alone omits the interaction correction.

At t4=0 both orientations have the same energy. In the stated globally gapped regime m>|e|, expanding this physical functional at U=2m gives the independently derived coefficient

    (E_antiparallel-E_parallel)/t4^2 ->
        - average_BZ[ m*g(k)^2/(m^2-e(k)^2) ].

It is negative for nonzero mixing on a set of finite measure. This coefficient follows from the Appendix D trial blocks plus Wick interaction accounting; the paper does not tabulate the newly chosen m values. The proposed test compares the full finite-t4 physical energy, paper eigenvalues/order, zero-hybridization control, sign reversal t4->-t4, and the leading coefficient. A Richardson estimate from fixed t4=.01 and .02 removes the first finite-hybridization correction; .04 supplies an independent fit-stability check, never a selected replacement.

The native square meshes16/32/64/128 and independent tensor Gauss orders64/96/128 must all be retained. All proposal gates are in proposal.json and still await peer review before any data. A real implementation needs explicit cold/warm timing receipts and predeclared resource projection before full execution. Parameter arms are one journal question, not additional ideas. No numerical result, new ground-state theorem, gRISB accuracy or phase-boundary reproduction is claimed.

A conservative pre-data bound is |epsilon_plus|<=8.9 and |epsilon_minus|<=1.5. All declared t4 satisfy |h|<=.64. Thus the parallel common mu=0 gap is at least12-8.9-sqrt(1.5^2+.64^2)>1.46, while the antiparallel gap is at least1.6. This makes the prescribed occupation regime testable without choosing points after data. Every actual native eigenvalue and occupation must still qualify. The Richardson formulas, fixed .02/.04 held-out stability comparison and 1e-6 stability gate are explicit in proposal.json. A direct observer must reproduce actual evaluate().rho and evaluate().physicalF before interpreting the independent analytic-projector result.
