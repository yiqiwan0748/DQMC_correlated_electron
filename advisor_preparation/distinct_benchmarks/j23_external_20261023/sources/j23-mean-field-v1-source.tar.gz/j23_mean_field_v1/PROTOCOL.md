# J23 prescribed mean-field trial energy — unexecuted candidate

This source preparation implements the unchanged theory-reviewed `proposal.json` and `DERIVATION.md` copied from `j23_mean_field_feasibility_v1`. It is not frozen or executed. J23 remains NOT_RUN. No source archive, numerical fixture/control evaluation, job or new scientific result has been produced. Parent and independent review must finish before freezing or any excluded pilot.

The journal question is the AppendixD hybridization mechanism favoring orbital-antiparallel over parallel **prescribed trial Slater states**. This is an occupancy-qualified functional comparison at n=2 per cell, not a self-consistent solution, exact ground-state certificate, doped-state theorem, gRISB reproduction or phase boundary. The author-preprint reference is [AppendixD, equations33–38](https://arxiv.org/html/2410.00909v1#A4). The newly selected exchange magnitudes are not tabulated journal data. The leading coefficient below is derived from those trial blocks plus physical Wick interaction accounting.

## Fixed model, states and normalization

All original proposal parameters and numerical gates are retained byte-for-byte in `proposal.json`; `manifest.toml` duplicates them mechanically and its contract rejects any discrepancy. Native square midpoint meshes16/32/64/128, independent tensor-Gauss orders64/96/128, m=12/16, t4=0,.01,.02,.04,.08,.16,−.04, and both alignments are mandatory. No arm or unsuccessful grid can be removed or replaced after seeing data. There are112 native mesh/field/alignment rows and84 Gaussian rows, representing exactly one journal question.

Use t1=−1,t2=−1.75,t3=−.85, h=0, density2, U=2m and the centered interaction UΣα(nαup−1/2)(nαdown−1/2). The native grid carrier has Ns=1,d=2; all reported energies are per physical cell, summed over both orbitals/spins. The new grid assembly calls the unchanged actual native `bloch_hamiltonian` at every midpoint momentum; it does not replace the native Hamiltonian by an analytic reference formula.

Initial parallel rho0 has both orbital rows[1,0]; antiparallel rho0 is[[1,0],[0,1]]. The actual unchanged `HFCompetition.evaluate(g,rho0,U,n,T;mu0=0)` generates V=U(rho0 with swapped spin columns−.5), calls the actual `solve_fields`, and returns actual V,mu,r.rho,kinetic,entropy,physicalF and other diagnostics. No SCF call is made. Its residual to rho0 is retained and is not required to vanish; neither stationaryF nor the auxiliary band sum is substituted for physicalF.

T=.001 is only a native API carrier for the pure-Slater prescription. Every occupation of every actual eigenvalue must be exactly0or1; every k must have exactly two occupied states, the native density must equal2, entropy must vanish within the original1e−12 gate, and the common chemical potential must be at least1 away from both occupied and empty spectra. This is the declared meaning of the common-mu gap gate. A failure is UNRESOLVED; it never becomes a thermal comparison. The original pre-data global bounds in DERIVATION.md motivate this regime but do not replace the actual qualification.

## New observer before independent interpretation

The native evaluator does not expose its eigenvalue/occupation buffer. An explicitly NEW observer diagonalizes the actual returned V with the actual native Bloch matrices, calls the native Fermi function, and retains every eigenvalue and occupation, native Bloch entries including the imaginary offdiagonal part, the actual mu and both common-gap distances. It reconstructs rho, kinetic, entropy and the physical Wick functional from these occupied states.

The observer MUST first reproduce the actual unmodified evaluator's r.rho and physicalF/kinetic under the fixed proposal gates, before any independent energy is interpreted. This is not a replacement primary solver or a fallback state. The evaluator's actual output remains primary. The direct analytic comparison includes all returned native V entries, all Bloch entries and every auxiliary eigenvalue. Both original source files remain byte-identical and hash-checked before include. The native implementation uses only Julia standard libraries, with primary version1.12.1.

## Independent analytic projectors and Wick functional

The Python reference imports no native code or target result. It independently constructs epsilon_x,epsilon_y and h=−4t4 sin(kx)sin(ky). Set a=(epsilon_x+epsilon_y)/2 and e=(epsilon_x−epsilon_y)/2. Parallel fills both orbital bands of the lower spin block; antiparallel has one occupied projector per spin,

    P_s(k) = [I − (h sigma_x + (e+s*m)sigma_z)/sqrt((e+s*m)^2+h^2)]/2,

with s=−1 for up and+1 for down. Analytic eigenvalues are retained at every native momentum. Momentum-averaged diagonal projectors give the local rho; Tr(PK) gives kinetic energy. The physical trial functional is

    F = average_k sum_s Tr(P_s K) + U sum_alpha(rho_alpha_up−.5)(rho_alpha_down−.5).

The interaction uses the momentum-averaged local densities, not a momentum-wise interaction average. No finite-T entropy, variational fit or auxiliary-band-only energy is inserted. The reference independently qualifies pure occupations and the common gap, rather than assuming that the two lowest bands at every momentum describe an arbitrary doped Fermi sea.

The same closed projectors are integrated on all native midpoint grids for direct API comparisons, and on independent Gauss-Legendre tensor grids for Brillouin-zone convergence. Mapping nodes k=pi*x gives normalized weights w_x*w_y/4. No data-dependent normalization, fitting or quadrature-order selection occurs. Every fixed order is retained.

The reference runtime is Python3.11.11/NumPy2.4.6/SciPy1.17.1. `reference_library_pins.json` extends the independently acquired X14 inventory with the actual SciPy `_orthogonal.py` Gauss-Legendre implementation, linalg decomposition/LAPACK support and native libraries:39 source/native/RECORD hashes, acquired read-only without numerical imports or fixture work. Before calculation it verifies every expected installed file, version, byte count and SHA, then the actual imported roots_legendre and native-module locations. Runtime binaries are never copied.

## Fixed convergence and mechanism gates

All original limits are retained. Native64→128 and Gaussian96→128 must stabilize each orientation's physicalF, kinetic and every rho entry, and each antiparallel-minus-parallel difference. Their limits are respectively1e−7 and1e−9. Final native128 versus Gaussian128 physicalF/kinetic/differences use1e−6 per cell; rho uses1e−10. The direct native-mesh analytic comparison also checks every native eigenvalue under1e−10 and reproduces actual density/entropy and the new observer first.

The zero-t4 alignment energy difference and t4=.04 versus−.04 evenness controls are mandatory. Every nonzero registered arm must exhibit the prescribed negative antiparallel-minus-parallel physical energy difference; none is selected after data.

For each m, the independent leading coefficient is

    C(m) = −average_BZ[ m*(-4sin(kx)sin(ky))^2 / (m^2−e(k)^2) ].

With Q(h)=[DeltaF(h)−DeltaF(0)]/h², the primary Richardson estimate is[4Q(.01)−Q(.02)]/3. The fixed held-out stability estimate is[4Q(.02)−Q(.04)]/3. Both must match the analytic Gaussian integral within1e−6 and agree with each other within1e−6; the held-out result cannot replace the primary. The independent coefficient itself must stabilize at the fixed final Gaussian orders. Arms.08/.16 and sign−.04 remain stress/evenness controls, not additional fit points. There is no adaptive fourth look.

Missing physical qualification, source/grid/runtime failure or unresolved numerical convergence yields UNRESOLVED. Qualified disagreement with the independent functional is FAIL. A complete full pass counts one J23; any excluded pilot counts zero. Every original failed or partial receipt remains preserved in a new output directory, with no automatic retry or gate change.

## Cold/warm pilot and bounded full workflow

The excluded pilot fixes m12,t4=.16, both alignments at N16 andN32. Each mesh runs in a separate fresh Julia process; its first pair of evaluations is the cold batch, followed by a repeated pair with the same grid/input in the warm batch. Warm means runtime/JIT caches only: the evaluator solves the same fields again, without a previous rho as input or a cached scientific result. Full process wall time includes Julia startup and source inclusion; individual grid/cold/warm timings are retained separately. The independent reference includes all three Gaussian orders for this pair, and the pilot comparator qualifies all8 native cold/warm rows against the4 native-grid and6 Gaussian reference rows.

Proposed pilot resources:1CPU3500MB,15-minute allocation,810-second combined inner cap; estimate2–10minutes after start excluding queue. This path is UNMEASURED. Proposed full resources:1CPU3500MB,30-minute allocation,1620-second inner cap. No full runtime prediction is accepted before the actual pilot. Current whole-user queue admission, including unrelated work and at most two running CPUs, remains the parent's separate responsibility.

`assess_pilot.py` replays only saved data; identities, grid, bounds, decisions and statuses remain exact. Only floating gate values admit declared arithmetic replay roundoff max(1e−12,64epsilon*scale), with all changes recorded. No scientific gate changes. The projection uses twice the warm32 pair-plus-grid time scaled by all14(m,t4) pairs and sum(N²)/32², plus twice the larger native cold-process wall. Reference and comparator wall times receive separate2× full/pilot point-count scaling, plus30seconds reserve. The memory projection adds six times projected raw text bytes to the measured maximum process RSS. These are explicit conditional engineering estimates, not guarantees.

Eligibility requires pilot maximum RSS≤2,800,000KiB, projected full RSS≤3,000,000KiB and projected full elapsed≤1500s. Full execution additionally requires an exact source-bound parent review receipt, matching pilot assessment, a fresh live-queue check and separate submission. These scripts never submit jobs, enable automation or admit themselves. Timeouts terminate the process group and retain original logs/status. No source freeze or archive has been created here.
