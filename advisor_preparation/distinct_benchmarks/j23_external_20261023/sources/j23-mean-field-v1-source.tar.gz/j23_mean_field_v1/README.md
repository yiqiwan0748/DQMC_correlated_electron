# J23 mean-field trial functional — preparation only

**UNFROZEN, UNEXECUTED; J23 remains NOT_RUN.** This implements the unchanged reviewed [proposal](proposal.json) and [derivation](DERIVATION.md) using actual native HFCompetition.evaluate/solve_fields and Bloch APIs, with new purity/functional observers and independent analytic projectors plus Wick/Gauss integration.

Every fixed mesh, exchange/hybridization arm, same-density/pure-occupation qualification, physical-energy correction and Richardson/held-out gate is retained. The comparison concerns prescribed n2 Slater trial energies. It makes no SCF, gRISB, doped-ground-state or exact-ground-state claim.

Read [PROTOCOL.md](PROTOCOL.md) and [manifest.toml](manifest.toml). Original sources are copied verbatim. Thirty-nine installed reference API/native/RECORD file hashes identify the actual independent implementation; no binaries are included. The excluded cold/warm16/32-grid pilot and measured full-admission workflow require parent and peer review before any source freeze or job. No source here submits a job or changes the public benchmark count.
