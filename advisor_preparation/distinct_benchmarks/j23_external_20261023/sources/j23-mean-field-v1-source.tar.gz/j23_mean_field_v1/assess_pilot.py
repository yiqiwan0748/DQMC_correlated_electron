#!/usr/bin/env python3
"""Replay only saved data; conditional engineering estimate, no job admission."""
import argparse,math,re,subprocess,sys
from pathlib import Path
from io_contract import HERE,contract,load,sha,write

def replay_equal(a,b,path=(),roundoff=None):
 if roundoff is None:roundoff=[]
 if type(a)!=type(b):raise ValueError('Replay types differ')
 if isinstance(a,dict):
  if a.keys()!=b.keys():raise ValueError('Replay fields differ')
  for k in a:replay_equal(a[k],b[k],path+(k,),roundoff)
 elif isinstance(a,list):
  if len(a)!=len(b):raise ValueError('Replay grids differ')
  for i,(x,y) in enumerate(zip(a,b)):replay_equal(x,y,path+(i,),roundoff)
 elif isinstance(a,float) and path[-1:]==('value',) and 'checks' in path:
  tolerance=max(1e-12,64*sys.float_info.epsilon*max(1.,abs(a),abs(b)))
  if not math.isfinite(a) or not math.isfinite(b) or abs(a-b)>tolerance:raise ValueError('Replay gate arithmetic differs')
  if a!=b:roundoff.append(dict(path=list(path),original=a,replay=b,difference=abs(a-b),tolerance=tolerance))
 elif a!=b:raise ValueError('Replay identity/bound/status differs')
 return roundoff

def main():
 p=argparse.ArgumentParser();p.add_argument('--pilot',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args();c,_=contract();root=a.pilot;a.output_dir.mkdir(parents=True,exist_ok=False);ex=load(root/'execution.json');saved=load(root/'comparison.json');r=c['resources']
 if ex['mode']!='pilot' or ex['status']!='PROCESSES_COMPLETE' or ex['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or [p['name'] for p in ex['processes']]!=['native16','native32','reference','comparator'] or any(p['exit_code'] or p['timed_out'] for p in ex['processes']):raise ValueError('Incomplete excluded pilot')
 for n,row in ex['outputs'].items():
  if sha(root/n)!=row['sha256'] or (root/n).stat().st_size!=row['bytes']:raise ValueError('Pilot output changed')
 replay=a.output_dir/'comparison_replay.json';subprocess.run([sys.executable,'-B',str(HERE/'compare.py'),'--native',str(root/'native16.toml'),str(root/'native32.toml'),'--reference',str(root/'reference.json'),'--output',str(replay)],check=True);fresh=load(replay);differences=replay_equal(saved,fresh)
 if fresh['status']!='PASS' or fresh['catalogue_status']!='NOT_RUN' or fresh['scientific_completions']!=0:raise ValueError('Pilot mathematical gates incomplete')
 n16=load(root/'native16.toml');n32=load(root/'native32.toml');rss=[]
 for p in ex['processes']:
  hit=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',(root/(p['name']+'.resources.txt')).read_text())
  if hit is None:raise ValueError('Native RSS receipt missing')
  rss.append(int(hit[1]))
 times={p['name']:p['elapsed_seconds'] for p in ex['processes']};warm=sum(x['elapsed_seconds'] for x in n32['rows'] if x['phase']=='warm')+n32['grids'][0]['grid_seconds'];parameter_pairs=len(c['m_values'])*len(c['t4_values']);square_factor=sum(N*N for N in c['native_square_mesh'])/32**2
 native_projection=2*parameter_pairs*square_factor*warm+2*max(times['native16'],times['native32'])
 full_native_points=2*parameter_pairs*sum(N*N for N in c['native_square_mesh']);pilot_unique_native_points=2*sum(N*N for N in c['pilot_meshes']);full_ref_points=full_native_points+2*parameter_pairs*sum(N*N for N in c['oracle_gauss_orders']);pilot_ref_points=pilot_unique_native_points+2*sum(N*N for N in c['oracle_gauss_orders'])
 reference_projection=2*full_ref_points/pilot_ref_points*times['reference'];comparator_projection=2*full_native_points/pilot_unique_native_points*times['comparator'];forecast=native_projection+reference_projection+comparator_projection+30
 targetbytes=sum((root/f'native{N}.toml').stat().st_size for N in c['pilot_meshes']);refbytes=(root/'reference.json').stat().st_size;projected_raw=targetbytes*full_native_points/(2*pilot_unique_native_points)+refbytes*full_native_points/pilot_unique_native_points;projected_peak=max(rss)+6*projected_raw/1024
 eligible=max(rss)<=r['max_pilot_rss_KiB'] and projected_peak<=r['max_projected_full_rss_KiB'] and forecast<=r['max_projected_full_seconds']
 write(a.output_dir/'assessment.json',dict(schema='J23_EXCLUDED_PILOT_ENGINEERING_V1',status='ELIGIBLE_FOR_SEPARATE_ROOT_REVIEW' if eligible else 'UNRESOLVED',source_freeze_sha256=sha(HERE/'source_freeze.json'),execution_sha256=sha(root/'execution.json'),comparison_sha256=sha(root/'comparison.json'),pilot_job_id=ex['job_id'],scientific_completions=0,SCF_executed=False,max_pilot_rss_KiB=max(rss),projected_full_peak_rss_KiB=projected_peak,projected_full_seconds=forecast,components_seconds=dict(native=native_projection,reference=reference_projection,comparator=comparator_projection,reserve=30),projection_formula='2*14*sum(N^2)/32^2*(warm32pair+grid)+2max(nativecoldprocesses); independent reference/comparator pointcount-scaled2x; +30s; maxRSS+6xprojectedraw bytes; conditional engineering only',replay_roundoff=differences,input_sha256={p.name:sha(p) for p in root.iterdir() if p.is_file()},separate_root_current_queue_admission_required=True,automatic_submission=False))
if __name__=='__main__':main()
