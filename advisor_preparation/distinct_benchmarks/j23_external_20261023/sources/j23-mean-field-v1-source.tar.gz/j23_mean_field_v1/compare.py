#!/usr/bin/env python3
"""Full fixed J23 functional/purity/convergence/Richardson gates; no SCF execution."""
import argparse,itertools,math,sys
from pathlib import Path
import numpy as np
from io_contract import HERE,contract,library_contract,load,sha,write
class Gates:
 def __init__(self):self.rows=[]
 def check(self,name,value,relation,bound,kind='qualification'):
  ok=value==bound if relation=='eq' else math.isfinite(value) and {'le':lambda:value<=bound,'ge':lambda:value>=bound,'lt':lambda:value<bound}[relation]()
  self.rows.append(dict(name=name,value=value,relation=relation,bound=bound,kind=kind,passed=bool(ok)))
 def error(self,name,x,y,limit,kind='comparison'):
  x=np.asarray(x,float);y=np.asarray(y,float)
  if x.shape!=y.shape or not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):raise ValueError('Incomplete/nonfinite observable grid '+name)
  self.check(name,float(np.max(abs(x-y),initial=0)),'le',limit,kind)
def key(r):return (r['size'],r['m'],r['t4'],r['alignment'])
def target_key(r):return (r['mesh'],r['m'],r['t4'],r['alignment'],r['phase'])
def compare(native,reference,c):
 g=Gates();mode=reference['mode'];lim=c['gates'];params=list(itertools.product([c['pilot_m']] if mode=='pilot' else c['m_values'],[c['pilot_t4']] if mode=='pilot' else c['t4_values'],c['alignments']));meshes=c['pilot_meshes'] if mode=='pilot' else c['native_square_mesh'];phases=c['pilot_phases'] if mode=='pilot' else ['production']
 refs={kind:{key(r):r for r in reference['rows'] if r['grid_kind']==kind} for kind in ['native_mesh','gauss']}
 for kind,sizes in [('native_mesh',meshes),('gauss',c['oracle_gauss_orders'])]:
  expected={(N,m,t4,a) for N in sizes for m,t4,a in params}
  if set(refs[kind])!=expected or len(refs[kind])!=sum(r['grid_kind']==kind for r in reference['rows']):raise ValueError('Incomplete/duplicate fixed referencegrid '+kind)
 rows=[r for doc in native for r in doc['rows']];table={target_key(r):r for r in rows};expected={(N,m,t4,a,phase) for N in meshes for m,t4,a in params for phase in phases}
 if len(rows)!=len(table) or set(table)!=expected:raise ValueError('Incomplete/duplicate fixed actual-native grid')
 for k,r in table.items():
  N,m,t4,align,phase=k;tag=f'N{N}/m{m}/t4{t4}/{align}/{phase}';ref=refs['native_mesh'][N,m,t4,align];actual=r['native_evaluate'];obs=r['observer'];U=2*m;rho0=np.array([[1.,0.],[1.,0.]]) if align=='parallel' else np.array([[1.,0.],[0.,1.]])
  if r['Ns']!=1 or r['d']!=2 or r['nk']!=N*N or r['U']!=U:raise ValueError('Native normalization/field metadata changed')
  g.error(tag+'/actual trial input',r['rho0'],rho0,lim['direct_analytic_eigenvalues_abs'],'qualification');g.error(tag+'/actual native V',actual['V'],U*(rho0[:,[1,0]]-.5),lim['direct_analytic_eigenvalues_abs'],'qualification')
  eig=np.asarray(obs['eigenvalues_by_spin_k_band'],float);f=np.asarray(obs['occupations_by_spin_k_band'],float)
  if eig.shape!=(2,N*N,2) or f.shape!=eig.shape or not np.all(np.isfinite(eig)) or not np.all(np.isfinite(f)):raise ValueError('Missing complete eigenvalue/occupation grid')
  g.check(tag+'/binary pure occupations',bool(np.all((f==0)|(f==1))) and obs['pure_exact_binary_occupations'],'eq',True);g.check(tag+'/two occupied at every k',bool(np.all(np.sum(f,axis=(0,2))==2)) and obs['two_occupied_per_k'],'eq',True);g.error(tag+'/saved occupied count',obs['occupations_per_k'],np.full(N*N,2.),0.,'qualification')
  mu=actual['mu'];gap=min(float(np.min(mu-eig[f==1])),float(np.min(eig[f==0]-mu)));g.check(tag+'/actual common mu gap',gap,'ge',lim['common_mu_gap_min']);g.check(tag+'/saved common mu gap',abs(gap-obs['common_mu_gap_min']),'le',lim['direct_analytic_eigenvalues_abs']);g.check(tag+'/actual density',abs(actual['n']-2),'le',lim['native_density_abs']);g.check(tag+'/actual entropy',abs(actual['entropy']),'le',lim['native_entropy_abs']);g.check(tag+'/observer entropy',abs(obs['entropy']),'le',lim['native_entropy_abs']);g.check(tag+'/eigenpair residual',obs['maximum_eigenpair_residual'],'le',lim['direct_analytic_eigenvalues_abs'])
  # Qualify the new observer against the actual unmodified evaluator first.
  g.error(tag+'/observer reproduces actual rho',obs['rho'],actual['rho'],lim['observer_density_vs_actual_native_rho_abs'],'qualification');g.check(tag+'/observer reproduces actual physicalF',abs(obs['physicalF']-actual['physicalF']),'le',lim['same_mesh_physical_energy_per_cell_abs']);g.check(tag+'/observer reproduces actual kinetic',abs(obs['kinetic']-actual['kinetic']),'le',lim['same_mesh_physical_energy_per_cell_abs'])
  g.error(tag+'/all actual Bloch entries',obs['bloch_entries_by_k'],ref['bloch_entries_by_k'],lim['direct_analytic_eigenvalues_abs']);g.error(tag+'/all analytic AppendixD eigenvalues',eig,ref['eigenvalues_by_spin_k_band'],lim['direct_analytic_eigenvalues_abs']);g.error(tag+'/independent pure occupation prescription',f,ref['occupations_by_spin_k_band'],0.);g.error(tag+'/same mesh actual rho',actual['rho'],ref['rho'],lim['observer_density_vs_actual_native_rho_abs']);
  for field in ['physicalF','kinetic']:g.check(tag+'/same mesh independent physical '+field,abs(actual[field]-ref[field]),'le',lim['same_mesh_physical_energy_per_cell_abs'],'comparison')
 for kind,lookup in refs.items():
  for k,row in lookup.items():
   tag=kind+'/'+str(k);g.check(tag+'/analytic pure-state qualification',row['pure_occupations_qualified'],'eq',True);g.check(tag+'/common gap',row['common_mu_gap_min'],'ge',lim['common_mu_gap_min']);g.check(tag+'/density',abs(row['density']-2),'le',lim['native_density_abs']);g.check(tag+'/integration measure normalization',abs(row['quadrature_weight_sum']-1),'le',lim['native_density_abs'])
 # Pilot is excluded even if the registered worst-field pair passes.
 details=[]
 if mode=='production':
  nat={(N,m,t4,a):r['native_evaluate'] for (N,m,t4,a,phase),r in table.items()}
  def diff(lookup,N,m,t4,field):return np.asarray(lookup[N,m,t4,'antiparallel'][field])-np.asarray(lookup[N,m,t4,'parallel'][field])
  for m,t4 in itertools.product(c['m_values'],c['t4_values']):
   for field in ['physicalF','kinetic','rho']:
    for a in c['alignments']:
     g.error(f'native64to128/m{m}/t4{t4}/{a}/{field}',nat[64,m,t4,a][field],nat[128,m,t4,a][field],lim['final_native_mesh_difference_abs'],'qualification');g.error(f'Gauss96to128/m{m}/t4{t4}/{a}/{field}',refs['gauss'][96,m,t4,a][field],refs['gauss'][128,m,t4,a][field],lim['oracle_quadrature_difference_abs'],'qualification');g.error(f'final independent/m{m}/t4{t4}/{a}/{field}',nat[128,m,t4,a][field],refs['gauss'][128,m,t4,a][field],lim['observer_density_vs_actual_native_rho_abs'] if field=='rho' else lim['native128_vs_oracle128_energy_abs'])
    g.error(f'native delta stability/m{m}/t4{t4}/{field}',diff(nat,64,m,t4,field),diff(nat,128,m,t4,field),lim['final_native_mesh_difference_abs'],'qualification');g.error(f'Gauss delta stability/m{m}/t4{t4}/{field}',diff(refs['gauss'],96,m,t4,field),diff(refs['gauss'],128,m,t4,field),lim['oracle_quadrature_difference_abs'],'qualification');g.error(f'final delta independent/m{m}/t4{t4}/{field}',diff(nat,128,m,t4,field),diff(refs['gauss'],128,m,t4,field),lim['observer_density_vs_actual_native_rho_abs'] if field=='rho' else lim['native128_vs_oracle128_energy_abs'])
  for name,lookup,sizes in [('native',nat,meshes),('Gauss',refs['gauss'],c['oracle_gauss_orders'])]:
   for N,m in itertools.product(sizes,c['m_values']):
    zero=float(diff(lookup,N,m,0.,'physicalF'));g.check(f'{name}{N}/m{m}/zero hybrid alignment',abs(zero),'le',lim['zero_t4_alignment_energy_difference_abs'])
    for a in c['alignments']:g.check(f'{name}{N}/m{m}/{a}/even t4',abs(lookup[N,m,.04,a]['physicalF']-lookup[N,m,-.04,a]['physicalF']),'le',lim['even_t4_energy_abs'])
    for t4 in c['t4_values']:
     if t4:g.check(f'{name}{N}/m{m}/t4{t4}/antiparallel lower physical trial energy',float(diff(lookup,N,m,t4,'physicalF')),'le',lim['nonzero_hybrid_delta_energy_upper'])
  for m in c['m_values']:
   analytic=refs['gauss'][128,m,0.,'parallel']['leading_coefficient'];g.check(f'm{m}/leading coefficient Gauss96to128',abs(analytic-refs['gauss'][96,m,0.,'parallel']['leading_coefficient']),'le',lim['oracle_quadrature_difference_abs'])
   estimates={}
   for backend,lookup in [('native',nat),('Gauss',refs['gauss'])]:
    zero=float(diff(lookup,128,m,0.,'physicalF'));Q=lambda h:(float(diff(lookup,128,m,h,'physicalF'))-zero)/(h*h);R1=(4*Q(.01)-Q(.02))/3;R2=(4*Q(.02)-Q(.04))/3;estimates[backend]=dict(primary=R1,heldout=R2)
    g.check(f'{backend}/m{m}/primary Richardson vs analytic coefficient',abs(R1-analytic),'le',lim['leading_coefficient_abs'],'comparison');g.check(f'{backend}/m{m}/heldout Richardson vs analytic coefficient',abs(R2-analytic),'le',lim['leading_coefficient_abs'],'comparison');g.check(f'{backend}/m{m}/primary vs heldout no selection',abs(R1-R2),'le',lim['Richardson_primary_vs_heldout_abs'],'qualification')
   details.append(dict(m=m,analytic_leading_coefficient=analytic,Richardson=estimates))
 quality=any(not r['passed'] and r['kind']=='qualification' for r in g.rows);failure=any(not r['passed'] for r in g.rows);status='UNRESOLVED' if quality else ('FAIL' if failure else 'PASS')
 return dict(status=status,checks=g.rows,leading_coefficients=details,native_rows=len(table),reference_rows=len(reference['rows']))

def main():
 p=argparse.ArgumentParser();p.add_argument('--native',nargs='+',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();c,source=contract();library_contract();docs=[load(p) for p in a.native];ref=load(a.reference);mode=ref['mode'];out=dict(schema='J23_COMPARISON_V1',catalogue_id='J23',mode=mode,catalogue_status='NOT_RUN',scientific_completions=0)
 try:
  if mode not in ('pilot','production') or ref['schema']!='J23_INDEPENDENT_ANALYTIC_WICK_RAW_V1' or ref['source_sha256']!=source or ref['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or ref['reference_library_sha256']!=load(HERE/'reference_library_pins.json')['files'] or ref['reference_library_pins_sha256']!=sha(HERE/'reference_library_pins.json') or ref['python_version']!=c['python_version'] or ref['versions']!={'numpy':c['numpy_version'],'scipy':c['scipy_version']} or ref['SCF_executed'] or ref['ground_state_claim']:raise ValueError('Wrong reference/source/runtime scope')
  if len(docs)!=(2 if mode=='pilot' else 1):raise ValueError('Wrong source-bound cold/warm execution grid')
  for doc in docs:
   if doc['schema']!='J23_ACTUAL_NATIVE_HF_RAW_V1' or doc['mode']!=mode or doc['source_sha256']!=source or doc['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or doc['native_source_sha256']!=c['native_source_hashes'] or doc['julia_version']!=c['julia_version'] or doc['job_id']!=ref['job_id'] or doc['SCF_executed'] or not doc['trial_state_only'] or doc['Ns']!=1 or doc['d']!=2:raise ValueError('Wrong actual native source/runtime/normalization scope')
  out.update(compare(docs,ref,c));out.update(catalogue_status=out['status'] if mode=='production' else 'NOT_RUN',scientific_completions=int(mode=='production' and out['status']=='PASS'),pilot_excluded=mode=='pilot')
 except Exception as ex:out.update(status='UNRESOLVED',catalogue_status='NOT_RUN' if mode=='pilot' else 'UNRESOLVED',reason=type(ex).__name__+': '+str(ex),checks=[])
 out.update(source_freeze_sha256=sha(HERE/'source_freeze.json'),input_sha256={str(p.name):sha(p) for p in a.native+[a.reference]},scientific_scope='One journal AppendixD prescribed pure-Slater trial functional at n2; actual evaluate/solve_fields+Bloch, analytic projectors/Wick/Gauss; no SCF/gRISB/doped/exact-ground claim')
 write(a.output,out);print(out['status']);raise SystemExit({'PASS':0,'FAIL':1,'UNRESOLVED':2}[out['status']])
if __name__=='__main__':main()
