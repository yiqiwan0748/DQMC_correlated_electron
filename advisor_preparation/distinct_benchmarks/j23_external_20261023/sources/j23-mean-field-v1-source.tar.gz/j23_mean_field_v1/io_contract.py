"""I/O/source/runtime contract only; independent analytic physics lives in oracle.py."""
from pathlib import Path
import hashlib,importlib.metadata,json,platform,os,tomllib
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return tomllib.loads(Path(p).read_text()) if Path(p).suffix=='.toml' else json.loads(Path(p).read_text())
def plain(x):
 import numpy as np
 if isinstance(x,dict):return {str(k):plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [plain(v) for v in x]
 return x.item() if isinstance(x,np.generic) else x

def write(p,x):
 with Path(p).open('x') as f:json.dump(plain(x),f,indent=2,allow_nan=False);f.write('\n')
def contract(compute=False):
 c=load(HERE/'manifest.toml');proposal=load(HERE/'proposal.json')
 if sha(HERE/'proposal.json')!=c['proposal_sha256'] or c['gates']!=proposal['proposed_gates']:raise ValueError('Theory-reviewed proposal/gates changed')
 for key in ['m_values','t4_values','alignments','native_square_mesh','oracle_gauss_orders']:
  if c[key]!=proposal[key]:raise ValueError('Fixed proposal grid changed')
 if not (HERE/'source_freeze.json').is_file():raise ValueError('Unfrozen proposal; no fixture evaluation')
 source={n:h for h,n in (line.split('  ',1) for line in (HERE/'SHA256SUMS').read_text().splitlines())}
 if any(sha(HERE/n)!=h for n,h in source.items()):raise ValueError('Source closure changed')
 if compute and not os.getenv('SLURM_JOB_ID'):raise ValueError('Compute allocation required')
 return c,source

def library_contract():
 spec=load(HERE/'reference_library_pins.json');observed={};locations={}
 if spec['schema']!='J23_NUMPY_SCIPY_CRITICAL_LIBRARY_PINS_V1' or platform.python_version()!=spec['python_version']:raise ValueError('Pinned reference Python required')
 for name,row in spec['distributions'].items():
  d=importlib.metadata.distribution(name)
  if d.version!=row['version'] or not set(row['files'])<={str(x) for x in d.files}:raise ValueError('Pinned reference distribution differs')
  for n in row['files']:
   p=d.locate_file(n).resolve()
   if p.stat().st_size!=spec['bytes'][n]:raise ValueError('Reference size changed')
   observed[n]=sha(p);locations[n]=p
 if observed!=spec['files']:raise ValueError('Reference source/native/RECORD hashes differ before calculation')
 import inspect,numpy,scipy
 from scipy.special import roots_legendre
 for name,path in {'numpy/__init__.py':numpy.__file__,'scipy/__init__.py':scipy.__file__,'scipy/special/_orthogonal.py':inspect.getsourcefile(roots_legendre),'scipy/linalg/__init__.py':importlib.import_module('scipy.linalg').__file__}.items():
  if path is None or Path(path).resolve()!=locations[name]:raise ValueError('Actual imported reference API differs')
 for mod in ['numpy._core._multiarray_umath','scipy.linalg._flapack','scipy.special._ufuncs']:
  if Path(importlib.import_module(mod).__file__).resolve() not in locations.values():raise ValueError('Actual native module not pinned')
 return observed
