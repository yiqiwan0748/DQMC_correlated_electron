#!/usr/bin/env python3
"""Independent closed2x2 projectors/Wick functional and tensor Gauss quadrature."""
import argparse,itertools,platform,time,importlib.metadata
from pathlib import Path
from io_contract import HERE,contract,library_contract,write,sha

def points(kind,size,c):
 import numpy as np
 if kind=='native_mesh':
  x=-np.pi+2*np.pi*(np.arange(size)+c['native_mesh_shift'])/size;w=np.full(size,1/size)
 else:
  from scipy.special import roots_legendre
  x,w=roots_legendre(size);x=np.pi*x;w=w/2
 kx,ky=np.meshgrid(x,x,indexing='ij');weights=np.outer(w,w).ravel()
 return kx.ravel(),ky.ravel(),weights

def analytic(kind,size,m,t4,alignment,c,full_eigenvalues=False):
 import numpy as np
 kx,ky,w=points(kind,size,c);ex=-2*c['t1']*np.cos(kx)-2*c['t2']*np.cos(ky)-4*c['t3']*np.cos(kx)*np.cos(ky);ey=-2*c['t2']*np.cos(kx)-2*c['t1']*np.cos(ky)-4*c['t3']*np.cos(kx)*np.cos(ky);a=(ex+ey)/2;e=(ex-ey)/2;g=-4*np.sin(kx)*np.sin(ky);h=t4*g;rho=np.zeros((2,2));kin=0.;eigs=[];occupations=[];occupied=[];empty=[]
 if alignment=='parallel':
  R=np.hypot(e,h);eigs=[np.stack([a-m-R,a-m+R],axis=1),np.stack([a+m-R,a+m+R],axis=1)];occupations=[np.ones((len(a),2)),np.zeros((len(a),2))];rho[:,0]=np.sum(w);kin=float(np.dot(w,2*a));occupied=[eigs[0].ravel()];empty=[eigs[1].ravel()]
 else:
  for spin,sign in enumerate([-1.,1.]):
   z=e+sign*m;R=np.hypot(z,h);P00=(1-z/R)/2;P11=(1+z/R)/2;rho[:,spin]=[np.dot(w,P00),np.dot(w,P11)];kin+=float(np.dot(w,a-(e*z+h*h)/R));E=np.stack([a-R,a+R],axis=1);eigs.append(E);occupations.append(np.tile([1.,0.],(len(a),1)));occupied.append(E[:,0]);empty.append(E[:,1])
 physicalF=kin+2*m*float(np.sum((rho[:,0]-.5)*(rho[:,1]-.5)));gap=min(-max(np.max(z) for z in occupied),min(np.min(z) for z in empty))
 # Canonical Slater pure-state prescription, not finite-T Fermi approximation.
 qualified=all(np.all(z<0) for z in occupied) and all(np.all(z>0) for z in empty)
 out=dict(grid_kind=kind,size=size,m=m,U=2*m,t4=t4,alignment=alignment,nk=len(a),rho=rho,kinetic=kin,physicalF=physicalF,common_mu_gap_min=float(gap),pure_occupations_qualified=bool(qualified),entropy=0.,density=float(np.sum(rho)),quadrature_weight_sum=float(np.sum(w)),leading_coefficient=float(-np.dot(w,m*g*g/(m*m-e*e))))
 if full_eigenvalues:out.update(eigenvalues_by_spin_k_band=eigs,occupations_by_spin_k_band=occupations,bloch_entries_by_k=np.stack([ex,ey,h,np.zeros_like(h)],axis=1))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('output',type=Path);a=p.parse_args();c,source=contract(compute=True);library=library_contract();start=time.time();rows=[]
 mvals=[c['pilot_m']] if a.mode=='pilot' else c['m_values'];tvals=[c['pilot_t4']] if a.mode=='pilot' else c['t4_values']
 for kind,sizes in [('native_mesh',c['pilot_meshes'] if a.mode=='pilot' else c['native_square_mesh']),('gauss',c['oracle_gauss_orders'])]:
  for size,m,t4,alignment in itertools.product(sizes,mvals,tvals,c['alignments']):rows.append(analytic(kind,size,m,t4,alignment,c,full_eigenvalues=kind=='native_mesh'))
 write(a.output,dict(schema='J23_INDEPENDENT_ANALYTIC_WICK_RAW_V1',mode=a.mode,job_id=__import__('os').environ['SLURM_JOB_ID'],python_version=platform.python_version(),versions={n:importlib.metadata.version(n) for n in ['numpy','scipy']},source_sha256=source,source_freeze_sha256=sha(HERE/'source_freeze.json'),reference_library_pins_sha256=sha(HERE/'reference_library_pins.json'),reference_library_sha256=library,scientific_completions=0,SCF_executed=False,ground_state_claim=False,rows=rows,elapsed_seconds=time.time()-start))
if __name__=='__main__':main()
