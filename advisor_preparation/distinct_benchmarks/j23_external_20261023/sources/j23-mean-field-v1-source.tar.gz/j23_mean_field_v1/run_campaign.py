#!/usr/bin/env python3
"""One capped compute-node campaign; never submits or enables automation."""
import argparse,json,os,signal,subprocess,time
from pathlib import Path
from io_contract import HERE,contract,load,sha,write

def process(name,command,timeout,out):
 started=time.time();timed_out=False
 with (out/(name+'.log')).open('x') as log:
  child=subprocess.Popen(['/usr/bin/time','-v','-o',str(out/(name+'.resources.txt'))]+command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 return dict(name=name,command=command,elapsed_seconds=time.time()-started,started_unix=started,finished_unix=time.time(),exit_code=code,timed_out=timed_out)

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('output',type=Path);p.add_argument('--julia',required=True);p.add_argument('--python',required=True);a=p.parse_args();c,source=contract(compute=True)
 if os.getenv('SLURM_CPUS_PER_TASK')!='1' or os.getenv('SLURM_MEM_PER_NODE')!='3500':raise ValueError('One CPU3500MB allocation required')
 if a.mode=='production':
  approval=Path(os.environ['J23_ROOT_APPROVAL']);assessment=Path(os.environ['J23_PILOT_ASSESSMENT'])
  if sha(approval)!=os.environ['J23_ROOT_APPROVAL_SHA256']:raise ValueError('Root review receipt changed')
  root=load(approval);pilot=load(assessment)
  if root['schema']!='J23_ROOT_REVIEWED_PILOT_ADMISSION_V1' or root['status']!='APPROVED_FOR_SEPARATE_SUBMISSION' or root['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or root['pilot_assessment_sha256']!=sha(assessment):raise ValueError('Separate exact root admission required')
  if pilot['schema']!='J23_EXCLUDED_PILOT_ENGINEERING_V1' or pilot['status']!='ELIGIBLE_FOR_SEPARATE_ROOT_REVIEW' or pilot['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or pilot['scientific_completions']!=0:raise ValueError('Unqualified pilot')
 a.output.mkdir(parents=True,exist_ok=False);start=time.time();deadline=start+c['resources'][a.mode+'_combined_timeout_seconds'];processes=[];error=None
 if a.mode=='pilot':
  native=[a.output/f'native{N}.toml' for N in c['pilot_meshes']];commands=[(f'native{N}',[a.julia,'--startup-file=no','--history-file=no','--threads=1',str(HERE/'target.jl'),'pilot',str(N),str(output)]) for N,output in zip(c['pilot_meshes'],native)]
 else:native=[a.output/'native.toml'];commands=[('native',[a.julia,'--startup-file=no','--history-file=no','--threads=1',str(HERE/'target.jl'),'production','all',str(native[0])])]
 commands += [('reference',[a.python,'-B',str(HERE/'oracle.py'),a.mode,str(a.output/'reference.json')]),('comparator',[a.python,'-B',str(HERE/'compare.py'),'--native']+[str(q) for q in native]+['--reference',str(a.output/'reference.json'),'--output',str(a.output/'comparison.json')])]
 try:
  for name,cmd in commands:
   remaining=deadline-time.time()
   if remaining<=1:raise TimeoutError('Fixed combined wall cap exhausted')
   row=process(name,cmd,remaining,a.output);processes.append(row)
   if row['exit_code'] or row['timed_out']:raise RuntimeError(name+' incomplete; retain all original output, no blind retry')
 except Exception as ex:error=type(ex).__name__+': '+str(ex)
 outputs={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in a.output.iterdir() if p.is_file()}
 write(a.output/'execution.json',dict(schema='J23_EXECUTION_RECEIPT_V1',status='PROCESSES_COMPLETE' if error is None else 'INCOMPLETE',error=error,mode=a.mode,job_id=os.environ['SLURM_JOB_ID'],cpus=1,memory_MB=3500,source_freeze_sha256=sha(HERE/'source_freeze.json'),source_sha256=source,processes=processes,outputs=outputs,started_unix=start,finished_unix=time.time(),scientific_completions=0,SCF_executed=False,submission_by_runner=False))
 if error:raise RuntimeError(error)
if __name__=='__main__':main()
