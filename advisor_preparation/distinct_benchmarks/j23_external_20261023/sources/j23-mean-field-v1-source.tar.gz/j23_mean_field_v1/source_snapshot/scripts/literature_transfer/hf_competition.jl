#!/usr/bin/env julia
module HFCompetition
using LinearAlgebra, Random, Printf, Serialization, Test
export make_grid, solve_fields, evaluate, scf, seed_density, stability_probe,
       rotate_density, translate_density, run_tests, run_screen, run_refine

const HOPPINGS=(-1.0,-1.75,-0.85,-0.65)
const OUT=normpath(joinpath(@__DIR__,"../../results/literature_transfer/hf_competition"))
fermi(x)=x>=0 ? exp(-x)/(1+exp(-x)) : 1/(1+exp(x))
softplus(x)=max(x,0)+log1p(exp(-abs(x)))
idx(x,y,a,Lx)=2*(x+Lx*y)+a

"Periodic supercell Bloch quadrature; theta is the phase across a whole supercell."
function make_grid(Lx::Int,Ly::Int,Nkx::Int,Nky::Int;shift=.5)
    t1,t2,t3,t4=HOPPINGS;d=2Lx*Ly
    matrices=Matrix{ComplexF64}[];thetas=Tuple{Float64,Float64}[]
    for ix in 0:Nkx-1,iy in 0:Nky-1
        tx=-pi+2pi*(ix+shift)/Nkx;ty=-pi+2pi*(iy+shift)/Nky
        K=zeros(ComplexF64,d,d)
        for x in 0:Lx-1,y in 0:Ly-1,a in 1:2,dx in -1:1,dy in -1:1
            dx==0 && dy==0 && continue
            targetx=x+dx;targety=y+dy
            phase=cis(tx*fld(targetx,Lx)+ty*fld(targety,Ly))
            jx=mod(targetx,Lx);jy=mod(targety,Ly)
            if dx==0 || dy==0
                hop=dx!=0 ? -(a==1 ? t1 : t2) : -(a==1 ? t2 : t1)
                K[idx(x,y,a,Lx),idx(jx,jy,a,Lx)]+=hop*phase
            else
                K[idx(x,y,a,Lx),idx(jx,jy,a,Lx)]-=t3*phase
                K[idx(x,y,a,Lx),idx(jx,jy,3-a,Lx)]+=t4*dx*dy*phase
            end
        end
        maximum(abs,K-K')<1e-12 || error("Non-Hermitian kinetic assembly")
        push!(matrices,K);push!(thetas,(tx,ty))
    end
    (Lx=Lx,Ly=Ly,Nkx=Nkx,Nky=Nky,Ns=Lx*Ly,d=d,K=matrices,thetas=thetas)
end

"Diagonalize prescribed onsite spin potentials at fixed total electrons/site n."
function solve_fields(g,V,n,T;mu0=0.0)
    nk=length(g.K);e=zeros(g.d,nk,2);vectors=Array{ComplexF64}(undef,g.d,g.d,nk,2)
    for spin in 1:2,k in 1:nk
        h=copy(g.K[k]);h[diagind(h)].+=V[:,spin]
        s=eigen(Hermitian(h));e[:,k,spin]=s.values;vectors[:,:,k,spin]=s.vectors
    end
    lo=minimum(e)-40T;hi=maximum(e)+40T;mu=clamp(mu0,lo,hi)
    for iteration in 1:100
        total=0.0;deriv=0.0
        for en in e
            f=fermi((en-mu)/T);total+=f;deriv+=f*(1-f)/T
        end
        density=total/(nk*g.Ns);deriv/=nk*g.Ns
        abs(density-n)<2e-13 && break
        if density<n;lo=mu;else;hi=mu;end
        candidate=mu+(n-density)/max(deriv,1e-14)
        mu=lo<candidate<hi ? candidate : (lo+hi)/2
        iteration==100 && error("Chemical potential did not converge")
    end
    rho=zeros(g.d,2);Eband=0.0;entropy=0.0;omega=0.0
    for spin in 1:2,k in 1:nk,b in 1:g.d
        en=e[b,k,spin];f=fermi((en-mu)/T)
        rho[:,spin].+=abs2.(view(vectors,:,b,k,spin))*(f/nk)
        Eband+=en*f/(nk*g.Ns)
        omega-=T*softplus((mu-en)/T)/(nk*g.Ns)
        if 0<f<1;entropy-=(f*log(f)+(1-f)*log1p(-f))/(nk*g.Ns);end
    end
    kinetic=Eband-sum(V.*rho)/g.Ns
    (rho=rho,mu=mu,n=sum(rho)/g.Ns,kinetic=kinetic,entropy=entropy,omega=omega,
     bandF=omega+mu*n)
end

function evaluate(g,rho,U,n,T;mu0=0.0)
    V=U*(rho[:,[2,1]].-.5)
    r=solve_fields(g,V,n,T;mu0=mu0)
    physicalF=r.kinetic+U*sum((r.rho[:,1].-.5).*(r.rho[:,2].-.5))/g.Ns-T*r.entropy
    stationaryF=r.bandF+U*sum(0.25 .- rho[:,1].*rho[:,2])/g.Ns
    merge(r,(physicalF=physicalF,stationaryF=stationaryF,V=V,
              residual=maximum(abs,r.rho-rho)))
end

function project_density(rho,n,Ns)
    lo=-2.0;hi=2.0
    for _ in 1:55
        mid=(lo+hi)/2
        if sum(clamp.(rho.+mid,1e-10,1-1e-10))<n*Ns;lo=mid;else;hi=mid;end
    end
    clamp.(rho.+(lo+hi)/2,1e-10,1-1e-10)
end

"Damped Pulay SCF. Physical free energy is diagnostic, not charge-saddle descent."
function scf(g,rho0,U,n,T;maxiter=650,tol=2e-8,mixing=.22,history=6,verbose=false)
    rho=project_density(copy(rho0),n,g.Ns);xs=Matrix{Float64}[];rs=Matrix{Float64}[]
    trace=NamedTuple[];mu=U*(n-2)/4;bestres=Inf;stall=0;last=nothing;lastinput=copy(rho)
    for it in 1:maxiter
        lastinput=copy(rho)
        r=evaluate(g,rho,U,n,T;mu0=mu);mu=r.mu;last=r;res=r.rho-rho
        push!(trace,(iteration=it,residual=r.residual,F=r.physicalF,mu=mu))
        if r.residual<tol
            return (rho=copy(r.rho),inputrho=copy(rho),converged=true,iterations=it,
                    result=r,trace=trace)
        end
        if r.residual<bestres*.95;bestres=r.residual;stall=0;else;stall+=1;end
        push!(xs,copy(rho));push!(rs,copy(res))
        if length(xs)>history;popfirst!(xs);popfirst!(rs);end
        next=rho+mixing*res
        if length(xs)>=3 && it%4!=0
            m=length(xs);B=zeros(m+1,m+1)
            for i in 1:m,j in 1:m;B[i,j]=dot(rs[i],rs[j]);end
            scale=max(maximum(abs,B),1e-20)
            for i in 1:m;B[i,i]+=scale*1e-9;B[i,m+1]=1;B[m+1,i]=1;end
            rhs=zeros(m+1);rhs[end]=1
            coeff=try B\rhs catch;fill(NaN,m+1) end
            if all(isfinite,coeff) && maximum(abs,coeff[1:m])<12
                next=zeros(size(rho))
                for i in 1:m;next.+=coeff[i]*(xs[i]+mixing*rs[i]);end
            end
        end
        if stall>70
            empty!(xs);empty!(rs);stall=0
            mixing=max(.06,mixing*.7)
        end
        rho=project_density(next,n,g.Ns)
        verbose && it%100==0 && println("  it=",it," residual=",r.residual," F=",r.physicalF)
    end
    (rho=copy(last.rho),inputrho=lastinput,converged=false,iterations=maxiter,
     result=last,trace=trace)
end

function seed_density(g,label,n;seed=1729,noise=0.0)
    rng=MersenneTwister(seed);rho=fill(n/4,g.d,2)
    for x in 0:g.Lx-1,y in 0:g.Ly-1,a in 1:2
        m=if label=="AM";.6*(a==1 ? 1 : -1)
        elseif label=="FM";.6
        elseif label=="mixed";.2+.4*(a==1 ? 1 : -1)
        elseif label=="stripe_x";.6*(-1)^x
        elseif label=="stripe_y";.6*(-1)^y
        elseif label=="Neel";.6*(-1)^(x+y)
        elseif label=="q23pi";.65*cos(2pi*x/3+pi*y)
        elseif label=="qpi23";.65*cos(pi*x+2pi*y/3)
        elseif label=="q23pi_odd";.65*cos(2pi*x/3+pi*y)*(a==1 ? 1 : -1)
        elseif label=="qpi23_odd";.65*cos(pi*x+2pi*y/3)*(a==1 ? 1 : -1)
        elseif startswith(label,"random");.65*(2rand(rng)-1)
        elseif label=="PM";0.0
        else;error("Unknown seed $label");end
        charge=label=="mixed" ? .035*(a==1 ? 1 : -1) : 0.0
        for spin in 1:2
            rho[idx(x,y,a,g.Lx),spin]+=charge/2+(spin==1 ? 1 : -1)*m/2+noise*randn(rng)
        end
    end
    project_density(rho,n,g.Ns)
end

function translate_density(rho,Lx,Ly,dx,dy)
    out=similar(rho)
    for x in 0:Lx-1,y in 0:Ly-1,a in 1:2
        out[idx(mod(x+dx,Lx),mod(y+dy,Ly),a,Lx),:]=rho[idx(x,y,a,Lx),:]
    end
    out
end
function rotate_density(rho,Lx,Ly)
    out=similar(rho)
    for x in 0:Lx-1,y in 0:Ly-1,a in 1:2
        out[idx(mod(-y,Ly),x,3-a,Ly),:]=rho[idx(x,y,a,Lx),:]
    end
    out
end

function signatures(g,rho)
    m=rho[:,1]-rho[:,2];charge=rho[:,1]+rho[:,2]
    modes=NamedTuple[]
    for px in 0:g.Lx-1,py in 0:g.Ly-1,odd in (false,true)
        z=0.0im
        for x in 0:g.Lx-1,y in 0:g.Ly-1,a in 1:2
            z+=m[idx(x,y,a,g.Lx)]*(odd && a==2 ? -1 : 1)*cis(-2pi*(px*x/g.Lx+py*y/g.Ly))/(2g.Ns)
        end
        push!(modes,(px=px,py=py,odd=odd,amplitude=abs(z)))
    end
    sort!(modes,by=x->-x.amplitude)
    (M=sum(m)/(2g.Ns),Delta=sum(m[1:2:end]-m[2:2:end])/(2g.Ns),
     max_m=maximum(abs,m),charge_range=maximum(charge)-minimum(charge),leading=modes[1])
end

"Finite-potential physical-F probes; optional full local canonical response stability."
function stability_probe(g,rho,U,n,T;full=true,step=2e-4)
    base=evaluate(g,rho,U,n,T);V=base.V;d=length(V);chi=zeros(d,d)
    probeF=Float64[]
    for j in 1:(full ? d : min(d,8))
        vp=copy(V);vm=copy(V);vp[j]+=step;vm[j]-=step
        plus=solve_fields(g,vp,n,T;mu0=base.mu);minus=solve_fields(g,vm,n,T;mu0=base.mu)
        chi[:,j]=-(vec(plus.rho)-vec(minus.rho))/(2step)
        for r in (plus,minus)
            F=r.kinetic+U*sum((r.rho[:,1].-.5).*(r.rho[:,2].-.5))/g.Ns-T*r.entropy
            push!(probeF,F-base.physicalF)
        end
    end
    if !full;return (min_deltaF=minimum(probeF),);end
    asym=maximum(abs,chi-chi');eig=eigen(Symmetric((chi+chi')/2))
    sqrtchi=eig.vectors*Diagonal(sqrt.(max.(eig.values,0)))*eig.vectors'
    A=zeros(d,d);half=d÷2
    for i in 1:half;A[i,half+i]=U;A[half+i,i]=U;end
    stability=eigen(Symmetric(I+sqrtchi*A*sqrtchi))
    (min_deltaF=minimum(probeF),chi_asymmetry=asym,chi_min=minimum(eig.values),
     margin=minimum(stability.values),unstable_density_direction=reshape(sqrtchi*stability.vectors[:,1],size(rho)))
end

function run_tests()
    @testset "Periodic supercell HF conventions" begin
        g=make_grid(6,2,2,6)
        t1,t2,t3,t4=HOPPINGS
        for (K,(tx,ty)) in zip(g.K,g.thetas)
            expected=Float64[]
            for ax in 0:5,ay in 0:1
                kx=(tx+2pi*ax)/6;ky=(ty+2pi*ay)/2
                ex=-2t1*cos(kx)-2t2*cos(ky)-4t3*cos(kx)*cos(ky)
                ey=-2t2*cos(kx)-2t1*cos(ky)-4t3*cos(kx)*cos(ky)
                xy=-4t4*sin(kx)*sin(ky)
                append!(expected,eigvals(Symmetric([ex xy;xy ey])))
            end
            @test isapprox(eigvals(Hermitian(K)),sort(expected);atol=2e-12,rtol=2e-12)
        end
        # U=0, fixed n and uniform imposed FM/AM fields versus 1x1 bands.
        for kind in ("AM","FM"),h in (0.0,.35,4.0)
            V=zeros(g.d,2)
            for a in 1:g.d,s in 1:2;V[a,s]=-(s==1 ? 1 : -1)*h*(kind=="AM" && iseven(a) ? -1 : 1);end
            direct=make_grid(1,1,12,12)
            a=solve_fields(g,V,52/36,.05);b=solve_fields(direct,V[1:2,:],52/36,.05)
            @test abs(a.n-52/36)<1e-11
            @test isapprox(a.bandF,b.bandF;atol=2e-11,rtol=2e-11)
            @test isapprox(a.rho[1:2,:],b.rho;atol=2e-11,rtol=2e-11)
        end
        rho=seed_density(g,"random",52/36)
        a=evaluate(g,rho,12.,52/36,.05)
        for b in (evaluate(g,rho[:,[2,1]],12.,52/36,.05),
                  evaluate(g,translate_density(rho,6,2,1,1),12.,52/36,.05),
                  evaluate(make_grid(2,6,6,2),rotate_density(rho,6,2),12.,52/36,.05))
            @test isapprox(a.physicalF,b.physicalF;atol=3e-11,rtol=3e-11)
        end
        r=scf(g,seed_density(g,"AM",52/36),12.,52/36,.05;tol=1e-10)
        @test r.converged
        @test abs(r.result.physicalF-r.result.stationaryF)<1e-9
    end
end

function save_candidate(path,g,label,r,U,n,T)
    mkpath(path)
    serialize(joinpath(path,label*".jls"),(grid=(g.Lx,g.Ly,g.Nkx,g.Nky),label=label,U=U,n=n,T=T,solution=r))
    open(joinpath(path,label*"_trace.csv"),"w") do io
        println(io,"iteration,residual,F,mu")
        for row in r.trace;println(io,join(values(row),","));end
    end
    open(joinpath(path,label*"_density.csv"),"w") do io
        println(io,"x,y,orbital,rho_up,rho_down")
        for x in 0:g.Lx-1,y in 0:g.Ly-1,a in 1:2
            j=idx(x,y,a,g.Lx);println(io,join((x,y,a,r.rho[j,1],r.rho[j,2]),","))
        end
    end
    sig=signatures(g,r.rho)
    println(label," converged=",r.converged," it=",r.iterations," residual=",r.result.residual,
            " F=",r.result.physicalF," M=",sig.M," Delta=",sig.Delta," leading=",sig.leading)
    flush(stdout)
end

function run_screen(;U=12.,n=52/36,T=.05,Lx=6,Ly=2,Nkx=4,Nky=12,tag="primary_screen")
    g=make_grid(Lx,Ly,Nkx,Nky);path=joinpath(OUT,tag);mkpath(path)
    labels=["PM","AM","FM","mixed","stripe_x","stripe_y","Neel",Lx==6 ? "q23pi" : "qpi23",Lx==6 ? "q23pi_odd" : "qpi23_odd","random1","random2"]
    for (i,label) in enumerate(labels)
        file=joinpath(path,label*".jls")
        if isfile(file);println("Checkpoint exists ",file);continue;end
        start=seed_density(g,label,n;seed=1729+i-1,noise=label in ("mixed","random1","random2") ? .02 : 0.)
        r=scf(g,start,U,n,T;maxiter=650)
        save_candidate(path,g,label,r,U,n,T)
    end
end

function run_refine(input::String;Nkx=8,Nky=24,T=nothing,n=nothing,U=nothing,tag="primary_refine",perturb=0.0)
    data=deserialize(input);Lx,Ly,_,_=data.grid
    n=isnothing(n) ? data.n : n;U=isnothing(U) ? data.U : U;T=isnothing(T) ? data.T : T
    g=make_grid(Lx,Ly,Nkx,Nky);rho=copy(data.solution.rho)
    if perturb>0;rho.+=perturb*randn(MersenneTwister(7103),size(rho));end
    r=scf(g,rho,U,n,T;maxiter=1000,tol=3e-9)
    save_candidate(joinpath(OUT,tag),g,data.label,r,U,n,T)
    r
end

function main(args)
    if isempty(args) || args[1]=="test";run_tests()
    elseif args[1]=="screen";run_screen()
    elseif args[1]=="refine";run_refine(args[2])
    else;error("Usage: hf_competition.jl [test|screen|refine checkpoint]");end
end
end # module
if abspath(PROGRAM_FILE)==@__FILE__
    HFCompetition.main(ARGS)
end
