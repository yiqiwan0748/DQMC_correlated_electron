#!/usr/bin/env julia
# Actual HF evaluate/solve_fields and actual Bloch APIs; NEW prescribed-grid/purity observer.
const PROGRAM_ENTRY=time()
using LinearAlgebra,TOML,SHA
BLAS.set_num_threads(1)
const HERE=@__DIR__
const CFG=TOML.parsefile(joinpath(HERE,"manifest.toml"))
sha(p)=bytes2hex(sha256(read(p)))
plain(x)=x
plain(x::AbstractMatrix)=[collect(x[i,:]) for i in axes(x,1)]
plain(x::AbstractVector)=[plain(v) for v in x]
plain(x::AbstractDict)=Dict(k=>plain(v) for (k,v) in x)
function source_map()
    isfile(joinpath(HERE,"source_freeze.json")) || error("Not frozen/reviewed; no fixture evaluation")
    out=Dict{String,String}()
    for line in eachline(joinpath(HERE,"SHA256SUMS"))
        h,n=split(line,"  ";limit=2);sha(joinpath(HERE,n))==h || error("Changed source");out[n]=h
    end
    for (n,h) in CFG["native_source_hashes"];sha(joinpath(HERE,"source_snapshot",n))==h || error("Changed native bytes");end
    out
end
haskey(ENV,"SLURM_JOB_ID") || error("Compute-node execution only")
string(VERSION)==CFG["julia_version"] || error("Pinned Julia required")
const SOURCE=source_map()
include(joinpath(HERE,"source_snapshot/scripts/literature_transfer/hf_competition.jl"))
module NativeBands
include(joinpath(Main.HERE,"source_snapshot/src/noninteracting.jl"))
end
function make_grid(N,t4)
    start=time();p=NativeBands.ModelParameters(CFG["t1"],CFG["t2"],CFG["t3"],t4)
    ks=[(-pi+2pi*(i+CFG["native_mesh_shift"])/N,-pi+2pi*(j+CFG["native_mesh_shift"])/N) for i in 0:N-1 for j in 0:N-1]
    K=[ComplexF64.(NativeBands.bloch_hamiltonian(kx,ky,p)) for (kx,ky) in ks]
    (g=(Lx=1,Ly=1,Nkx=N,Nky=N,Ns=1,d=2,K=K,thetas=ks),elapsed=time()-start)
end
function observer(g,r,U)
    nk=length(g.K);E=zeros(2,nk,2);F=zeros(2,nk,2);rho=zeros(2,2);kin=0.;entropy=0.;residual=0.;pure=true;two_per_k=true;gap_occ=Inf;gap_empty=Inf
    for spin in 1:2,k in 1:nk
        H=copy(g.K[k]);H[diagind(H)].+=r.V[:,spin];s=eigen(Hermitian(H))
        residual=max(residual,maximum(norm(H*s.vectors[:,b]-s.values[b]*s.vectors[:,b]) for b in 1:2))
        for b in 1:2
            en=s.values[b];f=HFCompetition.fermi((en-r.mu)/CFG["T"]);E[b,k,spin]=en;F[b,k,spin]=f;pure &= f==0 || f==1
            if f==1;gap_occ=min(gap_occ,r.mu-en);elseif f==0;gap_empty=min(gap_empty,en-r.mu);end
            rho[:,spin].+=abs2.(s.vectors[:,b])*f/nk
            kin+=real(dot(s.vectors[:,b],g.K[k]*s.vectors[:,b]))*f/nk
            if 0<f<1;entropy-=(f*log(f)+(1-f)*log1p(-f))/nk;end
        end
    end
    per_k=[sum(F[:,k,:]) for k in 1:nk];two_per_k=all(==(2.),per_k)
    physicalF=kin+U*sum((rho[:,1].-.5).*(rho[:,2].-.5))-CFG["T"]*entropy
    Dict("bloch_entries_by_k"=>[[real(K[1,1]),real(K[2,2]),real(K[1,2]),imag(K[1,2])] for K in g.K],"eigenvalues_by_spin_k_band"=>[[collect(E[:,k,s]) for k in 1:nk] for s in 1:2],"occupations_by_spin_k_band"=>[[collect(F[:,k,s]) for k in 1:nk] for s in 1:2],"occupations_per_k"=>per_k,"pure_exact_binary_occupations"=>pure,"two_occupied_per_k"=>two_per_k,"occupied_mu_distance_min"=>gap_occ,"empty_mu_distance_min"=>gap_empty,"common_mu_gap_min"=>min(gap_occ,gap_empty),"rho"=>rho,"kinetic"=>kin,"entropy"=>entropy,"physicalF"=>physicalF,"maximum_eigenpair_residual"=>residual)
end
function evaluate(g,N,m,t4,alignment,phase)
    start=time();rho0=alignment=="parallel" ? [1. 0.;1. 0.] : [1. 0.;0. 1.];U=2m
    r=HFCompetition.evaluate(g,rho0,U,CFG["density"],CFG["T"];mu0=0.0);obs=observer(g,r,U)
    saved=Dict("rho"=>r.rho,"V"=>r.V,"mu"=>r.mu,"n"=>r.n,"kinetic"=>r.kinetic,"entropy"=>r.entropy,"physicalF"=>r.physicalF,"bandF"=>r.bandF,"stationaryF"=>r.stationaryF,"residual_to_input_trial_density"=>r.residual)
    Dict("mesh"=>N,"m"=>m,"U"=>U,"t4"=>t4,"alignment"=>alignment,"phase"=>phase,"Ns"=>g.Ns,"d"=>g.d,"nk"=>length(g.K),"rho0"=>rho0,"native_evaluate"=>saved,"observer"=>obs,"elapsed_seconds"=>time()-start)
end
function main()
    length(ARGS)==3 || error("MODE MESH_OR_all OUTPUT");mode,mesharg,output=ARGS;mode in ("pilot","production") || error("Mode");ispath(output) && error("No overwrite");rows=Dict{String,Any}[];grids=Dict{String,Any}[]
    if mode=="pilot"
        N=parse(Int,mesharg);N in CFG["pilot_meshes"] || error("Fixed pilot mesh")
        t4=CFG["pilot_t4"];built=make_grid(N,t4);push!(grids,Dict("mesh"=>N,"t4"=>t4,"grid_seconds"=>built.elapsed))
        for phase in CFG["pilot_phases"],alignment in CFG["alignments"]
            push!(rows,evaluate(built.g,N,CFG["pilot_m"],t4,alignment,phase))
        end
    else
        mesharg=="all" || error("Full grid cannot be subset")
        for N in CFG["native_square_mesh"],t4 in CFG["t4_values"]
            built=make_grid(N,t4);push!(grids,Dict("mesh"=>N,"t4"=>t4,"grid_seconds"=>built.elapsed))
            for m in CFG["m_values"],alignment in CFG["alignments"];push!(rows,evaluate(built.g,N,m,t4,alignment,"production"));end
        end
    end
    raw=Dict("schema"=>"J23_ACTUAL_NATIVE_HF_RAW_V1","mode"=>mode,"job_id"=>ENV["SLURM_JOB_ID"],"julia_version"=>string(VERSION),"Ns"=>1,"d"=>2,"scientific_completions"=>0,"source_sha256"=>SOURCE,"source_freeze_sha256"=>sha(joinpath(HERE,"source_freeze.json")),"native_source_sha256"=>CFG["native_source_hashes"],"trial_state_only"=>true,"SCF_executed"=>false,"attribution"=>"Actual unchanged HFCompetition.evaluate invokes solve_fields; actual unchanged Bloch builds prescribed midpoint grid. NEW observer re-diagonalizes returned V to qualify actual rho/physicalF and exact binary occupations; no SCF or ground-state claim.","grids"=>grids,"rows"=>rows,"elapsed_since_program_entry"=>time()-PROGRAM_ENTRY)
    open(output,"w") do io;TOML.print(io,plain(raw));end
end
main()
