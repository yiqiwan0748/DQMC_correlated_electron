This is an analysis-only plan for parent review, not a job submission or new scientific run. The original J23 excluded pilot6466377 is complete:8 native rows,10 reference rows,200 PASS gates,0 catalogue completions. Its source archive5b78ce7e... and freeze7b763ad9... remain unchanged. Local original receipts are results/j23_mean_field_pilot_6466377.

Stage only this NEW runner, input_bindings.json and replay.sbatch to a NEW directory, e.g. $R/source/j23_saved_replay_v1. Review their exact hashes before submission. The source-bound runner reads the original source/$RELEASE and results/j23_mean_field_pilot_20261023T1858Z at their existing locations. It verifies all33 original source/result file bytes plus actual Python and39 reference runtime hashes before and after analysis. It never writes the original source/results.

Root alone may submit a separate1CPU3500MB3-minute allocation, afterany:6466533, with150-second inner cap. Use actual $R/quspin-venv/bin/python3.11.11; no local-version or frozen-library guard bypass. Estimate5–40seconds after start, excluding queue, is an analysis-only estimate and not a guarantee. The wrapper NEVER submits, cancels or admits another job. A fresh whole-user queue check remains root's responsibility.

The only child command is the UNCHANGED original source/j23_mean_field_v1/assess_pilot.py with --pilot pointing to the original direct result directory and --output-dir pointing to NEW_OUTPUT/replay. That frozen assessor itself invokes the unchanged frozen comparator on SAVED data. It produces comparison_replay.json and assessment.json under the new replay directory. No Julia/HF source, quadrature oracle, fixture producer, Monte Carlo, new eigenstate or sampling is executed. Output analysis_execution.json retains process wall/exit/timeout, source/raw/runtime before-after hashes and all new-file hashes; GNUtime records actual wall/RSS separately.

The original pilot execution.json and raw values remain intact. An eligible engineering result is only a conditional estimate for separate parent review; this job adds0scientific completions and grants no full admission.

After root retrieves the NEW replay/analysis receipts, run the independently reviewed local stdlib auditor:

    python3 -B audit_j23_pilot.py --raw ORIGINAL_LOCAL_RECEIPTS --replay NEW_LOCAL_REPLAY_DIR/replay --output NEW_IMMUTABLE_AUDIT_DIR

The auditor reconstructs only the saved native grid's closed2x2 projectors/physical Wick energy and independently reproduces the unchanged engineering formula. It requires exact schema/bounds/status and the originally preregistered small gate.value arithmetic tolerance for the frozen replay. No additional job is submitted by that audit.
