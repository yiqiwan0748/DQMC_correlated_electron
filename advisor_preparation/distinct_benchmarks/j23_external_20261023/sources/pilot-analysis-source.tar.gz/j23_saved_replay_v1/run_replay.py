#!/usr/bin/env python3
"""Run only the unchanged frozen saved-data assessor/comparator in an allocation."""
import argparse,hashlib,json,os,platform,signal,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def snapshot(spec):
 result={}
 for role,r in spec.items():
  p=Path(r['remote']);s=p.stat();h=sha(p);z=p.stat()
  if not p.is_file() or p.is_symlink() or (s.st_size,s.st_mtime_ns,s.st_ino)!=(z.st_size,z.st_mtime_ns,z.st_ino) or h!=r['sha256'] or s.st_size!=r['bytes']:raise ValueError('Original source/raw changed: '+role)
  result[role]=dict(sha256=h,bytes=s.st_size,mtime_ns=s.st_mtime_ns,inode=s.st_ino)
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();b=read(HERE/'input_bindings.json')
 if not os.getenv('SLURM_JOB_ID') or os.getenv('SLURM_CPUS_PER_TASK')!='1' or os.getenv('SLURM_MEM_PER_NODE')!='3500':raise ValueError('Separate root-submitted oneCPU3500MB compute allocation required')
 if platform.python_version()!=b['python_version'] or str(Path(sys.executable).resolve())!=b['python_executable_realpath']:raise ValueError('Actual pinned Python3.11.11 required; no version bypass')
 before=snapshot(b['files']);a.output.mkdir(parents=True,exist_ok=False);started=time.time();output=a.output/'replay';script=Path(b['source_root'])/'assess_pilot.py';cmd=[sys.executable,'-B',str(script),'--pilot',b['original_pilot_results'],'--output-dir',str(output)];child=None;code=None;timed_out=False;error=None
 try:
  with (a.output/'process.log').open('x') as log:
   child=subprocess.Popen(['/usr/bin/time','-v','-o',str(a.output/'process.resources.txt'),*cmd],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=child.wait(timeout=150)
   except subprocess.TimeoutExpired:
    timed_out=True;os.killpg(child.pid,signal.SIGTERM)
    try:code=child.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
  if code or timed_out:raise RuntimeError('Unchanged frozen analysis did not complete; preserve original failure')
 except Exception as ex:error=type(ex).__name__+': '+str(ex)
 finally:
  try:after=snapshot(b['files']);unchanged=before==after
  except Exception as ex:after=None;unchanged=False;error=(error or '')+'; remote-after '+type(ex).__name__+': '+str(ex)
  files={str(q.relative_to(a.output)):dict(sha256=sha(q),bytes=q.stat().st_size) for q in sorted(a.output.rglob('*')) if q.is_file()}
  receipt=dict(schema='J23_FROZEN_SAVED_DATA_REPLAY_EXECUTION_V1',status='ANALYSIS_COMPLETE' if error is None and unchanged else 'UNRESOLVED',job_id=os.environ['SLURM_JOB_ID'],original_pilot_job_id=b['original_pilot_job_id'],python_version=platform.python_version(),actual_python=str(Path(sys.executable).resolve()),cpus=1,memory_MB=3500,source_freeze_sha256=b['source_freeze_sha256'],input_bindings_sha256=sha(HERE/'input_bindings.json'),runner_sha256=sha(__file__),unchanged_assessor_sha256=sha(script),original_input_before=before,original_input_after=after,original_inputs_unchanged=unchanged,started_unix=started,finished_unix=time.time(),exit_code=code,timed_out=timed_out,error=error,outputs=files,scientific_completions=0,new_HF_or_quadrature_or_fixture_producer_executed=False,pinned_runtime_bypass=False,full_job_admitted=False)
  with (a.output/'analysis_execution.json').open('x') as out:json.dump(receipt,out,indent=2,allow_nan=False);out.write('\n')
 if error or not unchanged:raise SystemExit(2)
if __name__=='__main__':main()
