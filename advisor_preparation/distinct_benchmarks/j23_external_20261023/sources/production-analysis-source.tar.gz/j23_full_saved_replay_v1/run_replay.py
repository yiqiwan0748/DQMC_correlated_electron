#!/usr/bin/env python3
"""Unchanged frozen comparator on saved full J23 data in a separate allocation."""
import argparse,hashlib,json,os,platform,signal,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
EXPECTED_BINDINGS_SHA256='939c5299a2963348a9e440603d6af9a75341f7014c462ef5c2570b10ce84ec9b'

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as file:
  for block in iter(lambda:file.read(1048576),b''):h.update(block)
 return h.hexdigest()
def snapshot(spec):
 result={}
 for role,row in spec.items():
  p=Path(row['remote']);s=p.stat();h=sha(p);z=p.stat()
  if p.is_symlink() or not p.is_file() or h!=row['sha256'] or s.st_size!=row['bytes'] or (s.st_size,s.st_mtime_ns,s.st_ino)!=(z.st_size,z.st_mtime_ns,z.st_ino):raise ValueError('Original bound input changed:'+role)
  result[role]=dict(sha256=h,bytes=s.st_size,mtime_ns=s.st_mtime_ns,inode=s.st_ino)
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if sha(HERE/'input_bindings.json')!=EXPECTED_BINDINGS_SHA256:raise ValueError('Exact root-reviewed input bindings required')
 b=json.loads((HERE/'input_bindings.json').read_text())
 if not os.getenv('SLURM_JOB_ID','').isdigit() or os.getenv('SLURM_CPUS_PER_TASK')!='1' or os.getenv('SLURM_MEM_PER_NODE')!='3500':raise ValueError('Separate root-submitted1CPU3500MB allocation required')
 if platform.python_version()!=b['python_version'] or str(Path(sys.executable).resolve())!=b['python_executable_realpath']:raise ValueError('Actual pinned Python3.11.11 required,no bypass')
 before=snapshot(b['files']);a.output.mkdir(parents=True,exist_ok=False);started=time.time();child=None;code=None;timed_out=False;error=None
 script=Path(b['source_root'])/'compare.py';full=Path(b['original_full_results']);cmd=[sys.executable,'-B',str(script),'--native',str(full/'native.toml'),'--reference',str(full/'reference.json'),'--output',str(a.output/'comparison_replay.json')]
 try:
  with (a.output/'process.log').open('x') as log:
   child=subprocess.Popen(['/usr/bin/time','-v','-o',str(a.output/'process.resources.txt'),*cmd],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=child.wait(timeout=150)
   except subprocess.TimeoutExpired:
    timed_out=True;os.killpg(child.pid,signal.SIGTERM)
    try:code=child.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
  if code!=0 or timed_out:raise RuntimeError('Unchanged comparator incomplete;preserve original receipt without retry')
 except Exception as problem:error=type(problem).__name__+': '+str(problem)
 finally:
  try:after=snapshot(b['files']);unchanged=before==after
  except Exception as problem:after=None;unchanged=False;error=(error or '')+';after:'+type(problem).__name__+': '+str(problem)
  files={str(q.relative_to(a.output)):dict(sha256=sha(q),bytes=q.stat().st_size) for q in sorted(a.output.rglob('*')) if q.is_file()}
  receipt=dict(schema='J23_FULL_FROZEN_SAVED_COMPARATOR_REPLAY_V1',status='ANALYSIS_COMPLETE' if error is None and unchanged else 'UNRESOLVED',job_id=os.environ['SLURM_JOB_ID'],original_full_job_id=b['original_full_job_id'],python_version=platform.python_version(),actual_python=str(Path(sys.executable).resolve()),cpus=1,memory_MB=3500,original_source_freeze_sha256=b['source_freeze_sha256'],input_bindings_sha256=sha(HERE/'input_bindings.json'),runner_sha256=sha(__file__),unchanged_comparator_sha256=sha(script),original_input_before=before,original_input_after=after,original_inputs_unchanged=unchanged,started_unix=started,finished_unix=time.time(),exit_code=code,timed_out=timed_out,error=error,outputs=files,scientific_completions=0,new_HF_or_quadrature_or_fixture_producer_executed=False,pinned_runtime_bypass=False,full_job_admitted=False)
  with (a.output/'analysis_execution.json').open('x') as out:json.dump(receipt,out,indent=2,allow_nan=False);out.write('\n')
 if error or not unchanged:raise SystemExit(2)
if __name__=='__main__':main()
