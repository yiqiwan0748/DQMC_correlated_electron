# P21 first sampled statistical and timing pilot

**Candidate for independent review. No job has been submitted.** This package is a separately versioned, excluded pilot of the exact P21 question: matched interacting finite-temperature ALF and actual-user unequal-time matrices. It cannot pass P21 or increment the100-ID ledger, whatever the pilot means show. Final sampling, statistical gates and budget require another pre-execution freeze.

The common model is the periodic four-site chain with t1,U2,beta1,centered chemical potential0,dtau0.1 and ten slices, in the full grand-canonical ensemble. Keep each spin, every matrix entry, both GT0/G0T orders, all11 time points and both real/imaginary components:1408 real values. The shared convention has no overall Matsubara minus, no spatial/spin average and no multiplicity factor. `provenance/CORRESPONDENCE.md` documents the already verified continuous-Mz versus discrete-Hirsch identity, VK slice order and contemporaneous moving-cut endpoints. The modified ALF observer is not an official ALF release; both original license/origin notices and original/observer sources are preserved.

`closure.json` pins the existing ISAAC observer binary, its OpenBLAS provider, the9 native ALF observer sources, the original9 ALF sources, actual user source/environment, reviewed kernel observer overlay, unchanged `UserMatrixObserver.jl`, and the successful job6460659 eligibility receipts. The pilot performs no rebuild and changes neither propagation nor proposals/RNG algebra. Binary/runtime libraries remain on ISAAC and are never copied or published by this package.

## Native sampling and burn mapping

This mapping was read directly from the pinned primary sources under `provenance/alf_original`; it is not inferred from variable names:

- `Prog/main.F90:779` starts `NBC=1..NBin`, calls `ham%Init_obs(Ltau)`, executes `NSW=1..NSweep`, then calls `ham%Pr_obs(Ltau)` once per bin.
- With the frozen `Sequential=.T.`, each NSW executes one complete forward sweep and one complete reverse sweep. After rebuilding the zero-time Green function it calls `Tau_m` once for finite-temperature `Ltau=1`.
- `Prog/tau_m_mod.F90:56` traverses the current fixed HS configuration, measuring native GT0/G0T once at each tau0..10. `LOBS_ST/EN` restrict ordinary equal-time measurements; the native unequal-time grid remains complete.
- No warmup precedes this main bin loop. `n_skip` belongs to the analysis namelist and is not treated as native sampler burn-in.
- `parameters.in` fixes NSweep2 and NBin96. Retain all96 raw native bins. Analysis excludes exactly bins1..32, giving64 discarded full forward/reverse cycles, then retains bins33..96:64 bins containing128 measured cycles. This choice is fixed before seeing sampled data.
- The actual user driver burns64 complete forward/reverse cycles, then runs2 such cycles per retained bin. Each cycle is two `Observed.update_replica!` calls. The unchanged observer records only initial tau0 and pre-stabilization forward tau1..10. Each retained bin must therefore contain exactly2 observations at every tau. No dense primary recomputation is present.

The two algorithms use different valid HS representations and different observation locations within their update cycle. They match equilibrium observables, not individual trajectories or acceptance rates. Two fresh fixed chains per backend are recorded in `seeds.json`, separate from startup/proof seeds and excluded from any final production analysis. Native ALF seeds are positive signed32-bit values. Each chain runs in a new directory containing only its fresh `parameters` and `seeds`; `seeds.initial` preserves the input because native ALF may rewrite RNG state at exit. `P21_PROOF_ONLY` is removed from sampled children, leaving the already proved ordinary `Pr_obs_base` dispatch.

## Raw evidence and statistical interpretation

The native parser uses the actual OBS_LEGACY `Print_bin_Vec` grammar:352 complex numerators and a paired sign average per order. It never treats these as sign-divided means. Native `P21_Counts_scal` must contain2 observations at every tau for every raw bin. Conversion multiplies numerator/sign averages by the known count2, making the common receipt contain paired numerator sums, sign sums and counts. User moving-cut denominators remain separate for every tau.

For each of all1408 components, the summary retains both chain estimates, paired delete-one-bin ratio jackknife errors, an adjacent-bin32-bin coarsening check, first/second-half means, split-Rhat and a labeled lag1-bin ESS approximation. Backend errors are descriptive: the larger of between-chain and blocked within-chain errors. The difference and its combined descriptive error are reported without equivalence decisions. Imaginary zeros remain in the grid. A constant observed series is identified explicitly; zero error in a pilot is not a confidence-coverage proof.

Two chains and128 retained cycles per chain cannot establish mixing, rare-event control, production precision or simultaneous1408-component uncertainty. The pilot evaluates no post hoc mean-agreement PASS, no componentwise hypothesis test, no scientific equivalence margin and no ledger promotion. Raw bins, all native burn bins, parameters, initial/final RNG/HS state, logs, process exit/resource receipts and source/runtime hashes are retained. A missing component, wrong count, altered pin, numerical/endpoint failure, nonpositive expected sign or process failure yields PILOT_UNRESOLVED while P21 stays NOT_RUN.

## Resources, execution and review

One CPU,3500MB and a10-minute Slurm wall cap are fixed. Sampled runtime is unmeasured; the preliminary estimate is2–8minutes after start including cold Julia/loading, with queue delay separate. The existing binary is reused after exact hash, dependency-provider and source/proof checks. Individual ALF processes have90-second limits; the two-chain Julia driver has240seconds; the outer execution cap is540seconds. No nested jobs or background scheduling are created.

The candidate deliberately lacks `SHA256SUMS`. After independent review and any fixes, root must write the complete release hash list, an immutable freeze record and a new submission receipt. Execution refuses a missing or incomplete source closure. Before any launch, reconcile the live queue and admit at most two total running one-CPU jobs including unrelated work.

After review/freeze, the Slurm entry point expects `VALIDATION_ROOT` and an absolute `P21_PILOT_RELEASE`. It creates a new result path `results/p21_sampled_pilot_v1_JOBID`; no earlier attempt is overwritten. Actual sampling belongs only on ISAAC compute nodes. Local Python syntax and synthetic receipt checks do not execute science.

The summary can be replayed with the pinned release's Python standard-library script, a fresh output filename and the immutable completed result directory. It reads native bins directly, writes only its explicit output and binds an explicit input whitelist that excludes summaries, caches and replay artifacts. Replay never imports a scientific solver or repeats sampling. A separate independent raw-grid/source/scheduler audit remains necessary before using pilot observations to propose a final resource/statistical protocol.
