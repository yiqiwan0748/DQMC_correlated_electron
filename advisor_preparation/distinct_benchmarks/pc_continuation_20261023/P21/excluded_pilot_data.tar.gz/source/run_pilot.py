#!/usr/bin/env python3
"""Serial sampled P21 pilot on an ISAAC compute node; no nested submissions."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import tomllib

HERE = Path(__file__).resolve().parent


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def preflight(validation, proof):
    cfg = tomllib.loads((HERE / "manifest.toml").read_text())
    closure = json.loads((HERE / "closure.json").read_text())
    # A reviewer must create SHA256SUMS after approving this candidate; absence
    # deliberately prevents running an unfrozen draft.
    sums = HERE / "SHA256SUMS"
    need(sums.is_file(), "Independent review/freeze required: SHA256SUMS missing")
    declared = {}
    for line in sums.read_text().splitlines():
        digest, relative = line.split("  ", 1)
        rel = Path(relative)
        need(not rel.is_absolute() and ".." not in rel.parts and relative not in declared, "Safe unique source-closure member")
        need(sha(HERE / rel) == digest, "Frozen local release member: " + relative)
        declared[relative] = digest
    need({"manifest.toml", "run_pilot.py", "user_sampling.jl", "UserMatrixObserver.jl", "summarize_pilot.py", "parameters.in", "seeds.json", "closure.json", "pilot.sbatch", "README.md"} <= set(declared), "Executable/protocol source closure complete")
    for rel, digest in closure["assets"].items():
        need(sha(HERE / rel) == digest and declared.get(rel) == digest, "Preserved asset closure: " + rel)
    pins = {}
    for rel, digest in closure["remote_proof_pins"].items():
        path = proof / rel
        need(path.is_file() and sha(path) == digest, "Previously proved native/overlay source: " + rel)
        pins[str(path)] = digest
    source = validation / "source/renyi_disjoint_corrected"
    for rel, digest in closure["user_base_pins"].items():
        path = source / rel
        need(sha(path) == digest, "Actual user base pin: " + rel)
        pins[str(path)] = digest
    binary = proof / closure["binary_relative_path"]
    need(sha(binary) == closure["binary_sha256"], "Previously built observer binary")
    provider = Path(closure["provider"]).resolve(strict=True)
    need(sha(provider) == closure["provider_sha256"], "Pinned OpenBLAS provider bytes")
    linked = subprocess.run(["ldd", str(binary)], check=True, capture_output=True, text=True, timeout=20).stdout
    need("not found" not in linked, "All native runtime libraries resolved")
    providers = []
    for line in linked.splitlines():
        if any(name in line for name in ("libopenblas", "libblas", "liblapack")):
            need("=>" in line, "Resolved provider line")
            providers.append(Path(line.split("=>", 1)[1].strip().split()[0]).resolve(strict=True))
    need(providers and all(path == provider for path in providers), "Single pinned BLAS/LAPACK provider")
    alf_proof = json.loads((proof / "alf_adapter_proof.json").read_text())
    user_proof = tomllib.loads((proof / "user_adapter_proof.toml").read_text())
    need(alf_proof["status"] == user_proof["status"] == "ADAPTER_PROOF_PASS_NOT_EXTERNAL_BENCHMARK", "Both original eligibility proofs passed")
    seeds = json.loads((HERE / "seeds.json").read_text())
    need(seeds["namespace"] == cfg["seed_namespace"] and seeds["production_eligible"] is False, "Excluded pilot seeds")
    rows = seeds["chains"]
    need(len(rows) == 4 and {(s["backend"], s["chain"]) for s in rows} == {(b, c) for b in ("alf", "user") for c in (1, 2)}, "Complete seed grid")
    need(len({s["seed"] for s in rows}) == 4 and not {s["seed"] for s in rows} & {20261022, 20261022021}, "No startup/proof seed reuse")
    need(all(0 < s["seed"] < (2 ** 31 if s["backend"] == "alf" else 2 ** 63) for s in rows), "Native seed ranges")
    need(cfg["phase"] == "PILOT_ONLY" and cfg["scientific_completion_allowed"] is False, "Pilot identity")
    receipt = {"schema": "P21_SAMPLED_PILOT_PREFLIGHT_V1", "status": "SOURCE_RUNTIME_AND_PRIOR_PROOFS_VERIFIED",
        "scientific_completions": 0, "release_sha256sums_sha256": sha(sums), "release_files": declared,
        "actual_source_receipt_hashes": pins, "binary": str(binary), "binary_sha256": sha(binary),
        "user_source_root": str(source), "proof_root": str(proof),
        "provider": str(provider), "provider_sha256": sha(provider), "ldd": linked,
        "proof_mode_unset_in_sampled_children": True, "native_seed_namespace": seeds["namespace"],
        "job_id": os.environ["SLURM_JOB_ID"]}
    return cfg, closure, rows, binary, source, receipt


def run_process(name, command, cwd, env, folder, seconds):
    started = time.monotonic()
    resources = folder / (name + ".resources.txt")
    log = folder / (name + ".stdout.log")
    argv = ["timeout", "--signal=TERM", "--kill-after=5s", str(seconds) + "s", "/usr/bin/time", "-v", "-o", str(resources), *map(str, command)]
    with log.open("xb") as handle:
        completed = subprocess.run(argv, cwd=cwd, env=env, stdout=handle, stderr=subprocess.STDOUT, timeout=seconds + 15)
    return {"name": name, "argv": argv, "cwd": str(cwd), "exit_code": completed.returncode,
        "elapsed_seconds": time.monotonic() - started, "timeout_seconds": seconds,
        "resources": str(resources), "stdout": str(log), "proof_mode_present": "P21_PROOF_ONLY" in env}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--validation-root", type=Path, required=True)
    p.add_argument("--proof-root", type=Path)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    need(os.environ.get("SLURM_JOB_ID") and os.environ.get("SLURM_CPUS_PER_TASK") == "1", "Scientific pilot requires a one-CPU Slurm compute allocation")
    need(not os.environ.get("SLURM_JOB_NODELIST", "").startswith("login"), "Compute-node execution only")
    need(not args.output.exists(), "Use a new result directory")
    validation = args.validation_root.resolve(strict=True)
    proof = (args.proof_root or validation / "results/p21_adapter_proof_v5_attempt01").resolve(strict=True)
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=False)
    began = time.monotonic()
    state = {"schema": "P21_SAMPLED_PILOT_EXECUTION_V1", "status": "RUNNING_PILOT_ONLY", "scientific_completions": 0,
        "job_id": os.environ["SLURM_JOB_ID"], "processes": [], "elapsed_seconds": 0.0}
    write(folder / "execution.json", state)
    error = None
    try:
        cfg, closure, rows, binary, source, receipt = preflight(validation, proof)
        write(folder / "preflight.json", receipt)
        env = os.environ.copy()
        env.pop("P21_PROOF_ONLY", None)
        for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "JULIA_NUM_THREADS"):
            env[key] = "1"
        for row in rows:
            if row["backend"] != "alf":
                continue
            chain = folder / ("alf_chain_" + str(row["chain"]))
            chain.mkdir()
            shutil.copyfile(HERE / "parameters.in", chain / "parameters")
            seed_bytes = (str(row["seed"]) + "\n").encode()
            (chain / "seeds").write_bytes(seed_bytes)
            (chain / "seeds.initial").write_bytes(seed_bytes)
            result = run_process("alf_chain_" + str(row["chain"]), [binary], chain, env, folder,
                cfg["resources"]["alf_chain_timeout_seconds"])
            result.update(seed=row["seed"], initial_seed_sha256=sha(chain / "seeds.initial"), parameters_sha256=sha(chain / "parameters"))
            state["processes"].append(result)
            write(folder / "execution.json", state)
            need(result["exit_code"] == 0, "Native sampled process failed: " + result["name"])
        user_seeds = {row["chain"]: row["seed"] for row in rows if row["backend"] == "user"}
        env.update(P21_USER_BASE=str(source), P21_USER_OVERLAY=str(proof / closure["user_overlay_relative_path"]),
            P21_USER_PILOT_OUTPUT=str(folder / "user_sampling.toml"), P21_USER_SEED1=str(user_seeds[1]), P21_USER_SEED2=str(user_seeds[2]),
            JULIA_DEPOT_PATH=str(validation / "depot"))
        command = [validation / "runtime/julia-1.12.1/bin/julia", "--startup-file=no", "--project=" + str(source), HERE / "user_sampling.jl"]
        result = run_process("user_sampling", command, folder, env, folder, cfg["resources"]["user_driver_timeout_seconds"])
        state["processes"].append(result)
        need(result["exit_code"] == 0, "User sampled process failed")
        state["status"] = "PILOT_ONLY_COMPLETE"
    except Exception as exc:
        error = type(exc).__name__ + ": " + str(exc)
        state.update(status="PILOT_EXECUTION_UNRESOLVED", reason=error)
    finally:
        state["elapsed_seconds"] = time.monotonic() - began
        write(folder / "execution.json", state)
    summary = subprocess.run([sys.executable, "-B", str(HERE / "summarize_pilot.py"), "--result-dir", str(folder), "--output", str(folder / "summary.json")], timeout=45)
    if error or summary.returncode:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
