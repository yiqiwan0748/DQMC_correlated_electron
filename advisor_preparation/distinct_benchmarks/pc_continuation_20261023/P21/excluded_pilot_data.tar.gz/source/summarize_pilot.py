#!/usr/bin/env python3
"""Parse paired native bins and describe all1408 pilot components; never P21 PASS."""
import argparse
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import statistics
import tomllib

HERE = Path(__file__).resolve().parent


def need(ok, text):
    if not ok:
        raise ValueError(text)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save_new(path, value):
    with Path(path).open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write("\n")


def read_native_bins(path, width):
    """Pinned OBS_LEGACY Print_bin_Vec grammar; denominator is not divided out."""
    rows = []
    for lineno, line in enumerate(Path(path).read_text().splitlines(), 1):
        tokens = re.findall(r"\(([^()]*)\)", line)
        need(len(tokens) == width, f"{path}:{lineno}: complete vector required")
        need(int(line[:line.index("(")].strip()) == width + 1, "Native width marker")
        values = [complex(*map(float, token.replace("D", "E").replace("d", "e").split(","))) for token in tokens]
        denominator = float(line[line.rfind(")") + 1:].strip().replace("D", "E").replace("d", "e"))
        need(all(math.isfinite(x.real) and math.isfinite(x.imag) for x in values) and math.isfinite(denominator), "Finite native raw bin")
        rows.append((values, denominator))
    return rows


def coords():
    for order in ("GT0", "G0T"):
        for part in ("real", "imag"):
            for tau in range(11):
                for spin in range(2):
                    for i in range(4):
                        for j in range(4):
                            yield order, part, tau, spin, i, j


def vector_index(tau, spin, i, j):
    return (((tau * 2 + spin) * 4 + i) * 4 + j)


def check_bin(row, cfg):
    count = cfg["cycles_per_bin"]
    need(row["counts_by_tau"] == [count] * 11, "Exactly one complete tau traversal per measured cycle")
    den = row["sign_denominator_sums_by_tau"]
    need(len(den) == 11 and all(math.isfinite(x) and abs(x / count - 1) <= cfg["eligibility"]["positive_sign_abs"] for x in den), "Complete positive-sign denominators")
    for order in ("GT0", "G0T"):
        for part in ("real", "imag"):
            values = row[order + "_numerator_" + part + "_sums"]
            need(len(values) == 352 and all(math.isfinite(x) for x in values), "All352 complex-order entries retained")


def parse_alf(folder, cfg, chain, seed):
    paths = {name: folder / (name + "_scal") for name in ("P21_GT0", "P21_G0T", "P21_Counts")}
    gt = read_native_bins(paths["P21_GT0"], 352)
    gz = read_native_bins(paths["P21_G0T"], 352)
    counts = read_native_bins(paths["P21_Counts"], 11)
    need(len(gt) == len(gz) == len(counts) == cfg["alf_NBin"], "All96 native raw bins, including explicit burn bins")
    rows = []
    endpoint_error = 0.0
    for index, ((a, ad), (b, bd), (ct, cd)) in enumerate(zip(gt, gz, counts), 1):
        need(ad == bd and cd == 1.0, "Paired native vector denominators/count divisor")
        need(all(x == cfg["cycles_per_bin"] + 0j for x in ct), "Complete native tau-count vector")
        # Native Print_bin_Vec divides by its N=NSweep. Convert to common sums
        # without losing or independently resampling numerator/sign pairing.
        n = cfg["cycles_per_bin"]
        row = {"native_bin": index, "counts_by_tau": [n] * 11,
               "sign_denominator_sums_by_tau": [ad * n] * 11}
        for label, values in (("GT0", a), ("G0T", b)):
            row[label + "_numerator_real_sums"] = [x.real * n for x in values]
            row[label + "_numerator_imag_sums"] = [x.imag * n for x in values]
        check_bin(row, cfg)
        for spin in range(2):
            for i in range(4):
                for j in range(4):
                    z = vector_index(0, spin, i, j)
                    end = vector_index(10, spin, i, j)
                    identity = float(i == j)
                    endpoint_error = max(endpoint_error, abs(b[z] - (a[z] - identity * ad)),
                        abs(a[end] - (identity * ad - a[z])), abs(b[end] + a[z]))
        if index > cfg["alf_discard_initial_bins"]:
            row["bin"] = index - cfg["alf_discard_initial_bins"]
            rows.append(row)
    need(len(rows) == cfg["retained_bins"], "Exactly64 retained native bins")
    need(endpoint_error <= cfg["eligibility"]["user_endpoint_max_error"], "Native fixed-configuration endpoint identities")
    return {"backend": "alf", "chain": chain, "seed": seed, "status": "PILOT_ONLY_COMPLETE",
        "raw_bins": cfg["alf_NBin"], "discarded_initial_bins": cfg["alf_discard_initial_bins"],
        "retained_bins": len(rows), "bins": rows, "endpoint_max_error": endpoint_error,
        "raw_files": {str(path.resolve()): sha(path) for path in paths.values()}}


def parse_user(path, cfg, seed_rows):
    target = tomllib.loads(path.read_text())
    need(target["status"] == "PILOT_ONLY_COMPLETE" and target["phase"] == "PILOT_ONLY" and target["scientific_completions"] == 0, "Completed user pilot")
    need(target["manifest_sha256"] == sha(HERE / "manifest.toml") and target["driver_sha256"] == sha(HERE / "user_sampling.jl") and
         target["observer_sha256"] == sha(HERE / "UserMatrixObserver.jl"), "Executed user measurement closure")
    need(target["original_kernel_sha256"] == "b72bbbf158381b0f776c1fa259d532b069094c47e361d3490c19ea0f43ada4be" and
         target["observer_kernel_sha256"] == "911a61642b23a4465639c3b3e4c63ff9d7cf05d51da288f3224f1775c0aba891", "User kernel pins")
    need(target["julia_version"] == cfg["julia_version"] and target["jdqmcframework_version"] == cfg["jdqmcframework_version"], "Actual user runtime")
    need(target["julia_threads"] == target["blas_threads"] == 1, "Single-thread runtime")
    expected = {(s["chain"], s["seed"]) for s in seed_rows if s["backend"] == "user"}
    chains = target["chains"]
    need(len(chains) == 2 and {(r["chain"], r["seed"]) for r in chains} == expected, "Both fixed user chains/seeds")
    for chain in chains:
        need(chain["status"] == "PILOT_ONLY_COMPLETE" and chain["burn_cycles"] == cfg["burn_cycles"] and chain["retained_cycles"] == cfg["retained_cycles"], "Frozen user sampling budget")
        need(chain["update_calls"] == 2 * (cfg["burn_cycles"] + cfg["retained_cycles"]), "User full forward/reverse mapping")
        need(len(chain["bins"]) == cfg["retained_bins"] and [r["bin"] for r in chain["bins"]] == list(range(1, 65)), "Complete ordered user bin grid")
        deltas = [chain["cumulative_deltaG_after_burn"]] + [row["cumulative_deltaG"] for row in chain["bins"]]
        need(all(math.isfinite(x) and 0 <= x <= cfg["eligibility"]["user_cumulative_deltaG_max"] for x in deltas) and
             all(x <= y for x, y in zip(deltas, deltas[1:])) and deltas[-1] == chain["cumulative_deltaG"], "Cumulative user numerical stability including burn")
        need(0 <= chain["acceptance"] <= 1, "User acceptance bounds")
        for row in chain["bins"]:
            check_bin(row, cfg)
            need(math.isfinite(row["endpoint_contemporaneous_max_error"]) and row["endpoint_contemporaneous_max_error"] <= cfg["eligibility"]["user_endpoint_max_error"], "Contemporaneous user moving-cut endpoints")
        chain["backend"] = "user"
    return target, chains


def ratio_stat(nums, dens):
    n = len(nums)
    need(n >= 2 and len(dens) == n, "Paired ratio shape")
    sn, sd = sum(nums), sum(dens)
    need(sd > 0 and all(sd - d > 0 for d in dens), "Nonzero full/delete-one sign denominators")
    full = sn / sd
    loo = [(sn - x) / (sd - y) for x, y in zip(nums, dens)]
    average = statistics.mean(loo)
    return {"plug_in": full, "bias_corrected": n * full - (n - 1) * average,
        "standard_error": math.sqrt((n - 1) / n * sum((x - average) ** 2 for x in loo))}


def chain_component(chain, coordinate):
    order, part, tau, spin, i, j = coordinate
    index = vector_index(tau, spin, i, j)
    nums = [row[order + "_numerator_" + part + "_sums"][index] for row in chain["bins"]]
    dens = [row["sign_denominator_sums_by_tau"][tau] for row in chain["bins"]]
    primary = ratio_stat(nums, dens)
    coarse = ratio_stat([sum(nums[k:k + 2]) for k in range(0, 64, 2)], [sum(dens[k:k + 2]) for k in range(0, 64, 2)])
    series = [x / y for x, y in zip(nums, dens)]
    mean = statistics.mean(series)
    variance_sum = sum((x - mean) ** 2 for x in series)
    rho1 = sum((x - mean) * (y - mean) for x, y in zip(series, series[1:])) / variance_sum if variance_sum else 0.0
    ess = min(64.0, max(1.0, 64 * (1 - rho1) / max(1e-12, 1 + rho1)))
    return {**primary, "coarsened32_standard_error": coarse["standard_error"],
        "observed_constant_bins": variance_sum == 0, "lag1_bin_correlation": rho1,
        "lag1_bin_ESS_estimate": ess, "first_half_mean": statistics.mean(series[:32]),
        "second_half_mean": statistics.mean(series[32:]), "series": series}


def backend_component(chains, coordinate):
    values = [chain_component(chain, coordinate) for chain in chains]
    need(len(values) == 2, "Exactly two independent pilot chains")
    estimates = [v["bias_corrected"] for v in values]
    between = statistics.stdev(estimates) / math.sqrt(2)
    within = math.sqrt(sum(max(v["standard_error"], v["coarsened32_standard_error"]) ** 2 for v in values)) / 2
    halves = [series for v in values for series in (v["series"][:32], v["series"][32:])]
    w = statistics.mean(statistics.variance(series) for series in halves)
    between_halves = 32 * statistics.variance(statistics.mean(series) for series in halves)
    rhat = math.sqrt(((31 / 32) * w + between_halves / 32) / w) if w else (1.0 if between_halves == 0 else None)
    for value in values:
        del value["series"]
    return {"mean": statistics.mean(estimates), "between_chain_standard_error": between,
        "within_chain_blocked_standard_error": within, "descriptive_standard_error": max(between, within),
        "split_Rhat": rhat, "lag1_bin_ESS_estimate": sum(v["lag1_bin_ESS_estimate"] for v in values),
        "chains": values}


def summarize(folder):
    cfg = tomllib.loads((HERE / "manifest.toml").read_text())
    seeds = json.loads((HERE / "seeds.json").read_text())
    need(seeds["namespace"] == cfg["seed_namespace"] and seeds["production_eligible"] is False, "Excluded pilot namespace")
    seed_rows = seeds["chains"]
    need(len(seed_rows) == 4 and len({r["seed"] for r in seed_rows}) == 4, "All four independent seeds")
    execution = json.loads((folder / "execution.json").read_text())
    need(execution["status"] == "PILOT_ONLY_COMPLETE" and all(r["exit_code"] == 0 for r in execution["processes"]), "All declared sampled processes completed")
    need(len(execution["processes"]) == 3 and {r["name"] for r in execution["processes"]} == {"alf_chain_1", "alf_chain_2", "user_sampling"}, "All two native chains and the two-chain user driver")
    need(all(r["proof_mode_present"] is False for r in execution["processes"]), "Ordinary sampled mode, not proof dispatch")
    closure = json.loads((HERE / "closure.json").read_text())
    preflight = json.loads((folder / "preflight.json").read_text())
    need(preflight["status"] == "SOURCE_RUNTIME_AND_PRIOR_PROOFS_VERIFIED" and preflight["job_id"] == execution["job_id"], "Actual source/runtime preflight identity")
    need(preflight["binary_sha256"] == closure["binary_sha256"] and preflight["provider_sha256"] == closure["provider_sha256"], "Executed binary/provider pins")
    expected_pins = {str(PurePosixPath(preflight["proof_root"]) / rel): digest for rel, digest in closure["remote_proof_pins"].items()}
    expected_pins.update({str(PurePosixPath(preflight["user_source_root"]) / rel): digest for rel, digest in closure["user_base_pins"].items()})
    need(preflight["actual_source_receipt_hashes"] == expected_pins, "Full actual ALF/user/proof source closure")
    need(preflight["proof_mode_unset_in_sampled_children"] is True, "Sampled preflight mode")
    for rel, digest in preflight["release_files"].items():
        need(sha(HERE / rel) == digest, "Executed pilot source member: " + rel)
    alf = []
    for seed in seed_rows:
        if seed["backend"] == "alf":
            chain = parse_alf(folder / ("alf_chain_" + str(seed["chain"])), cfg, seed["chain"], seed["seed"])
            alf.append(chain)
    target, user = parse_user(folder / "user_sampling.toml", cfg, seed_rows)
    need(target["job_id"] == execution["job_id"], "Matched execution/job receipt")
    result = []
    for coordinate in coords():
        order, part, tau, spin, i, j = coordinate
        left = backend_component(alf, coordinate)
        right = backend_component(user, coordinate)
        difference = right["mean"] - left["mean"]
        combined = math.hypot(left["descriptive_standard_error"], right["descriptive_standard_error"])
        result.append({"order": order, "part": part, "tau_index": tau, "tau": tau * cfg["dtau"],
            "spin": "up" if spin == 0 else "down", "row": i, "column": j, "alf": left, "user": right,
            "user_minus_alf": difference, "combined_descriptive_standard_error": combined,
            "difference_over_descriptive_standard_error": difference / combined if combined else None})
    need(len(result) == 1408, "Complete1408-component summary")
    files = [folder / name for name in ("execution.json", "preflight.json", "user_sampling.toml",
        "user_sampling.resources.txt", "user_sampling.stdout.log", "alf_chain_1.resources.txt", "alf_chain_2.resources.txt",
        "alf_chain_1.stdout.log", "alf_chain_2.stdout.log", "user_sampling.toml.chain1.toml", "user_sampling.toml.chain2.toml")]
    files = [path for path in files if path.is_file()]
    # Explicit deterministic input roles; summaries/caches/replays cannot become
    # raw inputs. All other native files remain retained in their run directories.
    for chain in (1, 2):
        files.extend(folder / f"alf_chain_{chain}" / name for name in
            ("parameters", "seeds.initial", "seeds", "P21_GT0_scal", "P21_G0T_scal", "P21_Counts_scal"))
    return {"schema": cfg["schema"], "phase": "PILOT_ONLY", "catalogue_id": "P21", "catalogue_status": "NOT_RUN",
        "status": "SAMPLED_PILOT_NUMERICALLY_ELIGIBLE", "scientific_completions": 0,
        "production_decision": "REQUIRES_SEPARATE_FINAL_SOURCE_STATISTICAL_AND_BUDGET_FREEZE",
        "manifest_sha256": sha(HERE / "manifest.toml"), "seed_sha256": sha(HERE / "seeds.json"),
        "summary_tool_sha256": sha(__file__), "job_id": execution["job_id"], "real_components_retained": 1408,
        "complex_entries_per_order": 352, "component_ordering": cfg["component_ordering"],
        "chains_per_backend": 2, "retained_bins_per_chain": 64, "cycles_per_bin": 2, "burn_cycles": 64,
        "native_raw_bins_per_chain": 96, "native_discarded_initial_bins": 32,
        "alf_endpoint_max_error": max(chain["endpoint_max_error"] for chain in alf),
        "timing_processes": execution["processes"], "total_orchestrator_seconds": execution["elapsed_seconds"],
        "components": result, "input_sha256": {path.relative_to(folder).as_posix(): sha(path) for path in dict.fromkeys(files)},
        "interpretation": "All1408 real components retained. Means, paired-bin jackknife errors, blocking, split-Rhat and lag1-bin ESS are descriptive timing/precision diagnostics only. No componentwise or simultaneous equivalence test, fit, scientific PASS or production precision claim is evaluated. Two chains do not establish mixing or confidence coverage. Imaginary zeros are retained, not counted as extra ideas or validated uncertainty coverage."}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--result-dir", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    need(not args.output.exists(), "Use a new immutable summary")
    try:
        result = summarize(args.result_dir)
    except Exception as exc:
        result = {"schema": "P21_SAMPLED_TIMING_PILOT_V1", "phase": "PILOT_ONLY", "catalogue_id": "P21",
            "status": "PILOT_UNRESOLVED", "catalogue_status": "NOT_RUN", "scientific_completions": 0,
            "reason": type(exc).__name__ + ": " + str(exc), "summary_tool_sha256": sha(__file__)}
    save_new(args.output, result)
    print(json.dumps({key: result.get(key) for key in ("status", "scientific_completions", "real_components_retained", "reason")}, indent=2))
    if result["status"] != "SAMPLED_PILOT_NUMERICALLY_ELIGIBLE":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
