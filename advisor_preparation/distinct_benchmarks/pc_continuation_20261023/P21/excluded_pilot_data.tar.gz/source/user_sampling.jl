#!/usr/bin/env julia
# Excluded pilot: primary values are the user's maintained buffers, not dense products.
using LinearAlgebra, TOML, SHA, Dates
BLAS.set_num_threads(1)
const HERE=@__DIR__
const CFG=TOML.parsefile(joinpath(HERE,"manifest.toml"))
const BASE=realpath(ENV["P21_USER_BASE"])
const OVERLAY=realpath(ENV["P21_USER_OVERLAY"])
const OUTPUT=ENV["P21_USER_PILOT_OUTPUT"]
const SEED1=parse(Int,ENV["P21_USER_SEED1"])
const SEED2=parse(Int,ENV["P21_USER_SEED2"])
sha(p)=bytes2hex(sha256(read(p)))
CFG["phase"]=="PILOT_ONLY"&&!CFG["scientific_completion_allowed"]||error("Pilot only")
string(VERSION)==CFG["julia_version"]||error("Julia runtime pin")
Threads.nthreads()==1&&BLAS.get_num_threads()==1||error("Single-thread resources required")
ispath(OUTPUT)&&error("Use a new pilot receipt")
sha(joinpath(BASE,"src/dqmc_kernel.jl"))=="b72bbbf158381b0f776c1fa259d532b069094c47e361d3490c19ea0f43ada4be"||error("Original source pin")
sha(joinpath(OVERLAY,"src/dqmc_kernel.jl"))=="911a61642b23a4465639c3b3e4c63ff9d7cf05d51da288f3224f1775c0aba891"||error("Observer overlay pin")
include(joinpath(HERE,"UserMatrixObserver.jl"))
using .UserMatrixObserver
module Observed
include(joinpath(ENV["P21_USER_OVERLAY"],"src/dqmc_kernel.jl"))
end
string(pkgversion(Observed.jdqmcf))==CFG["jdqmcframework_version"]||error("Native JDQMC version pin")

function cycle(r,deltaG,observer=nothing)
    r.fermion_greens_calc_up.forward||error("Cycle must start forward")
    r,deltaG,a1=Observed.update_replica!(r,deltaG;observer=observer)
    !r.fermion_greens_calc_up.forward||error("First call must finish forward traversal")
    r,deltaG,a2=Observed.update_replica!(r,deltaG;observer=observer)
    r.fermion_greens_calc_up.forward||error("Cycle must finish ready for forward traversal")
    r,deltaG,(a1+a2)/2
end

function chain(index,seed)
    began=time()
    r=Observed.initializer(CFG["t"],CFG["U"],CFG["mu_centered"],CFG["beta"],CFG["L"],CFG["dtau"],seed;
        n_stab=CFG["n_stab"],boundary_condition=Symbol(CFG["boundary"]))
    deltaG=0.;acceptance=0.
    for _ in 1:CFG["burn_cycles"]
        r,deltaG,rate=cycle(r,deltaG);acceptance+=rate
    end
    burn_deltaG=deltaG;bins=Dict{String,Any}[]
    for index_bin in 1:CFG["retained_bins"]
        b=MatrixBin(CFG["L"],CFG["Ltau"])
        callback=event->observe!(b,event)
        for _ in 1:CFG["cycles_per_bin"]
            r,deltaG,rate=cycle(r,deltaG,callback);acceptance+=rate
        end
        row=raw_record(b)
        all(==(CFG["cycles_per_bin"]),row["counts_by_tau"])||error("Wrong primary callback counts")
        row["bin"]=index_bin;row["cumulative_deltaG"]=deltaG
        push!(bins,row)
    end
    Dict("chain"=>index,"seed"=>seed,"status"=>"PILOT_ONLY_COMPLETE","bins"=>bins,
        "burn_cycles"=>CFG["burn_cycles"],"retained_cycles"=>CFG["retained_cycles"],
        "update_calls"=>2*(CFG["burn_cycles"]+CFG["retained_cycles"]),
        "cumulative_deltaG_after_burn"=>burn_deltaG,"cumulative_deltaG"=>deltaG,
        "acceptance"=>acceptance/(CFG["burn_cycles"]+CFG["retained_cycles"]),
        "elapsed_seconds"=>time()-began)
end

function main()
    began=time()
    result=Dict{String,Any}("schema"=>CFG["schema"],"phase"=>"PILOT_ONLY","catalogue_id"=>"P21",
        "scientific_completions"=>0,"manifest_sha256"=>sha(joinpath(HERE,"manifest.toml")),
        "driver_sha256"=>sha(@__FILE__),"observer_sha256"=>sha(joinpath(HERE,"UserMatrixObserver.jl")),
        "original_kernel_sha256"=>sha(joinpath(BASE,"src/dqmc_kernel.jl")),
        "observer_kernel_sha256"=>sha(joinpath(OVERLAY,"src/dqmc_kernel.jl")),
        "julia_version"=>string(VERSION),"jdqmcframework_version"=>string(pkgversion(Observed.jdqmcf)),
        "job_id"=>get(ENV,"SLURM_JOB_ID","NONE"),"julia_threads"=>Threads.nthreads(),
        "blas_threads"=>BLAS.get_num_threads(),"created_utc"=>string(now(UTC)))
    # Save after each whole chain so a timeout preserves the first completed chain.
    result["chains"]=Dict{String,Any}[]
    for (i,seed) in enumerate((SEED1,SEED2))
        push!(result["chains"],chain(i,seed))
        part=OUTPUT*".chain$(i).toml"
        ispath(part)&&error("Partial receipt already exists")
        open(part,"w")do io;TOML.print(io,result);end
    end
    result["status"]="PILOT_ONLY_COMPLETE";result["elapsed_seconds"]=time()-began
    open(OUTPUT,"w")do io;TOML.print(io,result);end
end
main()
