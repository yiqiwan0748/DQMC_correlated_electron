#!/usr/bin/env python3
"""Pure raw-receipt arithmetic for the frozen one-look full-grid P21 comparison."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import tomllib

from mixing_diagnostics import diagnose, blocking_check, DISCLOSURE
from receipt_io import need, sha, coords, vector_index, parse_alf, parse_user, verify_execution, input_files

HERE = Path(__file__).resolve().parent


def save_new(path, value):
    with Path(path).open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write("\n")


def t7_cdf(value):
    """Student7 exact elementary integral after x=sqrt(7)*tan(theta)."""
    z = math.atan(value / math.sqrt(7))
    integral = z
    for n in (2, 4, 6):
        integral = math.sin(z) * math.cos(z) ** (n - 1) / n + (n - 1) / n * integral
    return 0.5 + 16 / (5 * math.pi) * integral


def ratio_stat(nums, dens):
    n = len(nums)
    need(n >= 2 and len(dens) == n, "Paired jackknife input grid")
    sn, sd = math.fsum(nums), math.fsum(dens)
    need(sd > 0 and all(sd - d > 0 for d in dens), "Positive full/delete-one phase denominators")
    full = sn / sd
    loo = [(sn - x) / (sd - y) for x, y in zip(nums, dens)]
    center = math.fsum(loo) / n
    return {"full_ratio": full, "delete_one_mean": center,
        "jackknife_bias_corrected": n * full - (n - 1) * center,
        "standard_error": math.sqrt((n - 1) / n * math.fsum((x - center) ** 2 for x in loo))}


def component_chain(chain, coordinate, cfg):
    order, part, tau, spin, i, j = coordinate
    k = vector_index(tau, spin, i, j)
    nums = [row[order + "_numerator_" + part + "_sums"][k] for row in chain["bins"]]
    dens = [row["sign_denominator_sums_by_tau"][tau] for row in chain["bins"]]
    fine = ratio_stat(nums, dens)
    coarse = ratio_stat([math.fsum(nums[a:a + 2]) for a in range(0, 64, 2)], [math.fsum(dens[a:a + 2]) for a in range(0, 64, 2)])
    series = [x / y for x, y in zip(nums, dens)]
    structural = part == "imag"
    blocking = {"eligible": True, "status": "SOURCE_BOUND_STRUCTURAL_ZERO", "relative_change": None,
        "issues": [], "se64": fine["standard_error"], "se32": coarse["standard_error"]} if structural else blocking_check(
            fine["standard_error"], coarse["standard_error"], cfg["eligibility"]["blocking_error_relative_change_max"])
    return {"chain": chain["chain"], "seed": chain["seed"], **fine,
        "coarsened32_standard_error": coarse["standard_error"],
        "observed_constant_bins": min(series) == max(series), "blocking": blocking}, series


def real_interval(pair_differences, critical, structural=False):
    need(len(pair_differences) == 8 and all(math.isfinite(x) for x in pair_differences), "Eight independent finite whole-grid differences")
    mean = math.fsum(pair_differences) / 8
    se = statistics.stdev(pair_differences) / math.sqrt(8)
    hw = critical * se
    issues = []
    if structural:
        need(all(x == 0 for x in pair_differences) and mean == se == hw == 0, "Exact structural zero interval")
    elif se == 0:
        issues.append("ZERO_BETWEEN_PAIR_VARIANCE_NONSTRUCTURAL_COMPONENT")
    return {"pair_differences": pair_differences, "mean": mean, "standard_error": se,
        "half_width": hw, "lower": mean - hw, "upper": mean + hw,
        "structural_zero": structural, "eligible": not issues, "issues": issues}


def complex_gate(real, imag, margin, precision):
    hw = math.hypot(real["half_width"], imag["half_width"])
    far = math.hypot(abs(real["mean"]) + real["half_width"], abs(imag["mean"]) + imag["half_width"])
    near = math.hypot(max(0.0, abs(real["mean"]) - real["half_width"]), max(0.0, abs(imag["mean"]) - imag["half_width"]))
    return {"half_radius": hw, "farthest_rectangle_corner_norm": far,
        "nearest_rectangle_point_norm": near, "precision_met": hw <= precision,
        "rectangle_inside_equivalence_disk": far <= margin,
        "rectangle_wholly_outside_equivalence_disk": near > margin}


def scientific_status(eligible, complex_results):
    if not eligible or not all(row["precision_met"] for row in complex_results):
        return "UNRESOLVED"
    if all(row["rectangle_inside_equivalence_disk"] for row in complex_results):
        return "PASS_CANDIDATE_REQUIRES_INDEPENDENT_AUDIT"
    if any(row["rectangle_wholly_outside_equivalence_disk"] for row in complex_results):
        return "FAIL_CANDIDATE_REQUIRES_INDEPENDENT_AUDIT"
    return "UNRESOLVED"


def summarize(folder):
    cfg = tomllib.loads((HERE / "manifest.toml").read_text())
    seeds = json.loads((HERE / "seeds.json").read_text())
    closure = json.loads((HERE / "closure.json").read_text())
    need(cfg["phase"] == "PRODUCTION_SINGLE_LOOK" and cfg["statistics"]["looks"] == 1, "Frozen one-look protocol")
    need(seeds["namespace"] == cfg["seed_namespace"] and seeds["production_eligible"] is True, "Fresh production namespace")
    seed_rows = seeds["chains"]
    need(len(seed_rows) == 16 and len({s["seed"] for s in seed_rows}) == 16 and
         {(s["backend"], s["chain"]) for s in seed_rows} == {(b, c) for b in ("alf", "user") for c in range(1, 9)}, "Full fixed seed grid")
    need(not {s["seed"] for s in seed_rows} & set(seeds["excluded_prior_seeds"]), "Pilot/proof/startup seeds excluded")
    critical = cfg["statistics"]["student_critical"]
    need(cfg["statistics"]["student_df"] == 7 and cfg["statistics"]["real_intervals"] == 1408 and
         abs(t7_cdf(critical) - (1 - cfg["statistics"]["family_alpha"] / (2 * 1408))) <= 16 * math.ulp(1.0), "Student7/Bonferroni critical formula")
    execution, preflight = verify_execution(folder, cfg, seeds, closure)
    raw_files = input_files(folder)
    input_hashes = {p.relative_to(folder).as_posix(): sha(p) for p in raw_files}
    alf = [parse_alf(folder / f"alf_chain_{s['chain']}", cfg, s["chain"], s["seed"]) for s in
           sorted((s for s in seed_rows if s["backend"] == "alf"), key=lambda s: s["chain"])]
    target, user = parse_user(folder / "user_sampling.toml", cfg, seed_rows)
    need(target["job_id"] == execution["job_id"] and target["scientific_soft_stop_epoch"] == execution["soft_stop_epoch"], "User execution/deadline binding")
    components = []
    indexed = {}
    issues = []
    for coordinate in coords():
        order, part, tau, spin, i, j = coordinate
        structural = part == "imag"
        row = {"order": order, "part": part, "tau_index": tau, "tau": tau * cfg["dtau"],
            "spin": "up" if spin == 0 else "down", "row": i, "column": j}
        eligible = True
        estimates = {}
        for backend, chains in (("alf", alf), ("user", user)):
            values, series = zip(*(component_chain(chain, coordinate, cfg) for chain in chains))
            values = list(values)
            if structural:
                diagnostic = {"eligible": True, "status": "SOURCE_BOUND_STRUCTURAL_ZERO",
                    "issues": [], "rhat": None, "ess_total": None, "ess_per_chain": [],
                    "coverage_basis": "Pinned real per-configuration operator theorem AND raw exact-zero test; not constant-bin diagnostics"}
            else:
                diagnostic = diagnose(series, rhat_max=cfg["eligibility"]["rhat_max"],
                    ess_min_per_chain=cfg["eligibility"]["ess_min_per_chain"], ess_min_total=cfg["eligibility"]["ess_min_total"])
            good = diagnostic["eligible"] and all(v["blocking"]["eligible"] for v in values)
            row[backend] = {"chains": values, "mean": math.fsum(v["full_ratio"] for v in values) / 8,
                "mixing": diagnostic, "eligible": good}
            eligible &= good
            estimates[backend] = [v["full_ratio"] for v in values]
        interval = real_interval([r - l for l, r in zip(estimates["alf"], estimates["user"])], critical, structural)
        row["difference_interval"] = interval
        row["eligible"] = eligible and interval["eligible"]
        if not row["eligible"]:
            issues.append({"real_component": len(components), "coordinate": rowcopy(row), "reason": "MIXING_BLOCKING_OR_PAIR_VARIANCE_GATE"})
        indexed[coordinate] = row
        components.append(row)
    complex_results = []
    for order in ("GT0", "G0T"):
        for tau in range(11):
            for spin in range(2):
                for i in range(4):
                    for j in range(4):
                        r, im = (indexed[(order, part, tau, spin, i, j)]["difference_interval"] for part in ("real", "imag"))
                        gate = complex_gate(r, im, cfg["statistics"]["complex_equivalence_margin"], cfg["statistics"]["complex_precision_half_radius"])
                        complex_results.append({"order": order, "tau_index": tau, "tau": tau * cfg["dtau"],
                            "spin": "up" if spin == 0 else "down", "row": i, "column": j, **gate})
    need(len(components) == 1408 and len(complex_results) == 704, "Complete unfiltered real and complex grids")
    eligible = not issues
    status = scientific_status(eligible, complex_results)
    # The frozen comparator itself is pure. Independent replay/audit is separate.
    need(input_hashes == {p.relative_to(folder).as_posix(): sha(p) for p in raw_files}, "Raw inputs unchanged during comparison")
    return {"schema": cfg["schema"], "phase": cfg["phase"], "catalogue_id": "P21", "status": status,
        "catalogue_status": "UNRESOLVED", "scientific_completions": 0,
        "independent_audit_required_before_catalogue_change": True, "receipt_integrity": "RAW_PARSING_AND_SOURCE_CHECKS_COMPLETE_NOT_INDEPENDENT_AUDIT",
        "manifest_sha256": sha(HERE / "manifest.toml"), "seed_sha256": sha(HERE / "seeds.json"),
        "comparison_tool_sha256": sha(__file__), "receipt_io_sha256": sha(HERE / "receipt_io.py"),
        "mixing_tool_sha256": sha(HERE / "mixing_diagnostics.py"), "job_id": execution["job_id"],
        "one_prespecified_look": True, "real_components_retained": 1408, "complex_entries_per_order": 352,
        "component_ordering": cfg["component_ordering"], "chains_per_backend": 8, "retained_bins_per_chain": 64,
        "cycles_per_bin": 1024, "burn_cycles": 4096, "retained_cycles": 65536, "native_raw_bins_per_chain": 68,
        "native_discarded_initial_bins": 4, "student_df": 7, "family_alpha": .01,
        "bonferroni_real_interval_count": 1408, "student_critical": critical,
        "complex_equivalence_margin": .02, "complex_precision_half_radius_max": .01,
        "structural_imaginary": {"components": 704, "all_raw_numerators_exact_zero_including_burn": True,
            "theorem_and_source_binding": "README.md plus closure.json and fixed native/user proofs; real Hamiltonian and per-configuration matrices",
            "multiplicity_reduced": False, "sample_constancy_used_as_coverage_proof": False},
        "numerically_eligible": True, "mixing_blocking_and_pair_variance_eligible": eligible,
        "all_complex_precision_met": all(r["precision_met"] for r in complex_results),
        "all_complex_rectangles_inside_margin": all(r["rectangle_inside_equivalence_disk"] for r in complex_results),
        "any_complex_rectangle_wholly_outside_margin": any(r["rectangle_wholly_outside_equivalence_disk"] for r in complex_results),
        "issues": issues, "components": components, "complex_grid": complex_results,
        "alf_endpoint_max_error": max(c["endpoint_max_error"] for c in alf),
        "alf_native_labelled_precision": [{"chain": c["chain"], **c["native_labelled_precision"]} for c in alf],
        "timing_processes": execution["processes"], "user_chain_elapsed_seconds": [c["elapsed_seconds"] for c in user],
        "total_orchestrator_seconds": execution["elapsed_seconds"], "input_sha256": input_hashes,
        "coverage_limitations": "Nominal extreme-tail Student calibration assumes approximately normal stationary independent chain estimates. Finite Rhat/ESS/blocking and4096-cycle burn do not prove equilibrium or that calibration; Monte Carlo error never bounds time-step or implementation bias. Fixed finite-dtau question only.",
        "mixing_disclosure": DISCLOSURE, "pilot_data_in_production_estimators": False}


def rowcopy(row):
    return {key: row[key] for key in ("order", "part", "tau_index", "spin", "row", "column")}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--result-dir", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    need(not args.output.exists(), "Use a new immutable comparison output")
    try:
        result = summarize(args.result_dir.resolve(strict=True))
    except Exception as exc:
        result = {"schema": "P21_SAMPLED_PRODUCTION_V1", "phase": "PRODUCTION_SINGLE_LOOK", "catalogue_id": "P21",
            "status": "UNRESOLVED", "catalogue_status": "UNRESOLVED", "scientific_completions": 0,
            "receipt_integrity": "UNRESOLVED", "reason": type(exc).__name__ + ": " + str(exc),
            "comparison_tool_sha256": sha(__file__)}
    save_new(args.output, result)
    print(json.dumps({key: result.get(key) for key in ("status", "scientific_completions", "real_components_retained", "reason")}, indent=2))
    # A scientifically unresolved result is a successful, reviewable comparison.
    if result.get("receipt_integrity") == "UNRESOLVED":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
