#!/usr/bin/env python3
"""Strict native/user raw reconstruction for the fixed P21 final protocol."""
import hashlib
from datetime import datetime
import json
import math
from pathlib import Path, PurePosixPath
import re
import tomllib

HERE = Path(__file__).resolve().parent
ORDERS = ("GT0", "G0T")
PARTS = ("real", "imag")


def need(ok, text):
    if not ok:
        raise ValueError(text)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def vector_index(tau, spin, i, j):
    return (((tau * 2 + spin) * 4 + i) * 4 + j)


def coords():
    for order in ORDERS:
        for part in PARTS:
            for tau in range(11):
                for spin in range(2):
                    for i in range(4):
                        for j in range(4):
                            yield order, part, tau, spin, i, j


def read_native_bins(path, width):
    rows = []
    for lineno, line in enumerate(Path(path).read_text().splitlines(), 1):
        tokens = re.findall(r"\(([^()]*)\)", line)
        need(len(tokens) == width, f"{path}:{lineno}: complete vector")
        need(int(line[:line.index("(")].strip()) == width + 1, "Native vector width marker")
        values = [complex(*map(float, token.replace("D", "E").replace("d", "e").split(","))) for token in tokens]
        denominator = float(line[line.rfind(")") + 1:].strip().replace("D", "E").replace("d", "e"))
        need(all(math.isfinite(x.real) and math.isfinite(x.imag) for x in values) and math.isfinite(denominator), "Finite native raw values")
        rows.append((values, denominator))
    return rows


def check_bin(row, cfg):
    count = cfg["cycles_per_bin"]
    need(row["counts_by_tau"] == [count] * 11 and all(type(x) is int for x in row["counts_by_tau"]), "Exact complete tau callback counts")
    den = row["sign_denominator_sums_by_tau"]
    need(len(den) == 11 and all(finite(x) and abs(x / count - 1) <= cfg["eligibility"]["positive_sign_abs"] for x in den), "Complete positive sign denominators")
    for order in ORDERS:
        for part in PARTS:
            values = row[order + "_numerator_" + part + "_sums"]
            need(len(values) == 352 and all(finite(x) for x in values), "Full352 complex entries per order")
            if part == "imag":
                need(all(x == 0 for x in values), "Structural-zero eligibility requires EXACT zero raw imaginary numerators, including burn")


def native_precision(path, cfg):
    text = path.read_text()
    patterns = {
        "green": (r"Precision Green\s+Mean, Max\s*:\s*(\S+)\s+(\S+)", "native_green_max"),
        "tau": (r"Precision tau\s+Mean, Max\s*:\s*(\S+)\s+(\S+)", "native_tau_max"),
        "phase": (r"Precision Phase, Max\s*:\s*(\S+)", "native_phase_max"),
    }
    result = {}
    for name, (pattern, gate) in patterns.items():
        matches = re.findall(pattern, text)
        need(len(matches) == 1, "Exactly one final native labelled precision diagnostic: " + name)
        vals = matches[0] if isinstance(matches[0], tuple) else (matches[0],)
        values = [float(x.replace("D", "E").replace("d", "e")) for x in vals]
        need(all(math.isfinite(x) and 0 <= x <= cfg["eligibility"][gate] for x in values), "Native labelled numerical rejection gate: " + name)
        result[name] = {"mean": values[0] if len(values) == 2 else None, "max": values[-1]}
    need("FIN TIME:" in text and "f4c500cc" in text, "Native complete-run/version receipt")
    for label, value in (("Sweeps", cfg["alf_NSweep"]), ("Bins", cfg["alf_NBin"])):
        match = re.findall(label + r"\s*:\s*(\d+)", text)
        need(match == [str(value)], "Native actual " + label + " budget")
    return result


def parse_alf(folder, cfg, chain, seed):
    need(sha(folder / "parameters") == sha(HERE / "parameters.in"), "Frozen native parameters executed")
    need((folder / "seeds.initial").read_bytes() == (str(seed) + "\n").encode(), "Fresh native seed initial bytes")
    gt = read_native_bins(folder / "P21_GT0_scal", 352)
    gz = read_native_bins(folder / "P21_G0T_scal", 352)
    counts = read_native_bins(folder / "P21_Counts_scal", 11)
    need(len(gt) == len(gz) == len(counts) == cfg["alf_NBin"], "All68 raw native bins including burn")
    retained, burn = [], []
    endpoint = 0.0
    for raw, ((a, ad), (b, bd), (ct, cd)) in enumerate(zip(gt, gz, counts), 1):
        n = cfg["cycles_per_bin"]
        need(ad == bd and cd == 1.0, "Paired native vector denominator/count print divisor")
        need(all(x == n + 0j for x in ct), "Exact raw native counts at all11 tau")
        row = {"raw_bin": raw, "chain": chain, "seed": seed,
            "role": "BURN_EXCLUDED" if raw <= cfg["burn_bins"] else "RETAINED",
            "bin": raw if raw <= cfg["burn_bins"] else raw - cfg["burn_bins"],
            "counts_by_tau": [n] * 11, "sign_denominator_sums_by_tau": [ad * n] * 11}
        # OBS_LEGACY Print_bin_Vec divides numerator AND phase by N=NSweep,
        # but never divides numerator by phase. Reconstruct the paired sums.
        for label, values in (("GT0", a), ("G0T", b)):
            row[label + "_numerator_real_sums"] = [x.real * n for x in values]
            row[label + "_numerator_imag_sums"] = [x.imag * n for x in values]
        check_bin(row, cfg)
        for spin in range(2):
            for i in range(4):
                for j in range(4):
                    z, end, identity = vector_index(0, spin, i, j), vector_index(10, spin, i, j), float(i == j)
                    endpoint = max(endpoint, abs(b[z] - (a[z] - identity * ad)),
                        abs(a[end] - (identity * ad - a[z])), abs(b[end] + a[z]))
        (burn if raw <= cfg["burn_bins"] else retained).append(row)
    need(len(burn) == 4 and len(retained) == 64, "Complete native burn/retained mapping")
    need(endpoint <= cfg["eligibility"]["user_endpoint_max_error"], "Native full-grid endpoint identities")
    info = native_precision(folder / "info", cfg)
    need(re.findall(r"No initial configuration, Seed_in\s+(\d+)", (folder / "info").read_text()) == [str(seed)], "Native fresh configuration and actual input seed")
    return {"backend": "alf", "chain": chain, "seed": seed, "bins": retained, "burn_bins": burn,
        "endpoint_max_error": endpoint, "native_labelled_precision": info}


def parse_user(path, cfg, seed_rows):
    target = tomllib.loads(path.read_text())
    need(target["status"] == "SAMPLED_PRODUCTION_COMPLETE" and target["phase"] == cfg["phase"] and target["scientific_completions"] == 0, "Complete raw production receipt, no automatic completion")
    for key, file in (("manifest_sha256", "manifest.toml"), ("driver_sha256", "user_sampling.jl"), ("observer_sha256", "UserMatrixObserver.jl")):
        need(target[key] == sha(HERE / file), "Executed user source: " + key)
    need(target["original_kernel_sha256"] == "b72bbbf158381b0f776c1fa259d532b069094c47e361d3490c19ea0f43ada4be" and
        target["observer_kernel_sha256"] == "911a61642b23a4465639c3b3e4c63ff9d7cf05d51da288f3224f1775c0aba891", "User kernel pins")
    need(target["julia_version"] == cfg["julia_version"] and target["jdqmcframework_version"] == cfg["jdqmcframework_version"], "Actual user runtime")
    need(target["julia_threads"] == target["blas_threads"] == 1, "Single-thread user runtime")
    expected = {(s["chain"], s["seed"]) for s in seed_rows if s["backend"] == "user"}
    chains = target["chains"]
    need(len(chains) == 8 and {(r["chain"], r["seed"]) for r in chains} == expected, "All eight fixed user chain/seeds")
    need([r["chain"] for r in chains] == list(range(1, 9)), "Fixed chain order")
    for chain in chains:
        need(chain["status"] == "SAMPLED_CHAIN_COMPLETE" and chain["burn_cycles"] == 4096 and chain["retained_cycles"] == 65536, "User budget")
        need(chain["update_calls"] == 2 * (cfg["burn_cycles"] + cfg["retained_cycles"]), "Full forward/reverse cycle mapping")
        rows = chain["burn_bins"] + chain["bins"]
        need(len(chain["burn_bins"]) == 4 and len(chain["bins"]) == 64 and [r["raw_bin"] for r in rows] == list(range(1, 69)), "All user raw burn and retained bins in order")
        deltas = [row["cumulative_deltaG"] for row in rows]
        need(all(finite(x) and 0 <= x <= cfg["eligibility"]["user_cumulative_deltaG_max"] for x in deltas) and all(x <= y for x, y in zip(deltas, deltas[1:])), "Cumulative numerical error incl burn")
        need(deltas[3] == chain["cumulative_deltaG_after_burn"] and deltas[-1] == chain["cumulative_deltaG"], "Burn/final cumulative numerical receipt")
        need(finite(chain["acceptance"]) and 0 <= chain["acceptance"] <= 1 and finite(chain["elapsed_seconds"]) and chain["elapsed_seconds"] > 0, "User acceptance/timing")
        partial = tomllib.loads(Path(str(path) + f".chain{chain['chain']}.toml").read_text())
        need(partial == chain, "Independent immutable per-chain raw receipt")
        for raw, row in enumerate(rows, 1):
            need(row["chain"] == chain["chain"] and row["seed"] == chain["seed"], "Per-bin chain/seed")
            need(row["role"] == ("BURN_EXCLUDED" if raw <= 4 else "RETAINED") and row["bin"] == (raw if raw <= 4 else raw - 4), "Explicit burn role")
            need(row["ordering"] == "tau-major,spin(up,down),row_i,column_j; all indices zero-based externally" and
                row["primary_stage"] == "initial(tau0) and pre_stabilization(tau1..M)" and
                row["measurement_origin"] == "actual user maintained buffers; no dense recomputation", "Actual primary callback provenance")
            check_bin(row, cfg)
            need(finite(row["endpoint_contemporaneous_max_error"]) and 0 <= row["endpoint_contemporaneous_max_error"] <= cfg["eligibility"]["user_endpoint_max_error"], "Contemporaneous endpoint numerical gate")
            binfile = Path(str(path) + ".bins") / f"chain{chain['chain']}_rawbin{raw:03}.toml"
            need(tomllib.loads(binfile.read_text()) == row, "Immutable per-bin raw receipt")
        chain["backend"] = "user"
    return target, chains


def verify_execution(folder, cfg, seeds, closure):
    execution = json.loads((folder / "execution.json").read_text())
    need(execution["status"] == "SAMPLED_PRODUCTION_COMPLETE" and execution["one_prespecified_look"] is True, "Complete single-look execution")
    processes = execution["processes"]
    names = [f"alf_chain_{i}" for i in range(1, 9)] + ["user_sampling"]
    need([r["name"] for r in processes] == names, "Exactly eight native processes and one eight-chain user process")
    need(all(r["exit_code"] == 0 and r["timed_out"] is False and r["proof_mode_present"] is False for r in processes), "Ordinary complete sampled processes")
    for row in processes:
        need(all(finite(row[k]) for k in ("started_epoch", "ended_epoch", "soft_stop_epoch")) and row["started_epoch"] < row["ended_epoch"] <= execution["hard_stop_epoch"], "All scientific process ends before hard cutoff")
        need(row["soft_stop_epoch"] == execution["soft_stop_epoch"] and row["timeout_seconds"] > 0, "Fixed child deadline")
    need(all(a["ended_epoch"] <= b["started_epoch"] for a, b in zip(processes, processes[1:])), "Serial scientific processes")
    need(execution["hard_stop_epoch"] <= execution["scientific_cutoff_epoch"] and execution["hard_stop_epoch"] == execution["actual_batch_start_epoch"] + 7200 and execution["soft_stop_epoch"] == execution["hard_stop_epoch"] - 5, "Fixed actual-start deadline closure")
    need(execution["scientific_cutoff_epoch"] == datetime.fromisoformat(cfg["resources"]["scientific_cutoff_utc"].replace("Z", "+00:00")).timestamp(), "Frozen whole-science UTC cutoff")
    preflight = json.loads((folder / "preflight.json").read_text())
    need(preflight["status"] == "SOURCE_RUNTIME_AND_PRIOR_PROOFS_VERIFIED" and preflight["job_id"] == execution["job_id"], "Source/runtime preflight identity")
    need(preflight["binary_sha256"] == closure["binary_sha256"] and preflight["provider_sha256"] == closure["provider_sha256"], "Executed binary/provider pins")
    expected = {str(PurePosixPath(preflight["proof_root"]) / rel): digest for rel, digest in closure["remote_proof_pins"].items()}
    expected.update({str(PurePosixPath(preflight["user_source_root"]) / rel): digest for rel, digest in closure["user_base_pins"].items()})
    need(preflight["actual_source_receipt_hashes"] == expected and preflight["proof_mode_unset_in_sampled_children"] is True, "Actual native/proof/user closure")
    sums = {}
    for line in (HERE / "SHA256SUMS").read_text().splitlines():
        digest, relative = line.split("  ", 1)
        need(relative not in sums and sha(HERE / relative) == digest, "Immutable release source " + relative)
        sums[relative] = digest
    need(preflight["release_files"] == sums and preflight["release_sha256sums_sha256"] == sha(HERE / "SHA256SUMS"), "Actual frozen source execution receipt")
    freeze = json.loads((HERE / "source_freeze.json").read_text())
    need(freeze["files"] == dict(sums, SHA256SUMS=sha(HERE / "SHA256SUMS")) and preflight["source_freeze_sha256"] == sha(HERE / "source_freeze.json"), "Externally pinned administrative freeze/source inventory binding")
    for rel, digest in closure["assets"].items():
        need(sums.get(rel) == digest, "Preserved proof/license/planning asset pin")
    for name in ("alf_adapter_proof.json", "user_adapter_proof.toml"):
        p = HERE / "provenance" / name
        receipt = json.loads(p.read_text()) if p.suffix == ".json" else tomllib.loads(p.read_text())
        need(receipt["status"] == "ADAPTER_PROOF_PASS_NOT_EXTERNAL_BENCHMARK", "Original observer eligibility proof")
    return execution, preflight


def input_files(folder):
    """Explicit raw roles only; prior outputs/replays never become inputs."""
    files = [folder / name for name in ("execution.json", "preflight.json", "user_sampling.toml", "user_sampling.resources.txt", "user_sampling.stdout.log")]
    for chain in range(1, 9):
        files.extend(folder / f"alf_chain_{chain}" / name for name in ("parameters", "seeds.initial", "seeds", "info", "P21_GT0_scal", "P21_G0T_scal", "P21_Counts_scal"))
        files.extend(folder / f"alf_chain_{chain}{suffix}" for suffix in (".resources.txt", ".stdout.log"))
        files.append(folder / f"user_sampling.toml.chain{chain}.toml")
        files.extend(folder / "user_sampling.toml.bins" / f"chain{chain}_rawbin{raw:03}.toml" for raw in range(1, 69))
    need(all(p.is_file() for p in files) and len(set(files)) == len(files), "Complete unique explicit input whitelist")
    return files
