#!/usr/bin/env python3
"""Fixed serial P21 production on an ISAAC compute allocation; no submissions."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import tomllib

HERE = Path(__file__).resolve().parent
ACTIVE = None


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def preflight(validation, proof):
    cfg = tomllib.loads((HERE / "manifest.toml").read_text())
    closure = json.loads((HERE / "closure.json").read_text())
    sums = HERE / "SHA256SUMS"
    need(sums.is_file(), "Independent review/freeze required: SHA256SUMS missing")
    declared = {}
    for line in sums.read_text().splitlines():
        digest, relative = line.split("  ", 1)
        rel = Path(relative)
        need(not rel.is_absolute() and ".." not in rel.parts and relative not in declared, "Safe unique source member")
        need(sha(HERE / rel) == digest, "Frozen release: " + relative)
        declared[relative] = digest
    actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob("*") if p.is_file() and p.relative_to(HERE).as_posix() not in {"SHA256SUMS", "source_freeze.json"}}
    need(set(declared) == actual, "Complete frozen release inventory, no additional executables")
    administrative_freeze = HERE / "source_freeze.json"
    need(administrative_freeze.is_file(), "Root must stage the externally pinned administrative freeze record")
    freeze = json.loads(administrative_freeze.read_text())
    need(freeze["files"] == dict(declared, SHA256SUMS=sha(sums)), "Administrative freeze binds the full scientific inventory and checksum bytes")
    need({"manifest.toml", "run_production.py", "user_sampling.jl", "UserMatrixObserver.jl", "receipt_io.py",
          "compare_production.py", "mixing_diagnostics.py", "parameters.in", "seeds.json", "closure.json",
          "production.sbatch", "README.md"} <= set(declared), "Executable/protocol source closure complete")
    for rel, digest in closure["assets"].items():
        need(sha(HERE / rel) == digest and declared.get(rel) == digest, "Preserved asset: " + rel)
    pins = {}
    for rel, digest in closure["remote_proof_pins"].items():
        path = proof / rel
        need(path.is_file() and sha(path) == digest, "Proved native/overlay source: " + rel)
        pins[str(path)] = digest
    source = validation / "source/renyi_disjoint_corrected"
    for rel, digest in closure["user_base_pins"].items():
        path = source / rel
        need(sha(path) == digest, "Actual user base: " + rel)
        pins[str(path)] = digest
    binary = proof / closure["binary_relative_path"]
    need(sha(binary) == closure["binary_sha256"], "Previously proved observer binary")
    provider = Path(closure["provider"]).resolve(strict=True)
    need(sha(provider) == closure["provider_sha256"], "Pinned OpenBLAS provider bytes")
    linked = subprocess.run(["ldd", str(binary)], check=True, capture_output=True, text=True, timeout=20).stdout
    need("not found" not in linked, "All native runtime libraries resolved")
    providers = []
    for line in linked.splitlines():
        if any(name in line for name in ("libopenblas", "libblas", "liblapack")):
            need("=>" in line, "Resolved provider line")
            providers.append(Path(line.split("=>", 1)[1].strip().split()[0]).resolve(strict=True))
    need(providers and all(path == provider for path in providers), "Single pinned BLAS/LAPACK provider")
    alf_proof = json.loads((proof / "alf_adapter_proof.json").read_text())
    user_proof = tomllib.loads((proof / "user_adapter_proof.toml").read_text())
    need(alf_proof["status"] == user_proof["status"] == "ADAPTER_PROOF_PASS_NOT_EXTERNAL_BENCHMARK", "Original eligibility proofs")
    seeds = json.loads((HERE / "seeds.json").read_text())
    need(seeds["namespace"] == cfg["seed_namespace"] and seeds["production_eligible"] is True, "Production seed namespace")
    rows = seeds["chains"]
    need(len(rows) == 16 and {(s["backend"], s["chain"]) for s in rows} == {(b, c) for b in ("alf", "user") for c in range(1, 9)}, "Complete seed grid")
    need(len({s["seed"] for s in rows}) == 16 and not {s["seed"] for s in rows} & set(seeds["excluded_prior_seeds"]), "No prior seed reuse")
    need(all(0 < s["seed"] < (2 ** 31 if s["backend"] == "alf" else 2 ** 63) for s in rows), "Native seed ranges")
    need(cfg["phase"] == "PRODUCTION_SINGLE_LOOK" and cfg["statistics"]["looks"] == 1, "Single production look")
    receipt = {"schema": "P21_PRODUCTION_PREFLIGHT_V1", "status": "SOURCE_RUNTIME_AND_PRIOR_PROOFS_VERIFIED",
        "scientific_completions": 0, "release_sha256sums_sha256": sha(sums), "release_files": declared,
        "actual_source_receipt_hashes": pins, "binary": str(binary), "binary_sha256": sha(binary),
        "user_source_root": str(source), "proof_root": str(proof), "provider": str(provider),
        "provider_sha256": sha(provider), "ldd": linked, "proof_mode_unset_in_sampled_children": True,
        "native_seed_namespace": seeds["namespace"], "job_id": os.environ["SLURM_JOB_ID"],
        "source_freeze_sha256": sha(administrative_freeze)}
    return cfg, closure, rows, binary, source, receipt


def terminate(process):
    """One owned process group; TERM then KILL within the outer five-second grace."""
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        pass
    # Kill the group even if /usr/bin/time exited before a descendant.
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=1)


def run_process(name, command, cwd, env, folder, seconds, soft_stop):
    global ACTIVE
    remaining = math.floor(soft_stop - time.time())
    need(remaining > 0, "No scientific time remaining")
    limit = min(seconds, remaining)
    began = time.monotonic()
    started = time.time()
    resources = folder / (name + ".resources.txt")
    log = folder / (name + ".stdout.log")
    argv = ["/usr/bin/time", "-v", "-o", str(resources), *map(str, command)]
    code = None
    timed_out = False
    try:
        with log.open("xb") as handle:
            ACTIVE = subprocess.Popen(argv, cwd=cwd, env=env, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = ACTIVE.wait(timeout=limit)
            except subprocess.TimeoutExpired:
                timed_out = True
                terminate(ACTIVE)
                code = 124
    finally:
        if ACTIVE is not None and ACTIVE.poll() is None:
            terminate(ACTIVE)
        ACTIVE = None
    return {"name": name, "argv": argv, "cwd": str(cwd), "exit_code": code,
        "elapsed_seconds": time.monotonic() - began, "timeout_seconds": limit, "timed_out": timed_out,
        "started_epoch": started, "ended_epoch": time.time(), "soft_stop_epoch": soft_stop,
        "resources": str(resources), "stdout": str(log), "proof_mode_present": "P21_PROOF_ONLY" in env}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--validation-root", type=Path, required=True)
    p.add_argument("--proof-root", type=Path)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    need(os.environ.get("SLURM_JOB_ID") and os.environ.get("SLURM_CPUS_PER_TASK") == "1", "One-CPU Slurm compute allocation required")
    need(not os.environ.get("SLURM_JOB_NODELIST", "").startswith("login"), "Compute-node execution only")
    cfg0 = tomllib.loads((HERE / "manifest.toml").read_text())
    batch_start = float(os.environ["P21_BATCH_START_EPOCH"])
    need(math.isfinite(batch_start) and 0 <= time.time() - batch_start < 300, "Actual first-line batch start receipt")
    cutoff = datetime.fromisoformat(cfg0["resources"]["scientific_cutoff_utc"].replace("Z", "+00:00")).timestamp()
    cap = cfg0["resources"]["overall_timeout_seconds"]
    need(cutoff - batch_start >= cap, "Late-start admission rejected before science; full fixed allocation must fit")
    hard_stop = min(batch_start + cap, cutoff)
    soft_stop = hard_stop - cfg0["resources"]["kill_grace_seconds"]
    need(not args.output.exists(), "Use a new result directory")
    validation = args.validation_root.resolve(strict=True)
    proof = (args.proof_root or validation / "results/p21_adapter_proof_v5_attempt01").resolve(strict=True)
    folder = args.output.resolve()
    folder.mkdir(parents=True, exist_ok=False)
    began = time.monotonic()
    state = {"schema": "P21_PRODUCTION_EXECUTION_V1", "status": "RUNNING_PRODUCTION", "scientific_completions": 0,
        "job_id": os.environ["SLURM_JOB_ID"], "processes": [], "elapsed_seconds": 0.0,
        "actual_batch_start_epoch": batch_start, "scientific_cutoff_epoch": cutoff, "hard_stop_epoch": hard_stop,
        "soft_stop_epoch": soft_stop, "allocated_seconds": cap, "one_prespecified_look": True}
    write(folder / "execution.json", state)
    error = None
    def on_term(signum, frame):
        raise TimeoutError("Outer fixed scientific deadline signal")
    signal.signal(signal.SIGTERM, on_term)
    try:
        cfg, closure, rows, binary, source, receipt = preflight(validation, proof)
        write(folder / "preflight.json", receipt)
        env = os.environ.copy()
        env.pop("P21_PROOF_ONLY", None)
        for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "JULIA_NUM_THREADS"):
            env[key] = "1"
        for row in sorted((s for s in rows if s["backend"] == "alf"), key=lambda s: s["chain"]):
            chain = folder / ("alf_chain_" + str(row["chain"]))
            chain.mkdir()
            shutil.copyfile(HERE / "parameters.in", chain / "parameters")
            seed_bytes = (str(row["seed"]) + "\n").encode()
            (chain / "seeds").write_bytes(seed_bytes)
            (chain / "seeds.initial").write_bytes(seed_bytes)
            result = run_process("alf_chain_" + str(row["chain"]), [binary], chain, env, folder,
                cfg["resources"]["alf_chain_timeout_seconds"], soft_stop)
            result.update(seed=row["seed"], initial_seed_sha256=sha(chain / "seeds.initial"), parameters_sha256=sha(chain / "parameters"))
            state["processes"].append(result)
            write(folder / "execution.json", state)
            need(result["exit_code"] == 0, "Native sampled process failed: " + result["name"])
        user_seeds = [s["seed"] for s in sorted((s for s in rows if s["backend"] == "user"), key=lambda s: s["chain"])]
        env.update(P21_USER_BASE=str(source), P21_USER_OVERLAY=str(proof / closure["user_overlay_relative_path"]),
            P21_USER_OUTPUT=str(folder / "user_sampling.toml"), P21_USER_SEEDS=",".join(map(str, user_seeds)),
            P21_SOFT_STOP_EPOCH=str(soft_stop), JULIA_DEPOT_PATH=str(validation / "depot"))
        command = [validation / "runtime/julia-1.12.1/bin/julia", "--startup-file=no", "--project=" + str(source), HERE / "user_sampling.jl"]
        result = run_process("user_sampling", command, folder, env, folder, cfg["resources"]["user_driver_timeout_seconds"], soft_stop)
        state["processes"].append(result)
        need(result["exit_code"] == 0, "User sampled process failed")
        state["status"] = "SAMPLED_PRODUCTION_COMPLETE"
    except Exception as exc:
        error = type(exc).__name__ + ": " + str(exc)
        state.update(status="PRODUCTION_EXECUTION_UNRESOLVED", reason=error)
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        terminate(ACTIVE)
        state["elapsed_seconds"] = time.monotonic() - began
        state["finished_epoch"] = time.time()
        write(folder / "execution.json", state)
    # No sampling below this point. Comparison is pure receipt arithmetic.
    summary = subprocess.run([sys.executable, "-B", str(HERE / "compare_production.py"), "--result-dir", str(folder),
        "--output", str(folder / "comparison.json")], timeout=180)
    if error or summary.returncode:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
