#!/usr/bin/env julia
# Primary values are actual maintained buffers; the observer is read-only.
using LinearAlgebra, TOML, SHA, Dates
BLAS.set_num_threads(1)
const HERE=@__DIR__
const CFG=TOML.parsefile(joinpath(HERE,"manifest.toml"))
const BASE=realpath(ENV["P21_USER_BASE"])
const OVERLAY=realpath(ENV["P21_USER_OVERLAY"])
const OUTPUT=ENV["P21_USER_OUTPUT"]
const RAWROOT=OUTPUT*".bins"
const SEEDS=parse.(Int,split(ENV["P21_USER_SEEDS"],","))
const CUTOFF=parse(Float64,ENV["P21_SOFT_STOP_EPOCH"])
sha(p)=bytes2hex(sha256(read(p)))
CFG["phase"]=="PRODUCTION_SINGLE_LOOK"||error("Production identity")
length(SEEDS)==8&&length(unique(SEEDS))==8||error("Eight fresh fixed seeds")
string(VERSION)==CFG["julia_version"]||error("Julia runtime pin")
Threads.nthreads()==1&&BLAS.get_num_threads()==1||error("Single-thread resources")
!haskey(ENV,"P21_PROOF_ONLY")||error("Sampled mode required")
(ispath(OUTPUT)||ispath(RAWROOT))&&error("New raw receipt paths required")
sha(joinpath(BASE,"src/dqmc_kernel.jl"))=="b72bbbf158381b0f776c1fa259d532b069094c47e361d3490c19ea0f43ada4be"||error("Original source pin")
sha(joinpath(OVERLAY,"src/dqmc_kernel.jl"))=="911a61642b23a4465639c3b3e4c63ff9d7cf05d51da288f3224f1775c0aba891"||error("Observer source pin")
include(joinpath(HERE,"UserMatrixObserver.jl"))
using .UserMatrixObserver
module Observed
include(joinpath(ENV["P21_USER_OVERLAY"],"src/dqmc_kernel.jl"))
end
string(pkgversion(Observed.jdqmcf))==CFG["jdqmcframework_version"]||error("Native JDQMC version pin")

function new_toml(path,value)
    ispath(path)&&error("Receipt already exists: "*path)
    open(path,"w") do io;TOML.print(io,value);end
end

function cycle(r,deltaG,observer)
    time()<CUTOFF||error("Fixed scientific deadline reached")
    r.fermion_greens_calc_up.forward||error("Cycle must start forward")
    r,deltaG,a1=Observed.update_replica!(r,deltaG;observer=observer)
    !r.fermion_greens_calc_up.forward||error("First call must finish forward traversal")
    r,deltaG,a2=Observed.update_replica!(r,deltaG;observer=observer)
    r.fermion_greens_calc_up.forward||error("Cycle must finish ready for forward traversal")
    r,deltaG,(a1+a2)/2
end

function chain(index,seed)
    began=time()
    r=Observed.initializer(CFG["t"],CFG["U"],CFG["mu_centered"],CFG["beta"],CFG["L"],CFG["dtau"],seed;
        n_stab=CFG["n_stab"],boundary_condition=Symbol(CFG["boundary"]))
    deltaG=0.;acceptance=0.;burn_deltaG=0.
    burn=Dict{String,Any}[];bins=Dict{String,Any}[]
    for raw_bin in 1:(CFG["burn_bins"]+CFG["retained_bins"])
        b=MatrixBin(CFG["L"],CFG["Ltau"])
        callback=event->observe!(b,event)
        for _ in 1:CFG["cycles_per_bin"]
            r,deltaG,rate=cycle(r,deltaG,callback);acceptance+=rate
        end
        row=raw_record(b)
        all(==(CFG["cycles_per_bin"]),row["counts_by_tau"])||error("Wrong primary callback counts")
        row["raw_bin"]=raw_bin;row["chain"]=index;row["seed"]=seed
        row["role"]=raw_bin<=CFG["burn_bins"] ? "BURN_EXCLUDED" : "RETAINED"
        row["bin"]=raw_bin<=CFG["burn_bins"] ? raw_bin : raw_bin-CFG["burn_bins"]
        row["cumulative_deltaG"]=deltaG
        # One immutable file per completed raw bin preserves partial timeout data.
        new_toml(joinpath(RAWROOT,"chain$(index)_rawbin$(lpad(string(raw_bin),3,'0')).toml"),row)
        if raw_bin<=CFG["burn_bins"]
            push!(burn,row);burn_deltaG=deltaG
        else
            push!(bins,row)
        end
    end
    Dict("chain"=>index,"seed"=>seed,"status"=>"SAMPLED_CHAIN_COMPLETE","bins"=>bins,"burn_bins"=>burn,
        "burn_cycles"=>CFG["burn_cycles"],"retained_cycles"=>CFG["retained_cycles"],
        "update_calls"=>2*(CFG["burn_cycles"]+CFG["retained_cycles"]),
        "cumulative_deltaG_after_burn"=>burn_deltaG,"cumulative_deltaG"=>deltaG,
        "acceptance"=>acceptance/(CFG["burn_cycles"]+CFG["retained_cycles"]),"elapsed_seconds"=>time()-began)
end

function main()
    began=time();mkdir(RAWROOT)
    result=Dict{String,Any}("schema"=>CFG["schema"],"phase"=>CFG["phase"],"catalogue_id"=>"P21",
        "scientific_completions"=>0,"manifest_sha256"=>sha(joinpath(HERE,"manifest.toml")),
        "driver_sha256"=>sha(@__FILE__),"observer_sha256"=>sha(joinpath(HERE,"UserMatrixObserver.jl")),
        "original_kernel_sha256"=>sha(joinpath(BASE,"src/dqmc_kernel.jl")),
        "observer_kernel_sha256"=>sha(joinpath(OVERLAY,"src/dqmc_kernel.jl")),
        "julia_version"=>string(VERSION),"jdqmcframework_version"=>string(pkgversion(Observed.jdqmcf)),
        "job_id"=>get(ENV,"SLURM_JOB_ID","NONE"),"julia_threads"=>Threads.nthreads(),
        "blas_threads"=>BLAS.get_num_threads(),"created_utc"=>string(now(UTC)),
        "scientific_soft_stop_epoch"=>CUTOFF,"chains"=>Dict{String,Any}[])
    for (i,seed) in enumerate(SEEDS)
        row=chain(i,seed)
        new_toml(OUTPUT*".chain$(i).toml",row)
        push!(result["chains"],row)
    end
    result["status"]="SAMPLED_PRODUCTION_COMPLETE";result["elapsed_seconds"]=time()-began
    new_toml(OUTPUT,result)
end
main()
