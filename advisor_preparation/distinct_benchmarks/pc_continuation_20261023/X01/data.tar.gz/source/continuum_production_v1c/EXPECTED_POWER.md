# Frozen pre-execution power and cost note

The excluded pilot is used only for runtime/precision planning and API
eligibility. Margins and the fit family originate in the earlier pinned
proposal. No pilot measurements, seeds or fitted endpoints enter production.

The pilot's maximum per-bundle64bin jackknife standard errors are
0.02866153307622272for total energy and0.03366050040057295for S2 at1024rounds.
An optimistic independent-round square-root scaling to16384rounds divides
these by4. Eight independent bundle contrasts divide bysqrt8. Multiply each
fixed contrast's L2weight norm and Student critical7.58185668916078 to obtain
the following approximate halfwidths. This assumes equal variance at all h,
no cross-time covariance, unchanged mixing, normal bundle averages and
representative two-endpoint pilot errors. None is guaranteed; it is a planning
screen, not a power certification or production confidence interval.

| Contrast | Energy projected halfwidth | S2 projected halfwidth |
|---|---:|---:|
|Primary all4h2intercept|0.01253943|0.01472648|
|Fine3h2intercept|0.01632320|0.01917020|
|All4h2+h4intercept|0.01706530|0.02004172|
|Fine3predicts heldout coarsest, descriptive|0.10002469|0.11747038|
|Coarse3predicts heldout finest, descriptive|0.02500617|0.02936759|

Required endpoint halfwidths are0.01energy and0.005S2. Full equivalence margins
are0.02and0.01. Thus the fixed16kstage is **strongly expected to remain
UNRESOLVED** under this projection. It provides a full-grid precision/mixing
screen, not a plausible guaranteed catalogue completion. The coarse-heldout
test is particularly noisy because its weights are
[1,-4.404761904761908,1.0238095238095242,2.3809523809523823]. No tolerance is
relaxed to compensate for that extrapolation cost.

Primary intercept weights are
[-.10447761194029864,.29353233830845765,.39303482587064675,.4179104477611941];
fine intercept weights are[0,-1/6,1/2,2/3]. The exact finite-h native model's
primary/fine continuum biases are energy-0.00127136/-0.000129446 and
S2-0.000169096/-0.0000168471. The exact fine-to-coarse heldout energy residual
has magnitude0.0109297391, so a0.01half-margin would reject the exact model;
heldout contrasts remain descriptive in the final26-CI design. No heldout
acceptance gate or inferential interval is evaluated.

Pilot work-count scaling gives1516.17338180542API seconds for16kstage1,
5559.302399953206for a hypothetical64kstage and21731.818472544353for256k.
The latter stages are not implemented or authorized by this release. The16k
projection includes scaled cold overhead and omits independent oracle/report
loading cost; it is not a runtime guarantee. All production work is capped at
60minutes, one CPU and3500MB, with no automatic extension or stage escalation.
