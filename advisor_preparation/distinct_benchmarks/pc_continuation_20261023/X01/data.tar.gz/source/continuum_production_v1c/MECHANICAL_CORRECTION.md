# V1c fixed mechanical retry of cancelled job6460728

Job6460728 used the separately preserved v1b release. Root cancelled only that
job at2026-10-23T00:40:52UTC after diagnosing an encoding defect in the scalar
energy adapter. Its oracle and partial sampling outputs remain preserved in
the42-file x01_cancelled_6460728 retrieval. The v1b directory, source freeze,
archive and remote source tree are unchanged.

The intended integer-division character in driver line60 was accidentally
decoded using the Windows default code page during source preparation. Its
actual UTF8 code points were U+00C3 followed by U+00B7. Julia parsed the
malformed token but scalar evaluation raised UndefVarError. Syntax-only
Meta.parseall was therefore insufficient to detect this execution defect.

V1c replaces that sole malformed division with the ASCII expression
`bs=div(CFG["measured_sweeps"],B)`. The fixed values16384and64 give256rounds
per bin. Source preparation now explicitly decodes UTF8 and emits the ASCII
division, preventing recurrence. All code/config files are scanned as ASCII,
and a static scalar check verifies256. Root must additionally evaluate the
exact extracted division with native Julia before launch; no sampler is
needed for that check.

The new result namespace is results/continuum_production_v1c_JOBID. Other
changes are version paths, preparation/static checks and this provenance.
`mechanical_diff_from_v1b.patch` contains the exact unified diff of every
changed preexisting payload file; `mechanical_changes.json` binds before/after
SHA256 values. The comparator, oracle, mixing implementation, scientific
manifest, models, all gates/margins/statistics and sampling budgets are
byte-identical. The manifest SHA256 remains
bfd9f808b9b25bf4e93393d3a05b2e958cf903ff4a43660744585100f1ac09ea;
the seed SHA256 remains
a0c2df1035bdf624ced1a974ec91bb6cae0b8fc2ece30e7f7c234790e4a07ae4.

The same predeclared288initialization seeds are retained as a fixed retry of
the administratively cancelled, mechanically defective attempt. No seed was
selected or replaced based on scientific output. Root reported that no
physical estimates or comparison gates were inspected to make this decision.
Every prior partial output is excluded from the new analysis: no pooling,
additional independent-chain credit, extra statistical look or relaxed gate
is granted. The fresh run must complete the entire original32bundle/160call
grid. An insufficient-precision result remains UNRESOLVED. This correction
does not assert a scientific PASS or authorize any larger stage.
