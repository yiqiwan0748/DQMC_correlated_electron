# X01 continuum production v1c: fixed stage1 mechanical retry

This is a new continuum-extrapolation adapter for the exact catalogue X01
question. It is a candidate frozen release for independent root review before
submission. No solver, sampling, remote execution or submission was performed
while preparing it. All previous attempts, the excluded pilot and its seeds
remain unchanged.

## Fixture, API and independent reference

Use the periodic four-site Hubbard chain with t=1,U=4,beta=1,centered mu=0
(physical mu=2), full256-state grand canonical ensemble and subsystem sites1-2
including both spins. Report total physical internal energy H=K+4D and natural
log finite-temperature subsystem S2. No fixed(2,2) projection, ground-state
interpretation, chemical-potential subtraction or entropy normalization change
is permitted.

The four registered steps are1/4,1/8,1/16,1/32 (4,8,16,32 slices). Each has
eight independent bundles. One bundle uses a separate native energy stream
and four independent native two-replica entropy-node streams. Each stream has
2048burn-in rounds,16384measured rounds and64bins of256measurements; stabilize
every2slices. The scalar path calls unchanged initializer/update_replica!;
entropy calls unchanged run_lambda_node_simulation and its fused update path.
No native kernel is modified. New work is full-grid receipt handling and fixed
statistical analysis. The source/environment hashes are in manifest.toml and
are checked before Julia includes them and again during comparison.

The four left lambda nodes0,.25,.5,.75 with delta=.25 are exact power-increment
ratios Z(lambda+delta)/Z(lambda). Their product telescopes. There is no lambda
quadrature truncation error. Nonlinear ratio/log finite-sample bias, overlap,
rare tails and mixing remain real concerns.

The independent QuSpin oracle constructs the full Fock Hamiltonian/number
operators and spatial partial trace. It computes normalized exp[-beta(K+V)],
V=4sum(nup-.5)(ndown-.5), while physical H is the energy observable. At finite
h it computes the asymmetric transfer T=exp(-hV)exp(-hK), plus
S=D exp(-hK)D,D=exp(-hV/2). It checks T=D S D^-1, direct integer powers,
full/cut similarity, purity invariance, trace, positivity of the symmetric
state and half filling. Matrix/scalar error<=1e-10 and symmetric eigenvalue
minimum>=-1e-12 are mandatory. The asymmetric reduced operator is never
Hermitized. Its continuum target, not any finite-h trace, is the endpoint.

The onsite cut-local D factorization proves purity/S2 invariance under the
similarity. For this real Hamiltonian, odd transformed-observable commutators
are antisymmetric and trace to zero against the symmetric transfer density;
both physical energy and S2 have an even leading h expansion. These are the
fixture-specific derivations preserved in PRIOR_PROPOSAL.md, not a general
claim for complex hopping or nonlocal interactions.

## Seeds, retained evidence and numerical gates

All288actual initialization seeds and64stream labels are fixed before
execution. The integer-only generator verifies positivity, uniqueness,
unchanged native UInt64 replica derivation, and disjointness from every
excluded pilot initializer and label. Neither the pilot's measurements nor
its seed choices enter any production fit or interval. No chain replacement,
time-point replacement, case omission, pooling or restart is allowed.

Retain32scalar rows,128entropy-node rows and160exact matching side receipts,
aggregate target TOML, oracle JSON, process exit codes, resource receipts and
Slurm log. Every call persists its own receipt before aggregate append.
Nonfinite/missing/incomplete/timeout cases are UNRESOLVED. All160cumulative
native deltaG maxima must be finite and in[0,1e-8]. Scalar cumulative history
must include burn-in, be monotone and end at the reported maximum. Require
all64phase bins within1e-10 of+1, strictly positive full/leave-one-out entropy
ratios, nondegenerate acceptance0<a<1 and positive measured runtimes.

## Independent units, nonlinear estimates and mixing rejection

Each scalar bundle uses paired numerator/phase delete-bin jackknife. Each S2
bundle jackknifes the whole functional -sum_k log(sum numerator_k/sum phase_k).
Each deletion removes the same bin label from all four independent nodes,
preserving every numerator/denominator pair. This constructs the independent
product resampling unit; it does not assert shared RNGs or physical covariance
between nodes, energy streams or time steps.

Eight complete bundle vectors are the eight independent statistical units.
The64bins are never treated as64additional independent chains. Recompute with
32adjacent merged bins for energy, full S2 and each node log increment. Require
abs(SE32/SE64-1)<=.5; zero/undefined scientific variance is unresolved.

For every h, use energy bin ratios and node log-ratio influence streams. The
node ratios used for centering are pooled across all eight bundles, preserving
between-chain differences. Full-S2 influence is the sum of the four node
influences. On energy, S2 and each of four node streams, require maximum rank
normalized/folded split-Rhat<=1.05, effective bins>=16in every original chain
and>=128across chains. The separate mixing module documents its rank, split,
Geyer positive/monotone and between-chain correction formulas. These are
rejection diagnostics, not equilibrium/rare-tail or confidence-coverage proofs.

## Fixed fits and26simultaneous intervals

No fit weight/window/order is chosen after sampling. For each eight-bundle
four-point vector, use unweighted OLS with x=h^2:

1. Primary: all4points,a+b*x.
2. Fine: three finest points,a+b*x.
3. Stability: all4points,a+b*x+c*x^2.
4. Descriptive heldout contrasts: fine fit predicts coarsest; a coarse first3fit
predicts finest. Report means/SE only; these are not acceptance intervals or
scientific gates and make no additional inferential claim.

For each fixed contrast c, apply c to each bundle vector first, then use
mean(c*y) plus/minus t7*SD(c*y)/sqrt8. No covariance matrix or data-dependent
regression weights are estimated. The26registered intervals are6continuum
endpoints,4primary-minus-fine/quartic intercept differences,8primary residuals,
8MC-minus-exact-finite-h differences.

Reserve family alpha=.01over at most3separately reviewed stages and26intervals
per stage: per-interval two-sided alpha=.01/(3*26),df7,critical
7.58185668916078. Only the16384stage is implemented here. Unused alpha is not
repurposed; no later stage is launched automatically. This is nominal
Bonferroni coverage conditional on independent approximately normal bundle
contrasts. The extreme Student tail and nonlinear S2 coverage are not
calibrated. X06's other-fixture95percent energy study does not certify them.

The margins were proposed before the timing pilot:0.02total energy and0.01S2.
All3endpoint intervals must be entirely inside +/-margin and have halfwidth
<=margin/2. The two fit-intercept-difference intervals per observable must lie
inside +/-margin/2. Primary residual and finite-h intervals use the full
respective margin. Inequalities are inclusive. Exact oracle fits must also
have each continuum intercept within margin/4. Exact heldout residuals are
descriptive. No exact finite-h bias is subtracted from sampled continuum
estimates.

Demonstrate finite-step bias using the Minkowski coarse-minus-finest interval
[Lcoarse-Ufine,Ucoarse-Lfine] derived from the already simultaneous raw-mean
finite-h intervals. Require its upper endpoint<0for both observables, matching
the predeclared exact signs. This uses no new interval or statistical look.

Missing/numerically/mixing-ineligible evidence or insufficient endpoint
precision is UNRESOLVED. Once eligible and precise, a finite-h interval wholly
outside its margin is FAIL; unresolved fit adequacy or bias detection is
UNRESOLVED; adequate fits with an endpoint interval wholly outside its margin
are FAIL. Only all equivalent endpoints/finite-h intervals, adequate fits,
precision and demonstrated bias yield candidate PASS. Partial overlaps are
UNRESOLVED. No gate or margin is widened after execution.

The comparison records candidate scientific status, while catalogue status
remains PENDING_INDEPENDENT_AUDIT and automatic catalogue completions remain0.
Root must independently audit raw/source/oracle/fit/statistical evidence before
any ledger promotion. Comparator FAIL/UNRESOLVED returns exit2; raw process exit
receipts distinguish this from execution failure and must not trigger restart.

## Resources and power

One CPU,3500MB,60-minute hard wall cap. Oracle timeout90s,target3300s,
comparison120s leave90nominal seconds for checks/IO/cleanup. Source installation,
runtime upgrades and nested jobs are absent. Fresh live admission must include
unrelated jobs and the two-total-running-job policy. Root owns staging,
submission and serial dependency decisions.

Excluded-pilot work-count scaling predicts1516.17API seconds,25.3minutes,
roughly25-35minutes with overhead. Cold overhead was scaled too, so this may
overpredict throughput cost; slow paths and queue delay remain unknown.
EXPECTED_POWER.md freezes a candid pre-execution precision projection:
stage1is expected to be underpowered, especially S2. Heldout extrapolation
contrasts are even noisier and remain descriptive. Its likely scientific
value is a full-grid precision/mixing screen,
and an honest UNRESOLVED outcome may be the correct result.

Before any production execution, root chose the original26mandatory-interval
proposal over an expanded30-interval candidate. Full-grid residuals and both
fixed alternate-fit stability checks already test adequacy. The extra
fine-to-coarse extrapolation requirement would add a high-variance gate
beyond the catalogue/prior proposal. The30-CI candidate sources are preserved
outside this release in continuum_production_v1_superseded_30ci. This is a
pre-execution design review, with no scientific attempt or margin change.

The v1c mechanical correction and exclusion of cancelled v1b partial outputs are recorded in MECHANICAL_CORRECTION.md. All scientific manifest and seed bytes are unchanged.
