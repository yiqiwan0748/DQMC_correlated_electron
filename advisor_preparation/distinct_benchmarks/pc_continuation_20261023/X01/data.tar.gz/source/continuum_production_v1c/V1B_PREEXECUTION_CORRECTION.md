# Pre-execution normal-score correction

The v1candidate was uploaded and hash/bash syntax checked, with zero sampling
or native scientific execution. It remains preserved unchanged locally and on
ISAAC, including its original archive/hash. Root approved this separately
versioned v1b preparation before any scientific attempt.

The Stan2.40manual displays a minus sign in the normal-score denominator,
whereas the standard Blom transform and Stan's own posterior implementation
use (rank-3/8)/(S+1/4). The implementation defines the general fractional
rank probability as (rank-c)/(S-2c+1),c=3/8. V1b follows that implementation.
With the plus denominator, extreme/paired ranks have opposite normal scores;
v1b adds a deterministic symmetry check. This changes the rank diagnostic
implementation, with no change to any threshold, physical model, native
kernel, seed, production budget, fit, margin or26-CI statistical family.

Primary implementation inspected before correction:
https://github.com/stan-dev/posterior/blob/master/R/convergence.R

Retrieved Git blob SHA:894c6bef6c8d6e17a3b19b25848a69ba9ff7fe3d.

The general split-Rhat and ESS definitions remain documented at:
https://mc-stan.org/docs/2_40/reference-manual/analysis.html

No production observation or gate outcome influenced this correction. The
source-stage/result prefix is explicitly continuum_production_v1b; scientific
schema/phase and all actual initialization seeds are unchanged from the
unexecuted v1candidate. Root must independently verify the new source freeze
and run Julia/bash/static checks before launch.
