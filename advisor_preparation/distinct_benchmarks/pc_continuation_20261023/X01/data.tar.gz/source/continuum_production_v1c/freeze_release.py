"""One-shot reproducible source freeze after preparation; no scientific execution."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    archive=HERE.parent/'continuum-production-v1c-source.tar.gz';record=HERE/'source_freeze.json';sums=HERE/'SHA256SUMS'
    assert not any(p.exists() for p in (archive,record,sums)),'Use a new release for changed sources'
    review=json.loads((HERE/'static_review.json').read_text())
    assert review['status']=='PASS_LOCAL_STATIC_ALGEBRA_AWAITING_ROOT_REVIEW'
    paths=sorted(p for p in HERE.iterdir() if p.is_file())
    sums.write_bytes(''.join(digest(p)+'  '+p.name+'\n' for p in paths).encode())
    paths.append(sums);paths.sort()
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w') as tar:
        for path in paths:
            raw=path.read_bytes();info=tarfile.TarInfo('continuum_production_v1c/'+path.name)
            info.size=len(raw);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
            tar.addfile(info,io.BytesIO(raw))
    with archive.open('wb') as out:
        with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:gz.write(buffer.getvalue())
    data=dict(schema='X01_CONTINUUM_V1C_SOURCE_FREEZE',status='FROZEN_CANDIDATE_AWAITING_INDEPENDENT_ROOT_REVIEW_NOT_SUBMITTED',
        scientific_execution=False,scientific_completions=0,archive=archive.name,archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,
        files={p.name:digest(p) for p in paths},cpus=1,memory_mb=3500,wall_minutes=60,estimated_api_seconds=1516.17338180542,
        expected_power='Strongly expected underpowered16k precision/mixing screen; margins unchanged; UNRESOLVED is an honest outcome',
        excluded_pilot='6460660; never pooled or fit',new_native_kernel_changes=False,
        remote_paths=dict(archive='source_releases/'+archive.name,extract_root='source/continuum_production_v1c',wrapper='source/continuum_production_v1c/production.sbatch',result='results/continuum_production_v1c_${SLURM_JOB_ID}'),
        mechanical_retry_of_job='6460728',prior_cancellation_utc='2026-10-23T00:40:52Z',
        original_manifest_sha256='bfd9f808b9b25bf4e93393d3a05b2e958cf903ff4a43660744585100f1ac09ea',
        original_seeds_sha256='a0c2df1035bdf624ced1a974ec91bb6cae0b8fc2ece30e7f7c234790e4a07ae4',
        same_predeclared_seed_grid_retry=True,all_prior_partial_outputs_excluded=True,additional_independent_chains=0,
        correction='Only malformed division replaced by ASCII div; output namespace and preparation safeguards updated. Scientific model,statistical gates,budget,seeds unchanged.',
        required_independent_checks=review['root_required'])
    record.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'archive_sha256':data['archive_sha256'],'archive_bytes':data['archive_bytes'],'files':len(paths),'status':data['status']}))
if __name__=='__main__':main()
