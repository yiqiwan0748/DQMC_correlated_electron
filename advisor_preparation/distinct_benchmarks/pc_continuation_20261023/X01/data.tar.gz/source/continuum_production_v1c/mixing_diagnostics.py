#!/usr/bin/env python3
"""Fixed X01 bin-series rejection diagnostics; standard library only.

These diagnostics do not prove equilibrium, independence, or coverage of the
very high-tail Student intervals used by the continuum protocol. The input is
eight independent scientific streams, each represented by 64 consecutive bin
values. Constant phase denominators belong in the sign gate, not this function.

Formula source: Stan Reference Manual 2.40, Posterior Analysis:
https://mc-stan.org/docs/2_40/reference-manual/analysis.html

Rhat is the maximum of rank-normalized split Rhat and folded rank-normalized
split Rhat. Pooled midranks use Blom's (rank-3/8)/(S+1/4) normal transform,
matching stan-dev/posterior backtransform_ranks (the manual has a sign typo).
ESS uses biased lag autocovariances, Geyer's initial positive paired sequence,
then its initial monotone sequence. Aggregate split-chain ESS includes the
between-chain variance correction. ESS is conservatively capped at the number
of retained bins; antithetic super-efficiency is not credited. Both raw and
rank-normalized ESS are evaluated and the smaller is used for each gate.
"""

from __future__ import annotations

import math
import statistics
from typing import Any, Sequence


SOURCE_URL = "https://mc-stan.org/docs/2_40/reference-manual/analysis.html"
DISCLOSURE = (
    "Bin-series rejection diagnostics only. Thresholds do not prove equilibrium, "
    "independent bins, or normality of the eight independent bundle estimates; "
    "they do not calibrate the protocol's high-tail Student intervals. ESS is an "
    "estimate from 64 retained bins per original stream, not measured sweeps."
)
_NORMAL = statistics.NormalDist()


def _finite_float(value: Any) -> float | None:
    if isinstance(value, (bool, str, bytes)):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if math.isfinite(result) else None


def _rank_normalize(rows: Sequence[Sequence[float]]) -> list[list[float]]:
    """Pooled midranks, including ties, followed by the Blom normal transform."""
    n = len(rows[0])
    values = [value for row in rows for value in row]
    order = sorted(range(len(values)), key=values.__getitem__)
    scores = [0.0] * len(values)
    start = 0
    while start < len(order):
        stop = start + 1
        while stop < len(order) and values[order[stop]] == values[order[start]]:
            stop += 1
        midrank = ((start + 1) + stop) / 2.0
        score = _NORMAL.inv_cdf((midrank - 3.0 / 8.0) / (len(values) + 1.0 / 4.0))
        for index in order[start:stop]:
            scores[index] = score
        start = stop
    return [scores[index:index + n] for index in range(0, len(scores), n)]


def _scale(rows: Sequence[Sequence[float]]) -> list[list[float]]:
    """A common positive scale avoids overflow without changing diagnostics."""
    largest = max(abs(value) for row in rows for value in row)
    if largest == 0.0:
        return [list(row) for row in rows]
    return [[value / largest for value in row] for row in rows]


def _moments(rows: Sequence[Sequence[float]]) -> tuple[list[float], list[float], float, float]:
    n = len(rows[0])
    means = [math.fsum(row) / n for row in rows]
    variances = [math.fsum((value - mean) ** 2 for value in row) / (n - 1)
                 for row, mean in zip(rows, means)]
    within = math.fsum(variances) / len(rows)
    if len(rows) == 1:
        between = 0.0
    else:
        overall = math.fsum(means) / len(means)
        between = n * math.fsum((mean - overall) ** 2 for mean in means) / (len(means) - 1)
    return means, variances, within, between


def _rhat(rows: Sequence[Sequence[float]]) -> float | None:
    _, _, within, between = _moments(rows)
    if within == 0.0:
        # A folded transform may be exactly constant even when the original
        # scientific stream varies. It then contributes no scale disagreement.
        return 1.0 if between == 0.0 else None
    n = len(rows[0])
    var_plus = (n - 1.0) / n * within + between / n
    value = math.sqrt(var_plus / within)
    return max(1.0, value) if math.isfinite(value) else None


def _ess(rows: Sequence[Sequence[float]]) -> dict[str, Any]:
    """Geyer IPS/IMS ESS, with cross-chain correction when multiple rows exist."""
    rows = _scale(rows)
    m, n = len(rows), len(rows[0])
    means, _, within, between = _moments(rows)
    if within <= 0.0:
        return {"ess": None, "status": "ZERO_WITHIN_CHAIN_VARIANCE"}
    centered = [[value - mean for value in row] for row, mean in zip(rows, means)]
    autocov = [math.fsum(math.fsum(row[j] * row[j + lag] for j in range(n - lag)) / n
                        for row in centered) / m for lag in range(n)]
    if m == 1:
        var_plus = autocov[0]
        rho = [value / var_plus for value in autocov]
    else:
        var_plus = (n - 1.0) / n * within + between / n
        if var_plus <= 0.0 or not math.isfinite(var_plus):
            return {"ess": None, "status": "INVALID_VARIANCE_ESTIMATE"}
        rho = [1.0] + [1.0 - (within - value) / var_plus for value in autocov[1:]]
    positive_pairs: list[float] = []
    available_pairs = n // 2
    for lag in range(0, n - 1, 2):
        pair = rho[lag] + rho[lag + 1]
        if not math.isfinite(pair) or pair <= 0.0:
            break
        # Geyer's initial monotone paired sequence, after initial positivity.
        positive_pairs.append(min(pair, positive_pairs[-1]) if positive_pairs else pair)
    tau_unclipped = -1.0 + 2.0 * math.fsum(positive_pairs)
    tau = max(1.0, tau_unclipped)
    value = min(float(m * n), m * n / tau)
    if not math.isfinite(value):
        return {"ess": None, "status": "NONFINITE_ESS"}
    return {
        "ess": value,
        "status": "ESTIMATED",
        "retained_bins": m * n,
        "integrated_autocorrelation_time_clipped": tau,
        "positive_monotone_pairs": len(positive_pairs),
        "positive_sequence_reached_lag_limit": len(positive_pairs) == available_pairs,
        "between_chain_variance_correction": m > 1,
        "antithetic_ess_capped_at_retained_bins": True,
    }


def diagnose(chains: Sequence[Sequence[float]], rhat_max: float = 1.05,
             ess_min_per_chain: float = 16, ess_min_total: float = 128) -> dict[str, Any]:
    """Evaluate the fixed eight-by-64 scientific bin-series eligibility gates.

    All returned numbers are finite; unavailable diagnostics are JSON null.
    Invalid input, constant original chains, undefined diagnostics, or a missed
    threshold gives UNRESOLVED. Input data are never silently dropped.
    """
    limits = [_finite_float(value) for value in (rhat_max, ess_min_per_chain, ess_min_total)]
    result: dict[str, Any] = {
        "schema": "X01_MIXING_DIAGNOSTICS_V1",
        "eligible": False,
        "status": "UNRESOLVED",
        "issues": [],
        "rhat": None,
        "rank_split_rhat": None,
        "folded_rank_split_rhat": None,
        "ess_total": None,
        "ess_per_chain": [],
        "thresholds": dict(zip(("rhat_max", "ess_min_per_chain", "ess_min_total"), limits)),
        "source_url": SOURCE_URL,
        "disclosure": DISCLOSURE,
    }
    issues = result["issues"]
    if any(value is None for value in limits) or limits[0] < 1 or min(limits[1:]) <= 0:
        issues.append("INVALID_THRESHOLDS")
        return result
    try:
        rows = [list(row) for row in chains]
    except (TypeError, ValueError):
        issues.append("INPUT_IS_NOT_A_RECTANGULAR_NUMERIC_CHAIN_GRID")
        return result
    result["input_shape"] = {"chains": len(rows), "bins_per_chain": [len(row) for row in rows]}
    if len(rows) != 8 or any(len(row) != 64 for row in rows):
        issues.append("EXPECTED_EIGHT_CHAINS_WITH_64_BINS_EACH")
        return result
    converted = [[_finite_float(value) for value in row] for row in rows]
    if any(value is None for row in converted for value in row):
        issues.append("NONFINITE_OR_NONNUMERIC_INPUT")
        return result
    rows = converted
    constant = [index + 1 for index, row in enumerate(rows) if min(row) == max(row)]
    result["constant_original_chains"] = constant
    if constant:
        issues.append("CONSTANT_SCIENTIFIC_CHAIN")
    split = [half for row in rows for half in (row[:32], row[32:])]
    ranked = _rank_normalize(split)
    # Work on commonly scaled values before subtracting the median so even
    # finite input spanning the floating-point range cannot overflow folding.
    scaled = _scale(split)
    ordered = sorted(value for row in scaled for value in row)
    lower_middle, upper_middle = ordered[len(ordered) // 2 - 1:len(ordered) // 2 + 1]
    half_gap = (upper_middle - lower_middle) / 2.0
    # Algebraically abs(value-median), expressed around the two middle values
    # so their mathematically equal folded distances remain an exact tie.
    folded_values = [[(lower_middle - value if value <= lower_middle else value - upper_middle)
                      + half_gap for value in row] for row in scaled]
    folded = _rank_normalize(folded_values)
    result["rank_split_rhat"] = _rhat(ranked)
    result["folded_rank_split_rhat"] = _rhat(folded)
    # The original all-constant case must not inherit the benign folded
    # transform convention used by _rhat.
    if len(set(value for row in rows for value in row)) == 1:
        result["rank_split_rhat"] = None
        result["folded_rank_split_rhat"] = None
    rhats = [result["rank_split_rhat"], result["folded_rank_split_rhat"]]
    if any(value is None for value in rhats):
        issues.append("UNDEFINED_SPLIT_RHAT")
    else:
        result["rhat"] = max(rhats)
        if result["rhat"] > limits[0]:
            issues.append("RHAT_EXCEEDS_THRESHOLD")
    raw_total = _ess(split)
    ranked_total = _ess(ranked)
    result["aggregate_ess_details"] = {"raw_split": raw_total, "rank_normalized_split": ranked_total}
    total_values = [raw_total["ess"], ranked_total["ess"]]
    if any(value is None for value in total_values):
        issues.append("UNDEFINED_AGGREGATE_ESS")
    else:
        result["ess_total"] = min(total_values)
        if result["ess_total"] < limits[2]:
            issues.append("AGGREGATE_ESS_BELOW_THRESHOLD")
    details = []
    for row in rows:
        raw = _ess([row])
        rank = _ess(_rank_normalize([row]))
        values = [raw["ess"], rank["ess"]]
        value = None if any(item is None for item in values) else min(values)
        result["ess_per_chain"].append(value)
        details.append({"raw": raw, "rank_normalized": rank})
    result["individual_ess_details"] = details
    if any(value is None for value in result["ess_per_chain"]):
        issues.append("UNDEFINED_INDIVIDUAL_CHAIN_ESS")
    elif min(result["ess_per_chain"]) < limits[1]:
        issues.append("INDIVIDUAL_CHAIN_ESS_BELOW_THRESHOLD")
    result["eligible"] = not issues
    result["status"] = "DIAGNOSTIC_THRESHOLDS_MET" if not issues else "UNRESOLVED"
    return result


def blocking_check(se64: float, se32: float, maxchange: float = 0.5) -> dict[str, Any]:
    """Reject undefined/zero errors or abs(SE32/SE64-1) above maxchange."""
    a, b, maximum = (_finite_float(value) for value in (se64, se32, maxchange))
    issues = []
    change = None
    if maximum is None or maximum < 0:
        issues.append("INVALID_BLOCKING_THRESHOLD")
    if a is None or b is None or a <= 0 or b <= 0:
        issues.append("JACKKNIFE_ERRORS_MUST_BE_FINITE_AND_POSITIVE")
    else:
        candidate = abs(b / a - 1.0)
        if math.isfinite(candidate):
            change = candidate
            if maximum is not None and candidate > maximum:
                issues.append("RELATIVE_BLOCKING_ERROR_CHANGE_EXCEEDS_THRESHOLD")
        else:
            issues.append("NONFINITE_RELATIVE_BLOCKING_ERROR_CHANGE")
    return {"schema": "X01_BLOCKING_CHECK_V1", "eligible": not issues,
            "status": "DIAGNOSTIC_THRESHOLDS_MET" if not issues else "UNRESOLVED",
            "se64": a, "se32": b, "maxchange": maximum,
            "relative_change": change, "issues": issues, "disclosure": DISCLOSURE}


def _self_test() -> None:
    """Deterministic diagnostic-unit tests only; no physical sampling."""
    import json
    import random

    rng = random.Random(104729)
    independent = [[rng.gauss(0, 1) for _ in range(64)] for _ in range(8)]
    good = diagnose(independent)
    symmetric_scores = _rank_normalize([list(range(64))])[0]
    assert all(abs(symmetric_scores[i] + symmetric_scores[-i-1]) < 1e-13 for i in range(64))
    assert good["eligible"], good["issues"]
    assert not diagnose([[1.0] * 64 for _ in range(8)])["eligible"]
    assert not diagnose(independent[:7])["eligible"]
    nonfinite = [list(row) for row in independent]
    nonfinite[0][0] = float("nan")
    assert not diagnose(nonfinite)["eligible"]
    shifted = [[value + 5 * chain for value in row] for chain, row in enumerate(independent)]
    assert not diagnose(shifted)["eligible"]
    drifting = [[value + 0.25 * index for index, value in enumerate(row)] for row in independent]
    assert not diagnose(drifting)["eligible"]
    assert blocking_check(1.0, 1.5)["eligible"]
    assert not blocking_check(1.0, 1.50001)["eligible"]
    assert not blocking_check(0.0, 0.0)["eligible"]
    json.dumps([good, diagnose(nonfinite), blocking_check(float("inf"), 1)], allow_nan=False)
    print("mixing_diagnostics self-test: PASS (diagnostic unit tests only)")


if __name__ == "__main__":
    _self_test()
