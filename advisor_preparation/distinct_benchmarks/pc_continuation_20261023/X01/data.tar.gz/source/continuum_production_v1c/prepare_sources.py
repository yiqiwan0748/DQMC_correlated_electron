"""Preparation only: derive disclosed full-grid driver from byte-pinned pilot."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
PILOT=HERE.parent/'next_stage_review/continuum_bias/pilot_v1'
def create(name,text):
    out=HERE/name
    assert not out.exists(),out
    out.write_bytes(text.encode())
def main():
    names={'target_pilot.jl':'7cf5ddb08297a828c88e3bd2b9c845245105ed3c732b16d6c387cce3d084b478',
           'oracle_quspin.py':'8ebd57c42a6fe5c066d255bb1325eb95bae2b637ae9b1b2c98531b49d9251149',
           'seeds.toml':'2522c3b6e5ce8e4d2a37a6750dac304e1984e158bbef0611c2df287370490356'}
    for name,want in names.items():assert hashlib.sha256((PILOT/name).read_bytes()).hexdigest()==want
    target=(PILOT/'target_pilot.jl').read_text(encoding='utf-8')
    target=target.replace('# Only the excluded timing pilot. Actual source kernels/native node runner unchanged.','# Fixed X01 continuum stage1. Actual source kernels/native node runner unchanged.')
    target=target.replace('CFG["phase"]=="PILOT_ONLY"&&!CFG["scientific_completion_allowed"]&&!CFG["production_campaign_implemented"]','CFG["phase"]=="X01_CONTINUUM_STAGE1"&&CFG["scientific_completion_allowed"]&&CFG["production_campaign_implemented"]')
    target=target.replace('Timing pilot only','Registered continuum stage1 only').replace('X01_PILOT_OUTPUT','X01_PRODUCTION_OUTPUT')
    target=target.replace('CFG["pilot_dtau"]==[.25,.03125]&&CFG["bundles_per_dtau"]==2&&CFG["measured_sweeps"]==1024','CFG["production_dtau"]==[.25,.125,.0625,.03125]&&CFG["bundles_per_dtau"]==8&&CFG["measured_sweeps"]==16384')
    target=target.replace('pilot_dtau','production_dtau').replace('for b in 1:2','for b in 1:8').replace('length(rows)==4','length(rows)==32')
    target=target.replace('CFG["bins"]==64||error("Unregistered pilot grid")','CFG["burn_sweeps"]==2048&&CFG["bins"]==64||error("Unregistered production grid")')
    target=target.replace('length(actual)==36&&length(unique(actual))==36','length(actual)==288&&length(unique(actual))==288')
    target=target.replace('"phase"=>"PILOT_ONLY"','"phase"=>CFG["phase"]').replace('PILOT_ONLY_COMPLETE','PRODUCTION_STAGE1_COMPLETE')
    target=target.replace('No production continuum fit.','Fixed continuum analysis is a separate new comparator.').replace('X01 timing pilot finished bundle','X01 continuum stage1 finished bundle')
    target=target.replace('CFG["measured_sweeps"]'+chr(0xf7)+'B','div(CFG["measured_sweeps"],B)')
    oracle=(PILOT/'oracle_quspin.py').read_text(encoding='utf-8').replace('cfg[\'phase\']==\'PILOT_ONLY\' and not cfg[\'scientific_completion_allowed\']','cfg[\'phase\']==\'X01_CONTINUUM_STAGE1\' and cfg[\'scientific_completion_allowed\']')
    create('target_production.jl',target);create('oracle_quspin.py',oracle)
    (HERE/'excluded_pilot_seeds.toml').write_bytes((PILOT/'seeds.toml').read_bytes())
    catalogue=json.loads((HERE.parent/'benchmark_ideas_100.json').read_text(encoding='utf-8'))
    create('catalogue_X01.json',json.dumps(next(r for r in catalogue if r['id']=='X01'),indent=2)+'\n')
    create('adapter_provenance.json',json.dumps({'schema':'X01_NEW_ADAPTER_PROVENANCE_V1','pinned_pilot_inputs':names,
        'changes':['Full four-step grid,eight bundles,2048burn+16384measured,64bins,freshseednamespace',
                   'Production completion/phase/output names and full-grid guards',
                   'Native initializer,update_replica!,run_lambda_node_simulation,energyformula,rawbinretention unchanged',
                   'Independent oracle compute() algebra unchanged; manifest phase guard updated',
                   'New fixed OLS/Studentinterval/mixing/blocking comparator; independent post-run audit still required'],
        'sampling_kernel_changes':False,'scientific_execution_during_preparation':False},indent=2)+'\n')
if __name__=='__main__':main()
