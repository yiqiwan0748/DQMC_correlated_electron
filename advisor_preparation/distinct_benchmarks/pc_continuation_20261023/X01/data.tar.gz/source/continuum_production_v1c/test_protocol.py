"""Deterministic static/algebra preparation checks; no native or QuSpin imports."""
import argparse,ast,hashlib,json,math,sys,tomllib
from pathlib import Path
import numpy as np
from generate_seeds import contents
from compare_production import design,jk,ci,t7_cdf
from mixing_diagnostics import diagnose,blocking_check
from mixing_diagnostics import _rank_normalize
HERE=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert not a.output.exists()
    c=tomllib.loads((HERE/'manifest.toml').read_text());seed=tomllib.loads((HERE/'seeds.toml').read_text());pilot=tomllib.loads((HERE/'excluded_pilot_seeds.toml').read_text())
    checks={}
    checks['allPythonASTparse']=all(isinstance(ast.parse(f.read_text()),ast.Module) for f in HERE.glob('*.py'))
    checks['seedregenerationbyteexact']=contents(c,pilot).encode()==(HERE/'seeds.toml').read_bytes()
    checks['full32bundlegrid']=len(seed['bundles'])==32 and {(r['dtau_index'],r['bundle']) for r in seed['bundles']}=={(i,b) for i in range(1,5) for b in range(1,9)}
    actual=[r['energy_seed'] for r in seed['bundles']]+[v for r in seed['bundles'] for pair in r['node_replica_seeds'] for v in pair]
    checks['actual288positiveuniqueseeds']=len(actual)==len(set(actual))==288 and min(actual)>0
    checks['30candidatepresuperseded26final']=c['statistics']['intervals_per_stage']==26 and c['statistics']['reserved_stages']==3
    alpha=.01/(3*26);q=c['statistics']['student_t_critical']
    checks['analyticStudent7tail']=abs(t7_cdf(q)-(1-alpha/2))<=2e-14
    D=design(c['production_dtau']);x=np.square(c['production_dtau']);y=2+3*x
    checks['fixedfullfinequarticlinearintercepts']=all(abs(D[n]@y-2)<1e-12 for n in ('primary','fine','quartic'))
    checks['quarticinterceptpreservesquadraticinx']=abs(D['quartic']@(2+3*x+4*x*x)-2)<1e-12
    checks['fullresidualannihilatesregisteredlinearspace']=np.max(abs(D['residuals']@y))<1e-12
    checks['heldoutlinearcontrastszero']=all(abs(D[n]@y)<1e-12 for n in ('heldout_coarse','heldout_fine'))
    E=jk([[2.]*64],[[1.]*64]);S=jk([[.5]*64]*4,[[1.]*64]*4,True)
    checks['pairedratiojackknifeidentity']=abs(E['bias_corrected']-2)<1e-12 and E['standard_error']==0
    checks['telescopinglogfunctionaljackknifeidentity']=abs(S['bias_corrected']-4*math.log(2))<1e-12
    checks['CIuses8bundlesdf7']=ci(list(range(8)),q)['df']==7 and ci(list(range(8)),q)['bundles']==8
    checks['blockingrejectsundefinedscientificvariance']=not blocking_check(0.,0.)['eligible']
    checks['mixingrejectsconstantstreams']=not diagnose(np.ones((8,64)))['eligible']
    scores=_rank_normalize([list(range(64))])[0]
    checks['Blompairedrankssymmetric']=all(abs(scores[i]+scores[-i-1])<1e-13 for i in range(64))
    target=(HERE/'target_production.jl').read_bytes().decode('utf-8')
    checks['ASCIIdivisiontokenscalar256']='bs=div(CFG["measured_sweeps"],B)' in target and c['measured_sweeps']//c['bins']==256
    checks['allCodeConfigFilesASCII']=all(f.read_bytes().isascii() for f in HERE.iterdir() if f.suffix in ('.py','.jl','.sbatch','.toml'))
    checks={key:bool(value) for key,value in checks.items()}
    data=dict(schema='X01_CONTINUUM_V1_STATIC_REVIEW',status='PASS_LOCAL_STATIC_ALGEBRA_AWAITING_ROOT_REVIEW' if all(checks.values()) else 'FAIL',checks=checks,
        sampler_executed=False,oracle_executed=False,remote_calls=0,jobs_submitted=0,
        count=dict(independent_bundles=8,dtau=4,energy_calls=32,entropy_calls=128,actual_initializations=288,measured_rounds_per_call=16384,bins=64),
        root_required=['Independent source/statistical review','ISAAC bash syntax and Julia parse-only checks','Pinned SciPy independent Studentcritical/OLS verification','Fresh live admission before launch'],
        student_t_critical=q,analytic_t7_CDF=t7_cdf(q),fixed_design={k:v.tolist() for k,v in D.items()},
        local_python=sys.version,local_numpy=np.__version__,test_driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    a.output.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':data['status'],'checks':len(checks),'failures':[k for k,v in checks.items() if not v]}))
    if not all(checks.values()):sys.exit(1)
if __name__=='__main__':main()
