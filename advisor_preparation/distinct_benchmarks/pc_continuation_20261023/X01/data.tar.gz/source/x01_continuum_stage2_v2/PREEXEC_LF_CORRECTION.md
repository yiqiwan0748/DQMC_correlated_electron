# Pre-execution LF correction

No stage2 jobs were submitted from v1. Its archive and freeze remain unchanged and excluded. ISAAC sha256sum exposed CRLF in SHA256SUMS, which adds a CR to each filename. V2 normalizes all frozen text to UTF8/LF, generates checksum/freeze bytes explicitly as LF, and changes only the output/release namespace and mechanical safeguards. Scientific model, gates, statistics, stage2 budget and seed bytes remain unchanged. No sampling, estimates or partial data informed this correction.
