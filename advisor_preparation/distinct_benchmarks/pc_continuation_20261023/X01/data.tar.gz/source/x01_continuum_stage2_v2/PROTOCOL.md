# X01 stage2: separate fixed overnight precision stage

This release implements the second of the original three reserved statistical
looks. It is a new stage with fresh independent seeds and no pooling of any
stage1 or pilot values. It answers the same X01 question on the same periodic
four-site Hubbard model: t=1, U=4, beta=1, physical mu=2, centered mu=0, grand
canonical full256-state trace. Physical energy is total K+U*D. S2 is the
natural-log second Renyi entropy of sites1-2, both spins.

Eight independent bundle vectors cover the four registered steps
1/4,1/8,1/16,1/32. Each scalar chain and each native lambda node uses2048burn
and262144measured rounds, retained in64consecutive bins of4096rounds. Burn2048
is retained because every one of the24stage1 mixing diagnostic groups passed
its original thresholds in the integrity-PASS stage1 audit. This observation
does not prove equilibration. The earlier protocol did not declare another
stage2round budget. The separately frozen16x precision stage is authorized
before any stage2sampling or estimate inspection.

The stage2seed namespace generates32scalar seeds and256native replica
initializations, all positive, unique and disjoint from every actual pilot and
stage1initialization and root label. The excluded list includes pilot6460660
and stage1job6460771. Cancelled mechanical retry6460728used the stage1seed
grid, so those partial streams are also excluded. No replacement, pooling or
independent-chain credit is given to earlier data. A failed/partial stage2part
is retained and cannot be replaced or silently omitted in this stage.

## Unchanged scientific decision

There are exactly26simultaneous intervals:6continuum endpoints,4fit-intercept
stability contrasts,8primary residuals and8MC-minus-exact finite-h contrasts.
The primary fit is all4points linear in h²; the fine fit is last3points linear
in h²; the quartic fit is all4points quadratic in h². Heldout contrasts are
descriptive means/SEs with no intervals or scientific acceptance gates.

The original energy/S2margins remain0.02/0.01. Every endpoint must have its
whole error interval inside its margin, with halfwidth at most0.01/0.005.
Stability margins remain half those margins; residual and finite-h margins
remain the full margins. The Student critical is7.58185668916078 atdf7 from
eight independent bundle vectors. Alpha remains0.01/(3*26), reserving the same
three-stage family. No unused alpha is repurposed. Native stability, phase,
blocking, rank/foldedRhat and ESS thresholds are byte-for-byte the original
manifest gates. Exact deterministic fit biases remain diagnostics, never
subtractions from fitted sample endpoints. Coarse-minus-finest bias intervals
are derived from the existing simultaneous finite-h intervals, adding no look.

The original comparator precedence is retained. Missing precision or numerical
and mixing eligibility gives UNRESOLVED. Eligible sufficiently precise
finite-h intervals wholly outside a margin give FAIL. Unestablished fit
adequacy/bias gives UNRESOLVED. Adequate continuum intervals wholly outside a
margin give FAIL. Only complete equivalence at all original requirements gives
PASS. Completed sampling alone cannot establish PASS. Execution failure is a
separate incomplete attempt, with the completed stage1UNRESOLVED ledger row
preserved. No ledger or publication is edited by this release.

Coverage is nominal Bonferroni familywise99percent conditional on approximate
normality of independent bundle contrasts. Extreme Student7tails and nonlinear
S2coverage are uncalibrated. Mixing and blocking are rejection diagnostics,
not proofs of equilibrium, independent bins or rare-tail coverage.64bins do
not create64independent bundle estimates. Stage2can honestly remainUNRESOLVED.

## Compute admission and morning deadline

The four sampler jobs run serially, one time step and all8bundles per job.
Each requests1CPU,3500MB and45/60/120/180minutes respectively on short.
The actual audited stage1API times by step are60.43,124.50,265.53,549.33seconds.
Conservative16x estimates are16.12,33.20,70.81,146.49minutes:266.61minutes
serial API time plus Julia startup and analysis. These are estimates, not
guarantees. The finest part has about20percent headroom below3hours. Caps
total6h45m plus10m analysis, leaving room within the root overnight allocation
for the separately budgeted P21work. No automatic extension or restart exists.

Root owns fresh global admission, the four-job afterok chain and a separate
analysis job afterany all four parts. Root must keep no more than2total running
CPUs/jobs including unrelated work and at most1new X01sampler concurrently.
Each wrapper also refuses native initialization if the running user CPU sum
exceeds2. No source file submits jobs or cancels unrelated work. If an earlier
part fails, root may cancel its unstarted dependent parts so analysis can
record the incomplete grid. This does not create a replacement scientific
look. A subsequent P21final job follows the X01analysis job and does not overlap.

The absolute sampler cutoff is2026-10-23T11:35:00Z, which is07:35EDT. At actual
job start each wrapper compares Unix wall time with the frozen cutoff. The
entire Julia initialization and kernel process gets the smaller of its
remaining standalone cap and cutoff-minus-current-time-minus10seconds.
Timeout sendsTERM and KILLafter2seconds, leaving8seconds before cutoff even
when TERMdoes not finish the process. The Julia adapter also checks the same
deadline before every native chain/node; a rejected new call closes the
aggregate with EXECUTION_ERROR. A forcible timeout retains all completed side
receipts and partial aggregate; it does not authorize completion or pooling.
The wrapper records actual start/end clocks, effective timeout, native exit,
own scontrol, time resources and every retained byte hash. No sampling can be
started by a job that begins too late.

Analysis is sampling-free and has an absolute deadline11:50UTC(07:50EDT), with
a10minute standalone cap, leaving the root final audit and Gmail handoff until
12:00UTC(08:00EDT). A late analysis job cannot postpone the handoff indefinitely.

## Full receipt grid and analysis identity

Root writes an immutable parts.json after the four admissions, before analysis:

```json
{"schema":"X01_STAGE2_PARTS_V1","stage_index":2,
 "source_freeze_sha256":"FROZEN_RECORD_SHA",
 "parts":[{"dtau_index":1,"job_id":"JOB1","result_dir":"ABSOLUTE_PART1_RESULT"},
          {"dtau_index":2,"job_id":"JOB2","result_dir":"ABSOLUTE_PART2_RESULT"},
          {"dtau_index":3,"job_id":"JOB3","result_dir":"ABSOLUTE_PART3_RESULT"},
          {"dtau_index":4,"job_id":"JOB4","result_dir":"ABSOLUTE_PART4_RESULT"}]}
```

Each part owns target.toml,8energy and32lambda side TOMLs, native.resources.txt,
process_exit_codes.txt, scontrol.txt and part_receipt.json. The merge verifies
all4distinct registered scheduler identities, exact per-part/global grids,
every retained hash, each source/seed/manifest pin and COMPLETED0:0before
copying160side files. It never reads stage1sample values. The final merged
target is explicitly attributed to an analysis-only job, with all4part_job_ids
retained and sampling_executed_by_this_job=false. Merge receipts bind all source
inputs and four scheduler receipts. The independent QuSpin oracle and unchanged
mathematical comparator then run only in that analysis job. A separate local
independent merge/statistical audit is mandatory before any ledger change.

Independent source review, native Julia actual scalar4096evaluation, bash
syntax, pinned numerical environment and actual short3h eligibility must pass
before root submits. The source archive/freeze are created only after review.
