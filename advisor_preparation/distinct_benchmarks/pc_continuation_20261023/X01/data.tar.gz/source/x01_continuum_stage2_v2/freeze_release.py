"""Freeze reviewed stage2 sources only; zero remote/scientific execution."""
import argparse,gzip,hashlib,io,json,tarfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--independent-review',type=Path,required=True);a=p.parse_args()
 review=json.loads(a.independent_review.read_text());assert review['status'] in ('APPROVED','APPROVED_SOURCE_NO_MATERIAL_BLOCKER')
 static=json.loads((HERE/'static_review.json').read_text());assert static['status']=='PASS'
 archive=HERE.parent/'x01-continuum-stage2-v2-source.tar.gz';record=HERE/'source_freeze.json';sums=HERE/'SHA256SUMS';assert not any(p.exists() for p in (archive,record,sums))
 files=sorted(p for p in HERE.iterdir() if p.is_file())
 assert all(b'\r' not in p.read_bytes() for p in files),'All frozen text must be LF bytes before checksumming'
 sums.write_bytes(''.join(sha(p)+'  '+p.name+'\n' for p in files).encode('utf-8'));files=sorted(files+[sums])
 assert b'\r' not in sums.read_bytes(),'Checksum filenames must not retain CR'
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w') as tar:
  for p in files:
   data=p.read_bytes();info=tarfile.TarInfo(HERE.name+'/'+p.name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 with archive.open('xb') as out:
  with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:gz.write(buffer.getvalue())
 data=dict(schema='X01_STAGE2_SOURCE_FREEZE_V1',release=HERE.name,stage_index=2,status='FROZEN_AFTER_INDEPENDENT_SOURCE_REVIEW_NOT_SUBMITTED',scientific_sampling=False,scientific_completions=0,archive=archive.name,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,files={p.name:sha(p) for p in files},independent_source_review_sha256=sha(a.independent_review),independent_source_review=str(a.independent_review.resolve()),sampler_cutoff_unix=1792755300,analysis_deadline_unix=1792756200,parts=4,serial_sampler_jobs=True,cpus_per_job=1,memory_mb=3500,part_wall_minutes=[45,60,120,180],analysis_wall_minutes=10,scientific_model_and_gates='Original stage1 fixed model/margins26CIs8units7df3-stagefamily unchanged; stage2 fresh262144rounds only; no pooling')
 with record.open('xb') as out:out.write((json.dumps(data,indent=2,sort_keys=True)+'\n').encode('utf-8'))
 print(json.dumps(dict(archive_sha256=data['archive_sha256'],source_freeze_sha256=sha(record),files=len(files))))
if __name__=='__main__':main()
