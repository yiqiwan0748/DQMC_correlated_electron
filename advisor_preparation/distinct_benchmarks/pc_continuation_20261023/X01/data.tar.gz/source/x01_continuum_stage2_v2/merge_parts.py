"""Strict four-part stage2 merge, no sampling and no scheduler submission."""
import argparse,datetime,hashlib,json,os,subprocess,time,tomllib,csv,io
from pathlib import Path
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def tomlvalue(v):
 if isinstance(v,dict):return '{'+', '.join(json.dumps(k)+' = '+tomlvalue(x) for k,x in v.items())+'}'
 if isinstance(v,list):return '['+', '.join(map(tomlvalue,v))+']'
 if isinstance(v,bool):return str(v).lower()
 return json.dumps(v,allow_nan=False)
def write_toml(p,obj):
 with p.open('x') as f:f.write('\n'.join(json.dumps(k)+' = '+tomlvalue(v) for k,v in obj.items())+'\n')
def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--parts-json',type=Path,required=True);p.add_argument('--result',type=Path,required=True);a=p.parse_args()
 cfg=tomllib.loads((a.source/'manifest.toml').read_text());reg=json.loads(a.parts_json.read_text());require(reg['schema']=='X01_STAGE2_PARTS_V1' and reg['stage_index']==2,'Wrong root admission registry')
 require(reg['source_freeze_sha256']==sha(a.source/'source_freeze.json'),'Registry/source freeze differs')
 parts=reg['parts'];require(len(parts)==4 and {r['dtau_index'] for r in parts}==set(range(1,5)) and len({r['job_id'] for r in parts})==4,'Exactly four distinct one-job-per-part registrations required')
 analysisjob=os.environ['SLURM_JOB_ID'];require(analysisjob not in {r['job_id'] for r in parts},'Analysis job cannot be a sampler job')
 inputs={str(a.parts_json.resolve()):sha(a.parts_json)};receipts={};metas=[];energy=[];nodes=[];elapsed=0.;files=[]
 for registered in sorted(parts,key=lambda r:r['dtau_index']):
  i=registered['dtau_index'];job=str(registered['job_id']);folder=Path(registered['result_dir'])
  require(folder.name==f'x01_continuum_stage2_v2_part{i}_{job}','Wrong isolated part result namespace')
  rp=folder/'part_receipt.json';receipt=json.loads(rp.read_text());inputs[str(rp)]=sha(rp);receipts[str(i)]=sha(rp)
  require(receipt['schema']=='X01_STAGE2_PART_RECEIPT_V1' and receipt['status']=='COMPLETE' and receipt['part_index']==i and receipt['job_id']==job and receipt['raw_job_id']==job and receipt['native_exit']==0,'Incomplete or wrong part receipt')
  require(receipt['source_freeze_sha256']==reg['source_freeze_sha256'] and receipt['manifest_sha256']==sha(a.source/'manifest.toml') and receipt['driver_sha256']==sha(a.source/'target_production.jl') and receipt['seeds_sha256']==sha(a.source/'seeds.toml') and receipt['source_hashes']==cfg['source_hashes'],'Part source closure differs')
  require(receipt['sampler_cutoff_unix']==cfg['sampler_cutoff_unix'] and receipt['actual_start_unix']<cfg['sampler_cutoff_unix']-cfg['deadline_guard_seconds'],'Late part cannot enter merge')
  raw=tomllib.loads((folder/'target.toml').read_text());meta=raw['metadata'];metas.append(meta)
  require(meta['job_id']==job and meta['part_index']==i and meta['stage_index']==2 and meta['phase']==cfg['phase'] and meta['source_hashes']==cfg['source_hashes'] and meta['manifest_sha256']==sha(a.source/'manifest.toml') and meta['seeds_sha256']==sha(a.source/'seeds.toml') and meta['adapter_sha256']==sha(a.source/'target_production.jl'),'Raw metadata source/part identity differs')
  require(raw['completion']['status']=='PRODUCTION_STAGE2_PART_COMPLETE' and raw['completion']['completed_calls']==40 and raw['completion']['errors']==[],'Part raw completion differs')
  require(receipt['actual_start_unix']<=raw['completion']['finished_unix']<=receipt['native_process_end_unix']<cfg['sampler_cutoff_unix'],'Completed sampling crosses absolute cutoff')
  require(0<receipt['effective_timeout_seconds']<=cfg['part_target_timeout_seconds'][i-1],'Invalid effective actual-start timeout')
  E,S=raw['energy_rows'],raw['entropy_node_rows'];require(len(E)==8 and {(r['dtau_index'],r['bundle']) for r in E}=={(i,b) for b in range(1,9)},'Missing/duplicate energy grid')
  require(len(S)==32 and {(r['dtau_index'],r['bundle'],r['lambda_index']) for r in S}=={(i,b,k) for b in range(1,9) for k in range(4)},'Missing/duplicate node grid')
  expected={'target.toml','native.resources.txt','process_exit_codes.txt','scontrol.txt'}
  for row in E+S:
   name=f'dt{i}_bundle{row["bundle"]}_'+('lambda'+str(row['lambda_index']) if 'lambda_index' in row else 'energy')+'.toml';expected.add(name)
   path=folder/name;require(tomllib.loads(path.read_text())==row,'Aggregate/side mismatch');files.append((name,path))
  require(set(receipt['input_sha256'])==expected,'Part exact full retained file grid differs')
  for name,want in receipt['input_sha256'].items():
   path=folder/name;require(path.is_file() and sha(path)==want,'Retained part bytes changed');inputs[str(path)]=want
  scheduler=subprocess.check_output(['sacct','-j',job,'--format=JobIDRaw,JobName,State,ExitCode,Elapsed,MaxRSS,ReqCPUS,ReqMem,Start,End','-P'],text=True)
  rows=list(csv.DictReader(io.StringIO(scheduler),delimiter='|'));mainrows=[r for r in rows if r['JobIDRaw']==job]
  require(len(mainrows)==1 and mainrows[0]['State']=='COMPLETED' and mainrows[0]['ExitCode']=='0:0' and mainrows[0]['ReqCPUS']=='1' and mainrows[0]['ReqMem']=='3500M','Part scheduler completion/resource differs')
  (a.result/f'part{i}.scheduler.txt').write_text(scheduler);inputs[str(a.result/f'part{i}.scheduler.txt')]=sha(a.result/f'part{i}.scheduler.txt')
  energy.extend(E);nodes.extend(S);elapsed+=raw['completion']['elapsed_seconds']
 require(len(energy)==32 and len(nodes)==128 and len(files)==160 and len({n for n,p in files})==160,'Merged global grid is incomplete')
 for key in ('manifest_sha256','seeds_sha256','adapter_sha256','source_hashes','julia_version','jdqmcframework_version','julia_threads','blas_threads','sampling'):
  require(all(m[key]==metas[0][key] for m in metas),'Cross-part metadata differs: '+key)
 meta=dict(metas[0]);meta.pop('part_index');meta.update(job_id=analysisjob,analysis_only_merge=True,sampling_executed_by_this_job=False,part_job_ids=[str(r['job_id']) for r in sorted(parts,key=lambda r:r['dtau_index'])],created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),attribution='Analysis-only merge of four distinct frozen native sampler jobs; no sampling by this job. Full stage2 alone, no prior-stage pooling.')
 merged=dict(metadata=meta,energy_rows=energy,entropy_node_rows=nodes,completion=dict(status='PRODUCTION_STAGE2_COMPLETE',scientific_completions=0,errors=[],elapsed_seconds=elapsed))
 write_toml(a.result/'target.toml',merged)
 for name,path in files:
  with (a.result/name).open('xb') as out:out.write(path.read_bytes())
 report=dict(schema='X01_STAGE2_MERGE_RECEIPT_V1',analysis_job_id=analysisjob,stage_index=2,scientific_sampling=False,scientific_completions=0,part_jobs={str(r['dtau_index']):str(r['job_id']) for r in parts},parts_json_sha256=sha(a.parts_json),part_receipts_sha256=receipts,source_freeze_sha256=reg['source_freeze_sha256'],all_input_sha256=inputs,merged_target_sha256=sha(a.result/'target.toml'),side_files_sha256={name:sha(a.result/name) for name,path in files},prior_stage_values_pooled=False)
 with (a.result/'merge_receipt.json').open('x') as out:json.dump(report,out,indent=2,sort_keys=True);out.write('\n')
 print('FULL_FOUR_PART_STAGE2_MERGED; zero sampling in analysis job; pending fixed comparator and independent audit')
if __name__=='__main__':main()
