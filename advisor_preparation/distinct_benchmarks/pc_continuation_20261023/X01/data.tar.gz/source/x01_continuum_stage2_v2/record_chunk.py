"""Record one stage2 part's retained bytes; analysis only, no submission."""
import argparse,hashlib,json,os,time,tomllib
from pathlib import Path
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--result',type=Path,required=True);p.add_argument('--part',type=int,required=True);p.add_argument('--native-exit',type=int,required=True);a=p.parse_args()
 cfg=tomllib.loads((a.source/'manifest.toml').read_text());target=a.result/'target.toml';raw=tomllib.loads(target.read_text()) if target.is_file() else {}
 meta=raw.get('metadata',{});complete=a.native_exit==0 and raw.get('completion',{}).get('status')=='PRODUCTION_STAGE2_PART_COMPLETE'
 data=dict(schema='X01_STAGE2_PART_RECEIPT_V1',status='COMPLETE' if complete else 'EXECUTION_INCOMPLETE',stage_index=2,part_index=a.part,
  job_id=os.environ['SLURM_JOB_ID'],native_exit=a.native_exit,manifest_sha256=sha(a.source/'manifest.toml'),driver_sha256=sha(a.source/'target_production.jl'),seeds_sha256=sha(a.source/'seeds.toml'),source_hashes=cfg['source_hashes'],
  source_freeze_sha256=sha(a.source/'source_freeze.json'),sampler_cutoff_unix=cfg['sampler_cutoff_unix'],actual_start_unix=int(os.environ['X01_PART_START_UNIX']),receipt_created_unix=time.time(),
  native_process_end_unix=float(os.environ['X01_PART_NATIVE_END_UNIX']),effective_timeout_seconds=int(os.environ.get('X01_EFFECTIVE_TIMEOUT_SECONDS','0')),
  raw_job_id=meta.get('job_id'),sampling_executed_by_this_job=target.is_file(),scientific_completions=0,
  input_sha256={f.name:sha(f) for f in sorted(a.result.iterdir()) if f.is_file() and f.name!='part_receipt.json'})
 out=a.result/'part_receipt.json'
 with out.open('x') as f:json.dump(data,f,indent=2,sort_keys=True);f.write('\n')
 print(data['status']+'; retained complete bytes; no scientific decision')
if __name__=='__main__':main()
