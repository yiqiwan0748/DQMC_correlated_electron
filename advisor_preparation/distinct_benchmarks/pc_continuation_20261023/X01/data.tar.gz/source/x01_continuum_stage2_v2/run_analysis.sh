#!/usr/bin/env bash
# Analysis-only helper; never calls Julia or a sampler.
set -uo pipefail
result=$1
python="$VALIDATION_ROOT/quspin-venv/bin/python"
/usr/bin/time -v -o "$result/merge.resources.txt" "$python" "$X01_STAGE2_SOURCE/merge_parts.py" \
 --source "$X01_STAGE2_SOURCE" --parts-json "$X01_STAGE2_PARTS_JSON" --result "$result"
merge_exit=$?
oracle_exit=125
comparator_exit=125
if (( merge_exit == 0 )); then
 /usr/bin/time -v -o "$result/oracle.resources.txt" timeout --signal=TERM --kill-after=2s 90 "$python" \
  "$X01_STAGE2_SOURCE/oracle_quspin.py" --manifest "$X01_STAGE2_SOURCE/manifest.toml" --output "$result/oracle.json"
 oracle_exit=$?
 if (( oracle_exit == 0 )); then
  /usr/bin/time -v -o "$result/comparator.resources.txt" timeout --signal=TERM --kill-after=2s 120 "$python" \
   "$X01_STAGE2_SOURCE/compare_production.py" --source "$X01_STAGE2_SOURCE" --native-root "$RENYI_ROOT" \
   --result-dir "$result" --target-exit-code 0 --oracle-exit-code 0 --output "$result/comparison.json"
  comparator_exit=$?
 fi
fi
printf 'merge_exit=%s\noracle_exit=%s\ncomparator_exit=%s\n' "$merge_exit" "$oracle_exit" "$comparator_exit" > "$result/process_exit_codes.txt"
if (( merge_exit != 0 || oracle_exit != 0 )); then exit 1; fi
exit "$comparator_exit"
