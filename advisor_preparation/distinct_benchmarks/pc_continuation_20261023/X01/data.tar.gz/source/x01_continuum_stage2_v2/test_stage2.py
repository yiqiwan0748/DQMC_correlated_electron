"""Deterministic protocol/source/algebra tests; no scientific sampling."""
import argparse,ast,hashlib,json,math,runpy,tomllib,re
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists()
 cfg=tomllib.loads((HERE/'manifest.toml').read_text());old=tomllib.loads((HERE.parent/'continuum_production_v1c/manifest.toml').read_text());checks={}
 checks['PythonAST']=all(isinstance(ast.parse(f.read_text()),ast.Module) for f in HERE.glob('*.py'))
 checks['allCodeConfigASCII']=all(f.read_bytes().isascii() for f in HERE.iterdir() if f.suffix in ('.py','.jl','.sh','.sbatch','.toml'))
 checks['allFrozenTextRawLF']=all(b'\r' not in f.read_bytes() for f in HERE.iterdir() if f.is_file())
 checks['sameScientificModel']=all(cfg[k]==old[k] for k in ('L','t','U','beta','mu_centered','mu_physical','boundary','nA','production_dtau','reference_dtau','bundles_per_dtau','bins','n_stab','lambda_indices','lambda_values','delta_lambda','cut_sites_one_based','source_hashes'))
 checks['allOriginalGatesIdentical']=cfg['gates']==old['gates']
 checks['statisticalAllocationIdentical']=all(cfg['statistics'][k]==old['statistics'][k] for k in ('independent_units','degrees_of_freedom','family_alpha','reserved_stages','intervals_per_stage','per_interval_two_sided_alpha','student_t_critical','fits','interval_grid','coverage'))
 checks['stage2FixedBudget']=cfg['stage_index']==2 and cfg['phase']=='X01_CONTINUUM_STAGE2' and cfg['measured_sweeps']==262144 and cfg['burn_sweeps']==2048 and cfg['measured_sweeps']//cfg['bins']==4096
 gen=runpy.run_path(str(HERE/'generate_seeds.py'));ex=tomllib.loads((HERE/'excluded_pilot_seeds.toml').read_text());checks['fresh288SeedRegenerationExact']=gen['contents'](cfg,ex).encode()==(HERE/'seeds.toml').read_bytes()
 checks['allPrior36BundlesExplicitlyExcluded']=len(ex['bundles'])==36
 cmp=runpy.run_path(str(HERE/'compare_production.py'));D=cmp['design'](cfg['production_dtau']);x=np.square(cfg['production_dtau']);checks['fitsPreserveLinearSpace']=all(abs(D[n]@(2+3*x)-2)<1e-12 for n in ('primary','fine','quartic'))
 checks['quarticPreservesQuadraticSpace']=abs(D['quartic']@(2+3*x+4*x*x)-2)<1e-12
 checks['StudentCriticalOriginal']=abs(cmp['t7_cdf'](cfg['statistics']['student_t_critical'])-(1-.01/(3*26)/2))<2e-14
 driver=(HERE/'target_production.jl').read_text();prior=(HERE.parent/'continuum_production_v1c/target_production.jl').read_text(encoding='utf-8')
 checks['nativeMeasurementFunctionsByteIdentical']=driver[driver.index('function energy_chain'):driver.index('function main()')]==prior[prior.index('function energy_chain'):prior.index('function main()')]
 checks['actualASCIIbinSizeToken']='bs=div(CFG["measured_sweeps"],B)' in driver
 checks['frozenAbsoluteDeadlines']=cfg['sampler_cutoff_unix']==1792755300 and cfg['analysis_deadline_unix']==1792756200 and cfg['deadline_guard_seconds']==10
 checks['fourWholeProcessTimeouts']=all('timeout --signal=TERM --kill-after=2s "$remaining"' in (HERE/f'chunk{i}.sbatch').read_text() and 'remaining=$((1792755300-now-10))' in (HERE/f'chunk{i}.sbatch').read_text() for i in range(1,5))
 checks['noNestedSubmission']=all(re.search(r'^\s*(?:sbatch|scancel)\s',f.read_text(),re.M) is None for f in HERE.iterdir() if f.suffix in ('.py','.sh','.sbatch','.jl'))
 checks['sameEightIndependentUnits']=cfg['bundles_per_dtau']==cfg['statistics']['independent_units']==8
 report=dict(schema='X01_STAGE2_STATIC_REVIEW_V1',status='PASS' if all(checks.values()) else 'FAIL',checks={k:bool(v) for k,v in checks.items()},scientific_sampling=False,remote_calls=False,jobs_submitted=0,manifest_sha256=hashlib.sha256((HERE/'manifest.toml').read_bytes()).hexdigest(),bins_per_chain=64,rounds_per_bin=4096)
 with a.output.open('xb') as out:out.write((json.dumps(report,indent=2,sort_keys=True)+'\n').encode('utf-8'))
 print(json.dumps(report));assert all(checks.values())
if __name__=='__main__':main()
