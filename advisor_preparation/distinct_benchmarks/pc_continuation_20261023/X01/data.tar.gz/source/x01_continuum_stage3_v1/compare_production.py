#!/usr/bin/env python3
"""Frozen X01 stage3 full-grid analysis; no sampling and no automatic ledger edit."""
import argparse,hashlib,json,math,statistics,sys,tomllib
from pathlib import Path
import numpy as np
from generate_seeds import contents
from mixing_diagnostics import diagnose,blocking_check

HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return tomllib.loads(Path(p).read_text()) if str(p).endswith('.toml') else json.loads(Path(p).read_text())
def finite(x):
    if isinstance(x,dict):return all(finite(v) for v in x.values())
    if isinstance(x,list):return all(finite(v) for v in x)
    return not isinstance(x,float) or math.isfinite(x)
def safe(x):
    if isinstance(x,dict):return {k:safe(v) for k,v in x.items()}
    if isinstance(x,list):return [safe(v) for v in x]
    if isinstance(x,float) and not math.isfinite(x):return str(x)
    return x
def jk(ns,ds,entropy=False):
    ns=np.asarray(ns,float);ds=np.asarray(ds,float)
    if ns.shape!=ds.shape or ns.ndim!=2 or not np.isfinite(ns).all() or not np.isfinite(ds).all():raise ValueError('Invalid paired-bin arrays')
    B=ns.shape[1];nt=ns.sum(axis=1);dt=ds.sum(axis=1)
    if B<2 or np.any(dt<=0) or np.any(dt[:,None]-ds<=0):raise ValueError('Invalid phase denominator')
    ratios=nt/dt;leave=(nt[:,None]-ns)/(dt[:,None]-ds)
    if entropy:
        if np.any(ratios<=0) or np.any(leave<=0):raise ValueError('Invalid entropy ratio')
        full=float(-np.log(ratios).sum());loo=-np.log(leave).sum(axis=0)
    else:
        if len(ns)!=1:raise ValueError('Scalar needs one stream')
        full=float(ratios[0]);loo=leave[0]
    avg=float(loo.mean())
    return dict(plug_in=full,bias_corrected=float(B*full-(B-1)*avg),
        standard_error=float(np.sqrt((B-1)/B*np.square(loo-avg).sum())),bins=B,
        leave_one_out_min=float(loo.min()),leave_one_out_max=float(loo.max()))
def merge(rows):
    a=np.asarray(rows,float);return a.reshape(a.shape[0],32,2).mean(axis=2)
def t7_cdf(t):
    z=math.atan(t/math.sqrt(7))
    return .5+(16/(5*math.pi))*(10*z+7.5*math.sin(2*z)+1.5*math.sin(4*z)+math.sin(6*z)/6)/32
def design(h):
    x=np.square(h);allx=np.column_stack([np.ones(4),x]);quart=np.column_stack([np.ones(4),x,x*x])
    full=np.linalg.pinv(allx);fine=np.zeros((2,4));fine[:,1:]=np.linalg.pinv(allx[1:])
    coarse=np.zeros((2,4));coarse[:,:3]=np.linalg.pinv(allx[:3])
    q=np.linalg.pinv(quart);I=np.eye(4)
    return dict(primary=full[0],fine=fine[0],quartic=q[0],
        primary_minus_fine=full[0]-fine[0],primary_minus_quartic=full[0]-q[0],
        residuals=I-allx@full,heldout_coarse=I[0]-allx[0]@fine,
        heldout_fine=I[3]-allx[3]@coarse)
def ci(values,critical):
    values=[float(v) for v in values]
    if len(values)!=8 or not all(math.isfinite(v) for v in values):raise ValueError('Exactly8 finite independent bundle contrasts required')
    mean=statistics.mean(values);se=statistics.stdev(values)/math.sqrt(8);hw=critical*se
    return dict(mean=mean,standard_error=se,halfwidth=hw,lower=mean-hw,upper=mean+hw,bundles=8,df=7)

def analyze(cfg,source,native,result,target_exit,oracle_exit):
    gates=[];hashes={};issues=[];intervals=[];mix=[];bundles=[]
    def check(name,ok,detail=None):
        gates.append(dict(name=name,eligible=bool(ok),detail=detail))
        if not ok:issues.append(name)
    def inp(p):
        p=Path(p)
        if not p.is_file():raise ValueError('Missing required file '+str(p))
        hashes[str(p)]=sha(p);return p
    def read(p):return load(inp(p))
    manifest=source/'manifest.toml';seeds=read(source/'seeds.toml');pilot=read(source/'excluded_pilot_seeds.toml')
    check('registered fixed stage and no automatic escalation',cfg['phase']=='X01_CONTINUUM_STAGE3' and cfg['stage_index']==3 and cfg['measured_sweeps']==288384 and cfg['burn_sweeps']==2048 and cfg['bins']==64 and cfg['bundles_per_dtau']==8 and cfg['automatic_escalation'] is False)
    check('integer-only seed regeneration exact',contents(cfg,pilot).encode()==(source/'seeds.toml').read_bytes())
    for name,want in cfg['source_hashes'].items():check('actual native source pin '+name,sha(inp(native/name))==want)
    raw,oracle=read(result/'target.toml'),read(result/'oracle.json')
    merge_receipt=read(result/'merge_receipt.json')
    check('explicit four-part analysis-only merge',merge_receipt.get('schema')=='X01_STAGE3_MERGE_RECEIPT_V1' and merge_receipt.get('scientific_sampling') is False and len(set(merge_receipt.get('part_jobs',{}).values()))==4 and raw.get('metadata',{}).get('analysis_only_merge') is True and raw['metadata'].get('sampling_executed_by_this_job') is False)
    meta,om=raw.get('metadata',{}),oracle.get('metadata',{})
    check('all raw target/oracle retained fields finite',finite(raw) and finite(oracle))
    check('both process exits zero',target_exit==oracle_exit==0)
    check('full native stage complete',raw.get('completion',{}).get('status')=='PRODUCTION_STAGE3_COMPLETE' and raw['completion'].get('errors')==[])
    check('same nonempty scheduler job',meta.get('job_id')==om.get('job_id') and meta.get('job_id') not in (None,'NONE','LOCAL'))
    check('target manifest/source/driver/seed closure',meta.get('manifest_sha256')==sha(inp(manifest)) and meta.get('adapter_sha256')==sha(inp(source/'target_production.jl')) and meta.get('seeds_sha256')==sha(source/'seeds.toml') and meta.get('source_hashes')==cfg['source_hashes'])
    check('target schema/phase and no automatic completion',meta.get('schema')==cfg['schema'] and meta.get('phase')==cfg['phase'] and meta.get('catalogue_id')=='X01' and meta.get('scientific_completions')==0)
    check('target pinned Julia/JDQMC/single threads',meta.get('julia_version')==cfg['julia_version'] and meta.get('jdqmcframework_version')==cfg['jdqmcframework_version'] and meta.get('julia_threads')==meta.get('blas_threads')==1)
    sampling_keys=('production_dtau','bundles_per_dtau','burn_sweeps','measured_sweeps','bins','n_stab','sweeps_per_measurement','lambda_indices','lambda_values','delta_lambda','cut_sites_one_based')
    check('target exact full-grid sampling configuration',meta.get('sampling')=={k:cfg[k] for k in sampling_keys})
    check('oracle pinned independent reference closure',om.get('phase')=='REFERENCE_ONLY' and om.get('scientific_completions')==0 and om.get('manifest_sha256')==sha(manifest) and om.get('adapter_sha256')==sha(inp(source/'oracle_quspin.py')) and om.get('versions')=={k:cfg[k+'_version'] for k in ('quspin','numpy','scipy')} and oracle.get('hilbert_dimension')==256)
    continuum_names={'physical_mu_centering_matrix_error','K_hermiticity_error','V_diagonal_error','continuum_eigen_residual','continuum_expm_error','continuum_rho_hermiticity_error','continuum_rho_eigenvalue_min','continuum_cut_eigenvalue_min','continuum_trace_error','continuum_cut_trace_error','continuum_half_filling_error'}
    finite_names={'transfer_similarity_error','transfer_eigen_residual','symmetric_transfer_hermiticity_error','symmetric_transfer_eigenvalue_min','direct_power_vs_similarity_rho_error','full_similarity_rho_error','cut_similarity_error','cut_purity_similarity_error','cut_S2_similarity_error','symmetric_rho_eigenvalue_min','symmetric_cut_eigenvalue_min','asymmetric_trace_error','asymmetric_cut_trace_error','symmetric_trace_error','symmetric_cut_trace_error','half_filling_error'}
    def diagnostics(name,rows,expected):
        check(name+' exact diagnostic key grid',set(rows)==expected)
        for key,value in rows.items():
            valid=isinstance(value,(float,int)) and math.isfinite(value)
            valid=valid and (value>=cfg['gates']['oracle_positive_eigenvalue_min'] if key.endswith('_min') else abs(value)<=cfg['gates']['oracle_matrix_abs'])
            check(name+' '+key,valid,value)
    diagnostics('continuum',oracle.get('diagnostics',{}),continuum_names)
    refs=oracle.get('finite_dtau',[])
    check('complete unique four-step exact reference grid',len(refs)==4 and [r['dtau'] for r in refs]==cfg['reference_dtau'])
    for row in refs:
        diagnostics('h='+str(row['dtau']),row['diagnostics'],finite_names)
        check('integer slice and positive complete oracle observables h='+str(row['dtau']),row['slices']==round(cfg['beta']/row['dtau']) and all(math.isfinite(row[mode][k]) for mode in ('asymmetric','symmetric') for k in ('physical_energy','S2','purity','trace','cut_trace','Nmean')) and row['asymmetric']['purity']>0 and row['symmetric']['purity']>0)
    er=raw.get('energy_rows',[]);sr=raw.get('entropy_node_rows',[])
    ek=[(r.get('dtau_index'),r.get('bundle')) for r in er];sk=[(r.get('dtau_index'),r.get('bundle'),r.get('lambda_index')) for r in sr]
    expected={(i,b) for i in range(1,5) for b in range(1,9)}
    check('complete unique32energy and128entropy-node grid',len(ek)==32 and set(ek)==expected and len(sk)==128 and set(sk)=={(i,b,k) for i,b in expected for k in range(4)})
    energies=dict(zip(ek,er));nodes=dict(zip(sk,sr));ys={'energy':np.zeros((8,4)),'S2':np.zeros((8,4))}
    hstreams={i:[] for i in range(1,5)}
    for seed in seeds['bundles']:
        i,b=seed['dtau_index'],seed['bundle'];E=energies.get((i,b),{});S=[nodes.get((i,b,k),{}) for k in range(4)]
        for kind,row,k in [('energy',E,None)]+[('lambda'+str(k),r,k) for k,r in enumerate(S)]:
            name=f'dt{i}_bundle{b}_{kind}';side=read(result/(name+'.toml'))
            check(name+' exact aggregate/individual receipt',side==row and bool(row))
            check(name+' complete configuration and native seed',row.get('status')=='COMPLETED' and row.get('dtau_index')==i and row.get('bundle')==b and row.get('dtau')==seed['dtau'] and (row.get('seed')==seed['energy_seed'] if k is None else row.get('root_seed')==seed['entropy_root_seed'] and [row.get('seed1'),row.get('seed2')]==seed['node_replica_seeds'][k] and row.get('lambda_index')==k and row.get('lambda_value')==cfg['lambda_values'][k] and row.get('delta_lambda')==.25 and row.get('cut_sites_one_based')==[1,2]))
            delta=row.get('cumulative_deltaG' if k is None else 'native_cumulative_deltaG')
            check(name+' cumulative native stability',isinstance(delta,(int,float)) and math.isfinite(delta) and 0<=delta<=cfg['gates']['cumulative_deltaG_max'],delta)
            check(name+' nondegenerate acceptance and positive runtime',cfg['gates']['acceptance_min_exclusive']<row.get('acceptance',-1)<cfg['gates']['acceptance_max_exclusive'] and math.isfinite(row.get('elapsed_seconds',float('nan'))) and row['elapsed_seconds']>0)
            for key in ('numerator_bins','denominator_bins')+(() if k is not None else ('N_numerator_bins',)):
                arr=row.get(key,[]);check(name+'64finite '+key,len(arr)==64 and all(isinstance(v,(float,int)) and math.isfinite(v) for v in arr))
            check(name+' positive-sign phase bins',len(row.get('denominator_bins',[]))==64 and all(abs(v-1)<=cfg['gates']['positive_phase_abs'] for v in row['denominator_bins']))
            if k is None:
                history=[row.get('deltaG_after_burnin')]+row.get('cumulative_deltaG_bins',[])
                check(name+' complete monotone cumulative history including burn',len(history)==65 and all(isinstance(v,(int,float)) and math.isfinite(v) and v>=0 for v in history) and all(x<=y for x,y in zip(history,history[1:])) and history[-1]==delta)
        en=[E['numerator_bins']];ed=[E['denominator_bins']];sn=[r['numerator_bins'] for r in S];sd=[r['denominator_bins'] for r in S]
        estimates={'energy':jk(en,ed),'S2':jk(sn,sd,True)}
        blocks={'energy':jk(merge(en),merge(ed)),'S2':jk(merge(sn),merge(sd),True)}
        for k in range(4):
            estimates['node'+str(k)]=jk([sn[k]],[sd[k]],True)
            blocks['node'+str(k)]=jk(merge([sn[k]]),merge([sd[k]]),True)
        for ob in estimates:
            bc=blocking_check(estimates[ob]['standard_error'],blocks[ob]['standard_error'],cfg['gates']['blocking_error_relative_change_max'])
            check(f'dt{i}_bundle{b}_{ob}64to32bin blocking',bc['eligible'],bc)
        for ob in ys:ys[ob][b-1,i-1]=estimates[ob]['bias_corrected']
        bundles.append(dict(dtau_index=i,bundle=b,dtau=seed['dtau'],estimates=estimates,merged32bin=blocks))
        hstreams[i].append(dict(bundle=b,en=np.array(en[0]),ed=np.array(ed[0]),sn=np.array(sn),sd=np.array(sd)))
    # Global ratio centering retains between-chain mean differences. Per-chain
    # self-centering would erase the very disagreement Rhat must detect.
    for i,streams in hstreams.items():
        streams.sort(key=lambda r:r['bundle'])
        sn=np.array([s['sn'] for s in streams]);sd=np.array([s['sd'] for s in streams])
        ratios=sn.sum(axis=(0,2))/sd.sum(axis=(0,2));mean_d=sd.mean(axis=(0,2))
        influence=-(sn-ratios[None,:,None]*sd)/(ratios[None,:,None]*mean_d[None,:,None])
        group={'energy':np.array([s['en']/s['ed'] for s in streams]),'S2':influence.sum(axis=1)}
        group.update({'node'+str(k):influence[:,k,:] for k in range(4)})
        for ob,chains in group.items():
            d=diagnose(chains,rhat_max=cfg['gates']['split_Rhat_max'],ess_min_per_chain=cfg['gates']['effective_bins_min_per_chain'],ess_min_total=cfg['gates']['effective_bins_min_total'])
            check(f'dt{i}_{ob}rank/foldedRhat and ESS rejection diagnostics',d['eligible'],d)
            mix.append(dict(dtau_index=i,observable=ob,diagnostics=d))
    critical=cfg['statistics']['student_t_critical'];alpha=cfg['statistics']['family_alpha']/(cfg['statistics']['reserved_stages']*cfg['statistics']['intervals_per_stage'])
    check('predeclared26interval3stage alpha and t7quantile',cfg['statistics']['intervals_per_stage']==26 and cfg['statistics']['reserved_stages']==3 and cfg['statistics']['degrees_of_freedom']==7 and abs(alpha-cfg['statistics']['per_interval_two_sided_alpha'])<1e-18 and abs(t7_cdf(critical)-(1-alpha/2))<2e-14)
    D=design(cfg['production_dtau']);adequacy=[];endpoint=[];finiteh=[];precision=[];bias=[];exactfits={};heldout_descriptive=[]
    def interval(name,values,margin,kind):
        row=ci(values,critical);inside=row['lower']>=-margin and row['upper']<=margin
        outside=row['upper']<-margin or row['lower']>margin
        item=dict(name=name,kind=kind,margin=margin,equivalent=inside,wholly_outside=outside,**row);intervals.append(item)
        return item
    for ob,Y in ys.items():
        margin=cfg['gates'][ob+'_margin'];key='physical_energy' if ob=='energy' else 'S2'
        y0=oracle['continuum'][key];ref=np.array([r['asymmetric'][key] for r in refs])
        exactfits[ob]={name:float(D[name]@ref-y0) for name in ('primary','fine','quartic')}
        exactfits[ob].update(heldout_coarse=float(D['heldout_coarse']@ref),heldout_fine=float(D['heldout_fine']@ref))
        check(ob+' exact deterministic fit family admissible',all(abs(exactfits[ob][name])<=margin/4 for name in ('primary','fine','quartic')),exactfits[ob])
        for name in ('primary','fine','quartic'):
            item=interval(ob+'_'+name+'_continuum',Y@D[name]-y0,margin,'endpoint');endpoint.append(item)
            precision.append(dict(name=item['name'],eligible=item['halfwidth']<=margin*cfg['gates']['endpoint_maximum_halfwidth_fraction'],halfwidth=item['halfwidth'],maximum=margin*.5))
        for name in ('primary_minus_fine','primary_minus_quartic'):
            adequacy.append(interval(ob+'_'+name,Y@D[name],margin*.5,'fit_stability'))
        for j in range(4):
            adequacy.append(interval(f'{ob}_primary_residual_h{j+1}',Y@D['residuals'][j],margin,'fit_residual'))
        own=[]
        for j in range(4):
            item=interval(f'{ob}_finite_h{j+1}',Y[:,j]-ref[j],margin,'finite_h');finiteh.append(item);own.append(item)
        for name in ('heldout_coarse','heldout_fine'):
            vals=[float(v) for v in Y@D[name]]
            heldout_descriptive.append(dict(observable=ob,contrast=name,mean=statistics.mean(vals),
                standard_error=statistics.stdev(vals)/math.sqrt(8),bundles=8,
                interpretation='Descriptive only; no acceptance interval, scientific gate or additional inferential claim.'))
        # Derived interval from existing simultaneous finite-h intervals, not
        # an uncounted new t interval or a lambda-quadrature correction.
        coarse_lo=own[0]['lower']+ref[0];coarse_hi=own[0]['upper']+ref[0]
        fine_lo=own[3]['lower']+ref[3];fine_hi=own[3]['upper']+ref[3]
        b=dict(observable=ob,lower=float(coarse_lo-fine_hi),upper=float(coarse_hi-fine_lo),exact_coarse_minus_finest=float(ref[0]-ref[3]),method='Minkowski difference of existing simultaneous intervals; no new statistical look')
        b['eligible']=b['upper']<0 and b['exact_coarse_minus_finest']<0;bias.append(b)
    check('complete exactly26predeclared interval grid',len(intervals)==26)
    eligible=not issues
    precision_ok=all(r['eligible'] for r in precision)
    adequate=all(r['equivalent'] for r in adequacy)
    finite_ok=all(r['equivalent'] for r in finiteh)
    endpoints_ok=all(r['equivalent'] for r in endpoint)
    bias_ok=all(r['eligible'] for r in bias)
    if not eligible or not precision_ok:status='UNRESOLVED'
    elif any(r['wholly_outside'] for r in finiteh):status='FAIL'
    elif not adequate or not bias_ok:status='UNRESOLVED'
    elif any(r['wholly_outside'] for r in endpoint):status='FAIL'
    elif finite_ok and endpoints_ok:status='PASS'
    else:status='UNRESOLVED'
    return dict(schema=cfg['schema'],scientific_status=status,catalogue_id='X01',catalogue_status='PENDING_INDEPENDENT_AUDIT',scientific_completions=0,
        interpretation='Fixed stage3 candidate scientific decision. No automatic ledger promotion; independent full raw/source/statistical audit required.',
        manifest_sha256=sha(manifest),comparator_sha256=sha(__file__),mixing_adapter_sha256=sha(source/'mixing_diagnostics.py'),input_sha256=hashes,
        job_id=meta['job_id'],eligibility_gates=gates,eligibility_issues=issues,bundles=bundles,mixing=mix,
        fit_design={k:v.tolist() for k,v in D.items()},exact_fit_diagnostics=exactfits,intervals=intervals,endpoint_precision=precision,derived_bias_detection=bias,heldout_descriptive=heldout_descriptive,
        decision_components=dict(raw_source_numerical_mixing_eligible=eligible,precision_adequate=precision_ok,fit_adequate=adequate,finite_h_equivalent=finite_ok,continuum_equivalent=endpoints_ok,finite_step_bias_demonstrated=bias_ok),
        statistical_design=cfg['statistics'],excluded_pilot=cfg['provenance'],
        limitations=['Only8independent top-level bundle vectors;64bins are not64additional independent chains.',
            'Nominal99percent familywise coverage is conditional on approximate normality of independent bundle contrasts; extreme Studentt7tails and nonlinearS2coverage are not calibrated.',
            'Rank/foldedRhat,ESS and64/32binblocking are rejection diagnostics, not equilibrium/mixing/rare-tail proofs.',
            'No finite-h bias is subtracted from sampled continuum endpoints; exact finite-h traces are diagnostics only.',
            'Native lambda power-increment ratios telescope exactly; no numerical quadrature bias is claimed.',
            'Thisstage3mayremainunderpowered; failed precision givesUNRESOLVED without changing margins; no stage1 pooling.',
            'No later stage, extra look, replacement, pooling or automatic resource extension is authorized by this output.'])

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=HERE);p.add_argument('--native-root',type=Path,required=True);p.add_argument('--result-dir',type=Path,required=True);p.add_argument('--target-exit-code',type=int,required=True);p.add_argument('--oracle-exit-code',type=int,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    if a.output.exists():raise ValueError('Use a new output')
    try:result=analyze(load(a.source/'manifest.toml'),a.source,a.native_root,a.result_dir,a.target_exit_code,a.oracle_exit_code)
    except Exception as ex:result=dict(schema='X01_CONTINUUM_STAGE3_V1',scientific_status='UNRESOLVED',catalogue_status='PENDING_INDEPENDENT_AUDIT',scientific_completions=0,error=type(ex).__name__+': '+str(ex),comparator_sha256=sha(__file__))
    a.output.write_text(json.dumps(safe(result),indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(result['scientific_status']+'; pending independent audit; zero automatic catalogue completions')
    if result['scientific_status']!='PASS':sys.exit(2)
if __name__=='__main__':main()
