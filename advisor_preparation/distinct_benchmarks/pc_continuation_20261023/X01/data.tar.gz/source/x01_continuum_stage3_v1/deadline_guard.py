"""Pure actual-start/suffix/whole-user queue qualification; no model imports."""
import argparse,hashlib,json,math,os,time,tomllib
from pathlib import Path
ACTIVE={'RUNNING','COMPLETING','CONFIGURING','SUSPENDED','RESIZING'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def qualify(cfg,part,start,now,queue,job):
 need(cfg['stage_index']==3 and cfg['release']=='x01_continuum_stage3_v1','Only frozen final stage3')
 need(cfg['part_wall_minutes']==[20,30,80,160] and cfg['serialized_suffix_seconds']==[17400,16200,14400,9600] and cfg['first_part_latest_start_unix']==1792737600,'Exact final full-grid caps/first-start limit')
 need(cfg['sampler_cutoff_unix']==1792755300 and cfg['analysis_deadline_unix']==1792756200 and cfg['deadline_guard_seconds']==10,'Exact absolute deadlines')
 rows=[r.split('|') for r in queue.splitlines() if r.strip()]
 need(1<=len(rows)<=2 and all(len(r)==3 and r[0].isdigit() and r[1] in ACTIVE and r[2].isdigit() and int(r[2])>0 for r in rows),'Fresh parseable active allocation snapshot')
 need(len({r[0] for r in rows})==len(rows) and sum(int(r[2]) for r in rows)<=2 and sum(r[0]==job and r[2]=='1' for r in rows)==1,'At most two whole-user active jobs/CPUs including this oneCPU job')
 need(isinstance(start,int) and isinstance(now,int) and 0<start<=now,'Actual batch/guard clock ordering')
 if part:
  need(part in (1,2,3,4),'Declared full-grid part')
  suffix=cfg['serialized_suffix_seconds'][part-1];cutoff=cfg['sampler_cutoff_unix']
  need(now+suffix<=cutoff,'Full remaining serialized science caps do not fit cutoff')
  if part==1:need(start<=cfg['first_part_latest_start_unix'] and now<=cfg['first_part_latest_start_unix'],'First native work must start by06:40UTC')
  owncap=cfg['part_target_timeout_seconds'][part-1]
 else:
  suffix=600;cutoff=cfg['analysis_deadline_unix'];owncap=560
  need(now+suffix<=cutoff,'Full10minute analysis cap does not fit finalization deadline')
 remaining=min(owncap-(now-start),cutoff-now-cfg['deadline_guard_seconds'])
 need(remaining>0,'No complete bounded process time remains')
 return dict(schema='X01_STAGE3_ACTUAL_START_GUARD_V1',part_index=part,job_id=job,actual_start_unix=start,checked_unix=now,serialized_suffix_seconds=suffix,absolute_cutoff_unix=cutoff,first_part_latest_start_unix=cfg['first_part_latest_start_unix'],effective_timeout_seconds=remaining,active_queue_snapshot=queue,whole_user_active_jobs=len(rows),whole_user_active_cpus=sum(int(r[2]) for r in rows),source_gate_changes=False)
def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--part',type=int,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--queue-file',type=Path,required=True);a=p.parse_args()
 cfg=tomllib.loads((a.source/'manifest.toml').read_text(encoding='utf-8'))
 r=qualify(cfg,a.part,int(os.environ['X01_PART_START_UNIX']),math.ceil(time.time()),a.queue_file.read_text(encoding='utf-8'),os.environ['SLURM_JOB_ID'])
 r['source_freeze_sha256']=hashlib.sha256((a.source/'source_freeze.json').read_bytes()).hexdigest()
 with a.output.open('xb') as f:f.write((json.dumps(r,indent=2,sort_keys=True)+'\n').encode('utf-8'))
 print(r['effective_timeout_seconds'])
if __name__=='__main__':main()
