#!/usr/bin/env python3
"""Integer-only preregistered seed namespace; no backend or sampler imports."""
import hashlib,json,tomllib
from pathlib import Path
MASK=(1<<64)-1
HERE=Path(__file__).resolve().parent
def derived_seed(root,k,rep):
    x=root^(((k+1)*0x9e3779b97f4a7c15)&MASK)^((rep*0xbf58476d1ce4e5b9)&MASK)
    z=(x+0x9e3779b97f4a7c15)&MASK
    z=((z^(z>>30))*0xbf58476d1ce4e5b9)&MASK
    z=((z^(z>>27))*0x94d049bb133111eb)&MASK
    return (z^(z>>31))%((1<<63)-1)
def contents(cfg,pilot):
    namespace=cfg['seed_namespace'];actual=[];labels=[]
    lines=['namespace = '+json.dumps(namespace),'algorithm = "SHA256 first8bytes big-endian masked63bits; unchanged native UInt64 derived_seed"','']
    oldactual=[r['energy_seed'] for r in pilot['bundles']]+[s for r in pilot['bundles'] for pair in r['node_replica_seeds'] for s in pair]
    oldlabels=[r[k] for r in pilot['bundles'] for k in ('energy_seed','entropy_root_seed')]
    for index,dt in enumerate(cfg['production_dtau'],1):
        for bundle in range(1,cfg['bundles_per_dtau']+1):
            def seed(stream):
                label=f'{namespace}|dtau_index={index}|bundle={bundle}|stream={stream}'
                value=int.from_bytes(hashlib.sha256(label.encode()).digest()[:8],'big')&((1<<63)-1)
                assert value>0;labels.append(value);return value
            energy,root=seed('energy'),seed('entropy')
            replicas=[[derived_seed(root,k,r) for r in (1,2)] for k in cfg['lambda_indices']]
            actual.extend([energy]+[x for pair in replicas for x in pair])
            lines.extend(['[[bundles]]',f'dtau_index = {index}',f'dtau = {dt!r}',f'bundle = {bundle}',f'energy_seed = {energy}',f'entropy_root_seed = {root}','node_replica_seeds = '+json.dumps(replicas),''])
    assert len(actual)==len(set(actual))==288 and min(actual)>0
    assert len(labels)==len(set(labels))==64
    assert not set(actual)&set(oldactual) and not set(labels)&set(oldlabels)
    assert not set(actual)&set(oldlabels) and not set(labels)&set(oldactual)
    return '\n'.join(lines)
def main():
    cfg=tomllib.loads((HERE/'manifest.toml').read_text(encoding='utf-8'));pilot=tomllib.loads((HERE/'excluded_pilot_seeds.toml').read_text(encoding='utf-8'))
    data=contents(cfg,pilot).encode();out=HERE/'seeds.toml'
    if out.exists():assert out.read_bytes()==data,'Frozen seeds differ'
    else:out.write_bytes(data)
    print('Verified288 disjoint actual initialization seeds;64 stream labels; excluded pilot/stage1/stage2 namespaces disjoint.')
if __name__=='__main__':main()
