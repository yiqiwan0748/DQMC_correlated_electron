#!/usr/bin/env julia
# Fixed X01 continuum stage3. Actual source kernels/native node runner unchanged.
using LinearAlgebra, TOML, SHA, Dates
BLAS.set_num_threads(1)
const HERE=@__DIR__
const CFGFILE=joinpath(HERE,"manifest.toml")
const CFG=TOML.parsefile(CFGFILE)
const SEEDFILE=joinpath(HERE,CFG["seed_file"])
const SEEDS=TOML.parsefile(SEEDFILE)
const ROOT=realpath(ENV["RENYI_ROOT"])
const OUTPUT=ENV["X01_PRODUCTION_OUTPUT"]
sha(p)=bytes2hex(sha256(read(p)))
CFG["phase"]=="X01_CONTINUUM_STAGE3"&&CFG["scientific_completion_allowed"]&&CFG["production_campaign_implemented"]||error("Registered continuum stage3 only")
CFG["production_dtau"]==[.25,.125,.0625,.03125]&&CFG["bundles_per_dtau"]==8&&CFG["measured_sweeps"]==288384&&CFG["burn_sweeps"]==2048&&CFG["bins"]==64||error("Unregistered production grid")
ispath(OUTPUT)&&error("Use a new output")
string(VERSION)==CFG["julia_version"]||error("Julia runtime mismatch")
const SOURCE_HASHES=Dict(rel=>sha(joinpath(ROOT,rel)) for rel in keys(CFG["source_hashes"]))
SOURCE_HASHES==CFG["source_hashes"]||error("Source/Project/Manifest pin differs before include")
module EnergySource
include(joinpath(Main.ROOT,"src/HubbardRenyiDQMC.jl"))
end
const H=EnergySource.HubbardRenyiDQMC
module NodeSource
include(joinpath(Main.ROOT,"run/run_lambda_node.jl"))
end
string(pkgversion(H.jdqmcf))==CFG["jdqmcframework_version"]||error("JDQMCFramework runtime version")

const PART=parse(Int,ENV["X01_PART_INDEX"])
1<=PART<=4||error("Invalid frozen part")
const CUTOFF=parse(Int,ENV["X01_SAMPLER_CUTOFF_UNIX"])
CUTOFF==CFG["sampler_cutoff_unix"]||error("Deadline differs from freeze")
guard()=time()<CUTOFF-CFG["deadline_guard_seconds"] ? nothing : error("SAMPLER_DEADLINE_REACHED")

function save_new(path,data)
    ispath(path)&&error("Receipt exists")
    mkpath(dirname(path));open(path,"w") do io;TOML.print(io,data);end
end
function append_row(key,row,filename)
    save_new(joinpath(dirname(OUTPUT),filename),row)
    open(OUTPUT,"a") do io;write(io,"\n");TOML.print(io,Dict(key=>[row]));end
end
function validate_seeds()
    SEEDS["namespace"]==CFG["seed_namespace"]||error("Seed namespace")
    expected=Set((i,b) for i in eachindex(CFG["production_dtau"]) for b in 1:8)
    rows=SEEDS["bundles"];Set((x["dtau_index"],x["bundle"]) for x in rows)==expected&&length(rows)==32||error("Incomplete/duplicate seeds")
    actual=Int[]
    for r in rows
        r["dtau"]==CFG["production_dtau"][r["dtau_index"]]||error("Seed/time-step mismatch")
        push!(actual,r["energy_seed"])
        for k in CFG["lambda_indices"],replica in 1:2
            derived=NodeSource.derived_seed(r["entropy_root_seed"],k,replica)
            derived==r["node_replica_seeds"][k+1][replica]||error("Native derived seed mismatch")
            push!(actual,derived)
        end
    end
    length(actual)==288&&length(unique(actual))==288&&all(>(0),actual)||error("Actual initialization seeds collide")
    nothing
end
function energy_chain(s)
    start=time();dt=s["dtau"];L=CFG["L"]
    r=H.initializer(CFG["t"],CFG["U"],CFG["mu_centered"],CFG["beta"],L,dt,s["energy_seed"];n_stab=CFG["n_stab"],boundary_condition=Symbol(CFG["boundary"]))
    deltaG=0.;acceptance=0.
    for _ in 1:CFG["burn_sweeps"]
        r,deltaG,a=H.update_replica!(r,deltaG);acceptance+=a
    end
    after_burn=deltaG;B=CFG["bins"];bs=div(CFG["measured_sweeps"],B)
    nums=zeros(B);dens=zeros(B);nnums=zeros(B);deltas=zeros(B)
    K=H.hubbard_chain_kinetic_matrix(CFG["t"],L,Symbol(CFG["boundary"]))
    for b in 1:B
        for _ in 1:bs
            # Pass the returned cumulative maximum into every following update.
            r,deltaG,a=H.update_replica!(r,deltaG);acceptance+=a
            cu=Matrix{Float64}(I,L,L)-transpose(r.Gup_00)
            cd=Matrix{Float64}(I,L,L)-transpose(r.Gdn_00)
            physical=real(tr(K*(cu+cd)))+CFG["U"]*sum(diag(cu).*diag(cd))
            phase=real(r.sgndetGup*r.sgndetGdn)
            nums[b]+=phase*physical;dens[b]+=phase;nnums[b]+=phase*sum(diag(cu)+diag(cd))
        end
        nums[b]/=bs;dens[b]/=bs;nnums[b]/=bs;deltas[b]=deltaG
    end
    Dict("status"=>"COMPLETED","dtau_index"=>s["dtau_index"],"dtau"=>dt,"bundle"=>s["bundle"],
        "seed"=>s["energy_seed"],"numerator_bins"=>nums,"denominator_bins"=>dens,"N_numerator_bins"=>nnums,
        "deltaG_after_burnin"=>after_burn,"cumulative_deltaG_bins"=>deltas,"cumulative_deltaG"=>deltaG,
        "acceptance"=>acceptance/(CFG["burn_sweeps"]+CFG["measured_sweeps"]),"elapsed_seconds"=>time()-start)
end
function entropy_node(s,k)
    config=(L=CFG["L"],t=CFG["t"],U=CFG["U"],mu=CFG["mu_centered"],beta=CFG["beta"],dtau=s["dtau"],
        n_stab=CFG["n_stab"],N_sweeps=CFG["sweeps_per_measurement"],boundary_condition=Symbol(CFG["boundary"]),
        nA=CFG["nA"],Ninc=CFG["lambda_increments"],S2_ED=NaN,N_burnin=CFG["burn_sweeps"],
        N_measurements=CFG["measured_sweeps"],N_bins=CFG["bins"])
    r=NodeSource.run_lambda_node_simulation(config,k,s["entropy_root_seed"])
    # r.deltaG is the native runner's cumulative maximum over both replicas/burn/measurements.
    Dict("status"=>"COMPLETED","dtau_index"=>s["dtau_index"],"dtau"=>s["dtau"],"bundle"=>s["bundle"],
        "lambda_index"=>r.lambda_index,"lambda_value"=>r.lambda_value,"delta_lambda"=>r.delta_lambda,
        "root_seed"=>r.root_seed,"seed1"=>r.seed1,"seed2"=>r.seed2,"cut_sites_one_based"=>r.C,
        "numerator_bins"=>r.avg_step_plus,"denominator_bins"=>r.avg_phase,
        "native_avg_den_bins"=>r.avg_den,"native_avg_num_bins"=>r.avg_num,
        "native_cumulative_deltaG"=>r.deltaG,"acceptance"=>r.acceptance,"elapsed_seconds"=>r.runtime,
        "native_plus_stats"=>Dict(string(k)=>v for (k,v) in pairs(r.plus_stats)))
end
function main()
    validate_seeds();guard();start=time();errors=String[];completed=0
    meta=Dict("schema"=>CFG["schema"],"phase"=>CFG["phase"],"catalogue_id"=>"X01","scientific_completions"=>0,
        "stage_index"=>3,"part_index"=>PART,"sampler_cutoff_unix"=>CUTOFF,
        "manifest_sha256"=>sha(CFGFILE),"seeds_sha256"=>sha(SEEDFILE),"adapter_sha256"=>sha(@__FILE__),
        "source_hashes"=>SOURCE_HASHES,"julia_version"=>string(VERSION),"jdqmcframework_version"=>string(pkgversion(H.jdqmcf)),
        "julia_threads"=>Threads.nthreads(),"blas_threads"=>BLAS.get_num_threads(),"job_id"=>get(ENV,"SLURM_JOB_ID","NONE"),
        "created_utc"=>string(now(UTC)),"source_root"=>ROOT,
        "sampling"=>Dict(k=>CFG[k] for k in ("production_dtau","bundles_per_dtau","burn_sweeps","measured_sweeps","bins","n_stab","sweeps_per_measurement","lambda_indices","lambda_values","delta_lambda","cut_sites_one_based")),
        "attribution"=>"Actual unchanged native kernels. This job samples only one declared h part; fresh stage3 seeds. No stage3 pooling.")
    save_new(OUTPUT,Dict("metadata"=>meta))
    try
        for s in filter(r->r["dtau_index"]==PART,SEEDS["bundles"])
            prefix="dt$(PART)_bundle$(s["bundle"])"
            guard();row=energy_chain(s);append_row("energy_rows",row,prefix*"_energy.toml");completed+=1
            for k in CFG["lambda_indices"]
                guard();row=entropy_node(s,k);append_row("entropy_node_rows",row,prefix*"_lambda$(k).toml");completed+=1
            end
            println("STAGE3_PART",PART," finished bundle ",s["bundle"]);flush(stdout)
        end
    catch ex
        push!(errors,sprint(showerror,ex));println(stderr,last(errors))
    end
    open(OUTPUT,"a") do io
        write(io,"\n");TOML.print(io,Dict("completion"=>Dict("status"=>isempty(errors)&&completed==40 ? "PRODUCTION_STAGE3_PART_COMPLETE" : "EXECUTION_ERROR",
            "scientific_completions"=>0,"completed_calls"=>completed,"finished_unix"=>time(),"elapsed_seconds"=>time()-start,"errors"=>errors)))
    end
    isempty(errors)&&completed==40||exit(1)
end
main()
