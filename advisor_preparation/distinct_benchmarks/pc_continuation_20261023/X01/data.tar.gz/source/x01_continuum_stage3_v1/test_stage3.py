"""Source, seed and refusal fixtures only; no scientific computation/import."""
import argparse,ast,hashlib,json,runpy,tomllib
from pathlib import Path
HERE=Path(__file__).resolve().parent
def normalized_comparator(path):
 tree=ast.parse(path.read_bytes())
 class Metadata(ast.NodeTransformer):
  def visit_Constant(self,node):
   if isinstance(node.value,str):node.value=node.value.replace('stage3','stage2').replace('STAGE3','STAGE2')
   elif node.value==288384:node.value=262144
   return node
  def visit_Compare(self,node):
   self.generic_visit(node)
   if isinstance(node.left,ast.Subscript) and isinstance(node.left.slice,ast.Constant) and node.left.slice.value=='stage_index':
    for value in node.comparators:
     if isinstance(value,ast.Constant) and value.value==3:value.value=2
   return node
 return ast.dump(Metadata().visit(tree))
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists()
 cfg=tomllib.loads((HERE/'manifest.toml').read_text(encoding='utf-8'));old=tomllib.loads((HERE.parent/'x01_continuum_stage2_v2/manifest.toml').read_text(encoding='utf-8'));checks={}
 checks['PythonAST']=all(isinstance(ast.parse(f.read_bytes()),ast.Module) for f in HERE.glob('*.py'))
 checks['RawLF']=all(b'\r' not in f.read_bytes() for f in HERE.iterdir() if f.is_file())
 checks['ASCIIcodeConfig']=all(f.read_bytes().isascii() for f in HERE.iterdir() if f.suffix in ('.py','.jl','.toml','.sh','.sbatch'))
 checks['FullModelAndGridUnchanged']=all(cfg[k]==old[k] for k in ('L','t','U','beta','mu_centered','mu_physical','boundary','nA','production_dtau','reference_dtau','bundles_per_dtau','bins','n_stab','lambda_indices','lambda_values','delta_lambda','cut_sites_one_based','source_hashes'))
 checks['AllAcceptanceGatesUnchanged']=cfg['gates']==old['gates']
 checks['All26CIStatisticalParametersUnchanged']=all(cfg['statistics'][k]==old['statistics'][k] for k in ('independent_units','degrees_of_freedom','family_alpha','reserved_stages','intervals_per_stage','per_interval_two_sided_alpha','student_t_critical','fits','interval_grid','coverage'))
 checks['FinalFreshBudget']=cfg['stage_index']==3 and cfg['phase']=='X01_CONTINUUM_STAGE3' and cfg['measured_sweeps']==288384 and cfg['burn_sweeps']==2048 and cfg['measured_sweeps']//cfg['bins']==4506 and cfg['final_reserved_stage'] is True
 gen=runpy.run_path(str(HERE/'generate_seeds.py'));ex=tomllib.loads((HERE/'excluded_pilot_seeds.toml').read_text(encoding='utf-8'))
 checks['Fresh288ActualAnd64RootLabels']=gen['contents'](cfg,ex).encode('utf-8')==(HERE/'seeds.toml').read_bytes()
 checks['AllPrior68BundlesExplicitlyExcluded']=len(ex['bundles'])==68 and ex['bundles']==tomllib.loads((HERE.parent/'x01_continuum_stage2_v2/excluded_pilot_seeds.toml').read_text(encoding='utf-8'))['bundles']+tomllib.loads((HERE.parent/'x01_continuum_stage2_v2/seeds.toml').read_text(encoding='utf-8'))['bundles']
 checks['FractionalActualClockRoundedConservatively']='math.ceil(time.time())' in (HERE/'deadline_guard.py').read_text(encoding='utf-8')
 checks['ReviewedComparatorMathASTUnchanged']=normalized_comparator(HERE/'compare_production.py')==normalized_comparator(HERE.parent/'x01_stage2_analysis_repair_v1/compare_production.py')
 driver=(HERE/'target_production.jl').read_text(encoding='utf-8');prior=(HERE.parent/'x01_continuum_stage2_v2/target_production.jl').read_text(encoding='utf-8')
 checks['NativeMeasurementFunctionsByteIdentical']=driver[driver.index('function energy_chain'):driver.index('function main()')]==prior[prior.index('function energy_chain'):prior.index('function main()')]
 checks['ReviewedMergeShadowFixRetained']='merge_receipt=read(' in (HERE/'compare_production.py').read_text(encoding='utf-8') and 'def merge(rows)' in (HERE/'compare_production.py').read_text(encoding='utf-8')
 guard=runpy.run_path(str(HERE/'deadline_guard.py'))['qualify'];queue='123|RUNNING|1\n';first=cfg['first_part_latest_start_unix'];now=first
 for i in range(1,5):
  start=cfg['sampler_cutoff_unix']-cfg['serialized_suffix_seconds'][i-1]-300
  checks[f'ValidFullSuffixPart{i}']=guard(cfg,i,start,start,queue,'123')['serialized_suffix_seconds']==cfg['serialized_suffix_seconds'][i-1]
 bad=[(1,first+1,first+1,queue),(2,cfg['sampler_cutoff_unix']-16200+1,cfg['sampler_cutoff_unix']-16200+1,queue),(3,cfg['sampler_cutoff_unix']-14400+1,cfg['sampler_cutoff_unix']-14400+1,queue),(4,cfg['sampler_cutoff_unix']-9600+1,cfg['sampler_cutoff_unix']-9600+1,queue)]
 bad += [(1,first,first,q) for q in ('','bad\n','123|RUNNING|0\n','123|BOGUS|1\n','123|RUNNING|1\n124|RUNNING|2\n','124|RUNNING|1\n','123|RUNNING|1\n123|RUNNING|1\n')]
 refused=0
 for part,start,clock,snapshot in bad:
  try:guard(cfg,part,start,clock,snapshot,'123')
  except ValueError:refused+=1
 checks['LateFirstMiddleAndInvalidQueueRefused']=refused==len(bad)
 final=cfg['analysis_deadline_unix']-600
 checks['AnalysisFull600Seconds']=guard(cfg,0,final,final,queue,'123')['serialized_suffix_seconds']==600
 try:guard(cfg,0,final+1,final+1,queue,'123');checks['LateAnalysisRefused']=False
 except ValueError:checks['LateAnalysisRefused']=True
 checks['WholeProcessNativeTimeouts']=all('timeout --signal=TERM --kill-after=2s "$X01_EFFECTIVE_TIMEOUT_SECONDS"' in (HERE/f'chunk{i}.sbatch').read_text(encoding='utf-8') for i in range(1,5))
 checks['ExternalFreezePinBeforeGuardImport']=all((HERE/f'chunk{i}.sbatch').read_text(encoding='utf-8').index('sha256sum source_freeze.json')<(HERE/f'chunk{i}.sbatch').read_text(encoding='utf-8').index('deadline_guard.py') for i in range(1,5))
 report=dict(schema='X01_STAGE3_SOURCE_STATIC_REVIEW_V1',status='PASS' if all(checks.values()) else 'FAIL',checks=checks,check_count=len(checks),queue_and_clock_refusal_fixtures=len(bad)+1,scientific_sampling=False,native_or_model_execution=False,remote_calls=False,first_part_latest_start_unix=first,manifest_sha256=hashlib.sha256((HERE/'manifest.toml').read_bytes()).hexdigest())
 with a.output.open('xb') as f:f.write((json.dumps(report,indent=2,sort_keys=True)+'\n').encode('utf-8'))
 print(json.dumps(report));assert all(checks.values())
if __name__=='__main__':main()
