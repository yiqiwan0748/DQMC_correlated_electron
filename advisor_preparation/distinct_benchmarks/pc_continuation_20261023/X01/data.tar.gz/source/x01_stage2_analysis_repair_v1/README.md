# X01 analysis-only mechanical repair candidate

UNFROZEN LOCAL PREPARATION. No actual-data replay, native/model computation,
sampling, statistical decision, source staging, job or ledger update is admitted
by this directory. Independent source review and a separately hash-pinned freeze
must precede any replay. Original source freeze4615a3c7... is immutable.

The original analysis job6460996 ended FAILED2:0 after native chunks and oracle
completed. Its frozen comparator raised `TypeError: 'dict' object is not callable`:
local variable `merge` containing merge_receipt.json shadowed global `merge(rows)`
at the first64to32-bin blocking call. The original error-only comparison and
failed independent audit are retained unchanged at their original paths and
their exact hashes are bound by repair_manifest.json.

The sole comparator edit renames that dictionary to `merge_receipt`: one AST
NameStore and three NameLoads. The global blocking function and all calls are
unchanged. mechanical_name_correction.diff and ast_equivalence.json prove this;
reverse-renaming those four identifiers restores the exact original full AST.
All other seven dependency files are byte-identical to the original freeze.
The copied Julia target and Python oracle are provenance dependencies only and
are NEVER executed by replay_analysis.py. The original manifest, seeds, fixed
budgets,26CI family, all scientific formulas and every gate remain unchanged.

After independent review, root freezes this separate repair source closure
(all files plus SHA256SUMS, excluding its own administrative source_freeze.json)
with release `x01_stage2_analysis_repair_v1`. Preserve the candidate, original
failures and all failed preflights. Root supplies the external repair freeze SHA.

Exact future replay command from campaign BASE, using a NEW result directory:

```powershell
python -B x01_stage2_analysis_repair_candidate_v1/replay_analysis.py --repair-freeze-sha256 APPROVED_REPAIR_FREEZE_SHA --original-release-dir x01_continuum_stage2_v2 --original-analysis-dir x01s2a_6460996 --native-source-dir x01s2p1_6460990/native_source --output-dir x01_stage2_analysis_repair_result_v1
```

If root copies the reviewed identical repair into a canonical frozen folder,
only replace the command's source-directory path, retaining the same approved
source bytes and release identity. Do not execute while the freeze pin is absent.

The driver reads the original COMPLETE analysis transfer and every one of its
original payload hashes, original parts mapc74263a1..., native6 pins, all160 side
receipts, complete aggregate/oracle, original failure and exit receipts. It
imports the corrected comparator only after the externally pinned repair source
and original-input closure pass. It writes only fresh comparison.json and
repair_receipt.json in a separate directory. All original input and repair source
hashes are checked again afterward. No previous data are pooled, no seeds are
replaced and this does not create another statistical look or catalogue count.

The repaired producer remains only a candidate decision. A separately versioned
independent full raw-math auditor must bind both original failure history and
this repair writer/source/output closure, rerun the SAME26CI, precision, mixing,
blocking, source and native-stability gates, and preserve the original failed
audit. Only after that audit may a separately reviewed append-only ledger
updater be considered. Original Slurm FAILED2:0 is never recast as scheduler
success. No source, CP, registry, ledger, queue or publication mutation is made
by the replay driver.
