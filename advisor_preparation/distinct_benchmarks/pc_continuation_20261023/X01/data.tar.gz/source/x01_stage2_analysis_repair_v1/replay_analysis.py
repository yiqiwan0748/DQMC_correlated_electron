#!/usr/bin/env python3
"""Guarded, separately frozen X01 postprocessing only; never sampling/model work."""
import argparse, datetime, hashlib, importlib.util, json, os, sys, time, tomllib
from pathlib import Path, PurePosixPath
sys.dont_write_bytecode=True
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
HERE=Path(__file__).resolve().parent

def need(ok,message):
    if not ok:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fresh(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode('utf-8')
    with path.open('xb') as out:out.write(raw);out.flush();os.fsync(out.fileno())

def source_closure(freeze_sha):
    freeze=HERE/'source_freeze.json'
    need(len(freeze_sha)==64 and sha(freeze)==freeze_sha,'Explicit approved repair freeze pin required before import or replay')
    f=json.loads(freeze.read_bytes());need(f['release']=='x01_stage2_analysis_repair_v1','Repair release identity')
    files=f['files'];need(isinstance(files,dict) and 'SHA256SUMS' in files and 'source_freeze.json' not in files,'Noncircular repair source inventory')
    actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p.name!='source_freeze.json'}
    need(actual==set(files),'Complete exact repair source inventory')
    for name,want in files.items():
        p=PurePosixPath(name);local=HERE/name
        need(len(p.parts)==1 and ':' not in name and '\\' not in name and not local.is_symlink() and sha(local)==want,'Repair source changed or unsafe: '+name)
    repair=json.loads((HERE/'repair_manifest.json').read_bytes())
    need(repair['analysis_only'] is True and repair['new_sampling'] is False and repair['new_statistical_look'] is False,'Analysis-only repair identity')
    need(all(sha(HERE/name)==want for name,want in repair['dependency_sha256'].items()),'Repaired dependencies differ')
    return repair,files

def inputs(a,repair):
    original=a.original_release_dir.resolve();analysis=a.original_analysis_dir.resolve();native=a.native_source_dir.resolve();output=a.output_dir.resolve()
    need(not output.exists() and output.parent.is_dir() and all(not output.is_relative_to(p) for p in (original,analysis,native,HERE)),'Fresh output outside every original/repair source and raw directory required')
    need(sha(original/'source_freeze.json')==repair['original_freeze_sha256'],'Original source freeze changed')
    original_freeze=json.loads((original/'source_freeze.json').read_bytes())
    need(all(sha(original/name)==want for name,want in original_freeze['files'].items()),'Original frozen source changed')
    need(sha(original/'compare_production.py')==repair['original_comparator_sha256'],'Original failed comparator changed')
    result=analysis/'results';failed=result/'comparison.json';failed_audit=analysis/'independent_audit_v1.json';parts=analysis/'submissions/parts.json'
    for path,want in ((analysis/'transfer.json',repair['original_analysis_transfer_sha256']),(failed,repair['original_failed_comparison_sha256']),(failed_audit,repair['original_failed_audit_sha256']),(parts,repair['original_parts_map_sha256'])):need(sha(path)==want,'Original failure/transfer/parts evidence changed: '+str(path))
    mapping=json.loads(parts.read_bytes());need([str(r['job_id']) for r in sorted(mapping['parts'],key=lambda r:r['dtau_index'])]==repair['original_part_job_ids'],'Original four-part identity')
    transfer=json.loads((analysis/'transfer.json').read_bytes());need(transfer['transfer_status']=='COMPLETE' and transfer['terminal_snapshot'] is True and str(transfer['job_id'])==repair['original_analysis_job_id'],'Complete original analysis transfer required')
    bound={}
    for row in transfer['files']:
        path=(analysis/row['local']).resolve();need(path.is_relative_to(analysis) and path not in bound and path.is_file() and not path.is_symlink(),'Unsafe or duplicate original receipt')
        need(row['status']=='RETRIEVED' and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],'Original transferred bytes changed')
        bound[path]=row['sha256']
    sides={result/f'dt{i}_bundle{b}_{kind}.toml' for i in range(1,5) for b in range(1,9) for kind in ['energy']+['lambda'+str(k) for k in range(4)]}
    need(len(sides)==160 and sides<=set(bound),'All160 original side receipts mandatory')
    for name,want in repair['native_source_sha256'].items():need(sha(native/name)==want,'Original native source pin changed: '+name)
    codes={k:int(v) for k,v in (line.split('=',1) for line in (result/'process_exit_codes.txt').read_text(encoding='utf-8').splitlines())}
    need(codes==dict(merge_exit=0,oracle_exit=0,comparator_exit=2,analysis_exit=2),'Original FAILED2 analysis provenance must remain explicit')
    error=json.loads(failed.read_bytes());need(error['error']=="TypeError: 'dict' object is not callable" and error['scientific_status']=='UNRESOLVED','Original comparator failure must remain preserved')
    for path in (original/'source_freeze.json',analysis/'transfer.json',failed,failed_audit,parts,analysis/'scheduler.txt',analysis/'scontrol.txt'):bound[path]=sha(path)
    bound.update({native/name:want for name,want in repair['native_source_sha256'].items()})
    return original,analysis,native,output,bound,codes

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repair-freeze-sha256',required=True);p.add_argument('--original-release-dir',type=Path,required=True);p.add_argument('--original-analysis-dir',type=Path,required=True);p.add_argument('--native-source-dir',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args()
    repair,files=source_closure(a.repair_freeze_sha256)
    original,analysis,native,output,bound,codes=inputs(a,repair)
    # Import only after complete approved repair and original-raw closure.
    sys.path.insert(0,str(HERE))
    spec=importlib.util.spec_from_file_location('x01_reviewed_analysis_repair',HERE/'compare_production.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    need(Path(module.__file__).resolve()==HERE/'compare_production.py','Unexpected comparator import')
    for name in ('generate_seeds','mixing_diagnostics'):need(Path(sys.modules[name].__file__).resolve()==HERE/(name+'.py'),'Unexpected dependency import')
    output.mkdir(exist_ok=False);started=time.time()
    try:
        cfg=tomllib.loads((HERE/'manifest.toml').read_text(encoding='utf-8'))
        result=module.analyze(cfg,HERE,native,analysis/'results',codes['merge_exit'],codes['oracle_exit'])
    except Exception as error:
        result=dict(schema='X01_ANALYSIS_REPAIR_ERROR_V1',scientific_status='UNRESOLVED',scientific_completions=0,error=type(error).__name__+': '+str(error),comparator_sha256=sha(HERE/'compare_production.py'))
    finished=time.time()
    need(all(sha(path)==want for path,want in bound.items()),'Original inputs changed during replay; do not adopt')
    need(all(sha(HERE/name)==want for name,want in files.items()),'Repair sources changed during replay; do not adopt')
    fresh(output/'comparison.json',module.safe(result))
    receipt=dict(schema='X01_ANALYSIS_ONLY_REPAIR_RECEIPT_V1',repair_release=repair['repair_release'],repair_freeze_sha256=a.repair_freeze_sha256,repair_writer_sha256=sha(__file__),repaired_comparator_sha256=sha(HERE/'compare_production.py'),original_comparator_sha256=repair['original_comparator_sha256'],original_freeze_sha256=repair['original_freeze_sha256'],original_analysis_job_id=repair['original_analysis_job_id'],original_part_job_ids=repair['original_part_job_ids'],original_failed_comparison_sha256=repair['original_failed_comparison_sha256'],original_failed_independent_audit_sha256=repair['original_failed_audit_sha256'],original_exit_codes=codes,source_sha256=files,input_sha256={str(k):v for k,v in sorted(bound.items(),key=lambda r:str(r[0]))},output_comparison_sha256=sha(output/'comparison.json'),started_unix=started,finished_unix=finished,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scientific_status=result['scientific_status'],scientific_completions=0,analysis_only=True,new_sampling=False,new_statistical_look=False,native_or_model_execution=False,remote_calls=False,original_inputs_unchanged=True,repair_sources_unchanged=True,independent_audit_required=True)
    fresh(output/'repair_receipt.json',receipt)
    print(json.dumps(dict(output=str(output),scientific_status=result['scientific_status'],independent_audit_required=True,scientific_completions=0)))
    return 0 if result['scientific_status']=='PASS' else 1 if result['scientific_status']=='FAIL' else 2
if __name__=='__main__':raise SystemExit(main())
