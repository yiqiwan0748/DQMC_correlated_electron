# X13 local candidate: charged thresholds and spectral visibility

This is unfrozen local preparation. It grants no execution, allocation, staging,
submission, ledger update or catalogue completion. The literal X13 criterion is:
"Match both thresholds and visibility weights; do not require an invisible state
to create a spectral peak." This is a finite exact-cluster test, not certification
of a native dynamical solver, Lanczos spectral convergence or a bulk limit.

The target imports only the unchanged native `analysis/compute_s2_ed.jl`, SHA256
`f8f94cfc13e11bb8b5e64e8ac8f4ade5ed3a13b3976c83b5ab5db89d86ba5f28`.
It calls `build_space` and `apply_hamiltonian!`. Materialization, charged-sector
enumeration, site/Fourier fermion operators and Lehmann extraction are explicitly
NEW adapters. Historical two-orbital spectral code is excluded. ITensors is not
imported. Full eigensystems, rather than iterative truncations, are retained.

The four fixed cases are L4, t1, U2/U4, PBC/APBC. Every spin block at N3,4,5 is
included (56,70,56 states; thirteen blocks per case). K=Hphysical-mu*N with
mu=U/2. The physical Hamiltonian is kinetic+U*double occupancy. Physical energies
are K+mu*N. The initial state is the uniform canonical *global* N4 ground
projector Pg/dg, including every degenerate ground vector in all spin blocks.
Neither backend selects a pure vector after observing degeneracy.

The canonical full Fock basis has index0=up_mask*16+down_mask, bit j=site j,
and ordered modes up0..up3,down0..down3. The new target annihilator uses lower
occupied modes for its parity, including all Nup for down-spin annihilation.
The reference independently builds QuSpin H and eight site annihilators. It
derives coordinates from QuSpin number-operator diagonals and obtains the signed
permutation from vacuum-to-state canonical creation strings, never from fitting
the target H or wavefunctions. Raw QuSpin coordinates, operators and bridge are
retained. Full CAR including cross-spin anticommutators must pass.

Every case has 32 channels: site j=0..3 or momentum m=0..3, both spins, addition
and removal. k=(2*pi*m+theta)/4, theta=0 for PBC and pi for APBC; only the wrap
bond carries the boundary sign. c_k=sum_j exp(-i*k*j)c_j/sqrt(4); addition uses
its exact adjoint. Complete final-state clusters, including zero weights, are
retained. Positive charged costs are K(N+/-1)-Kground. The plotted removal
frequency is the negative of its cost; addition frequency equals its cost.
The thermodynamic charged minimum and the lowest visible pole in a given
channel are reported separately. No hidden-state witness is required for PASS.

Energy clusters use complete diameter <=1e-8. Separate adjacent clusters must
have separation >=1e-6, otherwise the result is UNRESOLVED. The global N4 ground
cluster and all N3/N5 final clusters follow the same rule. Projector-summed
weights are Tr(Pg Odag Pe O)/dg. Ground eigenvector phases and rotations are
arbitrary: compare projectors and source covariance O Pg Odag/dg, not separately
diagonalized source columns. Native source vectors and all eigensystems remain
raw evidence and are checked against each backend's own basis.

All finite entries, coordinates, exact grids, source pins and complete receipts
are mandatory. H reconstruction, eigen residuals, orthogonality, CAR, occupation,
zeroth and first moments use 1e-10 absolute gates. Cross-backend energies,
projectors, source covariance, weights and thresholds use 1e-9. Nonnegative
weights allow only -1e-12 roundoff; invisible means weight<=1e-12, visible means
weight>=1e-9. A weight strictly between those limits gives UNRESOLVED. Occupation
and both add/remove zeroth moments are checked from Pg/dg; their sum is one per
normalized spatial mode. First cost moments are checked directly with
Odag(K-E0)O and from the full pole measure. Every group is required; no CI or
posthoc parameter selection is used.

Malformed/incomplete receipts, failed source/runtime pins, failed numerical
qualification, ambiguous degeneracy/visibility, timeout and execution failure
produce UNRESOLVED (or an administrative exception), never scientific FAIL.
Only numerically qualified complete receipts with cross-backend discrepancies
outside fixed tolerances yield FAIL. PASS requires full-grid agreement and all
qualifications. The frozen comparator is insufficient for ledger promotion:
an independently implemented receipt auditor and root review are mandatory.

The wrapper requests one CPU, 3500MB and 20 minutes. At its actual batch start
the full 1200 seconds must fit before 2026-10-23 11:35 UTC. An outer process-group
TERM/KILL covers module loading, interpreter startup and all numerical children.
An additional integer-clock rounding reserve makes the final kill strictly
earlier than actual-start+1200seconds and the science cutoff.
The cap guarantees termination, not completion; initialization is unmeasured.
No pilot estimates or partial X01/P21 results enter this design.

Before any execution: root and independent scientific/source review; preserve
all revisions and failed preflights; freeze all files with LF-only bytes and an
external hash; parse/import preflight without science; independent audit ready;
whole-user queue, serial dependency, exact remaining cap and deadline admission.
