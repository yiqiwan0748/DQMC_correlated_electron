# X13 source candidate - no execution admission

Read PROTOCOL.md and manifest.toml. This directory is UNFROZEN local preparation.
No science was run to choose its parameters or gates. A20-minute whole-process
cap is proposed; completion time is unmeasured. No pilot data are pooled.

The unchanged native ED source supplies Hamiltonian action and spin-sector bases.
All charged-sector/operator/Lehmann extraction here is a NEW explicit adapter.
Only QuSpin supplies the independent reference; target and reference are not
permitted to import each other's Hamiltonian or fermion implementation.

Raw schema `X13_CHARGED_SPECTRAL_RAW_V1` is target.toml/reference.json. Matrices
use rows,columns,real,imag with row-major flattened real/imag arrays. Sparse
operators use rows,columns,row0,column0,real,imag. Each case retains13complete
Hamiltonians/eigensystems/coordinate lists, complete global-sector energy
clusters, initial canonical ground ensemble, and32complete spectral channels.
The128channels include all zero-weight poles. Reference metadata retains raw
QuSpin integer states, occupation coordinates, site operators and a creation-
string-derived signed permutation. No arbitrary phase alignment is fitted.

`compare.py` independently checks each receipt's raw algebra, then compares
projectors/source covariances and degenerate weights. Its result cannot promote
X13 without a separately implemented raw receipt audit and root review.
Execution/integrity/qualification failure means UNRESOLVED, never a scientific
FAIL. Qualified cross-backend disagreement means FAIL; complete agreement PASS.

Local preparation checks only:

```powershell
python -B test_candidate.py
```

This test command uses synthetic algebra/source syntax only, no target native
Hamiltonian, QuSpin solver, sampling, submission or numerical case grid.

Before eventual execution: independent reviews and root approval, an immutable
source SHA256SUMS and source_freeze.json (files map exactly all eleven source files
plus SHA256SUMS), external freeze pin, native-three/source/archive closure,
syntax/import preflight, resource accounting, fresh actual queue inspection,
serial admission and independent auditor readiness. Failed preflights remain.
`candidate.sbatch` requires VALIDATION_ROOT, X13_SOURCE and the externally pinned
X13_EXPECTED_FREEZE_SHA256. It refuses actual starts with less than1200seconds
before2026-10-23T11:35Z, requests1CPU/3500M and limits the whole process group.

The runner records preflight.json, target/reference/comparator stdout/stderr and
GNUtime resources, per-process timing/exit receipts, execution.json and explicit
process_exit_codes.txt. A comparator exit1/2 can produce terminal FAILED despite
complete valid raw evidence. Preserve it and independently determine FAIL/U.
No ledger/checkpoint/email/publication helper is included here.
