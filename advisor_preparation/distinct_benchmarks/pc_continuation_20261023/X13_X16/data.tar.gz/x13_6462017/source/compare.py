#!/usr/bin/env python3
"""X13 fixed deterministic full-grid comparator; no sampler or ledger mutation."""
from __future__ import annotations
import argparse, hashlib, json, math, os, tomllib
from pathlib import Path
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from raw_io import SCHEMA, SOURCE_FILES, unpack, from_triplets, pack, coordinates, block_grid, block_key, cluster_records, channel_grid, mode_operator, sha, write_json_fresh

class Checks:
    def __init__(self):self.rows=[]
    def check(self,name,passed,detail=None):
        self.rows.append(dict(name=name,passed=bool(passed),detail=detail));return bool(passed)
    def close(self,name,a,b,tol):
        import numpy as np
        aa=np.asarray(a);bb=np.asarray(b)
        same=aa.shape==bb.shape
        error=float(np.max(np.abs(aa-bb),initial=0)) if same else None
        return self.check(name,same and error<=tol,dict(max_abs=error,tolerance=tol))
    @property
    def passed(self):return all(r['passed'] for r in self.rows)

def labels_from_weights(weights,gates):
    labels=[]
    for w in weights:
        if w<gates['negative_weight_min'] or not math.isfinite(w):labels.append('INVALID')
        elif w<=gates['invisible_max']:labels.append('INVISIBLE')
        elif w>=gates['visible_min']:labels.append('VISIBLE')
        else:labels.append('GRAY')
    return labels

def reconstructed_hamiltonian(site_c,case,cfg):
    from scipy.sparse import csr_matrix
    c=[csr_matrix(v) for v in site_c]; n=[a.conj().T@a for a in c]
    H=csr_matrix((256,256),dtype=complex)
    for j in range(4):
        k=(j+1)%4;s=-1 if case['boundary']=='apbc' and j==3 else 1
        for offset in (0,4):H-=cfg['t']*s*(c[offset+j].conj().T@c[offset+k]+c[offset+k].conj().T@c[offset+j])
        H+=case['U']*(n[j]@n[4+j])-case['mu']*(n[j]+n[4+j])
    return H.toarray()

def validate_backend(raw,cfg,folder,freeze_sha,backend):
    import numpy as np
    from scipy.sparse import csr_matrix,eye
    q=Checks();g=cfg['gates'];meta=raw['metadata']
    q.check('raw schema/backend/ensemble',raw['schema']==SCHEMA and meta['schema']==SCHEMA and meta['backend']==backend and meta['release']==cfg['release'] and meta['catalogue_id']=='X13' and meta['scientific_sampling'] is False and meta['initial_ensemble']==cfg['initial_ensemble'] and meta['fock_order']==cfg['fock_order'])
    q.check('complete before science cutoff',raw['completion']['status']=='COMPLETE' and math.isfinite(raw['completion']['finished_unix']) and raw['completion']['finished_unix']<cfg['science_cutoff_unix'])
    q.check('source and native metadata pins',meta['manifest_sha256']==sha(folder/'manifest.toml') and meta['source_freeze_sha256']==freeze_sha and meta['native_sha256']==cfg['native_sha256'] and meta['source_sha256']=={n:sha(folder/n) for n in SOURCE_FILES})
    versions=meta['versions'];expected={'julia':cfg['julia_version']} if backend=='native_ed_new_adapter' else {p:cfg[p+'_version'] for p in ('quspin','numpy','scipy')}
    q.check('exact backend versions',versions==expected)
    q.check('complete case labels', [c['case_id'] for c in raw['cases']]==[c['case_id'] for c in cfg['cases']])
    assert len(raw['site_annihilators'])==8
    site_c=[from_triplets(v) for v in raw['site_annihilators']]
    # Sparse full-Fock CAR includes every same/cross-species pair.
    cs=[csr_matrix(c) for c in site_c];ident=eye(256,format='csr',dtype=complex);carmax=0.
    for i in range(8):
        for j in range(8):
            for a in (cs[i]@cs[j]+cs[j]@cs[i],cs[i]@cs[j].conj().T+cs[j].conj().T@cs[i]-(ident if i==j else 0)):
                carmax=max(carmax,float(np.max(np.abs(a.data),initial=0)))
    q.check('full site CAR',carmax<=g['car_abs'],carmax)
    # Every raw operator is also checked against its physical mode/coordinate action.
    for mode,c in enumerate(site_c):
        expected=np.zeros((256,256),complex)
        for u,d in coordinates():
            occupied=[j for j in range(4) if u>>j&1]+[4+j for j in range(4) if d>>j&1]
            if mode not in occupied:continue
            new_u=u^(1<<mode) if mode<4 else u;new_d=d^(1<<(mode-4)) if mode>=4 else d
            expected[new_u*16+new_d,u*16+d]=(-1)**occupied.index(mode)
        q.close(f'canonical annihilator {mode}',c,expected,g['matrix_abs'])
    if backend=='independent_quspin':
        bridge=meta['quspin_bridge'];coords=bridge['raw_coordinates'];p=bridge['canonical_to_raw'];phase=np.asarray(bridge['phases_real'])+1j*np.asarray(bridge['phases_imag'])
        assert len(coords)==len(set(map(tuple,coords)))==len(p)==len(set(p))==256
        q.check('QuSpin raw state labels unique',len(bridge['raw_basis_states'])==len(set(bridge['raw_basis_states']))==256)
        T=np.zeros((256,256),complex)
        for i,(u,d) in enumerate(coordinates()):
            assert coords[p[i]]==[u,d];T[p[i],i]=phase[i]
        q.close('QuSpin bridge signed permutation',np.abs(phase),np.ones(256),g['matrix_abs'])
        qc=[from_triplets(v) for v in bridge['raw_site_annihilators']];vac=coords.index([0,0])
        for i,(u,d) in enumerate(coordinates()):
            v=np.zeros(256,complex);v[vac]=1
            occupied=[j for j in range(4) if u>>j&1]+[4+j for j in range(4) if d>>j&1]
            for mode in reversed(occupied):v=qc[mode].conj().T@v
            q.close(f'QuSpin creation string {i}',v,T[:,i],g['matrix_abs'])
        for i in range(8):q.close(f'QuSpin raw operator bridge {i}',T.conj().T@qc[i]@T,site_c[i],g['matrix_abs'])
    derived=[]
    for c,case in zip(raw['cases'],cfg['cases']):
        prefix=case['case_id'];q.check(prefix+' exact model',all(c[k]==case[k] for k in ('case_id','U','mu','boundary')))
        q.check(prefix+' complete spinblock grid',[r['block_key'] for r in c['blocks']]==[block_key(*v) for v in block_grid()])
        H=np.zeros((256,256),complex);vectors={};records={N:[] for N in (3,4,5)};values={}
        for row,(N,u,d) in zip(c['blocks'],block_grid()):
            key=block_key(N,u,d);coord=[(a,b) for a,b in coordinates() if a.bit_count()==u and b.bit_count()==d]
            q.check(prefix+' coordinates '+key,row['coordinates']==[list(v) for v in coord] and (row['N'],row['Nup'],row['Ndown'])==(N,u,d))
            ids=[a*16+b for a,b in coord];h=unpack(row['Hamiltonian']);v=unpack(row['eigenvectors']);e=np.asarray(row['eigenvalues'],float)
            assert h.shape==v.shape==(len(ids),len(ids)) and e.shape==(len(ids),) and np.all(np.isfinite(e))
            q.check(prefix+' sorted spectrum '+key,bool(np.all(np.diff(e)>=0)))
            q.close(prefix+' Hermitian '+key,h,h.conj().T,g['matrix_abs'])
            q.close(prefix+' eigen residual '+key,h@v,v*e,g['eigen_residual_abs'])
            q.close(prefix+' eigen orthogonality '+key,v.conj().T@v,np.eye(len(ids)),g['orthogonality_abs'])
            H[np.ix_(ids,ids)]=h
            for j,energy in enumerate(e):
                full=np.zeros(256,complex);full[ids]=v[:,j];vectors[key,j]=full;values[key,j]=float(energy)
                records[N].append(dict(energy=float(energy),block_key=key,eigen_index0=j))
        physical=reconstructed_hamiltonian(site_c,case,cfg)
        keep=[u*16+d for u,d in coordinates() if u.bit_count()+d.bit_count() in (3,4,5)]
        q.close(prefix+' physical H reconstruction',H[np.ix_(keep,keep)],physical[np.ix_(keep,keep)],g['matrix_abs'])
        if backend=='independent_quspin':q.close(prefix+' QuSpin raw H bridge',T.conj().T@from_triplets(c['raw_quspin_hamiltonian'])@T,physical,g['matrix_abs'])
        spectra={N:cluster_records(records[N],cfg) for N in (3,4,5)}
        q.check(prefix+' spectrum cluster totals',[(r['N'],sum(len(x['members']) for x in r['clusters'])) for r in c['sector_spectra']]==[(3,56),(4,70),(5,56)])
        for row in c['sector_spectra']:
            clusters=spectra[row['N']];q.check(prefix+f' cluster membership N{row["N"]}',[r['members'] for r in row['clusters']]==[r['members'] for r in clusters])
            for saved,new in zip(row['clusters'],clusters):
                q.close(prefix+' cluster energy fields',[saved[k] for k in ('energy','energy_min','energy_max')],[new[k] for k in ('energy','energy_min','energy_max')],g['matrix_abs'])
            q.check(prefix+f' cluster separated N{row["N"]}',all(x['energy_max']-x['energy_min']<=g['cluster_diameter_max'] for x in clusters) and all(b['energy_min']-a['energy_max']>=g['cluster_separation_min'] for a,b in zip(clusters,clusters[1:])))
        ground=spectra[4][0];G=np.column_stack([vectors[m['block_key'],m['eigen_index0']] for m in ground['members']]);dg=G.shape[1];E0=ground['energy'];P=G@G.conj().T
        q.check(prefix+' global canonical ground dimension',c['ground']['dimension']==dg)
        q.close(prefix+' ground values',[c['ground']['energy'],c['ground']['energy_physical']],[E0,E0+4*case['mu']],g['matrix_abs'])
        q.close(prefix+' ground individual energies',c['ground']['energies'],[values[m['block_key'],m['eigen_index0']] for m in ground['members']],g['matrix_abs'])
        saved_ground=unpack(c['ground']['vectors']);assert saved_ground.shape==G.shape
        q.close(prefix+' own ground orthogonality',saved_ground.conj().T@saved_ground,np.eye(dg),g['orthogonality_abs'])
        q.close(prefix+' own global ground projector',saved_ground@saved_ground.conj().T,P,g['matrix_abs'])
        # Any orthonormal basis of the declared Pg is valid; its saved sources
        # must use that same basis. No arbitrary eigenvector phase gate.
        G=saved_ground;P=G@G.conj().T
        descriptions=channel_grid(case['boundary']);q.check(prefix+' exact channel grid',[r['channel_id'] for r in c['channels']]==[r['channel_id'] for r in descriptions]);channels=[]
        for row,desc in zip(c['channels'],descriptions):
            label=prefix+'/'+desc['channel_id'];q.check(label+' descriptor',all(row[k]==desc[k] for k in ('channel_id','kind','index','spin','action')));q.close(label+' momentum',row['k'],desc['k'],g['matrix_abs'])
            O=mode_operator(site_c,desc);S=O@G;N=5 if desc['action']=='add' else 3;q.check(label+' final sector',row['final_N']==N)
            q.close(label+' own source columns',unpack(row['source_vectors']),S,g['matrix_abs'])
            poles=[]
            for cluster in spectra[N]:
                W=np.column_stack([vectors[m['block_key'],m['eigen_index0']] for m in cluster['members']]);weight=float(np.sum(np.abs(W.conj().T@S)**2)/dg);cost=cluster['energy']-E0
                poles.append(dict(energy=cluster['energy'],energy_physical=cluster['energy']+N*case['mu'],cost=cost,omega=cost if N==5 else -cost,weight=weight,multiplicity=len(cluster['members'])))
            q.check(label+' complete pole grid',len(row['poles'])==len(poles))
            for a,b in zip(row['poles'],poles):
                q.check(label+' multiplicity',a['multiplicity']==b['multiplicity'])
                q.close(label+' own pole measure',[a[k] for k in ('energy','energy_physical','cost','omega','weight')],[b[k] for k in ('energy','energy_physical','cost','omega','weight')],g['matrix_abs'])
            zero=float(np.sum(np.abs(S)**2)/dg);first=float(np.vdot(S,H@S-E0*S).real/dg);c_remove=mode_operator(site_c,dict(desc,action='remove'));occupation=float(np.sum(np.abs(c_remove@G)**2)/dg)
            q.close(label+' occupation',row['occupation'],occupation,g['occupation_abs'])
            q.close(label+' direct zeroth',row['zeroth_moment'],zero,g['zeroth_moment_abs'])
            q.close(label+' spectral zeroth',sum(p['weight'] for p in poles),zero,g['zeroth_moment_abs'])
            q.close(label+' occupation zeroth',zero,occupation if N==3 else 1-occupation,g['occupation_abs'])
            q.close(label+' direct first',row['cost_first_moment'],first,g['first_moment_abs'])
            q.close(label+' signed first',row['signed_first_moment'],first if N==5 else -first,g['first_moment_abs'])
            q.close(label+' spectral first',sum(p['cost']*p['weight'] for p in poles),first,g['first_moment_abs'])
            q.close(label+' charged minimum',row['charged_threshold'],poles[0]['cost'],g['matrix_abs'])
            visibility=labels_from_weights([p['weight'] for p in poles],g)
            saved_visibility=labels_from_weights([p['weight'] for p in row['poles']],g)
            q.check(label+' unambiguous visibility',all(v in ('VISIBLE','INVISIBLE') for v in visibility))
            q.check(label+' saved pole weights qualified',all(v in ('VISIBLE','INVISIBLE') for v in saved_visibility))
            q.check(label+' saved/reconstructed visibility exact',saved_visibility==visibility)
            visible=[p['cost'] for p,v in zip(poles,visibility) if v=='VISIBLE'];threshold=min(visible) if visible else None
            channels.append(dict(descriptor=desc,source_density=S@S.conj().T/dg,poles=poles,visibility=visibility,visible_threshold=threshold,charged_threshold=poles[0]['cost']))
        # Explicit paired add/remove rule for each normalized spatial mode.
        for i in range(0,32,2):q.close(prefix+' add/remove sum '+str(i),c['channels'][i]['zeroth_moment']+c['channels'][i+1]['zeroth_moment'],1.,g['zeroth_moment_abs'])
        derived.append(dict(case_id=prefix,H=H,ground_projector=P,ground_dimension=dg,channels=channels,all_eigenvalues={N:sorted(r['energy'] for r in records[N]) for N in (3,4,5)}))
    return q,dict(site_c=site_c,cases=derived)

def compare_raw(target,reference,cfg,folder,freeze_sha):
    q=Checks();tq,t=validate_backend(target,cfg,folder,freeze_sha,'native_ed_new_adapter');rq,r=validate_backend(reference,cfg,folder,freeze_sha,'independent_quspin');g=cfg['gates'];rows=[]
    if not tq.passed or not rq.passed:
        return dict(scientific_status='UNRESOLVED',qualification_checks={'target':tq.rows,'reference':rq.rows},cross_checks=[],channels=[],reason='Complete source/numerical/degeneracy/visibility qualification required before scientific comparison')
    for i in range(8):q.close('cross site annihilator '+str(i),t['site_c'][i],r['site_c'][i],g['matrix_abs'])
    for a,b in zip(t['cases'],r['cases']):
        prefix=a['case_id'];q.close(prefix+' cross H',a['H'],b['H'],g['matrix_abs']);q.check(prefix+' cross ground dimension',a['ground_dimension']==b['ground_dimension']);q.close(prefix+' cross ground projector',a['ground_projector'],b['ground_projector'],g['cross_projector_abs'])
        for N in (3,4,5):q.close(prefix+f' full energies N{N}',a['all_eigenvalues'][N],b['all_eigenvalues'][N],g['cross_energy_abs'])
        for x,y in zip(a['channels'],b['channels']):
            label=prefix+'/'+x['descriptor']['channel_id'];q.check(label+' cross descriptor',x['descriptor']==y['descriptor']);q.close(label+' cross source covariance',x['source_density'],y['source_density'],g['cross_source_density_abs']);q.check(label+' cross pole count',len(x['poles'])==len(y['poles']))
            for px,py in zip(x['poles'],y['poles']):
                q.check(label+' cross degeneracy',px['multiplicity']==py['multiplicity']);q.close(label+' cross pole energies',[px[k] for k in ('energy','cost','omega')],[py[k] for k in ('energy','cost','omega')],g['cross_energy_abs']);q.close(label+' cross weight',px['weight'],py['weight'],g['cross_weight_abs'])
            q.check(label+' cross visibility',x['visibility']==y['visibility']);q.close(label+' cross charged threshold',x['charged_threshold'],y['charged_threshold'],g['cross_threshold_abs'])
            if x['visible_threshold'] is None or y['visible_threshold'] is None:q.check(label+' cross empty visibility',x['visible_threshold'] is y['visible_threshold'])
            else:q.close(label+' cross visible threshold',x['visible_threshold'],y['visible_threshold'],g['cross_threshold_abs'])
            rows.append(dict(case_id=prefix,**x['descriptor'],charged_threshold=x['charged_threshold'],visible_threshold=x['visible_threshold'],visibility=x['visibility'],poles=x['poles'],hidden_lowest=x['visibility'][0]=='INVISIBLE'))
    return dict(scientific_status='PASS' if q.passed else 'FAIL',qualification_checks={'target':tq.rows,'reference':rq.rows},cross_checks=q.rows,channels=rows,complete_cases=4,complete_spinblocks_per_backend=52,complete_channels=128,scope='Finite exact native Hamiltonian/charged-adapter benchmark; no native dynamical solver or bulk claim')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--target',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--freeze-sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists()
    folder=a.manifest.resolve().parent;inputs={str(v.resolve()):sha(v) for v in (a.target,a.reference,a.manifest)}
    result=dict(schema='X13_CHARGED_SPECTRAL_COMPARISON_V1',catalogue_id='X13',scientific_status='UNRESOLVED',scientific_sampling=False,input_sha256=inputs)
    try:
        assert sha(folder/'source_freeze.json')==a.freeze_sha256
        cfg=tomllib.loads(a.manifest.read_text(encoding='utf-8'));target=tomllib.loads(a.target.read_text(encoding='utf-8'));reference=json.loads(a.reference.read_bytes())
        result.update(compare_raw(target,reference,cfg,folder,a.freeze_sha256))
    except Exception as e:result['administrative_error']=type(e).__name__+': '+str(e);result['scientific_status']='UNRESOLVED'
    assert inputs=={str(v.resolve()):sha(v) for v in (a.target,a.reference,a.manifest)},'raw inputs mutated'
    write_json_fresh(a.output,result)
    return 0 if result['scientific_status']=='PASS' else 1 if result['scientific_status']=='FAIL' else 2
if __name__=='__main__':raise SystemExit(main())
