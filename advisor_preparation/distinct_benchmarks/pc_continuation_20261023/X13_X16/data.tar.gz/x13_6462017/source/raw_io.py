"""New X13 raw representation and exact-grid adapter helpers; no native imports."""
from __future__ import annotations
import hashlib, json, math
from pathlib import Path

SCHEMA = "X13_CHARGED_SPECTRAL_RAW_V1"
SOURCE_FILES = ("manifest.toml", "PROTOCOL.md", "PROVENANCE.json", "raw_io.py", "target.jl", "reference.py", "compare.py", "run_candidate.py", "candidate.sbatch", "README.md", "test_candidate.py")

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def pack(a):
    import numpy as np
    a = np.asarray(a, dtype=complex)
    assert a.ndim == 2
    return dict(rows=a.shape[0], columns=a.shape[1], real=a.real.ravel().tolist(), imag=a.imag.ravel().tolist())

def unpack(a):
    import numpy as np
    r, c = a['rows'], a['columns']
    assert type(r) is int and type(c) is int and 0 <= r <= 256 and 0 <= c <= 256
    z = np.asarray(a['real'], dtype=float) + 1j*np.asarray(a['imag'], dtype=float)
    assert z.size == r*c and np.all(np.isfinite(z))
    return z.reshape(r, c)

def triplets(a):
    import numpy as np
    a = np.asarray(a, dtype=complex); r, c = np.nonzero(a)
    return dict(rows=a.shape[0], columns=a.shape[1], row0=r.tolist(), column0=c.tolist(), real=a[r,c].real.tolist(), imag=a[r,c].imag.tolist())

def from_triplets(a):
    import numpy as np
    r,c=a['rows'],a['columns']; assert r==c==256
    names=('row0','column0','real','imag'); assert len({len(a[k]) for k in names})==1
    z=np.zeros((r,c),complex); seen=set()
    for i,j,x,y in zip(*(a[k] for k in names)):
        assert type(i) is int and type(j) is int and 0<=i<r and 0<=j<c and (i,j) not in seen
        seen.add((i,j)); assert math.isfinite(x) and math.isfinite(y); z[i,j]=complex(x,y)
    return z

def coordinates(L=4):
    return [(u,d) for u in range(1<<L) for d in range(1<<L)]

def block_grid(L=4):
    return [(N,u,N-u) for N in (3,4,5) for u in range(L+1) if 0<=N-u<=L]

def block_key(N,u,d):
    return f'N{N}_up{u}_dn{d}'

def cluster_records(records, cfg):
    """Sort complete states; each cluster has bounded total diameter, never chaining."""
    records=sorted(records,key=lambda r:(r['energy'],r['block_key'],r['eigen_index0']))
    groups=[]
    for row in records:
        if not groups or row['energy']-groups[-1][0]['energy']>cfg['gates']['cluster_diameter_max']:
            groups.append([])
        groups[-1].append(row)
    out=[]
    for group in groups:
        energies=[r['energy'] for r in group]
        out.append(dict(energy=sum(energies)/len(energies),energy_min=min(energies),energy_max=max(energies),members=[dict(block_key=r['block_key'],eigen_index0=r['eigen_index0']) for r in group]))
    return out

def channel_grid(boundary,L=4):
    theta=0.0 if boundary=='pbc' else math.pi
    return [dict(channel_id=f'{kind}{index}_{spin}_{action}',kind=kind,index=index,spin=spin,action=action,k=(2*math.pi*index+theta)/L if kind=='k' else 0.0)
            for kind in ('site','k') for index in range(L) for spin in ('up','down') for action in ('remove','add')]

def mode_operator(site_c, channel, L=4):
    import numpy as np
    offset=0 if channel['spin']=='up' else L
    if channel['kind']=='site': c=site_c[offset+channel['index']]
    else: c=sum(np.exp(-1j*channel['k']*j)*site_c[offset+j] for j in range(L))/math.sqrt(L)
    return c.conj().T if channel['action']=='add' else c

def case_from_dense(H, site_c, case, cfg, extra=None):
    """Independent Python reference reduction; target uses separate Julia code."""
    import numpy as np
    from scipy.linalg import eigh
    coords=coordinates(); blocks=[]; bmap={}; vectors={}; sectors={}
    for N,u,d in block_grid():
        ids=[i for i,(a,b) in enumerate(coords) if a.bit_count()==u and b.bit_count()==d]
        h=H[np.ix_(ids,ids)]; e,v=eigh(h); key=block_key(N,u,d)
        row=dict(block_key=key,N=N,Nup=u,Ndown=d,coordinates=[list(coords[i]) for i in ids],Hamiltonian=pack(h),eigenvalues=e.tolist(),eigenvectors=pack(v))
        blocks.append(row); bmap[key]=row
        for j,energy in enumerate(e):
            full=np.zeros(256,complex);full[ids]=v[:,j];vectors[key,j]=full
            sectors.setdefault(N,[]).append(dict(energy=float(energy),block_key=key,eigen_index0=j))
    spectra=[dict(N=N,clusters=cluster_records(sectors[N],cfg)) for N in (3,4,5)]
    smap={s['N']:s['clusters'] for s in spectra}; gc=smap[4][0]; members=gc['members']
    G=np.column_stack([vectors[m['block_key'],m['eigen_index0']] for m in members]); dg=G.shape[1]; E0=gc['energy']
    ground=dict(dimension=dg,energy=E0,energy_physical=E0+4*case['mu'],energies=[bmap[m['block_key']]['eigenvalues'][m['eigen_index0']] for m in members],vectors=pack(G))
    channels=[]
    for desc in channel_grid(case['boundary']):
        O=mode_operator(site_c,desc); S=O@G; N=5 if desc['action']=='add' else 3
        measure=[]
        for cluster in smap[N]:
            W=np.column_stack([vectors[m['block_key'],m['eigen_index0']] for m in cluster['members']])
            weight=float(np.sum(np.abs(W.conj().T@S)**2)/dg); cost=cluster['energy']-E0
            measure.append(dict(energy=cluster['energy'],energy_physical=cluster['energy']+N*case['mu'],cost=cost,omega=cost if N==5 else -cost,weight=weight,multiplicity=len(cluster['members'])))
        zero=float(np.sum(np.abs(S)**2)/dg); first=float(np.vdot(S,H@S-E0*S).real/dg)
        c=mode_operator(site_c,dict(desc,action='remove')); occ=float(np.sum(np.abs(c@G)**2)/dg)
        channels.append(dict(desc,source_vectors=pack(S),final_N=N,occupation=occ,zeroth_moment=zero,cost_first_moment=first,signed_first_moment=first if N==5 else -first,charged_threshold=measure[0]['cost'],poles=measure))
    result=dict(case_id=case['case_id'],U=case['U'],mu=case['mu'],boundary=case['boundary'],blocks=blocks,sector_spectra=spectra,ground=ground,channels=channels)
    if extra: result.update(extra)
    return result

def source_metadata(folder, cfg, freeze_sha):
    folder=Path(folder)
    assert len(freeze_sha)==64 and sha(folder/'source_freeze.json')==freeze_sha
    return dict(schema=SCHEMA,release=cfg['release'],catalogue_id='X13',manifest_sha256=sha(folder/'manifest.toml'),source_freeze_sha256=freeze_sha,source_sha256={name:sha(folder/name) for name in SOURCE_FILES},native_sha256=cfg['native_sha256'],scientific_sampling=False,initial_ensemble=cfg['initial_ensemble'],fock_order=cfg['fock_order'])

def write_json_fresh(path,obj):
    raw=(json.dumps(obj,ensure_ascii=True,allow_nan=False,indent=2)+'\n').encode('utf-8')
    with Path(path).open('xb') as f:f.write(raw)
