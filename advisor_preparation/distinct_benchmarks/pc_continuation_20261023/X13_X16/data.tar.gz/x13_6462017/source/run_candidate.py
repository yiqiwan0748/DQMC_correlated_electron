#!/usr/bin/env python3
"""Frozen X13 execution receipt driver. No queue submission or ledger changes."""
import argparse, datetime, json, os, re, subprocess, sys, time, tomllib
from pathlib import Path
from raw_io import SOURCE_FILES, sha, write_json_fresh

def validate_active_queue(text, job_id):
    """Fail closed on every malformed/missing/ambiguous active queue row."""
    assert re.fullmatch(r'[0-9]+',str(job_id)), 'numeric own job identity required'
    assert isinstance(text,str) and text.strip() and '\0' not in text, 'active queue unavailable/empty'
    rows=[];seen=set();active={'RUNNING','COMPLETING','CONFIGURING','SUSPENDED','RESIZING'}
    for line in text.splitlines():
        parts=line.split('|')
        assert len(parts)==3, 'malformed active queue row'
        identity,state,cpus=(p.strip() for p in parts)
        assert re.fullmatch(r'[0-9]+(?:_[0-9]+)?',identity) and identity not in seen, 'unparsed/duplicate active job'
        assert state in active and re.fullmatch(r'[1-9][0-9]*',cpus), 'unknown state or nonpositive/noninteger CPU count'
        seen.add(identity);rows.append(dict(job_id=identity,state=state,cpus=int(cpus)))
    assert 1<=len(rows)<=2 and sum(r['cpus'] for r in rows)<=2, 'whole-user job/CPU guard'
    own=[r for r in rows if r['job_id']==str(job_id)]
    assert len(own)==1 and own[0]['cpus']==1, 'own one-CPU job absent or ambiguous'
    return dict(schema='X13_ACTIVE_QUEUE_GUARD_V1',status='PASS',rows=rows,active_jobs=len(rows),active_cpus=sum(r['cpus'] for r in rows))

def prepare(source,root,output,freeze_sha,batch_start):
    cfg=tomllib.loads((source/'manifest.toml').read_text(encoding='utf-8'))
    assert not output.exists() and output.parent.is_dir()
    assert int(os.environ['SLURM_CPUS_PER_TASK'])==1
    assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','JULIA_NUM_THREADS'))
    assert 0<=time.time()-batch_start<cfg['wall_cap_seconds']-cfg['termination_guard_seconds']
    assert batch_start+cfg['wall_cap_seconds']<=cfg['science_cutoff_unix']
    assert sha(source/'source_freeze.json')==freeze_sha
    freeze=json.loads((source/'source_freeze.json').read_bytes());files=freeze['files']
    assert isinstance(files,dict) and set(files)==set(SOURCE_FILES)|{'SHA256SUMS'}
    assert all(sha(source/name)==digest for name,digest in files.items())
    sums={}
    for line in (source/'SHA256SUMS').read_text(encoding='ascii').splitlines():
        digest,name=line.split('  ',1);assert name not in sums and name in SOURCE_FILES;sums[name]=digest
    assert set(sums)==set(SOURCE_FILES) and all(sums[n]==files[n] for n in SOURCE_FILES)
    assert all(b'\r' not in (source/n).read_bytes() for n in files)
    native=root/'source/renyi_disjoint_corrected'
    pins={cfg['native_relative_path']:cfg['native_sha256'],'Project.toml':cfg['native_project_sha256'],'Manifest.toml':cfg['native_manifest_sha256']}
    assert all(sha(native/name)==digest for name,digest in pins.items())
    return cfg,native,files,pins

def run(source,root,output,freeze_sha,batch_start):
    cfg,native,files,pins=prepare(source,root,output,freeze_sha,batch_start)
    queue=validate_active_queue(os.environ['X13_ACTIVE_QUEUE_SNAPSHOT'],os.environ['SLURM_JOB_ID'])
    output.mkdir(exist_ok=False)
    os.environ['RENYI_ROOT']=str(native)
    receipt=dict(schema='X13_EXECUTION_RECEIPT_V1',job_id=os.environ['SLURM_JOB_ID'],release=cfg['release'],catalogue_id='X13',status='STARTED',source_freeze_sha256=freeze_sha,source_sha256=files,native_source_sha256=pins,actual_batch_start_unix=batch_start,worker_start_unix=time.time(),cap_end_unix=batch_start+cfg['wall_cap_seconds'],science_cutoff_unix=cfg['science_cutoff_unix'],termination_guard_seconds=cfg['termination_guard_seconds'],cpus=1,memory_mb=3500,scientific_sampling=False,new_adapter=True,process_group_id=os.getpgrp(),active_queue_snapshot=os.environ['X13_ACTIVE_QUEUE_SNAPSHOT'],active_queue_guard=queue,threads={k:os.environ[k] for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','JULIA_NUM_THREADS')},processes=[],process_exit_codes={})
    write_json_fresh(output/'preflight.json',receipt)
    with (output/'scontrol.txt').open('wb') as f:subprocess.run(['scontrol','show','job',os.environ['SLURM_JOB_ID']],stdout=f,stderr=subprocess.STDOUT,check=False)
    manifest=str(source/'manifest.toml'); common=['--manifest',manifest,'--freeze-sha256',freeze_sha]
    commands=[('target',[str(root/'runtime/julia-1.12.1/bin/julia'),'--startup-file=no','--history-file=no','--project='+str(native),str(source/'target.jl')]+common+['--output',str(output/'target.toml')]),('reference',[sys.executable,'-B',str(source/'reference.py')]+common+['--output',str(output/'reference.json')]),('comparator',[sys.executable,'-B',str(source/'compare.py')]+common+['--target',str(output/'target.toml'),'--reference',str(output/'reference.json'),'--output',str(output/'comparison.json')])]
    code=2
    for name,command in commands:
        assert time.time()<min(cfg['science_cutoff_unix'],batch_start+cfg['wall_cap_seconds']-cfg['termination_guard_seconds'])
        assert all(sha(source/n)==d for n,d in files.items())
        start=time.time()
        with (output/(name+'.stdout.txt')).open('xb') as out,(output/(name+'.stderr.txt')).open('xb') as err:
            # Inherit outer timeout's process group: do not setsid/start_new_session.
            completed=subprocess.run(['/usr/bin/time','-v','-o',str(output/(name+'.resources.txt'))]+command,stdout=out,stderr=err,check=False)
        end=time.time();code=completed.returncode
        receipt['processes'].append(dict(name=name,command=command,start_unix=start,end_unix=end,exit_code=code,process_group_inherited=True))
        receipt['process_exit_codes'][name]=code
        write_json_fresh(output/(name+'.process.json'),receipt['processes'][-1])
        if name!='comparator' and code!=0:break
    receipt.update(status='PROCESSES_COMPLETE' if set(receipt['process_exit_codes'])=={'target','reference','comparator'} else 'EXECUTION_ERROR',finished_unix=time.time(),source_unchanged=all(sha(source/n)==d for n,d in files.items()),native_unchanged=all(sha(native/n)==d for n,d in pins.items()))
    receipt['output_sha256']={p.name:sha(p) for p in sorted(output.iterdir()) if p.is_file()}
    write_json_fresh(output/'execution.json',receipt)
    with (output/'process_exit_codes.txt').open('x',encoding='ascii',newline='\n') as f:
        for name in ('target','reference','comparator'):f.write(name+'_exit='+str(receipt['process_exit_codes'].get(name,'NOT_RUN'))+'\n')
    # Comparator 1 is a qualified scientific FAIL; 2 is UNRESOLVED. Both retained.
    return code if receipt['status']=='PROCESSES_COMPLETE' else 2

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check-queue',action='store_true');p.add_argument('--job-id');p.add_argument('--source',type=Path);p.add_argument('--validation-root',type=Path);p.add_argument('--output',type=Path);p.add_argument('--freeze-sha256');p.add_argument('--batch-start-unix',type=float);a=p.parse_args()
    if a.check_queue:
        assert a.job_id and all(v is None for v in (a.source,a.validation_root,a.output,a.freeze_sha256,a.batch_start_unix))
        print(json.dumps(validate_active_queue(sys.stdin.read(),a.job_id),sort_keys=True));return 0
    assert a.source is not None and a.validation_root is not None and a.output is not None and a.freeze_sha256 and a.batch_start_unix is not None and a.job_id is None
    return run(a.source.resolve(),a.validation_root.resolve(),a.output.resolve(),a.freeze_sha256,a.batch_start_unix)
if __name__=='__main__':raise SystemExit(main())
