#!/usr/bin/env julia
# NEW exact charged/operator adapter through unchanged native Hamiltonian action.
using LinearAlgebra, TOML, SHA
BLAS.set_num_threads(1)
length(ARGS)%2==0 || error("option/value arguments required")
const OPT=Dict(ARGS[i]=>ARGS[i+1] for i in 1:2:length(ARGS))
const MANIFEST=abspath(OPT["--manifest"])
const RELEASE=dirname(MANIFEST)
const CFG=TOML.parsefile(MANIFEST)
const OUTPUT=abspath(OPT["--output"])
const FREEZE=OPT["--freeze-sha256"]
ispath(OUTPUT) && error("fresh output required")
sha(path)=bytes2hex(sha256(read(path)))
sha(joinpath(RELEASE,"source_freeze.json"))==FREEZE || error("freeze pin")
const NATIVE_ROOT=abspath(ENV["RENYI_ROOT"])
const NATIVE=joinpath(NATIVE_ROOT,CFG["native_relative_path"])
sha(NATIVE)==CFG["native_sha256"] || error("native source pin")
string(VERSION)==CFG["julia_version"] || error("Julia version")
module NativeED
include(Main.NATIVE)
end

function pack(A)
    Dict("rows"=>size(A,1),"columns"=>size(A,2),"real"=>vec(permutedims(real.(A))),"imag"=>vec(permutedims(imag.(complex.(A)))))
end
function triplets(A)
    rows=Int[];cols=Int[];re=Float64[];im=Float64[]
    for i in axes(A,1),j in axes(A,2)
        iszero(A[i,j]) && continue
        push!(rows,i-1);push!(cols,j-1);push!(re,real(A[i,j]));push!(im,imag(A[i,j]))
    end
    Dict("rows"=>size(A,1),"columns"=>size(A,2),"row0"=>rows,"column0"=>cols,"real"=>re,"imag"=>im)
end
function site_annihilator(spin,site)
    C=zeros(ComplexF64,256,256);bit=1<<site
    for up in 0:15,dn in 0:15
        mask=spin=="up" ? up : dn
        (mask&bit)==0 && continue
        parity=count_ones(mask&(bit-1))+(spin=="down" ? count_ones(up) : 0)
        u=spin=="up" ? xor(up,bit) : up;d=spin=="down" ? xor(dn,bit) : dn
        C[u*16+d+1,up*16+dn+1]=isodd(parity) ? -1. : 1.
    end
    C
end
const SITE_C=[site_annihilator(spin,j) for spin in ("up","down") for j in 0:3]
function materialize(space)
    n=NativeED.dimension(space);H=zeros(n,n);v=zeros(n);out=zeros(n)
    for j in 1:n
        fill!(v,0.);v[j]=1.;NativeED.apply_hamiltonian!(out,v,space);H[:,j]=out
    end
    H
end
function cluster_records(records)
    sort!(records;by=r->(r["energy"],r["block_key"],r["eigen_index0"]))
    groups=Vector{Vector{Dict{String,Any}}}()
    for row in records
        if isempty(groups) || row["energy"]-groups[end][1]["energy"]>CFG["gates"]["cluster_diameter_max"]
            push!(groups,Dict{String,Any}[])
        end
        push!(groups[end],row)
    end
    [Dict("energy"=>sum(r["energy"] for r in g)/length(g),"energy_min"=>minimum(r["energy"] for r in g),"energy_max"=>maximum(r["energy"] for r in g),"members"=>[Dict("block_key"=>r["block_key"],"eigen_index0"=>r["eigen_index0"]) for r in g]) for g in groups]
end
function compute_case(case)
    blocks=Dict{String,Any}[];bmap=Dict{String,Any}();vectors=Dict{Tuple{String,Int},Vector{ComplexF64}}()
    records=Dict(N=>Dict{String,Any}[] for N in (3,4,5));Hfull=zeros(ComplexF64,256,256)
    for N in (3,4,5),up in 0:4
        dn=N-up;0<=dn<=4 || continue
        space=NativeED.build_space(4,CFG["t"],case["U"],case["mu"],up,dn;boundary=case["boundary"])
        H=materialize(space);dec=eigen(Symmetric(H))
        coords=[[Int(u),Int(d)] for u in space.up_masks for d in space.dn_masks]
        ids=[16*c[1]+c[2]+1 for c in coords];Hfull[ids,ids]=H
        key="N$(N)_up$(up)_dn$(dn)"
        row=Dict{String,Any}("block_key"=>key,"N"=>N,"Nup"=>up,"Ndown"=>dn,"coordinates"=>coords,"Hamiltonian"=>pack(H),"eigenvalues"=>dec.values,"eigenvectors"=>pack(dec.vectors))
        push!(blocks,row);bmap[key]=row
        for j in eachindex(dec.values)
            v=zeros(ComplexF64,256);v[ids]=dec.vectors[:,j];vectors[(key,j-1)]=v
            push!(records[N],Dict{String,Any}("energy"=>dec.values[j],"block_key"=>key,"eigen_index0"=>j-1))
        end
    end
    spectra=[Dict("N"=>N,"clusters"=>cluster_records(records[N])) for N in (3,4,5)]
    smap=Dict(s["N"]=>s["clusters"] for s in spectra)
    gc=smap[4][1];members=gc["members"];G=hcat([vectors[(m["block_key"],m["eigen_index0"])] for m in members]...)
    dg=size(G,2);E0=gc["energy"]
    ground=Dict("dimension"=>dg,"energy"=>E0,"energy_physical"=>E0+4*case["mu"],"energies"=>[bmap[m["block_key"]]["eigenvalues"][m["eigen_index0"]+1] for m in members],"vectors"=>pack(G))
    channels=Dict{String,Any}[];theta=case["boundary"]=="pbc" ? 0. : pi
    for kind in ("site","k"),index in 0:3,spin in ("up","down"),action in ("remove","add")
        k=kind=="k" ? (2pi*index+theta)/4 : 0.;offset=spin=="up" ? 0 : 4
        c=kind=="site" ? SITE_C[offset+index+1] : sum(exp(-im*k*j)*SITE_C[offset+j+1] for j in 0:3)/2
        O=action=="add" ? c' : c;S=O*G;N=action=="add" ? 5 : 3
        measure=Dict{String,Any}[]
        for cluster in smap[N]
            W=hcat([vectors[(m["block_key"],m["eigen_index0"])] for m in cluster["members"]]...)
            weight=sum(abs2,W'*S)/dg;cost=cluster["energy"]-E0
            push!(measure,Dict("energy"=>cluster["energy"],"energy_physical"=>cluster["energy"]+N*case["mu"],"cost"=>cost,"omega"=>(N==5 ? cost : -cost),"weight"=>weight,"multiplicity"=>length(cluster["members"])))
        end
        zero=sum(abs2,S)/dg;first=real(dot(S,Hfull*S-E0*S))/dg;occ=sum(abs2,c*G)/dg
        push!(channels,Dict("channel_id"=>"$(kind)$(index)_$(spin)_$(action)","kind"=>kind,"index"=>index,"spin"=>spin,"action"=>action,"k"=>k,"source_vectors"=>pack(S),"final_N"=>N,"occupation"=>occ,"zeroth_moment"=>zero,"cost_first_moment"=>first,"signed_first_moment"=>(N==5 ? first : -first),"charged_threshold"=>measure[1]["cost"],"poles"=>measure))
    end
    Dict("case_id"=>case["case_id"],"U"=>case["U"],"mu"=>case["mu"],"boundary"=>case["boundary"],"blocks"=>blocks,"sector_spectra"=>spectra,"ground"=>ground,"channels"=>channels)
end
function main_adapter()
    started=time();started<CFG["science_cutoff_unix"] || error("science cutoff")
    sourcefiles=["manifest.toml","PROTOCOL.md","PROVENANCE.json","raw_io.py","target.jl","reference.py","compare.py","run_candidate.py","candidate.sbatch","README.md","test_candidate.py"]
    metadata=Dict("schema"=>"X13_CHARGED_SPECTRAL_RAW_V1","release"=>CFG["release"],"catalogue_id"=>"X13","manifest_sha256"=>sha(MANIFEST),"source_freeze_sha256"=>FREEZE,"source_sha256"=>Dict(n=>sha(joinpath(RELEASE,n)) for n in sourcefiles),"native_sha256"=>sha(NATIVE),"scientific_sampling"=>false,"initial_ensemble"=>CFG["initial_ensemble"],"fock_order"=>CFG["fock_order"],"backend"=>"native_ed_new_adapter","versions"=>Dict("julia"=>string(VERSION)),"started_unix"=>started)
    cases=[compute_case(case) for case in CFG["cases"]]
    time()<CFG["science_cutoff_unix"] || error("science cutoff")
    sha(NATIVE)==CFG["native_sha256"] || error("native source changed")
    result=Dict("schema"=>"X13_CHARGED_SPECTRAL_RAW_V1","metadata"=>metadata,"site_annihilators"=>triplets.(SITE_C),"cases"=>cases,"completion"=>Dict("status"=>"COMPLETE","finished_unix"=>time()))
    # Runner owns a fresh directory; pre-existing output was rejected above.
    # A killed partial file cannot pass completion/parse/audit.
    open(OUTPUT,"w") do io
        TOML.print(io,result;sorted=true)
    end
end
main_adapter()
