"""Local source/synthetic algebra only: no native import, eigensolve or QuSpin."""
import ast, hashlib, math, unittest, tomllib
from pathlib import Path
import numpy as np
from raw_io import SOURCE_FILES, pack, unpack, triplets, from_triplets, block_grid, channel_grid, cluster_records, mode_operator
from compare import labels_from_weights
from run_candidate import validate_active_queue

HERE=Path(__file__).resolve().parent
CFG=tomllib.loads((HERE/'manifest.toml').read_text(encoding='utf-8'))

class CandidatePreparationTests(unittest.TestCase):
    def test_source_syntax_ascii_lf_and_fixed_grid(self):
        for name in SOURCE_FILES:
            raw=(HERE/name).read_bytes();self.assertNotIn(b'\r',raw);raw.decode('ascii')
            if name.endswith('.py'):ast.parse(raw.decode('ascii'),filename=name)
        self.assertEqual([(r['U'],r['boundary'],r['mu']) for r in CFG['cases']],[(2.,'pbc',1.),(2.,'apbc',1.),(4.,'pbc',2.),(4.,'apbc',2.)])
        self.assertEqual(len(block_grid()),13)
        for N,expected in ((3,56),(4,70),(5,56)):
            self.assertEqual(sum(math.comb(4,u)*math.comb(4,d) for n,u,d in block_grid() if n==N),expected)
        self.assertEqual(CFG['native_sha256'],'f8f94cfc13e11bb8b5e64e8ac8f4ade5ed3a13b3976c83b5ab5db89d86ba5f28')
        self.assertEqual(CFG['preparation_status'],'UNFROZEN_LOCAL_CANDIDATE_NO_EXECUTION_ADMISSION')

    def test_matrix_and_sparse_wire_format(self):
        a=np.array([[1+2j,3],[4j,-5]],complex)
        self.assertEqual(pack(a)['real'],[1.,3.,0.,-5.]);np.testing.assert_array_equal(unpack(pack(a)),a)
        c=np.zeros((256,256),complex);c[1,9]=1j;c[250,2]=-1
        np.testing.assert_array_equal(from_triplets(triplets(c)),c)
        bad=triplets(c);bad['row0'].append(1);bad['column0'].append(9);bad['real'].append(0);bad['imag'].append(1)
        with self.assertRaises(AssertionError):from_triplets(bad)

    def test_complete_diameter_clusters_not_chaining(self):
        rows=[dict(energy=e,block_key='fixture',eigen_index0=i) for i,e in enumerate((0.,.75e-8,1.5e-8,1.))]
        result=cluster_records(rows,CFG);self.assertEqual([len(r['members']) for r in result],[2,1,1])
        self.assertLessEqual(result[0]['energy_max']-result[0]['energy_min'],1e-8)
        self.assertLess(result[1]['energy_min']-result[0]['energy_max'],1e-6)
        self.assertEqual(labels_from_weights([0.,1e-12,1e-11,1e-9,-5e-11,float('nan')],CFG['gates']),['INVISIBLE','INVISIBLE','GRAY','VISIBLE','INVALID','INVALID'])

    def test_synthetic_fourier_adjoint_and_projector_rotation(self):
        # Arbitrary tiny matrix fixture, not a target Hamiltonian or case grid.
        c=[np.array([[0,j+1j],[0,0]],complex) for j in range(8)]
        for boundary in ('pbc','apbc'):
            grid=channel_grid(boundary);self.assertEqual(len(grid),32)
            for i in range(0,32,2):
                remove=mode_operator(c,grid[i]);add=mode_operator(c,grid[i+1])
                np.testing.assert_allclose(add,remove.conj().T,rtol=0,atol=1e-15)
        G=np.eye(2,dtype=complex);rotation=np.array([[1,1j],[1j,1]],complex)/math.sqrt(2)
        O=np.array([[1,2j],[3,4]],complex)
        np.testing.assert_allclose((O@G)@(O@G).conj().T/2,(O@G@rotation)@(O@G@rotation).conj().T/2,rtol=0,atol=1e-14)

    def test_cost_and_clock_algebra(self):
        # Arbitrary fixed energies test chemical-potential and signed removal definitions.
        e3,e4,e5,mu=-2.,-1.,4.,2.
        k3,k4,k5=e3-3*mu,e4-4*mu,e5-5*mu
        self.assertEqual(k5-k4,e5-e4-mu);self.assertEqual(k3-k4,e3-e4+mu)
        self.assertEqual(-(k3-k4),e4-e3-mu)
        for start_fraction in (0.,.1,.999999):
            for launch_fraction in (0.,.1,.999999):
                # Six-second TERM reserve, five-second fallback and one rounding second.
                self.assertLess(1194+launch_fraction+5,1200+start_fraction)
        self.assertEqual(CFG['science_cutoff_unix'],1792755300)

    def test_active_queue_fail_closed(self):
        self.assertEqual(validate_active_queue('42|RUNNING|1\n','42')['active_jobs'],1)
        self.assertEqual(validate_active_queue('42|RUNNING|1\n99|SUSPENDED|1\n','42')['active_cpus'],2)
        for raw in ('','\n','garbage','42|RUNNING','42|RUNNING|0','42|RUNNING|-1','42|RUNNING|x','42|PENDING|1','99|RUNNING|1','42|RUNNING|2','42|RUNNING|1\n42|RUNNING|1','42|RUNNING|1\n99|RUNNING|2','42|RUNNING|1\n98|RUNNING|1\n99|RUNNING|1','42|RUNNING|1\n\n'):
            with self.subTest(snapshot=raw):
                with self.assertRaises(AssertionError):validate_active_queue(raw,'42')

if __name__=='__main__':unittest.main()
