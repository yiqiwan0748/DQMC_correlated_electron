# X16 preparation candidate

Unfrozen, source-only preparation. No model, sampling, remote, staging or submission actions are authorized by these files. `PROTOCOL.md` defines the complete four-case/all-N2..6 question, new adapters, conditional floating-point budgets and exclusions. The original catalogue row is retained verbatim in `catalogue_X16.json`.

There are 13 source members listed in `raw_io.SOURCE_FILES`. A future independently approved source freeze adds SHA256SUMS as member14 and keeps its external source_freeze.json outside that self-hash inventory. All source must be UTF8 with LF, code ASCII. The separately approved native-three source closure is retained as external evidence; it is imported unchanged at runtime. No third-party runtime binaries are included.

Run only source-only checks now:

```
python -B test_candidate.py --output FRESH_LOCAL_VALIDATION_JSON
```

This checks parsing, schema, integer Fock algebra, scalar interval rules and guard rejection fixtures. It does not diagonalize a Hamiltonian, run a model, import a native kernel, execute a raw comparator, or claim a benchmark result. Root must separately parse Julia and Bash without evaluating target code. Independent source review and an independent complete raw auditor are prerequisites to freezing and any pilot.

Future root-only workflow: approve exact source and auditor maps; freeze source/archive externally; stage and verify all14members plus the external freeze without overwrites; freshly account all12 prior terminal jobs, whole-user queue and remaining budget; reserve the full25minutes; submit at most one excluded pilot. Retrieve and independently audit the full pilot. If it is incomplete or fails numerical qualification, stop rather than tune or retry. Only a successful reviewed timing/precision pilot can support a separately admitted fresh20minute production of the same frozen source. No wrapper submits another job. No catalogue row or canonical campaign file is changed here.

Future submission environment is VALIDATION_ROOT, X16_SOURCE (canonical frozen x16_pair_binding_v1 path) and X16_EXPECTED_FREEZE_SHA256. Production additionally requires X16_EXPECTED_PILOT_JOB_ID, X16_PILOT_READINESS and X16_EXPECTED_PILOT_READINESS_SHA256. Before model initialization it validates the pinned root-approved pilot independent audit, samefreeze300scap, all21 outputs and original transfer/scheduler, plus live owned COMPLETED0:0 and no active pilot. Only physical sign ambiguity may be exempt from excluded pilot numerical readiness; production sign/precision gates remain unchanged. `pilot.sbatch` and `production.sbatch` select distinct attempt modes/result directories and require full actual-start suffixes1500/1200 seconds before11:35UTC. Production takes no pilot/raw X13 physics input or pooling. Full per-process/resource/queue/native/source receipts remain mandatory, as do independent audit and append-only preservation of the other99 rows. The total cap0.4166666667CPUh is within the currently unreserved0.948611CPUh only as an unadmitted proposal; later accounting can change admissibility.

The full-scope X16 time has not been measured. Five-minute pilot and20minute production are hard caps, not promises. No admission helper, retrieval helper, independent raw auditor, ledger updater or automatic future submission is supplied or approved by this preparation.
