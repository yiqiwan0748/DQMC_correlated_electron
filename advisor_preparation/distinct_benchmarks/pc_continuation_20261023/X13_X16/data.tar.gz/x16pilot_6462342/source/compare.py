#!/usr/bin/env python3
"""Fixed complete X16 comparator; independent raw auditor required before credit."""
import argparse,json,math,os,tomllib
from pathlib import Path
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from raw_io import SCHEMA,SOURCE_FILES,sha,unpack,from_triplets,coordinates,block_grid,block_key,pair_grid,cluster_records,numerical_energy_budget,spectral_budget_from_norms,physical_interval,binding_record,finite_numbers,member_records,strict_json,write_json_fresh
class Checks:
 def __init__(self):self.rows=[]
 def check(self,name,passed,detail=None):self.rows.append(dict(name=name,passed=bool(passed),detail=detail));return bool(passed)
 def close(self,name,a,b,tol):
  import numpy as np
  aa,bb=np.asarray(a),np.asarray(b);same=aa.shape==bb.shape
  error=float(np.max(np.abs(aa-bb),initial=0))if same else None
  return self.check(name,same and math.isfinite(error)and error<=tol,dict(max_abs=error,tolerance=tol))
 def formula(self,name,a,b,conditioning_scale=None):
  assert type(a)in(int,float)and type(b)in(int,float)and math.isfinite(a)and math.isfinite(b)
  scale=max(abs(a),abs(b),1e-300)if conditioning_scale is None else conditioning_scale
  assert type(scale)in(int,float)and math.isfinite(scale)and scale>0
  tol=64*2.220446049250313e-16*scale
  return self.check(name,abs(a-b)<=tol,dict(max_abs=abs(a-b),tolerance=tol,conditioning_scale=scale))
 @property
 def passed(self):return all(row['passed']for row in self.rows)
 @property
 def numerical_qualification(self):return all(row['passed']for row in self.rows if not row['name'].endswith(' all signs resolved'))
def canonical_sites():
 import numpy as np
 result=[]
 for mode in range(8):
  C=np.zeros((256,256),complex)
  for u,d in coordinates():
   occupied=[j for j in range(4)if u>>j&1]+[4+j for j in range(4)if d>>j&1]
   if mode not in occupied:continue
   uu=u^(1<<mode)if mode<4 else u;dd=d^(1<<(mode-4))if mode>=4 else d
   C[uu*16+dd,u*16+d]=(-1)**occupied.index(mode)
  result.append(C)
 return result
def canonical_hamiltonian(site_c,case,cfg):
 from scipy.sparse import csr_matrix
 c=[csr_matrix(v)for v in site_c];number=[a.conj().T@a for a in c];H=csr_matrix((256,256),dtype=complex)
 for j in range(4):
  k=(j+1)%4;seam=-1 if case['boundary']=='apbc'and j==3 else 1
  for offset in (0,4):H-=cfg['t']*seam*(c[offset+j].conj().T@c[offset+k]+c[offset+k].conj().T@c[offset+j])
  H+=case['U']*(number[j]@number[4+j])-case['mu']*(number[j]+number[4+j])
 return H.toarray()
def raw_budget_qualification(q,label,saved,own,cfg):
 keys=('gram_fro','residual_fro','H_fro','D_max','delta','roundoff','energy_budget')
 finite_numbers([saved[k]for k in keys]);assert type(saved['dimension'])is int
 q.check(label+' budget dimension',saved['dimension']==own['dimension'])
 q.check(label+' raw budget nonnegative',all(saved[k]>=0 for k in keys))
 # Norms involve separately rounded matrix products. Formula replay uses each
 # backend's own saved primitive norms; primary scientific bounds use own H/V.
 n=own['dimension'];unit=cfg['uncertainty']['unit_roundoff_budget'];factor=cfg['uncertainty']['roundoff_guard_factor']
 q.close(label+' saved gram norm',saved['gram_fro'],own['gram_fro'],factor*unit*n)
 q.close(label+' saved residual norm',saved['residual_fro'],own['residual_fro'],own['roundoff'])
 for key in ('H_fro','D_max'):q.close(label+' saved '+key,saved[key],own[key],factor*unit*max(1.,own[key]))
 formula=spectral_budget_from_norms(n,saved['gram_fro'],saved['residual_fro'],saved['H_fro'],saved['D_max'],cfg)
 for key in ('delta','roundoff','energy_budget'):q.formula(label+' own saved formula '+key,saved[key],formula[key])
 q.check(label+' qualified full-square energy budget',own['energy_budget']<=cfg['gates']['maximum_block_energy_budget']and saved['energy_budget']<=cfg['gates']['maximum_block_energy_budget'])
def validate_backend(raw,cfg,folder,freeze_sha,backend,attempt_mode):
 import numpy as np
 from scipy.sparse import csr_matrix,eye
 q=Checks();g=cfg['gates'];meta=raw['metadata'];coords=coordinates();expected_c=canonical_sites()
 q.check('schema backend model ensemble role',raw['schema']==SCHEMA and meta['schema']==SCHEMA and meta['catalogue_id']=='X16'and meta['release']==cfg['release']and meta['backend']==backend and meta['initial_ensemble']==cfg['initial_ensemble']and meta['fock_order']==cfg['fock_order']and meta['scientific_sampling']is False and meta['attempt_mode']==attempt_mode and meta['pilot_excluded_from_production']is(attempt_mode=='pilot'))
 q.check('source native pins',meta['source_freeze_sha256']==freeze_sha and meta['manifest_sha256']==sha(folder/'manifest.toml')and meta['native_sha256']==cfg['native_sha256']and meta['source_sha256']=={name:sha(folder/name)for name in SOURCE_FILES})
 expected_versions={'julia':cfg['julia_version']}if backend=='native_ed_new_pair_adapter'else{k:cfg[k+'_version']for k in ('quspin','numpy','scipy')}
 q.check('backend versions',meta['versions']==expected_versions)
 if backend=='native_ed_new_pair_adapter':q.check('native three actualpins',meta['native_source_sha256']=={cfg['native_relative_path']:cfg['native_sha256'],'Project.toml':cfg['native_project_sha256'],'Manifest.toml':cfg['native_manifest_sha256']})
 q.check('complete before cutoff',raw['completion']['status']=='COMPLETE'and type(raw['completion']['finished_unix'])in(int,float)and math.isfinite(raw['completion']['finished_unix'])and raw['completion']['finished_unix']<cfg['science_cutoff_unix'])
 assert len(raw['site_annihilators'])==8
 site_c=[from_triplets(row)for row in raw['site_annihilators']]
 for i,(c,want)in enumerate(zip(site_c,expected_c)):q.check('EXACT canonical site operator '+str(i),c.shape==(256,256)and np.array_equal(c,want))
 cs=[csr_matrix(c)for c in site_c];ident=eye(256,format='csr',dtype=complex);car=0.
 for i in range(8):
  for j in range(8):
   for a in (cs[i]@cs[j]+cs[j]@cs[i],cs[i]@cs[j].conj().T+cs[j].conj().T@cs[i]-(ident if i==j else 0)):car=max(car,float(np.max(np.abs(a.data),initial=0)))
 q.check('full64 same crossspin CAR',car<=g['car_abs'],car)
 assert len(raw['pair_annihilators'])==28;pair_ops=[]
 for i,(row,(a,b))in enumerate(zip(raw['pair_annihilators'],pair_grid())):
  q.check('pair descriptor '+str(i),all(type(row[k])is int for k in ('pair_index','a','b'))and(row['pair_index'],row['a'],row['b'])==(i,a,b))
  p=from_triplets(row['matrix']);own=site_c[b]@site_c[a];q.check('EXACT wedge operator '+str(i),p.shape==(256,256)and np.array_equal(p,own));pair_ops.append(own)
 if backend=='independent_quspin':
  bridge=meta['quspin_bridge'];rawcoords=bridge['raw_coordinates'];perm=bridge['canonical_to_raw'];states=bridge['raw_basis_states'];finite_numbers(bridge['phases_real']);finite_numbers(bridge['phases_imag'])
  assert len(rawcoords)==len(set(map(tuple,rawcoords)))==len(perm)==len(set(perm))==len(states)==len(set(states))==256 and all(type(v)is int for v in perm+states)and all(len(v)==2 and all(type(x)is int and 0<=x<16 for x in v)for v in rawcoords)
  phase=np.asarray(bridge['phases_real'])+1j*np.asarray(bridge['phases_imag']);assert phase.shape==(256,)
  T=np.zeros((256,256),complex)
  for i,(u,d)in enumerate(coords):assert 0<=perm[i]<256 and rawcoords[perm[i]]==[u,d];T[perm[i],i]=phase[i]
  q.close('QuSpin unit phase permutation',np.abs(phase),np.ones(256),g['matrix_abs']);qc=[from_triplets(c)for c in bridge['raw_site_annihilators']];assert len(qc)==8;vac=rawcoords.index([0,0])
  for i,(u,d)in enumerate(coords):
   v=np.zeros(256,complex);v[vac]=1.;occupied=[j for j in range(4)if u>>j&1]+[4+j for j in range(4)if d>>j&1]
   for mode in reversed(occupied):v=qc[mode].conj().T@v
   q.close('QuSpin canonical creation string '+str(i),v,T[:,i],g['matrix_abs'])
  for mode in range(8):
   q.check('EXACT QuSpin fulloperator bridge '+str(mode),np.array_equal(T.conj().T@qc[mode]@T,expected_c[mode]))
   want=[float((u if mode<4 else d)>>(mode%4)&1)for u,d in rawcoords];q.close('QuSpin raw number coordinates '+str(mode),np.diag(qc[mode].conj().T@qc[mode]),want,g['matrix_abs'])
 q.check('ordered full casegrid',[c['case_id']for c in raw['cases']]==[c['case_id']for c in cfg['cases']]);derived=[]
 for c,case in zip(raw['cases'],cfg['cases']):
  prefix=case['case_id'];finite_numbers([c['U'],c['mu']]);q.check(prefix+' exact model',all(c[k]==case[k]for k in ('case_id','U','mu','boundary')))
  q.check(prefix+' exact19block grid',[r['block_key']for r in c['blocks']]==[block_key(*row)for row in block_grid()]);assert len(c['blocks'])==19
  nominal=canonical_hamiltonian(expected_c,case,cfg);vectors={};values={};budgets={};saved_budgets={};records={N:[]for N in cfg['total_N']};all_e={N:[]for N in cfg['total_N']}
  if backend=='independent_quspin':q.check(prefix+' EXACT raw QuSpin physicalH bridge',np.array_equal(T.conj().T@from_triplets(c['raw_quspin_hamiltonian'])@T,nominal))
  for row,(N,u,d)in zip(c['blocks'],block_grid()):
   key=block_key(N,u,d);label=prefix+'/'+key;coord=[(a,b)for a,b in coords if a.bit_count()==u and b.bit_count()==d];ids=[a*16+b for a,b in coord]
   q.check(label+' typed coordinates',all(type(row[k])is int for k in ('N','Nup','Ndown'))and(row['N'],row['Nup'],row['Ndown'])==(N,u,d)and all(all(type(x)is int for x in pair)for pair in row['coordinates'])and row['coordinates']==[list(v)for v in coord])
   h,v=unpack(row['Hamiltonian']),unpack(row['eigenvectors']);finite_numbers(row['eigenvalues']);e=np.asarray(row['eigenvalues'],float);n=len(ids);assert h.shape==v.shape==(n,n)and e.shape==(n,)
   canonical=nominal[np.ix_(ids,ids)];q.check(label+' EXACT nominal integerHamiltonian',np.array_equal(h,canonical))
   q.check(label+' sorted spectrum',bool(np.all(np.diff(e)>=0)));q.close(label+' Hermitian',h,h.conj().T,g['matrix_abs']);q.close(label+' residual',canonical@v,v*e,g['eigen_residual_abs']);q.close(label+' orthogonality',v.conj().T@v,np.eye(n),g['orthogonality_abs'])
   budget=numerical_energy_budget(canonical,e,v,cfg);raw_budget_qualification(q,label,row['numerical_energy_budget'],budget,cfg);budgets[key]=budget['energy_budget'];saved_budgets[key]=row['numerical_energy_budget']['energy_budget']
   for j,energy in enumerate(e):
    full=np.zeros(256,complex);full[ids]=v[:,j];vectors[key,j]=full;values[key,j]=float(energy);all_e[N].append(float(energy));records[N].append(dict(energy=float(energy),block_key=key,eigen_index0=j))
  spectra={N:cluster_records(records[N],cfg)for N in cfg['total_N']};q.check(prefix+' complete sectors',all(type(row['N'])is int for row in c['sector_spectra'])and[row['N']for row in c['sector_spectra']]==cfg['total_N']and[sum(len(x['members'])for x in row['clusters'])for row in c['sector_spectra']]==[28,56,70,56,28])
  for saved in c['sector_spectra']:
   N=saved['N'];clusters=spectra[N];q.check(prefix+f'/N{N} exact clustering',[r['members']for r in saved['clusters']]==[r['members']for r in clusters])
   bands=[]
   for ci,(old,new)in enumerate(zip(saved['clusters'],clusters)):
    finite_numbers([old[k]for k in('energy','energy_min','energy_max')]);member_records(old['members'])
    q.close(prefix+f'/N{N}/cluster{ci} saved values',[old[k]for k in ('energy','energy_min','energy_max')],[new[k]for k in ('energy','energy_min','energy_max')],g['matrix_abs'])
    lower=min(values[m['block_key'],m['eigen_index0']]-budgets[m['block_key']]for m in new['members']);upper=max(values[m['block_key'],m['eigen_index0']]+budgets[m['block_key']]for m in new['members']);bands.append((lower,upper))
    q.check(prefix+f'/N{N}/cluster{ci} uncertaintyqualified diameter',upper-lower<=g['cluster_diameter_max'])
   q.check(prefix+f'/N{N} uncertaintyqualified separation',all(b[0]-a[1]>=g['cluster_separation_min']for a,b in zip(bands,bands[1:])))
  q.check(prefix+' complete5ground grid',[r['N']for r in c['grounds']]==cfg['total_N']);ground_rows=[];number=[cc.conj().T@cc for cc in site_c]
  for row in c['grounds']:
   N=row['N'];assert type(N)is int and N in cfg['total_N'];label=prefix+f'/N{N}';cluster=spectra[N][0];members=cluster['members'];G=np.column_stack([vectors[m['block_key'],m['eigen_index0']]for m in members]);dg=G.shape[1]
   member_records(row['members']);q.check(label+' full global ground members dimension',row['members']==members and type(row['dimension'])is int and row['dimension']==dg)
   E=min(all_e[N]);blockkeys=[block_key(*v)for v in block_grid()if v[0]==N]
   lower=min(min(v['energy']for v in records[N]if v['block_key']==key)-budgets[key]for key in blockkeys);upper=min(min(v['energy']for v in records[N]if v['block_key']==key)+budgets[key]for key in blockkeys)
   ownphys=physical_interval(case['mu'],N,E,lower,upper,cfg)
   source_lo=min(min(v['energy']for v in records[N]if v['block_key']==key)-saved_budgets[key]for key in blockkeys);source_hi=min(min(v['energy']for v in records[N]if v['block_key']==key)+saved_budgets[key]for key in blockkeys);sourcephys=physical_interval(case['mu'],N,E,source_lo,source_hi,cfg)
   for name,want in [('energy_mu',E),('energy_mu_lower',source_lo),('energy_mu_upper',source_hi),('energy_physical',sourcephys['energy']),('energy_lower',sourcephys['lower']),('energy_upper',sourcephys['upper']),('physical_shift_roundoff',sourcephys['physical_shift_roundoff'])]:q.formula(label+' own saved '+name,row[name],want,max(1.,abs(E),abs(case['mu']*N))if name in('energy_physical','energy_lower','energy_upper')else None)
   finite_numbers(row['individual_energies']);q.close(label+' groundindividual energies',row['individual_energies'],[values[m['block_key'],m['eigen_index0']]for m in members],g['matrix_abs'])
   SG=unpack(row['vectors']);assert SG.shape==G.shape;q.close(label+' own ground orthogonality',SG.conj().T@SG,np.eye(dg),g['orthogonality_abs']);q.close(label+' own complete groundprojector',SG@SG.conj().T,G@G.conj().T,g['matrix_abs']);q.close(label+' saved complete projector',from_triplets(row['projector']),G@G.conj().T,g['matrix_abs']);G=SG
   sources=[p@G for p in pair_ops];assert len(row['pair_sources'])==28
   for i,(saved,S,(a,b))in enumerate(zip(row['pair_sources'],sources,pair_grid())):
    q.check(label+f'/pair{i} descriptor',all(type(saved[k])is int for k in ('pair_index','a','b','final_N'))and(saved['pair_index'],saved['a'],saved['b'],saved['final_N'])==(i,a,b,N-2));q.close(label+f'/pair{i} own source',from_triplets(saved['vectors']),S,g['pair_operator_abs'])
   A=np.column_stack([S.reshape(-1)for S in sources]);gamma=A.conj().T@A/dg;saved_gamma=unpack(row['pair_density']);assert saved_gamma.shape==(28,28);q.close(label+' own pairdensity',saved_gamma,gamma,g['matrix_abs']);q.close(label+' pairdensity Hermitian',saved_gamma,saved_gamma.conj().T,g['pair_density_hermitian_abs']);q.check(label+' pairdensity PSD',float(np.linalg.eigvalsh((saved_gamma+saved_gamma.conj().T)/2).min())>=g['pair_density_eigenvalue_min']);q.close(label+' pairtrace C(N,2)',np.trace(saved_gamma),N*(N-1)/2,g['pair_trace_abs'])
   occupations=[float(np.vdot(G,n@G).real/dg)for n in number];diagonal=[float(np.vdot(G,number[a]@number[b]@G).real/dg)for a,b in pair_grid()];onsite=[float(np.vdot(G,number[j]@number[j+4]@G).real/dg)for j in range(4)]
   finite_numbers(row['occupations']);finite_numbers(row['number_pair_diagonal']);finite_numbers(row['onsite_double']);q.close(label+' saved occupations',row['occupations'],occupations,g['matrix_abs']);q.close(label+' total particleN',sum(occupations),N,g['particle_number_abs']);q.close(label+' saved pairdiagonal',row['number_pair_diagonal'],diagonal,g['matrix_abs']);q.close(label+' all28 numberpair identities',np.diag(saved_gamma),diagonal,g['pair_diagonal_identity_abs']);q.close(label+' saved onsiteD',row['onsite_double'],onsite,g['onsite_identity_abs']);q.close(label+' onsite pairidentity',[saved_gamma[pair_grid().index((j,j+4)),pair_grid().index((j,j+4))]for j in range(4)],onsite,g['onsite_identity_abs'])
   ground_rows.append(dict(N=N,dimension=dg,energy_mu=E,energy_physical=ownphys['energy'],energy_lower=ownphys['lower'],energy_upper=ownphys['upper'],projector=G@G.conj().T,pair_density=gamma,source_saved_row=row))
  gm={r['N']:r for r in ground_rows};expected=[binding_record('B_h',gm[3],gm[2],gm[4],cfg),binding_record('B_e',gm[5],gm[4],gm[6],cfg)];q.check(prefix+' exact two bindinglabels',[r['name']for r in c['bindings']]==['B_h','B_e'])
  for saved,own in zip(c['bindings'],expected):
   label=prefix+'/'+own['name'];source=[r['source_saved_row']for r in ground_rows];sm={r['N']:r for r in source};odd=own['odd_N'];low,high=own['even_N'];formula=binding_record(own['name'],sm[odd],sm[low],sm[high],cfg)
   q.check(label+' exact descriptor',type(saved['odd_N'])is int and saved['odd_N']==odd and saved['even_N']==[low,high]and all(type(x)is int for x in saved['even_N'])and saved['conditional_numerical_budget']is True)
   energy_scale=max(1.,2*abs(sm[odd]['energy_physical'])+abs(sm[low]['energy_physical'])+abs(sm[high]['energy_physical']))
   for key in ('value','lower','upper'):q.formula(label+' saved propagation '+key,saved[key],formula[key],energy_scale)
   q.formula(label+' saved own halfwidth',saved['halfwidth'],(saved['upper']-saved['lower'])/2)
   q.formula(label+' saved own roundoff',saved['roundoff'],formula['roundoff'])
   saved_sign='BOUND'if saved['lower']>0 else'NONBINDING'if saved['upper']<0 else'UNRESOLVED'
   q.check(label+' own saved ordered interval',saved['lower']<=saved['value']<=saved['upper']);q.check(label+' own saved sign',saved['classification']==saved_sign);q.check(label+' independently same sign',saved['classification']==own['classification']);q.check(label+' all signs resolved',own['classification']in('BOUND','NONBINDING'));q.check(label+' predeclared binding precision',own['halfwidth']<=g['maximum_binding_halfwidth'])
  derived.append(dict(case_id=prefix,H=nominal,all_eigenvalues={N:sorted(all_e[N])for N in cfg['total_N']},grounds=ground_rows,bindings=expected))
 return q,dict(site_c=site_c,cases=derived)
def compare_raw(target,reference,cfg,folder,freeze_sha,attempt_mode):
 q=Checks();tq,t=validate_backend(target,cfg,folder,freeze_sha,'native_ed_new_pair_adapter',attempt_mode);rq,r=validate_backend(reference,cfg,folder,freeze_sha,'independent_quspin',attempt_mode);g=cfg['gates'];bindings=[];ground_receipts=[]
 if not tq.numerical_qualification or not rq.numerical_qualification:return dict(scientific_status='UNRESOLVED',pilot_readiness=dict(schema='X16_NUMERICAL_PILOT_READINESS_V1',status='NOT_READY',numerical_qualification=False,full_grid_cross_backend_match=False,physical_signs_resolved=tq.passed and rq.passed),qualification_checks={'target':tq.rows,'reference':rq.rows},cross_checks=[],bindings=[],ground_receipts=[],reason='Full source/numerical/ground/pair/precision qualification required before cross comparison; physical sign uncertainty is separate')
 for i in range(8):q.close('cross exactcanonicalC '+str(i),t['site_c'][i],r['site_c'][i],g['matrix_abs'])
 for a,b in zip(t['cases'],r['cases']):
  prefix=a['case_id'];q.close(prefix+' cross physicalH',a['H'],b['H'],g['matrix_abs'])
  for N in cfg['total_N']:q.close(prefix+f'/N{N} full eigenspectrum',a['all_eigenvalues'][N],b['all_eigenvalues'][N],g['cross_energy_abs'])
  for x,y in zip(a['grounds'],b['grounds']):
   N=x['N'];label=prefix+f'/N{N}';q.check(label+' cross global multiplicity',x['dimension']==y['dimension']);q.close(label+' cross globalprojector',x['projector'],y['projector'],g['cross_projector_abs']);q.close(label+' cross groundenergy',[x[k]for k in ('energy_physical','energy_lower','energy_upper')],[y[k]for k in ('energy_physical','energy_lower','energy_upper')],g['cross_energy_abs']);q.check(label+' conditional energyinterval overlap',max(x['energy_lower'],y['energy_lower'])<=min(x['energy_upper'],y['energy_upper']));q.close(label+' all784complex pairdensity entries',x['pair_density'],y['pair_density'],g['cross_pair_density_abs']);ground_receipts.append(dict(case_id=prefix,N=N,dimension=x['dimension'],energy_physical=x['energy_physical'],energy_interval=[x['energy_lower'],x['energy_upper']],pair_density_max_abs_error=float(abs(x['pair_density']-y['pair_density']).max()),pairtrace=float(x['pair_density'].trace().real)))
  for x,y in zip(a['bindings'],b['bindings']):
   label=prefix+'/'+x['name'];q.close(label+' cross binding intervals',[x[k]for k in ('value','lower','upper')],[y[k]for k in ('value','lower','upper')],g['cross_binding_abs']);q.check(label+' same binding classification',x['classification']==y['classification']);q.check(label+' conditional bindinginterval overlap',max(x['lower'],y['lower'])<=min(x['upper'],y['upper']));bindings.append(dict(case_id=prefix,**x))
 resolved=tq.passed and rq.passed
 return dict(scientific_status=('PASS'if q.passed else'FAIL')if resolved else'UNRESOLVED',pilot_readiness=dict(schema='X16_NUMERICAL_PILOT_READINESS_V1',status='READY'if q.passed else'NOT_READY',numerical_qualification=True,full_grid_cross_backend_match=q.passed,physical_signs_resolved=resolved,physical_sign_uncertainty_only_exempt=True,production_gates_unchanged=True),qualification_checks={'target':tq.rows,'reference':rq.rows},cross_checks=q.rows,bindings=bindings,ground_receipts=ground_receipts,complete_cases=4,spinblocks_per_backend=76,fixedN_ground_ensembles=20,pair_modes=28,complex_pairdensity_entries=15680,scope='One finite conditional-numerical-budget binding question with NEW pairobserver, no preexistingnativepairsolver or bulkclaim')
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);p.add_argument('--freeze-sha256',required=True);p.add_argument('--target',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists();folder=a.manifest.resolve().parent;mode=os.environ['X16_ATTEMPT_MODE'];assert mode in('pilot','production')
 inputs={str(v.resolve()):sha(v)for v in (a.manifest,a.target,a.reference)};result=dict(schema='X16_PAIR_BINDING_COMPARISON_V1',catalogue_id='X16',attempt_mode=mode,catalogue_status='PILOT_EXCLUDED'if mode=='pilot'else'PENDING_INDEPENDENT_AUDIT',scientific_status='UNRESOLVED',scientific_completions=0,scientific_sampling=False,input_sha256=inputs)
 try:
  assert sha(folder/'source_freeze.json')==a.freeze_sha256;freeze=strict_json((folder/'source_freeze.json').read_bytes());assert all(sha(folder/n)==freeze['files'][n]for n in SOURCE_FILES)
  cfg=tomllib.loads(a.manifest.read_text(encoding='utf-8'));target=tomllib.loads(a.target.read_text(encoding='utf-8'));reference=strict_json(a.reference.read_bytes());result.update(compare_raw(target,reference,cfg,folder,a.freeze_sha256,mode))
 except Exception as error:result.update(scientific_status='UNRESOLVED',administrative_error=type(error).__name__+': '+str(error))
 assert all(sha(Path(path))==want for path,want in inputs.items()),'Original raw inputs changed'
 write_json_fresh(a.output,result);return 0 if result['scientific_status']=='PASS'else 1 if result['scientific_status']=='FAIL'else 2
if __name__=='__main__':raise SystemExit(main())
