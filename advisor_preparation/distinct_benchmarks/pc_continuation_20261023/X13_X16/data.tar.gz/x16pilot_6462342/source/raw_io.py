"""Full X16 storage and independent Python reference reduction, no native imports."""
from __future__ import annotations
import hashlib,json,math,os
from pathlib import Path
SCHEMA='X16_PAIR_BINDING_RAW_V1'
SOURCE_FILES=('manifest.toml','PROTOCOL.md','PROVENANCE.json','raw_io.py','target.jl','reference.py','compare.py','run_candidate.py','pilot.sbatch','production.sbatch','README.md','test_candidate.py','catalogue_X16.json')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def finite_numbers(values):
 assert isinstance(values,list) and all(type(x)in(int,float)and math.isfinite(x)for x in values),'Finite numeric scalars, no bool/string coercion'
 return values
def member_records(values):
 assert isinstance(values,list)and all(isinstance(m,dict)and set(m)=={'block_key','eigen_index0'}and isinstance(m['block_key'],str)and type(m['eigen_index0'])is int and m['eigen_index0']>=0 for m in values),'Typed complete cluster members required'
 return values
def strict_json(raw):
 def pairs(items):
  result={}
  for key,value in items:assert key not in result,'Duplicate JSON key';result[key]=value
  return result
 def bad_constant(value):raise ValueError('Nonfinite JSON constant '+value)
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=bad_constant)
def pack(a):
 import numpy as np
 a=np.asarray(a,dtype=complex);assert a.ndim==2
 return dict(rows=a.shape[0],columns=a.shape[1],real=a.real.ravel().tolist(),imag=a.imag.ravel().tolist())
def unpack(a):
 r,c=a['rows'],a['columns'];assert type(r)is int and type(c)is int and 0<=r<=256 and 0<=c<=256
 finite_numbers(a['real']);finite_numbers(a['imag'])
 import numpy as np
 re,im=np.asarray(a['real'],float),np.asarray(a['imag'],float)
 assert re.shape==im.shape==(r*c,) and np.isfinite(re).all() and np.isfinite(im).all()
 return (re+1j*im).reshape(r,c)
def triplets(a):
 import numpy as np
 a=np.asarray(a,dtype=complex);r,c=np.nonzero(a)
 return dict(rows=a.shape[0],columns=a.shape[1],row0=r.tolist(),column0=c.tolist(),real=a[r,c].real.tolist(),imag=a[r,c].imag.tolist())
def from_triplets(a):
 r,c=a['rows'],a['columns'];assert type(r)is int and type(c)is int and 0<=r<=256 and 0<=c<=256
 names=('row0','column0','real','imag');assert len({len(a[k]) for k in names})==1
 finite_numbers(a['real']);finite_numbers(a['imag']);seen=set()
 for i,j,x,y in zip(*(a[k] for k in names)):
  assert type(i)is int and type(j)is int and 0<=i<r and 0<=j<c and (i,j)not in seen
  seen.add((i,j))
 import numpy as np
 z=np.zeros((r,c),complex)
 for i,j,x,y in zip(*(a[k]for k in names)):z[i,j]=complex(x,y)
 return z
def coordinates():return [(u,d)for u in range(16)for d in range(16)]
def block_grid():return [(N,u,N-u)for N in (2,3,4,5,6)for u in range(5)if 0<=N-u<=4]
def block_key(N,u,d):return f'N{N}_up{u}_dn{d}'
def pair_grid():return [(a,b)for a in range(8)for b in range(a+1,8)]
def cluster_records(records,cfg):
 records=sorted(records,key=lambda r:(r['energy'],r['block_key'],r['eigen_index0']));groups=[]
 for row in records:
  if not groups or row['energy']-groups[-1][0]['energy']>cfg['gates']['cluster_diameter_max']:groups.append([])
  groups[-1].append(row)
 return [dict(energy=sum(r['energy']for r in g)/len(g),energy_min=min(r['energy']for r in g),energy_max=max(r['energy']for r in g),members=[dict(block_key=r['block_key'],eigen_index0=r['eigen_index0'])for r in g])for g in groups]
def spectral_budget_from_norms(n,gram_fro,residual_fro,H_fro,D_max,cfg):
 """Conditional full-square polar/Weyl budget, with explicit rounding assumptions."""
 factor=cfg['uncertainty']['roundoff_guard_factor'];eps=cfg['uncertainty']['unit_roundoff_budget']
 assert type(n)is int and n>0 and all(type(x)in(int,float)and math.isfinite(x)and x>=0 for x in (gram_fro,residual_fro,H_fro,D_max))
 delta=gram_fro+factor*eps*n;roundoff=factor*eps*n*max(1.,H_fro,D_max)
 assert delta<1
 s=math.sqrt(1-delta)
 # delta/[s*(1+s)] is the stable form of 1/s-1.
 eta=(residual_fro+roundoff)/s+2*D_max*delta/(s*(1+s))+roundoff
 return dict(dimension=n,gram_fro=gram_fro,residual_fro=residual_fro,H_fro=H_fro,D_max=D_max,delta=delta,roundoff=roundoff,energy_budget=eta)
def numerical_energy_budget(h,e,v,cfg):
 import numpy as np
 n=len(e)
 return spectral_budget_from_norms(n,float(np.linalg.norm(v.conj().T@v-np.eye(n),'fro')),float(np.linalg.norm(h@v-v*e,'fro')),float(np.linalg.norm(h,'fro')),float(np.max(np.abs(e),initial=0)),cfg)
def physical_interval(mu,N,E,lower,upper,cfg):
 eps=cfg['uncertainty']['unit_roundoff_budget'];factor=cfg['uncertainty']['roundoff_guard_factor'];pad=factor*eps*max(1.,abs(E),abs(mu*N))
 return dict(energy=E+mu*N,lower=lower+mu*N-pad,upper=upper+mu*N+pad,physical_shift_roundoff=pad)
def binding_record(label,odd,evenlow,evenhigh,cfg):
 factor=cfg['uncertainty']['roundoff_guard_factor'];eps=cfg['uncertainty']['unit_roundoff_budget']
 pad=factor*eps*max(1.,2*abs(odd['energy_physical'])+abs(evenlow['energy_physical'])+abs(evenhigh['energy_physical']))
 mean=2*odd['energy_physical']-evenlow['energy_physical']-evenhigh['energy_physical']
 lo=2*odd['energy_lower']-evenlow['energy_upper']-evenhigh['energy_upper']-pad
 hi=2*odd['energy_upper']-evenlow['energy_lower']-evenhigh['energy_lower']+pad
 sign='BOUND'if lo>0 else 'NONBINDING'if hi<0 else 'UNRESOLVED'
 return dict(name=label,odd_N=odd['N'],even_N=[evenlow['N'],evenhigh['N']],value=mean,lower=lo,upper=hi,halfwidth=(hi-lo)/2,roundoff=pad,classification=sign,conditional_numerical_budget=True)
def case_from_dense(H,site_c,case,cfg,extra=None):
 """QuSpin-only reduction; native target independently implements Julia reduction."""
 import numpy as np
 from scipy.linalg import eigh
 coords=coordinates();blocks=[];bmap={};vectors={};sectors={N:[]for N in cfg['total_N']}
 for N,u,d in block_grid():
  ids=[i for i,(a,b)in enumerate(coords)if a.bit_count()==u and b.bit_count()==d];h=H[np.ix_(ids,ids)];e,v=eigh(h);key=block_key(N,u,d)
  row=dict(block_key=key,N=N,Nup=u,Ndown=d,coordinates=[list(coords[i])for i in ids],Hamiltonian=pack(h),eigenvalues=e.tolist(),eigenvectors=pack(v),numerical_energy_budget=numerical_energy_budget(h,e,v,cfg));blocks.append(row);bmap[key]=row
  for j,energy in enumerate(e):
   full=np.zeros(256,complex);full[ids]=v[:,j];vectors[key,j]=full;sectors[N].append(dict(energy=float(energy),block_key=key,eigen_index0=j))
 spectra=[dict(N=N,clusters=cluster_records(sectors[N],cfg))for N in cfg['total_N']];smap={s['N']:s['clusters']for s in spectra}
 pairs=[site_c[b]@site_c[a]for a,b in pair_grid()];number=[c.conj().T@c for c in site_c];grounds=[]
 for N in cfg['total_N']:
  gc=smap[N][0];members=gc['members'];G=np.column_stack([vectors[m['block_key'],m['eigen_index0']]for m in members]);dg=G.shape[1]
  sector=[r for r in blocks if r['N']==N];E=min(r['eigenvalues'][0]for r in sector);lo=min(r['eigenvalues'][0]-r['numerical_energy_budget']['energy_budget']for r in sector);hi=min(r['eigenvalues'][0]+r['numerical_energy_budget']['energy_budget']for r in sector);phys=physical_interval(case['mu'],N,E,lo,hi,cfg)
  sources=[p@G for p in pairs];A=np.column_stack([v.reshape(-1)for v in sources]);gamma=A.conj().T@A/dg
  occupations=[float(np.vdot(G,n@G).real/dg)for n in number];direct_pairs=[float(np.vdot(G,number[a]@number[b]@G).real/dg)for a,b in pair_grid()];onsite=[float(np.vdot(G,number[j]@number[4+j]@G).real/dg)for j in range(4)]
  grounds.append(dict(N=N,dimension=dg,members=members,energy_mu=E,energy_mu_lower=lo,energy_mu_upper=hi,energy_physical=phys['energy'],energy_lower=phys['lower'],energy_upper=phys['upper'],physical_shift_roundoff=phys['physical_shift_roundoff'],individual_energies=[bmap[m['block_key']]['eigenvalues'][m['eigen_index0']]for m in members],vectors=pack(G),projector=triplets(G@G.conj().T),pair_sources=[dict(pair_index=i,a=a,b=b,final_N=N-2,vectors=triplets(S))for i,((a,b),S)in enumerate(zip(pair_grid(),sources))],pair_density=pack(gamma),occupations=occupations,number_pair_diagonal=direct_pairs,onsite_double=onsite))
 gm={g['N']:g for g in grounds};bindings=[binding_record('B_h',gm[3],gm[2],gm[4],cfg),binding_record('B_e',gm[5],gm[4],gm[6],cfg)]
 result=dict(case_id=case['case_id'],U=case['U'],mu=case['mu'],boundary=case['boundary'],blocks=blocks,sector_spectra=spectra,grounds=grounds,bindings=bindings)
 if extra:result.update(extra)
 return result
def source_metadata(folder,cfg,freeze_sha):
 folder=Path(folder);assert len(freeze_sha)==64 and sha(folder/'source_freeze.json')==freeze_sha
 mode=os.environ['X16_ATTEMPT_MODE'];assert mode in ('pilot','production')
 return dict(schema=SCHEMA,release=cfg['release'],catalogue_id='X16',attempt_mode=mode,pilot_excluded_from_production=mode=='pilot',manifest_sha256=sha(folder/'manifest.toml'),source_freeze_sha256=freeze_sha,source_sha256={name:sha(folder/name)for name in SOURCE_FILES},native_sha256=cfg['native_sha256'],scientific_sampling=False,initial_ensemble=cfg['initial_ensemble'],fock_order=cfg['fock_order'])
def write_json_fresh(path,obj):
 raw=(json.dumps(obj,ensure_ascii=True,allow_nan=False,indent=2)+'\n').encode('utf-8')
 with Path(path).open('xb')as f:f.write(raw)
