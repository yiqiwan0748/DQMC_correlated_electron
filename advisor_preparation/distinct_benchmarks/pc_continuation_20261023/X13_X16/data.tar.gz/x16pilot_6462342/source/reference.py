#!/usr/bin/env python3
"""Independent QuSpin H/fermions and creation-string gauge; no native target import."""
import argparse, contextlib, hashlib, importlib.metadata, io, json, os, time, tomllib
from pathlib import Path
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from raw_io import SOURCE_FILES, sha, case_from_dense, pack, triplets, pair_grid, source_metadata, write_json_fresh

def compute(cfg,folder,freeze_sha):
    assert sha(folder/'source_freeze.json')==freeze_sha
    freeze=json.loads((folder/'source_freeze.json').read_bytes())
    assert all(sha(folder/name)==freeze['files'][name] for name in SOURCE_FILES)
    import numpy as np
    from quspin.basis import spinful_fermion_basis_1d
    from quspin.operators import hamiltonian
    for package,key in (('quspin','quspin_version'),('numpy','numpy_version'),('scipy','scipy_version')):
        assert importlib.metadata.version(package)==cfg[key],package+' runtime version'
    L=cfg['L'];basis=spinful_fermion_basis_1d(L)
    def op(static,hermitian=False):
        with contextlib.redirect_stdout(io.StringIO()):
            return np.asarray(hamiltonian(static,[],basis=basis,dtype=np.complex128,check_herm=hermitian,check_symm=False,check_pcon=False).toarray())
    qC=[op([['-|',[[1.,j]]]]) for j in range(L)]+[op([['|-',[[1.,j]]]]) for j in range(L)]
    qNu=[op([['n|',[[1.,j]]]]) for j in range(L)]; qNd=[op([['|n',[[1.,j]]]]) for j in range(L)]
    qcoords=[(sum(int(round(qNu[j][k,k].real))<<j for j in range(L)),sum(int(round(qNd[j][k,k].real))<<j for j in range(L))) for k in range(256)]
    assert len(set(qcoords))==256
    vacuum=qcoords.index((0,0)); T=np.zeros((256,256),complex); canonical_to_raw=[];phases=[]
    # This is a canonical creation-string construction, independent of any target sign rule.
    for u in range(16):
        for d in range(16):
            v=np.zeros(256,complex);v[vacuum]=1.
            occupied=[j for j in range(L) if u>>j&1]+[L+j for j in range(L) if d>>j&1]
            for mode in reversed(occupied):v=qC[mode].conj().T@v
            nonzero=np.flatnonzero(np.abs(v)>1e-12)
            assert len(nonzero)==1 and qcoords[nonzero[0]]==(u,d) and abs(abs(v[nonzero[0]])-1)<1e-12
            T[:,u*16+d]=v;canonical_to_raw.append(int(nonzero[0]));phases.append(complex(v[nonzero[0]]))
    assert np.max(np.abs(T.conj().T@T-np.eye(256)))<1e-12
    site_c=[T.conj().T@c@T for c in qC]
    bridge=dict(raw_coordinates=[list(v) for v in qcoords],raw_basis_states=[int(v) for v in basis.states],canonical_to_raw=canonical_to_raw,phases_real=[v.real for v in phases],phases_imag=[v.imag for v in phases],raw_site_annihilators=[triplets(c) for c in qC],derivation='vacuum plus canonical creation strings, descending application order; not fitted to target')
    cases=[]
    for case in cfg['cases']:
        hopping=[]
        for j in range(L):
            k=(j+1)%L;sign=-1. if case['boundary']=='apbc' and j==L-1 else 1.
            hopping.extend([[-cfg['t']*sign,j,k],[-cfg['t']*sign,k,j]])
        qH=op([['+-|',hopping],['|+-',hopping],['n|n',[[case['U'],j,j] for j in range(L)]],['n|',[[-case['mu'],j] for j in range(L)]],['|n',[[-case['mu'],j] for j in range(L)]]],True)
        H=T.conj().T@qH@T
        cases.append(case_from_dense(H,site_c,case,cfg,dict(raw_quspin_hamiltonian=triplets(qH))))
    metadata=source_metadata(folder,cfg,freeze_sha)
    metadata.update(backend='independent_quspin',versions={p:importlib.metadata.version(p) for p in ('quspin','numpy','scipy')},quspin_bridge=bridge)
    return dict(schema=metadata['schema'],metadata=metadata,site_annihilators=[triplets(c) for c in site_c],pair_annihilators=[dict(pair_index=i,a=a,b=b,matrix=triplets(site_c[b]@site_c[a]))for i,(a,b)in enumerate(pair_grid())],cases=cases,completion=dict(status='COMPLETE',finished_unix=time.time()))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--freeze-sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert not a.output.exists();cfg=tomllib.loads(a.manifest.read_text(encoding='utf-8'))
    write_json_fresh(a.output,compute(cfg,a.manifest.resolve().parent,a.freeze_sha256))
if __name__=='__main__':main()
