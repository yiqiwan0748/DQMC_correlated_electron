#!/usr/bin/env python3
"""Frozen X16 process driver; no submission, ledger, or sampling actions."""
import argparse,csv,io,json,math,os,re,subprocess,sys,time,tomllib
from pathlib import Path
from raw_io import SOURCE_FILES,sha,strict_json,write_json_fresh
ACTIVE={'RUNNING','COMPLETING','CONFIGURING','SUSPENDED','RESIZING'}
TERMINAL={'COMPLETED','FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE','REVOKED','SPECIAL_EXIT'}
THREADS=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','JULIA_NUM_THREADS')
def validate_active_queue(text,job_id,mode=None):
 assert re.fullmatch(r'[0-9]+',str(job_id)),'Own numeric job identity required'
 assert isinstance(text,str)and text.strip()and '\0'not in text,'Active queue unavailable/empty'
 rows=[];seen=set()
 for line in text.splitlines():
  parts=line.split('|');assert len(parts)==4,'Malformed active queue row'
  identity,state,cpus,name=(p.strip()for p in parts)
  assert re.fullmatch(r'[0-9]+(?:_[0-9]+)?',identity)and identity not in seen,'Unparsed/duplicate active job'
  assert state in ACTIVE and re.fullmatch(r'[1-9][0-9]*',cpus),'Unknown state or nonpositive/noninteger CPUs'
  assert name and not any(ord(c)<32 for c in name),'Missing/malformed JobName'
  assert identity==str(job_id)or name not in{'x16_pilot','x16_production'},'Another X16 science lane remains active'
  seen.add(identity);rows.append(dict(job_id=identity,state=state,cpus=int(cpus),job_name=name))
 assert 1<=len(rows)<=2 and sum(r['cpus']for r in rows)<=2,'Whole-user jobs/CPUs exceed two'
 own=[r for r in rows if r['job_id']==str(job_id)]
 assert len(own)==1 and own[0]['cpus']==1,'Own one-CPU job absent or ambiguous'
 assert (own[0]['job_name']=='x16_'+mode if mode is not None else own[0]['job_name']in{'x16_pilot','x16_production'}),'Own frozen JobName mismatch'
 return dict(schema='X16_ACTIVE_QUEUE_GUARD_V1',status='PASS',rows=rows,active_jobs=len(rows),active_cpus=sum(r['cpus']for r in rows))
def validate_previous_terminal(text,cfg):
 assert isinstance(text,str)and text.strip()and '\0'not in text
 reader=csv.DictReader(io.StringIO(text),delimiter='|');required={'JobIDRaw','State','User','AllocCPUS','Start','End','ExitCode'}
 assert reader.fieldnames is not None and len(set(reader.fieldnames))==len(reader.fieldnames)and required<=set(reader.fieldnames)
 rows=list(reader);expected=cfg['required_previous_job_ids'];assert len(expected)==len(set(expected))==12
 selected=[]
 for job in expected:
  found=[r for r in rows if r.get('JobIDRaw')==job];assert len(found)==1,'Missing/duplicate prior main-job identity'
  row=found[0];state=row['State'].split()[0].rstrip('+')
  assert row['User']==cfg['isaac_user']and state in TERMINAL,'Prior registered job is not freshly terminal/owned'
  assert re.fullmatch(r'[0-9]+',row['AllocCPUS'])and row['Start']and row['End']and re.fullmatch(r'[0-9]+:[0-9]+',row['ExitCode'])
  selected.append(row)
 # The query may include .batch/.extern step rows; no unregistered main jobs.
 assert all(None not in r and set(r)==set(reader.fieldnames)and(r.get('JobIDRaw')in expected or(r.get('JobIDRaw','').split('.')[0]in expected and re.fullmatch(r'[0-9]+\.(?:batch|extern|[0-9]+)',r.get('JobIDRaw',''))))for r in rows)
 return dict(schema='X16_PRIOR_TWELVE_TERMINAL_GUARD_V1',status='PASS',rows=selected)
def admission(cfg,mode,batch_start,now,queue,previous,job):
 assert mode in('pilot','production')and all(type(x)in(int,float)and math.isfinite(x)for x in(batch_start,now))
 assert cfg['science_cutoff_unix']==1792755300 and cfg['pilot_wall_cap_seconds']==300 and cfg['production_wall_cap_seconds']==1200 and cfg['pilot_serialized_suffix_seconds']==1500
 assert cfg['termination_guard_seconds']==6 and cfg['outer_KILL_grace_seconds']==5
 cap=cfg['pilot_wall_cap_seconds']if mode=='pilot'else cfg['production_wall_cap_seconds'];suffix=cfg['pilot_serialized_suffix_seconds']if mode=='pilot'else cap
 assert 0<batch_start<=now<batch_start+cap-6,'Own process cap/TERM reserve already exhausted'
 assert batch_start+suffix<=cfg['science_cutoff_unix'],'Complete predeclared serialized suffix does not fit before cutoff'
 return dict(schema='X16_ACTUAL_START_ADMISSION_V1',status='PASS',attempt_mode=mode,wall_cap_seconds=cap,serialized_suffix_seconds=suffix,actual_batch_start_unix=batch_start,checked_unix=now,cap_end_unix=batch_start+cap,science_cutoff_unix=cfg['science_cutoff_unix'],termination_guard_seconds=6,outer_KILL_grace_seconds=5,active_queue_guard=validate_active_queue(queue,job,mode),previous_terminal_guard=validate_previous_terminal(previous,cfg))
def regular_chain(path):
 path=Path(path).absolute()
 assert all(not p.is_symlink()for p in(path,*path.parents)),'Symlink path forbidden'
 return path
def pilot_terminal(text,job):
 assert re.fullmatch('[0-9]+',job)and isinstance(text,str)and text.strip()and '\0'not in text
 reader=csv.DictReader(io.StringIO(text),delimiter='|');names=reader.fieldnames;needed={'JobIDRaw','JobName','State','User','AllocCPUS','Start','End','ExitCode'}
 assert names and len(set(names))==len(names)and needed<=set(names);rows=list(reader)
 assert all(None not in r and set(r)==set(names)and(r['JobIDRaw']==job or r['JobIDRaw']in{job+'.batch',job+'.extern'})for r in rows)
 main=[r for r in rows if r['JobIDRaw']==job];assert len(main)==1;row=main[0]
 assert row['JobName']=='x16_pilot'and row['State']=='COMPLETED'and row['User']=='ywang287'and row['AllocCPUS']=='1'and row['ExitCode']=='0:0'and row['Start']and row['End'],'Pilot not freshly owned COMPLETED0:0'
 return row
def production_pilot_guard(root,cfg,freeze_sha,env):
 """Read-only administrative readiness; no pilot physics is pooled or evaluated."""
 job=env['X16_EXPECTED_PILOT_JOB_ID'];assert re.fullmatch('[0-9]+',job)
 path=regular_chain(env['X16_PILOT_READINESS']);assert root/'submissions'in path.parents
 pin=env['X16_EXPECTED_PILOT_READINESS_SHA256'];assert re.fullmatch('[0-9a-f]{64}',pin)and sha(path)==pin
 approval=strict_json(path.read_bytes());assert approval['schema']=='X16_PILOT_READINESS_APPROVAL_V1'and approval['status']=='ROOT_APPROVED_FOR_FIXED_PRODUCTION'
 assert approval['job_id']==job and approval['release']==cfg['release']and approval['source_freeze_sha256']==freeze_sha and approval['scientific_completions']==0 and approval['pilot_wall_cap_seconds']==300
 roles={'independent_audit','auditor_source','auditor_peer_review','auditor_validation','transfer','scheduler'};assert set(approval['artifacts'])==roles;artifacts={}
 for role,row in approval['artifacts'].items():
  p=regular_chain(row['path']);assert root/'submissions'in p.parents and re.fullmatch('[0-9a-f]{64}',row['sha256'])and p.is_file()and sha(p)==row['sha256'];artifacts[role]=p
 audit=strict_json(artifacts['independent_audit'].read_bytes())
 assert audit['schema']=='X16_INDEPENDENT_RAW_AUDIT_V1'and audit['integrity_status']=='PASS'and audit['attempt_mode']=='pilot'and audit['job_id']==job and audit['source_freeze_sha256']==freeze_sha
 assert audit['audit_tool_sha256']==approval['artifacts']['auditor_source']['sha256']and audit['scientific_sampling']is False and audit['remote_calls']is False
 assert audit['pilot_readiness']['status']=='READY'and audit['pilot_readiness']['numerical_qualification']is True and audit['pilot_readiness']['full_grid_cross_backend_match']is True and audit['pilot_readiness']['timing_precision_ready']is True
 assert audit['failed_checks']==0 and audit['input_sha256']and audit['check_count']==len(audit['checks'])>0 and all(row['passed']is True for row in audit['checks'])
 for role in('transfer','scheduler'):
  assert approval['artifacts'][role]['sha256']in audit['input_sha256'].values(),'Independent audit must bind original transfer and scheduler bytes'
 pilot=regular_chain(root/'results'/(cfg['release']+'_pilot_'+job));assert pilot.is_dir()
 expected={'preflight.json','active_queue.txt','previous_twelve_terminal.txt','scontrol.txt','target.toml','reference.json','comparison.json','execution.json','process_exit_codes.txt'}|{n+'.'+s for n in('target','reference','comparator')for s in('stdout.txt','stderr.txt','resources.txt','process.json')}
 outputs=approval['pilot_output_sha256'];assert set(outputs)==expected and outputs==audit['pilot_output_sha256']
 assert all(regular_chain(pilot/n).is_file()and sha(pilot/n)==d for n,d in outputs.items())
 execution=strict_json((pilot/'execution.json').read_bytes());comparison=strict_json((pilot/'comparison.json').read_bytes())
 assert execution['schema']=='X16_EXECUTION_RECEIPT_V1'and execution['status']=='PROCESSES_COMPLETE'and execution['attempt_mode']=='pilot'and execution['pilot_excluded_from_production']is True and execution['job_id']==job
 assert execution['source_freeze_sha256']==freeze_sha and execution['wall_cap_seconds']==300 and execution['serialized_suffix_seconds']==1500 and execution['termination_guard_seconds']==6 and execution['outer_KILL_grace_seconds']==5 and execution['source_unchanged']is True and execution['native_unchanged']is True
 assert execution['cpus']==1 and execution['memory_mb']==3500 and execution['process_exit_codes']in({'target':0,'reference':0,'comparator':0},{'target':0,'reference':0,'comparator':2})and execution['pilot_readiness_exit_code']==0
 assert 0<execution['actual_batch_start_unix']<=execution['worker_start_unix']<=execution['finished_unix']<execution['cap_end_unix']<=cfg['science_cutoff_unix']and execution['cap_end_unix']==execution['actual_batch_start_unix']+300
 assert execution['output_sha256']=={n:d for n,d in outputs.items()if n!='execution.json'}
 assert comparison['attempt_mode']=='pilot'and comparison['catalogue_status']=='PILOT_EXCLUDED'and comparison['scientific_completions']==0 and comparison['pilot_readiness']['status']=='READY'and comparison['pilot_readiness']['numerical_qualification']is True and comparison['pilot_readiness']['full_grid_cross_backend_match']is True
 assert [comparison[k]for k in('complete_cases','spinblocks_per_backend','fixedN_ground_ensembles','pair_modes','complex_pairdensity_entries')]==[4,76,20,28,15680]
 live=pilot_terminal(env['X16_PILOT_TERMINAL_SNAPSHOT'],job)
 assert all(line.split('|')[0].strip()!=job for line in env['X16_ACTIVE_QUEUE_SNAPSHOT'].splitlines()),'Expected pilot still active under any JobName'
 return dict(schema='X16_PRODUCTION_PILOT_GUARD_V1',status='PASS',job_id=job,source_freeze_sha256=freeze_sha,readiness_path=str(path),readiness_sha256=pin,artifacts=approval['artifacts'],pilot_output_sha256=outputs,live_terminal_row=live,live_terminal_snapshot=env['X16_PILOT_TERMINAL_SNAPSHOT'],read_only_qualification=True,production_physics_pooling=False)
def prepare(source,root,output,freeze_sha,batch_start,mode):
 source,root,output=(regular_chain(p)for p in(source,root,output));cfg=tomllib.loads((source/'manifest.toml').read_text(encoding='utf-8'))
 job=os.environ['SLURM_JOB_ID'];assert re.fullmatch(r'[0-9]+',job)
 assert not output.exists()and output.parent==root/'results'and output.parent.is_dir()and output.name==cfg['release']+'_'+mode+'_'+job
 assert os.environ['X16_ATTEMPT_MODE']==mode and os.environ['SLURM_CPUS_PER_TASK']=='1'and all(os.environ.get(k)=='1'for k in THREADS)
 assert re.fullmatch('[0-9a-f]{64}',freeze_sha)and sha(source/'source_freeze.json')==freeze_sha
 freeze=strict_json((source/'source_freeze.json').read_bytes());files=freeze['files'];assert freeze['release']==cfg['release']and set(files)==set(SOURCE_FILES)|{'SHA256SUMS'}
 assert {p.name for p in source.iterdir()}==set(files)|{'source_freeze.json'}and all((source/n).is_file()and not(source/n).is_symlink()and re.fullmatch('[0-9a-f]{64}',d)and sha(source/n)==d for n,d in files.items())
 sums={};sumraw=(source/'SHA256SUMS').read_bytes();assert b'\r'not in sumraw and sumraw.endswith(b'\n')
 for line in sumraw.decode('ascii').splitlines():
  digest,name=line.split('  ',1);assert name not in sums and name in SOURCE_FILES;sums[name]=digest
 assert set(sums)==set(SOURCE_FILES)and all(sums[n]==files[n]for n in SOURCE_FILES)and all(b'\r'not in(source/n).read_bytes()for n in files)
 native=regular_chain(root/'source/renyi_disjoint_corrected');pins={cfg['native_relative_path']:cfg['native_sha256'],'Project.toml':cfg['native_project_sha256'],'Manifest.toml':cfg['native_manifest_sha256']}
 assert all(regular_chain(native/n).is_file()and sha(native/n)==d for n,d in pins.items())
 guard=admission(cfg,mode,batch_start,time.time(),os.environ['X16_ACTIVE_QUEUE_SNAPSHOT'],os.environ['X16_PREVIOUS_TERMINAL_SNAPSHOT'],job)
 guard['pilot_qualification']=production_pilot_guard(root,cfg,freeze_sha,os.environ)if mode=='production'else dict(status='EXCLUDED_PILOT_NO_PRIOR_PRODUCTION_INPUT')
 return cfg,native,files,pins,guard
def run(source,root,output,freeze_sha,batch_start,mode):
 cfg,native,files,pins,guard=prepare(source,root,output,freeze_sha,batch_start,mode);output.mkdir(exist_ok=False);os.environ['RENYI_ROOT']=str(native)
 receipt=dict(schema='X16_EXECUTION_RECEIPT_V1',job_id=os.environ['SLURM_JOB_ID'],release=cfg['release'],catalogue_id='X16',attempt_mode=mode,pilot_excluded_from_production=mode=='pilot',status='STARTED',source_freeze_sha256=freeze_sha,source_sha256=files,native_source_sha256=pins,actual_batch_start_unix=batch_start,worker_start_unix=time.time(),wall_cap_seconds=guard['wall_cap_seconds'],serialized_suffix_seconds=guard['serialized_suffix_seconds'],cap_end_unix=guard['cap_end_unix'],science_cutoff_unix=cfg['science_cutoff_unix'],termination_guard_seconds=6,outer_KILL_grace_seconds=5,cpus=1,memory_mb=3500,scientific_sampling=False,scientific_completions=0,new_adapter=True,process_group_id=os.getpgrp(),actual_start_admission=guard,threads={k:os.environ[k]for k in THREADS},processes=[],process_exit_codes={})
 write_json_fresh(output/'preflight.json',receipt)
 for name,env in [('previous_twelve_terminal.txt','X16_PREVIOUS_TERMINAL_SNAPSHOT'),('active_queue.txt','X16_ACTIVE_QUEUE_SNAPSHOT')]:
  with(output/name).open('xb')as f:f.write((os.environ[env]+'\n').encode('utf-8'))
 with(output/'scontrol.txt').open('xb')as f:subprocess.run(['scontrol','show','job',os.environ['SLURM_JOB_ID']],stdout=f,stderr=subprocess.STDOUT,check=True)
 common=['--manifest',str(source/'manifest.toml'),'--freeze-sha256',freeze_sha]
 commands=[('target',[str(root/'runtime/julia-1.12.1/bin/julia'),'--startup-file=no','--history-file=no','--project='+str(native),str(source/'target.jl')]+common+['--output',str(output/'target.toml')]),('reference',[sys.executable,'-B',str(source/'reference.py')]+common+['--output',str(output/'reference.json')]),('comparator',[sys.executable,'-B',str(source/'compare.py')]+common+['--target',str(output/'target.toml'),'--reference',str(output/'reference.json'),'--output',str(output/'comparison.json')])]
 code=2
 for name,command in commands:
  assert time.time()<min(cfg['science_cutoff_unix'],guard['cap_end_unix']-6)and all(sha(source/n)==d for n,d in files.items())
  start=time.time()
  with(output/(name+'.stdout.txt')).open('xb')as out,(output/(name+'.stderr.txt')).open('xb')as err:
   completed=subprocess.run(['/usr/bin/time','-v','-o',str(output/(name+'.resources.txt'))]+command,stdout=out,stderr=err,check=False)
  code=completed.returncode;row=dict(name=name,command=command,start_unix=start,end_unix=time.time(),exit_code=code,process_group_inherited=True);receipt['processes'].append(row);receipt['process_exit_codes'][name]=code;write_json_fresh(output/(name+'.process.json'),row)
  if name!='comparator'and code!=0:break
 receipt.update(status='PROCESSES_COMPLETE'if set(receipt['process_exit_codes'])=={'target','reference','comparator'}else'EXECUTION_ERROR',finished_unix=time.time(),source_unchanged=all(sha(source/n)==d for n,d in files.items()),native_unchanged=all(sha(native/n)==d for n,d in pins.items()))
 if mode=='pilot':
  readiness=strict_json((output/'comparison.json').read_bytes()).get('pilot_readiness',{})if receipt['status']=='PROCESSES_COMPLETE'else{}
  receipt['pilot_readiness_exit_code']=0 if readiness.get('status')=='READY'and receipt['source_unchanged']and receipt['native_unchanged']and code in(0,2)else 2
 with(output/'process_exit_codes.txt').open('x',encoding='ascii',newline='\n')as f:
  for name in('target','reference','comparator'):f.write(name+'_exit='+str(receipt['process_exit_codes'].get(name,'NOT_RUN'))+'\n')
 receipt['output_sha256']={p.name:sha(p)for p in sorted(output.iterdir())if p.is_file()};write_json_fresh(output/'execution.json',receipt)
 return receipt['pilot_readiness_exit_code']if mode=='pilot'else code if receipt['status']=='PROCESSES_COMPLETE'else 2
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check-admission',action='store_true');p.add_argument('--source',type=Path,required=True);p.add_argument('--mode',choices=('pilot','production'),required=True);p.add_argument('--job-id');p.add_argument('--validation-root',type=Path);p.add_argument('--output',type=Path);p.add_argument('--freeze-sha256');p.add_argument('--batch-start-unix',type=float,required=True);a=p.parse_args()
 if a.check_admission:
  assert a.job_id and all(v is None for v in(a.validation_root,a.output,a.freeze_sha256));cfg=tomllib.loads((a.source/'manifest.toml').read_text(encoding='utf-8'));print(json.dumps(admission(cfg,a.mode,a.batch_start_unix,time.time(),os.environ['X16_ACTIVE_QUEUE_SNAPSHOT'],os.environ['X16_PREVIOUS_TERMINAL_SNAPSHOT'],a.job_id),sort_keys=True));return 0
 assert a.validation_root is not None and a.output is not None and a.freeze_sha256 and a.job_id is None
 return run(a.source.absolute(),a.validation_root.absolute(),a.output.absolute(),a.freeze_sha256,a.batch_start_unix,a.mode)
if __name__=='__main__':raise SystemExit(main())
