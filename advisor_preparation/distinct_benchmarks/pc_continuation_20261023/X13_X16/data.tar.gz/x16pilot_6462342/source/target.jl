#!/usr/bin/env julia
# NEW full pair/sector observer through unchanged native Hamiltonian action.
using LinearAlgebra, TOML, SHA
BLAS.set_num_threads(1)
length(ARGS)%2==0 || error("option/value arguments required")
const OPT=Dict(ARGS[i]=>ARGS[i+1] for i in 1:2:length(ARGS))
const MANIFEST=abspath(OPT["--manifest"])
const RELEASE=dirname(MANIFEST)
const CFG=TOML.parsefile(MANIFEST)
const OUTPUT=abspath(OPT["--output"])
const FREEZE=OPT["--freeze-sha256"]
ispath(OUTPUT) && error("fresh output required")
sha(path)=bytes2hex(sha256(read(path)))
sha(joinpath(RELEASE,"source_freeze.json"))==FREEZE || error("freeze pin")
const NATIVE_ROOT=abspath(ENV["RENYI_ROOT"])
const NATIVE=joinpath(NATIVE_ROOT,CFG["native_relative_path"])
sha(NATIVE)==CFG["native_sha256"] || error("native source pin")
string(VERSION)==CFG["julia_version"] || error("Julia version")
module NativeED
include(Main.NATIVE)
end

function pack(A)
    Dict("rows"=>size(A,1),"columns"=>size(A,2),"real"=>vec(permutedims(real.(A))),"imag"=>vec(permutedims(imag.(complex.(A)))))
end
function triplets(A)
    rows=Int[];cols=Int[];re=Float64[];im=Float64[]
    for i in axes(A,1),j in axes(A,2)
        iszero(A[i,j]) && continue
        push!(rows,i-1);push!(cols,j-1);push!(re,real(A[i,j]));push!(im,imag(A[i,j]))
    end
    Dict("rows"=>size(A,1),"columns"=>size(A,2),"row0"=>rows,"column0"=>cols,"real"=>re,"imag"=>im)
end
function site_annihilator(spin,site)
    C=zeros(ComplexF64,256,256);bit=1<<site
    for up in 0:15,dn in 0:15
        mask=spin=="up" ? up : dn
        (mask&bit)==0 && continue
        parity=count_ones(mask&(bit-1))+(spin=="down" ? count_ones(up) : 0)
        u=spin=="up" ? xor(up,bit) : up;d=spin=="down" ? xor(dn,bit) : dn
        C[u*16+d+1,up*16+dn+1]=isodd(parity) ? -1. : 1.
    end
    C
end
const SITE_C=[site_annihilator(spin,j) for spin in ("up","down") for j in 0:3]
function materialize(space)
    n=NativeED.dimension(space);H=zeros(n,n);v=zeros(n);out=zeros(n)
    for j in 1:n
        fill!(v,0.);v[j]=1.;NativeED.apply_hamiltonian!(out,v,space);H[:,j]=out
    end
    H
end
function cluster_records(records)
    sort!(records;by=r->(r["energy"],r["block_key"],r["eigen_index0"]))
    groups=Vector{Vector{Dict{String,Any}}}()
    for row in records
        if isempty(groups) || row["energy"]-groups[end][1]["energy"]>CFG["gates"]["cluster_diameter_max"]
            push!(groups,Dict{String,Any}[])
        end
        push!(groups[end],row)
    end
    [Dict("energy"=>sum(r["energy"] for r in g)/length(g),"energy_min"=>minimum(r["energy"] for r in g),"energy_max"=>maximum(r["energy"] for r in g),"members"=>[Dict("block_key"=>r["block_key"],"eigen_index0"=>r["eigen_index0"]) for r in g]) for g in groups]
end

const PAIR_GRID=[(a,b) for a in 0:7 for b in a+1:7]
const PAIR_C=[SITE_C[b+1]*SITE_C[a+1] for (a,b) in PAIR_GRID]
function energy_budget(H,e,V)
    n=length(e);factor=CFG["uncertainty"]["roundoff_guard_factor"];eps64=CFG["uncertainty"]["unit_roundoff_budget"]
    gram=norm(V'*V-I);residual=norm(H*V-V*Diagonal(e));h=norm(H);d=maximum(abs.(e);init=0.)
    delta=gram+factor*eps64*n;roundoff=factor*eps64*n*max(1.,h,d)
    delta<1 || error("Complete eigenbasis not invertible")
    s=sqrt(1-delta);eta=(residual+roundoff)/s+2*d*delta/(s*(1+s))+roundoff
    Dict("dimension"=>n,"gram_fro"=>gram,"residual_fro"=>residual,"H_fro"=>h,"D_max"=>d,"delta"=>delta,"roundoff"=>roundoff,"energy_budget"=>eta)
end
function binding_record(name,odd,low,high)
    factor=CFG["uncertainty"]["roundoff_guard_factor"];eps64=CFG["uncertainty"]["unit_roundoff_budget"]
    pad=factor*eps64*max(1.,2*abs(odd["energy_physical"])+abs(low["energy_physical"])+abs(high["energy_physical"]))
    value=2*odd["energy_physical"]-low["energy_physical"]-high["energy_physical"]
    lo=2*odd["energy_lower"]-low["energy_upper"]-high["energy_upper"]-pad
    hi=2*odd["energy_upper"]-low["energy_lower"]-high["energy_lower"]+pad
    sign=lo>0 ? "BOUND" : hi<0 ? "NONBINDING" : "UNRESOLVED"
    Dict("name"=>name,"odd_N"=>odd["N"],"even_N"=>[low["N"],high["N"]],"value"=>value,"lower"=>lo,"upper"=>hi,"halfwidth"=>(hi-lo)/2,"roundoff"=>pad,"classification"=>sign,"conditional_numerical_budget"=>true)
end
function compute_case(case)
    blocks=Dict{String,Any}[];bmap=Dict{String,Any}();vectors=Dict{Tuple{String,Int},Vector{ComplexF64}}()
    records=Dict(N=>Dict{String,Any}[] for N in CFG["total_N"])
    for N in CFG["total_N"],up in 0:4
        dn=N-up;0<=dn<=4 || continue
        space=NativeED.build_space(4,CFG["t"],case["U"],case["mu"],up,dn;boundary=case["boundary"])
        H=materialize(space);dec=eigen(Symmetric(H))
        coords=[[Int(u),Int(d)] for u in space.up_masks for d in space.dn_masks];ids=[16*c[1]+c[2]+1 for c in coords]
        key="N$(N)_up$(up)_dn$(dn)"
        row=Dict{String,Any}("block_key"=>key,"N"=>N,"Nup"=>up,"Ndown"=>dn,"coordinates"=>coords,"Hamiltonian"=>pack(H),"eigenvalues"=>dec.values,"eigenvectors"=>pack(dec.vectors),"numerical_energy_budget"=>energy_budget(H,dec.values,dec.vectors))
        push!(blocks,row);bmap[key]=row
        for j in eachindex(dec.values)
            v=zeros(ComplexF64,256);v[ids]=dec.vectors[:,j];vectors[(key,j-1)]=v
            push!(records[N],Dict{String,Any}("energy"=>dec.values[j],"block_key"=>key,"eigen_index0"=>j-1))
        end
    end
    spectra=[Dict("N"=>N,"clusters"=>cluster_records(records[N])) for N in CFG["total_N"]]
    smap=Dict(s["N"]=>s["clusters"] for s in spectra);grounds=Dict{String,Any}[]
    number=[c'*c for c in SITE_C]
    for N in CFG["total_N"]
        gc=smap[N][1];members=gc["members"];G=hcat([vectors[(m["block_key"],m["eigen_index0"])] for m in members]...);dg=size(G,2)
        sector=[r for r in blocks if r["N"]==N];E=minimum(minimum(r["eigenvalues"]) for r in sector)
        lo=minimum(minimum(r["eigenvalues"])-r["numerical_energy_budget"]["energy_budget"] for r in sector)
        hi=minimum(minimum(r["eigenvalues"])+r["numerical_energy_budget"]["energy_budget"] for r in sector)
        pad=CFG["uncertainty"]["roundoff_guard_factor"]*CFG["uncertainty"]["unit_roundoff_budget"]*max(1.,abs(E),abs(case["mu"]*N))
        sources=[p*G for p in PAIR_C];gamma=[dot(sources[i],sources[j])/dg for i in 1:28,j in 1:28]
        occupations=[real(dot(G,n*G))/dg for n in number]
        direct_pairs=[real(dot(G,number[a+1]*number[b+1]*G))/dg for (a,b) in PAIR_GRID]
        onsite=[real(dot(G,number[j+1]*number[j+5]*G))/dg for j in 0:3]
        pair_sources=[Dict("pair_index"=>i-1,"a"=>a,"b"=>b,"final_N"=>N-2,"vectors"=>triplets(S)) for (i,((a,b),S)) in enumerate(zip(PAIR_GRID,sources))]
        push!(grounds,Dict("N"=>N,"dimension"=>dg,"members"=>members,"energy_mu"=>E,"energy_mu_lower"=>lo,"energy_mu_upper"=>hi,"energy_physical"=>E+case["mu"]*N,"energy_lower"=>lo+case["mu"]*N-pad,"energy_upper"=>hi+case["mu"]*N+pad,"physical_shift_roundoff"=>pad,"individual_energies"=>[bmap[m["block_key"]]["eigenvalues"][m["eigen_index0"]+1] for m in members],"vectors"=>pack(G),"projector"=>triplets(G*G'),"pair_sources"=>pair_sources,"pair_density"=>pack(gamma),"occupations"=>occupations,"number_pair_diagonal"=>direct_pairs,"onsite_double"=>onsite))
    end
    gm=Dict(r["N"]=>r for r in grounds)
    bindings=[binding_record("B_h",gm[3],gm[2],gm[4]),binding_record("B_e",gm[5],gm[4],gm[6])]
    Dict("case_id"=>case["case_id"],"U"=>case["U"],"mu"=>case["mu"],"boundary"=>case["boundary"],"blocks"=>blocks,"sector_spectra"=>spectra,"grounds"=>grounds,"bindings"=>bindings)
end
function main_adapter()
    started=time();started<CFG["science_cutoff_unix"] || error("science cutoff")
    CFG["total_N"]==[2,3,4,5,6]&&CFG["L"]==4&&CFG["t"]==1. || error("Fixed full grid")
    mode=ENV["X16_ATTEMPT_MODE"];mode in ("pilot","production") || error("Declared attempt mode")
    sourcefiles=["manifest.toml","PROTOCOL.md","PROVENANCE.json","raw_io.py","target.jl","reference.py","compare.py","run_candidate.py","pilot.sbatch","production.sbatch","README.md","test_candidate.py","catalogue_X16.json"]
    pins=Dict(CFG["native_relative_path"]=>sha(NATIVE),"Project.toml"=>sha(joinpath(NATIVE_ROOT,"Project.toml")),"Manifest.toml"=>sha(joinpath(NATIVE_ROOT,"Manifest.toml")))
    metadata=Dict("schema"=>"X16_PAIR_BINDING_RAW_V1","release"=>CFG["release"],"catalogue_id"=>"X16","attempt_mode"=>mode,"pilot_excluded_from_production"=>(mode=="pilot"),"manifest_sha256"=>sha(MANIFEST),"source_freeze_sha256"=>FREEZE,"source_sha256"=>Dict(n=>sha(joinpath(RELEASE,n)) for n in sourcefiles),"native_sha256"=>sha(NATIVE),"native_source_sha256"=>pins,"scientific_sampling"=>false,"initial_ensemble"=>CFG["initial_ensemble"],"fock_order"=>CFG["fock_order"],"backend"=>"native_ed_new_pair_adapter","versions"=>Dict("julia"=>string(VERSION)),"started_unix"=>started)
    cases=[compute_case(case) for case in CFG["cases"]]
    time()<CFG["science_cutoff_unix"] || error("science cutoff")
    sha(NATIVE)==CFG["native_sha256"] || error("native source changed")
    result=Dict("schema"=>"X16_PAIR_BINDING_RAW_V1","metadata"=>metadata,"site_annihilators"=>triplets.(SITE_C),"pair_annihilators"=>[Dict("pair_index"=>i-1,"a"=>a,"b"=>b,"matrix"=>triplets(p)) for (i,((a,b),p)) in enumerate(zip(PAIR_GRID,PAIR_C))],"cases"=>cases,"completion"=>Dict("status"=>"COMPLETE","finished_unix"=>time()))
    open(OUTPUT,"w") do io;TOML.print(io,result;sorted=true);end
end
main_adapter()
