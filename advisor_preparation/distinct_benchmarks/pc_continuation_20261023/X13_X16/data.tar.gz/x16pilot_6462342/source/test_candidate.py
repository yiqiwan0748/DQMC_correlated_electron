#!/usr/bin/env python3
"""Source/guard/integer algebra fixtures only; no Hamiltonian or model solve."""
import argparse,ast,hashlib,json,math,sys,tempfile,time,tomllib
from fractions import Fraction
from pathlib import Path
import raw_io
import run_candidate as driver
ROOT=Path(__file__).resolve().parent
CFG=tomllib.loads((ROOT/'manifest.toml').read_text(encoding='utf-8'))
CHECKS=[]
def check(name,passed,detail=None):
 assert passed,name
 CHECKS.append(dict(name=name,passed=True,detail=detail))
def rejects(call):
 try:call()
 except(AssertionError,ValueError,TypeError,KeyError,IndexError):return True
 return False
def action(mode,index,dagger=False):
 u,d=divmod(index,16);mask=u if mode<4 else d;bit=1<<(mode%4);occupied=bool(mask&bit)
 if occupied==dagger:return None
 lower=(u&((1<<mode)-1)).bit_count()if mode<4 else u.bit_count()+(d&((1<<(mode-4))-1)).bit_count()
 out=((u^bit)*16+d)if mode<4 else u*16+(d^bit)
 return out,(-1 if lower%2 else 1)
def compose(first,second,index):
 b=action(second[0],index,second[1])
 if b is None:return {}
 a=action(first[0],b[0],first[1])
 return {}if a is None else {a[0]:a[1]*b[1]}
def add(a,b):
 out=dict(a)
 for k,v in b.items():out[k]=out.get(k,0)+v
 return {k:v for k,v in out.items()if v}
def pair_source(a,b,state):
 out={}
 for index,amplitude in state.items():
  for dest,sign in compose((b,False),(a,False),index).items():out[dest]=out.get(dest,0)+amplitude*sign
 return out
def pilot_fixture(root):
 """Administrative byte-only metadata fixture; no model/raw math evaluation."""
 job='998';freeze='a'*64;pilot=root/'results'/('x16_pair_binding_v1_pilot_'+job);pilot.mkdir(parents=True);admin=root/'submissions'/'pilot';admin.mkdir(parents=True)
 names={'preflight.json','active_queue.txt','previous_twelve_terminal.txt','scontrol.txt','target.toml','reference.json','process_exit_codes.txt'}|{n+'.'+s for n in('target','reference','comparator')for s in('stdout.txt','stderr.txt','resources.txt','process.json')}
 for name in names:(pilot/name).write_bytes(b'ADMINISTRATIVE FIXTURE ONLY\n')
 ready=dict(status='READY',numerical_qualification=True,full_grid_cross_backend_match=True,timing_precision_ready=True)
 comparison=dict(attempt_mode='pilot',catalogue_status='PILOT_EXCLUDED',scientific_completions=0,pilot_readiness=ready,complete_cases=4,spinblocks_per_backend=76,fixedN_ground_ensembles=20,pair_modes=28,complex_pairdensity_entries=15680)
 raw_io.write_json_fresh(pilot/'comparison.json',comparison)
 execution=dict(schema='X16_EXECUTION_RECEIPT_V1',status='PROCESSES_COMPLETE',attempt_mode='pilot',pilot_excluded_from_production=True,job_id=job,source_freeze_sha256=freeze,wall_cap_seconds=300,serialized_suffix_seconds=1500,termination_guard_seconds=6,outer_KILL_grace_seconds=5,source_unchanged=True,native_unchanged=True,cpus=1,memory_mb=3500,process_exit_codes={'target':0,'reference':0,'comparator':2},pilot_readiness_exit_code=0,actual_batch_start_unix=100.,worker_start_unix=101.,finished_unix=200.,cap_end_unix=400.,output_sha256={p.name:raw_io.sha(p)for p in pilot.iterdir()})
 raw_io.write_json_fresh(pilot/'execution.json',execution);outputs={p.name:raw_io.sha(p)for p in pilot.iterdir()}
 roles={'auditor_source','auditor_peer_review','auditor_validation','transfer','scheduler'}
 for role in roles:(admin/(role+'.txt')).write_bytes((role+' source-onlyfixture\n').encode('ascii'))
 artifacts={role:dict(path=str(admin/(role+'.txt')),sha256=raw_io.sha(admin/(role+'.txt')))for role in roles}
 audit=dict(schema='X16_INDEPENDENT_RAW_AUDIT_V1',integrity_status='PASS',attempt_mode='pilot',job_id=job,source_freeze_sha256=freeze,audit_tool_sha256=artifacts['auditor_source']['sha256'],scientific_sampling=False,remote_calls=False,pilot_readiness=ready,failed_checks=0,check_count=1,checks=[dict(passed=True)],input_sha256={artifacts[r]['path']:artifacts[r]['sha256']for r in('transfer','scheduler')},pilot_output_sha256=outputs)
 raw_io.write_json_fresh(admin/'audit.json',audit);artifacts['independent_audit']=dict(path=str(admin/'audit.json'),sha256=raw_io.sha(admin/'audit.json'))
 approval=dict(schema='X16_PILOT_READINESS_APPROVAL_V1',status='ROOT_APPROVED_FOR_FIXED_PRODUCTION',job_id=job,release=CFG['release'],source_freeze_sha256=freeze,scientific_completions=0,pilot_wall_cap_seconds=300,artifacts=artifacts,pilot_output_sha256=outputs)
 raw_io.write_json_fresh(admin/'approval.json',approval)
 live='JobIDRaw|JobName|State|User|AllocCPUS|Start|End|ExitCode\n998|x16_pilot|COMPLETED|ywang287|1|start|end|0:0'
 env=dict(X16_EXPECTED_PILOT_JOB_ID=job,X16_PILOT_READINESS=str(admin/'approval.json'),X16_EXPECTED_PILOT_READINESS_SHA256=raw_io.sha(admin/'approval.json'),X16_PILOT_TERMINAL_SNAPSHOT=live,X16_ACTIVE_QUEUE_SNAPSHOT='999|RUNNING|1|x16_production')
 return env,freeze,pilot,admin
def rebind_admin_fixture(env,pilot,admin):
 """Rehash intentionally bad metadata so rejection tests reach semantic gates."""
 outputs={p.name:raw_io.sha(p)for p in pilot.iterdir()};audit=raw_io.strict_json((admin/'audit.json').read_bytes());audit['pilot_output_sha256']=outputs;(admin/'audit.json').write_bytes((json.dumps(audit)+'\n').encode('ascii'))
 approval=raw_io.strict_json((admin/'approval.json').read_bytes());approval['pilot_output_sha256']=outputs;approval['artifacts']['independent_audit']['sha256']=raw_io.sha(admin/'audit.json');(admin/'approval.json').write_bytes((json.dumps(approval)+'\n').encode('ascii'));env['X16_EXPECTED_PILOT_READINESS_SHA256']=raw_io.sha(admin/'approval.json')
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists();started=time.time()
 check('exact13 complete LF ASCII source roles',set(v.name for v in ROOT.iterdir())==set(raw_io.SOURCE_FILES)and all(b'\r'not in(ROOT/n).read_bytes()for n in raw_io.SOURCE_FILES)and all((ROOT/n).read_bytes().isascii()for n in raw_io.SOURCE_FILES))
 for name in raw_io.SOURCE_FILES:
  if name.endswith('.py'):ast.parse((ROOT/name).read_text(encoding='utf-8'),filename=name)
 check('all Python AST parses',True)
 check('literal criterion and fixed complete cases',CFG['catalogue_id']=='X16'and CFG['literal_acceptance']==raw_io.strict_json((ROOT/'catalogue_X16.json').read_bytes())['acceptance']and[(c['U'],c['boundary'],c['mu'])for c in CFG['cases']]==[(2.,'pbc',1.),(2.,'apbc',1.),(4.,'pbc',2.),(4.,'apbc',2.)])
 grid=raw_io.block_grid();dims=[sum(math.comb(4,u)*math.comb(4,d)for n,u,d in grid if n==N)for N in CFG['total_N']]
 check('all76 spinblocks and952 complete eigenvalues per backend',len(grid)==19 and dims==[28,56,70,56,28]and sum(dims)*4==952)
 check('full20 ground ensembles28 modes15680 complex entries',len(raw_io.pair_grid())==28 and len(set(raw_io.pair_grid()))==28 and 4*5*28*28==15680)
 car_count=0
 for i in range(8):
  for j in range(8):
   for index in range(256):
    assert not add(compose((i,False),(j,False),index),compose((j,False),(i,False),index))
    assert add(compose((i,False),(j,True),index),compose((j,True),(i,False),index))==({index:1}if i==j else{})
    car_count+=2
 check('full integer Fock same/cross-spin CAR',True,dict(scalar_relations=car_count))
 for index in range(256):
  N=sum(v.bit_count()for v in divmod(index,16));total=sum(sum(v*v for v in pair_source(i,j,{index:1}).values())for i,j in raw_io.pair_grid());assert total==N*(N-1)//2
 check('allbasis wedge trace and diagonal count identity',True,dict(basis_vectors=256))
 state={((1<<i)|(1<<j))*17:1 for i in range(4)for j in range(i+1,4)}
 sources=[pair_source(i,i+4,state)for i in range(4)]
 gamma=[[Fraction(sum(x.get(k,0)*y.get(k,0)for k in set(x)|set(y)),6)for y in sources]for x in sources]
 check('pair condensate admits eigenvalue above one',all(gamma[i][i]==Fraction(1,2)for i in range(4))and sum(sum(row)for row in gamma)/4==Fraction(3,2))
 check('no forbidden pairdensity upper-eigenvalue-one gate','Gamma<=I condition' in(ROOT/'PROTOCOL.md').read_text(encoding='utf-8')and 'Gamma<=I'not in(ROOT/'compare.py').read_text(encoding='utf-8'))
 norm=raw_io.spectral_budget_from_norms(2,0.,0.,3.,2.,CFG)
 check('completebasis scalar polar budget finite positive',norm['dimension']==2 and 0<norm['energy_budget']<1e-8 and norm['delta']<1)
 check('bad fullbasis budget rejected',rejects(lambda:raw_io.spectral_budget_from_norms(2,1.,0.,1.,1.,CFG))and rejects(lambda:raw_io.spectral_budget_from_norms(2,0.,float('nan'),1.,1.,CFG)))
 def row(N,e,w):return dict(N=N,energy_physical=e,energy_lower=e-w,energy_upper=e+w)
 bound=raw_io.binding_record('B_h',row(3,2.,1e-10),row(2,1.,1e-10),row(4,1.,1e-10),CFG);negative=raw_io.binding_record('B_e',row(5,0.,1e-10),row(4,1.,1e-10),row(6,1.,1e-10),CFG);cross=raw_io.binding_record('B_h',row(3,1.,1e-10),row(2,1.,1e-10),row(4,1.,1e-10),CFG)
 check('binding propagated bounds/signs with no forced binding',bound['classification']=='BOUND'and negative['classification']=='NONBINDING'and cross['classification']=='UNRESOLVED'and bound['lower']<2<bound['upper']and bound['halfwidth']<5e-8)
 for mu in(1.,2.):assert 2*(3*mu)-2*mu-4*mu==0 and 2*(5*mu)-4*mu-6*mu==0
 check('chemical potential cancels both definitions',True)
 check('strict duplicate/nonfinite JSON',rejects(lambda:raw_io.strict_json('{"x":1,"x":2}'))and rejects(lambda:raw_io.strict_json('{"x":NaN}')))
 check('strict numeric scalar codecs reject before numpy import',all(rejects(lambda value=v:raw_io.finite_numbers(value))for v in([True],['1'],[None],[float('inf')]))and rejects(lambda:raw_io.unpack(dict(rows=1,columns=1,real=[True],imag=[0.])))and rejects(lambda:raw_io.from_triplets(dict(rows=1,columns=1,row0=[0],column0=[0],real=['1'],imag=[0.]))))
 check('strict typed cluster/eigenvector membership and primitive norms',rejects(lambda:raw_io.member_records([dict(block_key='N2_up1_dn1',eigen_index0=False)]))and rejects(lambda:raw_io.spectral_budget_from_norms(2,False,0.,1.,1.,CFG)))
 raw='JobIDRaw|State|User|AllocCPUS|Start|End|ExitCode\n'+'\n'.join(job+'|COMPLETED|ywang287|1|2026-10-23T00:00:00|2026-10-23T01:00:00|0:0'for job in CFG['required_previous_job_ids']);queue='999|RUNNING|1|x16_pilot';cut=CFG['science_cutoff_unix']
 good=driver.admission(CFG,'pilot',cut-1500,cut-1500,queue,raw,'999');check('full pilot suffix exact actualclock admission',good['serialized_suffix_seconds']==1500 and good['wall_cap_seconds']==300 and good['previous_terminal_guard']['status']=='PASS')
 badqueues=['','999|PENDING|1|x16_pilot','999|RUNNING|0|x16_pilot','999|RUNNING|-1|x16_pilot','999|RUNNING|1.0|x16_pilot','999|RUNNING|1|x16_pilot|x','998|RUNNING|1|unrelated','999|RUNNING|1|x16_pilot\n999|RUNNING|1|x16_pilot','999|RUNNING|2|x16_pilot','999|RUNNING|1|x16_pilot\n998|RUNNING|1|unrelated\n997|RUNNING|1|other','999|RUNNING|1|x16_pilot\n998|RUNNING|2|unrelated','999|RUNNING|1|x16_pilot\n998|RUNNING|1|x16_production','999|RUNNING|1|x16_pilot\n998|RUNNING|1|x16_pilot','999|RUNNING|1|']
 check('all14 malformed/overcapacity/serial JobName queue fixtures reject',all(rejects(lambda text=t:driver.validate_active_queue(text,'999'))for t in badqueues))
 badprior=[raw.replace('6460990|COMPLETED','6460990|RUNNING'),raw.replace('6460990|COMPLETED|ywang287','6460990|COMPLETED|someone'),raw+'\n'+raw.splitlines()[1],raw.replace(raw.splitlines()[1]+'\n',''),raw+'\n9999.batch|COMPLETED|ywang287|1|x|y|0:0']
 check('own mode name and overlapping pilot reject',rejects(lambda:driver.admission(CFG,'production',cut-1200,cut-1200,queue,raw,'999'))and driver.admission(CFG,'production',cut-1200,cut-1200,queue.replace('x16_pilot','x16_production'),raw,'999')['active_queue_guard']['status']=='PASS')
 check('all5 prior terminal identity/closure fixtures reject',all(rejects(lambda text=t:driver.validate_previous_terminal(text,CFG))for t in badprior))
 check('fractional late suffix/cap boundaries reject',all(rejects(f)for f in(lambda:driver.admission(CFG,'pilot',cut-1500+.000001,cut-1500+.000001,queue,raw,'999'),lambda:driver.admission(CFG,'production',cut-1200+.000001,cut-1200+.000001,queue,raw,'999'),lambda:driver.admission(CFG,'pilot',cut-1500,cut-1206,queue,raw,'999'))))
 import compare
 policy=compare.Checks();policy.check('case/B_h all signs resolved',False)
 check('only physical sign ambiguity exempt for pilot numerical readiness',policy.numerical_qualification and not policy.passed)
 policy.check('case/B_h predeclared binding precision',False);check('precision failure never exempt for pilot',not policy.numerical_qualification)
 with tempfile.TemporaryDirectory(prefix='x16_admin_fixture_',dir=ROOT.parent)as tmp:
  fixture=Path(tmp).absolute();assert fixture.parent==ROOT.parent
  env,freeze,pilot,admin=pilot_fixture(fixture)
  guard=driver.production_pilot_guard(fixture,CFG,freeze,env)
  check('production readiness verifies21 original pilot outputs and six approved artifacts',guard['status']=='PASS'and len(guard['pilot_output_sha256'])==21 and guard['production_physics_pooling']is False)
  check('running/nonzero/mismatched pilot refuses production',all(rejects(lambda text=t:driver.pilot_terminal(text,'998'))for t in(env['X16_PILOT_TERMINAL_SNAPSHOT'].replace('COMPLETED','RUNNING'),env['X16_PILOT_TERMINAL_SNAPSHOT'].replace('0:0','2:0'),env['X16_PILOT_TERMINAL_SNAPSHOT'].replace('ywang287','other'))))
  altered=dict(env);altered['X16_ACTIVE_QUEUE_SNAPSHOT']='999|RUNNING|1|x16_production\n998|RUNNING|1|renamed'
  check('expected active pilot rejected even under unrelated name',rejects(lambda:driver.production_pilot_guard(fixture,CFG,freeze,altered)))
  check('same frozen source required for readiness',rejects(lambda:driver.production_pilot_guard(fixture,CFG,'b'*64,env)))
  before=(pilot/'target.toml').read_bytes();(pilot/'target.toml').write_bytes(b'tamperedfixture')
  check('changed original pilot output refuses production',rejects(lambda:driver.production_pilot_guard(fixture,CFG,freeze,env)));(pilot/'target.toml').write_bytes(before)
  before=(admin/'audit.json').read_bytes();(admin/'audit.json').write_bytes(b'changedfixture')
  check('changed independent pilot audit refuses production',rejects(lambda:driver.production_pilot_guard(fixture,CFG,freeze,env)));(admin/'audit.json').write_bytes(before)
  badroot=fixture/'bad_precision';env2,freeze2,pilot2,admin2=pilot_fixture(badroot);bad=raw_io.strict_json((admin2/'audit.json').read_bytes());bad['pilot_readiness']['timing_precision_ready']=False;(admin2/'audit.json').write_bytes((json.dumps(bad)+'\n').encode('ascii'));rebind_admin_fixture(env2,pilot2,admin2)
  check('hash-consistent but false independent precision readiness refuses',rejects(lambda:driver.production_pilot_guard(badroot,CFG,freeze2,env2)))
  badroot=fixture/'bad_cap';env3,freeze3,pilot3,admin3=pilot_fixture(badroot);bad=raw_io.strict_json((pilot3/'execution.json').read_bytes());bad['wall_cap_seconds']=1200;(pilot3/'execution.json').write_bytes((json.dumps(bad)+'\n').encode('ascii'));rebind_admin_fixture(env3,pilot3,admin3)
  check('hash-consistent wrong pilot process cap refuses',rejects(lambda:driver.production_pilot_guard(badroot,CFG,freeze3,env3)))
 check('freeze absence hard gate before output/model',not(ROOT/'source_freeze.json').exists()and 'source_freeze.json' in(ROOT/'run_candidate.py').read_text(encoding='ascii')and 'check=True' in(ROOT/'run_candidate.py').read_text(encoding='ascii'))
 sourcehash={n:raw_io.sha(ROOT/n)for n in raw_io.SOURCE_FILES};result=dict(schema='X16_SOURCE_ONLY_VALIDATION_V1',status='PASS',scientific_sampling=False,native_or_model_execution=False,remote_calls=False,scientific_completions=0,elapsed_seconds=time.time()-started,check_count=len(CHECKS),checks=CHECKS,files=sourcehash,limits='Integer Fock actions and scalar synthetic intervals only; no H construction/eigensolve, NumPy, native or actual receipt replay')
 raw_io.write_json_fresh(a.output,result);print(json.dumps(dict(status='PASS',check_count=len(CHECKS),output=str(a.output)),sort_keys=True))
if __name__=='__main__':main()
