#!/usr/bin/env python3
"""Adapt immutable failed execution evidence, reuse EXACT original forecast.
The original execution status is never rewritten as PROCESSES_COMPLETE.
"""
import argparse,hashlib,importlib.util,json,math,textwrap,tomllib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return tomllib.loads(p.read_text()) if p.suffix=='.toml' else json.loads(p.read_text())
def main():
    p=argparse.ArgumentParser();p.add_argument('--original-source',type=Path,required=True);p.add_argument('--pilot-dir',type=Path,required=True);p.add_argument('--repair-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert not a.output.exists();inputs={};out={'schema':'PYSCF_RECOVERED_PILOT_RESOURCE_ASSESSMENT_V1','status':'UNRESOLVED','production_admitted':False,'scientific_completions':0}
    def bound(path):inputs[str(path)]={'sha256':sha(path),'bytes':path.stat().st_size};return load(path)
    try:
        pins=bound(ROOT/'original_pilot_pins.json');freeze=bound(a.original_source/'source_freeze.json')
        assert sha(a.original_source/'source_freeze.json')==pins['source_freeze_sha256']
        for n,h in freeze['files'].items():assert sha(a.original_source/n)==h
        cfg=bound(a.original_source/'manifest.toml');policy=cfg['resource_policy']
        assert sha(a.original_source/'manifest.toml')==pins['manifest_sha256']
        original=bound(a.pilot_dir/'execution.json');assert sha(a.pilot_dir/'execution.json')==pins['original_execution_sha256']
        assert original['status']=='UNRESOLVED' and original['error']=='RuntimeError: comparator failed; no blind retry'
        assert original['source_freeze_sha256']==pins['source_freeze_sha256'] and original['mode']=='pilot' and original['scientific_completions']==0
        assert sha(a.pilot_dir/'comparator.stderr.txt')==pins['serialization_traceback_sha256']
        processes={r['name']:r for r in original['processes']};assert set(processes)=={'target','reference','comparator'}
        assert [processes[k]['exit_code'] for k in ('target','reference','comparator')]==[0,0,1]
        assert original['finished_unix']<=original['deadline_unix'] and original['finished_unix']-original['started_unix']<=cfg['pilot_timeout_seconds']
        for n,h in pins['raw_sha256'].items():assert sha(a.pilot_dir/n)==h
        for n,record in original['outputs'].items():assert sha(a.pilot_dir/n)==record['sha256'] and (a.pilot_dir/n).stat().st_size==record['bytes']
        comparison=bound(a.repair_dir/'comparison.json');repaired=bound(a.repair_dir/'repair_receipt.json');timing=bound(a.repair_dir/'postprocessing_process.json')
        assert repaired['status']=='COMPARATOR_COMPLETE' and repaired['comparator_exit_code']==0 and repaired['original_source_and_raw_unchanged'] is True
        assert repaired['other_unsupported_types_converted']==0 and repaired['numpy_bool_leaves_converted']>0
        assert repaired['output_sha256']==sha(a.repair_dir/'comparison.json') and repaired['original_comparator_sha256']==freeze['files']['compare.py']
        assert timing['exit_code']==0 and timing['wrapper_sha256']==sha(ROOT/'strict_numpy_bool_json.py')==repaired['wrapper_sha256']
        assert timing['finished_unix']>timing['started_unix'] and timing['cpus']==1 and timing['blas_threads']==1
        assert comparison['mode']=='pilot' and comparison['completion_count']==0 and comparison['pilot_excluded'] is True and comparison['numerically_eligible'] is True
        assert all(c['passed'] for c in comparison['checks']) and all(r['status']=='NOT_RUN' and r['pilot_numerical_status']=='PASS' for r in comparison['rows'])
        assert {r['id'] for r in comparison['rows']}=={'P23','P24'}
        assert sorted(comparison['input_sha256'].values())==sorted([pins['raw_sha256']['target.toml'],pins['raw_sha256']['reference.json'],pins['manifest_sha256']])
        spec=importlib.util.spec_from_file_location('original_frozen_resource_formula',a.original_source/'assess_pilot_resources.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        target=bound(a.pilot_dir/'target.toml');reference=bound(a.pilot_dir/'reference.json')
        t=m.phases(target,['native_matrix_and_full_action','full_diagonalization','spin_and_directed_operators','all_final_transition_action'])
        q=m.phases(reference,['fci_matrix','spin_and_directed_operators','full_diagonalization','all_final_transition_rdms'])
        assert [c['id'] for c in target['cases']]==[c['id'] for c in reference['cases']]==cfg['pilot_case_ids']
        coldwall={k:r['finished_unix']-r['started_unix'] for k,r in processes.items()}
        # Conservatively retain BOTH original failed processing and fresh
        # processing costs. Producers and cold/warm measurements are unchanged.
        coldwall['comparator']+=timing['finished_unix']-timing['started_unix']
        files={k+'.resources.txt':a.pilot_dir/(k+'.resources.txt') for k in processes}
        old_comparator_peak=m.rss(files['comparator.resources.txt'])
        files['comparator.resources.txt']=a.repair_dir/'postprocessing.resources.txt'
        def peak(path):return max(m.rss(path),old_comparator_peak) if path==files['comparator.resources.txt'] else m.rss(path)
        for path in files.values():inputs[str(path)]={'sha256':sha(path),'bytes':path.stat().st_size}
        inputs[str(a.pilot_dir/'comparator.resources.txt')]={'sha256':sha(a.pilot_dir/'comparator.resources.txt'),'bytes':(a.pilot_dir/'comparator.resources.txt').stat().st_size}
        text=(a.original_source/'assess_pilot_resources.py').read_text()
        start=text.index("        R=policy['dimension_ratio']");end=text.index('        out.update(',start)
        formula=textwrap.dedent(text[start:end])
        scope=dict(policy=policy,coldwall=coldwall,t=t,q=q,comparison=comparison,processes=processes,files=files,cfg=cfg,rss=peak,math=math)
        # Execute the reviewed ORIGINAL engineering formula unchanged. No model
        # producer, eigensolver, PySCF or sampling function is called here.
        exec(compile(formula,str(a.original_source/'assess_pilot_resources.py')+'#exact_original_formula','exec'),scope)
        out.update(status='WITHIN_PREREGISTERED_ENGINEERING_LIMITS' if scope['fits'] else 'EXCEEDS_PREREGISTERED_ENGINEERING_LIMITS',
          root_resource_review_ready=scope['fits'],original_execution_status=original['status'],original_comparator_exit_code=1,
          original_producers_rerun=False,original_source_and_raw_unchanged=True,scientific_gates_changed=False,
          formula_source_sha256=sha(a.original_source/'assess_pilot_resources.py'),formula_fragment_sha256=hashlib.sha256(formula.encode()).hexdigest(),
          actual_process_wall_seconds_including_both_comparator_attempts=coldwall,actual_peak_rss_envelope_mib=scope['peaks'],
          projected_process_seconds=scope['projected'],projected_total_seconds=scope['total'],projected_peak_mib=scope['projected_peak'],
          maximum_projected_peak_mib=scope['peak'],thresholds=policy,warm_case_phases=scope['derivation'],warm_comparator_seconds=scope['warm_audit'],
          interpretation='OriginalFAILEDexecution retained. Serialization-only recovery; same original resource formula/gates, conservative sum of comparator wall and maxofpeaks. Root review required, never automatic admission.')
    except Exception as e:out['reason']=type(e).__name__+': '+str(e)
    out['inputs']=inputs;out['assessor_sha256']=sha(__file__)
    a.output.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:out[k] for k in ('status','production_admitted','scientific_completions')}))
    return 0 if out['status']=='WITHIN_PREREGISTERED_ENGINEERING_LIMITS' else 2
if __name__=='__main__':raise SystemExit(main())
