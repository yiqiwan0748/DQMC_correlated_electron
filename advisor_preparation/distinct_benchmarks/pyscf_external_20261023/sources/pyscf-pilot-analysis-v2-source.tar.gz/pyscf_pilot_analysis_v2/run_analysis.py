#!/usr/bin/env python3
"""Root-admitted, bounded postprocessing ONLY of completed failed pilot."""
import argparse,hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--original-source',type=Path,required=True);ap.add_argument('--pilot-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);a=ap.parse_args()
    if os.environ.get('PYSCF_ANALYSIS_ADMITTED')!='yes':raise RuntimeError('Root admission required')
    assert sha(ROOT/'source_freeze.json')==os.environ['PYSCF_ANALYSIS_FREEZE_SHA256']
    freeze=json.loads((ROOT/'source_freeze.json').read_text());assert all(sha(ROOT/n)==h for n,h in freeze['files'].items())
    assert os.environ['SLURM_CPUS_PER_TASK']=='1'
    a.output_dir.mkdir(parents=True,exist_ok=False)
    env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
    cmd=[sys.executable,'-B',str(ROOT/'strict_numpy_bool_json.py'),'--original-source',str(a.original_source),'--pilot-dir',str(a.pilot_dir),'--output',str(a.output_dir/'comparison.json'),'--receipt',str(a.output_dir/'repair_receipt.json')]
    record=dict(schema='PYSCF_POSTPROCESSING_PROCESS_V1',started_unix=time.time(),cpus=1,blas_threads=1,physics_executed=False,scientific_completions=0,wrapper_sha256=sha(ROOT/'strict_numpy_bool_json.py'),argv=cmd)
    record['analysis_source_freeze_sha256']=os.environ['PYSCF_ANALYSIS_FREEZE_SHA256']
    active=None
    def cleanup():
        if active is not None and active.poll() is None:
            try:os.killpg(active.pid,signal.SIGTERM)
            except ProcessLookupError:return
            try:active.wait(timeout=4)
            except subprocess.TimeoutExpired:os.killpg(active.pid,signal.SIGKILL);active.wait()
    def stop(sig,frame):cleanup();raise RuntimeError('Interrupted '+str(sig))
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        with (a.output_dir/'postprocessing.stdout.txt').open('w') as out,(a.output_dir/'postprocessing.stderr.txt').open('w') as err:
            active=subprocess.Popen(['/usr/bin/time','-v','-o',str(a.output_dir/'postprocessing.resources.txt'),*cmd],stdout=out,stderr=err,env=env,start_new_session=True)
            try:record['exit_code']=active.wait(timeout=110)
            except subprocess.TimeoutExpired:cleanup();record['exit_code']=2;record['error']='Postprocessing timeout'
    except Exception as e:cleanup();record['exit_code']=2;record['error']=type(e).__name__+': '+str(e)
    record['finished_unix']=time.time()
    (a.output_dir/'postprocessing_process.json').write_text(json.dumps(record,indent=2)+'\n')
    if record['exit_code']!=0:raise SystemExit(record['exit_code'])
    assess=[sys.executable,'-B',str(ROOT/'assess_recovered_pilot.py'),'--original-source',str(a.original_source),'--pilot-dir',str(a.pilot_dir),'--repair-dir',str(a.output_dir),'--output',str(a.output_dir/'resource_assessment.json')]
    with (a.output_dir/'assessor.stdout.txt').open('w') as out,(a.output_dir/'assessor.stderr.txt').open('w') as err:
        assessed=subprocess.run(assess,stdout=out,stderr=err,env=env,timeout=20)
    raise SystemExit(assessed.returncode)
if __name__=='__main__':main()
