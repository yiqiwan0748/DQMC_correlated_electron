#!/usr/bin/env python3
"""Run the unchanged frozen comparator; convert ONLY NumPy bool JSON leaves.
No native Julia or PySCF solver import, no scientific producer rerun.
"""
import argparse,hashlib,json,os,runpy,sys,time
from pathlib import Path
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import numpy as np
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--original-source',type=Path,required=True);p.add_argument('--pilot-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--receipt',type=Path,required=True);a=p.parse_args()
    if a.output.exists() or a.receipt.exists():raise ValueError('Fresh outputs required')
    pins=json.loads((ROOT/'original_pilot_pins.json').read_text());source=a.original_source.resolve()
    assert np.__version__=='2.4.6'
    assert sha(source/'source_freeze.json')==pins['source_freeze_sha256']
    freeze=json.loads((source/'source_freeze.json').read_text())
    before={source/n:h for n,h in freeze['files'].items()}
    before[source/'source_freeze.json']=pins['source_freeze_sha256']
    for n,h in pins['raw_sha256'].items():before[a.pilot_dir/n]=h
    for path,h in before.items():assert sha(path)==h,str(path)
    original_dumps=json.dumps;converted=0;started=time.time();exitcode=2;exception=None
    def only_numpy_bool(value):
        nonlocal converted
        if isinstance(value,np.bool_):converted+=1;return bool(value)
        raise TypeError('Unsupported JSON type remains rejected: '+type(value).__module__+'.'+type(value).__name__)
    def strict_dumps(value,*args,**kwargs):
        if 'default' in kwargs:raise TypeError('Frozen comparator unexpectedly supplied a JSON default')
        return original_dumps(value,*args,default=only_numpy_bool,**kwargs)
    saved_argv=sys.argv[:]
    try:
        json.dumps=strict_dumps
        sys.argv=[str(source/'compare.py'),'--manifest',str(source/'manifest.toml'),'--mode','pilot','--target',str(a.pilot_dir/'target.toml'),'--reference',str(a.pilot_dir/'reference.json'),'--output',str(a.output)]
        try:runpy.run_path(str(source/'compare.py'),run_name='__main__');exitcode=0
        except SystemExit as e:exitcode=int(e.code or 0)
    except Exception as e:exception=type(e).__name__+': '+str(e)
    finally:json.dumps=original_dumps;sys.argv=saved_argv
    for path,h in before.items():assert sha(path)==h,'Changed immutable input '+str(path)
    result=dict(schema='PYSCF_STRICT_BOOL_SERIALIZATION_REPAIR_V1',status='COMPARATOR_COMPLETE' if a.output.is_file() and exception is None else 'UNRESOLVED',
      original_comparator_sha256=sha(source/'compare.py'),wrapper_sha256=sha(__file__),original_freeze_sha256=pins['source_freeze_sha256'],
      original_source_and_raw_unchanged=True,numpy_bool_leaves_converted=converted,other_unsupported_types_converted=0,
      comparator_exit_code=exitcode,exception=exception,started_unix=started,finished_unix=time.time(),
      output_sha256=sha(a.output) if a.output.is_file() else None,physics_executed=False,scientific_completions=0)
    result.update(python_version=sys.version,numpy_version=np.__version__,host=os.uname().nodename,blas_thread_environment=os.environ['OPENBLAS_NUM_THREADS'])
    result['input_sha256']={**{'original_source/'+n:h for n,h in freeze['files'].items()},'original_source/source_freeze.json':pins['source_freeze_sha256'],**{'original_raw/'+n:h for n,h in pins['raw_sha256'].items()}}
    a.receipt.write_text(original_dumps(result,indent=2)+'\n')
    raise SystemExit(exitcode)
if __name__=='__main__':main()
