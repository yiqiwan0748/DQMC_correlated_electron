P23/P24 are prepared for independent source review. **No science has run; both remain NOT_RUN.** The adapters compare the actual user two-orbital open-cluster Hamiltonian against PySCF2.14.0 custom-integral FCI contraction. They cover interacting low excitation manifolds with invariant spin labels (P23), and directed orbital transition strengths from PySCF transition RDMs (P24).

Read PROTOCOL.md and manifest.toml for the frozen scientific scope. The six primary plaquette cases are (Nup,Ndown)=(1,1)/(2,2), U=0/2/6, original anisotropic hoppings with t4=-.65. The mandatory seventh, analytically solvable interacting dimer distinguishes C=a†b from C†: its exact total strengths are 2 and 0. Complete eigensystems and whole degenerate manifolds prevent column-phase fitting or partial excited-state selection.

The actual user APIs exercised are `open_cluster_kinetic_matrix`, `sector_hamiltonian`, `dense_sector_hamiltonian`, matrix-free `mul!`, and the fermionic `_hop` helper. Spin and transition observers, complete eigendecomposition and source wrappers are explicitly new adapters. This does not claim a pre-existing native PySCF, transition-RDM, or iterative excited-state solver.

The pinned primary sources are saved, unmodified, in primary_sources/ with URL/hash receipts in SOURCES.json. They are API references and are not imported instead of the installed PySCF package:

- [PySCF2.14.0 direct_spin1](https://github.com/pyscf/pyscf/blob/v2.14.0/pyscf/fci/direct_spin1.py): fixed-alpha/beta CI storage, absorb_h1e factor, contract_2e, transition-RDM convention.
- [PySCF2.14.0 spin_op](https://github.com/pyscf/pyscf/blob/v2.14.0/pyscf/fci/spin_op.py): actual S² contraction.
- [PySCF2.14.0 rdm](https://github.com/pyscf/pyscf/blob/v2.14.0/pyscf/fci/rdm.py): dm[p,q]=<c_q†c_p>.
- [PySCF2.14.0 addons](https://github.com/pyscf/pyscf/blob/v2.14.0/pyscf/fci/addons.py): alpha/beta creation/destruction and cross-spin parity.
- [PySCF2.14.0 cistring](https://github.com/pyscf/pyscf/blob/v2.14.0/pyscf/fci/cistring.py): determinant string ordering.

The independently constructed chemist integrals contain onsite (pp|pp)=U only; no molecular orbitals, SCF fit, Hund coupling or hidden spin penalty is introduced. Native centered energies are converted to physical Hubbard energies. Reference CI strings and native basis labels are mapped by their declared masks, without fitting phases to the native answer.

pilot.sbatch and production.sbatch are **admission-gated templates, not submitted jobs**. Root must review the source and exact freeze, specify ISAAC_ROOT, PYSCF_RELEASE_DIR, JULIA_BIN and PYSCF_APPROVED_FREEZE_SHA256, and explicitly set PYSCF_EXECUTION_ADMITTED to the selected mode. The installed isolated reference environment is `$ISAAC_ROOT/pyscf-venv/bin/python`; native code comes from this release's explicit immutable open-cluster snapshot, never from a similarly named 1D HubbardRenyi source. Production additionally needs a reviewed pilot. Pilot-only output contributes zero completed ideas.

Each mode has one serial combined time budget and one CPU, 3500 MB. Missing API/raw data, failed qualification, timeout or incomplete grids remain UNRESOLVED. There is no automatic retry or precision extension. No tool in this preparation changes a ledger or publishes results.
