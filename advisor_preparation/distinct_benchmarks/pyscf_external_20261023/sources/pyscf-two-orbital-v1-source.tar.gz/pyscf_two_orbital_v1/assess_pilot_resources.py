#!/usr/bin/env python3
"""Stdlib-only preregistered engineering projection from completed pilot.
No solver, raw physics recomputation, submission or production admission.
"""
import argparse,hashlib,json,math,re,tomllib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
    text=p.read_text();return tomllib.loads(text) if p.suffix=='.toml' else json.loads(text)
def rss(p):
    m=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',p.read_text())
    if not m:raise ValueError('Missing GNU time peakRSS '+p.name)
    return int(m.group(1))/1024
def phases(raw,expected):
    assert raw['mode']=='pilot' and len(raw['resource_repeat_cases'])==1
    repeat=raw['resource_repeat_cases'][0];assert repeat['id']=='N2_U2' and repeat['dimension']==64
    times=repeat['timing_seconds'];assert set(times)==set(expected)
    assert all(math.isfinite(v) and v>=0 for v in times.values())
    return times
def main():
    p=argparse.ArgumentParser();p.add_argument('--pilot-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    if a.output.exists():raise ValueError('Refuse overwrite')
    inputs={};out={'schema':'PYSCF_PILOT_RESOURCE_ASSESSMENT_V1','status':'UNRESOLVED','production_admitted':False,'scientific_completions':0}
    try:
        files={n:a.pilot_dir/n for n in ['target.toml','reference.json','comparison.json','execution.json','target.resources.txt','reference.resources.txt','comparator.resources.txt']}
        for n,f in files.items():assert f.is_file();inputs[n]={'sha256':sha(f),'bytes':f.stat().st_size}
        cfg=load(ROOT/'manifest.toml');policy=cfg['resource_policy'];comparison=load(files['comparison.json']);execution=load(files['execution.json'])
        assert comparison['mode']=='pilot' and comparison['completion_count']==0 and comparison['pilot_excluded'] is True
        assert comparison['numerically_eligible'] is True and all(x['passed'] for x in comparison['checks'])
        assert sorted(comparison['input_sha256'].values())==sorted([sha(files['target.toml']),sha(files['reference.json']),sha(ROOT/'manifest.toml')])
        assert {r['id'] for r in comparison['rows']}=={'P23','P24'} and all(r['status']=='NOT_RUN' and r['pilot_numerical_status']=='PASS' for r in comparison['rows'])
        assert execution['status']=='PROCESSES_COMPLETE' and execution['mode']=='pilot' and execution['scientific_completions']==0
        assert execution['source_freeze_sha256']==sha(ROOT/'source_freeze.json')
        for name,path in files.items():
            if name!='execution.json':assert execution['outputs'][name]['sha256']==sha(path) and execution['outputs'][name]['bytes']==path.stat().st_size
        assert execution['finished_unix']<=execution['deadline_unix'] and execution['finished_unix']-execution['started_unix']<=cfg['pilot_timeout_seconds']
        processes={r['name']:r for r in execution['processes']};assert set(processes)=={'target','reference','comparator'}
        assert all(r['exit_code']==0 and r['finished_unix']>r['started_unix'] for r in processes.values())
        coldwall={k:r['finished_unix']-r['started_unix'] for k,r in processes.items()}
        target,reference=load(files['target.toml']),load(files['reference.json'])
        t=phases(target,['native_matrix_and_full_action','full_diagonalization','spin_and_directed_operators','all_final_transition_action'])
        q=phases(reference,['fci_matrix','spin_and_directed_operators','full_diagonalization','all_final_transition_rdms'])
        assert [c['id'] for c in target['cases']]==[c['id'] for c in reference['cases']]==cfg['pilot_case_ids']
        reference_pins=load(ROOT/'reference_library_pins.json');assert reference['reference_library_sha256']==reference_pins['files']
        R=policy['dimension_ratio'];assert R==784/64
        f=policy['runtime_safety_factor'];pc=policy['particle_complexity_guard'];io=policy['fixed_io_allowance_per_process_seconds']
        projected={};derivation={}
        for name,times in [('target',t),('reference',q)]:
            diagonal=times['full_diagonalization'];other=sum(times.values())-diagonal
            # Entire actual pilot wall is retained as fixed overhead. Two more
            # 64-dim primary cases plus three784-dim cases remain. A4x guard
            # allows occupation/ground-multiplicity changes in contraction/RDM.
            added_small=2*pc*sum(times.values())
            added_large=3*(pc*R**policy['contraction_power']*other+R**policy['diagonalization_power']*diagonal)
            projected[name]=f*(coldwall[name]+added_small+added_large)+io
            derivation[name]={'actual_cold_pilot_wall':coldwall[name],'warm64_phases':times,'added_small_case_seconds':added_small,'added_large_case_seconds':added_large}
        warm_audit=comparison['resource_warm_postprocessing_seconds'];assert math.isfinite(warm_audit) and warm_audit>0
        projected['comparator']=f*(coldwall['comparator']+2*pc*warm_audit+3*R**3*warm_audit)+io
        peaks={k:rss(files[k+'.resources.txt']) for k in processes}
        d2=sum(c['dimension']**2 for c in cfg['cases'])
        extra_mib=policy['bytes_per_retained_dimension_squared']*d2/1024**2
        projected_peak={k:policy['memory_safety_factor']*(v+extra_mib) for k,v in peaks.items()}
        total=sum(projected.values());peak=max(projected_peak.values())
        fits=total<=policy['maximum_projected_total_seconds'] and peak<=policy['maximum_projected_peak_mib']
        out.update(status='WITHIN_PREREGISTERED_ENGINEERING_LIMITS' if fits else 'EXCEEDS_PREREGISTERED_ENGINEERING_LIMITS',
          root_resource_review_ready=fits,actual_process_wall_seconds=coldwall,actual_peak_rss_mib=peaks,
          actual_pilot_wall_seconds=execution['finished_unix']-execution['started_unix'],warm_case_phases=derivation,
          warm_comparator_seconds=warm_audit,projected_process_seconds=projected,projected_total_seconds=total,
          projected_peak_mib=projected_peak,maximum_projected_peak_mib=peak,thresholds=policy,
          assumption='Conservative empirical engineering projection, not a guaranteed timing/RSS upper bound. Root review still required; never automatically submits or expands allocation.')
    except Exception as e:out['reason']=type(e).__name__+': '+str(e)
    out['inputs']=inputs;out['assessor_sha256']=sha(__file__);out['manifest_sha256']=sha(ROOT/'manifest.toml')
    a.output.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps({k:out[k] for k in ['status','production_admitted','scientific_completions']}))
    return 0 if out['status']=='WITHIN_PREREGISTERED_ENGINEERING_LIMITS' else 2
if __name__=='__main__':raise SystemExit(main())
