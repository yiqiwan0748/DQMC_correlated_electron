#!/usr/bin/env python3
"""Independent receipt postprocessing, never producer/library solver execution."""
import argparse,hashlib,json,math,sys,time,tomllib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
    text=Path(p).read_text()
    return tomllib.loads(text) if str(p).endswith('.toml') else json.loads(text)
def matrix(row):
    out=np.zeros(row['shape'])
    ii,jj=np.asarray(row['row'],dtype=int),np.asarray(row['col'],dtype=int)
    assert len(ii)==len(jj)==len(row['value']) and len(set(zip(ii,jj)))==len(ii)
    assert all(0<=i<out.shape[0] for i in ii) and all(0<=j<out.shape[1] for j in jj)
    out[ii,jj]=row['value'];return out
def err(x):return float(np.max(np.abs(x))) if np.size(x) else 0.
def clusters(E,diameter):
    out=[];start=0
    for j in range(1,len(E)+1):
        if j==len(E) or E[j]-E[start]>diameter:
            out.append(np.arange(start,j));start=j
    return out

class Audit:
    def __init__(self,gates):self.rows=[];self.g=gates
    def add(self,name,value,limit,phase='qualification'):
        self.rows.append(dict(name=name,value=float(value),limit=float(limit),phase=phase,passed=math.isfinite(value) and value<=limit))
    def need(self,name,ok,phase='qualification'):self.add(name,0. if ok else 1.,0.,phase)

def one_backend(raw,spec,cfg,a,backend,tag=''):
    prefix=backend+tag+'/'+spec['id'];dim=spec['dimension'];N=spec['Nup']+spec['Ndown']
    assert (raw['Nup'],raw['Ndown'],raw['U'],raw['dimension'])==(spec['Nup'],spec['Ndown'],spec['U'],dim)
    coords=list(zip(raw['basis_up'],raw['basis_down']));assert len(coords)==dim and len(set(coords))==dim
    M=2*spec.get('Lx',cfg['Lx'])*spec.get('Ly',cfg['Ly'])
    assert all(u.bit_count()==spec['Nup'] and d.bit_count()==spec['Ndown'] and 0<=u<2**M and 0<=d<2**M for u,d in coords)
    order=np.array(sorted(range(dim),key=lambda i:coords[i]));V=np.array(raw['vectors'],dtype=float)[order,:]
    H=matrix(raw['H'])[np.ix_(order,order)];C=matrix(raw['C'])[np.ix_(order,order)];S=matrix(raw['S2'])[np.ix_(order,order)]
    E=np.array(raw['energies'],dtype=float);assert V.shape==H.shape==S.shape==C.shape==(dim,dim) and E.shape==(dim,)
    a.need(prefix+'/complete finite arrays',all(np.isfinite(x).all() for x in (V,H,C,S,E)))
    a.need(prefix+'/sorted complete energies',bool(np.all(np.diff(E)>=0)))
    a.add(prefix+'/Hermitian H',err(H-H.T),a.g['matrix_abs'])
    a.add(prefix+'/full eigenpair residual',err(H@V-V*E),a.g['eigen_residual_abs'])
    a.add(prefix+'/full eigenbasis orthogonality',err(V.T@V-np.eye(dim)),a.g['orthogonality_abs'])
    a.add(prefix+'/Hermitian S2',err(S-S.T),a.g['spin_hermitian_abs'])
    a.add(prefix+'/H S2 commutator',err(H@S-S@H),a.g['spin_commutator_abs'])
    a.add(prefix+'/scalar C S2 commutator',err(C@S-S@C),a.g['spin_commutator_abs'])
    a.add(prefix+'/directed operator is non-Hermitian',max(0.,a.g['directed_operator_min_asymmetry']-err(C-C.T)),0.)
    if backend=='target':a.add(prefix+'/actual native matrix-free action',raw['native_action_max_abs'],a.g['matrix_abs'])
    else:
        a.add(prefix+'/onsite ERI factor2 atomic guard',abs(raw['atomic_factor_guard']-2.),a.g['matrix_abs'])
        a.add(prefix+'/transRDM raising vs PySCF addons',raw['rdm_vs_addons_action_max_abs'],a.g['transition_rdm_action_abs'])
        a.add(prefix+'/transRDM lowering vs PySCF addons',raw['reverse_rdm_vs_addons_action_max_abs'],a.g['transition_rdm_action_abs'])
        expected_eri=[[p,p,p,p,spec['U']] for p in range(M)]
        a.need(prefix+'/only onsite chemist interaction entries',raw['eri_nonzero']==expected_eri)
    groups=clusters(E,a.g['cluster_diameter_max']);assert len(groups)>=cfg['low_energy_manifolds']
    for left,right in zip(groups,groups[1:]):
        a.add(prefix+'/complete spectral cluster separation '+str(right[0]),max(0.,a.g['cluster_separation_min']-(E[right[0]]-E[left[-1]])),0.)
    dg=len(groups[0]);assert raw['ground_dimension']==dg
    A=np.asarray(raw['transition_amplitudes']);Ar=np.asarray(raw['reverse_transition_amplitudes'])
    assert A.shape==Ar.shape==(dim,dg)
    a.add(prefix+'/saved raising amplitudes',err(A-V.T@C@V[:,:dg]),a.g['transition_rdm_action_abs'])
    a.add(prefix+'/saved lowering amplitudes',err(Ar-V.T@C.T@V[:,:dg]),a.g['transition_rdm_action_abs'])
    total=float(np.sum(np.abs(A)**2)/dg);reverse=float(np.sum(np.abs(Ar)**2)/dg)
    sumrule=float(np.sum(np.abs(C@V[:,:dg])**2)/dg)
    a.add(prefix+'/all-state raising sumrule',abs(total-sumrule),a.g['transition_sumrule_abs'])
    a.add(prefix+'/all-state lowering sumrule',abs(reverse-float(np.sum(np.abs(C.T@V[:,:dg])**2)/dg)),a.g['transition_sumrule_abs'])
    manifold=[]
    for ig,indices in enumerate(groups[:cfg['low_energy_manifolds']]):
        W=V[:,indices];P=W@W.T;spin=np.linalg.eigvalsh(W.T@S@W)
        allowed=np.array([s*(s+1) for s in range(N//2+1)])
        a.add(prefix+f'/group{ig} exact spin quantization',float(np.max(np.min(np.abs(spin[:,None]-allowed),axis=1))),a.g['spin_quantization_abs'])
        a.add(prefix+f'/group{ig} S2 subspace leakage',err(S@W-W@(W.T@S@W)),a.g['manifold_spin_leakage_abs'])
        manifold.append(dict(energy=float(np.mean(E[indices])),excitation=float(np.mean(E[indices])-E[0]),multiplicity=len(indices),spin=spin,projector=P,
          raising=float(np.sum(np.abs(A[indices,:])**2)/dg),lowering=float(np.sum(np.abs(Ar[indices,:])**2)/dg)))
    if spec['id']=='DIR_N2_U1':
        expected=(1-math.sqrt(50))/2
        a.need(prefix+'/unique direction witness',dg==1,'P24')
        a.add(prefix+'/direction witness analytic energy',abs(E[0]-expected),a.g['direction_witness_abs'],'P24')
        a.add(prefix+'/direction witness raising2',abs(total-2.),a.g['direction_witness_abs'],'P24')
        a.add(prefix+'/direction witness lowering0',abs(reverse),a.g['direction_witness_abs'],'P24')
        a.add(prefix+'/direction witness separation',max(0.,a.g['direction_witness_min_difference']-(total-reverse)),0.,'P24')
    return dict(H=H,C=C,S=S,E=E,h1=np.array(raw['h1']),groups=manifold,total=total,reverse=reverse)

def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,default=ROOT/'manifest.toml');p.add_argument('--target',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--mode',choices=['pilot','production'],required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    if args.output.exists():raise ValueError('Refuse overwrite')
    cfg=load(args.manifest);a=Audit(cfg['gates']);metrics=[];exception=None;warm_seconds=None
    try:
        target,reference=load(args.target),load(args.reference)
        pins={n:h for h,n in (line.split('  ',1) for line in (ROOT/'SHA256SUMS').read_text().splitlines())}
        assert all(sha(ROOT/n)==h for n,h in pins.items())
        expected_library=load(ROOT/'reference_library_pins.json')
        assert expected_library['schema']=='PYSCF_REFERENCE_LIBRARY_PINS_V1'
        assert reference['reference_library_sha256']==expected_library['files'] and reference['reference_library_pins_sha256']==sha(ROOT/'reference_library_pins.json')
        assert reference['python_version'].split()[0]==cfg['python_version'] and reference['h5py_version']==cfg['h5py_version']
        assert reference['installed_wheel_record_sha256']=={k:v for k,v in expected_library['files'].items() if k.endswith('/RECORD')}
        assert reference['library_sources_sha256']=={k.removeprefix('pyscf/'):v for k,v in expected_library['files'].items() if k in {'pyscf/fci/direct_spin1.py','pyscf/fci/spin_op.py','pyscf/fci/cistring.py','pyscf/fci/addons.py'}}
        selected=[s for s in cfg['cases'] if args.mode=='production' or s['id'] in cfg['pilot_case_ids']]
        for raw,backend,versions in [(target,'native_user_ed_new_observers',{'julia':cfg['julia_version']}),(reference,'independent_pyscf',{k:cfg[k+'_version'] for k in ('pyscf','numpy','scipy')})]:
            assert raw['schema']=='PYSCF_TWO_ORBITAL_RAW_V1' and raw['backend']==backend and raw['mode']==args.mode
            assert raw['versions']==versions and raw['threads']==1 and raw['source_sha256']==pins and raw['scientific_completions']==0 and raw['native_pair_or_transition_solver_claim'] is False
            assert [r['id'] for r in raw['cases']]==[s['id'] for s in selected]
        derived={}
        for spec,tc,rc in zip(selected,target['cases'],reference['cases']):
            t=one_backend(tc,spec,cfg,a,'target');r=one_backend(rc,spec,cfg,a,'reference');cid=spec['id'];derived[cid]=(t,r)
            for name,key,gate in [('nominal onebody','h1','matrix_abs'),('physical fullH','H','matrix_abs'),('complete eigenenergies','E','energy_abs'),('physical S2','S','spin_label_abs')]:
                a.add(cid+'/'+name,err(t[key]-r[key]),a.g[gate],'P23')
            a.add(cid+'/directed operator equality',err(t['C']-r['C']),a.g['matrix_abs'],'P24')
            for j,(tg,rg) in enumerate(zip(t['groups'],r['groups'])):
                label=cid+'/group'+str(j)
                a.need(label+'/complete multiplicity',tg['multiplicity']==rg['multiplicity'],'P23')
                a.add(label+'/excitation',abs(tg['excitation']-rg['excitation']),a.g['excitation_abs'],'P23')
                a.add(label+'/projector',err(tg['projector']-rg['projector']),a.g['projector_abs'],'P23')
                if tg['multiplicity']==rg['multiplicity']:a.add(label+'/spin labels',err(tg['spin']-rg['spin']),a.g['spin_label_abs'],'P23')
                for direction in ('raising','lowering'):a.add(label+'/'+direction+' strength',abs(tg[direction]-rg[direction]),a.g['transition_strength_abs'],'P24')
                metrics.append(dict(case_id=cid,manifold=j,energy=tg['energy'],excitation=tg['excitation'],dimension=tg['multiplicity'],spin_labels=tg['spin'].tolist(),raising=tg['raising'],lowering=tg['lowering']))
            a.add(cid+'/total raising match',abs(t['total']-r['total']),a.g['transition_strength_abs'],'P24')
        if args.mode=='pilot':
            assert len(target['resource_repeat_cases'])==len(reference['resource_repeat_cases'])==cfg['pilot_warm_repeat_count']==1
            spec=next(s for s in cfg['cases'] if s['id']==cfg['pilot_warm_repeat_case_id'])
            ts=time.perf_counter()
            for index,(raw,backend) in enumerate([(target['resource_repeat_cases'][0],'target'),(reference['resource_repeat_cases'][0],'reference')]):
                assert raw['id']==spec['id']
                warm=one_backend(raw,spec,cfg,a,backend,tag='_resource_repeat')
                cold=derived[spec['id']][index]
                for key in ('H','C','S','E'):a.add(backend+'/warmrepeat exact physical '+key,err(warm[key]-cold[key]),a.g['matrix_abs'])
                for j,(x,y) in enumerate(zip(warm['groups'],cold['groups'])):
                    a.add(backend+'/warmrepeat projector '+str(j),err(x['projector']-y['projector']),a.g['projector_abs'])
                    a.add(backend+'/warmrepeat raising '+str(j),abs(x['raising']-y['raising']),a.g['transition_strength_abs'])
            warm_seconds=time.perf_counter()-ts
        else:assert target['resource_repeat_cases']==reference['resource_repeat_cases']==[]
        if args.mode=='production':
            for backend in range(2):
                # Prevent a noninteracting-only path or silent C=0 substitute.
                for N in (2,4):
                    e0=derived[f'N{N}_U0'][backend]['E'][0];e2=derived[f'N{N}_U2'][backend]['E'][0]
                    a.add(f'backend{backend}/N{N} nonzeroU witness',max(0.,a.g['minimum_nonzero_U_energy_change']-abs(e2-e0)),0.,'P23')
                inelastic=sum(g['raising'] for cid,pair in derived.items() if cid.startswith('N') for g in pair[backend]['groups'][1:])
                a.add(f'backend{backend}/nonzero inelastic orbital transitions',max(0.,a.g['minimum_inelastic_strength']-inelastic),0.,'P24')
    except Exception as e:exception=type(e).__name__+': '+str(e);a.need('Complete finite supported raw/grid/provenance',False)
    eligible=all(c['passed'] for c in a.rows if c['phase']=='qualification') and exception is None
    decisions={}
    for key in ('P23','P24'):
        own=[c for c in a.rows if c['phase']==key]
        decisions[key]='UNRESOLVED' if not eligible or not own else 'PASS' if all(c['passed'] for c in own) else 'FAIL'
    if decisions['P23']!='PASS' and decisions['P24']=='PASS':decisions['P24']='UNRESOLVED'
    rows=[dict(id=k,status=('NOT_RUN' if args.mode=='pilot' else v),pilot_numerical_status=v) for k,v in decisions.items()]
    result=dict(schema='PYSCF_TWO_ORBITAL_COMPARISON_V1',mode=args.mode,catalogue_ids=['P23','P24'],rows=rows,
      completion_count=sum(r['status']=='PASS' for r in rows),pilot_excluded=args.mode=='pilot',numerically_eligible=eligible,
      checks=a.rows,manifold_receipts=metrics,exception=exception,
      resource_warm_postprocessing_seconds=warm_seconds,
      input_sha256={str(p):sha(p) for p in (args.manifest,args.target,args.reference) if p.is_file()})
    args.output.write_text(json.dumps(result,allow_nan=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('mode','rows','completion_count','numerically_eligible','exception')}))
    return 0 if eligible and all(v=='PASS' for v in decisions.values()) else 2 if not eligible else 1

if __name__=='__main__':sys.exit(main())
