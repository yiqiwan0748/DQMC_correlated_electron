#!/usr/bin/env python3
"""Independent PySCF integrals/FCI and directed transition-RDM reference.
Run only after frozen source review and explicit root execution admission.
"""
import argparse,hashlib,importlib.metadata,json,os,sys,time,tomllib
from pathlib import Path
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
import numpy as np
import scipy
import h5py
from scipy.linalg import eigh
import pyscf
from pyscf import lib
from pyscf.fci import direct_spin1,spin_op,cistring,addons
lib.num_threads(1)
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def source_map():
    sums=(ROOT/'SHA256SUMS').read_text().splitlines();out={}
    for line in sums:
        h,n=line.split('  ',1)
        if sha(ROOT/n)!=h:raise ValueError('Frozen source changed '+n)
        out[n]=h
    return out

def coo(a):
    i,j=np.nonzero(a)
    return dict(shape=list(a.shape),row=i.tolist(),col=j.tolist(),value=a[i,j].tolist())

def h1_independent(cfg,spec):
    # Tensor factors y,x,orbital. This is a geometric Kronecker construction,
    # independent of the native positive-displacement bond loop.
    A=np.array([[0.,1.],[1.,0.]]);J=np.array([[0.,1.],[-1.,0.]])
    nx,ny=spec.get('Lx',cfg['Lx']),spec.get('Ly',cfg['Ly'])
    assert nx==2 and ny in (1,2)
    Ay=A if ny==2 else np.zeros((1,1));Jy=J if ny==2 else np.zeros((1,1))
    I=np.eye(2);X=A
    return (-np.kron(np.kron(np.eye(ny),A),np.diag([cfg['t1'],cfg['t2']]))
            -np.kron(np.kron(Ay,I),np.diag([cfg['t2'],cfg['t1']]))
            -cfg['t3']*np.kron(np.kron(Ay,A),I)
            +cfg['t4']*np.kron(np.kron(Jy,J),X))

def fci_matrix(h1,U,nelec):
    n=len(h1);eri=np.zeros((n,n,n,n))
    for p in range(n):eri[p,p,p,p]=U
    h2=direct_spin1.absorb_h1e(h1,eri,n,nelec,.5)
    na=cistring.num_strings(n,nelec[0]);nb=cistring.num_strings(n,nelec[1]);dim=na*nb
    E=np.eye(dim)
    H=np.column_stack([direct_spin1.contract_2e(h2,E[:,j].reshape(na,nb),n,nelec).ravel() for j in range(dim)])
    return H,eri,(na,nb)

def directed_action(ci,nelec,n,reverse=False):
    out=np.zeros_like(ci)
    for a in range(0,n,2):
        b=a+1
        if reverse:a,b=b,a
        out+=addons.cre_a(addons.des_a(ci,n,nelec,b),n,(nelec[0]-1,nelec[1]),a)
        out+=addons.cre_b(addons.des_b(ci,n,nelec,b),n,(nelec[0],nelec[1]-1),a)
    return out

def one_case(spec,cfg):
    ts=[time.perf_counter()]
    h1=h1_independent(cfg,spec);n=len(h1);nelec=(spec['Nup'],spec['Ndown']);H,eri,shape=fci_matrix(h1,spec['U'],nelec)
    ts.append(time.perf_counter())
    dim=H.shape[0];basis=np.eye(dim)
    S2=np.column_stack([spin_op.contract_ss(basis[:,j].reshape(shape),n,nelec).ravel() for j in range(dim)])
    C=np.column_stack([directed_action(basis[:,j].reshape(shape),nelec,n).ravel() for j in range(dim)])
    ts.append(time.perf_counter())
    E,V=eigh(H,driver='evd',check_finite=True)
    ts.append(time.perf_counter())
    # Include the complete ground manifold, using the frozen global diameter.
    dg=1
    while dg<dim and E[dg]-E[0]<=cfg['gates']['cluster_diameter_max']:dg+=1
    amplitudes=np.empty((dim,dg));reverse_amplitudes=np.empty((dim,dg))
    for m in range(dim):
        for g in range(dg):
            dm=direct_spin1.trans_rdm1(V[:,m].reshape(shape),V[:,g].reshape(shape),n,nelec)
            # dm[p,q]=<bra|c_q^dagger c_p|ket>, spin summed.
            amplitudes[m,g]=sum(dm[a+1,a] for a in range(0,n,2))
            reverse_amplitudes[m,g]=sum(dm[a,a+1] for a in range(0,n,2))
    am_action=V.T@C@V[:,:dg]
    ts.append(time.perf_counter())
    strings_a=list(map(int,cistring.make_strings(range(n),nelec[0])))
    strings_b=list(map(int,cistring.make_strings(range(n),nelec[1])))
    return dict(id=spec['id'],Nup=nelec[0],Ndown=nelec[1],U=spec['U'],dimension=dim,
      basis_up=[a for a in strings_a for b in strings_b],basis_down=[b for a in strings_a for b in strings_b],
      h1=h1.tolist(),eri_nonzero=[[p,p,p,p,spec['U']] for p in range(n)],
      H=coo(H),S2=coo(S2),C=coo(C),energies=E.tolist(),vectors=V.tolist(),
      ground_dimension=dg,transition_amplitudes=amplitudes.tolist(),
      reverse_transition_amplitudes=reverse_amplitudes.tolist(),
      rdm_vs_addons_action_max_abs=float(np.max(np.abs(amplitudes-am_action))),
      reverse_rdm_vs_addons_action_max_abs=float(np.max(np.abs(reverse_amplitudes-V.T@C.T@V[:,:dg]))),
      timing_seconds={k:ts[i+1]-ts[i] for i,k in enumerate(['fci_matrix','spin_and_directed_operators','full_diagonalization','all_final_transition_rdms'])},
      atomic_factor_guard=float(fci_matrix(np.zeros((1,1)),2.,(1,1))[0][0,0]))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',type=Path,default=ROOT/'manifest.toml');ap.add_argument('--mode',choices=['pilot','production'],required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    if a.output.exists():raise ValueError('Refuse receipt overwrite')
    cfg=tomllib.loads(a.manifest.read_text());pins=source_map()
    assert (pyscf.__version__,np.__version__,scipy.__version__)==tuple(cfg[k+'_version'] for k in ('pyscf','numpy','scipy'))
    assert sys.version.split()[0]==cfg['python_version'] and h5py.__version__==cfg['h5py_version']
    library_pins=json.loads((ROOT/'reference_library_pins.json').read_text())
    assert library_pins['schema']=='PYSCF_REFERENCE_LIBRARY_PINS_V1' and library_pins['pyscf_version']==pyscf.__version__
    site_packages=Path(pyscf.__file__).resolve().parent.parent
    actual_library={}
    for name,expected in library_pins['files'].items():
        part=Path(name)
        assert not part.is_absolute() and '..' not in part.parts
        actual_library[name]=sha(site_packages/name)
        assert actual_library[name]==expected,'Installed reference changed '+name
    started=time.time();cases=[s for s in cfg['cases'] if a.mode=='production' or s['id'] in cfg['pilot_case_ids']]
    library_sources={str(Path(m.__file__).relative_to(Path(pyscf.__file__).parent)):sha(m.__file__) for m in (direct_spin1,spin_op,cistring,addons)}
    dist=importlib.metadata.distribution('pyscf');records=[p for p in dist.files if p.name=='RECORD']
    raw_cases=[one_case(s,cfg) for s in cases]
    repeat=[one_case(next(s for s in cfg['cases'] if s['id']==cfg['pilot_warm_repeat_case_id']),cfg)] if a.mode=='pilot' else []
    receipt=dict(schema='PYSCF_TWO_ORBITAL_RAW_V1',backend='independent_pyscf',mode=a.mode,source_sha256=pins,
      versions=dict(pyscf=pyscf.__version__,numpy=np.__version__,scipy=scipy.__version__),threads=1,
      python_version=sys.version,library_sources_sha256=library_sources,
      h5py_version=h5py.__version__,reference_library_sha256=actual_library,
      reference_library_pins_sha256=sha(ROOT/'reference_library_pins.json'),
      installed_wheel_record_sha256={str(p):sha(dist.locate_file(p)) for p in records},
      native_pair_or_transition_solver_claim=False,cases=raw_cases,resource_repeat_cases=repeat,
      started_unix=started,finished_unix=time.time(),scientific_completions=0)
    a.output.write_text(json.dumps(receipt,allow_nan=False,separators=(',',':'))+'\n')

if __name__=='__main__':main()
