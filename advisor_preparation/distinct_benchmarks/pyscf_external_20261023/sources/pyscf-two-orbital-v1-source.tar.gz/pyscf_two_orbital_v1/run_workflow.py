#!/usr/bin/env python3
"""Admission-gated future workflow. No execution is authorized by this file."""
import argparse,hashlib,json,os,signal,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('output',type=Path);a=p.parse_args()
    if os.environ.get('PYSCF_EXECUTION_ADMITTED')!=a.mode:raise RuntimeError('Separate root admission required')
    expected=os.environ['PYSCF_APPROVED_FREEZE_SHA256']
    if sha(ROOT/'source_freeze.json')!=expected:raise RuntimeError('Approved freeze does not match')
    freeze=json.loads((ROOT/'source_freeze.json').read_text())
    for n,h in freeze['files'].items():
        if sha(ROOT/n)!=h:raise RuntimeError('Changed source '+n)
    a.output.mkdir(exist_ok=False,parents=True)
    root=Path(os.environ['ISAAC_ROOT']);py=root/'pyscf-venv/bin/python'
    julia=Path(os.environ['JULIA_BIN'])
    if not py.is_file() or not julia.is_file():raise RuntimeError('Explicit verified runtime paths required')
    caps={'pilot':480,'production':2400};started=time.time();end=started+caps[a.mode]
    receipt={'schema':'PYSCF_TWO_ORBITAL_EXECUTION_V1','mode':a.mode,'source_freeze_sha256':expected,
      'started_unix':started,'deadline_unix':end,'cpu_limit':1,'memory_mb':3500,'scientific_completions':0,'processes':[]}
    env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','JULIA_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
    commands=[('target',[str(julia),'--startup-file=no',str(ROOT/'target.jl'),a.mode,str(a.output/'target.toml')]),
      ('reference',[str(py),'-B',str(ROOT/'oracle_pyscf.py'),'--mode',a.mode,'--output',str(a.output/'reference.json')]),
      ('comparator',[str(py),'-B',str(ROOT/'compare.py'),'--mode',a.mode,'--target',str(a.output/'target.toml'),'--reference',str(a.output/'reference.json'),'--output',str(a.output/'comparison.json')])]
    active=None
    def cleanup():
        if active is not None and active.poll() is None:
            try:os.killpg(active.pid,signal.SIGTERM)
            except ProcessLookupError:return
            try:active.wait(timeout=4)
            except subprocess.TimeoutExpired:
                os.killpg(active.pid,signal.SIGKILL);active.wait()
    def interrupted(sig,frame):
        cleanup();raise RuntimeError('Workflow interrupted signal '+str(sig))
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
    try:
        for name,cmd in commands:
            row={'name':name,'argv':cmd,'started_unix':time.time()}
            receipt['processes'].append(row)
            remaining=end-time.time()-6
            if remaining<=0:raise TimeoutError('Workflow budget exhausted')
            with (a.output/(name+'.stdout.txt')).open('w') as out,(a.output/(name+'.stderr.txt')).open('w') as err:
                active=subprocess.Popen(['/usr/bin/time','-v','-o',str(a.output/(name+'.resources.txt')),*cmd],stdout=out,stderr=err,env=env,start_new_session=True)
                row['process_group_id']=active.pid
                try:code=active.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    cleanup();row['timeout']=True;raise TimeoutError(name+' exceeded remaining workflow budget')
                finally:row.update(finished_unix=time.time(),exit_code=active.poll())
            if code:raise RuntimeError(name+' failed; no blind retry')
        receipt['status']='PROCESSES_COMPLETE'
    except Exception as e:
        cleanup();receipt['status']='UNRESOLVED';receipt['error']=type(e).__name__+': '+str(e)
    receipt['finished_unix']=time.time()
    receipt['outputs']={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in a.output.iterdir() if p.is_file()}
    (a.output/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if receipt['status']!='PROCESSES_COMPLETE':raise SystemExit(2)
if __name__=='__main__':main()
