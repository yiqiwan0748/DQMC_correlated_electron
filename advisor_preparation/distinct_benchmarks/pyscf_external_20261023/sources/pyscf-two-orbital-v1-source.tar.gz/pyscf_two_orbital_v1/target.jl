#!/usr/bin/env julia
# Actual user many-body Hamiltonian with explicitly new observer adapters.
using LinearAlgebra, TOML, SHA
BLAS.set_num_threads(1)
const ROOT=@__DIR__
const CFG=TOML.parsefile(joinpath(ROOT,"manifest.toml"))
VERSION==VersionNumber(CFG["julia_version"]) || error("Pinned Julia required")
function source_map()
    out=Dict{String,String}()
    for line in eachline(joinpath(ROOT,"SHA256SUMS"))
        h,n=split(line,"  ";limit=2)
        bytes2hex(sha256(read(joinpath(ROOT,n))))==h || error("Changed source: $n")
        out[n]=h
    end
    out
end
const PINS=source_map()
include(joinpath(ROOT,"source_snapshot","scripts","two_orbital_open_cluster_ed.jl"))
const ED=TwoOrbitalOpenClusterED
rows(A)=[collect(A[i,:]) for i in axes(A,1)]
function coo(A)
    ij=findall(!iszero,A)
    Dict("shape"=>collect(size(A)),"row"=>[i[1]-1 for i in ij],"col"=>[i[2]-1 for i in ij],"value"=>[A[i] for i in ij])
end
function labels(b)
    [(u,d) for u in b.up_states for d in b.down_states]
end
function directed(b)
    ls=labels(b);where=Dict(x=>i for (i,x) in enumerate(ls));C=zeros(length(b),length(b))
    for (j,(u,d)) in enumerate(ls),a in 1:2:b.nmodes,spin in 1:2
        z=ED._hop(spin==1 ? u : d,a,a+1)
        isnothing(z) && continue
        w,sign=z
        i=where[spin==1 ? (w,d) : (u,w)]
        C[i,j]+=sign
    end
    C
end
function spinsquared(b)
    # Sz=0: S²=S−S+; act on grouped2M-mode bits using actual native _hop.
    M=b.nmodes
    out=ED.sector_basis(M,b.Nup+1,b.Ndown-1)
    lookup=Dict(x=>i for (i,x) in enumerate(labels(out)))
    Splus=zeros(length(out),length(b));mask=(UInt64(1)<<M)-1
    for (j,(u,d)) in enumerate(labels(b)),p in 1:M
        z=ED._hop(u|(d<<M),p,p+M)
        isnothing(z) && continue
        w,sign=z;i=lookup[(w&mask,w>>M)];Splus[i,j]+=sign
    end
    transpose(Splus)*Splus
end
function one_case(spec)
    ts=[time_ns()/1e9]
    par=ED.ModelParameters(CFG["t1"],CFG["t2"],CFG["t3"],CFG["t4"])
    K=ED.open_cluster_kinetic_matrix(get(spec,"Lx",CFG["Lx"]),get(spec,"Ly",CFG["Ly"]),par)
    h=ED.sector_hamiltonian(K,spec["U"],spec["Nup"],spec["Ndown"];h=CFG["h"])
    H=ED.dense_sector_hamiltonian(h)
    N=spec["Nup"]+spec["Ndown"]
    M=size(K,1)
    H+=I*(spec["U"]*N/2-spec["U"]*M/4)
    # Record actual matrix-free action agreement; materializer is native too.
    e=zeros(size(H,1));work=similar(e);action_error=0.0
    for j in axes(H,2)
        fill!(e,0);e[j]=1;mul!(work,h,e)
        work[j]+=spec["U"]*N/2-spec["U"]*M/4
        action_error=max(action_error,maximum(abs.(work-H[:,j])))
    end
    push!(ts,time_ns()/1e9)
    decomp=eigen(Symmetric(H));E=decomp.values;V=decomp.vectors
    dg=1
    while dg<length(E) && E[dg+1]-E[1]<=CFG["gates"]["cluster_diameter_max"]
        dg+=1
    end
    push!(ts,time_ns()/1e9)
    C=directed(h.basis);S2=spinsquared(h.basis);ls=labels(h.basis)
    push!(ts,time_ns()/1e9)
    amp=transpose(V)*C*V[:,1:dg];ampr=transpose(V)*transpose(C)*V[:,1:dg]
    push!(ts,time_ns()/1e9)
    Dict("id"=>spec["id"],"Nup"=>spec["Nup"],"Ndown"=>spec["Ndown"],"U"=>spec["U"],"dimension"=>length(E),
      "basis_up"=>[Int(x[1]) for x in ls],"basis_down"=>[Int(x[2]) for x in ls],"h1"=>rows(K),
      "H"=>coo(H),"C"=>coo(C),"S2"=>coo(S2),"energies"=>collect(E),"vectors"=>rows(V),
      "ground_dimension"=>dg,"transition_amplitudes"=>rows(amp),
      "reverse_transition_amplitudes"=>rows(ampr),
      "timing_seconds"=>Dict(k=>ts[i+1]-ts[i] for (i,k) in enumerate(["native_matrix_and_full_action","full_diagonalization","spin_and_directed_operators","all_final_transition_action"])),
      "native_action_max_abs"=>action_error,"centered_to_physical_shift"=>spec["U"]*N/2-spec["U"]*M/4)
end
length(ARGS)==2 || error("Usage: target.jl pilot|production OUTPUT.toml")
mode,output=ARGS
mode in ("pilot","production") || error("Explicit mode required")
ispath(output) && error("Refuse output overwrite")
started=time()
specs=[s for s in CFG["cases"] if mode=="production" || s["id"] in CFG["pilot_case_ids"]]
raw_cases=[one_case(s) for s in specs]
repeat=mode=="pilot" ? [one_case(only(s for s in CFG["cases"] if s["id"]==CFG["pilot_warm_repeat_case_id"]))] : Dict[]
data=Dict("schema"=>"PYSCF_TWO_ORBITAL_RAW_V1","backend"=>"native_user_ed_new_observers","mode"=>mode,
  "source_sha256"=>PINS,"versions"=>Dict("julia"=>string(VERSION)),"threads"=>1,
  "native_pair_or_transition_solver_claim"=>false,"cases"=>raw_cases,"resource_repeat_cases"=>repeat,
  "started_unix"=>started,"finished_unix"=>time(),"scientific_completions"=>0)
open(output,"w") do io
    TOML.print(io,data)
end
