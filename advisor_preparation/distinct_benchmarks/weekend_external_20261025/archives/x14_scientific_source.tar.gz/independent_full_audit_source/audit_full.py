#!/usr/bin/env python3
"""Independent FULL saved-data X14 audit candidate; stdlib only, no candidate imports."""
import argparse,datetime,hashlib,json,math,os,platform,re,signal,struct,subprocess,sys,tarfile,time,tomllib
from pathlib import Path,PurePosixPath
QUAL='PADDED_BINARY64_OR_INDEPENDENT_EXACT_RATIONAL_POINT_SIGN_V2'
HERE=Path(__file__).resolve().parent
OLD_FREEZE='089328edf32570dda14273b77a74e05fcef0b0099bd9b6f0b391deff257c5196'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def read(p):return json.loads(Path(p).read_text())

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

class Audit:
 def __init__(self):self.checks=[];self.metrics={};self.inputs={}
 def need(self,n,v):
  self.checks.append(dict(name=n,passed=bool(v)))
  if not v:raise ValueError(n)
 def upper(self,n,v,b):
  self.need(n,math.isfinite(v) and 0<=v<=b);self.metrics[n]=dict(value=v,bound=b)
 def bind(self,p,base):self.inputs[str(Path(p).relative_to(base))]=sha(p);return sha(p)

def ratio_term(x,e,w,h):
 # Different exact construction: rational pairs and incremental LCM sum;
 # no Fraction module, producer terms, prefix/suffix verifier or candidate code.
 xn,xd=x.as_integer_ratio();en,ed=e.as_integer_ratio();wn,wd=w.as_integer_ratio();hn,hd=h.as_integer_ratio()
 tn=xn*ed-en*xd;td=xd*ed;g=math.gcd(tn,td);tn//=g;td//=g
 dn=tn*tn*hd*hd+hn*hn*td*td;dd=td*td*hd*hd;g=math.gcd(dn,dd);dn//=g;dd//=g
 if dn<=0 or wd<=0:raise ValueError('Nonpositive exact denominator')
 n=wn*tn*dd*dd;d=wd*td*dn*dn;g=math.gcd(n,d);return n//g,d//g

def exact_sum(x,e,w,h):
 n,d=0,1;maximum=0
 for p,q in zip(e,w):
  a,b=ratio_term(x,p,q,h);g=math.gcd(d,b);left,right=b//g,d//g
  # Guard known temporary sizes BEFORE products; independent analysis cap.
  predicted=max(max(1,n.bit_length())+left.bit_length(),max(1,a.bit_length())+right.bit_length())+1
  if max(predicted,d.bit_length()+left.bit_length())>65536:raise ValueError('Independent audit integer cap')
  n=n*left+a*right;d*=left;g=math.gcd(n,d);n//=g;d//=g;maximum=max(maximum,abs(n).bit_length(),d.bit_length())
 return (-1 if n>0 else 1 if n<0 else 0),n,d,maximum

def bounds(a,b,e,w,h,order,pad):
 lows=[];highs=[]
 for p,q in zip(e,w):
  left,right=a-p,b-p;critical=(-h/math.sqrt(3),h/math.sqrt(3)) if order==1 else (-h,0.,h)
  points=[left,right]+[z for z in critical if left<=z<=right]
  values=[-2*h*q*z/(math.pi*(z*z+h*h)**2) if order==1 else -2*h*q*(h*h-3*z*z)/(math.pi*(z*z+h*h)**3) for z in points]
  lows.append(min(values));highs.append(max(values))
 eps=pad*sum(w)/h**(order+1);return math.fsum(lows)-eps,math.fsum(highs)+eps

def value(x,e,w,h,order=0):
 if order==0:return math.fsum(q*h/(math.pi*((x-p)*(x-p)+h*h)) for p,q in zip(e,w))
 if order==1:return math.fsum(-2*h*q*(x-p)/(math.pi*((x-p)*(x-p)+h*h)**2) for p,q in zip(e,w))
 return math.fsum(-2*h*q*(h*h-3*(x-p)*(x-p))/(math.pi*((x-p)*(x-p)+h*h)**3) for p,q in zip(e,w))

class Stream:
 def __init__(self,path,a,c,freeze):
  self.a=a;self.c=c;self.events=[];self.index=0;self.signs=0;self.exact=0;self.fast=0;self.zeros=0;self.maxbits=0;self.cache={};self.fingerprints=[];self.active=None;previous='0'*64
  with path.open('rb') as f:
   for seq,line in enumerate(f):
    a.need('event byte cap '+str(seq),len(line)<=1048576 and line.endswith(b'\n'));v=json.loads(line);p=v['payload'];a.need('proof chain '+str(seq),p['sequence']==seq and p['previous_sha256']==previous and hashlib.sha256(canonical(p)).hexdigest()==v['sha256']);previous=v['sha256'];self.events.append(p['data'])
  self.header=self.take('HEADER');a.need('proof header',self.header['schema']=='X14_PADDED_OR_EXACT_POINT_SIGN_COMPLETE_STREAM_V2' and self.header['qualification']==QUAL and self.header['source_freeze_sha256']==freeze)
 def take(self,kind):
  if self.index>=len(self.events) or self.events[self.index]['kind']!=kind:raise ValueError('Complete census event order '+kind)
  d=self.events[self.index];self.index+=1;return d
 def sign(self,x,e,w,h):
  seq=self.index;d=self.take('SIGN');self.signs+=1;self.a.need('sign input identity '+str(seq),d['fingerprint']==self.active and d['x_hex']==x.hex())
  enclosure=bounds(x,x,e,w,h,1,self.c['numerics']['stationary_binary64_padding']);self.a.upper('independent point enclosure '+str(seq),max(abs(v-z) for v,z in zip(enclosure,d['enclosure'])),1e-12)
  key=(self.active,x.hex())
  if key not in self.cache:self.cache[key]=exact_sum(x,e,w,h)
  sign,n,den,bits=self.cache[key];self.maxbits=max(self.maxbits,bits);self.a.need('independent exact sign EVERY request '+str(seq),d['sign']==sign)
  fast=1 if enclosure[0]>0 else -1 if enclosure[1]<0 else 0
  if fast:self.fast+=1;self.a.need('definite fast path agrees with exact '+str(seq),d['method']=='PADDED_BINARY64' and fast==sign)
  else:
   self.exact+=1;self.zeros+=int(sign==0);self.a.need('exact fallback/zero classification '+str(seq),d['method']==('EXACT_ZERO' if sign==0 else 'EXACT_RATIONAL'))
   pn=int(d['rational_sum_numerator_hex'],16);pd=int(d['rational_sum_denominator_hex'],16);self.a.need('independent exact rational value '+str(seq),pd>0 and n*pd==pn*den)
  return sign,enclosure,seq
 def root(self,a,b,e,w,h):
  parent=[a,b];cl,ch=bounds(a,b,e,w,h,2,self.c['numerics']['stationary_binary64_padding']);self.a.need('independent strict monotone neighborhood',cl>0 or ch<0)
  sa,ea,_=self.sign(a,e,w,h);sb,eb,_=self.sign(b,e,w,h);self.a.need('independent opposite endpoint signs',sa!=0 and sb==-sa)
  for _ in range(180):
   if b-a<=self.c['numerics']['stationary_bracket_width_max']:break
   old=(a,b);left=[a];right=[b]
   for fraction in (.25,.5,.75):
    x=old[0]+fraction*(old[1]-old[0]);self.a.need('distinct progress probe',old[0]<x<old[1]);s,_,_=self.sign(x,e,w,h)
    if s==sa:left.append(x)
    elif s==sb:right.append(x)
   a,b=max(left),min(right);self.a.need('bracket contracts without fabrication',(a,b)!=old and a<b);sl,_,_=self.sign(a,e,w,h);sr,_,_=self.sign(b,e,w,h);self.a.need('endpoint signs retained',(sl,sr)==(sa,sb))
  self.a.need('original physical width',0<b-a<=self.c['numerics']['stationary_bracket_width_max']);sa,ea,li=self.sign(a,e,w,h);sb,eb,ri=self.sign(b,e,w,h);d=self.take('ROOT_POINT');x=float.fromhex(d['root_hex']);self.a.need('retained Brent bracket event',d['fingerprint']==self.active and d['a_hex']==a.hex() and d['b_hex']==b.hex() and math.isfinite(x) and a<=x<=b and x.hex()==d['root_hex'])
  return dict(location=x,bracket=[a,b],endpoint_signs=[sa,sb],endpoint_sign_event_indices=[li,ri],monotone_parent=parent,type='maximum' if ch<0 else 'minimum')
 def census(self,row):
  h=row['eta'];e=row['poles'];w=row['weights'];begin=self.take('CURVE_BEGIN');self.active=begin['fingerprint'];self.fingerprints.append(self.active);self.a.need('row complete source fingerprint',self.active==row['proof_curve_fingerprint'])
  c=self.c;n=c['numerics'];stack=[(c['frequency_min'],c['frequency_max'],0)];roots=[];candidates=[];visited=excluded=0
  while stack:
   a,b,depth=stack.pop();visited+=1;self.a.need('census interval cap',visited<=n['stationary_max_intervals']);lo,hi=bounds(a,b,e,w,h,1,n['stationary_binary64_padding'])
   if lo>0 or hi<0:excluded+=1;continue
   cl,ch=bounds(a,b,e,w,h,2,n['stationary_binary64_padding']);sa,_,_=self.sign(a,e,w,h);sb,_,_=self.sign(b,e,w,h)
   if cl>0 or ch<0:
    if sa and sb and sa==sb:excluded+=1;continue
    if sa and sb==-sa:roots.append(self.root(a,b,e,w,h));continue
   if b-a<=n['stationary_bracket_width_max']:candidates.append([a,b]);continue
   self.a.need('census depth cap',depth<n['stationary_max_depth']);mid=(a+b)/2;self.a.need('census subdivision progress',a<mid<b);stack.extend([(a,mid,depth+1),(mid,b,depth+1)])
  candidates.sort();unions=[]
  for a,b in candidates:
   if unions and a<=unions[-1][1]:unions[-1][1]=max(b,unions[-1][1])
   else:unions.append([a,b])
  roots.extend(self.root(a,b,e,w,h) for a,b in unions);roots.sort(key=lambda v:v['bracket'][0]);dedup=[]
  for r in roots:
   if dedup and r['bracket'][0]<=dedup[-1]['bracket'][1]:
    old=dedup.pop();self.a.need('dedup type agreement',old['type']==r['type']);merged=self.root(min(old['bracket'][0],r['bracket'][0]),max(old['bracket'][1],r['bracket'][1]),e,w,h);self.a.need('qualified union type',merged['type']==r['type']);dedup.append(merged)
   else:dedup.append(r)
  self.a.need('complete independent stationary grid',len(dedup)==len(row['all_stationary_points']) and visited==row['root_census_intervals'] and excluded==row['root_excluded_intervals'])
  for own,saved in zip(dedup,row['all_stationary_points']):
   self.a.need('independent stationary metadata',all(own[k]==saved[k] for k in own))
   for field,order in [('height',0),('derivative_abs',1),('curvature',2)]:
    expected=abs(value(own['location'],e,w,h,1)) if order==1 else value(own['location'],e,w,h,order);self.a.upper('independent stationary '+field,abs(saved[field]-expected),1e-12)
  end=self.take('CURVE_END');self.a.need('complete original curve result digest',end['fingerprint']==self.active and end['result_sha256']==hashlib.sha256(canonical([row['all_stationary_points'],visited,excluded])).hexdigest());self.active=None
 def finish(self,summary):
  d=self.take('FOOTER');self.a.need('entire proof consumed',self.index==len(self.events));self.a.need('complete footer grid/counts',d['complete'] is True and d['curves']==self.fingerprints==self.header['expected_curves'] and d['sign_calls']==self.signs and d['exact_calls']==self.exact and len(self.fingerprints)==140);self.a.need('reported cap proof',self.signs<=200000 and self.exact<=200000 and d['maximum_reserved_integer_workspace_bits']<=65536 and self.maxbits<=65536);self.a.need('raw proof count agrees',summary['sign_calls']==self.signs and summary['exact_calls']==self.exact and summary['curves']==140)
  return dict(sign_requests=self.signs,fast_signs_independently_exact=self.fast,fallback_signs=self.exact,exact_zeros=self.zeros,unique_exact_points=len(self.cache),independent_max_integer_bits=self.maxbits,all_events_consumed=True)

def expected_spectra(source,backend,c):
 p=source/'prior'/('target.toml' if backend=='native' else 'oracle.json');data=tomllib.loads(p.read_text()) if p.suffix=='.toml' else read(p);rows=data['P09']['rows'];out=[]
 for row in rows:
  for branch in c['branches']:out.append(dict(id=f"{row['spin']}_k{row['momentum_index']}_{branch}",role='physical',spin=row['spin'],momentum=row['momentum_index'],branch=branch,groups=row['addition']+row['removal'] if branch=='combined' else row[branch],expected_total_weight=1. if branch=='combined' else row['addition_norm' if branch=='addition' else 'occupation']))
 for name in ['single','equal','unequal','rescaled']:
  poles=c['controls'][name+'_pole' if name=='single' else name+'_poles'];weights=c['controls'][name+'_weight' if name=='single' else name+'_weights'];out.append(dict(id='control_'+name,role='control',branch='control',groups=[dict(omega=p,weight=w,multiplicity=1,span=0.) for p,w in zip(poles,weights)]))
 return out

def physical(rows,refs,c,a):
 g=c['gates'];dx=(c['frequency_max']-c['frequency_min'])/(c['mesh_points']-1);largest_curve=0.;summaries=[]
 for n,r in zip(rows,refs):
  e,w,h=n['poles'],n['weights'],n['eta'];er,wr=r['poles'],r['weights'];tag=n['id']+'/'+str(h);a.need(tag+'/same row',n['id']==r['id'] and h==r['eta']);a.upper(tag+'/prior poles',max(abs(x-y) for x,y in zip(e,er)),g['prior_pole_abs']);a.upper(tag+'/prior weights',max(abs(x-y) for x,y in zip(w,wr)),g['prior_weight_abs'])
  native_values=[];reference_values=[]
  for i in range(c['mesh_points']):
   x=c['frequency_min']+i*dx;native_values.append(value(x,e,w,h));reference_values.append(value(x,er,wr,h))
  diff=max(abs(x-y) for x,y in zip(native_values,reference_values));largest_curve=max(largest_curve,diff);a.upper(tag+'/independent full65537point curve',diff,g['full_curve_abs'])
  for label,row,ee,ww,vals in [('native',n,e,w,native_values),('reference',r,er,wr,reference_values)]:
   a.need(tag+'/'+label+'/complete positive measure',all(math.isfinite(x) and x>=0 for x in ww) and all(c['frequency_min']<p<c['frequency_max'] for p in ee));a.upper(tag+'/'+label+'/independent weight',abs(math.fsum(ww)-row['expected_total_weight']),g['prior_sumrule_abs']);a.upper(tag+'/'+label+'/stored probe recomputation',max(abs(vals[i]-z) for i,z in zip(row['probe_indices'],row['probe_values'])),g['pointwise_binary64_abs']);mass=math.fsum(q*(math.atan((c['frequency_max']-p)/h)-math.atan((c['frequency_min']-p)/h))/math.pi for p,q in zip(ee,ww));a.upper(tag+'/'+label+'/independent analytic mass',abs(mass-row['finite_window_analytic_mass' if label=='native' else 'finite_window_library_cdf_mass']),g['pointwise_binary64_abs']);a.upper(tag+'/'+label+'/mass+tails',abs(mass+row['outside_window_mass']-math.fsum(ww)),g['prior_sumrule_abs'])
  simpson=dx/3*(native_values[0]+native_values[-1]+4*math.fsum(native_values[1:-1:2])+2*math.fsum(native_values[2:-1:2]));a.upper(tag+'/independent Simpson stored',abs(simpson-n['finite_window_simpson_mass']),g['pointwise_binary64_abs']);a.upper(tag+'/Simpson actual error',abs(simpson-n['finite_window_analytic_mass']),n['simpson_error_bound']+g['pointwise_binary64_abs']);a.need(tag+'/same complete maximum count',len(n['peaks'])==len(r['peaks']))
  loc_error=max(max(min(abs(x['location']-y['location']) for y in r['peaks']) for x in n['peaks']),max(min(abs(x['location']-y['location']) for y in n['peaks']) for x in r['peaks']));a.upper(tag+'/all maximum locations',loc_error,g['peak_location_abs'])
  for p in r['peaks']:
   a.need(tag+'/reference maximum sign/qualification',p['endpoint_signs']==[1,-1] and p['endpoint_qualification']==QUAL);a.upper(tag+'/reference root width',p['bracket'][1]-p['bracket'][0],c['numerics']['stationary_bracket_width_max']);a.upper(tag+'/reference root derivative',abs(value(p['location'],er,wr,h,1)),g['stationary_derivative_abs']);a.need(tag+'/reference strict max curvature',value(p['location'],er,wr,h,2)<-g['minimum_peak_curvature'])
  if n['id']=='control_single':a.upper(tag+'/analytic single pole',max(abs(p['location']-1.25) for p in r['peaks']),g['control_location_abs'])
  if n['id']=='control_equal':
   z=2*math.sqrt(1+h*h)-(1+h*h);expected=[0.] if z<=0 else [-math.sqrt(z),math.sqrt(z)];a.need(tag+'/equalpair count',len(expected)==len(r['peaks']));a.upper(tag+'/analytic equalpair locations',max(abs(x-p['location']) for x,p in zip(expected,r['peaks'])),g['control_location_abs'])
  summaries.append(dict(id=n['id'],eta=h,maximum_count=len(r['peaks']),independent_full_curve_abs=diff,all_maximum_location_abs=loc_error))
 return summaries,largest_curve


def metadata(config,a,base):
 source=Path(config['original_source']);raw=Path(config['cancelled_results']);recovery=Path(config['recovery_results']);newsource=Path(config['recovery_source'])
 for path in (source,raw,recovery,newsource):a.need('input root contained '+str(path),path.is_dir() and not path.is_symlink() and path.resolve().is_relative_to(base.resolve()))
 fr=read(source/'source_freeze.json');a.need('original full65 freeze',a.bind(source/'source_freeze.json',base)==OLD_FREEZE and len(fr['files'])==65 and fr['mode']=='FULL_ONLY')
 for name,digest in fr['files'].items():
  rel=PurePosixPath(name);a.need('safe original source '+name,not rel.is_absolute() and '..' not in rel.parts and not (source/name).is_symlink() and (source/name).resolve().is_relative_to(source.resolve()));a.need('unchanged original source '+name,a.bind(source/name,base)==digest)
 a.need('original physical manifest exact',sha(source/'manifest.toml')=='953b483b8550012fc81d1db8b843ec8d867c0a615d0ffa8503add927d93ae1fc')
 a.need('original65 source archive',a.bind(Path(config['original_source_archive']),base)=='2356088ee82831fe747202837176fc3969f8e6c344651cde8fb837509ad52d42')
 newfreeze=read(newsource/'source_freeze.json');a.need('new recovery freeze distinct authority',a.bind(newsource/'source_freeze.json',base)==config['recovery_source_freeze_sha256'] and newfreeze['schema']=='X14_SAVED_COMPARE_RECOVERY_SOURCE_FREEZE_V1')
 for name,digest in newfreeze['files'].items():
  rel=PurePosixPath(name);a.need('safe recovery source '+name,not rel.is_absolute() and '..' not in rel.parts and not (newsource/name).is_symlink() and (newsource/name).resolve().is_relative_to(newsource.resolve()));a.need('unchanged recovery source '+name,a.bind(newsource/name,base)==digest)
 a.need('new input manifest pinned',a.bind(newsource/'inputs_manifest.json',base)==config['inputs_manifest_sha256']);m=read(newsource/'inputs_manifest.json')
 a.need('original13 cancelled input census',m['cancelled_job_id']=='6467601' and len(m['results'])==13 and not (raw/'comparison.json').exists() and {p.name for p in raw.iterdir()}==set(m['results']))
 for name,spec in m['results'].items():a.need('cancelled raw exact '+name,not (raw/name).is_symlink() and a.bind(raw/name,base)==spec['sha256'] and (raw/name).stat().st_size==spec['bytes'])
 stop=newsource/'original_context/stop_receipt.json';a.need('cancelled stop provenance',a.bind(stop,base)==m['stop_receipt_sha256']);stopped=read(stop);a.need('old stop not relabelled success',stopped['cancelled_only_job']=='6467601' and stopped['scientific_completions']==0 and stopped['full_admission_historical_not_permission_to_resume'])
 account=newsource/'original_context/cancelled_accounting.txt';a.need('cancelled69seconds parent retained',a.bind(account,base)==m['cancelled_accounting_sha256'] and '6467601|X14_exact_full_v3|CANCELLED by 12640|0:0|1|3500M|' in account.read_text())
 e=read(raw/'execution.json');a.need('cancelled producer execution is still unresolved',e['job_id']=='6467601' and e['status']=='UNRESOLVED' and e['mode']=='production' and e['source_freeze_sha256']==OLD_FREEZE and e['scientific_completions']==0 and e['error']=='TimeoutError: Whole allocation guard signal 15');a.need('only original two producers complete',[p['name'] for p in e['processes']]==['native','reference'] and all(p['exit_code']==0 and not p['timed_out'] for p in e['processes']))
 for name in ('native.json','reference.json','reference_sign_proof.jsonl'):a.need('original producer file declaration '+name,sha(raw/name)==e['outputs'][name]['sha256'] and (raw/name).stat().st_size==e['outputs'][name]['bytes'])
 resources={}
 for p in e['processes']:
  text=(raw/(p['name']+'.resources.txt')).read_text();rss=int(re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text)[1]);a.need('original role resource '+p['name'],'Exit status: 0' in text and 0<rss<=3500*1024);resources[p['name']]=dict(wall_seconds=p['elapsed_seconds'],peak_RSS_KiB=rss)
 approval=Path(config['recovery_admission']);a.need('new recovery admission exact',a.bind(approval,base)==config['recovery_admission_sha256']);ad=read(approval);a.need('new recovery permission separate from old',ad['schema']=='ROOT_X14_SAVED_COMPARE_RECOVERY_ADMISSION_V1' and ad['status']=='ADMITTED_FOR_ONE_COMPARATOR_ONLY_RECOVERY' and ad['source_freeze_sha256']==config['recovery_source_freeze_sha256'] and ad['inputs_manifest_sha256']==config['inputs_manifest_sha256'] and ad['cancelled_job_id']=='6467601' and ad['recovery_output']==str(recovery) and ad['original_full_admission_is_historical_provenance_only'] and ad['renderers_prohibited'] and not ad['automatic_retry'])
 rec=read(recovery/'execution.json');a.need('new comparator execution exact',a.bind(recovery/'execution.json',base)==config['recovery_execution_sha256']);a.need('new comparator completed not old allocation',rec['status']=='COMPARATOR_TERMINAL' and rec['error'] is None and rec['job_id']==config['recovery_job_id'] and rec['job_id']!='6467601' and rec['comparator_exit_code']==0 and rec['new_root_admission_sha256']==config['recovery_admission_sha256'] and rec['recovery_source_freeze_sha256']==config['recovery_source_freeze_sha256'] and not rec['historical_full_admission_is_permission'] and rec['cancelled_original_status']=='CANCELLED_ZERO_CREDIT' and rec['scientific_completions']==0 and rec['independent_full_audit_required'] and not rec['renderers_executed'] and not rec['eigensolver_or_sampler_executed'] and not rec['automatic_retry'])
 a.need('new recovery fixed resource budget',rec['cpus']==1 and rec['memory_MB']==3500 and rec['allocation_seconds']==600 and rec['whole_timeout_seconds']==540 and 0<rec['elapsed_seconds_including_preflight']<=550)
 a.need('original source/input/runtime/historicalcontext stable after recovery',rec['after']==dict(sources=rec['source_before'],inputs=rec['inputs_before'],runtime=rec['runtime_before'],historical_context=rec['historical_context_before']))
 a.need('recorded complete recovery source census',set(rec['source_before'])==set(newfreeze['files']))
 for name,digest in newfreeze['files'].items():a.need('recorded source independently rebound '+name,rec['source_before'][name]['sha256']==digest and rec['source_before'][name]['bytes']==(newsource/name).stat().st_size)
 a.need('recorded original raw complete census',set(rec['inputs_before'])==set(m['results'])|{'outer_log'})
 for name,spec in m['results'].items():a.need('recorded original raw independently rebound '+name,rec['inputs_before'][name]['sha256']==spec['sha256'] and rec['inputs_before'][name]['bytes']==spec['bytes'])
 a.need('recorded original outerlog independently rebound',rec['inputs_before']['outer_log']['sha256']==m['outer_log']['sha256'] and rec['inputs_before']['outer_log']['bytes']==m['outer_log']['bytes']);a.need('actual original outerlog immutable',a.bind(Path(m['outer_log']['path']),base)==m['outer_log']['sha256'] and Path(m['outer_log']['path']).stat().st_size==m['outer_log']['bytes'])
 exact=read(source/'exact_runtime_pins.json');numerical=read(source/'reference_library_pins.json');wanted_runtime={role:(exact['files'][role],exact['bytes'][role],str(Path(path).resolve())) for role,path in exact['paths'].items()}
 for package,spec in numerical['distributions'].items():
  for name in spec['files']:wanted_runtime[package+'/'+name]=(numerical['files'][name],numerical['bytes'][name],None)
 a.need('recorded original13plus30 runtime census independently rebound',len(wanted_runtime)==43 and set(rec['runtime_before'])==set(wanted_runtime))
 for role,(digest,size,path) in wanted_runtime.items():
  v=rec['runtime_before'][role];p=Path(v['path']);a.need('recorded qualified runtime independently rebound '+role,v['sha256']==digest and v['bytes']==size and (path is None or str(p.resolve())==path) and p.is_file() and sha(p)==digest and p.stat().st_size==size)
 for role,key in [('full_admission','historical_full_admission_sha256'),('resource_assessment','historical_resource_assessment_sha256')]:a.need('recorded historical provenance independently rebound '+role,rec['historical_context_before'][role]['sha256']==m[key])
 a.need('original compare unchanged',rec['original_compare_sha256']==sha(source/'compare.py')=='17414d3fbe389cb4f1989dda4995a4d0f7f945cdda27b46b8318f6e55d30fe5c')
 for name,spec in rec['outputs'].items():a.need('new recovery output binding '+name,not (recovery/name).is_symlink() and a.bind(recovery/name,base)==spec['sha256'] and (recovery/name).stat().st_size==spec['bytes'])
 a.need('new comparison exact',a.bind(recovery/'comparison.json',base)==config['comparison_sha256']);comparison=read(recovery/'comparison.json')
 a.need('complete original140 comparison',comparison['status']=='PASS' and comparison['catalogue_status']=='PASS' and comparison['scientific_completions']==1 and comparison['mode']=='production' and not comparison['pilot_excluded'] and len(comparison['details'])==140 and all(v['passed'] for v in comparison['checks']))
 a.need('comparison bound original inputs',comparison['target_sha256']==sha(raw/'native.json') and comparison['reference_sha256']==sha(raw/'reference.json') and comparison['proof_sha256']==sha(raw/'reference_sign_proof.jsonl') and comparison['complete_sign_proof_verification']['status']=='PASS' and comparison['complete_sign_proof_verification']['curves']==140)
 text=(recovery/'comparator.resources.txt').read_text();rss=int(re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text)[1]);a.need('new comparator bounded RSS/exit','Exit status: 0' in text and 0<rss<=3500*1024);resources['new_comparator']=dict(peak_RSS_KiB=rss)
 terminal=Path(config['recovery_terminal_receipt']);a.need('saved terminal accounting receipt exact',a.bind(terminal,base)==config['recovery_terminal_receipt_sha256']);tr=read(terminal);a.need('saved terminal accounting schema',tr['schema']=='ISAAC_X14_SAVED_COMPARE_TERMINAL_RECEIPT_V1' and tr['job_id']==config['recovery_job_id'] and tr['columns']==['JobIDRaw','User','JobName','State','ExitCode','AllocCPUS','ReqMem','ElapsedRaw','Timelimit']);rows=[line.rstrip('|').split('|') for line in tr['sacct_raw'].splitlines() if line.strip()];owned=[r for r in rows if r[0]==config['recovery_job_id']];a.need('actual owned comparator terminal0:0 allocation',len(owned)==1 and len(owned[0])==9 and owned[0][1:7]==['ywang287','X14_saved_compare_v1','COMPLETED','0:0','1','3500M'] and 0<int(owned[0][7])<=600 and owned[0][8]=='00:10:00')
 closure=Path(config['recovery_transfer_closure']);a.need('saved terminal transfer closure exact',a.bind(closure,base)==config['recovery_transfer_closure_sha256']);tc=read(closure);a.need('saved terminal transfer closure identity',tc['schema']=='ISAAC_X14_RECOVERY_TERMINAL_TRANSFER_CLOSURE_V1' and tc['status']=='PASS' and tc['job_id']==config['recovery_job_id'] and tc['source_freeze_sha256']==config['recovery_source_freeze_sha256'] and tc['before']==tc['after']);wanted_files={p.name for p in recovery.iterdir() if p.is_file()};a.need('entire terminal recovery transfer retained',set(tc['before'])==wanted_files and 'execution.json' in wanted_files and 'comparison.json' in wanted_files)
 for name,spec in tc['before'].items():a.need('terminal transferred file exact '+name,sha(recovery/name)==spec['sha256'] and (recovery/name).stat().st_size==spec['bytes'])
 return source,raw,recovery,e,rec,resources,comparison


def full_additional_gates(native,reference,c,a):
 """Full-only witness and independent checks additional to unchanged pilot math."""
 g=c['gates'];witnesses=[];by_native={(r['id'],r['eta']):r for r in native}
 for n,r in zip(native,reference):
  tag=n['id']+'/'+str(n['eta']);h=n['eta'];w=n['weights'];wr=r['weights'];er=r['poles']
  a.need(tag+'/complete pole and weight lengths',len(n['poles'])==len(w)==len(er)==len(wr)>0)
  for label,row in [('native',n),('reference',r)]:
   a.need(tag+'/'+label+'/all cluster spans and multiplicities',all(v['span']<=g['cluster_span_max'] and v['multiplicity']>=1 for v in row['groups']));a.upper(tag+'/'+label+'/cluster rendering certificate',row['cluster_render_error_bound'],g['cluster_render_bound_max']);a.upper(tag+'/'+label+'/stored full weight',abs(row['full_weight']-row['expected_total_weight']),g['prior_sumrule_abs'])
   independent_cluster=math.fsum(v['weight']*v['span'] for v in row['groups'])/(math.pi*h*h);a.upper(tag+'/'+label+'/independent cluster certificate',abs(independent_cluster-row['cluster_render_error_bound']),g['pointwise_binary64_abs']);a.need(tag+'/'+label+'/positive full branch',math.fsum(row['weights'])>g['minimum_total_branch_weight'])
  a.upper(tag+'/independent finite window cross mass',abs(n['finite_window_analytic_mass']-r['finite_window_library_cdf_mass']),g['finite_mass_abs']);a.upper(tag+'/reference quadrature value error',abs(r['finite_window_quadrature_mass']-r['finite_window_library_cdf_mass']),g['finite_mass_abs']);a.upper(tag+'/reference quadrature reported uncertainty',r['quadrature_error_estimate'],g['quadrature_error_max']);a.upper(tag+'/native Simpson certificate ceiling',n['simpson_error_bound'],g['simpson_absolute_max']);a.need(tag+'/tail certificate nonnegative',0<=n['outside_window_mass']<=n['outside_window_upper_bound']+g['pointwise_binary64_abs']);a.upper(tag+'/tail cross check',abs(n['outside_window_mass']-r['outside_window_mass']),g['finite_mass_abs'])
  for p in n['peaks']:
   lo,hi=p['bracket'];left,right=p['initial_mesh_bracket'];a.need(tag+'/native stays in fixed initial mesh neighborhood',left<=lo<=hi<=right);a.upper(tag+'/native final golden bracket',hi-lo,c['numerics']['golden_bracket_width_max']);cl,ch=bounds(left,right,n['poles'],w,h,2,c['numerics']['stationary_binary64_padding']);a.need(tag+'/native entire mesh neighborhood strictly concave',ch < -g['minimum_peak_curvature'])
   a.upper(tag+'/independent native peak height',abs(value(p['location'],n['poles'],w,h)-p['height']),g['pointwise_binary64_abs']);limit=g['stationary_derivative_abs']+16*sum(w)*math.sqrt(2.220446049250313e-16)/(math.pi*h*h)+2*sum(w)*c['numerics']['golden_bracket_width_max']/(math.pi*h*h*h);a.upper(tag+'/native stationary derivative',abs(value(p['location'],n['poles'],w,h,1)),limit)
  dx=(c['frequency_max']-c['frequency_min'])/(c['mesh_points']-1);values=[value(c['frequency_min']+i*dx,n['poles'],w,h) for i in range(c['mesh_points'])];a.upper(tag+'/independent fine mesh maximum height',abs(max(values)-n['mesh_maximum_height']),g['pointwise_binary64_abs']);a.upper(tag+'/independent coarse mesh maximum height',abs(max(values[::c['coarse_mesh_stride']])-n['coarse_mesh_maximum_height']),g['pointwise_binary64_abs']);fine=math.fsum(w)*dx*dx/(4*math.pi*h*h*h);a.upper(tag+'/fine mesh peak-height error bound',abs(max(p['height'] for p in n['peaks'])-n['mesh_maximum_height']),fine+g['pointwise_binary64_abs']);a.upper(tag+'/coarse mesh peak-height error bound',abs(max(p['height'] for p in n['peaks'])-n['coarse_mesh_maximum_height']),fine*c['coarse_mesh_stride']**2+g['pointwise_binary64_abs']);certificate=(c['frequency_max']-c['frequency_min'])*dx**4/180*24*math.fsum(w)/(math.pi*h**5);a.upper(tag+'/independent Simpson certificate',abs(certificate-n['simpson_error_bound']),g['pointwise_binary64_abs']);tail=math.fsum(v*h/math.pi*(1/(c['frequency_max']-p)+1/(p-c['frequency_min'])) for p,v in zip(n['poles'],w));a.upper(tag+'/independent outside-window upper bound',abs(tail-n['outside_window_upper_bound']),g['pointwise_binary64_abs'])
  for p in r['peaks']:
   nearest=min(abs(c['frequency_min']+i*dx-p['location']) for i in (max(0,min(c['mesh_points']-1,int((p['location']-c['frequency_min'])/dx))),max(0,min(c['mesh_points']-1,int((p['location']-c['frequency_min'])/dx)+1))));a.upper(tag+'/independent root to mesh proximity',nearest,min(g['root_to_mesh_max'],dx/2+c['numerics']['stationary_bracket_width_max']))
  maxn=max(p['height'] for p in n['peaks']);maxr=max(p['height'] for p in r['peaks']);ntie=[p['location'] for p in n['peaks'] if p['height']>=maxn-c['numerics']['global_peak_height_tie_abs']];rtie=[p['location'] for p in r['peaks'] if p['height']>=maxr-c['numerics']['global_peak_height_tie_abs']]
  err=max(max(min(abs(x-y) for y in rtie) for x in ntie),max(min(abs(x-y) for y in ntie) for x in rtie));a.upper(tag+'/all tied global maximum locations',err,g['peak_location_abs'])
  if n['id']=='control_rescaled':
   u=by_native[('control_unequal',h)];loc=[p['location'] for p in n['peaks']];other=[p['location'] for p in u['peaks']];a.need(tag+'/rescaling maximum count',len(loc)==len(other));a.upper(tag+'/rescaling maxima fixed',max(max(min(abs(x-y) for y in other) for x in loc),max(min(abs(x-y) for y in loc) for x in other)),g['control_location_abs']);a.upper(tag+'/rescaling mass',abs(n['full_weight']-c['controls']['rescaling_factor']*u['full_weight']),g['control_rescaling_abs'])
  if n['role']=='physical':
   a.need(tag+'/visibility threshold clearance',all(abs(v-c['visible_pole_weight_min'])>=c['visible_threshold_clearance'] for v in wr))
   if n['branch']=='combined' and h==c['witness_eta']:
    visible=[p for p,v in zip(er,wr) if v>=c['visible_pole_weight_min']];a.need(tag+'/nonempty visible poles',bool(visible));shift=min(min(abs(p-v) for v in visible) for p in rtie);overlap=any(c['minimum_distinct_pole_separation']<=abs(er[i]-er[j])<=2*h and wr[i]>=c['minimum_overlapping_pole_weight'] and wr[j]>=c['minimum_overlapping_pole_weight'] for i in range(len(er)) for j in range(i));witnesses.append(dict(id=n['id'],eta=h,minimum_distance_to_visible_exact_pole=shift,overlapping_poles=overlap,eligible=shift>=c['minimum_physical_peak_to_visible_pole_distance'] and overlap))
 a.need('all eight physical full-grid eta16 witness candidates retained',len(witnesses)==8);a.need('mandatory physical complete-grid broadening shift and overlap witness',any(w['eligible'] for w in witnesses));return witnesses


def compute_guard(config_path,admission_path,admission_sha,output,a):
 a.need('NEW independent-audit admission exact',sha(admission_path)==admission_sha);ad=read(admission_path)
 a.need('NEW independent-audit admission permission',ad['schema']=='ROOT_X14_FULL_INDEPENDENT_SAVED_AUDIT_ADMISSION_V1' and ad['status']=='ADMITTED_FOR_ONE_FULL_INDEPENDENT_SAVED_AUDIT' and ad['source_freeze_sha256']==sha(HERE/'source_freeze.json') and ad['config_sha256']==sha(config_path) and ad['output']==str(output) and ad['cpus']==1 and ad['memory_MB']==3500 and ad['allocation_seconds']==1200 and ad['whole_timeout_seconds']==1140 and ad['scientific_completions']==0)
 a.need('dedicated fresh compute allocation',os.getenv('SLURM_JOB_ID','').isdigit() and os.getenv('SLURM_CPUS_PER_TASK')=='1' and os.getenv('SLURM_MEM_PER_NODE')=='3500' and os.getenv('SLURM_RESTART_COUNT','0')=='0' and all(os.getenv(k)=='1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']))
 f=read(HERE/'source_freeze.json');a.need('new reviewed full audit freeze',f['schema']=='X14_FULL_INDEPENDENT_SAVED_AUDIT_SOURCE_FREEZE_V1')
 for name,digest in f['files'].items():
  rel=PurePosixPath(name);a.need('safe auditor source '+name,not rel.is_absolute() and '..' not in rel.parts and not (HERE/name).is_symlink() and (HERE/name).resolve().is_relative_to(HERE));a.need('auditor source unchanged '+name,sha(HERE/name)==digest)
 config=read(config_path);a.need('fixed reviewed config complete',config['schema']=='X14_FULL_INDEPENDENT_SAVED_AUDIT_CONFIG_V1' and config['status']=='ROOT_PINNED_COMPLETE' and all(isinstance(config[k],str) and len(config[k])==64 for k in ['recovery_source_freeze_sha256','inputs_manifest_sha256','recovery_admission_sha256','recovery_execution_sha256','comparison_sha256','recovery_terminal_receipt_sha256','recovery_transfer_closure_sha256']))
 a.need('preserved original pilot auditor source',sha(HERE/'provenance/original_pilot_auditor.py')=='58ee14fabcd07ac45591b8baa5723166362c167bf08e50a76ffcfe2a75802f61')
 queue=subprocess.check_output(['squeue','-u','ywang287','-h','-o','%i|%u|%j|%T|%C|%m'],text=True,timeout=20);rows=[r.split('|') for r in queue.splitlines() if r];a.need('whole-user queue parse',all(len(r)==6 and r[1]=='ywang287' for r in rows));live=[r for r in rows if r[3] in ['RUNNING','COMPLETING','CONFIGURING']];a.need('whole-user maximum2oneCPU3500 jobs',len(live)<=2 and all(r[4:6]==['1','3500M'] for r in live));own=[r for r in live if r[0]==os.environ['SLURM_JOB_ID']];a.need('actual owned independent-audit job',len(own)==1 and own[0][2]=='X14_full_independent_v1');a.need('one campaign science lane',not any(r[0]!=os.environ['SLURM_JOB_ID'] and r[2].startswith(('X14_','X19_','P17_','A25_','J23_','X17_')) for r in live));ad=dict(ad,whole_user_queue_before_PRIVATE=queue)
 return config,ad


def stdlib_runtime(source,a):
 p=read(source/'exact_runtime_pins.json');a.need('unchanged original exact13 runtime map',sha(source/'exact_runtime_pins.json')=='2613c2fd9386856f26ce38abdb496dda5af744dc45a03e564d283d7813e52a82');a.need('actual independent binary64 interpreter',platform.python_version()==p['python_version'] and platform.python_implementation()==p['implementation'] and sys.version==p['version_text'] and Path(sys.executable).resolve()==Path(p['paths']['Python_executable']).resolve());a.need('actual pinned math gcd/provider',Path(math.__file__).resolve()==Path(p['paths']['module/math']).resolve() and math.gcd.__module__=='math' and sys.int_info.bits_per_digit==30 and sys.int_info.sizeof_digit==4)
 observed={}
 for role,path in p['paths'].items():
  f=Path(path).resolve();a.need('original exact runtime unchanged '+role,f.is_file() and f.stat().st_size==p['bytes'][role] and sha(f)==p['files'][role]);observed[role]=dict(path=str(f),sha256=sha(f),bytes=f.stat().st_size)
 for role,oldtext in p['ldd_metadata'].items():
  text=subprocess.check_output(['ldd',p['paths'][role]],text=True,timeout=20)
  def providers(t):
   result={}
   for line in t.splitlines():
    a.need('no missing loader provider','not found' not in line);m=re.search(r'^\s*(\S+)\s+=>\s+(/\S+)',line)
    if m:result['provider/'+m[1]]=str(Path(m[2]).resolve())
    else:
     m=re.search(r'^\s*(/\S+)\s+\(',line)
     if m:result['provider/'+Path(m[1]).name]=str(Path(m[1]).resolve())
   return result
  current=providers(text);a.need('actual pinned CPython/math/decimal loader '+role,current==providers(oldtext) and all(k in p['paths'] and str(Path(p['paths'][k]).resolve())==v for k,v in current.items()))
 return observed


def interrupted(signum,frame):raise TimeoutError('Full independent audit fixed whole-process guard '+str(signum))


def main():
 p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);p.add_argument('--admission',type=Path,required=True);p.add_argument('--admission-sha256',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args();a=Audit();start=time.monotonic();report={};error=None
 signal.signal(signal.SIGALRM,interrupted);signal.signal(signal.SIGTERM,interrupted);signal.alarm(1140)
 config,ad=compute_guard(args.config,args.admission,args.admission_sha256,args.output,a);base=Path(config['root']);a.need('fresh contained audit output',args.output.parent.resolve()==(base/'results').resolve() and args.output.name.startswith('x14_full_independent_saved_audit_v1_') and not args.output.exists());args.output.mkdir(exist_ok=False)
 try:
  source,raw,recovery,e,rec,resources,old=metadata(config,a,base);runtime_before=stdlib_runtime(source,a);c=tomllib.loads((source/'manifest.toml').read_text());n=read(raw/'native.json');r=read(raw/'reference.json');a.need('complete full140 saved rows',len(n['rows'])==len(r['rows'])==len(old['details'])==140)
  for i,v in enumerate(old['checks']):
   if 'value' in v:a.upper('every retained unchanged comparator bound '+str(i),v['value'],v['bound'])
  for backend,doc in [('native',n),('quspin',r)]:
   specs=expected_spectra(source,backend,c);wanted=[(s,h) for s in specs for h in c['etas']];a.need(backend+'/original full140 grid',len(wanted)==len(doc['rows'])==140)
   for row_index,((s,h),row) in enumerate(zip(wanted,doc['rows'])):
    a.need(backend+'/original complete groups '+row['id']+str(h),(row['id'],row['role'],row['branch'],row['groups'],row['eta'])==(s['id'],s['role'],s['branch'],s['groups'],h));a.need(backend+'/original full poles weights '+row['id']+str(h),row['poles']==[v['omega'] for v in s['groups']] and row['weights']==[v['weight'] for v in s['groups']] and row['expected_total_weight']==s.get('expected_total_weight',.37 if s['id']=='control_rescaled' else 1.))
    fp=hashlib.sha256(canonical(dict(backend='retained_QuSpin_Lehmann' if backend=='quspin' else 'actual_native_prior_ED',spectrum=s,eta_hex=float(h).hex(),poles_hex=[float(v['omega']).hex() for v in s['groups']],weights_hex=[float(v['weight']).hex() for v in s['groups']]))).hexdigest();a.need(backend+'/exact source fingerprint '+row['id']+str(h),fp==(row['proof_curve_fingerprint'] if backend=='quspin' else doc['input_fingerprints'][row_index]))
  a.need('full proof byte cap and original complete summary',(raw/'reference_sign_proof.jsonl').stat().st_size<=268435456 and r['complete_sign_proof']['sha256']==sha(raw/'reference_sign_proof.jsonl') and r['complete_sign_proof']['bytes']==(raw/'reference_sign_proof.jsonl').stat().st_size and r['complete_sign_proof']['complete'] and r['complete_sign_proof']['curves']==140);a.need('all full fingerprints unique',len(set(n['input_fingerprints']))==140 and len({row['proof_curve_fingerprint'] for row in r['rows']})==140)
  proof=Stream(raw/'reference_sign_proof.jsonl',a,c,OLD_FREEZE)
  for row in r['rows']:proof.census(row)
  stats=proof.finish(r['complete_sign_proof']);a.need('all actual full sign requests and fallback requests',stats['sign_requests']==33769 and stats['fallback_signs']==1226);rows,maxcurve=physical(n['rows'],r['rows'],c,a);witnesses=full_additional_gates(n['rows'],r['rows'],c,a)
  a.need('original failed attempts retained',read(source/'implementation_manifest.json')['old_failure_jobs']==['6466312','6466728']);a.need('unchanged literal physical manifest',sha(source/'manifest.toml')==sha(source/'original_v1/manifest.toml'))
  for rel,digest in list(a.inputs.items()):a.need('input unchanged after independent audit '+rel,sha(base/rel)==digest)
  runtime_after=stdlib_runtime(source,a);a.need('independent exact13 runtime unchanged before after',runtime_before==runtime_after)
  report.update(status='PASS',integrity_status='PASS',scientific_status='PASS',independent_mathematics='PASS',grid_rows=140,full_census_replayed=True,every_point_sign_independently_exact=True,proof_statistics=stats,row_metrics=rows,max_independent_full_curve_abs=maxcurve,mandatory_full_witnesses=witnesses,original_cancelled_execution_preserved=True,original_resources=resources,original_cancelled_job='6467601',new_recovery_job=config['recovery_job_id'],comparison_sha256=sha(recovery/'comparison.json'),proof_sha256=sha(raw/'reference_sign_proof.jsonl'),original_execution_sha256=sha(raw/'execution.json'),recovery_execution_sha256=sha(recovery/'execution.json'),original_source_freeze_sha256=OLD_FREEZE,runtime_before=runtime_before,runtime_after=runtime_after)
 except Exception as ex:error=type(ex).__name__+': '+str(ex);report.update(status='UNRESOLVED',integrity_status='UNRESOLVED',scientific_status='UNRESOLVED',error=error)
 signal.alarm(0)
 report.update(schema='X14_FULL_INDEPENDENT_SAVED_AUDIT_V1',auditor_sha256=sha(__file__),source_freeze_sha256=sha(HERE/'source_freeze.json'),new_root_admission_sha256=args.admission_sha256,config_sha256=sha(args.config),job_id=os.getenv('SLURM_JOB_ID'),whole_user_queue_before_PRIVATE=ad['whole_user_queue_before_PRIVATE'],scientific_completions=0,catalogue_update_performed=False,pilot_excluded_from_full=True,checks=a.checks,check_count=len(a.checks),metric_specific_errors=a.metrics,input_sha256=a.inputs,analysis_runtime=dict(python=platform.python_version(),implementation=platform.python_implementation(),stdlib_only=True,candidate_modules_imported=False,original_pinned_runtime_replay=False),scope='Complete140row saved-data independent exact point signs/conditional binary64 census/full65537point curves and fixed production gates. Original6467601 remains CANCELLED/zero credit; no producer, eigenstate solver, sampler or new fixture. No automatic ledger update.',elapsed_seconds=time.monotonic()-start,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 with (args.output/'audit.json').open('x') as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
 print(json.dumps({k:v for k,v in report.items() if k in ['status','error','check_count','elapsed_seconds']},indent=2));return 0 if error is None else 2


if __name__=='__main__':raise SystemExit(main())
