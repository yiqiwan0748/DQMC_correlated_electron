#!/usr/bin/env python3
"""Independent stdlib saved-data audit. No original module imports or producer calls."""
import argparse,datetime,hashlib,json,math,platform,re,struct,sys,tarfile,time,tomllib
from pathlib import Path,PurePosixPath
QUAL='PADDED_BINARY64_OR_INDEPENDENT_EXACT_RATIONAL_POINT_SIGN_V2'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
class Audit:
 def __init__(self):self.checks=[];self.metrics={};self.inputs={}
 def need(self,n,v):
  self.checks.append(dict(name=n,passed=bool(v)))
  if not v:raise ValueError(n)
 def upper(self,n,v,b):
  self.need(n,math.isfinite(v) and 0<=v<=b);self.metrics[n]=dict(value=v,bound=b)
 def bind(self,p,base):self.inputs[str(Path(p).relative_to(base))]=sha(p);return sha(p)

def ratio_term(x,e,w,h):
 # Different exact construction: rational pairs and incremental LCM sum;
 # no Fraction module, producer terms, prefix/suffix verifier or candidate code.
 xn,xd=x.as_integer_ratio();en,ed=e.as_integer_ratio();wn,wd=w.as_integer_ratio();hn,hd=h.as_integer_ratio()
 tn=xn*ed-en*xd;td=xd*ed;g=math.gcd(tn,td);tn//=g;td//=g
 dn=tn*tn*hd*hd+hn*hn*td*td;dd=td*td*hd*hd;g=math.gcd(dn,dd);dn//=g;dd//=g
 if dn<=0 or wd<=0:raise ValueError('Nonpositive exact denominator')
 n=wn*tn*dd*dd;d=wd*td*dn*dn;g=math.gcd(n,d);return n//g,d//g

def exact_sum(x,e,w,h):
 n,d=0,1;maximum=0
 for p,q in zip(e,w):
  a,b=ratio_term(x,p,q,h);g=math.gcd(d,b);left,right=b//g,d//g
  # Guard known temporary sizes BEFORE products; independent analysis cap.
  predicted=max(max(1,n.bit_length())+left.bit_length(),max(1,a.bit_length())+right.bit_length())+1
  if max(predicted,d.bit_length()+left.bit_length())>65536:raise ValueError('Independent audit integer cap')
  n=n*left+a*right;d*=left;g=math.gcd(n,d);n//=g;d//=g;maximum=max(maximum,abs(n).bit_length(),d.bit_length())
 return (-1 if n>0 else 1 if n<0 else 0),n,d,maximum

def bounds(a,b,e,w,h,order,pad):
 lows=[];highs=[]
 for p,q in zip(e,w):
  left,right=a-p,b-p;critical=(-h/math.sqrt(3),h/math.sqrt(3)) if order==1 else (-h,0.,h)
  points=[left,right]+[z for z in critical if left<=z<=right]
  values=[-2*h*q*z/(math.pi*(z*z+h*h)**2) if order==1 else -2*h*q*(h*h-3*z*z)/(math.pi*(z*z+h*h)**3) for z in points]
  lows.append(min(values));highs.append(max(values))
 eps=pad*sum(w)/h**(order+1);return math.fsum(lows)-eps,math.fsum(highs)+eps

def value(x,e,w,h,order=0):
 if order==0:return math.fsum(q*h/(math.pi*((x-p)*(x-p)+h*h)) for p,q in zip(e,w))
 if order==1:return math.fsum(-2*h*q*(x-p)/(math.pi*((x-p)*(x-p)+h*h)**2) for p,q in zip(e,w))
 return math.fsum(-2*h*q*(h*h-3*(x-p)*(x-p))/(math.pi*((x-p)*(x-p)+h*h)**3) for p,q in zip(e,w))
class Stream:
 def __init__(self,path,a,c,freeze):
  self.a=a;self.c=c;self.events=[];self.index=0;self.signs=0;self.exact=0;self.fast=0;self.zeros=0;self.maxbits=0;self.cache={};self.fingerprints=[];self.active=None;previous='0'*64
  with path.open('rb') as f:
   for seq,line in enumerate(f):
    a.need('event byte cap '+str(seq),len(line)<=1048576 and line.endswith(b'\n'));v=json.loads(line);p=v['payload'];a.need('proof chain '+str(seq),p['sequence']==seq and p['previous_sha256']==previous and hashlib.sha256(canonical(p)).hexdigest()==v['sha256']);previous=v['sha256'];self.events.append(p['data'])
  self.header=self.take('HEADER');a.need('proof header',self.header['schema']=='X14_PADDED_OR_EXACT_POINT_SIGN_COMPLETE_STREAM_V2' and self.header['qualification']==QUAL and self.header['source_freeze_sha256']==freeze)
 def take(self,kind):
  if self.index>=len(self.events) or self.events[self.index]['kind']!=kind:raise ValueError('Complete census event order '+kind)
  d=self.events[self.index];self.index+=1;return d
 def sign(self,x,e,w,h):
  seq=self.index;d=self.take('SIGN');self.signs+=1;self.a.need('sign input identity '+str(seq),d['fingerprint']==self.active and d['x_hex']==x.hex())
  enclosure=bounds(x,x,e,w,h,1,self.c['numerics']['stationary_binary64_padding']);self.a.upper('independent point enclosure '+str(seq),max(abs(v-z) for v,z in zip(enclosure,d['enclosure'])),1e-12)
  key=(self.active,x.hex())
  if key not in self.cache:self.cache[key]=exact_sum(x,e,w,h)
  sign,n,den,bits=self.cache[key];self.maxbits=max(self.maxbits,bits);self.a.need('independent exact sign EVERY request '+str(seq),d['sign']==sign)
  fast=1 if enclosure[0]>0 else -1 if enclosure[1]<0 else 0
  if fast:self.fast+=1;self.a.need('definite fast path agrees with exact '+str(seq),d['method']=='PADDED_BINARY64' and fast==sign)
  else:
   self.exact+=1;self.zeros+=int(sign==0);self.a.need('exact fallback/zero classification '+str(seq),d['method']==('EXACT_ZERO' if sign==0 else 'EXACT_RATIONAL'))
   pn=int(d['rational_sum_numerator_hex'],16);pd=int(d['rational_sum_denominator_hex'],16);self.a.need('independent exact rational value '+str(seq),pd>0 and n*pd==pn*den)
  return sign,enclosure,seq
 def root(self,a,b,e,w,h):
  parent=[a,b];cl,ch=bounds(a,b,e,w,h,2,self.c['numerics']['stationary_binary64_padding']);self.a.need('independent strict monotone neighborhood',cl>0 or ch<0)
  sa,ea,_=self.sign(a,e,w,h);sb,eb,_=self.sign(b,e,w,h);self.a.need('independent opposite endpoint signs',sa!=0 and sb==-sa)
  for _ in range(180):
   if b-a<=self.c['numerics']['stationary_bracket_width_max']:break
   old=(a,b);left=[a];right=[b]
   for fraction in (.25,.5,.75):
    x=old[0]+fraction*(old[1]-old[0]);self.a.need('distinct progress probe',old[0]<x<old[1]);s,_,_=self.sign(x,e,w,h)
    if s==sa:left.append(x)
    elif s==sb:right.append(x)
   a,b=max(left),min(right);self.a.need('bracket contracts without fabrication',(a,b)!=old and a<b);sl,_,_=self.sign(a,e,w,h);sr,_,_=self.sign(b,e,w,h);self.a.need('endpoint signs retained',(sl,sr)==(sa,sb))
  self.a.need('original physical width',0<b-a<=self.c['numerics']['stationary_bracket_width_max']);sa,ea,li=self.sign(a,e,w,h);sb,eb,ri=self.sign(b,e,w,h);d=self.take('ROOT_POINT');x=float.fromhex(d['root_hex']);self.a.need('retained Brent bracket event',d['fingerprint']==self.active and d['a_hex']==a.hex() and d['b_hex']==b.hex() and math.isfinite(x) and a<=x<=b and x.hex()==d['root_hex'])
  return dict(location=x,bracket=[a,b],endpoint_signs=[sa,sb],endpoint_sign_event_indices=[li,ri],monotone_parent=parent,type='maximum' if ch<0 else 'minimum')
 def census(self,row):
  h=row['eta'];e=row['poles'];w=row['weights'];begin=self.take('CURVE_BEGIN');self.active=begin['fingerprint'];self.fingerprints.append(self.active);self.a.need('row complete source fingerprint',self.active==row['proof_curve_fingerprint'])
  c=self.c;n=c['numerics'];stack=[(c['frequency_min'],c['frequency_max'],0)];roots=[];candidates=[];visited=excluded=0
  while stack:
   a,b,depth=stack.pop();visited+=1;self.a.need('census interval cap',visited<=n['stationary_max_intervals']);lo,hi=bounds(a,b,e,w,h,1,n['stationary_binary64_padding'])
   if lo>0 or hi<0:excluded+=1;continue
   cl,ch=bounds(a,b,e,w,h,2,n['stationary_binary64_padding']);sa,_,_=self.sign(a,e,w,h);sb,_,_=self.sign(b,e,w,h)
   if cl>0 or ch<0:
    if sa and sb and sa==sb:excluded+=1;continue
    if sa and sb==-sa:roots.append(self.root(a,b,e,w,h));continue
   if b-a<=n['stationary_bracket_width_max']:candidates.append([a,b]);continue
   self.a.need('census depth cap',depth<n['stationary_max_depth']);mid=(a+b)/2;self.a.need('census subdivision progress',a<mid<b);stack.extend([(a,mid,depth+1),(mid,b,depth+1)])
  candidates.sort();unions=[]
  for a,b in candidates:
   if unions and a<=unions[-1][1]:unions[-1][1]=max(b,unions[-1][1])
   else:unions.append([a,b])
  roots.extend(self.root(a,b,e,w,h) for a,b in unions);roots.sort(key=lambda v:v['bracket'][0]);dedup=[]
  for r in roots:
   if dedup and r['bracket'][0]<=dedup[-1]['bracket'][1]:
    old=dedup.pop();self.a.need('dedup type agreement',old['type']==r['type']);merged=self.root(min(old['bracket'][0],r['bracket'][0]),max(old['bracket'][1],r['bracket'][1]),e,w,h);self.a.need('qualified union type',merged['type']==r['type']);dedup.append(merged)
   else:dedup.append(r)
  self.a.need('complete independent stationary grid',len(dedup)==len(row['all_stationary_points']) and visited==row['root_census_intervals'] and excluded==row['root_excluded_intervals'])
  for own,saved in zip(dedup,row['all_stationary_points']):
   self.a.need('independent stationary metadata',all(own[k]==saved[k] for k in own))
   for field,order in [('height',0),('derivative_abs',1),('curvature',2)]:
    expected=abs(value(own['location'],e,w,h,1)) if order==1 else value(own['location'],e,w,h,order);self.a.upper('independent stationary '+field,abs(saved[field]-expected),1e-12)
  end=self.take('CURVE_END');self.a.need('complete original curve result digest',end['fingerprint']==self.active and end['result_sha256']==hashlib.sha256(canonical([row['all_stationary_points'],visited,excluded])).hexdigest());self.active=None
 def finish(self,summary):
  d=self.take('FOOTER');self.a.need('entire proof consumed',self.index==len(self.events));self.a.need('complete footer grid/counts',d['complete'] is True and d['curves']==self.fingerprints==self.header['expected_curves'] and d['sign_calls']==self.signs and d['exact_calls']==self.exact and len(self.fingerprints)==35);self.a.need('reported cap proof',self.signs<=200000 and self.exact<=200000 and d['maximum_reserved_integer_workspace_bits']<=65536 and self.maxbits<=65536);self.a.need('raw proof count agrees',summary['sign_calls']==self.signs and summary['exact_calls']==self.exact and summary['curves']==35)
  return dict(sign_requests=self.signs,fast_signs_independently_exact=self.fast,fallback_signs=self.exact,exact_zeros=self.zeros,unique_exact_points=len(self.cache),independent_max_integer_bits=self.maxbits,all_events_consumed=True)

def metadata(packet,a,base):
 source=packet/'source';raw=packet/'results';bf=read(packet/'transfer_before.json');af=read(packet/'transfer_after.json');bm={v['local']:v for v in bf['files']};am={v['local']:v for v in af['files']};a.need('stable complete transfer membership',len(bm)==len(bf['files'])==len(am)==len(af['files']) and set(bm)==set(am) and af['status']=='PASS')
 for name,row in bm.items():
  p=packet/name;s=row.get('after_read',row.get('before',{}));a.need('local/remote original SHA bytes '+name,p.is_file() and not p.is_symlink() and a.bind(p,base)==row['sha256']==am[name]['sha256'] and p.stat().st_size==row['bytes']==am[name]['bytes'] and all(s[k]==am[name][k] for k in ['inode','mtime_ns']))
 a.need('original30/exact13 runtime stable',bf['runtime_files']==af['runtime_files'] and bf['runtime_critical_file_sha256']==af['runtime_critical_file_sha256'] and len(bf['runtime_files'])==43)
 fr=read(packet/'release_freeze.json');a.need('exact frozen source archive',sha(packet/'source_archive.tar.gz')==fr['archive_sha256']=='3bfa6d393bb59c6eb1c5f14b9d1bad5dfde0bb4e6b309bafff06a4052f3a5f5b' and sha(source/'source_freeze.json')==sha(packet/'release_freeze.json')=='97c262f5bf2cdc5e047e02c82c3602a6e97b4d91237b5d0b73dba24bcd994fb6');seen=set();prefix=fr['prefix']
 with tarfile.open(packet/'source_archive.tar.gz','r:gz') as t:
  for m in t:
   a.need('safe source member '+m.name,m.isfile() and m.name.startswith(prefix) and '..' not in PurePosixPath(m.name).parts);name=m.name[len(prefix):];a.need('exact source member '+name,name not in seen and hashlib.sha256(t.extractfile(m).read()).hexdigest()==fr['files'][name]==sha(source/name));seen.add(name)
 a.need('full54 frozen source roles',len(seen)==54 and seen==set(fr['files']));e=read(raw/'execution.json');a.need('excluded completed allocation',e['status']=='PROCESSES_COMPLETE' and e['mode']=='pilot' and e['job_id']=='6467268' and e['cpus']==1 and e['memory_mb']==3500 and e['combined_cap_seconds']==540 and e['pilot_excluded'] and e['scientific_completions']==0 and e['catalogue_status']=='NOT_RUN' and not e['full_admitted'] and not e['new_eigensolver_or_sampler_executed']);a.need('all3actual roles completed',[v['name'] for v in e['processes']]==['native','reference','comparator'] and all(v['exit_code']==0 for v in e['processes']))
 for n,spec in e['outputs'].items():a.need('execution bound output '+n,sha(raw/n)==spec['sha256'] and (raw/n).stat().st_size==spec['bytes'])
 resources={}
 for v in e['processes']:
  text=(raw/(v['name']+'.resources.txt')).read_text();rss=int(re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text)[1]);a.need('bounded original role '+v['name'],'Exit status: 0' in text and rss<=3500*1024 and 0<v['elapsed_seconds']<=540);resources[v['name']]=dict(wall_seconds=v['elapsed_seconds'],peak_RSS_KiB=rss)
 return source,raw,e,resources

def expected_spectra(source,backend,c):
 p=source/'prior'/('target.toml' if backend=='native' else 'oracle.json');data=tomllib.loads(p.read_text()) if p.suffix=='.toml' else read(p);rows=data['P09']['rows'];out=[]
 for row in rows:
  if (row['spin'],row['momentum_index'])!=(c['pilot_spin'],c['pilot_momentum']):continue
  for branch in c['branches']:out.append(dict(id=f"{row['spin']}_k{row['momentum_index']}_{branch}",role='physical',spin=row['spin'],momentum=row['momentum_index'],branch=branch,groups=row['addition']+row['removal'] if branch=='combined' else row[branch],expected_total_weight=1. if branch=='combined' else row['addition_norm' if branch=='addition' else 'occupation']))
 for name in ['single','equal','unequal','rescaled']:
  poles=c['controls'][name+'_pole' if name=='single' else name+'_poles'];weights=c['controls'][name+'_weight' if name=='single' else name+'_weights'];out.append(dict(id='control_'+name,role='control',branch='control',groups=[dict(omega=p,weight=w,multiplicity=1,span=0.) for p,w in zip(poles,weights)]))
 return out

def physical(rows,refs,c,a):
 g=c['gates'];dx=(c['frequency_max']-c['frequency_min'])/(c['mesh_points']-1);largest_curve=0.;summaries=[]
 for n,r in zip(rows,refs):
  e,w,h=n['poles'],n['weights'],n['eta'];er,wr=r['poles'],r['weights'];tag=n['id']+'/'+str(h);a.need(tag+'/same row',n['id']==r['id'] and h==r['eta']);a.upper(tag+'/prior poles',max(abs(x-y) for x,y in zip(e,er)),g['prior_pole_abs']);a.upper(tag+'/prior weights',max(abs(x-y) for x,y in zip(w,wr)),g['prior_weight_abs'])
  native_values=[];reference_values=[]
  for i in range(c['mesh_points']):
   x=c['frequency_min']+i*dx;native_values.append(value(x,e,w,h));reference_values.append(value(x,er,wr,h))
  diff=max(abs(x-y) for x,y in zip(native_values,reference_values));largest_curve=max(largest_curve,diff);a.upper(tag+'/independent full65537point curve',diff,g['full_curve_abs'])
  for label,row,ee,ww,vals in [('native',n,e,w,native_values),('reference',r,er,wr,reference_values)]:
   a.need(tag+'/'+label+'/complete positive measure',all(math.isfinite(x) and x>=0 for x in ww) and all(c['frequency_min']<p<c['frequency_max'] for p in ee));a.upper(tag+'/'+label+'/independent weight',abs(math.fsum(ww)-row['expected_total_weight']),g['prior_sumrule_abs']);a.upper(tag+'/'+label+'/stored probe recomputation',max(abs(vals[i]-z) for i,z in zip(row['probe_indices'],row['probe_values'])),g['pointwise_binary64_abs']);mass=math.fsum(q*(math.atan((c['frequency_max']-p)/h)-math.atan((c['frequency_min']-p)/h))/math.pi for p,q in zip(ee,ww));a.upper(tag+'/'+label+'/independent analytic mass',abs(mass-row['finite_window_analytic_mass' if label=='native' else 'finite_window_library_cdf_mass']),g['pointwise_binary64_abs']);a.upper(tag+'/'+label+'/mass+tails',abs(mass+row['outside_window_mass']-math.fsum(ww)),g['prior_sumrule_abs'])
  simpson=dx/3*(native_values[0]+native_values[-1]+4*math.fsum(native_values[1:-1:2])+2*math.fsum(native_values[2:-1:2]));a.upper(tag+'/independent Simpson stored',abs(simpson-n['finite_window_simpson_mass']),g['pointwise_binary64_abs']);a.upper(tag+'/Simpson actual error',abs(simpson-n['finite_window_analytic_mass']),n['simpson_error_bound']+g['pointwise_binary64_abs']);a.need(tag+'/same complete maximum count',len(n['peaks'])==len(r['peaks']))
  loc_error=max(max(min(abs(x['location']-y['location']) for y in r['peaks']) for x in n['peaks']),max(min(abs(x['location']-y['location']) for y in n['peaks']) for x in r['peaks']));a.upper(tag+'/all maximum locations',loc_error,g['peak_location_abs'])
  for p in r['peaks']:
   a.need(tag+'/reference maximum sign/qualification',p['endpoint_signs']==[1,-1] and p['endpoint_qualification']==QUAL);a.upper(tag+'/reference root width',p['bracket'][1]-p['bracket'][0],c['numerics']['stationary_bracket_width_max']);a.upper(tag+'/reference root derivative',abs(value(p['location'],er,wr,h,1)),g['stationary_derivative_abs']);a.need(tag+'/reference strict max curvature',value(p['location'],er,wr,h,2)<-g['minimum_peak_curvature'])
  if n['id']=='control_single':a.upper(tag+'/analytic single pole',max(abs(p['location']-1.25) for p in r['peaks']),g['control_location_abs'])
  if n['id']=='control_equal':
   z=2*math.sqrt(1+h*h)-(1+h*h);expected=[0.] if z<=0 else [-math.sqrt(z),math.sqrt(z)];a.need(tag+'/equalpair count',len(expected)==len(r['peaks']));a.upper(tag+'/analytic equalpair locations',max(abs(x-p['location']) for x,p in zip(expected,r['peaks'])),g['control_location_abs'])
  summaries.append(dict(id=n['id'],eta=h,maximum_count=len(r['peaks']),independent_full_curve_abs=diff,all_maximum_location_abs=loc_error))
 return summaries,largest_curve

def main():
 p=argparse.ArgumentParser();p.add_argument('--packet',type=Path,required=True);p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args();args.output.mkdir(parents=True,exist_ok=False);a=Audit();start=time.monotonic();report={};error=None
 try:
  source,raw,e,resources=metadata(args.packet,a,args.base);c=tomllib.loads((source/'manifest.toml').read_text());n=read(raw/'native.json');r=read(raw/'reference.json');old=read(raw/'comparison.json');a.need('literal2453rawchecksPASS35rowszero credit',old['status']=='PASS' and old['scientific_completions']==0 and old['catalogue_status']=='NOT_RUN' and old['pilot_excluded'] and len(old['checks'])==2453 and all(v['passed'] for v in old['checks']) and len(n['rows'])==len(r['rows'])==len(old['details'])==35)
  for i,v in enumerate(old['checks']):
   if 'value' in v:a.upper('every retained raw bound '+str(i),v['value'],v['bound'])
  for backend,doc in [('native',n),('quspin',r)]:
   specs=expected_spectra(source,backend,c);wanted=[(s,h) for s in specs for h in c['etas']];a.need(backend+'/original35grid',len(wanted)==len(doc['rows'])==35)
   for row_index,((s,h),row) in enumerate(zip(wanted,doc['rows'])):
    a.need(backend+'/originalcompletegroups '+row['id']+str(h),(row['id'],row['role'],row['branch'],row['groups'],row['eta'])==(s['id'],s['role'],s['branch'],s['groups'],h))
    fp=hashlib.sha256(canonical(dict(backend='retained_QuSpin_Lehmann' if backend=='quspin' else 'actual_native_prior_ED',spectrum=s,eta_hex=float(h).hex(),poles_hex=[float(v['omega']).hex() for v in s['groups']],weights_hex=[float(v['weight']).hex() for v in s['groups']]))).hexdigest();a.need(backend+'/exactinputfingerprint '+row['id']+str(h),fp==(row['proof_curve_fingerprint'] if backend=='quspin' else doc['input_fingerprints'][row_index]))
  proof=Stream(raw/'reference_sign_proof.jsonl',a,c,e['source_freeze_sha256'])
  for row in r['rows']:proof.census(row)
  stats=proof.finish(r['complete_sign_proof']);rows,maxcurve=physical(n['rows'],r['rows'],c,a);a.need('priorfailedattempts preserved',read(source/'implementation_manifest.json')['old_failure_jobs']==['6466312','6466728']);a.need('no physical model/source gates changed',sha(source/'manifest.toml')==sha(source/'original_v1/manifest.toml'))
  for rel,digest in list(a.inputs.items()):a.need('input immutable after audit '+rel,sha(args.base/rel)==digest)
  report.update(status='PASS',independent_mathematics='PASS',grid_rows=35,full_census_replayed=True,every_point_sign_independently_exact=True,original_failed_attempts_preserved=True,proof_statistics=stats,row_metrics=rows,max_independent_full_curve_abs=maxcurve,original_resources=resources,original_execution_elapsed_seconds=e['finished_unix']-e['started_unix'],comparison_sha256=sha(raw/'comparison.json'),proof_sha256=sha(raw/'reference_sign_proof.jsonl'),execution_sha256=sha(raw/'execution.json'),source_archive_sha256=sha(args.packet/'source_archive.tar.gz'),source_freeze_sha256=sha(source/'source_freeze.json'))
 except Exception as ex:error=type(ex).__name__+': '+str(ex);report.update(status='UNRESOLVED',error=error)
 report.update(schema='X14_EXACT_SIGN_PILOT_INDEPENDENT_AUDIT_V1',auditor_sha256=sha(__file__),pilot_excluded=True,scientific_completions=0,catalogue_status='NOT_RUN',full_admitted=False,checks=a.checks,check_count=len(a.checks),metric_specific_errors=a.metrics,input_sha256=a.inputs,local_analysis_runtime=dict(python=platform.python_version(),implementation=platform.python_implementation(),stdlib_only=True,candidate_modules_imported=False,original_pinned_runtime_replay=False),scope='Independent saved-data mathematics only: exact integer sign sums for every request, complete conditional floating census replay, original raw bound validation and independent full-grid convolution/mass/controls. No original renderer, optimizer, eigensolver, sampler or new fixture executed; existing kernel/gates untouched.',elapsed_seconds=time.monotonic()-start,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (args.output/'audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in report.items() if k in ['status','error','check_count','proof_statistics','max_independent_full_curve_abs','elapsed_seconds']},indent=2));return 0 if error is None else 2
if __name__=='__main__':raise SystemExit(main())
