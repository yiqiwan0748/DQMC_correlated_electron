# Pre-operation integer inventory

No operation in this inventory has been evaluated on a fixture during
preparation. Integer and source-hash calculations used to write this static
inventory are metadata only. A future pilot must independently review this
inventory and the actual runtime before freeze/execution.

Let B(z)=max(1,bit_length(z)). The guard checks an upper bound b **before**
each operation and reserves 4b+256 bits, rejecting a reservation above
65,536. It then checks the result as a fail-closed postcondition. The extra
workspace reservation is deliberately conservative; it is not a numerical
error allowance and cannot make an otherwise invalid proof valid.

| Operation | Bounds checked before arithmetic |
|---|---|
| finite float.as_integer_ratio | 1076 for both binary64 integers before conversion; actual integer bounds afterwards |
| integer sum/subtraction | max(B(a),B(b))+1 |
| integer multiplication | B(a)+B(b), even if cancellation/zero would make it smaller |
| integer exact division/remainder and gcd | both input sizes; quotient/remainder/gcd cannot exceed input magnitudes |
| Fraction(n,d) | both input bounds before gcd, sign normalization and exact divisions; d cannot be zero |
| Fraction addition/subtraction | B(na)+B(db), B(nb)+B(da), max of those+1, B(da)+B(db), before any cancellation |
| Fraction multiplication | B(na)+B(nb), B(da)+B(db), and all four gcd inputs before cancellation |
| Fraction division | B(na)+B(db), B(nb)+B(da), and all four gcd inputs; nb cannot be zero |
| term t², eta² and d² | separate guarded multiplication calls, with no unguarded Fraction power |
| independent term construction | every numerator/denominator product, sum, gcd and exact division calls the integer guard |
| prefix/suffix denominator products | every product checked separately before allocation |
| common numerator and rational equality | each a_j*prefix_j*suffix_(j+1), sum, and final cross product checked before execution |
| hexadecimal encoding/decoding | integer size and maximum encoded length before encoding; line/character length and predicted bit bound before int parsing |

The actual pinned Fraction implementation uses gcd-reduced branches.
Addition/subtraction first forms the two unreduced numerator cross products
and a possible sum; its later denominator is at most da*db. Multiplication
and division first divide by gcds and then multiply. Bounds above use the
larger unreduced inputs, so they cover all those branches, including a small
final answer caused by cancellation. No other Fraction operator (power,
ordering/comparison, decimal conversion) is used. Numerator comparisons are
integer comparisons. Sign negation is bounded by the same integer size.

`IntegerGuard.reserve` also leaves a factor-four plus 256-bit reservation
for CPython digit carry/normalization and the native multiplication/division
implementation. The mathematical bit-growth claim concerns the integer
temporaries in the inventoried operators; this is not a formal proof of all
C allocator workspace or Python object overhead. The pinned CPython gcd
uses remainders and fixed-word/digit linear combinations whose mathematical
outputs do not exceed the original operands. Any different digit model or
provider is rejected. The independent OS memory and time caps remain
mandatory. A source/runtime reviewer must reject this candidate if the
stated conservative native scratch reservation cannot be justified for the
pinned implementation; no automatic admission is inferred here.

The independent verifier intentionally may hit the bit cap earlier because
its common denominator is not the producer's incrementally reduced sum.
That yields UNRESOLVED rather than silently changing the verification
algorithm, increasing a cap, omitting terms, or trusting a producer sign.
All bounds are fixed before data; later resource failure needs a new
separately reviewed source version.
