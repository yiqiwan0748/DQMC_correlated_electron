#!/usr/bin/env python3
"""Metadata/resource-only compute assessment; no numerical package or producer import."""
import argparse,datetime,hashlib,json,math,os,pathlib,re,tarfile,time
HERE=pathlib.Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def main():
 p=argparse.ArgumentParser();p.add_argument('--packet',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();checks=[];bindings={};error=None;r={}
 def need(n,v):checks.append(dict(name=n,passed=bool(v)));assert v,n
 def bind(p):p=pathlib.Path(p);h=sha(p);bindings[str(p)]=h;return h
 try:
  need('compute1CPU3500',os.getenv('SLURM_JOB_ID','').isdigit() and os.getenv('SLURM_CPUS_PER_TASK')=='1' and os.getenv('SLURM_MEM_PER_NODE')=='3500')
  plan=read(HERE/'full_workflow_plan.json');fr=read(HERE/'source_freeze.json');need('fullreviewedfreeze',fr['schema']=='X14_EXACT_SIGN_FULL_V3_SOURCE_FREEZE' and fr['mode']=='FULL_ONLY')
  for n,h in fr['files'].items():
   f=HERE/n;need('fullsource/'+n,not pathlib.Path(n).is_absolute() and '..' not in pathlib.Path(n).parts and not f.is_symlink() and f.is_file() and bind(f)==h)
  review=read(HERE/'independent_pilot_review.json');need('actualindependentpilotmath',review['schema']=='X14_EXACT_SIGN_PILOT_INDEPENDENT_AUDIT_V1' and review['status']==review['independent_mathematics']=='PASS' and review['grid_rows']==35 and review['full_census_replayed'] and review['every_point_sign_independently_exact'] and review['scientific_completions']==0 and review['catalogue_status']=='NOT_RUN' and review['pilot_excluded'] and not review['full_admitted'] and all(q['passed'] for q in review['checks']))
  iv=read(HERE/'pilot_input_inventory.json');need('fixedinputpacket',iv['schema']=='ROOT_X14_V2_PILOT_ASSESSMENT_INPUT_INVENTORY' and iv['pilot_job_id']=='6467268')
  for n,q in iv['files'].items():
   f=a.packet/n;need('input/'+n,not pathlib.Path(n).is_absolute() and '..' not in pathlib.Path(n).parts and not f.is_symlink() and f.is_file() and f.stat().st_size==q['bytes'] and bind(f)==q['sha256'])
  release=read(a.packet/'release_freeze.json');need('originalpilotfreeze',bind(a.packet/'release_freeze.json')==plan['prior_pilot_source_freeze_sha256']==bind(a.packet/'source/source_freeze.json'))
  need('originalpilotarchive',bind(a.packet/'source_archive.tar.gz')=='3bfa6d393bb59c6eb1c5f14b9d1bad5dfde0bb4e6b309bafff06a4052f3a5f5b'==release['archive_sha256']);seen=set()
  with tarfile.open(a.packet/'source_archive.tar.gz') as tf:
   for m in tf:
    n=m.name[len(release['prefix']):];need('pilotmember/'+m.name,m.isfile() and m.name.startswith(release['prefix']) and n in release['files'] and n not in seen and '..' not in pathlib.PurePosixPath(m.name).parts and hashlib.sha256(tf.extractfile(m).read()).hexdigest()==release['files'][n]==bind(a.packet/'source'/n));seen.add(n)
  need('all54source',len(seen)==54 and seen==set(release['files']))
  raw=a.packet/'results';e=read(raw/'execution.json');q=read(raw/'comparison.json');native=read(raw/'native.json');reference=read(raw/'reference.json')
  need('fixedpilotexecution',bind(raw/'execution.json')==plan['prior_pilot_execution_sha256']==review['execution_sha256'] and e['status']=='PROCESSES_COMPLETE' and e['mode']=='pilot' and e['job_id']=='6467268' and e['scientific_completions']==0 and not e['full_admitted'] and e['source_freeze_sha256']==plan['prior_pilot_source_freeze_sha256'] and e['cpus']==1 and e['memory_mb']==3500)
  need('literalall2453checks35rows',bind(raw/'comparison.json')==plan['prior_pilot_comparison_sha256']==review['comparison_sha256'] and q['status']=='PASS' and q['scientific_completions']==0 and q['catalogue_status']=='NOT_RUN' and q['pilot_excluded'] and len(q['checks'])==2453 and all(x['passed'] for x in q['checks']) and len(q['details'])==len(native['rows'])==len(reference['rows'])==35)
  need('all35nativefingerprints',len(native['input_fingerprints'])==len(set(native['input_fingerprints']))==35)
  need('originalcompleteproof',bind(raw/'reference_sign_proof.jsonl')==plan['prior_pilot_proof_sha256']==review['proof_sha256']==reference['complete_sign_proof']['sha256']==q['proof_sha256'] and reference['complete_sign_proof']['complete'] and q['complete_sign_proof_verification']['status']=='PASS' and q['complete_sign_proof_verification']['every_census_sign_replayed'] and q['complete_sign_proof_verification']['independent_prefix_suffix_verification'])
  need('threecompleteroles',[x['name'] for x in e['processes']]==['native','reference','comparator'] and all(x['exit_code']==0 and math.isfinite(x['elapsed_seconds']) and x['elapsed_seconds']>0 for x in e['processes']))
  for n,row in e['outputs'].items():need('executionoutput/'+n,bind(raw/n)==row['sha256'] and (raw/n).stat().st_size==row['bytes'])
  rss=[]
  for role in ['native','reference','comparator']:
   text=(raw/(role+'.resources.txt')).read_text();need('resourceexit/'+role,'Exit status: 0' in text);rss.append(int(re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text)[1]))
  before=read(a.packet/'transfer_before.json');after=read(a.packet/'transfer_after.json');need('originalruntime43stable',before['runtime_files']==after['runtime_files'] and before['runtime_critical_file_sha256']==after['runtime_critical_file_sha256'] and len(before['runtime_files'])==43 and after['status']=='PASS')
  rows=[line.split('|') for line in (a.packet/'sacct_fresh.txt').read_text().splitlines() if line.strip()];job=[x for x in rows if x[0]=='6467268'];need('own11fieldaccounting',len(job)==1 and len(job[0])==11 and job[0][2:6]==['COMPLETED','0:0','1','3500M'] and job[0][10]=='00:10:00')
  days,clock=job[0][8].split('-',1) if '-' in job[0][8] else ('0',job[0][8]);hours,minutes,seconds=map(int,clock.split(':'));scheduler_seconds=int(days)*86400+hours*3600+minutes*60+seconds;runner_seconds=e['finished_unix']-e['started_unix'];need('finiterunnerclock',math.isfinite(runner_seconds) and runner_seconds>0 and runner_seconds<=scheduler_seconds+1)
  role_seconds=sum(x['elapsed_seconds'] for x in e['processes']);need('roleswithintimedrunner',role_seconds<=runner_seconds+1);outside=max(0.,scheduler_seconds-runner_seconds);old_projection=2*8*role_seconds+30;new_projection=plan['projection_factor']*plan['channel_multiplier']*role_seconds+plan['cold_preflight_factor']*outside+plan['constant_margin_seconds'];peak=max(rss);eligible=new_projection<=plan['max_projected_full_seconds'] and peak<=plan['max_pilot_rss_KiB']
  need('newbudgetwithinallocation',plan['outer_timeout_seconds']+plan['post_timeout_kill_seconds']<60*plan['allocation_minutes'] and plan['max_projected_full_seconds']<plan['outer_timeout_seconds'])
  for path,h in list(bindings.items()):need('inputstableafter/'+path,sha(path)==h)
  r.update(status='ELIGIBLE_FOR_SEPARATE_ROOT_FULL_REVIEW' if eligible else 'UNRESOLVED',all_pilot_scientific_qualifications_pass=True,old_resource_result_preserved=True,old_projection_seconds=old_projection,old1000second_forecast_eligible=old_projection<=1000,old20minute_proposal_not_relabelled=True,new_resource_protocol_explicit=True,projected_full_seconds=new_projection,max_pilot_rss_KiB=peak,observed_scheduler_seconds=scheduler_seconds,observed_runner_seconds=runner_seconds,observed_role_seconds=role_seconds,observed_outside_runner_seconds=outside,projection_rule=plan['projection_rule'],source_freeze_sha256=sha(HERE/'source_freeze.json'),workflow_plan_sha256=sha(HERE/'full_workflow_plan.json'),independent_pilot_review_sha256=sha(HERE/'independent_pilot_review.json'))
 except Exception as ex:error=type(ex).__name__+': '+str(ex);r.update(status='UNRESOLVED',error=error)
 r.update(schema='X14_EXACT_SIGN_V3_PILOT_COMPUTE_RESOURCE_ASSESSMENT',assessment_job=os.environ.get('SLURM_JOB_ID'),assessor_sha256=sha(__file__),checks=checks,check_count=len(checks),input_sha256=bindings,scientific_completions=0,full_admitted=False,job_submitted=False,new_physics_or_producer_or_sampler_or_optimizer=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());a.output.parent.mkdir(parents=True,exist_ok=True)
 with a.output.open('x') as f:json.dump(r,f,indent=2,allow_nan=False);f.write('\n')
 print(json.dumps({k:r[k] for k in ['status','check_count','scientific_completions']}));return 0 if r['status']=='ELIGIBLE_FOR_SEPARATE_ROOT_FULL_REVIEW' else 2
if __name__=='__main__':raise SystemExit(main())
