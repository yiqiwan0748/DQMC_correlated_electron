"""Bounded producer Fraction arithmetic; no arithmetic runs on import.

Every Fraction operator is preceded by source-derived bounds on BOTH
unreduced cross products, their sum, and denominator products. This is a
resource guard, not a floating error allowance. Budget exhaustion is fatal.
The independent verifier in verify_exact.py does not use these formulas.
"""
import math
from fractions import Fraction


class ProofBudgetExceeded(ValueError):
    pass


class IntegerGuard:
    def __init__(self, maximum_bits=65536):
        self.cap = maximum_bits
        self.maximum_predicted_bits = 0
        self.operations = 0

    @staticmethod
    def bits(n):
        if type(n) is not int:
            raise TypeError('Exact integers only')
        return max(1, n.bit_length())

    def reserve(self, *bounds):
        """BEFORE arithmetic: bound values and conservative native workspace.

        The 4*b+256 envelope reserves more than unreduced products/sums and
        CPython's digit normalization/carry scratch; it is deliberately
        checked before, not inferred from a small reduced result. See
        ARITHMETIC_INVENTORY.md for scope and pinned-source assumptions.
        """
        for b in bounds:
            if type(b) is not int or b < 0:
                raise TypeError('Invalid operation bit bound')
            workspace = 4*b + 256
            self.maximum_predicted_bits = max(self.maximum_predicted_bits, workspace)
            if workspace > self.cap:
                raise ProofBudgetExceeded('Pre-operation integer/workspace bit cap')
        self.operations += 1

    def check(self, *values):
        if any(self.bits(n) > self.cap for n in values):
            raise ProofBudgetExceeded('Integer postcondition cap (no continued proof)')

    def add(self, a, b):
        self.reserve(max(self.bits(a), self.bits(b)) + 1)
        z = a+b
        self.check(z)
        return z

    def sub(self, a, b):
        self.reserve(max(self.bits(a), self.bits(b)) + 1)
        z = a-b
        self.check(z)
        return z

    def mul(self, a, b):
        self.reserve(self.bits(a) + self.bits(b))
        z = a*b
        self.check(z)
        return z

    def neg(self, a):
        self.reserve(self.bits(a))
        return -a

    def divexact(self, a, b):
        if b == 0:
            raise ZeroDivisionError('Exact division by zero')
        self.reserve(self.bits(a), self.bits(b))
        q, r = divmod(a, b)
        if r:
            raise ValueError('Expected exact integer division')
        self.check(q, r)
        return q

    def gcd(self, a, b):
        self.reserve(self.bits(a), self.bits(b))
        z = math.gcd(a, b)
        self.check(z)
        return z

    def ratio(self, value):
        if type(value) is not float or not math.isfinite(value):
            raise ValueError('Finite binary64 Python float required')
        # All finite IEEE binary64 ratios fit in 1075 bits; reserve BEFORE
        # the builtin allocates numerator/denominator, including subnormals.
        self.reserve(1076)
        a, b = value.as_integer_ratio()
        self.check(a, b)
        if b <= 0:
            raise ValueError('Nonpositive exact denominator')
        return a, b

    def encode(self, value):
        # Hex avoids CPython's decimal digit conversion limit. Guard bytes
        # BEFORE conversion; at most ceil(cap/4)+3 ASCII characters.
        self.reserve(self.bits(value))
        if (self.bits(value)+3)//4 + 3 > self.cap//4 + 4:
            raise ProofBudgetExceeded('Integer serialization cap')
        return hex(value)

    def decode(self, text):
        if not isinstance(text, str) or len(text) > self.cap//4 + 4:
            raise ProofBudgetExceeded('Input integer encoding cap before parse')
        digits = text[1:] if text.startswith('-') else text
        if not digits.startswith('0x') or not digits[2:] or any(c not in '0123456789abcdef' for c in digits[2:]):
            raise ValueError('Noncanonical hexadecimal integer')
        self.reserve(4*len(digits[2:]))
        z = int(text, 16)
        self.check(z)
        if hex(z) != text:
            raise ValueError('Noncanonical exact integer encoding')
        return z


class FractionArithmetic:
    def __init__(self, guard):
        self.g = guard

    def make(self, n, d):
        if d == 0:
            raise ZeroDivisionError('Zero rational denominator')
        self.g.reserve(self.g.bits(n), self.g.bits(d))
        out = Fraction(n, d)
        self.g.check(out.numerator, out.denominator)
        return out

    def floating(self, x):
        return self.make(*self.g.ratio(float(x)))

    def op(self, kind, a, b):
        na, da, nb, db = a.numerator, a.denominator, b.numerator, b.denominator
        # Upper bounds cover ALL branches of the pinned Fraction _add/_sub,
        # _mul/_div implementations BEFORE gcd cancellation is known.
        ba, bd, bb, be = map(self.g.bits, (na, da, nb, db))
        if kind in ('add', 'sub'):
            self.g.reserve(ba+be, bb+bd, max(ba+be, bb+bd)+1, bd+be)
            out = a+b if kind == 'add' else a-b
        elif kind == 'mul':
            self.g.reserve(ba+bb, bd+be, ba, bd, bb, be)
            out = a*b
        elif kind == 'div':
            if nb == 0:
                raise ZeroDivisionError('Zero rational divisor')
            self.g.reserve(ba+be, bb+bd, ba, bd, bb, be)
            out = a/b
        else:
            raise ValueError('Uninventoried Fraction operation')
        self.g.check(out.numerator, out.denominator)
        return out

    def derivative_sign(self, x, poles, weights, eta):
        r = self.floating(x)
        h = self.floating(eta)
        h2 = self.op('mul', h, h)
        total = self.make(0, 1)
        for pole, weight in zip(poles, weights):
            t = self.op('sub', r, self.floating(float(pole)))
            d = self.op('add', self.op('mul', t, t), h2)
            if d.numerator <= 0:
                raise ValueError('Exact Lorentz denominator not positive')
            term = self.op('div', self.op('mul', self.floating(float(weight)), t), self.op('mul', d, d))
            total = self.op('add', total, term)
        # A' = -(2 eta/pi)*total: pi is positive, and eta must be positive.
        if not math.isfinite(eta) or eta <= 0:
            raise ValueError('Positive finite width required')
        sign = -1 if total.numerator > 0 else 1 if total.numerator < 0 else 0
        return sign, total.numerator, total.denominator
