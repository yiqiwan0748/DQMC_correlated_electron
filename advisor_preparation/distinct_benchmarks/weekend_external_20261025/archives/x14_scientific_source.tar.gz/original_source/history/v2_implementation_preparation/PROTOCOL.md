# X14 v2: excluded exact-sign implementation pilot

This is an unexecuted source candidate. No source freeze, approval receipt,
job, proof evaluation, numerical import, `Fraction` calculation or fixture
calculation has been performed during preparation. X14 remains NOT_RUN.
The original failed pilot 6466312 and trace diagnostic 6466728 are retained;
their original reference renderer is never described as passing.

The question is the original catalogue X14: quantify the difference between
retained exact Lehmann poles and broadened spectral maxima. Both renderers
are new adapters over the previously audited P09 native ED and QuSpin data.
No eigensolver, MC sampler, or new physical-state calculation is introduced.

`manifest.toml`, the catalogue definition, all previous P09 bytes, and the
original 30-file NumPy/SciPy map are unchanged. The physical qualification
still uses width ≤ 1e-7, the same 1e-13 binary64 padding, complete census,
strict interval curvature, derivative/peak/mass/positivity/quadrature/tail
gates, controls, and the registered full-grid peak-shift witness. The four
functions `scalar`, `derivative`, `second`, and `interval_bounds` have the
same AST as v1. The native curve, golden search and render ASTs also agree.

The new, explicitly named implementation qualification is
`PADDED_BINARY64_OR_INDEPENDENT_EXACT_RATIONAL_POINT_SIGN_V2`.
The original padded point sign is used whenever it is definite. Only an
uncertain padded point sign invokes exact rational arithmetic. For original
binary64 inputs t_j=x−e_j and d_j=t_j²+eta²,

    A'(x) = -(2 eta/pi) * sum_j w_j*t_j/d_j².

Since eta>0 and d_j>0, the sign is minus the sign of that rational sum;
pi is a positive common factor. Each input is converted with its exact
binary64 integer ratio, without decimal rounding. A zero numerator is
EXACT_ZERO and never becomes a fabricated positive or negative sign.
Zero-weight terms and their original positions remain in the input map.

Exact signs change point qualification only. The complete census remains
conditional on the unchanged padded binary64 interval derivative and
curvature bounds. No rigorous interval-arithmetic claim is made. Unknown
curvature, flat roots, nonprogress, contradictory signs, Brent failure or
proof/resource exhaustion give UNRESOLVED. The float derivative and Brent
xtol remain unchanged; Brent's retained point must lie in the qualified
bracket and pass the original physical gates.

Every call that requests a point sign is recorded, including calls used to
exclude monotone intervals, contract brackets, qualify unions and deduplicate
roots. Each row has a bijective fingerprint of backend, full spectrum
identity/role/branch/groups, width, and the float-hex poles/weights (including
signed zeros). Sign records retain exact probe hex, padded enclosure,
method, sign, and bounded exact rational numerator/denominator when needed.
Final root objects reference the exact two endpoint event indices. Actual
Brent outputs are separate events. The hash-chained stream has registered
ordered curve headers, complete result hashes and one final footer.

Before PASS, `verify_census.py` repeats the whole census control flow against
the original backend inputs. It recomputes all original floating interval
exclusions and all padded point signs. For every fallback it independently
constructs the terms a_j/b_j using guarded integer pairs, then forms

    D = product_j b_j > 0,
    N = sum_j a_j * prefix_j * suffix_(j+1).

It verifies the producer's rational value by guarded cross multiplication
and verifies sign/EXACT_ZERO. Producer per-term fractions are not trusted.
The saved Brent point is consumed without rerunning an optimizer; its
bracket, original derivative/width gates and complete root/result identity
are checked. Every event must be consumed in order, and every registered
curve must appear exactly once. Missing, extra, truncated or reordered
events cannot establish PASS. No sampled or shortened proof log is accepted.

The sole changed comparator gate is named padded-or-independently-exact
opposite endpoint signs. It is enabled only after this full replay succeeds.
The original padded enclosures are still exported and compared under their
original tolerance. A rational proof is never relabelled as a successful
old padded-only proof.

The only candidate execution is the original 35-row excluded pilot: one
physical spin/momentum channel, all three branches, all five widths, and all
four controls at all widths. It requires a new independently reviewed source
freeze and separate root approval. All numerical imports and work require
that compute allocation. There is no production CLI or full-admission path.
Even a pilot PASS grants zero catalogue completions.

The allocation cap is one CPU, 3500 MB and ten minutes. The original native
renderer, new reference renderer plus full independent verifier/comparator
share a 540-second child-process-group deadline. The proof has at most
200,000 point-sign requests and 200,000 fallbacks, 65,536 guarded integer
bits, one MiB per event, and 256 MiB total streamed bytes. All guards precede
the relevant operation or decoding/writing. Partial files remain evidence
of an unresolved attempt. These are additional implementation resource
guards, never enlarged physical uncertainties.

Actual cost is unmeasured. Any later full candidate needs a new measured,
source-bound pilot/resource assessment, independent review and separate root
admission; the v1 projection does not admit this different arithmetic cost.

`exact_runtime_pins.json` supplements the unchanged numerical map with the
actual CPython3.11.11 executable, Fraction/dependency sources, math/gcd and
decimal extensions, and their explicitly recorded loader providers. The
preflight rehashes these bytes, checks actual imported dispatch and repeats
the loader map before numerical work. No binary is copied. This inventory
does not claim to bind every possible system library or prove binary
correctness; the mathematical proof is conditional on the pinned Python
integer/Fraction semantics and original binary64 interval model.

The Fraction conversion and normalization semantics follow the official
[Python 3.11 Fraction documentation](https://docs.python.org/3.11/library/fractions.html).
Arithmetic guards were inspected against the actual hashed `fractions.py`
and the corresponding [CPython 3.11.11 integer implementation](https://github.com/python/cpython/blob/v3.11.11/Objects/longobject.c).
