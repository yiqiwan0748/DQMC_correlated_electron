X14 v2 is **unexecuted, unfrozen and pilot only**. The original padded-sign
precision failure is retained. The new qualification allows an independently
verified exact rational point sign when the unchanged padded sign is unknown.
All physical grids and tolerances remain in the unchanged manifest.

Read [PROTOCOL.md](PROTOCOL.md) and
[ARITHMETIC_INVENTORY.md](ARITHMETIC_INVENTORY.md) before reviewing the code.
`original_v1/` preserves the original frozen source/archive identities;
`prior/` holds the same previously audited P09 inputs. `prior_feasibility/`
is the unchanged theory proposal. `static_preparation.json` and
`PREPARATION_SHA256SUMS` record source/AST-only preparation, never validation
of the numerical result.

The future root-approved command inside a separate one-CPU/3500MB allocation
is `python -B run_analysis.py pilot NEW_OUTPUT`, with the matching frozen
source and independently reviewed pilot-approval receipt. `pilot.sbatch`
is a candidate wrapper, not a submission. No source freeze or approval is
included. There is no production mode, no full admission, and no catalogue
credit from this pilot.
