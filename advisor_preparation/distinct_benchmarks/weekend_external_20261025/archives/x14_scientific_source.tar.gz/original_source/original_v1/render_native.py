#!/usr/bin/env python3
"""New vectorized renderer of already retained actual-native-ED Lehmann groups."""
import argparse,hashlib,json,math,time
from pathlib import Path
import numpy as np
from io_contract import contract,spectra,write,sha,HERE,read

def curve(x,e,w,eta):
 out=np.zeros_like(np.asarray(x,dtype=float))
 for pole,weight in zip(e,w):out+=weight*eta/(np.pi*((np.asarray(x)-pole)**2+eta**2))
 return out

def golden(e,w,eta,left,right,tol):
 a,b=float(left),float(right);original=[a,b];ratio=(math.sqrt(5)-1)/2;c=b-ratio*(b-a);d=a+ratio*(b-a)
 f=lambda z:float(curve(np.asarray(z),e,w,eta))
 fc,fd=f(c),f(d)
 for _ in range(160):
  if b-a<=tol:break
  if fc>fd:b,d,fd=d,c,fc;c=b-ratio*(b-a);fc=f(c)
  else:a,c,fc=c,d,fd;d=a+ratio*(b-a);fd=f(d)
 if b-a>tol:raise ValueError('Golden peak bracket did not contract')
 x=(a+b)/2
 return dict(location=x,height=f(x),bracket=[a,b],initial_mesh_bracket=original)

def render(s,eta,c):
 e=np.array([g['omega'] for g in s['groups']]);w=np.array([g['weight'] for g in s['groups']]);n=c['mesh_points'];x=np.linspace(c['frequency_min'],c['frequency_max'],n);dx=float(x[1]-x[0]);W=float(sum(w))
 if min(w)<0 or not c['frequency_min']<min(e)<=max(e)<c['frequency_max'] or W<=c['gates']['minimum_total_branch_weight']:raise ValueError('No positive, interior supported spectrum')
 y=curve(x,e,w,eta);indices=np.flatnonzero((y[1:-1]>=y[:-2])&(y[1:-1]>=y[2:])&((y[1:-1]>y[:-2])|(y[1:-1]>y[2:])))+1
 peaks=[golden(e,w,eta,x[i-1],x[i+1],c['numerics']['golden_bracket_width_max']) for i in indices]
 if not peaks:raise ValueError('No interior maximum found')
 # Simpson is an independent finite-window mass estimate; no renormalization.
 mass=dx/3*(y[0]+y[-1]+4*sum(y[1:-1:2])+2*sum(y[2:-1:2]));cdf=sum(float(weight)*(math.atan((x[-1]-pole)/eta)-math.atan((x[0]-pole)/eta))/math.pi for pole,weight in zip(e,w));tail=W-cdf;tail_bound=sum(float(weight)*eta/math.pi*(1/(x[-1]-pole)+1/(pole-x[0])) for pole,weight in zip(e,w));fine=float(max(y));coarse=float(max(y[::c['coarse_mesh_stride']]));probe=np.linspace(0,n-1,257,dtype=int)
 return dict(id=s['id'],role=s['role'],branch=s['branch'],expected_total_weight=s.get('expected_total_weight',0.37 if s['id']=='control_rescaled' else 1.),eta=eta,poles=e.tolist(),weights=w.tolist(),groups=s['groups'],full_weight=W,mesh_points=n,mesh_spacing=dx,probe_indices=probe.tolist(),probe_values=y[probe].tolist(),full_mesh_binary64_sha256=hashlib.sha256(np.asarray(y,dtype='<f8').tobytes()).hexdigest(),peaks=peaks,mesh_maximum_height=fine,coarse_mesh_maximum_height=coarse,mesh_maximum_locations=x[np.flatnonzero(y==max(y))].tolist(),finite_window_analytic_mass=cdf,finite_window_simpson_mass=float(mass),simpson_error_bound=(x[-1]-x[0])*dx**4/180*24*W/(math.pi*eta**5),outside_window_mass=tail,outside_window_upper_bound=tail_bound,cluster_render_error_bound=sum(g['weight']*g['span'] for g in s['groups'])/(math.pi*eta**2))

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('output',type=Path);a=p.parse_args();c=contract(a.mode);start=time.time();rows=[]
 for s in spectra('native',a.mode,c):
  for eta in c['etas']:rows.append(render(s,eta,c))
 write(a.output,dict(schema='X14_RENDERED_RAW_V1',backend='actual_native_prior_ED_new_numpy_renderer',mode=a.mode,scientific_completions=0,source_freeze_sha256=sha(HERE/'source_freeze.json'),prior_input_manifest_sha256=sha(HERE/'prior_inputs.json'),renderer_sha256=sha(__file__),reference_library_pins_sha256=sha(HERE/'reference_library_pins.json'),reference_library_sha256=read(HERE/'reference_library_pins.json')['files'],rows=rows,elapsed_seconds=time.time()-start,producer_or_sampler_executed=False))
if __name__=='__main__':main()
