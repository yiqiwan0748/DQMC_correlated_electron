#!/usr/bin/env python3
"""Bounded compute-node analysis of retained P09 data, never submits jobs."""
import argparse,json,os,signal,subprocess,sys,time
from pathlib import Path
from io_contract import HERE,cfg,sha,write,read

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('output',type=Path);a=p.parse_args();c=cfg();r=c['resources']
 if not os.getenv('SLURM_JOB_ID') or int(os.getenv('SLURM_CPUS_PER_TASK','0'))!=1 or int(os.getenv('SLURM_MEM_PER_NODE','0'))!=3500:raise ValueError('One CPU/3500MB Slurm analysis allocation required')
 if not (HERE/'source_freeze.json').is_file():raise ValueError('Not reviewed/frozen; no analysis authorized')
 if a.mode=='production':
  review=Path(os.environ['X14_ROOT_APPROVED_PILOT_RECEIPT']);assessment=Path(os.environ['X14_PILOT_ASSESSMENT'])
  if sha(review)!=os.environ['X14_ROOT_APPROVAL_SHA256']:raise ValueError('Changed explicit root pilot review')
  approved=read(review);pilot=read(assessment)
  if approved['schema']!='X14_ROOT_REVIEWED_PILOT_ADMISSION_V1' or approved['status']!='APPROVED_FOR_SEPARATE_SUBMISSION' or approved['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or approved['pilot_assessment_sha256']!=sha(assessment):raise ValueError('Missing matching root-reviewed pilot admission')
  if pilot['schema']!='X14_EXCLUDED_PILOT_ENGINEERING_V1' or pilot['status']!='ELIGIBLE_FOR_SEPARATE_ROOT_REVIEW' or pilot['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or pilot['scientific_completions']!=0:raise ValueError('Unqualified or wrong-source excluded pilot')
 a.output.mkdir(parents=True,exist_ok=False);start=time.time();deadline=start+r[a.mode+'_combined_timeout_seconds'];processes=[]
 env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C')
 commands=[('native',[str(HERE/'render_native.py'),a.mode,str(a.output/'native.json')]),('reference',[str(HERE/'render_quspin_reference.py'),a.mode,str(a.output/'reference.json')]),('comparator',[str(HERE/'compare.py'),'--target',str(a.output/'native.json'),'--reference',str(a.output/'reference.json'),'--output',str(a.output/'comparison.json')])]
 status='UNRESOLVED';error=None
 try:
  for name,cmd in commands:
   begin=time.time();remaining=deadline-begin
   if remaining<1:raise TimeoutError('Fixed combined cap exhausted')
   with (a.output/(name+'.stdout.txt')).open('x') as out,(a.output/(name+'.stderr.txt')).open('x') as err:
    proc=subprocess.Popen(['/usr/bin/time','-v','-o',str(a.output/(name+'.resources.txt')),sys.executable,'-B']+cmd,stdout=out,stderr=err,env=env,start_new_session=True)
    try:code=proc.wait(timeout=remaining)
    except subprocess.TimeoutExpired:
     os.killpg(proc.pid,signal.SIGTERM)
     try:proc.wait(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
     code=124
   processes.append(dict(name=name,argv=cmd,exit_code=code,elapsed_seconds=time.time()-begin))
   if code:raise RuntimeError(name+' failed; partial original analysis retained, no blind retry')
  status='PROCESSES_COMPLETE'
 except Exception as ex:error=type(ex).__name__+': '+str(ex)
 outputs={f.name:dict(sha256=sha(f),bytes=f.stat().st_size) for f in a.output.iterdir() if f.is_file()}
 write(a.output/'execution.json',dict(schema='X14_READONLY_ANALYSIS_EXECUTION_V1',mode=a.mode,job_id=os.environ['SLURM_JOB_ID'],status=status,error=error,source_freeze_sha256=sha(HERE/'source_freeze.json'),processes=processes,outputs=outputs,cpus=1,memory_mb=3500,started_unix=start,finished_unix=time.time(),scientific_completions=0,new_eigensolver_or_sampler_executed=False))
 if error:raise RuntimeError(error)
if __name__=='__main__':main()
