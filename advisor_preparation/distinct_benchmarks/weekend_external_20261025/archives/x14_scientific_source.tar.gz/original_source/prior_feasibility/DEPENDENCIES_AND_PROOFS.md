# Required source and mathematical closure before implementation

| Existing dependency | v2 proposal and remaining obligation |
|---|---|
| P09 model/state/poles/residues and exact backend roles | Same original archived sources/raw/audit hashes, all8channels,addition/removal/combined,zero weights and grouping; no new solver or normalization |
| `scalar`, `derivative`, `second`, `interval_bounds` | Preserve numerical bodies/ASTs and padding. The new sign helper has a separate identity; it cannot silently replace curve values or curvature calculations |
| Whole-interval derivative enclosure excludes zero | Keep original conditional padded exclusion verbatim; exact signs at a few points cannot replace this whole-interval proof |
| Strictly positive/negative curvature neighborhood | Keep original padded curvature qualification. No fallback from a non-monotone/unknown neighborhood to simple endpoint sampling |
| Monotone derivative with equal endpoint signs | Exclusion stays valid when BOTH endpoints have their explicitly verified fast or exact signs and curvature proves monotonicity |
| Monotone derivative with opposite endpoint signs | Existence and uniqueness follow from continuity plus strict monotonicity. Retain actual parent, both endpoint proofs and final width<=1e-7 |
| Quarter/midpoint contraction | Same probe schedule and180-iteration bound; exact zero remains zero. Reject collapsed/reordered probes or lost opposite signs; never fabricate a bracket around Brent output |
| Adjacent unresolved boundary cells | Merge only touching/overlapping cells, then independently qualify outer signs and original strict curvature over the complete union |
| Deduplication | Keep overlap-based union and type agreement. Never combine nearby roots without a new qualified union |
| Brent point | Keep original actual binary64 derivative/xtol and require point inside the qualified bracket. If its float endpoint assumptions or convergence fail, report UNRESOLVED; exact endpoint signs do not certify arbitrary Brent output |
| Maxima/minima classification | Retain complete stationary list and original curvature sign. Reference maxima still meet original minimum-curvature and derivative-absolute gates |
| Curve/mesh/mass/tail/control/witness tests | Unchanged65,537points,eta list,all140rows,normalizations,positivity,quadrature,Simpson,all-maxima matching and registered physical shift predicate |

The comparator needs a named endpoint-proof verifier rather than the old
unconditionally padded-opposite-sign assertion. It must recompute proofs from
the backend's original complete groups, with exact equality of backend/id/
branch/eta/input fingerprints. It must still recompute retained float
enclosures and check their stored values under the original tolerance. A
successful exact proof is never reported under the old padded-only name.

Independent verification can avoid mirroring the producer's Fraction sum.
Reduce every rational term to a_j/b_j with b_j>0. Form positive D=product b_j
and N=sum a_j*product_(k!=j)b_k using prefix/suffix integer products. The sign
is -sign(N); cross-multiplication can verify a retained Fraction numerator/
denominator as well. Zero terms retain their original indices. No common
factor, visibility threshold, tiny weight or pole is removed from the measure.
This exact algebra is a point proof only, not an additional benchmark idea.

For finite positive eta, every d_j is strictly positive, so no denominator
ambiguity or floating underflow occurs in the rational calculation itself.
Input conversion must use the exact finite binary64 ratio, not decimal
rounding or a newly fitted coefficient. Fraction(-0.0)=0 is mathematically
valid; raw IEEE input fingerprints still retain the original representation.

A future implementation should record method (PADDED_BINARY64 or
EXACT_RATIONAL or EXACT_ZERO), original padded enclosure, exact-input hash,
probe hex/ratio, rational sign and bounded integer-size statistics. Final
root endpoint proofs must be independently recomputable. Intermediate proof
events may use hashes/bit lengths with a streamed ledger; the complete inputs
remain present. No omitted events or truncated proof log may establish PASS.
Any contradiction between a fast-path sign and the independent exact check
is an implementation qualification failure, not permission to rewrite history.

Runtime closure must retain the existing30-file numerical map and actual
SciPy Cauchy/CDF/QUADPACK/Brent dispatch. Add read-only pins for the actual
Python3.11.11 Fraction source, its integer/gcd dependencies and used Python/
libpython provider; include no binaries. A future reviewer must inspect the
actual dispatch/metadata and integer resource guards before source freeze.

No exact arithmetic has been performed over raw arrays or controls here.
The following resource numbers are proposed caps, not measurements: oneCPU,
3500MB,10-minute pilot/540-second combined cap; exact fallback at most200,000
calls over the entire pilot,65,536-bit guarded integers and a streamed proof
ledger at most256MiB. Intermediate integer operations must be checked before
unbounded growth (including temporary products). Guard exhaustion gives
UNRESOLVED with the original failure preserved. These are extra implementation
resource guards; they do not change any physical threshold.

The original35-row pilot/all controls is the only proposed first execution.
No future full run is admitted by this note or by an old pilot assessment:
integer cost can scale differently from the old floating renderer. A new
measured source-bound pilot and conservative full cost/maximum-group analysis
must pass the existing resource limits and independent review before root
can consider a separate full allocation. No source, freeze, runner or job is
created by this feasibility proposal.
