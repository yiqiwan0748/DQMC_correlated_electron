# X14 exact endpoint-sign fallback: unexecuted feasibility

This proposes a versioned implementation repair to the demonstrated excluded
pilot failure. It is not an implemented algorithm, source freeze, pilot,
scientific comparison or catalogue completion. Original X14 sources, failed
pilot6466312, trace-only diagnostic6466728 and their zero-credit records stay
unchanged. No spectrum, root, rational control or other numerical fixture was
evaluated in preparing this note.

The retained diagnostic shows `enclosed_root` stalling while all three allowed
interior probes have uncertain padded signs. The already published conditional
analysis establishes that the fixed padded-sign requirement cannot achieve the
1e-7 width inside that particular retained failed bracket under its stated
binary64 model. Merely adding probes cannot solve that certificate limitation.
It does not show failure of the original physical peak-width requirement.

For the same recorded binary64 poles e_j, weights w_j, width eta>0 and a finite
binary64 probe x, interpret each input as its exact binary rational. Write

```
t_j = x-e_j
d_j = t_j^2 + eta^2 > 0
F(x) = sum_j w_j*t_j/d_j^2
A_eta'(x) = -(2*eta/pi)*F(x).
```

Therefore sign(A') is exactly the negative sign of rational F. Pi cancels
from the sign question; no higher-precision approximation to pi is needed.
Python Fraction/integer arithmetic can evaluate this finite sum exactly for
the declared input measure. This does not change poles, weights, grouping,
eta, the spectral curve or its normalization, and it introduces no tolerance.

Proposed dispatch keeps the original binary64 padded fast path unchanged.
Only an uncertain sign triggers the exact rational calculation. An exactly
zero rational numerator remains EXACT_ZERO, never an invented nonzero sign.
Its handling follows the existing adjacent-cell/symmetry-boundary rules.
In a qualified strictly monotone derivative neighborhood there is at most one
zero; the original quarter/midpoint refinement then has definite signs at the
other interior probes and contracts in exact arithmetic. Finite distinct-probe
and original iteration guards still apply. This is a feasibility argument,
not a calculation of the failed bracket or proof that all future rows pass.

**The old comparator cannot remain literally unchanged.** It currently
requires padded endpoint enclosures to be strictly positive/negative. That
implementation qualification is precisely the demonstrated obstacle. A new
release would explicitly replace this one certificate rule with: an endpoint
has the required sign if its original padded enclosure proves it OR a
recomputed exact-rational proof proves it. Store both the original enclosure
(possibly uncertain) and the new named proof; never label it a successful
original padded-sign check. This is a different, stronger point-sign proof of
the same mathematical endpoint property, not a widened physical gate. Root
and independent review must accept that pre-data distinction before any code.

The physical root width1e-7, complete140-row grid/all maxima, strict monotone
curvature, derivative/location/control/overlap witness, positive full measure,
mass/tails, cluster uncertainty and all curve/integration gates remain fixed.
The original float padding1e-13 remains unchanged everywhere it is used.

Global completeness is still conditional on the original padded interval
range/curvature bounds. Exact point signs alone do not turn those bounds into
rigorous interval arithmetic or prove curvature on an interval. If a range
or curvature remains unqualified, a flat root cannot be isolated, the full
census is incomplete, Brent cannot produce an enclosed point, or resources
are insufficient, the new release remains UNRESOLVED. No exact interval
fallback, new pole selection, smaller padding or wider window is proposed.

`DEPENDENCIES_AND_PROOFS.md` lists every census/exclusion dependency and the
required independent proof verification. The bounded next step would be a
new reviewed implementation and excluded35-row resource/quality pilot using
the original10-minute allocation/540-second inner cap. It would rerun only
rendering analysis on unchanged P09 data. There is no full-run admission here.
