"""Complete, capped census event stream; no truncation or sampling of proof.

The consumer replays the entire control flow against original curve inputs.
It never trusts producer reduced per-pole terms or a sign-only certificate.
"""
import hashlib,json,math
from pathlib import Path
from exact_arithmetic import IntegerGuard,FractionArithmetic,ProofBudgetExceeded
from verify_exact import independent_sign

SCHEMA = 'X14_PADDED_OR_EXACT_POINT_SIGN_COMPLETE_STREAM_V2'
QUALIFICATION = 'PADDED_BINARY64_OR_INDEPENDENT_EXACT_RATIONAL_POINT_SIGN_V2'


def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')


def file_sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):
            h.update(block)
    return h.hexdigest()


def curve_identity(s, eta, backend="retained_QuSpin_Lehmann"):
    # Position, multiplicity, zero weight and signed float zero are retained.
    data = dict(backend=backend,spectrum=s,
                eta_hex=float(eta).hex(),poles_hex=[float(v['omega']).hex() for v in s['groups']],
                weights_hex=[float(v['weight']).hex() for v in s['groups']])
    return hashlib.sha256(canonical(data)).hexdigest()


class StreamBase:
    def __init__(self, caps):
        self.caps = caps
        self.guard = IntegerGuard(caps['integer_bit_cap'])
        self.sequence = 0
        self.previous = '0'*64
        self.calls = 0
        self.exact_calls = 0
        self.curves = []
        self.active = None
        self.last_sign_event = None

    def request(self):
        if not self.active:
            raise ValueError('Point sign outside a registered curve')
        if self.calls >= self.caps['sign_call_cap_total']:
            raise ProofBudgetExceeded('Total point-sign request cap')
        self.calls += 1

    def end_curve(self, roots, visited, excluded):
        data = dict(kind='CURVE_END',fingerprint=self.active,
                    result_sha256=hashlib.sha256(canonical([roots,visited,excluded])).hexdigest())
        self.event(data)
        self.active = None


class ProofWriter(StreamBase):
    def __init__(self, path, caps, freeze_sha, expected_fingerprints):
        super().__init__(caps)
        self.path = Path(path)
        self.handle = self.path.open('xb')
        self.bytes = 0
        self.expected = expected_fingerprints
        self.arithmetic = FractionArithmetic(self.guard)
        self.event(dict(kind='HEADER',schema=SCHEMA,qualification=QUALIFICATION,
                        source_freeze_sha256=freeze_sha,caps=caps,expected_curves=expected_fingerprints))

    def event(self, data):
        payload = dict(sequence=self.sequence,previous_sha256=self.previous,data=data)
        digest = hashlib.sha256(canonical(payload)).hexdigest()
        line = canonical(dict(payload=payload,sha256=digest))+b'\n'
        if len(line)>self.caps['maximum_event_bytes'] or self.bytes+len(line)>self.caps['proof_ledger_byte_cap']:
            raise ProofBudgetExceeded('Complete proof ledger byte cap before write')
        self.handle.write(line)
        self.bytes += len(line)
        self.sequence += 1
        self.previous = digest
        return payload['sequence']

    def begin_curve(self, s, eta):
        fp = curve_identity(s,eta)
        if self.active or fp in self.curves or len(self.curves)>=len(self.expected) or self.expected[len(self.curves)]!=fp:
            raise ValueError('Nonbijective or misordered curve identity')
        self.active = fp
        self.curves.append(fp)
        self.event(dict(kind='CURVE_BEGIN',fingerprint=fp))

    def sign(self, x, e, w, eta, c, interval_function):
        self.request()
        enclosure = interval_function(x,x,e,w,eta,1,c['numerics']['stationary_binary64_padding'])
        sign = 1 if enclosure[0]>0 else -1 if enclosure[1]<0 else 0
        data = dict(kind='SIGN',fingerprint=self.active,x_hex=float(x).hex(),
                    enclosure=list(enclosure),method='PADDED_BINARY64',sign=sign)
        if not sign:
            if self.exact_calls >= self.caps['exact_fallback_call_cap_total']:
                raise ProofBudgetExceeded('Exact fallback call cap before Fraction work')
            self.exact_calls += 1
            sign,n,d = self.arithmetic.derivative_sign(float(x),e,w,float(eta))
            data.update(method='EXACT_ZERO' if sign==0 else 'EXACT_RATIONAL',sign=sign,
                        rational_sum_numerator_hex=self.guard.encode(n),
                        rational_sum_denominator_hex=self.guard.encode(d))
        self.last_sign_event = self.event(data)
        return sign,enclosure

    def root_point(self, a, b, compute):
        value = float(compute())
        if not math.isfinite(value) or not a<=value<=b:
            raise ValueError('Brent point outside the qualified bracket')
        self.event(dict(kind='ROOT_POINT',fingerprint=self.active,a_hex=float(a).hex(),
                        b_hex=float(b).hex(),root_hex=value.hex()))
        return value

    def finish(self):
        if self.active or self.curves!=self.expected:
            raise ValueError('Incomplete curve coverage cannot finish a proof')
        self.event(dict(kind='FOOTER',complete=True,curves=self.curves,sign_calls=self.calls,
                        exact_calls=self.exact_calls,integer_guard_operations=self.guard.operations,
                        maximum_reserved_integer_workspace_bits=self.guard.maximum_predicted_bits))
        self.handle.flush()
        self.handle.close()
        return dict(schema=SCHEMA,qualification=QUALIFICATION,sha256=file_sha(self.path),
                    bytes=self.bytes,curves=len(self.curves),sign_calls=self.calls,exact_calls=self.exact_calls,
                    complete=True,maximum_reserved_integer_workspace_bits=self.guard.maximum_predicted_bits)

    def abort(self):
        self.handle.flush()
        self.handle.close()


class ProofReader(StreamBase):
    def __init__(self, path, caps, freeze_sha, expected_fingerprints):
        super().__init__(caps)
        self.path = Path(path)
        if not self.path.is_file() or self.path.is_symlink() or self.path.stat().st_size>caps['proof_ledger_byte_cap']:
            raise ValueError('Missing, nonregular or oversized proof ledger')
        self.handle = self.path.open('rb')
        self.expected = expected_fingerprints
        header = self.take('HEADER')
        if header!=dict(kind='HEADER',schema=SCHEMA,qualification=QUALIFICATION,
                        source_freeze_sha256=freeze_sha,caps=caps,expected_curves=expected_fingerprints):
            raise ValueError('Changed proof header or complete backend input fingerprint grid')

    def take(self, kind):
        # Bound line bytes BEFORE JSON decoding or integer-string inspection.
        line = self.handle.readline(self.caps['maximum_event_bytes']+1)
        if not line or len(line)>self.caps['maximum_event_bytes'] or not line.endswith(b'\n'):
            raise ValueError('Missing/truncated/oversized proof event')
        value = json.loads(line)
        if set(value)!=set(('payload','sha256')):
            raise ValueError('Unexpected event envelope')
        payload = value['payload']
        if set(payload)!=set(('sequence','previous_sha256','data')) or payload['sequence']!=self.sequence or payload['previous_sha256']!=self.previous:
            raise ValueError('Missing, reordered or duplicated proof event')
        if hashlib.sha256(canonical(payload)).hexdigest()!=value['sha256'] or payload['data'].get('kind')!=kind:
            raise ValueError('Changed event hash/type')
        self.sequence += 1
        self.previous = value['sha256']
        return payload['data']

    def event(self, expected):
        if self.take(expected['kind'])!=expected:
            raise ValueError('Proof census replay decision/result differs')

    def begin_curve(self, s, eta):
        fp = curve_identity(s,eta)
        if self.active or fp in self.curves or len(self.curves)>=len(self.expected) or self.expected[len(self.curves)]!=fp:
            raise ValueError('Nonbijective original backend/row/width coverage')
        self.active = fp
        self.curves.append(fp)
        self.event(dict(kind='CURVE_BEGIN',fingerprint=fp))

    def sign(self, x, e, w, eta, c, interval_function):
        self.request()
        event_index = self.sequence
        d = self.take('SIGN')
        enclosure = interval_function(x,x,e,w,eta,1,c['numerics']['stationary_binary64_padding'])
        fast = 1 if enclosure[0]>0 else -1 if enclosure[1]<0 else 0
        if d.get('fingerprint')!=self.active or d.get('x_hex')!=float(x).hex() or d.get('enclosure')!=list(enclosure):
            raise ValueError('Point proof not derived from this exact original probe/curve/enclosure')
        base = dict(kind='SIGN',fingerprint=self.active,x_hex=float(x).hex(),enclosure=list(enclosure))
        if fast:
            expected = dict(base,method='PADDED_BINARY64',sign=fast)
            if d!=expected:
                raise ValueError('Original definite padded sign was replaced')
            sign = fast
        else:
            if self.exact_calls>=self.caps['exact_fallback_call_cap_total']:
                raise ProofBudgetExceeded('Verifier fallback call cap before work')
            self.exact_calls += 1
            if set(d)!=set(base)|{'method','sign','rational_sum_numerator_hex','rational_sum_denominator_hex'}:
                raise ValueError('Wrong exact-sign proof fields')
            sign = independent_sign(float(x),e,w,float(eta),d['rational_sum_numerator_hex'],d['rational_sum_denominator_hex'],self.guard)
            if d['sign']!=sign or d['method']!=('EXACT_ZERO' if sign==0 else 'EXACT_RATIONAL'):
                raise ValueError('Exact-zero/nonzero proof classification differs')
        self.last_sign_event = event_index
        return sign,enclosure

    def root_point(self, a, b, compute):
        # No optimizer is called by verification. The original Brent output
        # is retained and checked by unchanged physical derivative/width gates.
        d = self.take('ROOT_POINT')
        if set(d)!=set(('kind','fingerprint','a_hex','b_hex','root_hex')) or d['fingerprint']!=self.active or d['a_hex']!=float(a).hex() or d['b_hex']!=float(b).hex():
            raise ValueError('Retained root does not belong to this replayed bracket')
        if not isinstance(d['root_hex'],str) or len(d['root_hex'])>32:
            raise ValueError('Invalid retained binary64 root encoding')
        root = float.fromhex(d['root_hex'])
        if not math.isfinite(root) or root.hex()!=d['root_hex'] or not a<=root<=b:
            raise ValueError('Invalid retained Brent point')
        return root

    def finish(self):
        if self.active or self.curves!=self.expected:
            raise ValueError('Incomplete original curve replay')
        d = self.take('FOOTER')
        if set(d)!=set(('kind','complete','curves','sign_calls','exact_calls','integer_guard_operations','maximum_reserved_integer_workspace_bits')) or not d['complete'] or d['curves']!=self.expected or d['sign_calls']!=self.calls or d['exact_calls']!=self.exact_calls:
            raise ValueError('Incomplete sign-proof census')
        if type(d['integer_guard_operations']) is not int or d['integer_guard_operations']<0 or type(d['maximum_reserved_integer_workspace_bits']) is not int or not 0<=d['maximum_reserved_integer_workspace_bits']<=self.caps['integer_bit_cap']:
            raise ValueError('Invalid producer resource accounting')
        if self.handle.read(1):
            raise ValueError('Unconsumed events after complete proof')
        self.handle.close()
        return dict(status='PASS',qualification=QUALIFICATION,curves=len(self.curves),sign_calls=self.calls,
                    exact_calls=self.exact_calls,every_census_sign_replayed=True,
                    independent_prefix_suffix_verification=True,producer_terms_trusted=False,
                    verifier_maximum_reserved_integer_workspace_bits=self.guard.maximum_predicted_bits)
