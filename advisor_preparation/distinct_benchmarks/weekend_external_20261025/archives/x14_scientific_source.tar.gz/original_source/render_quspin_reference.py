#!/usr/bin/env python3
"""Independent SciPy Cauchy renderer/root census of retained QuSpin poles."""
import argparse,hashlib,math,time,warnings
from pathlib import Path
from runtime_contract import verify_execution_context
verify_execution_context('production')
import numpy as np
from scipy.stats import cauchy
from scipy.integrate import quad,IntegrationWarning
from scipy.optimize import brentq
from io_contract import contract,spectra,write,sha,HERE,read
from proof_stream import ProofWriter,curve_identity
from runtime_contract import proof_caps

def scalar(x,e,w,eta):return math.fsum(float(q)*eta/(math.pi*((x-float(p))**2+eta**2)) for p,q in zip(e,w))
def derivative(x,e,w,eta):return math.fsum(-2*eta*float(q)*(x-float(p))/(math.pi*((x-float(p))**2+eta**2)**2) for p,q in zip(e,w))
def second(x,e,w,eta):return math.fsum(-2*eta*float(q)*(eta**2-3*(x-float(p))**2)/(math.pi*((x-float(p))**2+eta**2)**3) for p,q in zip(e,w))
def interval_bounds(a,b,e,w,eta,order,padding):
 lo=[];hi=[]
 for p,q in zip(e,w):
  l,r=a-p,b-p;points=[l,r];critical=[-eta/math.sqrt(3),eta/math.sqrt(3)] if order==1 else [-eta,0.,eta]
  points += [t for t in critical if l<=t<=r]
  if order==1:values=[-2*eta*q*t/(math.pi*(t*t+eta*eta)**2) for t in points]
  else:values=[-2*eta*q*(eta*eta-3*t*t)/(math.pi*(t*t+eta*eta)**3) for t in points]
  lo.append(min(values));hi.append(max(values))
 eps=padding*sum(w)/eta**(order+1)
 return math.fsum(lo)-eps,math.fsum(hi)+eps

def derivative_sign(x,e,w,eta,c,proof):
    return proof.sign(x,e,w,eta,c,interval_bounds)

def enclosed_root(a,b,e,w,eta,c,proof):
    """Keep genuinely opposite padded-or-independently-exact endpoint signs."""
    n=c['numerics'];parent=[a,b];cl,ch=interval_bounds(a,b,e,w,eta,2,n['stationary_binary64_padding'])
    if not(cl>0 or ch<0):raise ValueError('No padded monotone derivative neighborhood')
    sa,ea=derivative_sign(a,e,w,eta,c,proof);sb,eb=derivative_sign(b,e,w,eta,c,proof)
    if not sa or sb!=-sa:raise ValueError('No opposite padded endpoint signs')
    for _ in range(180):
        if b-a<=n['stationary_bracket_width_max']:break
        original=(a,b);lefts=[a];rights=[b]
        # Unknown midpoint signs never fabricate a bracket. Quarter points
        # can prove a smaller neighborhood around an exact symmetry root.
        for fraction in (0.25,0.5,0.75):
            x=original[0]+fraction*(original[1]-original[0])
            if not original[0]<x<original[1]:raise ValueError('Binary64 root refinement cannot progress')
            sign,_=derivative_sign(x,e,w,eta,c,proof)
            if sign==sa:lefts.append(x)
            elif sign==sb:rights.append(x)
        a,b=max(lefts),min(rights)
        if (a,b)==original or not a<b:raise ValueError('Endpoint padding prevents required root precision')
        sleft,_=derivative_sign(a,e,w,eta,c,proof);sright,_=derivative_sign(b,e,w,eta,c,proof)
        if (sleft,sright)!=(sa,sb):raise ValueError('Endpoint enclosure signs lost during refinement')
    if b-a>n['stationary_bracket_width_max']:raise ValueError('Padded root bracket unresolved')
    sa,ea=derivative_sign(a,e,w,eta,c,proof);left_event=proof.last_sign_event
    sb,eb=derivative_sign(b,e,w,eta,c,proof);right_event=proof.last_sign_event
    if not sa or sb!=-sa:raise ValueError('Final padded-or-exact bracket is not sign qualified')
    root=proof.root_point(a,b,lambda:float(brentq(lambda x:derivative(x,e,w,eta),a,b,xtol=n['brent_xtol'],maxiter=200)))
    if not a<=root<=b:raise ValueError('Brent point lies outside retained qualified bracket')
    return dict(location=root,height=scalar(root,e,w,eta),bracket=[a,b],endpoint_derivative_enclosures=[list(ea),list(eb)],endpoint_signs=[sa,sb],endpoint_sign_event_indices=[left_event,right_event],endpoint_qualification="PADDED_BINARY64_OR_INDEPENDENT_EXACT_RATIONAL_POINT_SIGN_V2",curvature=second(root,e,w,eta),monotone_parent=parent,curvature_bounds=[cl,ch],type='maximum' if ch<0 else 'minimum',derivative_abs=abs(derivative(root,e,w,eta)))

def stationary(e,w,eta,c,proof):
    n=c['numerics'];left,right=c['frequency_min'],c['frequency_max'];stack=[(left,right,0)];roots=[];boundary_candidates=[];visited=0;excluded=0
    while stack:
        a,b,depth=stack.pop();visited+=1
        if visited>n['stationary_max_intervals']:raise ValueError('Root census exceeded fixed interval budget')
        lo,hi=interval_bounds(a,b,e,w,eta,1,n['stationary_binary64_padding'])
        if lo>0 or hi<0:excluded+=1;continue
        cl,ch=interval_bounds(a,b,e,w,eta,2,n['stationary_binary64_padding']);sa,_=derivative_sign(a,e,w,eta,c,proof);sb,_=derivative_sign(b,e,w,eta,c,proof)
        if cl>0 or ch<0:
            if sa and sb and sa==sb:excluded+=1;continue
            if sa and sb==-sa:
                roots.append(enclosed_root(a,b,e,w,eta,c,proof));continue
        if b-a<=n['stationary_bracket_width_max']:
            boundary_candidates.append([a,b]);continue
        if depth>=n['stationary_max_depth']:raise ValueError('Root census depth exhausted with unresolved coverage')
        middle=(a+b)/2
        if not a<middle<b:raise ValueError('Binary64 census subdivision cannot progress')
        stack.extend([(a,middle,depth+1),(middle,b,depth+1)])
    # A root on a dyadic split boundary makes each neighboring endpoint sign
    # uncertain. Join ONLY actually touching/overlapping unresolved cells,
    # then require definite outer signs and padded monotonicity for the union.
    boundary_candidates.sort();neighborhoods=[]
    for a,b in boundary_candidates:
        if neighborhoods and a<=neighborhoods[-1][1]:neighborhoods[-1][1]=max(b,neighborhoods[-1][1])
        else:neighborhoods.append([a,b])
    for a,b in neighborhoods:roots.append(enclosed_root(a,b,e,w,eta,c,proof))
    roots.sort(key=lambda r:r['bracket'][0]);dedup=[]
    for r in roots:
        if dedup and r['bracket'][0]<=dedup[-1]['bracket'][1]:
            old=dedup.pop()
            if old['type']!=r['type']:raise ValueError('Overlapping root classifications disagree')
            merged=enclosed_root(min(old['bracket'][0],r['bracket'][0]),max(old['bracket'][1],r['bracket'][1]),e,w,eta,c,proof)
            if merged['type']!=r['type']:raise ValueError('Merged qualified neighborhood changes root type')
            dedup.append(merged)
        else:dedup.append(r)
    return dedup,visited,excluded

def render(s,eta,c,proof):
 e=np.array([g['omega'] for g in s['groups']],float);w=np.array([g['weight'] for g in s['groups']],float);a,b=c['frequency_min'],c['frequency_max'];W=float(math.fsum(w));x=np.linspace(a,b,c['mesh_points'])
 if min(w)<0 or not a<min(e)<=max(e)<b or W<=c['gates']['minimum_total_branch_weight']:raise ValueError('Invalid positive interior spectral measure')
 # Actual independent distribution-library PDF/CDF, not the native kernel.
 y=np.asarray(cauchy.pdf(x[:,None],loc=e[None,:],scale=eta))@w
 cdf=float(np.dot(cauchy.cdf(b,loc=e,scale=eta)-cauchy.cdf(a,loc=e,scale=eta),w));outside=float(np.dot(cauchy.cdf(a,loc=e,scale=eta)+cauchy.sf(b,loc=e,scale=eta),w))
 with warnings.catch_warnings():
  warnings.simplefilter('error',IntegrationWarning)
  mass,error=quad(lambda z:scalar(z,e,w,eta),a,b,points=sorted(set(e)),epsabs=c['numerics']['quadrature_epsabs'],epsrel=c['numerics']['quadrature_epsrel'],limit=c['numerics']['quadrature_limit'])
 proof.begin_curve(s,eta)
 roots,visited,excluded=stationary(e,w,eta,c,proof);proof.end_curve(roots,visited,excluded);probe=np.linspace(0,len(x)-1,257,dtype=int);peaks=[r for r in roots if r['type']=='maximum']
 if not peaks:raise ValueError('No certified interior maximum')
 return dict(id=s['id'],role=s['role'],branch=s['branch'],expected_total_weight=s.get('expected_total_weight',0.37 if s['id']=='control_rescaled' else 1.),eta=eta,poles=e.tolist(),weights=w.tolist(),groups=s['groups'],full_weight=W,probe_indices=probe.tolist(),probe_values=y[probe].tolist(),full_mesh_binary64_sha256=hashlib.sha256(np.asarray(y,dtype='<f8').tobytes()).hexdigest(),peaks=peaks,all_stationary_points=roots,root_census_intervals=visited,root_excluded_intervals=excluded,root_census_complete=True,proof_curve_fingerprint=curve_identity(s,eta),endpoint_qualification='PADDED_BINARY64_OR_INDEPENDENT_EXACT_RATIONAL_POINT_SIGN_V2',finite_window_library_cdf_mass=cdf,finite_window_quadrature_mass=float(mass),quadrature_error_estimate=float(error),outside_window_mass=outside,cluster_render_error_bound=math.fsum(g['weight']*g['span'] for g in s['groups'])/(math.pi*eta**2))

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['production']);p.add_argument('output',type=Path);p.add_argument('--proof',required=True,type=Path);a=p.parse_args();c=contract(a.mode);start=time.time();rows=[]
 expected=[curve_identity(s,eta) for s in spectra('quspin',a.mode,c) for eta in c['etas']]
 proof=ProofWriter(a.proof,proof_caps(),sha(HERE/'source_freeze.json'),expected)
 try:
  for s in spectra('quspin',a.mode,c):
   for eta in c['etas']:rows.append(render(s,eta,c,proof))
  summary=proof.finish()
 except BaseException:
  if not proof.handle.closed:proof.abort()
  raise
 write(a.output,dict(schema='X14_RENDERED_RAW_V1',implementation_schema='X14_EXACT_SIGN_RENDERER_V2',backend='retained_QuSpin_Lehmann_new_independent_SciPy_renderer',mode=a.mode,scientific_completions=0,source_freeze_sha256=sha(HERE/'source_freeze.json'),prior_input_manifest_sha256=sha(HERE/'prior_inputs.json'),renderer_sha256=sha(__file__),reference_library_pins_sha256=sha(HERE/'reference_library_pins.json'),reference_library_sha256=read(HERE/'reference_library_pins.json')['files'],exact_runtime_pins_sha256=sha(HERE/'exact_runtime_pins.json'),complete_sign_proof=summary,rows=rows,elapsed_seconds=time.time()-start,new_QuSpin_solve=False,producer_or_sampler_executed=False))
if __name__=='__main__':main()
