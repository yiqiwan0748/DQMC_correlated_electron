"""Metadata/source/provider guards. This module performs no fixture math."""
import hashlib,importlib,importlib.metadata,importlib.util,json,os,platform,re,subprocess,sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
_VERIFIED = None


def read(p):
    return json.loads(Path(p).read_text())


def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):
            h.update(block)
    return h.hexdigest()


def proof_caps():
    caps=read(HERE/'implementation_manifest.json')['caps']
    expected=dict(integer_bit_cap=65536,sign_call_cap_total=200000,
                  exact_fallback_call_cap_total=200000,proof_ledger_byte_cap=268435456,
                  maximum_event_bytes=1048576)
    if caps!=expected:
        raise ValueError('Unreviewed change to predeclared proof resource caps')
    return caps


def metadata_preflight():
    global _VERIFIED
    if _VERIFIED is not None:
        return _VERIFIED
    p=read(HERE/'exact_runtime_pins.json')
    if p['schema']!='X14_EXACT_SIGN_CPYTHON_FRACTION_RUNTIME_METADATA_V2' or platform.python_version()!=p['python_version'] or platform.python_implementation()!=p['implementation'] or sys.version!=p['version_text']:
        raise ValueError('Unpinned actual CPython/Fraction implementation')
    if Path(sys.executable).resolve()!=Path(p['paths']['Python_executable']).resolve():
        raise ValueError('Actual interpreter executable differs')
    observed={}
    for role,path in p['paths'].items():
        f=Path(path).resolve()
        if not f.is_file() or f.stat().st_size!=p['bytes'][role]:
            raise ValueError('Changed exact-runtime file size '+role)
        observed[role]=sha(f)
        if observed[role]!=p['files'][role]:
            raise ValueError('Changed exact-runtime source/provider '+role)
        if role.startswith('module/'):
            spec=importlib.util.find_spec(role.split('/',1)[1])
            if spec is None or spec.origin is None or Path(spec.origin).resolve()!=f:
                raise ValueError('Imported module search path differs '+role)
    for role in p['ldd_metadata']:
        result=subprocess.run(['ldd',p['paths'][role]],capture_output=True,text=True,check=True)
        found={}
        for line in result.stdout.splitlines():
            if 'not found' in line:
                raise ValueError('Missing runtime loader provider')
            hit=re.search(r'^\s*(\S+)\s+=>\s+(/\S+)',line)
            if hit:
                found['provider/'+hit[1]]=str(Path(hit[2]).resolve())
            else:
                hit=re.search(r'^\s*(/\S+)\s+\(',line)
                if hit:
                    found['provider/'+Path(hit[1]).name]=str(Path(hit[1]).resolve())
        expected={}
        for line in p['ldd_metadata'][role].splitlines():
            hit=re.search(r'^\s*(\S+)\s+=>\s+(/\S+)',line)
            if hit:expected['provider/'+hit[1]]=str(Path(hit[2]).resolve())
            else:
                hit=re.search(r'^\s*(/\S+)\s+\(',line)
                if hit:expected['provider/'+Path(hit[1]).name]=str(Path(hit[1]).resolve())
        if found!=expected or any(k not in p['paths'] or str(Path(p['paths'][k]).resolve())!=v for k,v in found.items()):
            raise ValueError('Actual CPython/math/decimal loader provider differs')
    # Original 30-file NumPy/SciPy map is preserved exactly, checked before
    # any NumPy/SciPy import. io_contract additionally checks actual dispatch.
    lib=read(HERE/'reference_library_pins.json')
    for package,spec in lib['distributions'].items():
        dist=importlib.metadata.distribution(package)
        if dist.version!=spec['version'] or not set(spec['files'])<={str(f) for f in dist.files}:
            raise ValueError('Changed original numerical distribution membership')
        for name in spec['files']:
            f=dist.locate_file(name).resolve()
            if f.stat().st_size!=lib['bytes'][name] or sha(f)!=lib['files'][name]:
                raise ValueError('Changed original critical numerical file '+name)
    # No Fraction operation is performed: bind dispatch to the hashed source.
    import fractions,math,inspect
    if Path(fractions.__file__).resolve()!=Path(p['paths']['module/fractions']).resolve() or not inspect.isbuiltin(math.gcd) or math.gcd.__module__!='math' or Path(math.__file__).resolve()!=Path(p['paths']['module/math']).resolve():
        raise ValueError('Actual Fraction/gcd dispatch mismatch')
    for name in ('__new__','_add','_sub','_mul','_div'):
        func=getattr(fractions.Fraction,name)
        if Path(func.__code__.co_filename).resolve()!=Path(p['paths']['module/fractions']).resolve():
            raise ValueError('Fraction arithmetic method not from pinned source')
    if sys.int_info.bits_per_digit!=30 or sys.int_info.sizeof_digit!=4:
        raise ValueError('Unreviewed CPython bigint digit implementation')
    implementation=read(HERE/'implementation_manifest.json')
    if sha(HERE/'manifest.toml')!=implementation['physical_manifest_sha256'] or sha(HERE/'reference_library_pins.json')!=implementation['original_reference_library_pins_sha256']:
        raise ValueError('Original physical thresholds/grid/library map changed')
    proof_caps()
    _VERIFIED=observed
    return observed


def verify_execution_context(mode):
    metadata_preflight()
    if mode!='production':
        raise ValueError('X14 v3 admits only the separately reviewed full production grid')
    if not os.getenv('SLURM_JOB_ID') or os.getenv('SLURM_CPUS_PER_TASK')!='1' or os.getenv('SLURM_MEM_PER_NODE')!='3500':
        raise ValueError('Separate one-CPU/3500MB compute allocation required')
    for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
        if os.getenv(key)!='1':raise ValueError('Numerical provider threads must equal one')
    freeze=read(HERE/'source_freeze.json')
    if freeze.get('schema')!='X14_EXACT_SIGN_FULL_V3_SOURCE_FREEZE' or freeze.get('qualification')!='PADDED_BINARY64_OR_INDEPENDENT_EXACT_RATIONAL_POINT_SIGN_V2' or freeze.get('mode')!='FULL_ONLY':
        raise ValueError('No matching full implementation source freeze')
    for name,digest in freeze['files'].items():
        path=(HERE/name).resolve()
        if not path.is_relative_to(HERE) or not path.is_file() or path.is_symlink() or sha(path)!=digest:
            raise ValueError('Changed frozen source member '+name)
    approval=Path(os.environ['X14_V3_ROOT_FULL_ADMISSION'])
    if sha(approval)!=os.environ['X14_V3_ROOT_FULL_ADMISSION_SHA256']:
        raise ValueError('Changed full root admission')
    a=read(approval)
    if a.get('schema')!='X14_EXACT_SIGN_V3_ROOT_FULL_ADMISSION' or a.get('status')!='ADMITTED_FOR_ONE_FULL_FIXED_GRID' or a.get('source_freeze_sha256')!=sha(HERE/'source_freeze.json') or a.get('exact_runtime_pins_sha256')!=sha(HERE/'exact_runtime_pins.json') or a.get('independent_pilot_review_sha256')!=sha(HERE/'independent_pilot_review.json'):
        raise ValueError('Missing separate source/runtime/pilot full admission')
    assessment=Path(os.environ['X14_V3_RESOURCE_ASSESSMENT'])
    if sha(assessment)!=a.get('resource_assessment_sha256'):
        raise ValueError('Wrong source-bound resource assessment')
    r=read(assessment);plan=read(HERE/'full_workflow_plan.json')
    if r.get('status')!='ELIGIBLE_FOR_SEPARATE_ROOT_FULL_REVIEW' or r.get('source_freeze_sha256')!=sha(HERE/'source_freeze.json') or r.get('workflow_plan_sha256')!=sha(HERE/'full_workflow_plan.json') or not r.get('all_pilot_scientific_qualifications_pass') or not r.get('old_resource_result_preserved') or not r.get('new_resource_protocol_explicit') or r.get('projected_full_seconds',float('inf'))>plan['max_projected_full_seconds'] or r.get('max_pilot_rss_KiB',float('inf'))>plan['max_pilot_rss_KiB']:
        raise ValueError('Unqualified source-bound full resource admission')
    return a
