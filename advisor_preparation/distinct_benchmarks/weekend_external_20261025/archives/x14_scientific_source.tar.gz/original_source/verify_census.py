"""Full saved-proof census replay, including every exclusion/refinement sign."""
from pathlib import Path
from runtime_contract import verify_execution_context,proof_caps
verify_execution_context('production')
import numpy as np
from io_contract import HERE,sha,spectra
from render_quspin_reference import stationary
from proof_stream import ProofReader,curve_identity,QUALIFICATION


def verify_census(reference,ledger,c):
    expected_specs=[(s,eta) for s in spectra('quspin','production',c) for eta in c['etas']]
    expected=[curve_identity(s,eta) for s,eta in expected_specs]
    if len(expected)!=140 or len(set(expected))!=140 or len(reference['rows'])!=140:
        raise ValueError('Original complete 140-row production grid is not bijective')
    summary=reference['complete_sign_proof']
    if summary['schema']!='X14_PADDED_OR_EXACT_POINT_SIGN_COMPLETE_STREAM_V2' or summary['qualification']!=QUALIFICATION or not summary['complete'] or summary['sha256']!=sha(ledger) or summary['bytes']!=Path(ledger).stat().st_size:
        raise ValueError('Changed or incomplete saved sign-proof ledger')
    proof=ProofReader(ledger,proof_caps(),sha(HERE/'source_freeze.json'),expected)
    for (s,eta),row in zip(expected_specs,reference['rows']):
        if (row['id'],row['eta'],row['role'],row['branch'],row['groups'])!=(s['id'],eta,s['role'],s['branch'],s['groups']):
            raise ValueError('Proof rows not derived bijectively from original backend groups')
        if row['proof_curve_fingerprint']!=curve_identity(s,eta) or row['endpoint_qualification']!=QUALIFICATION or not row['root_census_complete']:
            raise ValueError('Wrong row proof/input qualification')
        e=np.array([v['omega'] for v in s['groups']],float)
        w=np.array([v['weight'] for v in s['groups']],float)
        proof.begin_curve(s,eta)
        roots,visited,excluded=stationary(e,w,eta,c,proof)
        proof.end_curve(roots,visited,excluded)
        if roots!=row['all_stationary_points'] or [r for r in roots if r['type']=='maximum']!=row['peaks'] or visited!=row['root_census_intervals'] or excluded!=row['root_excluded_intervals']:
            raise ValueError('Stored complete stationary census differs from independent sign replay')
    result=proof.finish()
    if any(summary[key]!=result[key] for key in ('curves','sign_calls','exact_calls')):
        raise ValueError('Final complete proof accounting differs')
    return result
