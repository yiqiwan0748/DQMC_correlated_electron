"""Independent rational-sign reconstruction from original binary64 inputs.

No Fraction operations, producer reduced terms or producer summation are
used. Each term is re-derived as an integer pair. Prefix/suffix products
form one common-denominator numerator; every product/sum is preguarded.
"""
from exact_arithmetic import IntegerGuard


def normalize(n, d, g):
    if d <= 0:
        raise ValueError('Positive denominator required')
    common = g.gcd(n, d)
    return g.divexact(n, common), g.divexact(d, common)


def independent_sign(x, poles, weights, eta, recorded_n, recorded_d, guard):
    g = guard
    xn, xd = g.ratio(float(x))
    hn, hd = g.ratio(float(eta))
    if hn <= 0:
        raise ValueError('Positive width required')
    hn2, hd2 = g.mul(hn, hn), g.mul(hd, hd)
    numerators, denominators = [], []
    for pole, weight in zip(poles, weights):
        en, ed = g.ratio(float(pole))
        wn, wd = g.ratio(float(weight))
        # t=(xn*ed-en*xd)/(xd*ed), d=t²+eta². Keep an
        # independently normalized pair after EACH guarded construction.
        tn, td = normalize(g.sub(g.mul(xn, ed), g.mul(en, xd)), g.mul(xd, ed), g)
        tn2, td2 = g.mul(tn, tn), g.mul(td, td)
        dn, dd = normalize(g.add(g.mul(tn2, hd2), g.mul(hn2, td2)), g.mul(td2, hd2), g)
        if dn <= 0:
            raise ValueError('Invalid exact positive denominator')
        # w*t/d²; no Fraction arithmetic or producer per-term input.
        an = g.mul(g.mul(wn, tn), g.mul(dd, dd))
        bd = g.mul(g.mul(wd, td), g.mul(dn, dn))
        an, bd = normalize(an, bd, g)
        numerators.append(an)
        denominators.append(bd)
    # All terms, including zero-weight terms, retain their original slots.
    prefix = [1]
    for d in denominators:
        prefix.append(g.mul(prefix[-1], d))
    suffix = [1]*(len(denominators)+1)
    for j in range(len(denominators)-1, -1, -1):
        suffix[j] = g.mul(denominators[j], suffix[j+1])
    n = 0
    for j, a in enumerate(numerators):
        n = g.add(n, g.mul(a, g.mul(prefix[j], suffix[j+1])))
    d = prefix[-1]
    producer_n, producer_d = g.decode(recorded_n), g.decode(recorded_d)
    if producer_d <= 0 or g.mul(n, producer_d) != g.mul(producer_n, d):
        raise ValueError('Independent common-denominator rational disagrees')
    sign = -1 if n > 0 else 1 if n < 0 else 0
    return sign
