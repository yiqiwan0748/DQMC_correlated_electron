#!/usr/bin/env python3
"""Parse/hash/AST-only preparation; never imports a numerical candidate module."""
import argparse,ast,hashlib,json,subprocess,tarfile
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    if args.output.exists():
        raise ValueError('Refuse overwrite of static receipt')
    checks=[]
    def need(name,condition,**detail):
        checks.append(dict(name=name,passed=bool(condition),**detail))
        if not condition:
            raise ValueError(name)
    def funcs(path):
        return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(path.read_text()).body if isinstance(x,ast.FunctionDef)}
    for f in sorted(HERE.rglob('*.py')):
        ast.parse(f.read_text(),filename=str(f))
        need('AST only '+str(f.relative_to(HERE)),True)
    for f in HERE.glob('*.sbatch'):
        r=subprocess.run(['bash','-n',str(f)],capture_output=True,text=True)
        need('bash syntax only '+f.name,r.returncode==0)
    old,new=funcs(HERE/'original_v1/render_quspin_reference.py'),funcs(HERE/'render_quspin_reference.py')
    for name in ('scalar','derivative','second','interval_bounds'):
        need('original reference numerical AST unchanged '+name,old[name]==new[name],ast_sha256=hashlib.sha256(old[name].encode()).hexdigest())
    old,new=funcs(HERE/'original_v1/render_native.py'),funcs(HERE/'render_native.py')
    for name in ('curve','golden','render'):
        need('original native AST unchanged '+name,old[name]==new[name],ast_sha256=hashlib.sha256(old[name].encode()).hexdigest())
    need('physical manifest exact',sha(HERE/'manifest.toml')==sha(HERE/'original_v1/manifest.toml'))
    need('original 30-file reference map exact',sha(HERE/'reference_library_pins.json')=='b39d5eb29520dcc74dae7118750745deb0595e01d33307979127f31de2d643e9')
    need('no source freeze created',not (HERE/'source_freeze.json').exists())
    need('no full wrapper',not (HERE/'production.sbatch').exists())
    freeze=json.loads((HERE/'original_v1/original_freeze.json').read_text())
    need('original archive exact',sha(HERE/'original_v1/original_source.tar.gz')==freeze['archive_sha256'])
    seen=set()
    with tarfile.open(HERE/'original_v1/original_source.tar.gz','r:gz') as tar:
        for m in tar:
            name=m.name.removeprefix(freeze['prefix'])
            need('original archive regular/unique '+m.name,m.name.startswith(freeze['prefix']) and m.isfile() and name not in seen and name in freeze['files'])
            need('original archive member exact '+name,hashlib.sha256(tar.extractfile(m).read()).hexdigest()==freeze['files'][name])
            seen.add(name)
    need('original full archive membership exact',seen==set(freeze['files']))
    for name in ('render_quspin_reference.py','render_native.py','compare.py','io_contract.py','manifest.toml','run_analysis.py'):
        need('preserved original source exact '+name,sha(HERE/'original_v1'/name)==freeze['files'][name])
    # Compare physical comparator body after undoing ONLY the declared
    # implementation gate and pilot-only mode restriction. No raw evaluation.
    oldtree=ast.parse((HERE/'original_v1/compare.py').read_text())
    newtree=ast.parse((HERE/'compare.py').read_text())
    original=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=='compare')
    candidate=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=='compare')
    candidate.args=original.args
    candidate.body=[n for n in candidate.body if not (isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and n.value.args and isinstance(n.value.args[0],ast.Constant) and n.value.args[0].value=='complete independent census-use sign-proof replay')]
    old_endpoint=next(n for n in ast.walk(original) if isinstance(n,ast.Call) and n.args and any(isinstance(v,ast.Constant) and 'reference final padded opposite signs' in str(v.value) for v in ast.walk(n.args[0])))
    class RestoreNamedGate(ast.NodeTransformer):
        def visit_Call(self,node):
            if node.args and any(isinstance(v,ast.Constant) and 'reference final padded-or-independently-exact opposite signs' in str(v.value) for v in ast.walk(node.args[0])):
                return old_endpoint
            return self.generic_visit(node)
        def visit_Compare(self,node):
            if isinstance(node.left,ast.Name) and node.left.id=='mode' and len(node.ops)==1 and isinstance(node.ops[0],ast.Eq) and len(node.comparators)==1 and isinstance(node.comparators[0],ast.Constant) and node.comparators[0].value=='pilot':
                return ast.Compare(left=node.left,ops=[ast.In()],comparators=[ast.List(elts=[ast.Constant('pilot'),ast.Constant('production')],ctx=ast.Load())])
            return self.generic_visit(node)
    candidate=RestoreNamedGate().visit(candidate)
    need('all comparator physical body AST unchanged except named endpoint qualification and pilot restriction',ast.dump(original,include_attributes=False)==ast.dump(candidate,include_attributes=False))
    report=dict(schema='X14_V2_STATIC_PREPARATION_ONLY',status='PARSE_AND_SOURCE_IDENTITY_ONLY_REQUIRES_INDEPENDENT_REVIEW',
                checks=checks,checks_total=len(checks),checks_failed=sum(not x['passed'] for x in checks),
                numeric_imports_or_Fraction_calls_or_finfo_or_fixture_work=False,source_freeze_created=False,
                jobs_submitted=False,scientific_completions=0,original_archive_sha256=sha(HERE/'original_v1/original_source.tar.gz'),
                exact_runtime_metadata_sha256=sha(HERE/'exact_runtime_pins.json'),
                files={str(f.relative_to(HERE)):dict(sha256=sha(f),bytes=f.stat().st_size) for f in sorted(HERE.rglob('*')) if f.is_file() and f.name not in ('static_preparation.json','PREPARATION_SHA256SUMS')})
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(checks=len(checks),status=report['status'],sha256=sha(args.output))))


if __name__=='__main__':
    main()
