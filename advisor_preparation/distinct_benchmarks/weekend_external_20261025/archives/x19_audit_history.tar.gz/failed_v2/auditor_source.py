#!/usr/bin/env python3
"""Independent postprocessing of saved X19 H/masks; never runs a producer."""
import argparse,datetime,hashlib,importlib,importlib.metadata,importlib.util,inspect,itertools,json,math,os,platform,re,shutil,signal,subprocess,sys,tarfile,time,tomllib,traceback
from fractions import Fraction
from pathlib import Path
ARCHIVE='003633ead8e285634132374b9947eba3bcf596a324585f8494d16c06537cb9ff'
FREEZE='4374afd8266634b635e059ef995f62c420167bfbdf682238458d7e8ae2aaf9cd'
HERE=Path(__file__).resolve().parent
PLAN_SHA256='e654aae1eb90a63a195967a09abafedb7c50df8e572ae627ac16dfb33e45f22b'
PILOT_AUDITOR_SHA256='ac2d9b306e0a8b24ef2a383eecf08c022855d8c69e698a6be4f1d1714f119d69'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return tomllib.loads(p.read_text()) if p.suffix=='.toml' else json.loads(p.read_text())
def hop(s,to,frm):
 if not (s>>frm)&1:return None
 sign=-1 if (s&((1<<frm)-1)).bit_count()%2 else 1;s^=1<<frm
 if (s>>to)&1:return None
 sign*= -1 if (s&((1<<to)-1)).bit_count()%2 else 1
 return s|(1<<to),sign

def quotient(cell,a1,a2):
 D=a1[0]*a2[1]-a1[1]*a2[0];x,y=cell
 return (Fraction(a2[1]*x-a2[0]*y,D)%1,Fraction(-a1[1]*x+a1[0]*y,D)%1)

def exact_torus_K(cells,spec,c,t4,np):
 """Enumerate dual characters by congruences, independent of native wrapping/bond loops."""
 a1,a2=spec['a1'],spec['a2'];D=abs(a1[0]*a2[1]-a1[1]*a2[0]);chars=[(p,q) for p in range(D) for q in range(D) if (a1[0]*p+a1[1]*q)%D==0 and (a2[0]*p+a2[1]*q)%D==0]
 if len(chars)!=4 or len({quotient(r,a1,a2) for r in cells})!=4:raise ValueError('Incomplete four-cell quotient/dual characters')
 K=np.zeros((8,8),complex);fourier={}
 for p,q in chars:
  kx=2*math.pi*p/D;ky=2*math.pi*q/D;H=np.array([[-2*c['t1']*math.cos(kx)-2*c['t2']*math.cos(ky)-4*c['t3']*math.cos(kx)*math.cos(ky),-4*t4*math.sin(kx)*math.sin(ky)],[-4*t4*math.sin(kx)*math.sin(ky),-2*c['t2']*math.cos(kx)-2*c['t1']*math.cos(ky)-4*c['t3']*math.cos(kx)*math.cos(ky)]])
  fourier[p,q]=H
  for i,r in enumerate(cells):
   for j,s in enumerate(cells):K[2*i:2*i+2,2*j:2*j+2]+=complex(math.cos(kx*(r[0]-s[0])+ky*(r[1]-s[1])),math.sin(kx*(r[0]-s[0])+ky*(r[1]-s[1])))*H/4
 return K,fourier,D

def unpack(coo,np):
 d=tuple(coo['shape']);out=np.zeros(d);ij=list(zip(coo['row'],coo['col']))
 if len(ij)!=len(set(ij)) or len(ij)!=len(coo['value']):raise ValueError('Duplicate/missing COO entries')
 for (i,j),v in zip(ij,coo['value']):out[i,j]=v
 return out

def independent_H(K,U,block,np):
 labels=list(zip(block['basis_up_per_row'],block['basis_down_per_row']));states=[u|(d<<8) for u,d in labels];lookup={s:i for i,s in enumerate(states)};dim=len(states)
 if len(lookup)!=dim or any(u.bit_count()!=block['Nup'] or d.bit_count()!=block['Ndown'] for u,d in labels):raise ValueError('Invalid physical fixed-sector labels')
 H=np.zeros((dim,dim))
 for col,(u,d) in enumerate(labels):
  H[col,col]=U*((u&d).bit_count()-(block['Nup']+block['Ndown'])/2+2)
  for spin in range(2):
   for i in range(8):
    for j in range(8):
     if K[i,j]:
      step=hop(states[col],i+8*spin,j+8*spin)
      if step is not None:H[lookup[step[0]],col]+=K[i,j]*step[1]
 return H,states,labels

def thermal_observers(blocks,beta,np,csr_matrix):
 """Full canonical trace from freshly diagonalized SAVED matrices and independent Fock actions."""
 emin=min(b['E'][0] for b in blocks);parts=[np.exp(-beta*(b['E']-emin)) for b in blocks];Z=sum(float(w.sum()) for w in parts);density=np.zeros(8);zm=np.zeros(8);nn=np.zeros((8,8));zz=nn.copy();sd=nn.copy();cup=nn.copy();cdn=nn.copy();energy=0.;transfer=0.;commmax=0.;prob=[]
 for b,w0 in zip(blocks,parts):
  w=w0/Z;rho=(b['V']*w)@b['V'].T;diagonal=np.diag(rho);states=b['states'];labels=b['labels'];lookup={s:i for i,s in enumerate(states)};up=np.array([[(u>>i)&1 for u,d in labels] for i in range(8)],float);dn=np.array([[(d>>i)&1 for u,d in labels] for i in range(8)],float);n=up+dn;z=(up-dn)/2;density+=n@diagonal;zm+=z@diagonal;nn+=(n*diagonal)@n.T;zz+=(z*diagonal)@z.T;sd+=(z*diagonal)@z.T
  for col,s in enumerate(states):
   for i in range(8):
    for j in range(8):
     for offset,C in [(0,cup),(8,cdn)]:
      step=hop(s,i+offset,j+offset)
      if step is not None:C[i,j]+=step[1]*rho[col,lookup[step[0]]]
     for a,b0,c,d in [(j+8,j,i,i+8),(j,j+8,i+8,i)]:
      first=hop(s,a,b0)
      if first is None:continue
      second=hop(first[0],c,d)
      if second is not None:sd[i,j]+=.5*first[1]*second[1]*rho[col,lookup[second[0]]]
  NA=np.array([sum(((u>>i)&1)+((d>>i)&1) for i in [0,2,4,6]) for u,d in labels]);C=csr_matrix(b['H']*(NA[None,:]-NA[:,None]));commmax=max(commmax,max(abs(C.data),default=0.));transfer+=float(C.multiply(C@rho).sum())/4;energy+=float(w@b['E']);prob.append(float(w.sum()))
 nn-=np.outer(density,density);zz-=np.outer(zm,zm);sd-=np.outer(zm,zm);A=[0,2,4,6];B=[1,3,5,7]
 return dict(normalization=sum(prob),logZ=math.log(Z)-beta*emin,energy=energy,density=density,Sz=zm,onebody_up=cup,onebody_down=cdn,Cnn=nn,Czz=zz,Sdot_connected=sd,cross_Cnn=nn[np.ix_(A,B)],cross_Sdot=sd[np.ix_(A,B)],orbital_coherence_per_cell=float((np.sum(cup[np.ix_(A,B)]**2)+np.sum(cdn[np.ix_(A,B)]**2))/4),orbital_transfer_second_moment_per_cell=transfer,orbital_number_commutator_maxabs=commmax),prob

def replay_equal_only_gate_value(old,new,path=(),differences=None):
 """Portability policy: exact everything except float numeric gates[].value leaves."""
 if differences is None:differences=[]
 if type(old) is not type(new):raise ValueError('Replay type changed at '+repr(path))
 if isinstance(old,dict):
  if old.keys()!=new.keys():raise ValueError('Replay schema changed at '+repr(path))
  for k in old:replay_equal_only_gate_value(old[k],new[k],path+(k,),differences)
 elif isinstance(old,list):
  if len(old)!=len(new):raise ValueError('Replay array length changed at '+repr(path))
  for i,(x,y) in enumerate(zip(old,new)):replay_equal_only_gate_value(x,y,path+(i,),differences)
 elif isinstance(old,float) and len(path)>=3 and path[-3]=='gates' and type(path[-2]) is int and path[-1]=='value':
  tolerance=max(1e-12,64*sys.float_info.epsilon*max(1.,abs(old),abs(new)))
  if not math.isfinite(old) or not math.isfinite(new) or abs(old-new)>tolerance:raise ValueError('Replay arithmetic exceeds declared portability bound at '+repr(path))
  if old!=new:differences.append(dict(path=list(path),original=old,replay=new,absolute_difference=abs(old-new),allowed_roundoff=tolerance))
 elif old!=new:raise ValueError('Replay identity/bound/decision/raw value changed at '+repr(path))
 return differences


def geometry_key(cell,spec):return tuple(cell) if spec['kind']=='open' else quotient(cell,spec['a1'],spec['a2'])
def mode_map(left,right,spec):
 lookup={geometry_key(v,spec):i for i,v in enumerate(right)}
 if len(left)!=4 or len(right)!=4 or len(lookup)!=4 or len({geometry_key(v,spec) for v in left})!=4 or set(lookup)!={geometry_key(v,spec) for v in left}:raise ValueError('Physical geometry/cell quotient is not bijective')
 return [2*lookup[geometry_key(v,spec)]+orb for v in left for orb in range(2)]
def open_edges_K(cells,c,t4,np):
 """Physical displacement rules, without native/source bond helpers or wrap calls."""
 if {tuple(v) for v in cells}!={(x,y) for x in range(2) for y in range(2)}:raise ValueError('Incomplete open square cells')
 K=np.zeros((8,8))
 for i,(x,y) in enumerate(cells):
  for j,(xx,yy) in enumerate(cells):
   dx,dy=xx-x,yy-y
   for orb in range(2):
    if abs(dx)==1 and dy==0:K[2*i+orb,2*j+orb]=-c['t1' if orb==0 else 't2']
    elif dx==0 and abs(dy)==1:K[2*i+orb,2*j+orb]=-c['t2' if orb==0 else 't1']
    elif abs(dx)==abs(dy)==1:K[2*i+orb,2*j+orb]=-c['t3']
   if abs(dx)==abs(dy)==1:
    K[2*i,2*j+1]=K[2*i+1,2*j]=t4 if dx*dy>0 else -t4
 return K

def verify_metadata(args,plan,need,bind):
 raw=args.raw;source=raw/'source';data=raw/'results';fr=load(raw/'release_freeze.json');need(bind(raw/'release_freeze.json')==FREEZE and bind(args.archive)==ARCHIVE==fr['archive_sha256'],'Exact frozen full source/archive')
 seen=set();prefix=fr['prefix'].rstrip('/')+'/'
 with tarfile.open(args.archive,'r:gz') as tf:
  for m in tf:
   need(m.isfile() and not m.issym() and not m.islnk() and m.name.startswith(prefix) and '..' not in Path(m.name).parts,'Safe full source member');name=m.name[len(prefix):];need(name not in seen and name in fr['files'],'Unique registered full source member');seen.add(name);need(hashlib.sha256(tf.extractfile(m).read()).hexdigest()==fr['files'][name]==bind(source/name),'Exact full source byte '+name)
 need(len(seen)==plan['source_members'] and seen==set(fr['files']),'All29full source members');need(bind(source/'source_freeze.json')==FREEZE,'Exact source-local full freeze');cfg=load(source/'manifest.toml');sourcehash={name:digest for digest,name in (line.split('  ',1) for line in (source/'SHA256SUMS').read_text().splitlines())};need(set(sourcehash)==set(fr['files'])-{'SHA256SUMS'} and all(sourcehash[n]==fr['files'][n] for n in sourcehash),'Full28substantive source map')
 before=load(raw/'transfer_before.json');after=load(raw/'transfer_after.json');bind(raw/'transfer_before.json');bind(raw/'transfer_after.json');bm={r['local']:r for r in before['files']};am={r['local']:r for r in after['files']};need(before['job_id']==after['job_id']==args.expected_job_id and after['status']=='PASS' and len(bm)==len(before['files']) and len(am)==len(after['files']) and set(bm)==set(am),'Original job/stable complete transfer')
 for name,row in bm.items():
  path=raw/name;need(not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name and ':' not in name and path.is_file() and not path.is_symlink(),'Safe transferred original '+name);z=am[name];need(bind(path)==row['sha256']==z['sha256'] and path.stat().st_size==row['bytes']==z['bytes'],'Original transferred scientific bytes '+name)
  stamp=row.get('after_read',row.get('before',{}));need(all(z.get(k)==stamp.get(k) for k in ['inode','mtime_ns']),'Remote file retained unchanged '+name)
 pins=load(source/'reference_library_pins.json');need(sha(source/'reference_library_pins.json')==plan['reference_pins_sha256'] and len(pins['files'])==72,'Exact original72reference pins');locations={}
 for name,spec in pins['distributions'].items():
  dist=importlib.metadata.distribution(name);need(dist.version==spec['version'],'Actual installed distribution '+name)
  for member in spec['files']:
   path=dist.locate_file(member).resolve();need(path.stat().st_size==pins['bytes'][member] and sha(path)==pins['files'][member],'Actual installed72file '+member);locations[member]=path
 for name,digest in pins['files'].items():
  key='reference/'+name;b=before['runtime_files'][key];z=after['runtime_files'][key];need(b['sha256']==z['sha256']==digest and b['bytes']==z['bytes']==pins['bytes'][name] and b['inode']==z['inode'] and b['mtime_ns']==z['mtime_ns'],'Original72actual runtime metadata '+name)
 accounting_path=raw/args.accounting_name;bind(accounting_path);rows=[line.split('|') for line in accounting_path.read_text().splitlines() if line.strip()];job=[r for r in rows if r[0]==args.expected_job_id]
 need(len(job)==1 and len(job[0])==11 and job[0][2:6]==['COMPLETED','0:0','1','3500M'] and job[0][10]=='01:30:00','Original ownjob complete1CPU3500MB90min')
 ex=load(data/'execution.json');bind(data/'execution.json');need(ex['schema']=='X19_PARENT_ADMITTED_FULL_EXECUTION_V2' and ex['status']=='PROCESSES_COMPLETE' and ex['mode']=='full' and ex['job_id']==args.expected_job_id and ex['source_freeze_sha256']==FREEZE and ex['source_sha256']==sourcehash and ex['scientific_completions']==0 and ex['cpus']==1 and ex['memory_MB']==3500 and ex['allocation_minutes']==90 and ex['combined_cap_seconds']==5100,'Original full scientific execution closure')
 need([p['name'] for p in ex['processes']]==['target','reference','comparator'] and all(p['exit_code']==0 and not p['timed_out'] and 0<p['elapsed_seconds']<=p['cap_seconds'] for p in ex['processes']) and all((data/n).is_file() for n in ['target.toml','reference.json','comparison.json']),'All three original complete full roles before imports')
 for name,row in ex['outputs'].items():need(bind(data/name)==row['sha256'] and (data/name).stat().st_size==row['bytes'],'Original execution output '+name)
 return source,data,cfg,sourcehash,pins,locations,ex

def qualify_analysis_runtime(raw,original_locations,need,bind):
 """Current-analysis supplement only; original72 pins/checks remain untouched."""
 complete_path=HERE/'reference_distribution_pins.json';provider_path=HERE/'certificate_system_provider_pins.json';complete=load(complete_path);providers=load(provider_path);plan=load(HERE/'plan.json');supp=plan['current_analysis_runtime_supplement']
 need(bind(complete_path)==supp['reference_distribution_pins_sha256'] and bind(provider_path)==supp['system_provider_pins_sha256'],'Exact separate current-analysis supplemental pin inventories')
 need(complete['python_version']==providers['python_version']==platform.python_version()=='3.11.11' and len(complete['files'])==1598,'Current-analysis actual3.11 supplement size')
 locations=dict(original_locations);expected={};observed={};site=Path(importlib.metadata.distribution('numpy').locate_file('')).resolve()
 for name,spec in complete['distributions'].items():
  dist=importlib.metadata.distribution(name);members=sorted(str(p) for p in dist.files if str(p).endswith('.py') or '.so' in p.name or p.name=='RECORD')
  need(dist.version==spec['version'] and members==spec['files'],'Current-analysis complete installed membership '+name)
  for member in spec['files']:
   path=dist.locate_file(member).resolve();need(path.is_relative_to(site) and path.is_file() and path.stat().st_size==complete['bytes'][member] and sha(path)==complete['files'][member],'Current-analysis supplemental installed bytes '+member)
   need(member not in locations or locations[member]==path,'Consistent separate analysis/original location '+member);locations[member]=path;expected[str(path)]=complete['files'][member];observed[str(path)]=dict(sha256=sha(path),bytes=path.stat().st_size,role='CURRENT_ANALYSIS_SUPPLEMENT_NOT_ORIGINAL_PRODUCER_PIN')
 for name,spec in providers['providers'].items():
  path=Path(spec['realpath']);need(path.is_file() and str(path.resolve())==spec['realpath'] and path.stat().st_size==spec['bytes'] and sha(path)==spec['sha256'],'Current-analysis system/provider bytes '+name);expected[str(path)]=spec['sha256'];observed[str(path)]=dict(sha256=sha(path),bytes=path.stat().st_size,role='CURRENT_ANALYSIS_EXISTING_SYSTEM_PROVIDER_INVENTORY')
 original_runtime=load(raw/'transfer_before.json')['runtime_files'];python=original_runtime['Python_executable'];actual=Path(sys.executable).resolve();need(str(actual)==python['path'] and actual.stat().st_size==python['bytes'] and sha(actual)==python['sha256'],'Current-analysis Python executable equals retained observed executable')
 return dict(locations=locations,expected=expected,before=observed,providers=providers['providers'],site=str(site),supplement_sha256=supp['reference_distribution_pins_sha256'],provider_inventory_sha256=supp['system_provider_pins_sha256'],scope='Only the later saved-data analysis is newly qualified; original72 reference pins remain separately checked and unchanged.')

def loaded_analysis_runtime(contract,need,stage,eigh,csr_matrix):
 locations=contract['locations'];pinned={str(p):sha(p) for p in locations.values()};mapped={str(Path(line.split()[-1]).resolve()) for line in Path('/proc/self/maps').read_text().splitlines() if line.split()[-1].startswith('/')};active={}
 for name,spec in contract['providers'].items():need(spec['realpath'] in mapped,stage+'/expected actual loaded system/provider '+name)
 openblas=[str(p) for name,p in locations.items() if '.libs/' in name and 'openblas' in name and '.so' in name];need(len(openblas)==2 and all(p in mapped for p in openblas),stage+'/both pinned NumPy and SciPy OpenBLAS providers actually loaded')
 for path in sorted(mapped):
  p=Path(path)
  if p.is_relative_to(contract['site']) and '.so' in p.name and p.relative_to(contract['site']).parts[0].split('.')[0] in ['numpy','scipy','quspin','quspin_extensions']:
   need(path in pinned and sha(p)==pinned[path],stage+'/actual package native provider pinned '+path);active[path]=pinned[path]
 modules={}
 for name,module in sorted(sys.modules.items()):
  if name.split('.')[0] not in ['numpy','scipy','quspin','quspin_extensions']:continue
  origin=getattr(module,'__file__',None)
  if not origin:continue
  p=Path(origin).resolve()
  if p.suffix=='.pyc':p=Path(importlib.util.source_from_cache(str(p))).resolve()
  need(str(p) in pinned and sha(p)==pinned[str(p)],stage+'/actual imported numerical API/native module pinned '+name);modules[name]=dict(path=str(p),sha256=pinned[str(p)])
 api={};chain=[];function=eigh;seen=set()
 while True:
  need(id(function) not in seen and len(chain)<16,stage+'/finite acyclic actual eigh wrapper chain');seen.add(id(function));path=inspect.getsourcefile(function);need(path is not None and str(Path(path).resolve()) in pinned,stage+'/actual eigh wrapper/core pinned source');path=Path(path).resolve();chain.append(dict(module=function.__module__,qualified_name=function.__qualname__,source=str(path),sha256=pinned[str(path)]))
  if not hasattr(function,'__wrapped__'):break
  function=function.__wrapped__
 need(len(chain)>=2 and chain[0]['source']==str(locations['scipy/_lib/_util.py']) and chain[-1]['source']==str(locations['scipy/linalg/_decomp.py']) and function is inspect.unwrap(eigh) and function.__name__=='eigh' and function.__module__=='scipy.linalg._decomp',stage+'/actual exposed eigh decorator and unwrapped core dispatch')
 api['eigh']=dict(wrapper_chain=chain,core_source='scipy/linalg/_decomp.py',exposed_source='scipy/_lib/_util.py',all_levels_pinned=True)
 path=inspect.getsourcefile(csr_matrix);need(path is not None and Path(path).resolve()==locations['scipy/sparse/_csr.py'],stage+'/actual used CSR class dispatch');api['csr_matrix']=dict(module=csr_matrix.__module__,source='scipy/sparse/_csr.py',sha256=pinned[str(locations['scipy/sparse/_csr.py'])])
 return dict(loaded_package_providers=active,used_imported_modules=modules,actual_API_dispatch=api,both_pinned_OpenBLAS_loaded=True,scope='Actual current analysis API/provider identity, not retrospective producer qualification.')

def actual_imports(locations,need):
 import numpy as np
 from scipy.linalg import eigh
 from scipy.sparse import csr_matrix
 import scipy
 need(Path(np.__file__).resolve()==locations['numpy/__init__.py'] and Path(scipy.__file__).resolve()==locations['scipy/__init__.py'],'Actual current-analysis NumPy/SciPy import paths are pinned')
 for module in ['numpy._core._multiarray_umath','scipy.linalg._fblas','scipy.linalg._flapack']:
  path=Path(importlib.import_module(module).__file__).resolve();need(path in locations.values(),'Actual current-analysis imported native module pinned '+module)
 need(Path(inspect.getsourcefile(eigh)).resolve() in locations.values(),'Actual SciPy saved-matrix eigh API pinned')
 return np,eigh,csr_matrix

def one_case(case,spec,c,backend,np,eigh,csr_matrix,need,close):
 lim=c['gates'];tag=backend+'/'+case['id']
 if spec['kind']=='open':expected=open_edges_K(case['cells'],c,case['t4'],np);need(case['fourier']==[],'Open cluster has no Fourier surrogate '+tag)
 else:
  expected,fourier,D=exact_torus_K(case['cells'],spec,c,case['t4'],np);need(np.max(abs(expected.imag))<=lim['hamiltonian_abs'],'Independent dual K imaginary '+tag);expected=expected.real;have={}
  need(len(case['fourier'])==4,'All four saved momentum blocks '+tag)
  for row in case['fourier']:
   ints=tuple(round(float(k)*D/(2*math.pi))%D for k in row['k']);need(ints not in have and ints in fourier,'Unique dual momentum '+tag);have[ints]=1;close(row['Hk'],fourier[ints],lim['hamiltonian_abs'],'Independent dual Bloch '+tag+'/'+str(ints))
   if backend=='native':need(0<=row['maximum_imaginary_component']<=lim['hamiltonian_abs'],'Actual native Fourier imaginary eligibility '+tag+'/'+str(ints))
  need(set(have)==set(fourier),'Complete dual character set '+tag)
 close(case['K'],expected,lim['hamiltonian_abs'],'Independent complete K '+tag);K=np.asarray(case['K'],float);es,V=eigh(K);clusters=[];i=0
 while i<8:
  j=i+1
  while j<8 and es[j]-es[i]<=lim['onebody_cluster_diameter']:j+=1
  clusters.append(dict(rank=j-i,energy=float(es[i:j].mean()),P=V[:,i:j]@V[:,i:j].T));i=j
 need(len(clusters)==len(case['onebody_spectral_clusters']),'Complete shell census '+tag)
 for k,(own,saved) in enumerate(zip(clusters,case['onebody_spectral_clusters'])):
  need(saved['rank']==own['rank'],'Whole shell rank '+tag+'/'+str(k));close(saved['energy'],own['energy'],lim['eigenenergy_abs'],'Whole shell energy '+tag+'/'+str(k));close(saved['projector'],own['P'],lim['spectral_projector_abs'],'Whole shell projector '+tag+'/'+str(k));weight=float(np.sum(own['P'][np.ix_(c['orbital_A_zero_based'],c['orbital_B_zero_based'])]**2)/4);close(saved['mixing_weight_per_cell'],weight,lim['spectral_mixing_weight_abs'],'Whole shell orbital measure '+tag+'/'+str(k))
 need(len(case['sectors'])==5 and [[s['Nup'],s['Ndown']] for s in case['sectors']]==c['spin_sectors'],'All five canonical sectors '+tag);blocks=[]
 for block,dim in zip(case['sectors'],c['sector_dimensions']):
  st=tag+f"/{block['Nup']}/{block['Ndown']}";coo=block['H'];need(coo['shape']==[dim,dim] and len(coo['row'])==len(coo['col'])==len(coo['value']) and all(type(i) is int and 0<=i<dim for i in coo['row']+coo['col']) and all(math.isfinite(v) for v in coo['value']),'Complete finite COO domain '+st);need(len(block['basis_up_per_row'])==len(block['basis_down_per_row'])==dim and all(type(u) is int and 0<=u<256 for u in block['basis_up_per_row']+block['basis_down_per_row']),'Complete physical mask domain '+st);H=unpack(block['H'],np);own,states,labels=independent_H(expected,case['U'],block,np);need(H.shape==(dim,dim) and block['dimension']==dim,'Complete sector shape '+st);close(H,own,lim['hamiltonian_abs'],'Independent physical Fock H '+st);close(H,H.T,lim['hamiltonian_abs'],'Saved Hermiticity '+st);E,W=eigh(H);close(block['energies'],E,lim['eigenenergy_abs'],'Complete saved-H eigenspectrum '+st);scale=max(1.,np.linalg.norm(H,np.inf));close(block['operator_scale'],scale,1e-10,'Saved operator scale '+st);need(0<=block['eigen_residual_scaled']<=lim['eigen_residual_scaled'] and 0<=block['orthogonality_abs']<=lim['orthogonality_abs'],'Original eigensystem eligibility '+st);need(np.max(np.linalg.norm(H@W-W*E,axis=0))/scale<=lim['eigen_residual_scaled'] and np.max(abs(W.T@W-np.eye(dim)))<=lim['orthogonality_abs'],'Fresh SAVED-matrix decomposition eligibility '+st);blocks.append(dict(H=H,E=E,V=W,states=states,labels=labels))
 ownobs,prob=thermal_observers(blocks,c['beta'],np,csr_matrix)
 for name,value in ownobs.items():close(case['observables'][name],value,lim['thermal_observable_abs'],'Independent physical Gibbs '+tag+'/'+name)
 close([s['canonical_sector_probability'] for s in case['sectors']],prob,lim['normalization_abs'],'All canonical spin probabilities '+tag);close(ownobs['Sdot_connected'],3*ownobs['Czz'],lim['spin_rotation_abs'],'Explicit transverse SU2 '+tag);close(sum(ownobs['density']),4.,lim['normalization_abs'],'Fixed totalN '+tag);close(np.sum(ownobs['Cnn']),0.,lim['normalization_abs'],'FixedN covariance sum '+tag)
 for key in ['orbital_transfer_second_moment_per_cell','orbital_number_commutator_maxabs','orbital_coherence_per_cell']:need(ownobs[key]>=-lim['thermal_observable_abs'],'Nonnegative physical quantity '+tag+'/'+key)
 conserved=case['geometry']=='periodic2x2' or case['t4']==0
 for key in ['orbital_transfer_second_moment_per_cell','orbital_number_commutator_maxabs']:
  if conserved:close(ownobs[key],0.,lim['conserved_orbital_zero_abs'],'Conserved orbital '+tag+'/'+key)
  else:need(ownobs[key]>lim['noncancelling_transfer_min'],'Noncancelling orbital transfer '+tag+'/'+key)
 if case['U']==0:
  # Canonical four-particle coefficient via explicit independent occupation
  # combinations of16 spin orbitals, rather than grand-canonical Wick.
  levels=list(es)+list(es);Z=math.fsum(math.exp(-c['beta']*math.fsum(levels[i] for i in occ)) for occ in itertools.combinations(range(16),4));close(ownobs['logZ'],math.log(Z),lim['free_canonical_logZ_abs'],'Independent free canonical occupation partition '+tag)
 return blocks,ownobs

def map_backends(tc,rc,spec,tb,rb,to,ro,c,np,need,close):
 p=mode_map(tc['cells'],rc['cells'],spec);need(sorted(p)==list(range(8)),'Bijective physical mode map '+tc['id'])
 for target,ref in zip(tb,rb):
  index={pair:i for i,pair in enumerate(ref['labels'])};perm=[];sign=[]
  for u,d in target['labels']:
   mapped=[];parity=0
   for mask in (u,d):
    sites=[p[i] for i in range(8) if mask>>i&1];parity+=sum(sites[i]>sites[j] for i in range(len(sites)) for j in range(i+1,len(sites)));mapped.append(sum(1<<j for j in sites))
   perm.append(index[tuple(mapped)]);sign.append((-1)**parity)
  ss=np.array(sign);close(target['H'],ref['H'][np.ix_(perm,perm)]*ss[:,None]*ss[None,:],c['gates']['hamiltonian_abs'],'Independent fermionic cell-relabel H '+tc['id']+'/'+str(len(perm)))
 for name in ['onebody_up','onebody_down','Cnn','Czz','Sdot_connected']:close(to[name],ro[name][np.ix_(p,p)],c['gates']['thermal_observable_abs'],'Mapped backend physical '+tc['id']+'/'+name)
 return p

def reconstructed_measure(case,c,p,np):
 o=case['observables'];A=c['orbital_A_zero_based'];B=c['orbital_B_zero_based'];matrices={key:np.asarray(o[key],float)[np.ix_(p,p)] for key in ['onebody_up','onebody_down','Cnn','Czz','Sdot_connected']};obs=dict(matrices);obs.update({key:np.asarray(o[key],float)[p] for key in ['density','Sz']});obs.update({key:float(o[key]) for key in ['energy','logZ','orbital_coherence_per_cell','orbital_transfer_second_moment_per_cell','orbital_number_commutator_maxabs']});obs['cross_Cnn']=matrices['Cnn'][np.ix_(A,B)];obs['cross_Sdot']=matrices['Sdot_connected'][np.ix_(A,B)];K=np.asarray(case['K'],float)[np.ix_(p,p)];clusters=[dict(energy=s['energy'],rank=s['rank'],projector=np.asarray(s['projector'],float)[np.ix_(p,p)],mixing_weight_per_cell=s['mixing_weight_per_cell']) for s in case['onebody_spectral_clusters']]
 summary=dict(integrated_onebody_mixing_weight_per_cell=math.fsum(s['mixing_weight_per_cell'] for s in clusters),kinetic_spectral_moments_1_to_4=[float(np.trace(np.linalg.matrix_power(K,n))/8) for n in range(1,5)],orbital_coherence_per_cell=obs['orbital_coherence_per_cell'],orbital_transfer_second_moment_per_cell=obs['orbital_transfer_second_moment_per_cell'],orbital_number_commutator_maxabs=obs['orbital_number_commutator_maxabs'],cross_charge_covariance_sum=float(np.sum(obs['cross_Cnn'])),cross_physical_spin_connected_sum=float(np.sum(obs['cross_Sdot'])),onsite_cross_orbital_charge_mean=float(np.trace(obs['cross_Cnn'])/4),onsite_cross_orbital_physical_spin_mean=float(np.trace(obs['cross_Sdot'])/4),orbital_x_density_mean=float(np.mean(obs['density'][A])),orbital_y_density_mean=float(np.mean(obs['density'][B])),energy_per_cell=obs['energy']/4,canonical_logZ_per_cell=obs['logZ']/4)
 return dict(K=K,observables=obs,invariant_summaries=summary,onebody_complete_energy_cluster_measure=clusters,manybody_complete_sector_spectra=[dict(Nup=s['Nup'],Ndown=s['Ndown'],energies=np.asarray(s['energies'],float),canonical_sector_probability=s['canonical_sector_probability']) for s in case['sectors']])

def verify_full_report(saved,docs,maps,c,np,need,close):
 report=saved['full_report'];need(report['schema']=='X19_COMPLETE_GEOMETRY_CONTRASTS_V2' and report['cross_geometry_array_subtraction'] is False and report['cross_geometry_shell_pairing'] is False and report['cross_geometry_equality_gate'] is False and report['all_summaries_invariant_under_cell_relabeling'] is True and report['onebody_measures_are_not_interacting_Lehmann_functions'] is True,'Complete report physical interpretation flags')
 ids=[case['id'] for case in docs[0]['cases']];wanted_backends=['actual_native','independent_QuSpin_in_native_physical_order'];need(set(report['backends'])==set(wanted_backends),'Both actual complete-report backends')
 def tree(actual,expected,name):
  if isinstance(expected,dict):
   need(isinstance(actual,dict) and set(actual)==set(expected),'Complete report field keys '+name)
   for key,value in expected.items():tree(actual[key],value,name+'/'+key)
  elif isinstance(expected,np.ndarray):close(actual,expected,c['gates']['thermal_observable_abs'],'Independent complete report '+name)
  elif name.rsplit('/',1)[-1] in ['own_physical_cells','reference_original_physical_cells','on_own_physical_cells','off_own_physical_cells','exact_on_to_off_physical_mode_map']:
   need(actual==expected,'Exact report physical coordinates/permutation '+name)
  elif isinstance(expected,(list,tuple)):
   need(isinstance(actual,list) and len(actual)==len(expected),'Complete report array length '+name)
   if expected and all(isinstance(v,(int,float,np.integer,np.floating)) and not isinstance(v,bool) for v in expected):close(actual,expected,c['gates']['thermal_observable_abs'],'Independent complete report '+name)
   else:
    for i,(a,b) in enumerate(zip(actual,expected)):tree(a,b,name+'/'+str(i))
  elif isinstance(expected,(float,np.floating)):close(actual,expected,c['gates']['thermal_observable_abs'],'Independent complete report '+name)
  else:need(type(actual) is type(expected) and actual==expected,'Exact report metadata '+name)
 for index,(backend,doc) in enumerate(zip(wanted_backends,docs)):
  recorded=report['backends'][backend];need(set(recorded)=={'complete_cases','same_U_t4_geometry_contrasts','within_geometry_t4_on_off_contrasts'} and [row['id'] for row in recorded['complete_cases']]==ids,'Full report complete ordered12cases '+backend);cases={}
  for case,native,full in zip(doc['cases'],docs[0]['cases'],recorded['complete_cases']):
   p=list(range(8)) if index==0 else maps[case['id']];own=reconstructed_measure(case,c,p,np);cases[case['id']]=(case,native,own)
   expected=dict(id=case['id'],geometry=case['geometry'],U=case['U'],t4=case['t4'],own_physical_cells=native['cells'],mode_labels=[dict(cell=native['cells'][i//2],orbital='x' if i%2==0 else 'y') for i in range(8)],actual_fourier_blocks=case['fourier'],**own)
   if index==1:expected['reference_original_physical_cells']=case['cells']
   tree(full,expected,backend+'/'+case['id'])
  contrasts=[]
  for U,t4 in itertools.product(c['U_arms'],c['t4_arms']):
   for left,right in itertools.combinations(c['geometries'],2):
    ident=lambda geometry:f"{geometry}_U{int(U)}_t4{'0' if t4==0 else 'm065'}"
    l=ident(left['id']);r=ident(right['id']);ls=cases[l][2]['invariant_summaries'];rs=cases[r][2]['invariant_summaries'];delta={key:np.asarray(rs[key])-np.asarray(ls[key]) for key in ls};contrasts.append(dict(left_id=l,right_id=r,difference_direction='right minus left',U=U,t4=t4,finite_geometry_bias_only=True,delta_invariant_summaries=delta,complete_arrays_and_spectral_measures_retained_by_case_id=[l,r],own_coordinates_required=True,equality_gate=False))
  need(len(recorded['same_U_t4_geometry_contrasts'])==12,'All12crossgeometry contrasts '+backend);tree(recorded['same_U_t4_geometry_contrasts'],contrasts,backend+'/crossgeometry')
  hybrids=[]
  for spec,U in itertools.product(c['geometries'],c['U_arms']):
   off=f"{spec['id']}_U{int(U)}_t40";on=f"{spec['id']}_U{int(U)}_t4m065";offraw,offnative,offdata=cases[off];onraw,onnative,ondata=cases[on];p=mode_map(onnative['cells'],offnative['cells'],spec);cellp=[p[i]//2 for i in range(0,8,2)];deltas={}
   for key,value in ondata['observables'].items():
    left=np.asarray(offdata['observables'][key]);right=np.asarray(value)
    if left.ndim==2:left=left[np.ix_(p,p)] if left.shape==(8,8) else left[np.ix_(cellp,cellp)] if left.shape==(4,4) else (_ for _ in ()).throw(ValueError('Unexpected report matrix shape'))
    elif left.ndim==1:left=left[p]
    deltas[key]=right-left
   ls=offdata['invariant_summaries'];rs=ondata['invariant_summaries'];hybrids.append(dict(geometry=spec['id'],U=U,off_id=off,on_id=on,difference_direction='t4=-0.65 minus t4=0',exact_on_to_off_physical_mode_map=p,on_own_physical_cells=onnative['cells'],off_own_physical_cells=offnative['cells'],delta_full_observables=deltas,delta_full_K=ondata['K']-offdata['K'][np.ix_(p,p)],delta_invariant_summaries={key:np.asarray(rs[key])-np.asarray(ls[key]) for key in ls},complete_separate_spectral_measures_retained_by_case_id=[off,on],no_assumed_energy_shell_pairing=True,equality_gate=False))
  need(len(recorded['within_geometry_t4_on_off_contrasts'])==6,'All6onoff contrasts '+backend);tree(recorded['within_geometry_t4_on_off_contrasts'],hybrids,backend+'/hybridization')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--raw',type=Path,required=True);parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--expected-job-id',required=True);parser.add_argument('--accounting-name',default='sacct_fresh.txt');parser.add_argument('--expected-auditor-sha256',required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 if sha(HERE/'plan.json')!=PLAN_SHA256 or sha(__file__)!=args.expected_auditor_sha256:raise SystemExit('Reviewed full auditor/plan differs')
 plan=load(HERE/'plan.json')
 if args.expected_job_id!=plan['expected_full_job_id'] or not os.getenv('SLURM_JOB_ID') or os.getenv('SLURM_JOB_ID')==args.expected_job_id or not args.expected_job_id.isdigit() or os.getenv('SLURM_CPUS_PER_TASK')!='1' or os.getenv('SLURM_MEM_PER_NODE')!='3500' or platform.python_version()!=plan['python_version']:raise SystemExit('Separate ROOT-approved exact1CPU3500MB/pinned3.11.11 analysis allocation required')
 for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','JULIA_NUM_THREADS']:os.environ[name]='1'
 args.raw=args.raw.resolve();args.archive=args.archive.resolve();args.output=args.output.resolve();args.output.mkdir(parents=True,exist_ok=False);checks=[];metrics={};inputs={};report={};replay_differences=[];resources={};runtime=None;analysis_contract=None;analysis_runtime={};matrix_math_reached=False;progress={'completed_saved_matrix_eigh_calls':0}
 def need(ok,name):
  checks.append(dict(name=name,passed=bool(ok)))
  if not ok:raise ValueError(name)
 def bind(path):path=Path(path).resolve();inputs[str(path)]={'sha256':sha(path),'bytes':path.stat().st_size};return inputs[str(path)]['sha256']
 bind(__file__);bind(HERE/'plan.json')
 try:
  source,data,c,sourcehash,pins,locations,ex=verify_metadata(args,plan,need,bind);analysis_contract=qualify_analysis_runtime(args.raw,locations,need,bind);np,eigh_api,csr_matrix=actual_imports(analysis_contract['locations'],need);analysis_runtime['before']=loaded_analysis_runtime(analysis_contract,need,'before',eigh_api,csr_matrix)
  def eigh(*values,**keywords):
   result=eigh_api(*values,**keywords);progress['completed_saved_matrix_eigh_calls']+=1;return result
  def close(x,y,lim,name):
   x=np.asarray(x);y=np.asarray(y);need(x.shape==y.shape and np.all(np.isfinite(x)) and np.all(np.isfinite(y)),name+' completefinite shape');error=float(np.max(abs(x-y),initial=0));need(error<=lim,name);metrics[name]=dict(value=error,bound=lim)
  docs=[load(data/'target.toml'),load(data/'reference.json')];need(docs[0]['schema']=='X19_NATIVE_THERMAL_RAW_V1' and docs[1]['schema']=='X19_QUSPIN_THERMAL_RAW_V1','Actual original native and QuSpin full roles')
  need(docs[0]['native_source_sha256']==c['native_source_hashes'] and docs[0]['julia_version']==c['runtime_julia'] and docs[1]['python_version']==c['runtime_python'] and docs[1]['versions']=={'quspin':c['quspin_version'],'quspin-extensions':c['quspin_extensions_version'],'numpy':c['numpy_version'],'scipy':c['scipy_version']} and docs[1]['reference_library_pins_sha256']==sha(source/'reference_library_pins.json') and docs[1]['reference_library_sha256']==pins['files'],'Original actual native/reference/runtime bindings')
  expected=[(spec,U,t4,f"{spec['id']}_U{int(U)}_t4{'0' if t4==0 else 'm065'}") for spec,U,t4 in itertools.product(c['geometries'],c['U_arms'],c['t4_arms'])];ids=[row[3] for row in expected]
  for name,doc in zip(['native','QuSpin'],docs):need(doc['source_sha256']==sourcehash and doc['source_freeze_sha256']==FREEZE and doc['job_id']==args.expected_job_id and doc['mode']=='full' and doc['scientific_completions']==0 and [case['id'] for case in doc['cases']]==ids and len(ids)==12,'Exact mandatory12case full document '+name)
  saved=load(data/'comparison.json');need(saved['schema']=='X19_FULL_COMPARISON_V2' and saved['status']=='PASS' and saved['catalogue_status']=='PASS' and saved['scientific_completions']==1 and not saved['pilot_excluded'] and saved['full_report_complete'] and saved['job_id']==args.expected_job_id and saved['source_freeze_sha256']==FREEZE and saved['raw_sha256']=={'target':sha(data/'target.toml'),'reference':sha(data/'reference.json')} and [row['id'] for row in saved['cases']]==ids,'Original full comparator/raw/grid/onecredit binding')
  need(docs[0]['full_admission']==docs[1]['full_admission']==saved['full_admission'] and saved['full_admission']['pilot_assessment_sha256']==ex['bindings']['pilot_assessment_sha256'] and saved['full_admission']['pilot_audit_sha256']==ex['bindings']['pilot_audit_sha256'] and saved['full_admission']['admission_sha256']==ex['admission_sha256'],'Actual original pilot/full admission hash closure')
  maps={};totalgates=0
  for (spec,U,t4,ident),tc,rc,row in zip(expected,docs[0]['cases'],docs[1]['cases'],saved['cases']):
   need((tc['id'],tc['geometry'],tc['U'],tc['t4'])==(rc['id'],rc['geometry'],rc['U'],rc['t4'])==(ident,spec['id'],U,t4),'Registered own geometry/U/t4 '+ident);need(row['status']=='PASS' and bool(row['gates']) and all(g['passed'] for g in row['gates']),'Every frozen fullcase gate '+ident);totalgates+=len(row['gates']);matrix_math_reached=True;tb,to=one_case(tc,spec,c,'native',np,eigh,csr_matrix,need,close);rb,ro=one_case(rc,spec,c,'QuSpin',np,eigh,csr_matrix,need,close);maps[ident]=map_backends(tc,rc,spec,tb,rb,to,ro,c,np,need,close);need(row['mode_mapping_native_to_reference']==maps[ident],'Original comparator physical permutation '+ident)
  verify_full_report(saved,docs,maps,c,np,need,close)
  replay=args.output/'frozen_comparison_replay.json';cmd=[sys.executable,'-B',str(source/'compare.py'),'--target',str(data/'target.toml'),'--reference',str(data/'reference.json'),'--output',str(replay)];timed_out=False
  with (args.output/'replay.stdout.txt').open('x') as so,(args.output/'replay.stderr.txt').open('x') as se:
   process=subprocess.Popen(cmd,stdout=so,stderr=se,start_new_session=True)
   try:code=process.wait(timeout=plan['proposal_replay_cap_seconds'])
   except subprocess.TimeoutExpired:timed_out=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
  need(code==0 and not timed_out,'Frozen complete full comparator replay exit0');replay_differences=replay_equal_only_gate_value(saved,load(replay));need(True,'Frozen full JSON equality except original authorized floatgates.value policy')
  for proc in ex['processes']:
   text=(data/(proc['name']+'.resources.txt')).read_text();hit=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text);need(hit is not None and 'Exit status: 0' in text and 0<proc['end_unix']-proc['start_unix']<=proc['cap_seconds'],'Original bounded process/GNUtime '+proc['name']);resources[proc['name']]=dict(elapsed_seconds=proc['end_unix']-proc['start_unix'],peak_RSS_KiB=int(hit[1]));need(int(hit[1])<=3500*1024,'Original requested memory limit '+proc['name'])
  for path,row in list(inputs.items()):need(sha(path)==row['sha256'] and Path(path).stat().st_size==row['bytes'],'Every input immutable after saved-data audit '+path)
  for name,path in locations.items():need(sha(path)==pins['files'][name],'Actual72runtime after unchanged '+name)
  for path,digest in analysis_contract['expected'].items():need(sha(path)==digest,'Current-analysis supplemental/system bytes after unchanged '+path)
  analysis_runtime['after']=loaded_analysis_runtime(analysis_contract,need,'after',eigh_api,csr_matrix)
  report.update(status='PASS',full_mathematics='PASS',registered_cases=12,spin_sectors_per_case_per_backend=5,total_sector_blocks_both_backends=120,complete_eigenenergies_per_case_per_backend=sum(c['sector_dimensions']),raw_resources=resources,frozen_comparator_gate_count=totalgates,full_report_cases_per_backend=12,full_report_cross_geometry_contrasts_per_backend=12,full_report_t4_contrasts_per_backend=6,replay_semantics_equal=True,exact_replay_equal=not replay_differences)
 except Exception as exception:report.update(status='UNRESOLVED',reason=type(exception).__name__+': '+str(exception),traceback=traceback.format_exc())
 shutil.copyfile(__file__,args.output/'auditor_source.py');status=report['status'];report.update(schema='X19_INDEPENDENT_FULL_SAVED_DATA_AUDIT_V2',catalogue_id='X19',catalogue_status='PASS' if status=='PASS' else 'UNRESOLVED',scientific_completions=int(status=='PASS'),pilot_scientific_completions=0,original_job=args.expected_job_id,analysis_job=os.environ['SLURM_JOB_ID'],auditor_sha256=sha(__file__),audit_plan_sha256=sha(HERE/'plan.json'),source_archive_sha256=ARCHIVE,source_freeze_sha256=FREEZE,checks=checks,check_count=len(checks),metric_specific_errors=metrics,input_sha256=inputs,replay_roundoff_differences=replay_differences,preserved_pilot_v2_auditor_sha256=PILOT_AUDITOR_SHA256,replay_policy='Only finite FLOAT gates[index].value leaves within max(1e-12,64eps*scale); every other type/schema/array/bound/decision/status exact. No additional relaxation.',scope=plan['scope'],fresh_saved_matrix_diagonalization=progress['completed_saved_matrix_eigh_calls']>0,saved_matrix_math_reached=matrix_math_reached,completed_saved_matrix_eigh_calls=progress['completed_saved_matrix_eigh_calls'],current_analysis_runtime=analysis_runtime,current_analysis_supplement_before=analysis_contract['before'] if analysis_contract else None,current_analysis_runtime_scope=plan['current_analysis_runtime_supplement']['origin'],preserved_failed_v1_analysis_job='6467037',preserved_failed_v1_report_sha256=plan['preserved_failed_analysis_report_sha256'],target_reference_producer_or_new_fixture_executed=False,job_submitted=False,catalogue_ledger_mutated=False,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (args.output/'audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(status);return 0 if status=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
