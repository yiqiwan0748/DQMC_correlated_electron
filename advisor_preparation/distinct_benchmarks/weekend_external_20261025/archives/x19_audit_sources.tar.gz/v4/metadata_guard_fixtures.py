"""Pure AST/JSON/synthetic-map checks. Never imports the auditor or numerical APIs."""
import ast
import copy
import hashlib
import json
import sys
from pathlib import Path

HERE = Path('\\\\?\\' + str(Path(__file__).resolve().parent))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
source = HERE / 'audit_x19_full_v4.py'
tree = ast.parse(source.read_text(encoding='utf-8'))
nodes = {n.name:n for n in tree.body if isinstance(n, ast.FunctionDef)}
old_tree = ast.parse((HERE/'preserved_v3_source/audit_x19_full_v3.py').read_text())
old_nodes = {n.name:n for n in old_tree.body if isinstance(n, ast.FunctionDef)}
checks = []
def check(ok, name):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok: raise AssertionError(name)
def need(ok, name):
    if not ok: raise ValueError(name)
def rejected(call, name):
    try: call()
    except (ValueError, KeyError, TypeError): check(True,name)
    else: check(False,name)
pure_names = ['validate_optional_grp_pin_document','qualify_current_maps']
for name in pure_names:
    check(not any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(nodes[name])),name+'/no imports')
namespace = {}
exec(compile(ast.fix_missing_locations(ast.Module(body=[nodes[n] for n in pure_names],type_ignores=[])), '<metadata-guards-only>', 'exec'),namespace)
validate = namespace['validate_optional_grp_pin_document']
qualify = namespace['qualify_current_maps']
pin = load(HERE/'optional_grp_runtime_pin.json')
finding = load(HERE/'preserved_v3_failure/current_grp_identity_finding_PRIVATE.json')
failure = load(HERE/'preserved_v3_failure/audit.json')
review = load(HERE/'preserved_v3_failure/review.json')
plan = load(HERE/'plan.json')
check(validate(pin,finding,failure,review)==(pin['path'],dict(sha256=pin['sha256'],bytes=57320)),'exact one-file pin eligible')
check(pin['required_to_load'] is False,'grp is optional')
for name,key,value in [('different path','path',pin['path']+'.other'),('different hash','sha256','0'*64),('different byte size','bytes',57321),('bool size','bytes',True),('mandatory grp','required_to_load',True),('historical approval','historical_runtime_mapping_recovered',True),('stdlib wildcard','broad_stdlib_allowance',True),('different job','source_analysis_job','6467557'),('different module','module','pwd'),('different scope','scope','ALL_HISTORY')]:
    altered=copy.deepcopy(pin);altered[key]=value
    rejected(lambda a=altered:validate(a,finding,failure,review),'pin rejects '+name)
altered=copy.deepcopy(pin);altered['extra_provider']={'path':'/usr/other.so'}
rejected(lambda:validate(altered,finding,failure,review),'pin rejects extra schema/provider')
for key,value in [('all_segment_inode_device_nondeleted',False),('entry_exception_identical',False),('prospective_only',False),('current_path_hash_not_memory_dump',False),('observed_segments_per_capture',4),('scientific_completions',1),('source_audit_sha256','0'*64),('historical_runtime_mapping_recovered',True)]:
    altered=copy.deepcopy(finding);altered[key]=value
    rejected(lambda a=altered:validate(pin,a,failure,review),'finding rejects '+key)
for key,value in [('status','PASS'),('saved_matrix_math_reached',True),('completed_saved_matrix_eigh_calls',1),('scientific_completions',1),('reason','different failure'),('analysis_job','6467557'),('historical_failed_runtime_mapping_recovered',True)]:
    altered=copy.deepcopy(failure);altered[key]=value
    rejected(lambda a=altered:validate(pin,finding,a,review),'prior v3 rejects '+key)
for key,value in [('status','PASS_SCIENCE'),('check_count',1099),('current_grp_bytes',57321),('current_grp_sha256','0'*64),('current_grp_finding_sha256','0'*64),('provider_guard_dropped',True),('scientific_completions',1),('source_changes',True),('jobs_submitted',True)]:
    altered=copy.deepcopy(review);altered[key]=value
    rejected(lambda a=altered:validate(pin,finding,failure,a),'independent review rejects '+key)
altered=copy.deepcopy(review);altered['checks'][1]['passed']=False
rejected(lambda:validate(pin,finding,failure,altered),'independent review rejects failed check')

def row(path, digest='a'*64, size=19):
    return dict(realpath=path,regular_file=True,unchanged_during_read=True,sha256=digest,bytes=size,inode=17,device_major=1,device_minor=2,proc_map_entries=[dict(device='01:02',inode=17,deleted=False),dict(device='01:02',inode=17,deleted=False)])
base='/metadata_fixture_required.so'
snapshot=dict(files={base:row(base)},raw_maps_sha256='b'*64)
contract=dict(approved_loaded={base:dict(sha256='a'*64,bytes=19),pin['path']:dict(sha256=pin['sha256'],bytes=pin['bytes'])},required75={base:{}})
check(qualify(snapshot,contract,need,'fixture',True)['all_actual_mappings_qualified'],'approved maps pass while optional grp absent')
with_grp=copy.deepcopy(snapshot);with_grp['files'][pin['path']]=row(pin['path'],pin['sha256'],pin['bytes'])
check(qualify(with_grp,contract,need,'fixture',True)['all_actual_mappings_qualified'],'exact optional grp present passes')
for case in ['unregistered','hash','size','deleted later segment','inode later segment','device later segment','unstable current path','nonregular','missing hash']:
    altered=copy.deepcopy(with_grp)
    r=altered['files'][pin['path']]
    if case=='unregistered': r['realpath']=pin['path']+'.unknown'
    elif case=='hash': r['sha256']='0'*64
    elif case=='size': r['bytes']+=1
    elif case=='deleted later segment': r['proc_map_entries'][1]['deleted']=True
    elif case=='inode later segment': r['proc_map_entries'][1]['inode']+=1
    elif case=='device later segment': r['proc_map_entries'][1]['device']='01:03'
    elif case=='unstable current path': r['unchanged_during_read']=False
    elif case=='nonregular': r['regular_file']=False
    elif case=='missing hash': r['sha256']=None
    rejected(lambda a=altered:qualify(a,contract,need,'fixture',True),'map rejects '+case)
missing=copy.deepcopy(snapshot);missing['files'].clear()
rejected(lambda:qualify(missing,contract,need,'fixture',True),'required captured paths stay mandatory')
check(qualify(missing,contract,need,'entry_fixture',False)['required75_present'] is False,'entry does not require all postimport paths')

unchanged=['sha','load','hop','quotient','exact_torus_K','unpack','independent_H','thermal_observers','replay_equal_only_gate_value','geometry_key','mode_map','open_edges_K','verify_metadata','one_case','map_backends','reconstructed_measure','verify_full_report','mapped_snapshot','qualify_current_maps','loaded_analysis_runtime','actual_imports']
for name in unchanged:
    check(ast.dump(nodes[name],include_attributes=False)==ast.dump(old_nodes[name],include_attributes=False),'unchanged AST/'+name)
for name in ['reference_distribution_pins.json','certificate_system_provider_pins.json','current_capture_independent_review.json','current_observed75_registry_PRIVATE.json','optional_cpython_runtime_pins.json']:
    check(sha(HERE/name)==sha(HERE/'preserved_v3_source'/name),'exact inherited inventory/'+name)
for name,key in [('optional_grp_runtime_pin.json','optional_grp_runtime_pin_sha256'),('preserved_v3_failure/audit.json','preserved_failed_v3_report_sha256'),('preserved_v3_failure/current_grp_identity_finding_PRIVATE.json','current_grp_identity_finding_sha256'),('preserved_v3_failure/review.json','v3_failure_independent_review_sha256')]:
    check(sha(HERE/name)==plan[key],'new plan provenance binding/'+name)
check(sha(HERE/'preserved_v3_failure/audit.json')==pin['source_audit_sha256'],'pin binds exact failed v3')
check(sha(HERE/'preserved_v3_failure/current_grp_identity_finding_PRIVATE.json')==pin['identity_finding_sha256'],'pin binds exact identity finding')
check(sha(HERE/'preserved_v3_failure/review.json')==pin['independent_failure_review_sha256'],'pin binds exact independent1100 review')
check(plan['proposal_replay_cap_seconds']==300 and plan['registered_full_cases']==12 and plan['spin_sectors_per_case']==5,'full grid and replay cap retained')
check(plan['proposal_analysis_wall_minutes']==30 and 'OneCPU3500MB' in plan['resources'],'inherited analysis-only budget retained')
check(len(load(HERE/'optional_cpython_runtime_pins.json')['paths'])==13,'optional13 unchanged and separate')
check(len(load(HERE/'current_observed75_registry_PRIVATE.json')['files'])==75,'required75 inventory remains75')
check(len(load(HERE/'reference_distribution_pins.json')['files'])==1598,'current1598 remains1598')
check(not any(name in sys.modules for name in ['numpy','scipy','quspin','quspin_extensions']),'no numerical import')
report=dict(schema='X19_V4_PURE_METADATA_GUARD_FIXTURES_V1',status='PASS',checks=checks,check_count=len(checks),failed_checks=[],auditor_sha256=sha(source),plan_sha256=sha(HERE/'plan.json'),fixture_source_sha256=sha(__file__),candidate_imported=False,executed_AST_functions=pure_names,synthetic_maps_only=True,numerical_imports=False,numerical_fixtures=False,real_runtime_qualified=False,saved_matrix_math=False,scientific_completions=0,jobs_submitted=False)
(HERE/'metadata_guard_fixture_report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS_METADATA_ONLY',checks=len(checks),auditor_sha256=report['auditor_sha256'],fixture_report_sha256=sha(HERE/'metadata_guard_fixture_report.json'))))
