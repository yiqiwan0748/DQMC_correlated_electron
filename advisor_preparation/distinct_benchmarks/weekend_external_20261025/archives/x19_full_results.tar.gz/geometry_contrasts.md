# X19 full finite-geometry comparison

Status: **PASS**. All12 registered cases are mandatory for one X19 completion.

The complete JSON report retains every array with its own coordinates, both independent backends and complete separate spectral measures. Different geometries are compared only through the named invariant summaries below. Their differences are finite-geometry bias, with no equality or bulk claim.

## actual_native

|case|integrated_onebody_mixing_weight_per_cell|orbital_coherence_per_cell|orbital_transfer_second_moment_per_cell|cross_charge_covariance_sum|cross_physical_spin_connected_sum|onsite_cross_orbital_charge_mean|onsite_cross_orbital_physical_spin_mean|
|---|---:|---:|---:|---:|---:|---:|---:|
|open2x2_U0_t40|1.121726898e-31|7.154232809e-34|0|-0.6563466792|9.23740251e-17|-0.04102166745|5.800481623e-18|
|open2x2_U0_t4m065|0.2632279274|0.01871777385|0.3738430348|-0.6984605657|-0.05298521354|-0.04105989972|-0.001366161619|
|open2x2_U4_t40|1.121726898e-31|7.006083427e-34|0|-0.3875419895|2.458970527e-16|-0.02422137434|1.604619215e-17|
|open2x2_U4_t4m065|0.2632279274|0.01411740733|0.370593754|-0.4416283752|-0.03910393055|-0.02499868407|-0.00152642326|
|periodic2x2_U0_t40|7.329332379e-30|2.841982217e-33|0|-0.393014284|-7.437626903e-17|-0.02456339275|-1.870248748e-18|
|periodic2x2_U0_t4m065|7.329332379e-30|2.841982217e-33|0|-0.393014284|-7.437626903e-17|-0.02456339275|-1.870248748e-18|
|periodic2x2_U4_t40|7.329332379e-30|6.570068711e-34|0|-0.2662316891|-2.107689023e-16|-0.01663948057|-1.4474099e-17|
|periodic2x2_U4_t4m065|7.329332379e-30|6.570068711e-34|0|-0.2662316891|-2.107689023e-16|-0.01663948057|-1.4474099e-17|
|tilted4_U0_t40|7.093885468e-32|2.035159184e-33|0|-0.5354238852|1.823628054e-16|-0.03346399283|1.596487699e-17|
|tilted4_U0_t4m065|0.25|0.07913601053|3.845523268|-0.8476463427|-0.212662186|-0.07069974525|-0.02658277325|
|tilted4_U4_t40|7.093885468e-32|4.782041223e-33|0|-0.3391053555|4.570996359e-16|-0.02119408472|3.01408204e-17|
|tilted4_U4_t4m065|0.25|0.07135056987|3.956933147|-0.6375333108|-0.1192656534|-0.05974232382|-0.01912650175|

### All same-U/t4 geometry differences

Right minus left; each full matrix/spectral measure keeps its own coordinates.

|left|right|integrated_onebody_mixing_weight_per_cell|orbital_coherence_per_cell|orbital_transfer_second_moment_per_cell|cross_charge_covariance_sum|cross_physical_spin_connected_sum|onsite_cross_orbital_charge_mean|onsite_cross_orbital_physical_spin_mean|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|open2x2_U0_t40|periodic2x2_U0_t40|7.217159689e-30|2.126558936e-33|0|0.2633323952|-1.667502941e-16|0.0164582747|-7.67073037e-18|
|open2x2_U0_t40|tilted4_U0_t40|-4.123383508e-32|1.319735903e-33|0|0.120922794|8.998878032e-17|0.007557674626|1.016439537e-17|
|periodic2x2_U0_t40|tilted4_U0_t40|-7.258393524e-30|-8.068230328e-34|0|-0.1424096012|2.567390744e-16|-0.008900600075|1.783512574e-17|
|open2x2_U0_t4m065|periodic2x2_U0_t4m065|-0.2632279274|-0.01871777385|-0.3738430348|0.3054462817|0.05298521354|0.01649650697|0.001366161619|
|open2x2_U0_t4m065|tilted4_U0_t4m065|-0.01322792736|0.06041823668|3.471680233|-0.149185777|-0.1596769724|-0.02963984553|-0.02521661163|
|periodic2x2_U0_t4m065|tilted4_U0_t4m065|0.25|0.07913601053|3.845523268|-0.4546320587|-0.212662186|-0.0461363525|-0.02658277325|
|open2x2_U4_t40|periodic2x2_U4_t40|7.217159689e-30|-4.360147157e-35|0|0.1213103004|-4.566659551e-16|0.007581893774|-3.052029116e-17|
|open2x2_U4_t40|tilted4_U4_t40|-4.123383508e-32|4.081432881e-33|0|0.04843663395|2.112025832e-16|0.003027289622|1.409462824e-17|
|periodic2x2_U4_t40|tilted4_U4_t40|-7.258393524e-30|4.125034352e-33|0|-0.07287366644|6.678685383e-16|-0.004554604152|4.46149194e-17|
|open2x2_U4_t4m065|periodic2x2_U4_t4m065|-0.2632279274|-0.01411740733|-0.370593754|0.1753966861|0.03910393055|0.0083592035|0.00152642326|
|open2x2_U4_t4m065|tilted4_U4_t4m065|-0.01322792736|0.05723316255|3.586339393|-0.1959049356|-0.08016172286|-0.03474363976|-0.01760007849|
|periodic2x2_U4_t4m065|tilted4_U4_t4m065|0.25|0.07135056987|3.956933147|-0.3713016217|-0.1192656534|-0.04310284326|-0.01912650175|

### All within-geometry hybridization responses

t4=-0.65 minus t4=0. Full-array differences use the exact own-geometry cell map, saved in JSON. Spectral measures are kept separately without pairing shells.

|off|on|integrated_onebody_mixing_weight_per_cell|orbital_coherence_per_cell|orbital_transfer_second_moment_per_cell|cross_charge_covariance_sum|cross_physical_spin_connected_sum|onsite_cross_orbital_charge_mean|onsite_cross_orbital_physical_spin_mean|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|open2x2_U0_t40|open2x2_U0_t4m065|0.2632279274|0.01871777385|0.3738430348|-0.04211388651|-0.05298521354|-3.823227026e-05|-0.001366161619|
|open2x2_U4_t40|open2x2_U4_t4m065|0.2632279274|0.01411740733|0.370593754|-0.05408638571|-0.03910393055|-0.0007773097258|-0.00152642326|
|periodic2x2_U0_t40|periodic2x2_U0_t4m065|0|0|0|0|0|0|0|
|periodic2x2_U4_t40|periodic2x2_U4_t4m065|0|0|0|0|0|0|0|
|tilted4_U0_t40|tilted4_U0_t4m065|0.25|0.07913601053|3.845523268|-0.3122224575|-0.212662186|-0.03723575242|-0.02658277325|
|tilted4_U4_t40|tilted4_U4_t4m065|0.25|0.07135056987|3.956933147|-0.2984279553|-0.1192656534|-0.0385482391|-0.01912650175|

The JSON additionally retains Tr(K^p)/8 for p=1..4, their contrasts, energy/logZ per cell, orbital mean densities, every complete Cnn/physical Sdot/coherence array and all canonical sector eigenenergies.

## independent_QuSpin_in_native_physical_order

|case|integrated_onebody_mixing_weight_per_cell|orbital_coherence_per_cell|orbital_transfer_second_moment_per_cell|cross_charge_covariance_sum|cross_physical_spin_connected_sum|onsite_cross_orbital_charge_mean|onsite_cross_orbital_physical_spin_mean|
|---|---:|---:|---:|---:|---:|---:|---:|
|open2x2_U0_t40|4.173414845e-31|4.879074602e-34|0|-0.6563466792|1.073360151e-16|-0.04102166745|6.776263578e-18|
|open2x2_U0_t4m065|0.2632279274|0.01871777385|0.3738430348|-0.6984605657|-0.05298521354|-0.04105989972|-0.001366161619|
|open2x2_U4_t40|4.173414845e-31|4.428581856e-34|0|-0.3875419895|3.170207152e-16|-0.02422137434|1.908195824e-17|
|open2x2_U4_t4m065|0.2632279274|0.01411740733|0.370593754|-0.4416283752|-0.03910393055|-0.02499868407|-0.00152642326|
|periodic2x2_U0_t40|8.440248296e-31|7.761191725e-33|0|-0.393014284|-1.95156391e-18|-0.02456339275|9.893344824e-19|
|periodic2x2_U0_t4m065|8.440248296e-31|7.761191725e-33|0|-0.393014284|-1.95156391e-18|-0.02456339275|9.893344824e-19|
|periodic2x2_U4_t40|8.440248296e-31|7.833123579e-34|0|-0.2662316891|8.435092902e-17|-0.01663948057|4.445228907e-18|
|periodic2x2_U4_t4m065|8.440248296e-31|7.833123579e-34|0|-0.2662316891|8.435092902e-17|-0.01663948057|4.445228907e-18|
|tilted4_U0_t40|7.5728702e-32|3.146145207e-33|0|-0.5354238852|1.972163752e-16|-0.03346399283|1.664250335e-17|
|tilted4_U0_t4m065|0.25|0.07913601053|3.845523268|-0.8476463427|-0.212662186|-0.07069974525|-0.02658277325|
|tilted4_U4_t40|7.5728702e-32|1.332057747e-33|0|-0.3391053555|5.889386201e-16|-0.02119408472|3.3935528e-17|
|tilted4_U4_t4m065|0.25|0.07135056987|3.956933147|-0.6375333108|-0.1192656534|-0.05974232382|-0.01912650175|

### All same-U/t4 geometry differences

Right minus left; each full matrix/spectral measure keeps its own coordinates.

|left|right|integrated_onebody_mixing_weight_per_cell|orbital_coherence_per_cell|orbital_transfer_second_moment_per_cell|cross_charge_covariance_sum|cross_physical_spin_connected_sum|onsite_cross_orbital_charge_mean|onsite_cross_orbital_physical_spin_mean|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|open2x2_U0_t40|periodic2x2_U0_t40|4.266833451e-31|7.273284265e-33|0|0.2633323952|-1.09287579e-16|0.0164582747|-5.786929096e-18|
|open2x2_U0_t40|tilted4_U0_t40|-3.416127825e-31|2.658237747e-33|0|0.120922794|8.98803601e-17|0.007557674626|9.86623977e-18|
|periodic2x2_U0_t40|tilted4_U0_t40|-7.682961276e-31|-4.615046518e-33|0|-0.1424096012|1.991679391e-16|-0.008900600075|1.565316887e-17|
|open2x2_U0_t4m065|periodic2x2_U0_t4m065|-0.2632279274|-0.01871777385|-0.3738430348|0.3054462817|0.05298521354|0.01649650697|0.001366161619|
|open2x2_U0_t4m065|tilted4_U0_t4m065|-0.01322792736|0.06041823668|3.471680233|-0.149185777|-0.1596769724|-0.02963984553|-0.02521661163|
|periodic2x2_U0_t4m065|tilted4_U0_t4m065|0.25|0.07913601053|3.845523268|-0.4546320587|-0.212662186|-0.0461363525|-0.02658277325|
|open2x2_U4_t40|periodic2x2_U4_t40|4.266833451e-31|3.404541724e-34|0|0.1213103004|-2.326697862e-16|0.007581893774|-1.463672933e-17|
|open2x2_U4_t40|tilted4_U4_t40|-3.416127825e-31|8.891995616e-34|0|0.04843663395|2.719179049e-16|0.003027289622|1.485356976e-17|
|periodic2x2_U4_t40|tilted4_U4_t40|-7.682961276e-31|5.487453892e-34|0|-0.07287366644|5.045876911e-16|-0.004554604152|2.949029909e-17|
|open2x2_U4_t4m065|periodic2x2_U4_t4m065|-0.2632279274|-0.01411740733|-0.370593754|0.1753966861|0.03910393055|0.0083592035|0.00152642326|
|open2x2_U4_t4m065|tilted4_U4_t4m065|-0.01322792736|0.05723316255|3.586339393|-0.1959049356|-0.08016172286|-0.03474363976|-0.01760007849|
|periodic2x2_U4_t4m065|tilted4_U4_t4m065|0.25|0.07135056987|3.956933147|-0.3713016217|-0.1192656534|-0.04310284326|-0.01912650175|

### All within-geometry hybridization responses

t4=-0.65 minus t4=0. Full-array differences use the exact own-geometry cell map, saved in JSON. Spectral measures are kept separately without pairing shells.

|off|on|integrated_onebody_mixing_weight_per_cell|orbital_coherence_per_cell|orbital_transfer_second_moment_per_cell|cross_charge_covariance_sum|cross_physical_spin_connected_sum|onsite_cross_orbital_charge_mean|onsite_cross_orbital_physical_spin_mean|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|open2x2_U0_t40|open2x2_U0_t4m065|0.2632279274|0.01871777385|0.3738430348|-0.04211388651|-0.05298521354|-3.823227026e-05|-0.001366161619|
|open2x2_U4_t40|open2x2_U4_t4m065|0.2632279274|0.01411740733|0.370593754|-0.05408638571|-0.03910393055|-0.0007773097258|-0.00152642326|
|periodic2x2_U0_t40|periodic2x2_U0_t4m065|0|0|0|0|0|0|0|
|periodic2x2_U4_t40|periodic2x2_U4_t4m065|0|0|0|0|0|0|0|
|tilted4_U0_t40|tilted4_U0_t4m065|0.25|0.07913601053|3.845523268|-0.3122224575|-0.212662186|-0.03723575242|-0.02658277325|
|tilted4_U4_t40|tilted4_U4_t4m065|0.25|0.07135056987|3.956933147|-0.2984279553|-0.1192656534|-0.0385482391|-0.01912650175|

The JSON additionally retains Tr(K^p)/8 for p=1..4, their contrasts, energy/logZ per cell, orbital mean densities, every complete Cnn/physical Sdot/coherence array and all canonical sector eigenenergies.

