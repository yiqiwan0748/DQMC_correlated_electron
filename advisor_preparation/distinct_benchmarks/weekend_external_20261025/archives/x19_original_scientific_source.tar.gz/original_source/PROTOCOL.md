# X19 full v2 protocol before execution

This is a new, unfrozen full-workflow release from original pilot source archive `17a2e0c3dc1f0bbb861457555cdeb9ada72736b408b9ffd1af794fc27602df0f`, freeze `53097c5e2cc638cdb67c91e8bbf5604dbb731a3ef79743c2e84e5501c6451b6f`. It preserves the original question and scientific functions; the pilot source/archive and all original outcomes stay separate.

## Mandatory scientific grid and scope

Three four-cell geometries (open 2x2; periodic a1=(2,0),a2=(0,2); tilted a1=(1,1),a2=(-2,2)) times U=0,4 times t4=0,-0.65 gives 12 cases in the manifest's fixed enumeration order. Total N=4, beta=1, t1=-1,t2=-1.75,t3=-0.85,h=0. Sum all five (Nup,Ndown) sectors (0,4),(1,3),(2,2),(3,1),(4,0), dimensions70,448,784,448,70, with exact canonical Boltzmann weights. No fixed-Sz or selected/averaged ground-state replacement is permitted. Degenerate energy shells use whole projectors, not a chosen vector. Spin correlations use physical S=(1/2)c†sigma c, including both transverse terms.

Each geometry is compared with its own independently constructed QuSpin model after the original exact quotient/cell mapping and within-spin occupied permutation signs. Every original gate in `one_case` and `[gates]` is verbatim. All matrices, eigenenergies, kinetic shell projectors/weights, thermodynamic quantities, 8x8 physical charge/spin/one-body arrays and explicit16 cross-orbital values are retained. QuSpin source/extensions/RECORD hashes, runtime versions and all actual user source pins remain exact. The full manifest changes resource/workflow metadata only.

The square periodic2x2 geometry cancels diagonal t4 mixing; the tilted quotient retains it. The tilted quotient's image aliases and lost C4 symmetry are properties of this finite quotient. Different geometries need not have equal spectra/correlations. At t4=0 or the cancelling periodic quotient, conserved NA forces the original commutator/coherence/mixing zeros. Canonical total-N interorbital charge covariance can remain nonzero. Complete physical Sdot is retained rather than replaced by an unqualified Czz assertion; the original canonical SU2 checks remain.

## Complete descriptive report, fixed before full data

The full comparator first evaluates all12 unchanged independent per-case tests. Every case stays in the report even if its numerical gates fail. Missing/nonfinite data or an incomplete grid is unresolved, with no partial completion. Any unresolved case makes the whole X19 unresolved; otherwise any comparison failure makes it fail; only12 PASS cases and a complete descriptive report give one scientific completion.

For each of the two backends, the report retains12 complete cases, each with its own physical coordinates, full K/Fourier arrays, complete kinetic energy-cluster projectors/weights, all canonical sector spectra/probabilities and physical arrays. The independent backend is mapped only within its own geometry to the actual native coordinates by the existing exact map. No cross-geometry map is inferred.

For each of four same-(U,t4) arms, all three unordered geometry pairs produce12 descriptive contrasts per backend. **Only the following invariant quantities are subtracted (right minus left)**:

- Integrated kinetic mixing weight: sum_clusters ||P_cluster[A,B]||F^2/4; complete separate cluster measures are retained, with no one-to-one shell pairing.
- Kinetic spectral moments Tr(K^p)/8, p=1,2,3,4, using complete actual8mode K. These are one-body moments, not interacting spectral moments or Lehmann functions.
- Existing coherence (||C_up[A,B]||F^2+||C_down[A,B]||F^2)/4, positive transfer <[H,NA]†[H,NA]>/4 and the stated occupation-basis commutator maximum. They are invariant under physical cell relabeling.
- Sum_AB Cnn=Cov(NA,NB), and sum_AB physical connected Sdot. These sums are extensive over the four-cell cluster, without an implicit division.
- On-site cross-orbital means: (1/4)sum_cell Cnn(rx,ry) and (1/4)sum_cell Sdot_connected(rx,ry).
- Orbital-x/y mean density, energy per four physical cells and canonical logZ per four cells.

These contrasts describe finite-geometry bias; there is no cross-geometry equality threshold. Full arrays/spectra remain separate, carrying their own coordinate labels. The report does not subtract arbitrary cell slots or pair sorted unlike shells as a shared physical excitation.

Within each geometry, two U arms give six t4-on/off contrasts per backend. Use the existing exact own-geometry quotient/cell map to align t4=0 to t4=-0.65, then retain differences of every registered full density/spin/one-body/cross array and K, plus all invariant-summary differences. Preserve both full spectral measures separately without pairing shells. No new fitted map, fixture selection or threshold is introduced. The unchanged per-case zero/nonzero mixing tests carry scientific qualification; descriptive contrasts are not new equality gates.

## Original pilot and exact admission chain

Original pilot6466304 completed one tilted/U4/t4=-0.65 case, all five sectors. The adopted independent v2 audit is `f664c11c93a7e6c83e93b0ad4c45432ce28954c348e6c93024cf463cffcfcc1a`, auditor `ac2d9b306e0a8b24ef2a383eecf08c022855d8c69e698a6be4f1d1714f119d69`. Its496 checks and152 frozen comparator gates pass. It records five gate.value arithmetic differences only; statuses, identities, gate bounds/decisions and scientific raw/source bytes remain exact. The original strict v1 replay is preserved, not overwritten. This excluded pilot has no catalogue credit.

A full run requires: independent pilot mathematical audit PASS with exact source/raw binding; a measured resource assessment additionally bound to the new full source freeze; separate parent scientific/source/current-queue approval bound to that assessment and output directory; then actual compute-node admission token verification in every producer. `RESOURCE_PROPOSAL.json` is not such approval. No adapter can admit a standalone full campaign merely from a source freeze or a declared pilot PASS. See `ADMISSION_FORMAT.md` for the explicit schema and commands. The parent owns all source freezes and scheduler submissions.

## Measured conditional resource policy

Original process wall times are target79.4139416218s, reference84.2469348907s, comparator0.5387997627s. GNU-time peak RSS values are509352,209108,66484KiB. Original scientific raw sizes are546358,1940487,34940bytes for target/reference/comparison.

Freeze the forecast `2*12*(target_wall+reference_wall+comparator_wall)+30` =3970.792230606079s and require <=4800s. Component forecasts1905.9345989227295,2021.9264373779297,12.931194305419922s must individually fit fixed2100,2200,300s caps. Their sum4600s plus30s reserve fits the5100s combined inner cap. The allocation is90minutes, one CPU/3500M, with no more than two running CPUs user-wide under separate parent queue admission.

Projected raw bytes=`2*12*(pilot target+reference+comparison bytes)`=60522840, including a fixed extra factor two for full comparative reporting. Projected peak=`max(pilot GNUtime RSS)+16*projectedraw/1024`=1455021.375KiB, required <=3000000KiB; pilot max must be <=2800000KiB. These multipliers are explicit parser/report/workspace allowances, conditional engineering estimates rather than proven peak-memory bounds. Slurm's hard memory/time allocation and the actual per-process GNU-time receipts remain authoritative. All component/deadline failures retain their partial data and add no completion; no blind retry exists.

The runner uses a monotonic combined deadline and per-process caps; scientific producers execute sequentially. Source/admission checks are included in each actual process. Complete comparator FAIL/UNRESOLVED is retained as a scientific outcome, never converted to PASS by the wrapper. The execution wrapper itself awards zero credit; the full comparator and later independent raw audit determine scientific status. No full performance claim is permitted from pilot scaling.

## Source review and reproduction boundaries

Before freeze run the static-only equivalence script against the exact original archive; it parses Julia source without including/evaluating it and compares all original Python function/class ASTs except workflow main. New admission/report functions are disclosed separately. Confirm all scientific manifest values and snapshots are unchanged. The preparation supplies no source_freeze.json or SHA256SUMS and cannot execute science.

After a parent-reviewed complete attempt, pure saved-data comparator/report replay is supported in a fresh output path. Any later independent audit must check all12 raw cases/all60 sectors per backend, source/runtime/actual execution closure, all unchanged signed/directional gates and every complete descriptive contrast, preserving original pilot/failed histories. Audit PASS means evidence was reproduced; it cannot substitute for scientific PASS or authorize another job. Public raw/source records exclude runtime binaries and private CV/contact/controller material.
