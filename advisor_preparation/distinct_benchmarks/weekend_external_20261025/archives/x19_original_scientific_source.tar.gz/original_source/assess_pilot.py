#!/usr/bin/env python3
"""Original saved pilot resource assessment only; no solver or admission."""
import argparse
from pathlib import Path
from workflow import HERE,original_pilot,resource_projection,sha,source_contract,write
def main():
 p=argparse.ArgumentParser();p.add_argument('--pilot',type=Path,required=True);p.add_argument('--audit',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();cfg,source=source_contract();ex,au,required=original_pilot(a.pilot,a.audit);projection=resource_projection(a.pilot,ex,cfg)
 write(a.output,dict(schema='X19_SOURCE_BOUND_FULL_RESOURCE_ASSESSMENT_V2',status='ELIGIBLE_FOR_SEPARATE_ROOT_REVIEW' if projection['eligible'] else 'UNRESOLVED',full_source_freeze_sha256=sha(HERE/'source_freeze.json'),full_source_sha256=source,pilot_audit_sha256=sha(a.audit),pilot_execution_sha256=sha(a.pilot/'results/execution.json'),original_pilot_input_sha256={n:sha(a.pilot/n) for n in required},projection=projection,scientific_completions=0,original_pilot_excluded=True,separate_root_current_queue_admission_required=True,automatic_submission=False,new_scientific_execution=False))
if __name__=='__main__':main()
