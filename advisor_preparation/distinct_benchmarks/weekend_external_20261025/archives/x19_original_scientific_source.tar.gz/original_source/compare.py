#!/usr/bin/env python3
"""X19 candidate: same-geometry independent comparisons; no preparation/pilot credit."""
import argparse,hashlib,itertools,json,math,sys,tomllib
from fractions import Fraction
from pathlib import Path
import numpy as np
from full_report import build_full_report,expected_grid,write_markdown
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return tomllib.loads(p.read_text()) if p.suffix=='.toml' else json.loads(p.read_text())
def plain(x):
 if isinstance(x,dict):return {k:plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [plain(v) for v in x]
 return x.item() if isinstance(x,np.generic) else x

def array(x,shape):
 a=np.asarray(x,float)
 if a.shape!=tuple(shape) or not np.all(np.isfinite(a)):raise ValueError('Incomplete/nonfinite observable grid')
 return a
class Gates:
 def __init__(self):self.rows=[]
 def check(self,name,value,relation,bound,kind='qualification'):
  ok=value==bound if relation=='eq' else math.isfinite(value) and {'le':lambda:value<=bound,'ge':lambda:value>=bound,'gt':lambda:value>bound}[relation]()
  self.rows.append(dict(name=name,value=plain(value),relation=relation,bound=plain(bound),kind=kind,passed=bool(ok)))
 def error(self,name,x,y,tol,kind='comparison'):
  x=np.asarray(x,float);y=np.asarray(y,float)
  if x.shape!=y.shape or not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):raise ValueError('Comparison array invalid')
  self.check(name,float(np.max(abs(x-y),initial=0)),'le',tol,kind)

def key(cell,spec):
 if spec['kind']=='open':return tuple(cell)
 x,y=cell;a,b=spec['a1'],spec['a2'];D=a[0]*b[1]-b[0]*a[1]
 return (Fraction(b[1]*x-b[0]*y,D)%1,Fraction(-a[1]*x+a[0]*y,D)%1)
def site_permutation(t,r,spec):
 kt=[key(c,spec) for c in t['cells']];kr=[key(c,spec) for c in r['cells']]
 if len(kt)!=4 or len(set(kt))!=4 or set(kt)!=set(kr):raise ValueError('Incomplete physical quotient mapping')
 return [2*kr.index(k)+a for k in kt for a in range(2)]
def sector_matrix(s):
 d=s['dimension'];a=s['H']
 if a['shape']!=[d,d] or not len(a['row'])==len(a['col'])==len(a['value']):raise ValueError('Sparse H incomplete')
 H=np.zeros((d,d));seen=set()
 for i,j,v in zip(a['row'],a['col'],a['value']):
  if type(i) is not int or type(j) is not int or not 0<=i<d or not 0<=j<d or (i,j) in seen or not math.isfinite(v):raise ValueError('Sparse H invalid')
  H[i,j]=v;seen.add((i,j))
 return H

def fock_mapping(t,r,p):
 inverse=np.argsort(p).tolist()
 def mapped(mask):
  positions=[inverse[j] for j in range(8) if mask>>j&1];sign=(-1)**sum(a>b for i,a in enumerate(positions) for b in positions[i+1:]);return sum(1<<a for a in positions),sign
 def ls(s):
  pairs=list(zip(s['basis_up_per_row'],s['basis_down_per_row']))
  if len(pairs)!=s['dimension'] or len(set(pairs))!=len(pairs) or any(not 0<=u<256 or not 0<=d<256 or u.bit_count()!=s['Nup'] or d.bit_count()!=s['Ndown'] for u,d in pairs):raise ValueError('Sector basis invalid')
  return pairs
 refs={}
 for i,(u,d) in enumerate(ls(r)):
  uu,su=mapped(u);dd,sd=mapped(d);refs[uu,dd]=(i,su*sd)
 target=ls(t)
 if set(refs)!=set(target):raise ValueError('Fock states do not represent same physical sector')
 return np.array([refs[x][0] for x in target]),np.array([refs[x][1] for x in target])

def one_case(spec,t,r,cfg):
 g=Gates();limits=cfg['gates'];p=site_permutation(t,r,spec);Kt=array(t['K'],(8,8));Kr=array(r['K'],(8,8))[np.ix_(p,p)];g.error('independent full K',Kt,Kr,limits['hamiltonian_abs'])
 if spec['kind']=='torus':
  if len(t['fourier'])!=4 or len(r['fourier'])!=4:raise ValueError('Missing full torus momentum grid')
  matched=set()
  for i,row in enumerate(t['fourier']):
   g.check(f'actual native Fourier block{i}/imaginary component',row['maximum_imaginary_component'],'le',limits['hamiltonian_abs'])
   choices=[(j,other) for j,other in enumerate(r['fourier']) if np.max(abs(np.angle(np.exp(1j*(np.asarray(row['k'])-other['k'])))))<1e-10]
   if len(choices)!=1 or choices[0][0] in matched:raise ValueError('Torus momentum map ambiguous/incomplete')
   j,other=choices[0];matched.add(j);g.error(f'actual native Fourier block{i}/independent Bloch',array(row['Hk'],(2,2)),array(other['Hk'],(2,2)),limits['hamiltonian_abs'])
 elif t['fourier'] or r['fourier']:raise ValueError('Open cluster misrepresented as translation invariant')
 expected=cfg['spin_sectors']
 for producer in [t,r]:
  if [[s['Nup'],s['Ndown']] for s in producer['sectors']]!=expected or [s['dimension'] for s in producer['sectors']]!=cfg['sector_dimensions']:raise ValueError('Full canonical sector grid absent')
 for st,sr in zip(t['sectors'],r['sectors']):
  name=f"sector({st['Nup']},{st['Ndown']})";indices,signs=fock_mapping(st,sr,p);Ht=sector_matrix(st);Hr=sector_matrix(sr)[np.ix_(indices,indices)]*signs[:,None]*signs[None,:];g.error(name+'/complete physical H',Ht,Hr,limits['hamiltonian_abs']);g.error(name+'/all eigenenergies',st['energies'],sr['energies'],limits['eigenenergy_abs'])
  for backend,row in [('native',st),('QuSpin',sr)]:
   g.check(name+'/'+backend+'/eigen residual',row['eigen_residual_scaled'],'le',limits['eigen_residual_scaled']);g.check(name+'/'+backend+'/orthogonality',row['orthogonality_abs'],'le',limits['orthogonality_abs']);g.error(name+'/'+backend+'/Hermiticity',sector_matrix(row),sector_matrix(row).T,limits['hamiltonian_abs'],'qualification')
 # Full energy-cluster projectors, never a chosen vector in a degenerate shell.
 tc=t['onebody_spectral_clusters'];rc=r['onebody_spectral_clusters']
 if len(tc)!=len(rc) or sum(c['rank'] for c in tc)!=8 or sum(c['rank'] for c in rc)!=8:raise ValueError('One-body spectral cluster grid differs')
 for i,(a,b) in enumerate(zip(tc,rc)):
  g.check(f'cluster{i}/multiplicity',a['rank'],'eq',b['rank'],'comparison');g.check(f'cluster{i}/energy',abs(a['energy']-b['energy']),'le',limits['eigenenergy_abs'],'comparison');g.error(f'cluster{i}/complete projector',array(a['projector'],(8,8)),array(b['projector'],(8,8))[np.ix_(p,p)],limits['spectral_projector_abs']);g.check(f'cluster{i}/orbital spectral mixing weight',abs(a['mixing_weight_per_cell']-b['mixing_weight_per_cell']),'le',limits['spectral_mixing_weight_abs'],'comparison')
 for backend,obj in [('native',t),('QuSpin',r)]:
  clusters=obj['onebody_spectral_clusters'];Psum=np.zeros((8,8));Ksum=np.zeros((8,8))
  for i,c in enumerate(clusters):
   P=array(c['projector'],(8,8));Psum+=P;Ksum+=c['energy']*P;g.error(f'{backend}/cluster{i}/idempotent',P@P,P,limits['spectral_projector_abs'],'qualification');g.error(f'{backend}/cluster{i}/Hermitian',P,P.T,limits['spectral_projector_abs'],'qualification');g.check(f'{backend}/cluster{i}/rank trace',abs(np.trace(P)-c['rank']),'le',limits['normalization_abs']);g.check(f'{backend}/cluster{i}/nonnegative weight',c['mixing_weight_per_cell'],'ge',-limits['spectral_mixing_weight_abs']);weight=np.sum(P[np.ix_(cfg['orbital_A_zero_based'],cfg['orbital_B_zero_based'])]**2)/4;g.check(f'{backend}/cluster{i}/actual projector weight',abs(weight-c['mixing_weight_per_cell']),'le',limits['spectral_mixing_weight_abs'])
   if i:g.check(f'{backend}/cluster{i}/separated energy shells',c['energy']-clusters[i-1]['energy'],'gt',limits['onebody_intercluster_gap_min'])
  g.error(backend+'/complete spectral resolution',Psum,np.eye(8),limits['spectral_projector_abs'],'qualification')
  g.error(backend+'/full K from complete spectral projectors',Ksum,array(obj['K'],(8,8)),limits['spectral_projector_abs'],'qualification')
  obs=obj['observables'];energies=np.concatenate([array(s['energies'],(s['dimension'],)) for s in obj['sectors']]);emin=np.min(energies);Z=sum(np.exp(-cfg['beta']*(energies-emin)));g.check(backend+'/canonical logZ',abs(math.log(Z)-cfg['beta']*emin-obs['logZ']),'le',limits['normalization_abs']);g.check(backend+'/complete thermal normalization',abs(obs['normalization']-1),'le',limits['normalization_abs']);g.check(backend+'/canonical total particle number',abs(sum(obs['density'])-4),'le',limits['normalization_abs']);g.check(backend+'/all-sector thermal probability',abs(sum(s['canonical_sector_probability'] for s in obj['sectors'])-1),'le',limits['normalization_abs']);g.check(backend+'/zero field spin mean',float(np.max(abs(array(obs['Sz'],(8,))))),'le',limits['normalization_abs']);g.error(backend+'/physical spin rotation',array(obs['Sdot_connected'],(8,8)),3*array(obs['Czz'],(8,8)),limits['spin_rotation_abs'],'qualification');g.check(backend+'/fixed N charge covariance sum',abs(float(np.sum(array(obs['Cnn'],(8,8))))),'le',limits['normalization_abs'])
  no_mixing=obj['geometry']=='periodic2x2' or obj['t4']==0
  for metric in ['orbital_number_commutator_maxabs','orbital_transfer_second_moment_per_cell']:
   g.check(backend+'/'+metric+('/conserved zero' if no_mixing else '/retained finite mixing'),obs[metric],'le' if no_mixing else 'gt',limits['conserved_orbital_zero_abs'] if no_mixing else limits['noncancelling_transfer_min'])
  weight=sum(c['mixing_weight_per_cell'] for c in clusters);g.check(backend+'/total spectral mixing'+('/zero' if no_mixing else '/retained'),weight,'le' if no_mixing else 'gt',limits['conserved_orbital_zero_abs'] if no_mixing else limits['noncancelling_transfer_min'])
  if no_mixing:
   for name in ['onebody_up','onebody_down']:g.check(backend+'/'+name+'/orbital coherence zero',float(np.max(abs(array(obs[name],(8,8))[np.ix_(cfg['orbital_A_zero_based'],cfg['orbital_B_zero_based'])]))),'le',limits['conserved_orbital_zero_abs'])
  if obj['U']==0:
   levels=np.linalg.eigvalsh(array(obj['K'],(8,8)));coeff=np.zeros(5);coeff[0]=1.
   for e in np.repeat(levels,2):
    for k in range(4,0,-1):coeff[k]+=coeff[k-1]*np.exp(-cfg['beta']*e)
   g.check(backend+'/independent free canonical logZ',abs(np.log(coeff[4])-obs['logZ']),'le',limits['free_canonical_logZ_abs'])
 for field in ['density','Sz']:g.error('independent/'+field,array(t['observables'][field],(8,)),array(r['observables'][field],(8,))[p],limits['thermal_observable_abs'])
 for field in ['onebody_up','onebody_down','Cnn','Czz','Sdot_connected']:g.error('independent/full '+field,array(t['observables'][field],(8,8)),array(r['observables'][field],(8,8))[np.ix_(p,p)],limits['thermal_observable_abs'])
 for field in ['energy','logZ','orbital_coherence_per_cell','orbital_transfer_second_moment_per_cell','orbital_number_commutator_maxabs']:g.check('independent/'+field,abs(t['observables'][field]-r['observables'][field]),'le',limits['thermal_observable_abs'],'comparison')
 # The explicit 16 cross correlations are retained, never required to vanish.
 A=cfg['orbital_A_zero_based'];B=cfg['orbital_B_zero_based']
 for backend,obj in [('native',t),('QuSpin',r)]:
  for cross,full in [('cross_Cnn','Cnn'),('cross_Sdot','Sdot_connected')]:g.error(backend+'/'+cross+'/complete16',array(obj['observables'][cross],(4,4)),array(obj['observables'][full],(8,8))[np.ix_(A,B)],limits['normalization_abs'],'qualification')
 if spec['kind']=='torus':g.error('independent Bloch Fourier full K',array(r['bloch_reconstructed_K'],(8,8)),array(r['K'],(8,8)),limits['hamiltonian_abs'],'qualification')
 reasons=[x for x in g.rows if not x['passed']];quality=any(x['kind']=='qualification' for x in reasons)
 return dict(id=t['id'],status='UNRESOLVED' if quality else ('FAIL' if reasons else 'PASS'),mode_mapping_native_to_reference=p,gates=g.rows,cross_charge_not_zero_assumed=False)

def main():
 p=argparse.ArgumentParser();p.add_argument('--target',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--report-markdown',type=Path);p.add_argument('--execution-admitted',action='store_true');a=p.parse_args()
 if a.output.exists() or (a.report_markdown is not None and a.report_markdown.exists()):raise ValueError('No overwrite')
 if a.execution_admitted:
  from admission import require_child
  require_child('comparator',str(a.output),'full')
 from workflow import source_contract
 cfg,closed_source=source_contract();t=load(a.target);r=load(a.reference);out=dict(schema='X19_FULL_COMPARISON_V2',catalogue_id='X19',mode='full',job_id=t.get('job_id'),catalogue_status='UNRESOLVED',scientific_completions=0,pilot_excluded=False,full_report_complete=False)
 try:
  if t['schema']!='X19_NATIVE_THERMAL_RAW_V1' or r['schema']!='X19_QUSPIN_THERMAL_RAW_V1' or t['mode']!=r['mode'] or t['mode']!='full' or t['job_id']!=r['job_id'] or not str(t['job_id']).isdigit():raise ValueError('Wrong producer/full mode/job')
  source={n:h for h,n in (line.split('  ',1) for line in (HERE/'SHA256SUMS').read_text().splitlines())}
  if source!=closed_source or any(sha(HERE/n)!=h for n,h in source.items()) or t['source_sha256']!=source or r['source_sha256']!=source or t['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or r['source_freeze_sha256']!=sha(HERE/'source_freeze.json'):raise ValueError('Frozen source identity differs')
  lib=load(HERE/'reference_library_pins.json');pc=load(HERE/'pilot_contract.json');ad=t['full_admission']
  required={'admission_sha256','root_approval_sha256','pilot_assessment_sha256','pilot_audit_sha256','original_pilot_source_freeze_sha256','original_pilot_job_id'}
  if ad!=r['full_admission'] or set(ad)!=required or any(not isinstance(ad[k],str) or (k!='original_pilot_job_id' and (len(ad[k])!=64 or any(x not in '0123456789abcdef' for x in ad[k]))) for k in required) or ad['pilot_audit_sha256']!=pc['independent_audit_sha256'] or ad['original_pilot_job_id']!=pc['job_id'] or ad['original_pilot_source_freeze_sha256']!=pc['source_freeze_sha256']:raise ValueError('Original pilot/source/full-run admission binding differs')
  if t['native_source_sha256']!=cfg['native_source_hashes'] or t['julia_version']!=cfg['runtime_julia'] or r['python_version']!=cfg['runtime_python'] or r['versions']!={'quspin':cfg['quspin_version'],'quspin-extensions':cfg['quspin_extensions_version'],'numpy':cfg['numpy_version'],'scipy':cfg['scipy_version']} or r['reference_library_sha256']!=lib['files'] or r['reference_library_pins_sha256']!=sha(HERE/'reference_library_pins.json'):raise ValueError('Unpinned actual native/reference/runtime')
  expected=expected_grid(cfg);ids=[x[3] for x in expected]
  if len(ids)!=12 or len(set(ids))!=12 or [x['id'] for x in t['cases']]!=ids or [x['id'] for x in r['cases']]!=ids:raise ValueError('Incomplete registered12case full grid')
  rows=[]
  for (spec,U,t4,ident),tt,rr in zip(expected,t['cases'],r['cases']):
   if (tt['id'],tt['geometry'],tt['U'],tt['t4'])!=(ident,spec['id'],U,t4) or (rr['id'],rr['geometry'],rr['U'],rr['t4'])!=(ident,spec['id'],U,t4):raise ValueError('Original registered model arm differs')
   rows.append(one_case(spec,tt,rr,cfg))
  report=build_full_report(t,r,rows,cfg,site_permutation);status='UNRESOLVED' if any(x['status']=='UNRESOLVED' for x in rows) else ('FAIL' if any(x['status']=='FAIL' for x in rows) else 'PASS');out.update(status=status,catalogue_status=status,scientific_completions=int(status=='PASS'),cases=rows,source_freeze_sha256=sha(HERE/'source_freeze.json'),raw_sha256={'target':sha(a.target),'reference':sha(a.reference)},full_admission=ad,full_report_complete=True,full_report=report,scope='One X19 question;12 mandatory fixtures. Kinetic projectors/moments describe geometry mixing and are not interacting Lehmann spectra. Interacting evidence is the complete canonical physical correlations/coherence/transfer. No cross-geometry equality or bulk inference.')
  if a.report_markdown is not None:write_markdown(a.report_markdown,report,status)
 except Exception as ex:out.update(status='UNRESOLVED',catalogue_status='UNRESOLVED',scientific_completions=0,reason=type(ex).__name__+': '+str(ex),cases=[])
 with a.output.open('x') as f:json.dump(plain(out),f,indent=2,allow_nan=False);f.write('\n')
 print(json.dumps({k:out[k] for k in ['status','catalogue_status','scientific_completions']}));sys.exit({'PASS':0,'FAIL':1,'UNRESOLVED':2}[out['status']])
if __name__=='__main__':main()
