"""Complete descriptive X19 contrasts. No cross-geometry equality hypothesis."""
import itertools,math
import numpy as np
def fixed_id(geometry,U,t4):return f"{geometry}_U{int(U)}_t4{'0' if t4==0 else 'm065'}"
def expected_grid(cfg):return [(g,U,t4,fixed_id(g['id'],U,t4)) for g,U,t4 in itertools.product(cfg['geometries'],cfg['U_arms'],cfg['t4_arms'])]
def finite(x):
 a=np.asarray(x,float)
 if not np.all(np.isfinite(a)):raise ValueError('Nonfinite report input')
 return a
def case_measure(raw,cfg,p=None):
 p=list(range(8)) if p is None else list(p);o=raw['observables'];A=cfg['orbital_A_zero_based'];B=cfg['orbital_B_zero_based'];matrix_names=['onebody_up','onebody_down','Cnn','Czz','Sdot_connected'];obs={k:finite(o[k])[np.ix_(p,p)] for k in matrix_names};obs.update({k:finite(o[k])[p] for k in ['density','Sz']});obs.update({k:float(o[k]) for k in ['energy','logZ','orbital_coherence_per_cell','orbital_transfer_second_moment_per_cell','orbital_number_commutator_maxabs']});obs['cross_Cnn']=obs['Cnn'][np.ix_(A,B)];obs['cross_Sdot']=obs['Sdot_connected'][np.ix_(A,B)]
 K=finite(raw['K'])[np.ix_(p,p)];power=np.eye(8);moments=[]
 for n in range(1,5):power=power@K;moments.append(float(np.trace(power)/8))
 spectra=[dict(energy=float(s['energy']),rank=int(s['rank']),projector=finite(s['projector'])[np.ix_(p,p)],mixing_weight_per_cell=float(s['mixing_weight_per_cell'])) for s in raw['onebody_spectral_clusters']]
 summary=dict(integrated_onebody_mixing_weight_per_cell=sum(s['mixing_weight_per_cell'] for s in spectra),kinetic_spectral_moments_1_to_4=moments,orbital_coherence_per_cell=obs['orbital_coherence_per_cell'],orbital_transfer_second_moment_per_cell=obs['orbital_transfer_second_moment_per_cell'],orbital_number_commutator_maxabs=obs['orbital_number_commutator_maxabs'],cross_charge_covariance_sum=float(np.sum(obs['cross_Cnn'])),cross_physical_spin_connected_sum=float(np.sum(obs['cross_Sdot'])),onsite_cross_orbital_charge_mean=float(np.trace(obs['cross_Cnn'])/4),onsite_cross_orbital_physical_spin_mean=float(np.trace(obs['cross_Sdot'])/4),orbital_x_density_mean=float(np.mean(obs['density'][A])),orbital_y_density_mean=float(np.mean(obs['density'][B])),energy_per_cell=obs['energy']/4,canonical_logZ_per_cell=obs['logZ']/4)
 return dict(id=raw['id'],geometry=raw['geometry'],U=raw['U'],t4=raw['t4'],own_physical_cells=raw['cells'],mode_labels=[dict(cell=raw['cells'][i//2],orbital='x' if i%2==0 else 'y') for i in range(8)],K=K,actual_fourier_blocks=raw['fourier'],observables=obs,invariant_summaries=summary,onebody_complete_energy_cluster_measure=spectra,manybody_complete_sector_spectra=[dict(Nup=s['Nup'],Ndown=s['Ndown'],energies=finite(s['energies']),canonical_sector_probability=s['canonical_sector_probability']) for s in raw['sectors']])
def delta_summary(left,right):
 if left.keys()!=right.keys():raise ValueError('Summary fields incomplete')
 out={}
 for k in left:
  a=finite(left[k]);b=finite(right[k])
  if a.shape!=b.shape:raise ValueError('Invariant-summary shape differs')
  d=b-a;out[k]=float(d) if d.ndim==0 else d
 return out
def build_full_report(target,reference,rows,cfg,site_permutation):
 expected=expected_grid(cfg);ids=[x[3] for x in expected]
 if len(ids)!=12 or len(set(ids))!=12 or [r['id'] for r in rows]!=ids:raise ValueError('Full12case report grid incomplete')
 native={c['id']:case_measure(c,cfg) for c in target['cases']};external={}
 for t,r,row in zip(target['cases'],reference['cases'],rows):
  p=row['mode_mapping_native_to_reference'];m=case_measure(r,cfg,p);m['reference_original_physical_cells']=r['cells'];m['own_physical_cells']=t['cells'];m['mode_labels']=native[t['id']]['mode_labels'];external[t['id']]=m
 report=dict(schema='X19_COMPLETE_GEOMETRY_CONTRASTS_V2',comparison_scope='Every geometry compared to independent QuSpin at its own model; descriptive contrasts never assert equality across different geometries.',summary_formulas=dict(integrated_onebody_mixing_weight_per_cell='sum over all complete kinetic energy clusters of ||P_cluster[A,B]||F^2/4; NOT interacting Lehmann spectral weight',kinetic_spectral_moments_1_to_4='Tr(K^p)/8 for p=1,2,3,4 using full actual8mode K',orbital_coherence_per_cell='(||C_up[A,B]||F^2+||C_down[A,B]||F^2)/4',orbital_transfer_second_moment_per_cell='<[H,NA]†[H,NA]>/4',cross_charge_covariance_sum='sum_i_in_A,j_in_B connected<n_i n_j>=Cov(NA,NB); canonical fixedN generally permits a nonzero value even without hybridization',cross_physical_spin_connected_sum='sum_i_in_A,j_in_B <Si dot Sj>_connected',onsite_cross_orbital_charge_mean='mean over four physical cells of connected<n_rx n_ry>',onsite_cross_orbital_physical_spin_mean='mean over four physical cells of <S_rx dot S_ry>_connected',energy_and_logZ='total energy/canonical logZ divided by four cells'),cross_geometry_array_subtraction=False,cross_geometry_shell_pairing=False,cross_geometry_equality_gate=False,all_summaries_invariant_under_cell_relabeling=True,onebody_measures_are_not_interacting_Lehmann_functions=True,backends={})
 for backend,cases in [('actual_native',native),('independent_QuSpin_in_native_physical_order',external)]:
  geo=[];hybrid=[]
  for U,t4 in itertools.product(cfg['U_arms'],cfg['t4_arms']):
   for a,b in itertools.combinations(cfg['geometries'],2):
    l=cases[fixed_id(a['id'],U,t4)];r=cases[fixed_id(b['id'],U,t4)];geo.append(dict(left_id=l['id'],right_id=r['id'],difference_direction='right minus left',U=U,t4=t4,finite_geometry_bias_only=True,delta_invariant_summaries=delta_summary(l['invariant_summaries'],r['invariant_summaries']),complete_arrays_and_spectral_measures_retained_by_case_id=[l['id'],r['id']],own_coordinates_required=True,equality_gate=False))
  for spec,U in itertools.product(cfg['geometries'],cfg['U_arms']):
   off=cases[fixed_id(spec['id'],U,0.)];on=cases[fixed_id(spec['id'],U,-.65)];p=site_permutation(dict(cells=on['own_physical_cells']),dict(cells=off['own_physical_cells']),spec);delta={}
   for k,v in on['observables'].items():
    left=finite(off['observables'][k]);right=finite(v)
    if left.ndim==2:
     if left.shape==(8,8):left=left[np.ix_(p,p)]
     elif left.shape==(4,4):
      cellp=[p[i]//2 for i in range(0,8,2)];left=left[np.ix_(cellp,cellp)]
     else:raise ValueError('Unregistered within-geometry array shape')
    elif left.ndim==1:left=left[p]
    d=right-left;delta[k]=float(d) if d.ndim==0 else d
   hybrid.append(dict(geometry=spec['id'],U=U,off_id=off['id'],on_id=on['id'],difference_direction='t4=-0.65 minus t4=0',exact_on_to_off_physical_mode_map=p,on_own_physical_cells=on['own_physical_cells'],off_own_physical_cells=off['own_physical_cells'],delta_full_observables=delta,delta_full_K=on['K']-off['K'][np.ix_(p,p)],delta_invariant_summaries=delta_summary(off['invariant_summaries'],on['invariant_summaries']),complete_separate_spectral_measures_retained_by_case_id=[off['id'],on['id']],no_assumed_energy_shell_pairing=True,equality_gate=False))
  if len(geo)!=12 or len(hybrid)!=6:raise ValueError('Missing geometry/onoff contrast')
  report['backends'][backend]=dict(complete_cases=[cases[k] for k in ids],same_U_t4_geometry_contrasts=geo,within_geometry_t4_on_off_contrasts=hybrid)
 return report
def write_markdown(path,report,status):
 lines=['# X19 full finite-geometry comparison','',f'Status: **{status}**. All12 registered cases are mandatory for one X19 completion.','', 'The complete JSON report retains every array with its own coordinates, both independent backends and complete separate spectral measures. Different geometries are compared only through the named invariant summaries below. Their differences are finite-geometry bias, with no equality or bulk claim.','']
 keys=['integrated_onebody_mixing_weight_per_cell','orbital_coherence_per_cell','orbital_transfer_second_moment_per_cell','cross_charge_covariance_sum','cross_physical_spin_connected_sum','onsite_cross_orbital_charge_mean','onsite_cross_orbital_physical_spin_mean']
 for backend,data in report['backends'].items():
  lines+=['## '+backend,'','|case|'+ '|'.join(keys)+'|','|---|'+'---:|'*len(keys)]
  for case in data['complete_cases']:lines+=['|'+case['id']+'|'+'|'.join(format(float(case['invariant_summaries'][k]),'.10g') for k in keys)+'|']
  lines+=['','### All same-U/t4 geometry differences','', 'Right minus left; each full matrix/spectral measure keeps its own coordinates.','', '|left|right|'+ '|'.join(keys)+'|','|---|---|'+'---:|'*len(keys)]
  for row in data['same_U_t4_geometry_contrasts']:lines+=['|'+row['left_id']+'|'+row['right_id']+'|'+'|'.join(format(float(row['delta_invariant_summaries'][k]),'.10g') for k in keys)+'|']
  lines+=['','### All within-geometry hybridization responses','', 't4=-0.65 minus t4=0. Full-array differences use the exact own-geometry cell map, saved in JSON. Spectral measures are kept separately without pairing shells.','', '|off|on|'+ '|'.join(keys)+'|','|---|---|'+'---:|'*len(keys)]
  for row in data['within_geometry_t4_on_off_contrasts']:lines+=['|'+row['off_id']+'|'+row['on_id']+'|'+'|'.join(format(float(row['delta_invariant_summaries'][k]),'.10g') for k in keys)+'|']
  lines+=['','The JSON additionally retains Tr(K^p)/8 for p=1..4, their contrasts, energy/logZ per cell, orbital mean densities, every complete Cnn/physical Sdot/coherence array and all canonical sector eigenenergies.','']
 with path.open('x') as f:f.write('\n'.join(lines)+'\n')
