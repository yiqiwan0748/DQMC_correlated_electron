#!/usr/bin/env python3
"""Independent finite quotients, Bloch/Fourier construction, QuSpin canonical trace."""
import argparse,contextlib,hashlib,importlib.metadata,io,itertools,json,math,os,platform,tomllib
from fractions import Fraction
import sys
from admission import require_child
FULL_ADMISSION=require_child("reference",sys.argv[2] if len(sys.argv)==3 else "",sys.argv[1] if len(sys.argv)==3 else "")
from pathlib import Path
for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[n]='1'
import numpy as np
from scipy.linalg import eigh
from quspin.basis import spinful_fermion_basis_1d
from quspin.operators import hamiltonian
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def plain(x):
 if isinstance(x,dict):return {str(k):plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [plain(v) for v in x]
 return x.item() if isinstance(x,np.generic) else x

def pins():
 if not (HERE/'source_freeze.json').is_file():raise ValueError('Unfrozen proposal; execution prohibited')
 source={n:h for h,n in (line.split('  ',1) for line in (HERE/'SHA256SUMS').read_text().splitlines())}
 if any(sha(HERE/n)!=h for n,h in source.items()):raise ValueError('Changed frozen source')
 library=json.loads((HERE/'reference_library_pins.json').read_text());observed={}
 if library['python_version']!=platform.python_version():raise ValueError('Reference Python differs')
 for name,spec in library['distributions'].items():
  dist=importlib.metadata.distribution(name);names=sorted(str(p) for p in dist.files if str(p).endswith('.py') or '.so' in p.name or p.name=='RECORD')
  if names!=spec['files'] or dist.version!=spec['version']:raise ValueError('Installed reference closure differs')
  for n in names:
   p=dist.locate_file(n)
   if p.stat().st_size!=library['bytes'][n]:raise ValueError('Reference size differs')
   observed[n]=sha(p)
 if observed!=library['files']:raise ValueError('Installed reference hashes differ before computation')
 return source,observed

def quotient_key(cell,a1,a2):
 x,y=cell;D=a1[0]*a2[1]-a2[0]*a1[1]
 return (Fraction(a2[1]*x-a2[0]*y,D)%1,Fraction(-a1[1]*x+a1[0]*y,D)%1)

def torus(spec):
 a1,a2=spec['a1'],spec['a2'];D=a1[0]*a2[1]-a2[0]*a1[1];N=abs(D);cells=[];lookup={}
 for x,y in itertools.product(range(N),repeat=2):
  key=quotient_key((x,y),a1,a2)
  if key not in lookup:lookup[key]=len(cells);cells.append((x,y))
 if len(cells)!=N:raise ValueError('Independent quotient incomplete')
 momenta=set()
 for n,m in itertools.product(range(N),repeat=2):
  momenta.add((Fraction(a2[1]*n-a1[1]*m,D)%1,Fraction(-a2[0]*n+a1[0]*m,D)%1))
 if len(momenta)!=N:raise ValueError('Independent dual quotient incomplete')
 return cells,lookup,[(2*np.pi*float(a),2*np.pi*float(b)) for a,b in sorted(momenta)]

def bloch(k,cfg,t4):
 x,y=k;a=-2*cfg['t1']*np.cos(x)-2*cfg['t2']*np.cos(y)-4*cfg['t3']*np.cos(x)*np.cos(y);b=-2*cfg['t2']*np.cos(x)-2*cfg['t1']*np.cos(y)-4*cfg['t3']*np.cos(x)*np.cos(y);v=-4*t4*np.sin(x)*np.sin(y)
 return np.array([[a,v],[v,b]])

def geometry(spec,cfg,t4):
 if spec['kind']=='open':cells=[(x,y) for y in range(2) for x in range(2)];lookup={c:i for i,c in enumerate(cells)};momenta=[]
 else:cells,lookup,momenta=torus(spec)
 K=np.zeros((8,8));bonds=[(1,0,np.diag([-cfg['t1'],-cfg['t2']])),(0,1,np.diag([-cfg['t2'],-cfg['t1']])),(1,1,np.array([[-cfg['t3'],t4],[t4,-cfg['t3']]])),(1,-1,np.array([[-cfg['t3'],-t4],[-t4,-cfg['t3']]]))]
 for i,(x,y) in enumerate(cells):
  for dx,dy,T in bonds:
   dest=(x+dx,y+dy);key=dest if spec['kind']=='open' else quotient_key(dest,spec['a1'],spec['a2'])
   if key not in lookup:continue
   j=lookup[key];K[2*i:2*i+2,2*j:2*j+2]+=T;K[2*j:2*j+2,2*i:2*i+2]+=T.T
 rows=[dict(k=k,Hk=bloch(k,cfg,t4)) for k in momenta];KF=np.zeros((8,8),complex)
 for row in rows:
  for i,r in enumerate(cells):
   for j,s in enumerate(cells):KF[2*i:2*i+2,2*j:2*j+2]+=np.exp(1j*np.dot(row['k'],np.subtract(r,s)))*row['Hk']/4
 if rows and max(np.max(abs(KF.imag)),np.max(abs(KF.real-K)))>cfg['gates']['hamiltonian_abs']:raise ValueError('Independent bond/Bloch construction mismatch')
 return K,cells,rows,KF.real if rows else None

def op(b,terms):
 with contextlib.redirect_stdout(io.StringIO()):return hamiltonian(terms,[],basis=b,dtype=np.float64,check_herm=False,check_symm=False,check_pcon=False).tocsr()
def labels(b):
 return [(sum(((int(s)>>(15-i))&1)<<i for i in range(8)),sum(((int(s)>>(7-i))&1)<<i for i in range(8))) for s in b.states]
def coo(A):
 i,j=np.nonzero(A);return dict(shape=list(A.shape),row=i,col=j,value=A[i,j])
def spectral(K,cfg):
 es,V=eigh(K);rows=[];i=0;A=cfg['orbital_A_zero_based'];B=cfg['orbital_B_zero_based']
 while i<8:
  j=i+1
  while j<8 and es[j]-es[i]<=cfg['gates']['onebody_cluster_diameter']:j+=1
  P=V[:,i:j]@V[:,i:j].T;rows.append(dict(energy=float(np.mean(es[i:j])),rank=j-i,projector=P,mixing_weight_per_cell=float(np.sum(P[np.ix_(A,B)]**2)/4)));i=j
 return rows

def physical_operators(cfg):
 b=spinful_fermion_basis_1d(8,Nf=[tuple(s) for s in cfg['spin_sectors']]);ls=labels(b);lookup={p:i for i,p in enumerate(ls)}
 up=np.array([[(u>>i)&1 for u,d in ls] for i in range(8)],float);dn=np.array([[(d>>i)&1 for u,d in ls] for i in range(8)],float)
 for i in range(8):
  if not np.array_equal(op(b,[['n|',[[1.,i]]]]).diagonal(),up[i]) or not np.array_equal(op(b,[['|n',[[1.,i]]]]).diagonal(),dn[i]):raise ValueError('Independent physical mask interpretation differs')
 plus=[op(b,[['+|-',[[1.,i,i]]]]) for i in range(8)];minus=[s.T for s in plus]
 spin=[[.5*(plus[i]@minus[j]+minus[i]@plus[j]) for j in range(8)] for i in range(8)]
 cup=[[op(b,[['+-|',[[1.,i,j]]]]) for j in range(8)] for i in range(8)];cdn=[[op(b,[['|+-',[[1.,i,j]]]]) for j in range(8)] for i in range(8)]
 return dict(lookup=lookup,spin=spin,cup=cup,cdn=cdn)

def sector(K,U,nu,nd):
 b=spinful_fermion_basis_1d(8,Nf=(nu,nd));hop=[[float(K[i,j]),int(i),int(j)] for i,j in zip(*np.nonzero(K))];H=op(b,[['+-|',hop],['|+-',hop],['z|z',[[U,i,i] for i in range(8)]]]).toarray();es,V=eigh(H);scale=max(1.,np.linalg.norm(H,np.inf));ls=labels(b)
 saved=dict(Nup=nu,Ndown=nd,dimension=b.Ns,basis_up_per_row=[u for u,d in ls],basis_down_per_row=[d for u,d in ls],H=coo(H),energies=es,eigen_residual_scaled=float(np.max(np.linalg.norm(H@V-V*es,axis=0))/scale),orthogonality_abs=float(np.max(abs(V.T@V-np.eye(b.Ns)))),operator_scale=float(scale))
 return dict(saved=saved,H=H,E=es,V=V,labels=ls)

def thermal(blocks,cfg,ops):
 emin=min(float(b['E'][0]) for b in blocks);weights=[np.exp(-cfg['beta']*(b['E']-emin)) for b in blocks];Z=sum(np.sum(w) for w in weights);mean=np.zeros(8);zm=np.zeros(8);nn=np.zeros((8,8));zz=nn.copy();sd=nn.copy();cup=nn.copy();cdn=nn.copy();energy=0.;norm=0.;transfer=0.;commmax=0.
 for b,w in zip(blocks,weights):
  w=w/Z;rho=(b['V']*w)@b['V'].T;p=np.diag(rho);up=np.array([[(u>>i)&1 for u,d in b['labels']] for i in range(8)],float);dn=np.array([[(d>>i)&1 for u,d in b['labels']] for i in range(8)],float);n=up+dn;z=(up-dn)/2;mean+=n@p;zm+=z@p;nn+=(n*p)@n.T;zz+=(z*p)@z.T;sd+=(z*p)@z.T
  idx=[ops['lookup'][p] for p in b['labels']]
  for i,j in itertools.product(range(8),repeat=2):
   for name,arr in [('spin',sd),('cup',cup),('cdn',cdn)]:
    A=ops[name][i][j][idx,:][:,idx].tocoo();arr[i,j]+=np.dot(A.data,rho[A.col,A.row])
  NA=np.array([sum(((u>>i)&1)+((d>>i)&1) for i in cfg['orbital_A_zero_based']) for u,d in b['labels']],float);comm=b['H']*(NA[None,:]-NA[:,None]);commmax=max(commmax,float(np.max(abs(comm))));transfer+=np.dot(w,np.sum((comm@b['V'])**2,axis=0))/4;energy+=np.dot(w,b['E']);norm+=np.sum(w);b['saved']['canonical_sector_probability']=float(np.sum(w))
 nn-=np.outer(mean,mean);zz-=np.outer(zm,zm);sd-=np.outer(zm,zm);A=cfg['orbital_A_zero_based'];B=cfg['orbital_B_zero_based']
 return dict(normalization=norm,logZ=np.log(Z)-cfg['beta']*emin,energy=energy,density=mean,Sz=zm,onebody_up=cup,onebody_down=cdn,Cnn=nn,Czz=zz,Sdot_connected=sd,cross_Cnn=nn[np.ix_(A,B)],cross_Sdot=sd[np.ix_(A,B)],orbital_coherence_per_cell=(np.sum(cup[np.ix_(A,B)]**2)+np.sum(cdn[np.ix_(A,B)]**2))/4,orbital_transfer_second_moment_per_cell=transfer,orbital_number_commutator_maxabs=commmax)

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['full']);p.add_argument('output',type=Path);a=p.parse_args()
 if a.output.exists() or not os.getenv('SLURM_JOB_ID'):raise ValueError('New compute-job output required')
 cfg=tomllib.loads((HERE/'manifest.toml').read_text());source,library=pins();versions={n:importlib.metadata.version(n) for n in ['quspin','quspin-extensions','numpy','scipy']}
 if versions!={'quspin':cfg['quspin_version'],'quspin-extensions':cfg['quspin_extensions_version'],'numpy':cfg['numpy_version'],'scipy':cfg['scipy_version']} or platform.python_version()!=cfg['runtime_python']:raise ValueError('Runtime version differs')
 ops=physical_operators(cfg);rows=[]
 for geo,U,t4 in itertools.product(cfg['geometries'],cfg['U_arms'],cfg['t4_arms']):
  ident=f"{geo['id']}_U{int(U)}_t4{'0' if t4==0 else 'm065'}"
  K,cells,fourier,KF=geometry(geo,cfg,t4);blocks=[sector(K,U,nu,nd) for nu,nd in cfg['spin_sectors']];obs=thermal(blocks,cfg,ops);rows.append(dict(id=ident,geometry=geo['id'],U=U,t4=t4,cells=cells,K=K,fourier=fourier,bloch_reconstructed_K=KF,onebody_spectral_clusters=spectral(K,cfg),sectors=[b['saved'] for b in blocks],observables=obs))
 if len(rows)!=12:raise ValueError('Complete12case grid required')
 admission=dict(admission_sha256=sha(Path(os.environ['X19_EXECUTION_ADMISSION'])),**{k:v for k,v in FULL_ADMISSION['bindings'].items() if isinstance(v,str)})
 raw=dict(schema='X19_QUSPIN_THERMAL_RAW_V1',mode=a.mode,job_id=os.environ['SLURM_JOB_ID'],python_version=platform.python_version(),versions=versions,scientific_completions=0,source_sha256=source,source_freeze_sha256=sha(HERE/'source_freeze.json'),reference_library_sha256=library,reference_library_pins_sha256=sha(HERE/'reference_library_pins.json'),full_admission=admission,cases=rows)
 with a.output.open('x') as f:json.dump(plain(raw),f,indent=2,allow_nan=False);f.write('\n')
if __name__=='__main__':main()
