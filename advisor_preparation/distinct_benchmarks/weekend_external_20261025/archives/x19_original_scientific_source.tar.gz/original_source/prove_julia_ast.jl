#!/usr/bin/env julia
# Parse source syntax only. Never include/evaluate a scientific source file.
using SHA,TOML
length(ARGS)==3 || error("BASELINE_TARGET FULL_TARGET OUTPUT")
function definitions(path)
    tree=Meta.parseall(read(path,String))
    function valid(e)
        e isa Expr || return
        e.head in (:error,:incomplete) && error("Source parse error")
        foreach(valid,e.args)
    end
    valid(tree);Base.remove_linenums!(tree);d=Dict{String,String}()
    for e in tree.args
        e isa Expr || continue
        signature = e.head==:function ? e.args[1] : (e.head==:(=) && e.args[1] isa Expr && e.args[1].head==:call ? e.args[1] : nothing)
        signature===nothing && continue
        name=signature isa Expr ? signature.args[1] : signature
        name==:main && continue
        k=sprint(show,signature);h=bytes2hex(sha256(sprint(show,e)))
        haskey(d,k) && error("Duplicate parsed definition");d[k]=h
    end
    d
end
a=definitions(ARGS[1]);b=definitions(ARGS[2]);a==b || error("Scientific Julia definition AST changed")
ispath(ARGS[3]) && error("No overwrite")
open(ARGS[3],"w") do io
    TOML.print(io,Dict("status"=>"PASS","parser_julia_version"=>string(VERSION),"scope"=>"Meta.parseall and AST comparison only; no include or target execution","definitions"=>a))
end
