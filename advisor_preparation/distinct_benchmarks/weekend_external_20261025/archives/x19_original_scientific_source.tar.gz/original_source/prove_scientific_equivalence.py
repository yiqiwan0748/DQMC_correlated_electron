#!/usr/bin/env python3
"""Static AST/file/model equality only; no scientific imports or calculation."""
import argparse,ast,hashlib,json,subprocess,tarfile,tempfile,tomllib
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def python_definitions(text):
 tree=ast.parse(text);return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name!='main'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--baseline-archive',type=Path,required=True);p.add_argument('--julia',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();pc=json.loads((HERE/'pilot_contract.json').read_text());assert not a.output.exists();assert sha(a.baseline_archive)==pc['source_archive_sha256'];baseline={}
 with tarfile.open(a.baseline_archive) as tf:
  for m in tf.getmembers():
   assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts;parts=Path(m.name).parts;baseline[str(Path(*parts[1:]))]=tf.extractfile(m).read()
 checks=[];details={}
 for name in ['oracle_quspin.py','compare.py']:
  before=python_definitions(baseline[name].decode());after=python_definitions((HERE/name).read_text());assert before==after,name+' scientific AST changed';checks.append('Every original scientific Python function/class AST unchanged: '+name);details[name]={k:hashlib.sha256(v.encode()).hexdigest() for k,v in before.items()}
 with tempfile.TemporaryDirectory(prefix='x19_static_ast_') as tmp:
  tmp=Path(tmp);old=tmp/'target_v1.jl';old.write_bytes(baseline['target.jl']);out=tmp/'julia_ast.toml';subprocess.run([a.julia,'--startup-file=no','--history-file=no',str(HERE/'prove_julia_ast.jl'),str(old),str(HERE/'target.jl'),str(out)],check=True,capture_output=True,text=True);details['target.jl']=tomllib.loads(out.read_text());checks.append('Every original scientific Julia function/short definition AST unchanged; main/admission workflow separate')
 old=tomllib.loads(baseline['manifest.toml'].decode());new=tomllib.loads((HERE/'manifest.toml').read_text());science={k:v for k,v in old.items() if k not in ['schema','status','scientific_completion_allowed','resources']};assert science=={k:new[k] for k in science};assert set(new)-set(old)==set();checks.append('Every original model/geometry/arm/ensemble/runtime/native pin and scientific gate unchanged')
 for name in ['catalogue_X19.json','native_source_pins.json','reference_library_pins.json']+[n for n in baseline if n.startswith('source_snapshot/')]:
  assert baseline[name]==(HERE/name).read_bytes(),name+' changed';checks.append('Verbatim original '+name)
 report=dict(schema='X19_FULL_V2_SCIENTIFIC_STATIC_EQUIVALENCE_V1',status='PASS',checks=checks,check_count=len(checks),baseline_archive_sha256=sha(a.baseline_archive),baseline_source_freeze_sha256=pc['source_freeze_sha256'],details=details,source_inputs={n:sha(HERE/n) for n in ['target.jl','oracle_quspin.py','compare.py','manifest.toml','catalogue_X19.json','native_source_pins.json','reference_library_pins.json']},scientific_source_executed=False,numerical_modules_imported=False,fixture_calculations=False,source_frozen=False,job_submitted=False,scope='Full mode, workflow/admission and descriptive reporting are new; no scientific function, native implementation, registered model or numerical gate change.')
 with a.output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
if __name__=='__main__':main()
