#!/usr/bin/env julia

module TwoOrbitalTiltedClusterED

using LinearAlgebra

# Keep this feasibility module independent of the package-loading path while
# reusing the validated two-orbital Bloch convention.
module ValidatedModel
include(joinpath(@__DIR__, "..", "src", "noninteracting.jl"))
end

const ModelParameters = ValidatedModel.ModelParameters
const DEFAULT_PARAMETERS = ValidatedModel.DEFAULT_PARAMETERS
const bloch_hamiltonian = ValidatedModel.bloch_hamiltonian

export TiltedTorus,
       EDResourceLimitError,
       ModelParameters,
       DEFAULT_PARAMETERS,
       bloch_hamiltonian,
       tilted_torus,
       standard_eight_site_torus,
       allowed_torus_momenta,
       torus_single_particle_index,
       tilted_kinetic_matrix,
       torus_fourier_block,
       has_c4_symmetry,
       sector_resource_estimate,
       target_filling_feasibility,
       require_feasible_sector,
       dense_sector_hamiltonian,
       lanczos_lowest_sector

"""
    TiltedTorus

Finite quotient of the square lattice by the integer translations `a1` and
`a2`. `cells` contains one deterministic integer representative of every
coset in `Z^2/<a1,a2>`. The quotient has `abs(det([a1 a2]))` cells.
"""
struct TiltedTorus
    a1::NTuple{2,Int}
    a2::NTuple{2,Int}
    signed_determinant::Int
    ncells::Int
    cells::Vector{NTuple{2,Int}}
    signatures::Vector{NTuple{2,Int}}
    index_by_signature::Dict{NTuple{2,Int},Int}
    momentum_quantum_numbers::Vector{NTuple{2,Int}}
    momenta::Vector{NTuple{2,Float64}}
end

"""Raised before a sector basis or Krylov vector exceeds a declared limit."""
struct EDResourceLimitError <: Exception
    message::String
end
Base.showerror(io::IO, error::EDResourceLimitError) = print(io, error.message)

function _checked_vector(vector, name)
    length(vector) == 2 || throw(ArgumentError("$name must have two entries"))
    return (Int(vector[1]), Int(vector[2]))
end

function _signed_determinant(a1, a2)
    determinant = Base.checked_sub(
        Base.checked_mul(a1[1], a2[2]),
        Base.checked_mul(a2[1], a1[2]),
    )
    iszero(determinant) &&
        throw(ArgumentError("the two torus translations must be independent"))
    return determinant
end

# adj(B) * r modulo |det(B)| is an exact label for a coset, where B has
# translation vectors as columns. This avoids floating-point cell wrapping.
function _coset_signature(coordinate, a1, a2, determinant)
    x, y = coordinate
    modulus = abs(determinant)
    return (
        mod(a2[2] * x - a2[1] * y, modulus),
        mod(-a1[2] * x + a1[1] * y, modulus),
    )
end

function _coset_representatives(a1, a2)
    determinant = _signed_determinant(a1, a2)
    count = abs(determinant)
    representatives = NTuple{2,Int}[]
    signatures = NTuple{2,Int}[]
    seen = Set{NTuple{2,Int}}()
    radius = 0
    while length(representatives) < count
        for y in -radius:radius, x in -radius:radius
            max(abs(x), abs(y)) == radius || continue
            coordinate = (x, y)
            signature = _coset_signature(coordinate, a1, a2, determinant)
            signature in seen && continue
            push!(seen, signature)
            push!(representatives, coordinate)
            push!(signatures, signature)
            length(representatives) == count && break
        end
        radius += 1
    end
    return representatives, signatures
end

function _wrap_momentum(value)
    wrapped = mod(value, 2pi)
    (abs(wrapped) <= 64eps(Float64) || abs(wrapped - 2pi) <= 64eps(Float64)) &&
        return 0.0
    abs(wrapped - pi) <= 64eps(Float64) && return Float64(pi)
    return Float64(wrapped)
end

function _momentum_from_quantum_numbers(n, a1, a2, determinant)
    n1, n2 = n
    kx_numerator = a2[2] * n1 - a1[2] * n2
    ky_numerator = -a2[1] * n1 + a1[1] * n2
    return (
        _wrap_momentum(2pi * kx_numerator / determinant),
        _wrap_momentum(2pi * ky_numerator / determinant),
    )
end

"""
    tilted_torus(a1, a2)

Construct a two-dimensional integer torus. Translation vectors are columns of
the supercell matrix. Both orientations are accepted.
"""
function tilted_torus(a1=(2, 2), a2=(-2, 2))
    first_translation = _checked_vector(a1, "a1")
    second_translation = _checked_vector(a2, "a2")
    determinant = _signed_determinant(first_translation, second_translation)
    cells, signatures = _coset_representatives(
        first_translation, second_translation,
    )
    indices = Dict(signature => index for (index, signature) in enumerate(signatures))

    # Inequivalent n modulo B^T Z^2 generate k=2pi B^(-T)n.
    dual_a1 = (first_translation[1], second_translation[1])
    dual_a2 = (first_translation[2], second_translation[2])
    quantum_numbers, _ = _coset_representatives(dual_a1, dual_a2)
    momenta = [
        _momentum_from_quantum_numbers(
            n, first_translation, second_translation, determinant,
        ) for n in quantum_numbers
    ]
    permutation = sortperm(eachindex(momenta); by=index -> (
        momenta[index][1], momenta[index][2],
        quantum_numbers[index][1], quantum_numbers[index][2],
    ))
    return TiltedTorus(
        first_translation,
        second_translation,
        determinant,
        abs(determinant),
        cells,
        signatures,
        indices,
        quantum_numbers[permutation],
        momenta[permutation],
    )
end

"""The C4-symmetric eight-site torus generated by `(2,2)` and `(-2,2)`."""
standard_eight_site_torus() = tilted_torus((2, 2), (-2, 2))

"""Return all periodic momenta in `[0,2pi)^2`."""
allowed_torus_momenta(torus::TiltedTorus) = copy(torus.momenta)

function _site_index(torus::TiltedTorus, coordinate)
    signature = _coset_signature(
        coordinate, torus.a1, torus.a2, torus.signed_determinant,
    )
    return torus.index_by_signature[signature]
end

"""Orbital-fast one-spin index for a site and orbital `1` or `2`."""
function torus_single_particle_index(
    torus::TiltedTorus,
    site::Integer,
    orbital::Integer,
)
    1 <= site <= torus.ncells || throw(ArgumentError("site is outside the torus"))
    1 <= orbital <= 2 || throw(ArgumentError("orbital must be 1 or 2"))
    return 2 * (Int(site) - 1) + Int(orbital)
end

function _positive_displacement_blocks(parameters::ModelParameters{T}) where {T<:Real}
    (; t1, t2, t3, t4) = parameters
    z = zero(T)
    return (
        (1, 0, T[-t1 z; z -t2]),
        (0, 1, T[-t2 z; z -t1]),
        (1, 1, T[-t3 t4; t4 -t3]),
        (1, -1, T[-t3 -t4; -t4 -t3]),
    )
end

"""
    tilted_kinetic_matrix(torus, parameters=DEFAULT_PARAMETERS)

Construct the exact real, one-spin, two-orbital kinetic matrix. Distinct
periodic images are accumulated, which is essential on small tori.
"""
function tilted_kinetic_matrix(
    torus::TiltedTorus,
    parameters::ModelParameters=DEFAULT_PARAMETERS,
)
    dimension = 2torus.ncells
    kinetic = zeros(typeof(parameters.t1), dimension, dimension)
    for (source_site, (x, y)) in enumerate(torus.cells)
        for (dx, dy, block) in _positive_displacement_blocks(parameters)
            destination_site = _site_index(torus, (x + dx, y + dy))
            for source_orbital in 1:2, destination_orbital in 1:2
                source = torus_single_particle_index(
                    torus, source_site, source_orbital,
                )
                destination = torus_single_particle_index(
                    torus, destination_site, destination_orbital,
                )
                hopping = block[source_orbital, destination_orbital]
                kinetic[source, destination] += hopping
                kinetic[destination, source] += hopping
            end
        end
    end
    issymmetric(kinetic) || error("tilted-torus kinetic matrix is not symmetric")
    return kinetic
end

"""Project a torus kinetic matrix onto an allowed momentum."""
function torus_fourier_block(
    kinetic::AbstractMatrix{<:Number},
    torus::TiltedTorus,
    kx::Real,
    ky::Real,
)
    dimension = 2torus.ncells
    size(kinetic) == (dimension, dimension) ||
        throw(DimensionMismatch("kinetic matrix must have size 2Ncells by 2Ncells"))
    coefficient_type = promote_type(eltype(kinetic), ComplexF64)
    waves = zeros(coefficient_type, dimension, 2)
    normalization = sqrt(torus.ncells)
    for (site, (x, y)) in enumerate(torus.cells), orbital in 1:2
        p = torus_single_particle_index(torus, site, orbital)
        waves[p, orbital] = cis(kx * x + ky * y) / normalization
    end
    return adjoint(waves) * kinetic * waves
end

"""Return whether a 90-degree lattice rotation is well-defined on the torus."""
function has_c4_symmetry(torus::TiltedTorus)
    for translation in (torus.a1, torus.a2)
        rotated = (-translation[2], translation[1])
        _coset_signature(
            rotated, torus.a1, torus.a2, torus.signed_determinant,
        ) == (0, 0) || return false
    end
    return true
end

function _translation_permutation(torus::TiltedTorus, displacement)
    return [
        _site_index(torus, (cell[1] + displacement[1], cell[2] + displacement[2]))
        for cell in torus.cells
    ]
end

function _cycle_lengths(permutation)
    visited = falses(length(permutation))
    lengths = Int[]
    for initial in eachindex(permutation)
        visited[initial] && continue
        position = initial
        cycle_length = 0
        while !visited[position]
            visited[position] = true
            cycle_length += 1
            position = permutation[position]
        end
        push!(lengths, cycle_length)
    end
    return lengths
end

function _multiply_cycle_factor(polynomial, cycle_length, multiplicity, maximum_degree)
    result = polynomial
    coefficient = isodd(cycle_length) ? big(1) : big(-1)
    for _ in 1:multiplicity
        extended = fill(big(0), min(maximum_degree, length(result) - 1 + cycle_length) + 1)
        for degree in 0:(length(result) - 1)
            extended[degree + 1] += result[degree + 1]
            degree + cycle_length <= maximum_degree &&
                (extended[degree + cycle_length + 1] += coefficient * result[degree + 1])
        end
        result = extended
    end
    return result
end

# Trace of a site translation in the n-particle fermion sector. A site cycle
# of length l contributes (1-(-x)^l)^orbital_multiplicity to det(I+xP).
function _fixed_number_translation_trace(
    torus::TiltedTorus,
    displacement,
    number::Int,
    orbital_multiplicity::Int,
)
    number < 0 && return big(0)
    number > orbital_multiplicity * torus.ncells && return big(0)
    polynomial = BigInt[1]
    for cycle_length in _cycle_lengths(_translation_permutation(torus, displacement))
        polynomial = _multiply_cycle_factor(
            polynomial, cycle_length, orbital_multiplicity, number,
        )
    end
    return number + 1 <= length(polynomial) ? polynomial[number + 1] : big(0)
end

function _character_phase(torus::TiltedTorus, n, displacement)
    # n' B^(-1) r, evaluated in high precision before exponentiation.
    numerator =
        n[1] * (torus.a2[2] * displacement[1] - torus.a2[1] * displacement[2]) +
        n[2] * (-torus.a1[2] * displacement[1] + torus.a1[1] * displacement[2])
    denominator = torus.signed_determinant
    return setprecision(256) do
        angle = -2big(pi) * BigFloat(numerator) / BigFloat(denominator)
        Complex{BigFloat}(cos(angle), sin(angle))
    end
end

function _momentum_dimensions(trace_function, torus::TiltedTorus)
    dimensions = BigInt[]
    for n in torus.momentum_quantum_numbers
        projected_trace = setprecision(256) do
            total = Complex{BigFloat}(0)
            for displacement in torus.cells
                total += BigFloat(trace_function(displacement)) *
                         _character_phase(torus, n, displacement)
            end
            total / BigFloat(torus.ncells)
        end
        abs(imag(projected_trace)) <= big"1e-50" ||
            error("momentum projector did not produce a real dimension")
        dimension = round(BigInt, real(projected_trace))
        abs(real(projected_trace) - BigFloat(dimension)) <= big"1e-50" ||
            error("momentum projector did not produce an integer dimension")
        dimension >= 0 || error("negative momentum-sector dimension")
        push!(dimensions, dimension)
    end
    return dimensions
end

_checked_binomial(n::Int, k::Int) = 0 <= k <= n ? binomial(big(n), k) : big(0)

function _checked_bytes(states::BigInt, bytes_per_state::Integer)
    bytes_per_state >= 0 || throw(ArgumentError("byte multiplier must be nonnegative"))
    return states * BigInt(bytes_per_state)
end

"""
    sector_resource_estimate(torus; N, Nup, Ndown, krylov_vectors=3)

Return allocation-free, exact dimensions for the full Hilbert space, the
fixed-number sector, and every translation-momentum block. Memory figures are
mathematical lower bounds based on dense `Float64` storage; practical hash
tables and sparse-operator metadata require additional memory.
"""
function sector_resource_estimate(
    torus::TiltedTorus;
    N::Integer,
    Nup::Integer,
    Ndown::Integer,
    krylov_vectors::Integer=3,
)
    particle_number = Int(N)
    up_number = Int(Nup)
    down_number = Int(Ndown)
    particle_number == up_number + down_number ||
        throw(ArgumentError("N must equal Nup + Ndown"))
    modes_per_spin = 2torus.ncells
    0 <= up_number <= modes_per_spin || throw(ArgumentError("Nup is out of range"))
    0 <= down_number <= modes_per_spin || throw(ArgumentError("Ndown is out of range"))
    0 <= particle_number <= 2modes_per_spin || throw(ArgumentError("N is out of range"))
    krylov_vectors >= 1 || throw(ArgumentError("krylov_vectors must be positive"))

    full_hilbert_dimension = big(2)^(4torus.ncells)
    fixed_number_dimension = _checked_binomial(4torus.ncells, particle_number)
    spin_resolved_dimension =
        _checked_binomial(modes_per_spin, up_number) *
        _checked_binomial(modes_per_spin, down_number)
    spin_momentum_dimensions = _momentum_dimensions(torus) do displacement
        _fixed_number_translation_trace(torus, displacement, up_number, 2) *
        _fixed_number_translation_trace(torus, displacement, down_number, 2)
    end
    number_momentum_dimensions = _momentum_dimensions(torus) do displacement
        _fixed_number_translation_trace(torus, displacement, particle_number, 4)
    end
    sum(spin_momentum_dimensions) == spin_resolved_dimension ||
        error("spin-resolved momentum dimensions are incomplete")
    sum(number_momentum_dimensions) == fixed_number_dimension ||
        error("fixed-N momentum dimensions are incomplete")

    momentum_blocks = [(
        kx=torus.momenta[index][1],
        ky=torus.momenta[index][2],
        quantum_numbers=torus.momentum_quantum_numbers[index],
        fixed_N_dimension=number_momentum_dimensions[index],
        fixed_Nup_Ndown_dimension=spin_momentum_dimensions[index],
        vector_bytes=_checked_bytes(spin_momentum_dimensions[index], 8),
        dense_matrix_bytes=_checked_bytes(spin_momentum_dimensions[index]^2, 8),
    ) for index in eachindex(torus.momenta)]

    return (
        ncells=torus.ncells,
        spatial_orbitals=2torus.ncells,
        spin_orbitals=4torus.ncells,
        N=particle_number,
        Nup=up_number,
        Ndown=down_number,
        full_hilbert_dimension=full_hilbert_dimension,
        fixed_N_dimension=fixed_number_dimension,
        fixed_Nup_Ndown_dimension=spin_resolved_dimension,
        momentum_blocks=momentum_blocks,
        largest_fixed_N_momentum_dimension=maximum(number_momentum_dimensions),
        largest_fixed_Nup_Ndown_momentum_dimension=maximum(spin_momentum_dimensions),
        one_sector_vector_bytes=_checked_bytes(spin_resolved_dimension, 8),
        minimum_krylov_vector_bytes=_checked_bytes(
            spin_resolved_dimension, 8krylov_vectors,
        ),
        explicit_combined_basis_bytes=_checked_bytes(spin_resolved_dimension, 16),
        explicit_basis_with_index_bytes=_checked_bytes(spin_resolved_dimension, 24),
        dense_sector_matrix_bytes=_checked_bytes(spin_resolved_dimension^2, 8),
        all_eigenvalues_bytes=_checked_bytes(full_hilbert_dimension, 8),
        full_dense_matrix_bytes=_checked_bytes(full_hilbert_dimension^2, 8),
        memory_note=
            "Vector and dense-array byte counts are exact for Float64 storage. " *
            "Explicit-basis figures assume two UInt64 state words plus an Int64 index per product state; " *
            "hash tables and operator metadata add implementation-dependent overhead.",
    )
end

"""
    target_filling_feasibility(torus=standard_eight_site_torus(); filling=1.5)

Plan the nearest even, spin-balanced canonical sector without allocating it.
The metadata explicitly separates feasible low-state Krylov work from the
infeasible full spectrum and target-filling spectral-function calculation.
"""
function target_filling_feasibility(
    torus::TiltedTorus=standard_eight_site_torus();
    filling::Real=1.5,
    krylov_vectors::Integer=3,
    max_basis_states::Integer=2_000_000,
    max_working_bytes::Integer=2 * 1024^3,
)
    0 <= filling <= 4 || throw(ArgumentError("filling must lie between 0 and 4"))
    target_N = 2round(Int, filling * torus.ncells / 2)
    target_N = clamp(target_N, 0, 4torus.ncells)
    estimate = sector_resource_estimate(
        torus;
        N=target_N,
        Nup=target_N ÷ 2,
        Ndown=target_N ÷ 2,
        krylov_vectors=krylov_vectors,
    )
    removal = target_N > 0 ? sector_resource_estimate(
        torus;
        N=target_N - 1,
        Nup=target_N ÷ 2 - 1,
        Ndown=target_N ÷ 2,
        krylov_vectors=krylov_vectors,
    ) : nothing
    addition = target_N < 4torus.ncells ? sector_resource_estimate(
        torus;
        N=target_N + 1,
        Nup=target_N ÷ 2 + 1,
        Ndown=target_N ÷ 2,
        krylov_vectors=krylov_vectors,
    ) : nothing
    spectral_dimensions = BigInt[estimate.fixed_Nup_Ndown_dimension]
    removal === nothing || push!(spectral_dimensions, removal.fixed_Nup_Ndown_dimension)
    addition === nothing || push!(spectral_dimensions, addition.fixed_Nup_Ndown_dimension)
    peak_spectral_dimension = maximum(spectral_dimensions)
    basis_ok = estimate.fixed_Nup_Ndown_dimension <= max_basis_states
    memory_ok = estimate.minimum_krylov_vector_bytes <= max_working_bytes
    feasible_here = basis_ok && memory_ok
    return merge(estimate, (
        requested_filling=Float64(filling),
        realized_filling=target_N / torus.ncells,
        local_target_sector_feasible=feasible_here,
        full_spectrum_available=false,
        target_Akw_available=false,
        removal_sector_estimate=removal,
        addition_sector_estimate=addition,
        largest_ground_or_spectral_sector_dimension=peak_spectral_dimension,
        three_vector_peak_spectral_bytes=_checked_bytes(peak_spectral_dimension, 24),
        reason=feasible_here ?
            "The declared local gates permit lowest-state Lanczos only; a full spectrum is still unavailable." :
            "The target sector exceeds the declared basis or Krylov-memory gate before basis construction.",
        recommended_method=
            "Use symmetry-resolved, matrix-free Lanczos on an HPC node, with translation, spin, and point-group reduction. " *
            "Compute selected A(k,w) by N±1 Krylov continued fractions or Chebyshev expansion; do not form eigenvectors or a dense matrix.",
        hpc_resource_note=
            "A practical starting point is a multicore node with at least 64 GiB RAM for translation-reduced ground-state work; " *
            "128 GiB or distributed memory is safer for repeated N±1 spectral Krylov spaces. These are engineering recommendations, " *
            "not exact minima; the exact raw vector sizes are reported above.",
        full_spectrum_note=
            "A complete spectrum scales with the full 2^(4Ncells) Hilbert space and is not a viable eight-site deliverable.",
    ))
end

"""
    require_feasible_sector(torus; Nup, Ndown, ...)

Apply hard limits before any Fock basis is constructed. Returns the resource
estimate on success and raises `EDResourceLimitError` otherwise.
"""
function require_feasible_sector(
    torus::TiltedTorus;
    Nup::Integer,
    Ndown::Integer,
    krylov_vectors::Integer=3,
    max_basis_states::Integer=2_000_000,
    max_working_bytes::Integer=2 * 1024^3,
    dense::Bool=false,
    max_dense_bytes::Integer=512 * 1024^2,
)
    estimate = sector_resource_estimate(
        torus;
        N=Int(Nup) + Int(Ndown), Nup=Nup, Ndown=Ndown,
        krylov_vectors=krylov_vectors,
    )
    failures = String[]
    estimate.fixed_Nup_Ndown_dimension > max_basis_states && push!(
        failures,
        "$(estimate.fixed_Nup_Ndown_dimension) basis states exceed max_basis_states=$max_basis_states",
    )
    estimate.minimum_krylov_vector_bytes > max_working_bytes && push!(
        failures,
        "$(estimate.minimum_krylov_vector_bytes) Krylov-vector bytes exceed max_working_bytes=$max_working_bytes",
    )
    dense && estimate.dense_sector_matrix_bytes > max_dense_bytes && push!(
        failures,
        "$(estimate.dense_sector_matrix_bytes) dense-matrix bytes exceed max_dense_bytes=$max_dense_bytes",
    )
    isempty(failures) || throw(EDResourceLimitError(
        "tilted-cluster ED allocation refused before basis construction: " * join(failures, "; "),
    ))
    return estimate
end

function _fixed_weight_states(mode_count::Int, particle_number::Int)
    mode_count <= 64 || throw(ArgumentError("the UInt64 Lanczos backend supports at most 64 modes per spin"))
    states = UInt64[]
    function visit(next_mode::Int, remaining::Int, state::UInt64)
        if iszero(remaining)
            push!(states, state)
            return
        end
        last_mode = mode_count - remaining + 1
        for mode in next_mode:last_mode
            visit(mode + 1, remaining - 1, state | (UInt64(1) << (mode - 1)))
        end
    end
    visit(1, particle_number, UInt64(0))
    return states
end

function _hopping_transitions(kinetic, basis, indices)
    mode_count = size(kinetic, 1)
    transitions = Vector{Vector{Tuple{Int,Float64}}}(undef, length(basis))
    for (column, state) in enumerate(basis)
        column_transitions = Tuple{Int,Float64}[]
        for source in 1:mode_count
            source_bit = UInt64(1) << (source - 1)
            state & source_bit == 0 && continue
            intermediate = xor(state, source_bit)
            for destination in 1:mode_count
                hopping = Float64(kinetic[destination, source])
                iszero(hopping) && continue
                destination_bit = UInt64(1) << (destination - 1)
                intermediate & destination_bit != 0 && continue
                parity = count_ones(state & (source_bit - UInt64(1))) +
                         count_ones(intermediate & (destination_bit - UInt64(1)))
                final_state = intermediate | destination_bit
                amplitude = iseven(parity) ? hopping : -hopping
                push!(column_transitions, (indices[final_state], amplitude))
            end
        end
        transitions[column] = column_transitions
    end
    return transitions
end

function _sector_problem(
    torus::TiltedTorus,
    U::Real,
    Nup::Integer,
    Ndown::Integer;
    parameters::ModelParameters=DEFAULT_PARAMETERS,
    gate_keywords...,
)
    estimate = require_feasible_sector(
        torus; Nup=Nup, Ndown=Ndown, gate_keywords...,
    )
    mode_count = 2torus.ncells
    up_basis = _fixed_weight_states(mode_count, Int(Nup))
    down_basis = _fixed_weight_states(mode_count, Int(Ndown))
    length(up_basis) * length(down_basis) == estimate.fixed_Nup_Ndown_dimension ||
        error("constructed basis dimension does not match resource estimate")
    up_indices = Dict(state => index for (index, state) in enumerate(up_basis))
    down_indices = Dict(state => index for (index, state) in enumerate(down_basis))
    kinetic = tilted_kinetic_matrix(torus, parameters)
    up_transitions = _hopping_transitions(kinetic, up_basis, up_indices)
    down_transitions = _hopping_transitions(kinetic, down_basis, down_indices)
    constant_shift = Float64(U) * (
        torus.ncells / 2 - (Int(Nup) + Int(Ndown)) / 2
    )
    return (
        torus=torus,
        U=Float64(U),
        Nup=Int(Nup),
        Ndown=Int(Ndown),
        estimate=estimate,
        up_basis=up_basis,
        down_basis=down_basis,
        up_transitions=up_transitions,
        down_transitions=down_transitions,
        constant_shift=constant_shift,
        dimension=length(up_basis) * length(down_basis),
    )
end

function _sector_mul!(output, problem, input)
    fill!(output, 0.0)
    up_dimension = length(problem.up_basis)
    for down_index in eachindex(problem.down_basis), up_index in eachindex(problem.up_basis)
        column = up_index + (down_index - 1) * up_dimension
        coefficient = input[column]
        iszero(coefficient) && continue
        double_occupancy = count_ones(
            problem.up_basis[up_index] & problem.down_basis[down_index],
        )
        output[column] += (
            problem.constant_shift + problem.U * double_occupancy
        ) * coefficient
        for (target_up, hopping) in problem.up_transitions[up_index]
            row = target_up + (down_index - 1) * up_dimension
            output[row] += hopping * coefficient
        end
        for (target_down, hopping) in problem.down_transitions[down_index]
            row = up_index + (target_down - 1) * up_dimension
            output[row] += hopping * coefficient
        end
    end
    return output
end

"""Build a dense low-filling sector only after both dense and basis gates pass."""
function dense_sector_hamiltonian(
    torus::TiltedTorus,
    U::Real,
    Nup::Integer,
    Ndown::Integer;
    parameters::ModelParameters=DEFAULT_PARAMETERS,
    max_basis_states::Integer=20_000,
    max_working_bytes::Integer=512 * 1024^2,
    max_dense_bytes::Integer=512 * 1024^2,
)
    problem = _sector_problem(
        torus, U, Nup, Ndown;
        parameters=parameters,
        dense=true,
        max_basis_states=max_basis_states,
        max_working_bytes=max_working_bytes,
        max_dense_bytes=max_dense_bytes,
    )
    hamiltonian = zeros(Float64, problem.dimension, problem.dimension)
    input = zeros(Float64, problem.dimension)
    output = similar(input)
    for column in 1:problem.dimension
        input[column] = 1.0
        _sector_mul!(output, problem, input)
        hamiltonian[:, column] = output
        input[column] = 0.0
    end
    issymmetric(hamiltonian) || error("many-body Hamiltonian is not symmetric")
    return hamiltonian
end

"""
    lanczos_lowest_sector(torus, U, Nup, Ndown; ...)

Run unrestarted, fully reorthogonalized Lanczos for a small approved sector.
This proof-of-principle backend intentionally refuses the eight-site target
sector under its default resource gate.
"""
function lanczos_lowest_sector(
    torus::TiltedTorus,
    U::Real,
    Nup::Integer,
    Ndown::Integer;
    parameters::ModelParameters=DEFAULT_PARAMETERS,
    maxiter::Integer=200,
    tolerance::Real=1.0e-12,
    max_basis_states::Integer=200_000,
    max_working_bytes::Integer=2 * 1024^3,
)
    maxiter >= 1 || throw(ArgumentError("maxiter must be positive"))
    tolerance > 0 || throw(ArgumentError("tolerance must be positive"))
    requested_vectors = Int(maxiter) + 2
    problem = _sector_problem(
        torus, U, Nup, Ndown;
        parameters=parameters,
        krylov_vectors=requested_vectors,
        max_basis_states=max_basis_states,
        max_working_bytes=max_working_bytes,
    )
    dimension = problem.dimension
    iterations = min(Int(maxiter), dimension)
    vectors = zeros(Float64, dimension, iterations)
    initial = [sin(index) + cos(sqrt(2.0) * index) for index in 1:dimension]
    initial ./= norm(initial)
    vectors[:, 1] = initial
    alphas = Float64[]
    betas = Float64[]
    work = zeros(Float64, dimension)
    actual_iterations = iterations
    terminal_beta = 0.0
    for iteration in 1:iterations
        current = view(vectors, :, iteration)
        _sector_mul!(work, problem, current)
        iteration > 1 && (work .-= betas[iteration - 1] .* view(vectors, :, iteration - 1))
        alpha = dot(current, work)
        push!(alphas, alpha)
        work .-= alpha .* current
        # Two passes make the low-sector validation insensitive to nearly
        # degenerate Ritz vectors without introducing an external dependency.
        for _ in 1:2, previous in 1:iteration
            coefficient = dot(view(vectors, :, previous), work)
            work .-= coefficient .* view(vectors, :, previous)
        end
        beta = norm(work)
        terminal_beta = beta
        if iteration == iterations || beta <= tolerance
            actual_iterations = iteration
            break
        end
        push!(betas, beta)
        vectors[:, iteration + 1] = work / beta
    end
    tridiagonal = SymTridiagonal(
        alphas[1:actual_iterations],
        betas[1:max(0, actual_iterations - 1)],
    )
    decomposition = eigen(tridiagonal)
    ground_index = argmin(decomposition.values)
    residual = abs(terminal_beta * decomposition.vectors[end, ground_index])
    return (
        energy=decomposition.values[ground_index],
        residual_estimate=residual,
        converged=residual <= tolerance,
        iterations=actual_iterations,
        sector_dimension=dimension,
        Nup=Int(Nup),
        Ndown=Int(Ndown),
        estimate=problem.estimate,
    )
end

end # module
