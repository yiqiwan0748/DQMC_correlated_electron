#!/usr/bin/env julia
# Actual native geometry/Hamiltonian APIs; explicitly NEW canonical thermal observers.
using LinearAlgebra,TOML,SHA
BLAS.set_num_threads(1)
const HERE=@__DIR__
const CFG=TOML.parsefile(joinpath(HERE,"manifest.toml"))
sha(p)=bytes2hex(sha256(read(p)))
plain(x)=x
plain(x::AbstractMatrix)=[collect(x[i,:]) for i in axes(x,1)]
plain(x::AbstractVector)=[plain(v) for v in x]
plain(x::AbstractDict)=Dict(k=>plain(v) for (k,v) in x)
function source_map()
    isfile(joinpath(HERE,"source_freeze.json")) || error("Unfrozen proposal; execution prohibited")
    pins=Dict{String,String}()
    for line in eachline(joinpath(HERE,"SHA256SUMS"))
        h,n=split(line,"  ";limit=2);sha(joinpath(HERE,n))==h || error("Changed source $n");pins[n]=h
    end
    for (n,h) in CFG["native_source_hashes"]
        sha(joinpath(HERE,"source_snapshot",n))==h || error("Changed native source")
    end
    pins
end
const VERIFIED_SOURCE_BEFORE_INCLUDES=source_map()
const VERIFIED_FULL_ADMISSION = let
    length(ARGS)==2 && ARGS[1]=="full" || error("Parent-admitted full mode required")
    py=get(ENV,"X19_APPROVED_PYTHON","");isempty(py) && error("Full runner/pilot/root admission required")
    TOML.parse(read(`$py -B $(joinpath(HERE,"admission.py")) --role target --output $(ARGS[2]) --mode full --emit-toml`,String))
end
module Native
include(joinpath(Main.HERE,"source_snapshot/scripts/two_orbital_open_cluster_ed.jl"))
end
module Tilted
include(joinpath(Main.HERE,"source_snapshot/scripts/two_orbital_tilted_cluster_ed.jl"))
end
const ED=Native.TwoOrbitalOpenClusterED
const TOR=Tilted.TwoOrbitalTiltedClusterED
function coo(A)
    ii=findall(x->!iszero(x),A)
    Dict("shape"=>collect(size(A)),"row"=>[i[1]-1 for i in ii],"col"=>[i[2]-1 for i in ii],"value"=>[A[i] for i in ii])
end
function fourier_row(k,Hk)
    Dict("k"=>collect(k),"Hk"=>real.(Hk),"maximum_imaginary_component"=>maximum(abs,imag.(Hk)))
end
function geometry(spec,t4)
    pp=ED.ModelParameters(CFG["t1"],CFG["t2"],CFG["t3"],t4)
    if spec["id"]=="open2x2"
        K=ED.open_cluster_kinetic_matrix(2,2,pp)
        return K,[(x,y) for y in 0:1 for x in 0:1],Dict{String,Any}[]
    elseif spec["id"]=="periodic2x2"
        K=ED.ValidatedKinetic.realspace_kinetic_matrix(2,pp)
        rows=[fourier_row((kx,ky),ED.ValidatedKinetic.fourier_block(K,2,kx,ky)) for kx in ED.ValidatedKinetic.allowed_momenta(2) for ky in ED.ValidatedKinetic.allowed_momenta(2)]
        return K,[(x,y) for y in 0:1 for x in 0:1],rows
    end
    tor=TOR.tilted_torus(Tuple(spec["a1"]),Tuple(spec["a2"]));p=TOR.ModelParameters(CFG["t1"],CFG["t2"],CFG["t3"],t4)
    K=TOR.tilted_kinetic_matrix(tor,p)
    rows=[fourier_row((kx,ky),TOR.torus_fourier_block(K,tor,kx,ky)) for (kx,ky) in TOR.allowed_torus_momenta(tor)]
    return K,tor.cells,rows
end
function spectral(K)
    ee=eigen(Symmetric(K));rows=Dict{String,Any}[];a=CFG["orbital_A_zero_based"].+1;b=CFG["orbital_B_zero_based"].+1;i=1
    while i<=8
        j=i;while j<8 && ee.values[j+1]-ee.values[i]<=CFG["gates"]["onebody_cluster_diameter"];j+=1;end
        P=ee.vectors[:,i:j]*ee.vectors[:,i:j]'
        push!(rows,Dict("energy"=>sum(ee.values[i:j])/(j-i+1),"rank"=>j-i+1,"projector"=>P,"mixing_weight_per_cell"=>sum(abs2,P[a,b])/4));i=j+1
    end
    rows
end
function sector(K,U,nu,nd)
    ham=ED.sector_hamiltonian(K,U,nu,nd;h=0.0);H=ED.dense_sector_hamiltonian(ham);ee=eigen(Symmetric(H));d=length(ham.basis);scale=max(1.0,opnorm(H,Inf));labels=[(u,v) for u in ham.basis.up_states for v in ham.basis.down_states]
    saved=Dict{String,Any}("Nup"=>nu,"Ndown"=>nd,"dimension"=>d,"basis_up_per_row"=>[Int(u) for (u,v) in labels],"basis_down_per_row"=>[Int(v) for (u,v) in labels],"H"=>coo(H),"energies"=>ee.values,"eigen_residual_scaled"=>maximum(norm,eachcol(H*ee.vectors-ee.vectors.*ee.values'))/scale,"orthogonality_abs"=>maximum(abs,ee.vectors'*ee.vectors-I),"operator_scale"=>scale)
    (saved=saved,H=H,V=ee.vectors,E=ee.values,labels=labels)
end
function thermal(blocks)
    emin=minimum(minimum(z.E) for z in blocks);weights=[exp.(-CFG["beta"].*(z.E.-emin)) for z in blocks];Z=sum(sum(w) for w in weights);nmean=zeros(8);zmean=zeros(8);nn=zeros(8,8);zz=zeros(8,8);sd=zeros(8,8);cup=zeros(8,8);cdn=zeros(8,8);transfer=0.0;energy=0.0;normalization=0.0;commmax=0.0
    for (block,w0) in zip(blocks,weights)
        w=w0/Z;rho=(block.V.*w')*block.V';p=diag(rho);d=length(p);n=zeros(8,d);z=zeros(8,d)
        states=[u|(v<<8) for (u,v) in block.labels];lookup=Dict(s=>i for (i,s) in enumerate(states));NA=zeros(d)
        for (column,(u,v)) in enumerate(block.labels)
            NA[column]=count_ones(u&UInt64(0x55))+count_ones(v&UInt64(0x55))
            for i in 1:8
                up=Float64((u>>(i-1))&1);dn=Float64((v>>(i-1))&1);n[i,column]=up+dn;z[i,column]=(up-dn)/2
            end
        end
        nmean+=n*p;zmean+=z*p;nn+=(n.*p')*n';zz+=(z.*p')*z';sd+=(z.*p')*z'
        for (column,state) in enumerate(states),i in 1:8,j in 1:8
            for (offset,C) in ((0,cup),(8,cdn))
                step=ED._hop(state,i+offset,j+offset)
                step===nothing || (C[i,j]+=step[2]*rho[column,lookup[step[1]]])
            end
            # S+i S-j and S-i S+j: rightmost physical spin flip first.
            for (dst1,src1,dst2,src2) in ((8+j,j,i,8+i),(j,8+j,8+i,i))
                s1=ED._hop(state,dst1,src1);s1===nothing && continue
                s2=ED._hop(s1[1],dst2,src2);s2===nothing && continue
                sd[i,j]+=.5*s1[2]*s2[2]*rho[column,lookup[s2[1]]]
            end
        end
        comm=block.H.*(NA'.-NA);commmax=max(commmax,maximum(abs,comm));transfer+=sum(w.*vec(sum(abs2,comm*block.V;dims=1)))/4
        energy+=sum(w.*block.E);normalization+=sum(w)
        block.saved["canonical_sector_probability"]=sum(w)
    end
    nn-=nmean*nmean';zz-=zmean*zmean';sd-=zmean*zmean';a=CFG["orbital_A_zero_based"].+1;b=CFG["orbital_B_zero_based"].+1
    Dict("normalization"=>normalization,"logZ"=>log(Z)-CFG["beta"]*emin,"energy"=>energy,"density"=>nmean,"Sz"=>zmean,"onebody_up"=>cup,"onebody_down"=>cdn,"Cnn"=>nn,"Czz"=>zz,"Sdot_connected"=>sd,"cross_Cnn"=>nn[a,b],"cross_Sdot"=>sd[a,b],"orbital_coherence_per_cell"=>(sum(abs2,cup[a,b])+sum(abs2,cdn[a,b]))/4,"orbital_transfer_second_moment_per_cell"=>transfer,"orbital_number_commutator_maxabs"=>commmax)
end
function one_case(spec,U,t4)
    K,cells,ks=geometry(spec,t4);blocks=[sector(K,U,nu,nd) for (nu,nd) in CFG["spin_sectors"]]
    Dict("id"=>string(spec["id"],"_U",Int(U),"_t4",t4==0 ? "0" : "m065"),"geometry"=>spec["id"],"U"=>U,"t4"=>t4,"cells"=>[collect(x) for x in cells],"K"=>K,"fourier"=>ks,"onebody_spectral_clusters"=>spectral(K),"sectors"=>[z.saved for z in blocks],"observables"=>thermal(blocks))
end
function main()
    length(ARGS)==2 || error("MODE OUTPUT");mode=ARGS[1];mode=="full" || error("Only separately admitted full mode is supported");haskey(ENV,"SLURM_JOB_ID") || error("Compute-node execution only")
    string(VERSION)==CFG["runtime_julia"] || error("Wrong Julia");pins=source_map();out=ARGS[2];ispath(out) && error("No overwrite")
    rows=Dict{String,Any}[]
    for geom in CFG["geometries"],U in CFG["U_arms"],t4 in CFG["t4_arms"]
        push!(rows,one_case(geom,U,t4))
    end
    length(rows)==12 || error("Complete12case grid required")
    raw=Dict("schema"=>"X19_NATIVE_THERMAL_RAW_V1","mode"=>mode,"job_id"=>ENV["SLURM_JOB_ID"],"julia_version"=>string(VERSION),"scientific_completions"=>0,"source_sha256"=>pins,"native_source_sha256"=>CFG["native_source_hashes"],"source_freeze_sha256"=>sha(joinpath(HERE,"source_freeze.json")),"full_admission"=>VERIFIED_FULL_ADMISSION,"attribution"=>"Unchanged actual native open/periodic/tilted geometry constructors and generic SectorHamiltonian; NEW complete canonical thermal trace and physical observers. No native thermal solver claim.","cases"=>rows)
    open(out,"w") do io;TOML.print(io,plain(raw));end
end
main()
