#!/usr/bin/env python3
"""Observe an unchanged original reference renderer; never replace its functions."""
import argparse, datetime, hashlib, importlib.metadata, json, math, os, platform, runpy, sys, tarfile, traceback
from pathlib import Path, PurePosixPath
HERE=Path(__file__).resolve().parent
PLAN_SHA256='66fd970b94f7db7e8d31ce51bb085d57764071a22dc6bceb2396d189fbfcf416'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def write(path,data):
    with Path(path).open('x') as stream:json.dump(data,stream,indent=2,allow_nan=False);stream.write('\n')
def require(ok,message):
    if not ok:raise ValueError(message)
def plain(value):
    """Copy already-existing data only; never call a scientific helper."""
    if value is None or type(value) in (str,bool,int):return value
    if type(value) is float:return value if math.isfinite(value) else {'nonfinite_repr':repr(value)}
    if isinstance(value,(list,tuple)):return [plain(x) for x in value]
    if isinstance(value,dict):return {str(k):plain(v) for k,v in value.items()}
    if type(value).__module__.startswith('numpy') and hasattr(value,'tolist'):return plain(value.tolist())
    return {'unserialized_type':type(value).__module__+'.'+type(value).__name__}

def verify(source,expected_sha):
    require(sha(__file__)==expected_sha,'Root-pinned diagnostic source differs')
    require(sha(HERE/'plan.json')==PLAN_SHA256,'Reviewed plan differs')
    plan=read(HERE/'plan.json')
    require(os.environ.get('SLURM_JOB_ID') not in (None,plan['original_job']),'Separate ROOT analysis allocation required')
    require(os.environ.get('SLURM_CPUS_PER_TASK')=='1' and os.environ.get('SLURM_MEM_PER_NODE')=='3500','Exactly one CPU and3500MB required')
    require(platform.python_version()==plan['python_version'],'Original pinned Python3.11.11 required')
    for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):require(os.environ.get(key)=='1','One numerical thread required')
    release=HERE/'source_freeze.json';require(release.is_file(),'New diagnostic source requires root-reviewed freeze')
    for name,digest in read(release)['files'].items():require(sha(HERE/name)==digest,'Changed diagnostic release member '+name)
    for name,digest in plan['prior'].items():require(sha(HERE/name)==digest,'Changed original failure/source evidence '+name)
    original=read(HERE/'prior/original_freeze.json')
    require(sha(source/'source_freeze.json')==plan['original_source_freeze_sha256'],'Original frozen source marker differs')
    seen=set()
    with tarfile.open(HERE/'prior/original_source.tar.gz','r:gz') as archive:
        for member in archive:
            require(member.isfile() and not member.issym() and not member.islnk() and member.name.startswith(original['prefix']) and '..' not in PurePosixPath(member.name).parts,'Unsafe original source archive member')
            name=member.name[len(original['prefix']):]
            require(name not in seen and name in original['files'],'Duplicate/unexpected original source member');seen.add(name)
            digest=hashlib.sha256(archive.extractfile(member).read()).hexdigest()
            require(digest==original['files'][name]==sha(source/name),'Original source byte differs '+name)
    require(seen==set(original['files']),'Incomplete original source archive')
    require(sha(source/'render_quspin_reference.py')==plan['original_renderer_sha256'] and sha(source/'io_contract.py')==plan['original_io_contract_sha256'],'Original function bodies changed')
    require(sha(source/'reference_library_pins.json')==plan['reference_library_pins_sha256'],'Original runtime pins changed')
    pins=read(source/'reference_library_pins.json');observed={};locations={}
    for name,spec in pins['distributions'].items():
        dist=importlib.metadata.distribution(name);require(dist.version==spec['version'],'Original distribution version differs')
        for relative in spec['files']:
            path=dist.locate_file(relative).resolve();require(path.stat().st_size==pins['bytes'][relative],'Original critical size differs '+relative)
            observed[relative]=sha(path);locations[relative]=str(path)
    require(len(observed)==30 and observed==pins['files'],'Original30 critical runtime files differ before renderer import')
    return plan,observed,locations

class Capture:
    def __init__(self,renderer,limit):
        self.renderer=str(renderer);self.limit=limit;self.active={};self.failures=[];self.completed=[];self.truncated=False
    def snapshot(self,frame):
        name=frame.f_code.co_name;values=frame.f_locals
        keys={'enclosed_root':['a','b','e','w','eta','parent','cl','ch','sa','sb','ea','eb','original','lefts','rights','fraction','x','sign','sleft','sright','_'],
              'stationary':['a','b','depth','visited','excluded','boundary_candidates','neighborhoods'],
              'render':['s','eta'], 'main':['s','eta']}.get(name,[])
        result={'function':name,'line':frame.f_lineno,'locals':{key:plain(values[key]) for key in keys if key in values}}
        if name=='main' and 'rows' in values:result['completed_rows']=len(values['rows'])
        if name=='enclosed_root':result['existing_probe_history']=self.active.get(id(frame),[])
        return result
    def append(self,frame,value):
        history=self.active.get(id(frame))
        if history is not None:
            if len(history)<self.limit:history.append(value)
            else:self.truncated=True
    def trace(self,frame,event,arg):
        if frame.f_code.co_filename!=self.renderer:return None
        name=frame.f_code.co_name
        if name not in ('enclosed_root','derivative_sign','interval_bounds','stationary','render','main'):return None
        frame.f_trace_lines=False;frame.f_trace_opcodes=False
        if event=='call' and name=='enclosed_root':self.active[id(frame)]=[]
        if event=='return' and name=='derivative_sign' and frame.f_back and frame.f_back.f_code.co_name=='enclosed_root':
            self.append(frame.f_back,{'call':'derivative_sign','x':plain(frame.f_locals.get('x')),'returned_sign_and_enclosure':plain(arg)})
        if event=='return' and name=='interval_bounds':
            caller=frame.f_back
            root=caller if caller and caller.f_code.co_name=='enclosed_root' else caller.f_back if caller and caller.f_code.co_name=='derivative_sign' else None
            if root and root.f_code.co_name=='enclosed_root':self.append(root,{'call':'interval_bounds','existing_locals':{key:plain(frame.f_locals[key]) for key in ('a','b','order','eps','lo','hi') if key in frame.f_locals},'returned_enclosure':plain(arg)})
        if event=='exception' and name=='enclosed_root':
            kind,error,_=arg;stack=[];cursor=frame
            while cursor:
                if cursor.f_code.co_filename==self.renderer and cursor.f_code.co_name in ('enclosed_root','stationary','render','main'):stack.append(self.snapshot(cursor))
                cursor=cursor.f_back
            self.failures.append({'exception_type':kind.__name__,'message':str(error),'original_stack':stack})
        if event=='return' and name=='enclosed_root':self.active.pop(id(frame),None)
        if event=='return' and name=='render' and isinstance(arg,dict):self.completed.append({key:plain(arg[key]) for key in ('id','eta','role','branch')})
        return self.trace

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--original-source',type=Path,required=True);parser.add_argument('--expected-diagnostic-sha256',required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    source=args.original_source.resolve();output=args.output.resolve();require(not output.exists(),'Refuse existing diagnostic directory')
    plan,pins,locations=verify(source,args.expected_diagnostic_sha256);output.mkdir(parents=True)
    renderer=source/'render_quspin_reference.py';captured=Capture(renderer,plan['trace_history_limit_per_root']);old_trace=sys.gettrace();require(old_trace is None,'Refuse an existing trace hook')
    sys.path.insert(0,str(source));saved_argv=sys.argv[:];error=None;original_exit=0
    try:
        # runpy imports the byte-exact original module without invoking its main.
        # No original function, code object or global scientific helper is replaced.
        namespace=runpy.run_path(str(renderer),run_name='x14_original_renderer_diagnostic')
        require(namespace['enclosed_root'].__code__.co_filename==str(renderer),'Original root function source identity differs')
        sys.argv=[str(renderer),'pilot',str(output/'reference_if_original_completes.json')]
        sys.settrace(captured.trace);namespace['main']()
    except BaseException as exception:
        original_exit=1;error={'type':type(exception).__name__,'message':str(exception)}
        with (output/'original_reference_traceback.txt').open('x') as stream:traceback.print_exc(file=stream)
    finally:
        sys.settrace(old_trace);sys.argv=saved_argv;sys.path.pop(0)
    # Hash-only checks after the traced execution; no extra scientific calls.
    unchanged=sha(source/'source_freeze.json')==plan['original_source_freeze_sha256'] and all(sha(source/name)==digest for name,digest in read(HERE/'prior/original_freeze.json')['files'].items())
    runtime_after={relative:sha(path) for relative,path in locations.items()}
    report={'schema':'X14_ORIGINAL_REFERENCE_INSTRUMENTATION_V1','analysis_job':os.environ['SLURM_JOB_ID'],'original_failed_job':plan['original_job'],'diagnostic_status':'CAPTURED_ORIGINAL_FAILURE' if error and captured.failures and not captured.truncated and unchanged and runtime_after==pins else 'ORIGINAL_COMPLETED_DIAGNOSTIC_ONLY' if not error and not captured.truncated and unchanged and runtime_after==pins else 'UNRESOLVED_DIAGNOSTIC','catalogue_status':'NOT_RUN','scientific_completions':0,'original_exception':error,'original_reference_exit_code':original_exit,'original_renderer_sha256':sha(renderer),'original_source_freeze_sha256':sha(source/'source_freeze.json'),'diagnostic_sha256':sha(__file__),'diagnostic_plan_sha256':sha(HERE/'plan.json'),'reference_library_sha256_before':pins,'reference_library_sha256_after':runtime_after,'original_source_unchanged':unchanged,'completed_original_reference_rows':captured.completed,'captured_failures':captured.failures,'history_truncated':captured.truncated,'extra_scientific_probes':False,'native_renderer_executed':False,'new_eigensolver_or_sampler_executed':False,'original_functions_replaced':False,'original_padding_or_gates_changed':False,'automatic_remedy_or_catalogue_promotion':False,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write(output/'diagnostic.json',report);print(report['diagnostic_status']);return original_exit
if __name__=='__main__':raise SystemExit(main())
