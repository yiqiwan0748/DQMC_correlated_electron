#!/usr/bin/env python3
"""Resource-bounded single reference-only diagnostic; no scientific qualification."""
import argparse,datetime,hashlib,json,os,platform,signal,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PLAN_SHA256='66fd970b94f7db7e8d31ce51bb085d57764071a22dc6bceb2396d189fbfcf416'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--original-source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--expected-diagnostic-sha256',required=True);a=p.parse_args()
 if sha(HERE/'plan.json')!=PLAN_SHA256:raise SystemExit('Reviewed plan changed')
 plan=json.loads((HERE/'plan.json').read_text())
 if not os.getenv('SLURM_JOB_ID') or os.getenv('SLURM_JOB_ID')==plan['original_job'] or os.getenv('SLURM_CPUS_PER_TASK')!='1' or os.getenv('SLURM_MEM_PER_NODE')!='3500' or platform.python_version()!=plan['python_version']:raise SystemExit('Separate1CPU3500MB pinned3.11.11 allocation required')
 freeze=HERE/'source_freeze.json'
 if not freeze.is_file():raise SystemExit('Root-reviewed diagnostic freeze required')
 for name,digest in json.loads(freeze.read_text())['files'].items():
  if sha(HERE/name)!=digest:raise SystemExit('Changed diagnostic source '+name)
 for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
 if sha(HERE/'diagnose.py')!=a.expected_diagnostic_sha256:raise SystemExit('Root-reviewed diagnostic hash differs')
 out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
 cmd=['/usr/bin/time','-v','-o',str(out/'reference_diagnostic.resources.txt'),sys.executable,'-B',str(HERE/'diagnose.py'),'--original-source',str(a.original_source.resolve()),'--expected-diagnostic-sha256',a.expected_diagnostic_sha256,'--output',str(out/'diagnostic')]
 start=time.time();timed_out=False
 with (out/'reference_diagnostic.stdout.txt').open('x') as so,(out/'reference_diagnostic.stderr.txt').open('x') as se:
  process=subprocess.Popen(cmd,stdout=so,stderr=se,start_new_session=True)
  try:exit_code=process.wait(timeout=plan['process_cap_seconds'])
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(process.pid,signal.SIGKILL);process.wait();exit_code=process.returncode
 diag=out/'diagnostic/diagnostic.json';status=json.loads(diag.read_text())['diagnostic_status'] if diag.exists() else 'UNRESOLVED_DIAGNOSTIC'
 files={str(path.relative_to(out)):{'sha256':sha(path),'bytes':path.stat().st_size} for path in sorted(out.rglob('*')) if path.is_file() and not path.is_symlink()}
 receipt={'schema':'X14_REFERENCE_DIAGNOSTIC_EXECUTION_V1','job_id':os.environ['SLURM_JOB_ID'],'original_job':plan['original_job'],'source_freeze_sha256':sha(freeze),'workflow_sha256':sha(__file__),'diagnostic_sha256':sha(HERE/'diagnose.py'),'plan_sha256':sha(HERE/'plan.json'),'status':status,'process':{'argv':cmd,'exit_code':exit_code,'elapsed_seconds':time.time()-start,'timed_out':timed_out,'cap_seconds':plan['process_cap_seconds']},'cpus':1,'memory_mb':3500,'outputs':files,'catalogue_status':'NOT_RUN','scientific_completions':0,'native_renderer_executed':False,'eigensolver_or_sampler_executed':False,'automatic_remedy':False,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/'execution.json').open('x') as stream:json.dump(receipt,stream,indent=2,allow_nan=False);stream.write('\n')
 return 0 if status in ('CAPTURED_ORIGINAL_FAILURE','ORIGINAL_COMPLETED_DIAGNOSTIC_ONLY') and not timed_out else 2
if __name__=='__main__':raise SystemExit(main())
