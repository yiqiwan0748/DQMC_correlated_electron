# X14 spectral peak-shift feasibility and source — NOT RUN

This new unexecuted analysis tests whether Lorentzian overlap moves apparent spectral maxima away from actual many-electron excitations. It reuses **all** complete P09 spin/momentum pole data from the already audited native-ED/independent-QuSpin record, with prior availability disclosed.

**Native ED supplied the original poles. Both renderers in this folder are new adapters; no existing native broadening API is claimed.** No ED/QuSpin solve, sampling, rendering calculation, freeze, job or scientific completion has been performed for X14.

The [protocol](PROTOCOL.md) fixes the model/state, five widths, all branches/channels, exact mass/tail formulas, full frequency mesh, peak census/mesh error controls, analytic single/two-pole controls, failure classification and excluded resource pilot before execution. The [manifest](manifest.toml) contains every threshold. The [prior-input manifest](prior_inputs.json) binds original scientific raw/source/audit bytes, while [primary references](primary_sources.json) identify QuSpin and actual independent SciPy APIs.

The existing pole arrays are sufficient: both complete N±1 branches and aggregate degenerate weights remain available; the old initial state and conventions are unchanged. Conditional binary64 root-control limitations, possible flat peaks, finite-window tails and cluster-mean uncertainty remain explicit. If any adequacy or registered physical-shift witness fails, no data-selected replacement is authorized.

Source: `render_native.py`, `render_quspin_reference.py`, `compare.py`, shared I/O contract, bounded analysis wrapper and engineering-only pilot assessor. The initial read-only source review and rejected unexecuted candidate are retained in `reviews/`. Its endpoint-enclosure and provenance findings have source-only fixes; 30 actual NumPy/SciPy critical source/native/RECORD hash pins now qualify the independent APIs before numerical work. Final root/peer re-review is pending; **do not freeze or execute yet**. The pilot counts zero; a separately approved complete result could count only one X14 idea. P09 and public44 are unchanged.
