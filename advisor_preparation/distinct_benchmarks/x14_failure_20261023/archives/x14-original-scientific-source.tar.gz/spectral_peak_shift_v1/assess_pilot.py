#!/usr/bin/env python3
"""Fixed engineering estimate only. Does not submit or admit a production job."""
import argparse,re
from pathlib import Path
from io_contract import cfg,read,write,sha,HERE

def main():
 p=argparse.ArgumentParser();p.add_argument('--raw',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();c=cfg();e=read(a.raw/'execution.json');q=read(a.raw/'comparison.json');r=c['resources']
 if e['schema']!='X14_READONLY_ANALYSIS_EXECUTION_V1' or e['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or e['cpus']!=1 or e['memory_mb']!=3500 or e['status']!='PROCESSES_COMPLETE' or e['mode']!='pilot' or [x['exit_code'] for x in e['processes']]!=[0,0,0] or q['mode']!='pilot' or q['status']!='PASS' or q['catalogue_status']!='NOT_RUN' or q['scientific_completions']!=0:raise ValueError('Incomplete or unqualified pilot')
 for n,row in e['outputs'].items():
  if sha(a.raw/n)!=row['sha256'] or (a.raw/n).stat().st_size!=row['bytes']:raise ValueError('Pilot output bytes changed')
 if q['target_sha256']!=sha(a.raw/'native.json') or q['reference_sha256']!=sha(a.raw/'reference.json') or not q['checks'] or not all(v['passed'] for v in q['checks']):raise ValueError('Wrong or incomplete pilot mathematical gates')
 rss=[]
 for z in e['processes']:
  m=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',(a.raw/(z['name']+'.resources.txt')).read_text())
  if not m:raise ValueError('Missing process RSS')
  rss.append(int(m[1]))
 times={x['name']:x['elapsed_seconds'] for x in e['processes']};forecast=r['projection_factor']*8*(times['native']+times['reference']+times['comparator'])+30;eligible=max(rss)<=r['max_pilot_rss_KiB'] and forecast<=r['max_projected_full_seconds']
 write(a.output,dict(schema='X14_EXCLUDED_PILOT_ENGINEERING_V1',status='ELIGIBLE_FOR_SEPARATE_ROOT_REVIEW' if eligible else 'UNRESOLVED',projected_full_seconds=forecast,max_pilot_rss_KiB=max(rss),source_freeze_sha256=sha(HERE/'source_freeze.json'),execution_sha256=sha(a.raw/'execution.json'),comparison_sha256=sha(a.raw/'comparison.json'),scientific_completions=0,submission_admitted=False,projection_rule=r['projection_rule'],new_science_or_job_executed=False))
if __name__=='__main__':main()
