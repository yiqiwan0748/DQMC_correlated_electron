# X14: broadening-induced apparent peak shifts — UNEXECUTED preparation

This is exactly catalogue **X14**, “Do plotted peak positions misrepresent actual excitation energies?” It is a distinct rendering/broadening error question, not another P09 excitation-pole comparison or another idea for each width. No new analysis, spectrum, controls, freeze, job or catalogue completion has been executed by this preparation. Root and independent review must finish before any source freeze or execution.

## Prior availability and actual scientific attribution

The complete P09 data from ISAAC job6458468 were already available before this design. The prior source/schema, qualification metadata and file hashes were inspected; no numerical pole values, broadened spectra, peak locations or new numerical control result was evaluated or used to choose this protocol. This is explicitly a prospective **new rendering analysis of previously available exact spectra**, not an unseen-data study.

The unchanged prior native adapter calls actual user `build_space`, `apply_hamiltonian!` and `ground_state_lanczos`; it uses the actual native Lanczos ground state, qualified against its dense same-sector eigensystem. Independent QuSpin constructs its own Hamiltonian and complete spin-resolved N±1 blocks and qualifies its own unique same-sector ground state. Both use the periodic four-site Hubbard chain, t=1,U=4, fixed (Nup,Ndown)=(2,2), physical H=−t hopping+U nup ndown, no centered shift, and physical frequency reference mu=2. Their complete energy groups include zero-weight states. All original source/raw/audit bytes are pinned under `prior/` and `prior_inputs.json`; the original archived release and native ED/thermal source are retained.

**The native-data pole input comes from actual user ED. Both Lorentzian renderers here are NEW adapters. No existing native broadening API is claimed or exercised.** No new ED, Lanczos, QuSpin solve, native DQMC, DMRG, sampling or time evolution occurs in this tranche. Prior P09 remains the pole question; X14 adds only broadening/peak/integrated-mass error control.

Frequencies remain addition E(N+1)−E0−mu and removal E0−E(N−1)−mu; Fourier normalization is1/sqrt(L). No frequency reflection or guessed-gap relabelling is allowed. Each eight-channel row retains addition, removal and their combined spectral measure. Initial-state matching is the original qualified unique fixed-sector state; no thermal mixture or different ground state is substituted.

## Fixed prospective grid

All eight prior spin/momentum rows, both branches and their sum are mandatory, in their original order. Widths are eta=[0.05,0.2,0.8,3.2,16.0] in hopping units. Eta16 is deliberately very broad, testing the large-width merging bias rather than claiming experimental resolution. The window is[−16,16] with65,537 equally spaced points, and its stride2 held-out mesh is fixed in advance. A finite pole outside the strict interior makes the release UNRESOLVED; the window is not enlarged after seeing data.

All groups/weights, including zeros, enter every convolution. No clipping, sorting-away small weights, fitting peaks to poles, changing widths, renormalizing a finite-window curve or selecting a successful channel is permitted. A declared visibility threshold1e−6 is used **only to label a physical peak-distance witness**; it never removes a pole from a curve or a sum rule. Weights within1e−8 of that threshold make the witness convention unresolved.

The fixed controls use poles/weights: single[1.25]/[1], symmetric[−1,1]/[.5,.5], unequal[−1,1]/[.75,.25], and the same unequal measure scaled by.37, [.2775,.0925]. All five widths enter all four controls. The symmetric two-pole maxima are analytically at0 if eta²≥3, otherwise at ±sqrt(2sqrt(1+eta²)−1−eta²). A single pole peaks at its exact position; multiplying every weight leaves all peak positions unchanged and scales total mass.

The excluded pilot is spinup,momentum index1, all three branches/all widths/all controls:35 renderer rows. Full analysis has140 rows:8×3×5 physical and4×5 controls. Those rows represent **one** distinct idea. A partial full grid cannot PASS.

## Spectral measure, mass and grouping uncertainty

For retained energy groups (epsilon_j,w_j), A_eta(omega)=sum_j w_j eta/[pi((omega−epsilon_j)²+eta²)]. Its full real-line integral is W=sum_j w_j, without division by W. Addition mass equals the retained independent addition norm, removal mass equals occupation, and the combined mass is1. Controls have their stated total weight.

Native rendering uses a new explicit NumPy Lorentz kernel, golden-section local maximization and analytic arctangent window integrals. The independent renderer uses actual SciPy Cauchy PDF/CDF/SF, independently accumulated scalar QUADPACK integrals, and an independently coded derivative/root census. Kernels are not imported from each other. Shared code handles file hashes, declared roles and grid selection only.

Finite-window mass is sum_j w_j[atan((b−epsilon_j)/eta)−atan((a−epsilon_j)/eta)]/pi. The missing mass stays visible. For all poles inside(a,b), it is positive and bounded by sum_j w_j eta/pi[1/(b−epsilon_j)+1/(epsilon_j−a)]. This bound follows atan(x)≤x for positive tail arguments. QUADPACK's error field is an estimate, separately qualified against its fixed gate; no interval-proof claim follows.

Composite Simpson integration uses every mesh point. The analytic bound |L_eta^(n)|≤n!/(pi eta^(n+1)) gives absolute Simpson error ≤(b−a)h^4 W 24/(180pi eta^5). The full and coarse peak-height mesh bounds use ||A''||≤2W/(pi eta³), yielding W h²/(4pi eta³) and four times that value, respectively. These explicit bounds are compared to the actual retained mesh extrema and masses.

The older P09 groups use unweighted mean energy within a cluster. Group span≤1e−8 is retained, with a conservative possible raw-pole replacement error sum_j w_j span_j/(pi eta²), from |L'|≤1/(pi eta²). This error must be≤1e−6 for every rendering; it is reported rather than silently treating a numerically grouped mean as an exact new excitation. The original energy/residue gates remain1e−8.

Cauchy/Lorentzian tails do not have finite ordinary variance and their mean is not an ordinary convergent expectation. No broadened second moment, variance or “spectral gap from the plotted maximum” is computed. Original exact pole moments remain prior P09 evidence.

## Peak coverage, locations and finite-precision scope

The native-data renderer retains every mesh local-maximum candidate and refines its enclosing neighboring-mesh interval with golden-section search to width≤1e−8. Golden-section unimodality is **not assumed**: the comparator requires negative curvature throughout that original interval and matches **all** maxima to the independent root census. Flat/unresolved candidates cannot certify X14.

For positive weights, A'>0 below the smallest pole and A'<0 above the largest. All real maxima therefore lie inside the declared window when all poles do. The reference recursively covers the entire window, not only mesh sign changes. For each component, extrema of A' occur at offset ±eta/sqrt(3); extrema of A'' occur at offsets0,±eta. Evaluating those analytic candidates and interval endpoints bounds each term over an interval, then summing bounds encloses the derivative/curvature under the stated binary64 allowance. Intervals excluding zero derivative are discarded. A strictly monotone derivative with a sign bracket contains one stationary point; Brent gives a location and bisection retains a≤1e−7 bracket. Positive curvature marks a minimum; negative curvature marks a maximum. Shared endpoints are deduplicated. A remaining flat/stationary interval, budget exhaustion or unqualified curvature yields UNRESOLVED.

The source freezes100,000 intervals, depth55 and a binary64 padding1e−13 W/eta^(order+1). **This is conditional floating-point numerical error control, not a directed-rounding interval proof.** Every root's derivative, curvature, complete coverage metadata, analytic controls and cross-backend result remain explicit. If the binary64/flat-root qualifications fail, no stronger claim is substituted.

Native golden-section comparisons have an additional predeclared rounding allowance in the derivative gate:1e−8+16W sqrt(eps)/(pi eta²)+2W bracket_width/(pi eta³). This acknowledges near-equal function values; a tiny final golden bracket alone is not claimed as a rigorous peak-location interval. Reference bracket widths, independent all-maxima matching, strict local concavity and fixed2e−3 cross-position tolerance independently qualify reported locations. Every reference peak must lie within half a mesh spacing (plus its bracket uncertainty) of the declared mesh. Global maxima are compared as sets with a1e−10 height-tie rule, preserving symmetry-related ties rather than arbitrarily selecting one sign.

Every one of the65,537 mesh values is independently reconstructed and compared by the frozen comparator. Fixed257-point diagnostic probes and full-grid byte hashes are saved by each renderer. The hashes are provenance/reconstruction guards, **not a requirement that different formulas have identical binary64 bytes**. The full curves are reproducible from complete retained poles, widths and source, avoiding hundreds of megabytes of duplicate text arrays. Cross-formula full-grid errors use the fixed1e−6 science gate; stored-versus-replayed same-formula probes use1e−12.

A full-release qualification additionally requires at least one combined physical spectrum at registered eta16 whose global-maximum set has distance≥.01 from every visible exact pole and at least two retained poles with weight≥1e−4 and separation in[1e−5,2eta]. All eight registered channels are checked; the witness is selected by the **predeclared full-grid predicate**, never by changing parameters or omitting failed points. This demonstrates overlap-induced apparent displacement; it is not a fitted excitation or physical gap. Absence of the registered witness is UNRESOLVED, not a replacement fixture or extra look.

## Failure classification and execution controls

Bad source/raw closure, incomplete grid, invalid normalization/positivity, unresolved stationary coverage, numerical adequacy or absent physical witness yields UNRESOLVED. Qualified native-versus-independent curve/pole/peak disagreement is FAIL. A complete full analysis with all qualifications/comparisons passing can add exactly one X14 PASS after independent audit. Every pilot, failed attempt, partial output and subsequent repair remains visible with zero pilot credit.

No `source_freeze.json` is generated by this preparation. Both renderers reject an unfrozen source and require a Slurm analysis allocation; their functions are not called by syntax review. The root first reviews/finalizes source and gates, then separately approves a freeze and pilot. One CPU/3500MB,10-minute pilot cap/540-second inner cap. Runtime is unmeasured. The separately proposed full cap is20minutes/1080 seconds, and its execution requires an exact root-reviewed pilot-admission receipt plus matching pilot assessment. The fixed engineering projection is2×8×(pilot native+reference+comparator process wall)+30seconds; eligibility requires≤1000seconds and maximum pilot RSS≤2,800,000KiB. This is a conservative engineering estimate, not a timing or numerical guarantee. It grants no submission permission.

Before any actual job, root must inspect the live whole-user queue, include unrelated jobs in the two-slot limit, and serialize as required. These source files submit no jobs and do not enable automation. No public count, CV or prior source is changed by this preparation. The source archive/freezing and final public selection remain separate reviewed actions.
