#!/usr/bin/env python3
"""Complete-grid X14 arithmetic/peak gates. No eigensolver or sampler calls."""
import argparse,math,hashlib,sys
from pathlib import Path
import numpy as np
from scipy.stats import cauchy
from io_contract import cfg,read,write,verify_prior,spectra,sha,HERE
from render_native import curve
from render_quspin_reference import derivative,second,interval_bounds

class Audit:
 def __init__(self):self.checks=[]
 def need(self,name,condition,kind='qualification'):
  self.checks.append(dict(name=name,passed=bool(condition),kind=kind))
 def error(self,name,value,bound,kind='comparison'):
  self.checks.append(dict(name=name,value=float(value),bound=float(bound),passed=bool(math.isfinite(value) and value<=bound),kind=kind))

def close_points(x,y):
 if not x or not y:return math.inf
 return max(max(min(abs(a-b) for b in y) for a in x),max(min(abs(b-a) for a in x) for b in y))

def compare(t,q,c):
 a=Audit();g=c['gates'];mode=t['mode'];a.need('same declared mode',mode==q['mode'] and mode in ['pilot','production']);expected=[(s['id'],eta) for s in spectra('native',mode,c) for eta in c['etas']]
 maps=[];original_specs={b:{s['id']:s for s in spectra(b,mode,c)} for b in ['native','quspin']}
 for backend,d in [('native',t),('reference',q)]:
  a.need(backend+'/identity',d['schema']=='X14_RENDERED_RAW_V1' and d['scientific_completions']==0 and not d['producer_or_sampler_executed']);a.need(backend+'/freeze',d['source_freeze_sha256']==sha(HERE/'source_freeze.json') and d['prior_input_manifest_sha256']==sha(HERE/'prior_inputs.json'))
  m={(r['id'],r['eta']):r for r in d['rows']};a.need(backend+'/complete grid',len(m)==len(d['rows'])==len(expected) and list(m)==expected);maps.append(m)
 if any(not x['passed'] for x in a.checks):return a,[],[]
 details=[];witnesses=[];x=np.linspace(c['frequency_min'],c['frequency_max'],c['mesh_points']);dx=float(x[1]-x[0])
 for key in expected:
  n,r=maps[0][key],maps[1][key];tag=key[0]+'/eta'+str(key[1]);eta=key[1];e=np.array(n['poles']);w=np.array(n['weights']);er=np.array(r['poles']);wr=np.array(r['weights']);a.need(tag+'/same complete poles',len(e)==len(er) and len(w)==len(wr));a.need(tag+'/native exact reused groups',n['groups']==original_specs['native'][key[0]]['groups']);a.need(tag+'/reference exact reused groups',r['groups']==original_specs['quspin'][key[0]]['groups'])
  if len(e)!=len(er):continue
  a.error(tag+'/exact prior poles',float(max(abs(e-er),default=0)),g['prior_pole_abs']);a.error(tag+'/exact prior weights',float(max(abs(w-wr),default=0)),g['prior_weight_abs'])
  for backend,z in [('native',n),('reference',r)]:
   a.error(tag+'/'+backend+'/independent full spectral weight',abs(z['full_weight']-z['expected_total_weight']),g['prior_sumrule_abs'],'qualification');a.need(tag+'/'+backend+'/nonnegative complete weights',all(v>=0 and math.isfinite(v) for v in z['weights']));a.need(tag+'/'+backend+'/pole interior',all(c['frequency_min']<v<c['frequency_max'] for v in z['poles']));a.need(tag+'/'+backend+'/group coverage',all(v['span']<=g['cluster_span_max'] and v['multiplicity']>=1 for v in z['groups']));a.error(tag+'/'+backend+'/cluster rendering uncertainty',z['cluster_render_error_bound'],g['cluster_render_bound_max'],'qualification')
  # Reconstruct and compare every predefined frequency point, in independent
  # formulas. Stored full-grid hashes are provenance, not a scientific-equality gate.
  yn=curve(x,e,w,eta);yr=cauchy.pdf(x[:,None],loc=er[None,:],scale=eta)@wr
  a.error(tag+'/all full-mesh PDF values',float(np.max(abs(yn-yr))),g['full_curve_abs']);a.need(tag+'/native mesh hash',hashlib.sha256(np.asarray(yn,dtype='<f8').tobytes()).hexdigest()==n['full_mesh_binary64_sha256']);a.need(tag+'/reference mesh hash',hashlib.sha256(np.asarray(yr,dtype='<f8').tobytes()).hexdigest()==r['full_mesh_binary64_sha256'])
  probe=np.linspace(0,len(x)-1,257,dtype=int);a.need(tag+'/probe grid',n['probe_indices']==r['probe_indices']==probe.tolist());a.error(tag+'/native stored probes',max(abs(yn[probe]-n['probe_values'])),g['pointwise_binary64_abs'],'qualification');a.error(tag+'/reference stored probes',max(abs(yr[probe]-r['probe_values'])),g['pointwise_binary64_abs'],'qualification')
  a.error(tag+'/finite-window mass native-vs-reference',abs(n['finite_window_analytic_mass']-r['finite_window_library_cdf_mass']),g['finite_mass_abs']);a.error(tag+'/independent quadrature',abs(r['finite_window_quadrature_mass']-r['finite_window_library_cdf_mass']),g['finite_mass_abs'],'qualification');a.error(tag+'/quadrature error estimate',r['quadrature_error_estimate'],g['quadrature_error_max'],'qualification');a.error(tag+'/Simpson bound eligible',n['simpson_error_bound'],g['simpson_absolute_max'],'qualification');a.error(tag+'/Simpson integral error',abs(n['finite_window_simpson_mass']-n['finite_window_analytic_mass']),n['simpson_error_bound']+g['pointwise_binary64_abs'],'qualification');a.error(tag+'/full mass with tails',abs(n['finite_window_analytic_mass']+n['outside_window_mass']-sum(w)),g['prior_sumrule_abs'],'qualification');a.error(tag+'/independent full mass with tails',abs(r['finite_window_library_cdf_mass']+r['outside_window_mass']-sum(wr)),g['prior_sumrule_abs'],'qualification');a.need(tag+'/positive tail bound',0<=n['outside_window_mass']<=n['outside_window_upper_bound']+g['pointwise_binary64_abs']);a.error(tag+'/outside mass cross',abs(n['outside_window_mass']-r['outside_window_mass']),g['finite_mass_abs'])
  # Every reference stationary root is covered by the interval census. Golden
  # sections must match all maxima, not a chosen largest hump.
  a.need(tag+'/complete root census',r['root_census_complete']);npk=[v['location'] for v in n['peaks']];rpk=[v['location'] for v in r['peaks']];a.need(tag+'/all local maximum counts',len(npk)==len(rpk));a.error(tag+'/all maximum locations',close_points(npk,rpk),g['peak_location_abs'])
  for i,p in enumerate(n['peaks']):
   lo,hi=p['bracket'];a.error(tag+f'/native golden width{i}',hi-lo,c['numerics']['golden_bracket_width_max'],'qualification');left,right=p['initial_mesh_bracket'];a.need(tag+f'/native peak stays inside original mesh bracket{i}',left<=lo<=hi<=right)
   cl,ch=interval_bounds(left,right,e,w,eta,2,c['numerics']['stationary_binary64_padding']);a.need(tag+f'/native mesh neighborhood is strictly concave{i}',ch < -g['minimum_peak_curvature']);a.error(tag+f'/native peak derivative{i}',abs(derivative(p['location'],e,w,eta)),g['stationary_derivative_abs']+16*sum(w)*math.sqrt(np.finfo(float).eps)/(math.pi*eta**2)+2*sum(w)*c['numerics']['golden_bracket_width_max']/(math.pi*eta**3),'qualification')
  for i,p in enumerate(r['peaks']):
   a.error(tag+f'/reference root bracket{i}',p['bracket'][1]-p['bracket'][0],c['numerics']['stationary_bracket_width_max'],'qualification');a.need(tag+f'/reference curvature{i}',p['curvature'] < -g['minimum_peak_curvature']);a.error(tag+f'/reference derivative{i}',p['derivative_abs'],g['stationary_derivative_abs'],'qualification');a.error(tag+f'/mesh proximity{i}',min(abs(x-p['location'])),min(g['root_to_mesh_max'],dx/2+c['numerics']['stationary_bracket_width_max']),'qualification')
  # Max value error for a stationary point from a nearest grid point, using
  # ||A''|| <= 2W/(pi eta^3). Coarse stride2 has its own explicit bound.
  maxheight=max(p['height'] for p in n['peaks']);finebound=sum(w)*dx**2/(4*math.pi*eta**3);coarsebound=finebound*c['coarse_mesh_stride']**2
  a.error(tag+'/fine mesh maximum-height discretization',abs(maxheight-n['mesh_maximum_height']),finebound+g['pointwise_binary64_abs'],'qualification');a.error(tag+'/coarse mesh maximum-height discretization',abs(maxheight-n['coarse_mesh_maximum_height']),coarsebound+g['pointwise_binary64_abs'],'qualification')
  ntie=[p['location'] for p in n['peaks'] if p['height']>=max(v['height'] for v in n['peaks'])-c['numerics']['global_peak_height_tie_abs']];rtie=[p['location'] for p in r['peaks'] if p['height']>=max(v['height'] for v in r['peaks'])-c['numerics']['global_peak_height_tie_abs']];a.error(tag+'/global maximum set',close_points(ntie,rtie),g['peak_location_abs'])
  visible=[v for v,ww in zip(er,wr) if ww>=c['visible_pole_weight_min']];shift=min((min(abs(p-v) for v in visible) for p in rtie),default=0.);overlap=any(abs(er[i]-er[j])>=c['minimum_distinct_pole_separation'] and abs(er[i]-er[j])<=2*eta and wr[i]>=c['minimum_overlapping_pole_weight'] and wr[j]>=c['minimum_overlapping_pole_weight'] for i in range(len(er)) for j in range(i))
  if n['role']=='physical':
   a.need(tag+'/visibility threshold clearance',all(abs(v-c['visible_pole_weight_min'])>=c['visible_threshold_clearance'] for v in wr));a.need(tag+'/full branch mass identity',abs(sum(w)-n['expected_total_weight'])<=g['prior_sumrule_abs'])
   if n['branch']=='combined' and eta==c['witness_eta']:witnesses.append(dict(id=n['id'],eta=eta,minimum_distance_to_visible_exact_pole=shift,visible_pole_threshold=c['visible_pole_weight_min'],overlapping_poles=overlap,eligible=shift>=c['minimum_physical_peak_to_visible_pole_distance'] and overlap))
  if n['id']=='control_single':a.error(tag+'/single-pole unchanged maximum',close_points(npk,[1.25]),g['control_location_abs'])
  if n['id']=='control_equal':
   z=2*math.sqrt(1+eta**2)-(1+eta**2);exact=[0.] if z<=0 else [-math.sqrt(z),math.sqrt(z)];a.error(tag+'/analytic equal-pair maxima',close_points(rpk,exact),g['control_location_abs'])
  if n['id']=='control_rescaled':
   u=maps[0][('control_unequal',eta)];a.error(tag+'/weight scaling leaves maxima fixed',close_points(npk,[v['location'] for v in u['peaks']]),g['control_location_abs']);a.error(tag+'/weight scaling preserves mass ratio',abs(n['full_weight']-c['controls']['rescaling_factor']*u['full_weight']),g['control_rescaling_abs'])
  details.append(dict(id=n['id'],eta=eta,peak_count=len(rpk),global_maxima=rtie,minimum_distance_to_visible_pole=shift,full_weight=sum(w),finite_window_mass=n['finite_window_analytic_mass'],outside_mass=n['outside_window_mass'],mesh_height_bound=finebound))
 if mode=='production':a.need('physical complete-grid broadening-shift and overlap witness',any(w['eligible'] for w in witnesses))
 return a,details,witnesses

def main():
 p=argparse.ArgumentParser();p.add_argument('--target',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();c=cfg();verify_prior();t,q=read(a.target),read(a.reference);error=None
 try:checks,details,witness=compare(t,q,c);status='UNRESOLVED' if any(not r['passed'] and r['kind']=='qualification' for r in checks.checks) else 'FAIL' if any(not r['passed'] for r in checks.checks) else 'PASS'
 except Exception as ex:checks=Audit();details=[];witness=[];status='UNRESOLVED';error=type(ex).__name__+': '+str(ex)
 mode=t.get('mode');write(a.output,dict(schema='X14_COMPARISON_V1',status=status,catalogue_status=status if mode=='production' else 'NOT_RUN',scientific_completions=int(mode=='production' and status=='PASS'),mode=mode,pilot_excluded=mode=='pilot',checks=checks.checks,details=details,physical_shift_witnesses=witness,exception=error,target_sha256=sha(a.target),reference_sha256=sha(a.reference),scientific_scope='Broadening error of reused audited native/QuSpin Lehmann data only; no new eigenstate, eigensolver, sampling or physical-gap claim'))
 print(status);sys.exit({'PASS':0,'FAIL':1,'UNRESOLVED':2}[status])
if __name__=='__main__':main()
