"""Shared hashing/grid/role contract only. Spectral kernels are independent."""
from pathlib import Path
import hashlib,json,tomllib,sys,os,tarfile
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 p=Path(p);return tomllib.loads(p.read_text()) if p.suffix=='.toml' else json.loads(p.read_text())
def plain(x):
 import numpy as np
 if isinstance(x,dict):return {str(k):plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [plain(v) for v in x]
 return x.item() if isinstance(x,np.generic) else x
def write(p,x):
 p=Path(p)
 if p.exists():raise ValueError('Refuse overwrite')
 p.write_text(json.dumps(plain(x),indent=2,allow_nan=False)+'\n')
def cfg():return read(HERE/'manifest.toml')
def verify_prior():
 pins=read(HERE/'prior_inputs.json')
 for n,r in pins['files'].items():
  p=HERE/n
  if not p.is_file() or p.is_symlink() or sha(p)!=r['sha256'] or p.stat().st_size!=r['bytes']:raise ValueError('Changed prior scientific bytes '+n)
 previous=read(HERE/'prior/previous_manifest.toml');audit=read(HERE/'prior/independent_audit_attempt01.json');comp=read(HERE/'prior/comparison.json')
 if audit['status']!='PASS' or next(r for r in comp['rows'] if r['id']=='P09')['status']!='PASS':raise ValueError('Prior P09 not independently qualified')
 if audit['source_archive_sha256']!=sha(HERE/'prior/spectral-dynamics-v1-source.tar.gz'):raise ValueError('Prior source archive mismatch')
 if audit['manifest_sha256']!=sha(HERE/'prior/previous_manifest.toml') or audit['auditor_sha256']!=sha(HERE/'prior/previous_independent_auditor.py'):raise ValueError('Prior independent audit binding differs')
 for name,row in pins['files'].items():
  if row['original_role'].startswith('advisor_preparation/'):
   original=row['original_role'].removeprefix('advisor_preparation/')
   if original in audit['input_sha256'] and audit['input_sha256'][original]!=sha(HERE/name):raise ValueError('Original independent audit input changed')
 freeze=read(HERE/'prior/spectral-dynamics-v1-freeze.json');seen=set()
 with tarfile.open(HERE/'prior/spectral-dynamics-v1-source.tar.gz','r:gz') as tar:
  for item in tar:
   if not item.isfile() or item.name in seen or item.name not in freeze['files']:raise ValueError('Prior archive membership differs')
   if hashlib.sha256(tar.extractfile(item).read()).hexdigest()!=freeze['files'][item.name]:raise ValueError('Prior original source member changed')
   seen.add(item.name)
 if seen!=set(freeze['files']):raise ValueError('Prior source archive incomplete')
 for backend,path in [('native','target.toml'),('quspin','oracle.json')]:
  data=read(HERE/'prior'/path)
  if data['manifest_sha256']!=sha(HERE/'prior/previous_manifest.toml'):raise ValueError('Prior raw manifest differs')
  if backend=='native':
   if data['adapter_sha256']!=sha(HERE/'prior/previous_target_ed.jl') or data['ed_source_sha256']!=sha(HERE/'prior/native/compute_s2_ed.jl') or data['thermal_source_sha256']!=sha(HERE/'prior/native/audit_u4_l4_thermal_ed.jl'):raise ValueError('Prior actual native source differs')
  elif data['oracle_source_sha256']!=sha(HERE/'prior/previous_oracle_quspin.py'):raise ValueError('Prior actual QuSpin source differs')
 if previous['L']!=4 or previous['U']!=4 or previous['P09']['physical_mu_frequency']!=2 or previous['P09']['broadening']!='NONE':raise ValueError('Wrong previous scientific model')
 return pins

def contract(mode):
 import numpy as np,scipy
 c=cfg()
 if mode not in ['pilot','production']:raise ValueError('Explicit mode required')
 if np.__version__!=c['numpy_version'] or scipy.__version__!=c['scipy_version']:raise ValueError('Pinned math runtime required')
 if sys.version_info<(3,11):raise ValueError('Python3.11+ required')
 if not (HERE/'source_freeze.json').is_file() or not os.getenv('SLURM_JOB_ID'):raise ValueError('Preparation is unfrozen; root-reviewed source freeze and Slurm analysis job required')
 freeze=read(HERE/'source_freeze.json')
 for n,h in freeze['files'].items():
  if sha(HERE/n)!=h:raise ValueError('Changed frozen source '+n)
 verify_prior();return c

def spectra(backend,mode,c):
 data=read(HERE/'prior'/('target.toml' if backend=='native' else 'oracle.json'));rows=data['P09']['rows'];expected=[(s,m) for s in c['spins'] for m in c['momenta']]
 if [(r['spin'],r['momentum_index']) for r in rows]!=expected:raise ValueError('Incomplete prior P09 grid')
 out=[]
 for row in rows:
  if mode=='pilot' and (row['spin'],row['momentum_index'])!=(c['pilot_spin'],c['pilot_momentum']):continue
  for branch in c['branches']:
   groups=row['addition']+row['removal'] if branch=='combined' else row[branch]
   out.append(dict(id=f"{row['spin']}_k{row['momentum_index']}_{branch}",role='physical',spin=row['spin'],momentum=row['momentum_index'],branch=branch,groups=groups,expected_total_weight=1. if branch=='combined' else row['addition_norm' if branch=='addition' else 'occupation']))
 for name in ['single','equal','unequal','rescaled']:
  groups=[dict(omega=e,weight=w,multiplicity=1,span=0.) for e,w in zip(c['controls'][name+'_pole' if name=='single' else name+'_poles'],c['controls'][name+'_weight' if name=='single' else name+'_weights'])]
  out.append(dict(id='control_'+name,role='control',branch='control',groups=groups))
 return out
