#!/usr/bin/env python3
"""Independent SciPy Cauchy renderer/root census of retained QuSpin poles."""
import argparse,hashlib,math,time,warnings
from pathlib import Path
import numpy as np
from scipy.stats import cauchy
from scipy.integrate import quad,IntegrationWarning
from scipy.optimize import brentq
from io_contract import contract,spectra,write,sha,HERE

def scalar(x,e,w,eta):return math.fsum(float(q)*eta/(math.pi*((x-float(p))**2+eta**2)) for p,q in zip(e,w))
def derivative(x,e,w,eta):return math.fsum(-2*eta*float(q)*(x-float(p))/(math.pi*((x-float(p))**2+eta**2)**2) for p,q in zip(e,w))
def second(x,e,w,eta):return math.fsum(-2*eta*float(q)*(eta**2-3*(x-float(p))**2)/(math.pi*((x-float(p))**2+eta**2)**3) for p,q in zip(e,w))
def interval_bounds(a,b,e,w,eta,order,padding):
 lo=[];hi=[]
 for p,q in zip(e,w):
  l,r=a-p,b-p;points=[l,r];critical=[-eta/math.sqrt(3),eta/math.sqrt(3)] if order==1 else [-eta,0.,eta]
  points += [t for t in critical if l<=t<=r]
  if order==1:values=[-2*eta*q*t/(math.pi*(t*t+eta*eta)**2) for t in points]
  else:values=[-2*eta*q*(eta*eta-3*t*t)/(math.pi*(t*t+eta*eta)**3) for t in points]
  lo.append(min(values));hi.append(max(values))
 eps=padding*sum(w)/eta**(order+1)
 return math.fsum(lo)-eps,math.fsum(hi)+eps

def stationary(e,w,eta,c):
 n=c['numerics'];a,b=c['frequency_min'],c['frequency_max'];stack=[(a,b,0)];roots=[];uncertain=[];visited=0;excluded=0
 while stack:
  a,b,depth=stack.pop();visited+=1
  if visited>n['stationary_max_intervals']:raise ValueError('Root census exceeded fixed interval budget')
  lo,hi=interval_bounds(a,b,e,w,eta,1,n['stationary_binary64_padding'])
  if lo>0 or hi<0:excluded+=1;continue
  cl,ch=interval_bounds(a,b,e,w,eta,2,n['stationary_binary64_padding']);fa,fb=derivative(a,e,w,eta),derivative(b,e,w,eta)
  monotone=cl>0 or ch<0
  if monotone and fa*fb>0:excluded+=1;continue
  if monotone and fa*fb<=0:
   root=float(brentq(lambda x:derivative(x,e,w,eta),a,b,xtol=n['brent_xtol'],maxiter=200));left,right=a,b
   # Retain a small independent sign-changing bracket, not only Brent's point.
   for _ in range(180):
    if right-left<=n['stationary_bracket_width_max']:break
    mid=(left+right)/2;fm=derivative(mid,e,w,eta)
    if fm==0:left=max(left,mid-n['stationary_bracket_width_max']/4);right=min(right,mid+n['stationary_bracket_width_max']/4);break
    if derivative(left,e,w,eta)*fm<=0:right=mid
    else:left=mid
   if right-left>n['stationary_bracket_width_max']:raise ValueError('Root bracket unresolved')
   roots.append(dict(location=root,height=scalar(root,e,w,eta),bracket=[left,right],curvature=second(root,e,w,eta),monotone_parent=[a,b],curvature_bounds=[cl,ch],type='maximum' if ch<0 else 'minimum',derivative_abs=abs(derivative(root,e,w,eta))));continue
  if depth>=n['stationary_max_depth'] or b-a<=n['stationary_bracket_width_max']:
   uncertain.append([a,b]);continue
  middle=(a+b)/2;stack.extend([(a,middle,depth+1),(middle,b,depth+1)])
 if uncertain:raise ValueError('Stationary/flat point remains unresolved; no hidden maximum accepted')
 roots.sort(key=lambda r:r['location']);dedup=[]
 for r in roots:
  if dedup and abs(r['location']-dedup[-1]['location'])<=2*n['stationary_bracket_width_max']:
   if r['type']!=dedup[-1]['type']:raise ValueError('Inconsistent duplicate stationary classification')
   continue
  dedup.append(r)
 return dedup,visited,excluded

def render(s,eta,c):
 e=np.array([g['omega'] for g in s['groups']],float);w=np.array([g['weight'] for g in s['groups']],float);a,b=c['frequency_min'],c['frequency_max'];W=float(math.fsum(w));x=np.linspace(a,b,c['mesh_points'])
 if min(w)<0 or not a<min(e)<=max(e)<b or W<=c['gates']['minimum_total_branch_weight']:raise ValueError('Invalid positive interior spectral measure')
 # Actual independent distribution-library PDF/CDF, not the native kernel.
 y=np.asarray(cauchy.pdf(x[:,None],loc=e[None,:],scale=eta))@w
 cdf=float(np.dot(cauchy.cdf(b,loc=e,scale=eta)-cauchy.cdf(a,loc=e,scale=eta),w));outside=float(np.dot(cauchy.cdf(a,loc=e,scale=eta)+cauchy.sf(b,loc=e,scale=eta),w))
 with warnings.catch_warnings():
  warnings.simplefilter('error',IntegrationWarning)
  mass,error=quad(lambda z:scalar(z,e,w,eta),a,b,points=sorted(set(e)),epsabs=c['numerics']['quadrature_epsabs'],epsrel=c['numerics']['quadrature_epsrel'],limit=c['numerics']['quadrature_limit'])
 roots,visited,excluded=stationary(e,w,eta,c);probe=np.linspace(0,len(x)-1,257,dtype=int);peaks=[r for r in roots if r['type']=='maximum']
 if not peaks:raise ValueError('No certified interior maximum')
 return dict(id=s['id'],role=s['role'],branch=s['branch'],expected_total_weight=s.get('expected_total_weight',0.37 if s['id']=='control_rescaled' else 1.),eta=eta,poles=e.tolist(),weights=w.tolist(),groups=s['groups'],full_weight=W,probe_indices=probe.tolist(),probe_values=y[probe].tolist(),full_mesh_binary64_sha256=hashlib.sha256(np.asarray(y,dtype='<f8').tobytes()).hexdigest(),peaks=peaks,all_stationary_points=roots,root_census_intervals=visited,root_excluded_intervals=excluded,root_census_complete=True,finite_window_library_cdf_mass=cdf,finite_window_quadrature_mass=float(mass),quadrature_error_estimate=float(error),outside_window_mass=outside,cluster_render_error_bound=math.fsum(g['weight']*g['span'] for g in s['groups'])/(math.pi*eta**2))

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('output',type=Path);a=p.parse_args();c=contract(a.mode);start=time.time();rows=[]
 for s in spectra('quspin',a.mode,c):
  for eta in c['etas']:rows.append(render(s,eta,c))
 write(a.output,dict(schema='X14_RENDERED_RAW_V1',backend='retained_QuSpin_Lehmann_new_independent_SciPy_renderer',mode=a.mode,scientific_completions=0,source_freeze_sha256=sha(HERE/'source_freeze.json'),prior_input_manifest_sha256=sha(HERE/'prior_inputs.json'),renderer_sha256=sha(__file__),rows=rows,elapsed_seconds=time.time()-start,new_QuSpin_solve=False,producer_or_sampler_executed=False))
if __name__=='__main__':main()
