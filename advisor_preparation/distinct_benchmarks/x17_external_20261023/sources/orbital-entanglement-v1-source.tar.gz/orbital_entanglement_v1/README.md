# X17 orbital entanglement — preparation only

**NOT FROZEN; NOT EXECUTED; X17 remains NOT_RUN.** Parent and independent source review are required before any freeze or resource pilot. No job has been submitted by this preparation.

The fixed protocol compares six open 2×2,N=4 fixtures (U=0/2/6 × t4=0/−.65, t3=0) using the actual native Lanczos state and unchanged repaired native Rényi entropy function. An explicitly new full orbital-RDM/spin/certificate adapter is compared with independently constructed QuSpin states and actual fermionic partial traces. All256 RDM eigenvalues, connected density/spin-dot observables, global unique-singlet certificates and analytic constant-density/product controls must pass before entropy is interpreted. One full campaign can complete only the original X17 idea.

Read [PROTOCOL.md](PROTOCOL.md) and [manifest.toml](manifest.toml) for conventions, qualifications, failure classifications and proposed capped pilot/full wrappers. The copied native sources remain byte-identical. The entropy site's zero-based API and native hopping's one-based mode labels are explicitly distinguished. No dense vector can replace a failed native Lanczos state, and no state averaging, fixture removal or gate change is allowed after data.

The installed independent implementation is pinned by [reference_library_pins.json](reference_library_pins.json): 72 QuSpin/API/extension/RECORD file hashes, verified before computation and checked against every reference receipt. No runtime binaries are included. Parent and peer review of this final pre-execution revision remains pending.
