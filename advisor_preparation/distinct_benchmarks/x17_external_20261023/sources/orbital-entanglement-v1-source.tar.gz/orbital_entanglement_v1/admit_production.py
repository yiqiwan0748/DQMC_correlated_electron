#!/usr/bin/env python3
"""Check explicit frozen-pilot admission receipt; performs no execution/submission."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--receipt',type=Path,required=True);a=p.parse_args();r=json.loads(a.receipt.read_text());root=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
if r.get('schema')!='X17_INDEPENDENT_PILOT_RESOURCE_ADMISSION_V1' or r.get('status')!='PASS' or r.get('source_freeze_sha256')!=sha(root/'source_freeze.json') or r.get('pilot_case_ids')!=['U6_hybrid'] or r.get('all_producer_and_mathematical_gates_passed') is not True or r.get('scientific_completions')!=0 or r.get('max_process_rss_KiB',10**20)>2800000 or r.get('projected_full_seconds',10**20)>1600 or r.get('projected_full_peak_rss_KiB',10**20)>3000000:raise ValueError('Missing complete independently reviewed pilot/resource eligibility; no full execution')
print('Frozen pilot resource eligibility PASS; current scheduler/resource admission remains separately required')
