#!/usr/bin/env python3
"""Read-only pilot arithmetic/resource admission; no scientific producer runs."""
import argparse,hashlib,json,math,re,subprocess,sys,tomllib
from pathlib import Path
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def replay_agreement(saved,fresh,path=(),roundoff=None):
 # Every source/status/grid/gate identity and every bound remains exact.
 # Only re-evaluated floating gate values admit declared BLAS roundoff.
 if roundoff is None:roundoff=[]
 if type(saved) is not type(fresh):raise ValueError('Replay type differs at '+str(path))
 if isinstance(saved,dict):
  if saved.keys()!=fresh.keys():raise ValueError('Replay fields differ at '+str(path))
  for k in saved:replay_agreement(saved[k],fresh[k],path+(k,),roundoff)
 elif isinstance(saved,list):
  if len(saved)!=len(fresh):raise ValueError('Replay grid differs at '+str(path))
  for i,(s,f) in enumerate(zip(saved,fresh)):replay_agreement(s,f,path+(i,),roundoff)
 elif isinstance(saved,float) and path[-1:] == ('value',) and 'gates' in path:
  tolerance=max(1e-12,64*sys.float_info.epsilon*max(1.,abs(saved),abs(fresh)))
  if not math.isfinite(saved) or not math.isfinite(fresh) or abs(saved-fresh)>tolerance:raise ValueError('Replay gate arithmetic differs at '+str(path))
  if saved!=fresh:roundoff.append(dict(path=list(path),original=saved,replay=fresh,absolute_difference=abs(saved-fresh),replay_tolerance=tolerance))
 elif saved!=fresh:raise ValueError('Replay identity/status/bound differs at '+str(path))
 return roundoff
def main():
 p=argparse.ArgumentParser();p.add_argument('--pilot-dir',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=False);r=a.pilot_dir
 ex=json.loads((r/'execution.json').read_text());saved=json.loads((r/'comparison.json').read_text());cfg=tomllib.loads((HERE/'manifest.toml').read_text());freeze=sha(HERE/'source_freeze.json')
 if ex['schema']!='X17_EXECUTION_RECEIPT_V1' or ex['mode']!='pilot' or ex['status']!='PROCESSES_COMPLETE' or ex['source_freeze_sha256']!=freeze or [p['name'] for p in ex['processes']]!=['target','reference','comparator'] or any(p['exit_code']!=0 or p['timed_out'] for p in ex['processes']):raise ValueError('Incomplete/failed original pilot; no production admission')
 replay=a.output_dir/'comparison_replay.json';subprocess.run([sys.executable,'-B',str(HERE/'compare.py'),'--target',str(r/'target.toml'),'--reference',str(r/'reference.json'),'--output',str(replay)],check=True)
 fresh=json.loads(replay.read_text())
 roundoff=replay_agreement(saved,fresh)
 if fresh['status']!='PASS' or fresh['catalogue_status']!='NOT_RUN' or fresh['scientific_completions']!=0 or not fresh['pilot_excluded'] or [c['id'] for c in fresh['cases']]!=cfg['pilot_case_ids']:raise ValueError('Pilot scientific/completeness gate failure')
 rss=[];pins={}
 for process in ex['processes']:
  path=r/(process['name']+'.resources.txt');text=path.read_text();m=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',text)
  if not m:raise ValueError('Missing native process MaxRSS')
  rss.append(int(m[1]));pins[path.name]=sha(path)
 producer_seconds=sum(p['elapsed_seconds'] for p in ex['processes'] if p['name']!='comparator');projection=1.5*6*producer_seconds+60
 projected_rss=max(rss)+15*((r/'target.toml').stat().st_size+(r/'reference.json').stat().st_size)/1024
 passed=max(rss)<=2800000 and projected_rss<=3000000 and projection<=1600
 for name in ['execution.json','comparison.json','target.toml','reference.json']:pins[name]=sha(r/name)
 receipt=dict(schema='X17_INDEPENDENT_PILOT_RESOURCE_ADMISSION_V1',status='PASS' if passed else 'UNRESOLVED',source_freeze_sha256=freeze,pilot_job_id=ex['job_id'],pilot_case_ids=cfg['pilot_case_ids'],all_producer_and_mathematical_gates_passed=True,scientific_completions=0,max_process_rss_KiB=max(rss),projected_full_peak_rss_KiB=projected_rss,projected_full_seconds=projection,projection_formula='1.5*6*(pilot target+reference elapsed)+60s; peak=maxprocessRSS+15*(two producer file bytes)/1024; engineering estimate, not guaranteed convergence/time',full_budget_seconds=1800,input_sha256=pins,source_sha256={'audit_pilot.py':sha(__file__),'compare.py':sha(HERE/'compare.py')},replay_roundoff=roundoff,replay_scope='Exact identities/grids/statuses/gate directions/bounds/Boolean decisions; floating gate values only max(1e-12,64epsilon*scale) arithmetic replay tolerance; no scientific threshold change',physics_executed=False,needs_separate_current_scheduler_admission=True)
 (a.output_dir/'admission.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt['status']);sys.exit(0 if passed else 2)
if __name__=='__main__':main()
