#!/usr/bin/env python3
"""Full fixed six-fixture X17 gates; only archived-data arithmetic, no solver run."""
import argparse,hashlib,json,math,sys,tomllib
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):
 p=Path(p);return tomllib.loads(p.read_text()) if p.suffix=='.toml' else json.loads(p.read_text())
def plain(x):
 if isinstance(x,dict):return {str(k):plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [plain(v) for v in x]
 return x.item() if isinstance(x,np.generic) else x

def array(x,shape=None):
 a=np.asarray(x,float)
 if not np.all(np.isfinite(a)) or (shape is not None and a.shape!=tuple(shape)):raise ValueError('Nonfinite or incomplete numerical grid')
 return a

def matrix(row,d):
 if row['shape']!=[d,d] or not len(row['row'])==len(row['col'])==len(row['value']):raise ValueError('Invalid sparse grid')
 out=np.zeros((d,d));seen=set()
 for i,j,v in zip(row['row'],row['col'],row['value']):
  if type(i) is not int or type(j) is not int or not 0<=i<d or not 0<=j<d or (i,j) in seen or not math.isfinite(v):raise ValueError('Sparse entry invalid')
  out[i,j]=v;seen.add((i,j))
 return out

def labels(r,target):
 ls=[(u,d) for u in r['basis_up_masks'] for d in r['basis_down_masks']] if target else list(zip(r['basis_up_per_row'],r['basis_down_per_row']))
 if len(ls)!=r['dimension'] or len(set(ls))!=len(ls) or any(u.bit_count()!=r['Nup'] or d.bit_count()!=r['Ndown'] or u<0 or d<0 or u>=256 or d>=256 for u,d in ls):raise ValueError('Invalid fixed-sector basis labels')
 return ls

class Gates:
 def __init__(self):self.rows=[]
 def check(self,name,value,relation,bound,kind='qualification'):
  if relation=='le':ok=math.isfinite(value) and value<=bound
  elif relation=='ge':ok=math.isfinite(value) and value>=bound
  elif relation=='eq':ok=value==bound
  elif relation=='gt':ok=math.isfinite(value) and value>bound
  else:raise ValueError('Unknown direction')
  self.rows.append(dict(name=name,value=plain(value),relation=relation,bound=plain(bound),kind=kind,passed=bool(ok)))
 def error(self,name,a,b,tol,kind='comparison'):
  a=array(a);b=array(b)
  if a.shape!=b.shape:raise ValueError('Complete observable grids differ')
  self.check(name,float(np.max(abs(a-b),initial=0.)),'le',tol,kind)

def gaussian_levels(K,A):
 _,v=np.linalg.eigh(K);nu=np.linalg.eigvalsh((v[:,:2]@v[:,:2].T)[np.ix_(A,A)])
 one=np.array([np.prod([nu[i] if bits>>i&1 else 1-nu[i] for i in range(4)]) for bits in range(16)])
 return np.sort(np.outer(one,one).ravel())

def symmetry_errors(K):
 ix=lambda x,y,a:2*(x+2*y)+a;maps=[]
 for axis in ['x','y','transpose']:
  v=np.zeros((8,8))
  for x in range(2):
   for y in range(2):
    for a in range(2):
     xx,yy,aa=(1-x,y,a) if axis=='x' else ((x,1-y,a) if axis=='y' else (y,x,1-a));v[ix(xx,yy,aa),ix(x,y,a)]=1 if axis=='transpose' or a==0 else -1
  maps.append(v)
 return {name:float(np.max(abs(v@K@v.T-K))) for name,v in zip(['Rx_orbital_gauge','Ry_orbital_gauge','transpose_orbital_exchange'],maps)}

def case(spec,t,r,cfg):
 g=Gates();lim=cfg['gates'];ident=spec['id']
 if t.get('status')!='TARGET_READY' or r.get('status')!='ORACLE_READY':return dict(id=ident,status='UNRESOLVED',reason='Producer state/receipt unqualified; no dense or ensemble substitution',target_status=t.get('status'),reference_status=r.get('status'),target_reason=t.get('reason'),reference_reason=r.get('reason'),gates=[])
 if t['id']!=ident or r['id']!=ident or t['U']!=spec['U'] or r['U']!=spec['U'] or t['t4']!=spec['t4'] or r['t4']!=spec['t4']:raise ValueError('Fixture identity changed')
 Kt=array(t['h1'],(8,8));Kr=array(r['h1'],(8,8));g.error('independent complete one-body matrix',Kt,Kr,lim['hamiltonian_abs'])
 for b,obj in [('target',t),('reference',r)]:
  if set(obj['symmetry_errors'])!={'Rx_orbital_gauge','Ry_orbital_gauge','transpose_orbital_exchange'}:raise ValueError('Missing density-control symmetry')
  computed=symmetry_errors(array(obj['h1'],(8,8)))
  for name,value in obj['symmetry_errors'].items():
   g.check(b+'/'+name,float(computed[name]),'le',lim['symmetry_commutator_abs']);g.check(b+'/'+name+'_saved_error',abs(float(value)-computed[name]),'le',lim['symmetry_commutator_abs'])
 expected=[tuple(s) for s in cfg['spin_sectors']]
 if [tuple((s['Nup'],s['Ndown'])) for s in t['sectors']]!=expected or [tuple((s['Nup'],s['Ndown'])) for s in r['sectors']]!=expected:raise ValueError('Incomplete global fixedN sector grid')
 for st,sr,d in zip(t['sectors'],r['sectors'],cfg['sector_dimensions']):
  tag=f"Nup{st['Nup']}_Ndown{st['Ndown']}";g.check(tag+'/target_dimension',st['dimension'],'eq',d);g.check(tag+'/reference_dimension',sr['dimension'],'eq',d)
  lt=labels(st,True);lr=labels(sr,False);lookup={p:i for i,p in enumerate(lr)}
  if set(lt)!=set(lr):raise ValueError('Fixed-sector Fock states differ')
  perm=[lookup[p] for p in lt];Ht=matrix(st['H'],d);Hr=matrix(sr['H'],d)[np.ix_(perm,perm)];scale=max(1.,np.linalg.norm(Ht,np.inf))
  g.error(tag+'/complete_H',Ht,Hr,lim['hamiltonian_abs']);g.error(tag+'/H_hermiticity',Ht,Ht.T,lim['matrix_hermiticity_abs'],'qualification')
  et=array(st['energies'],(d,));er=array(sr['energies'],(d,));g.check(tag+'/target_energy_order',bool(np.all(np.diff(et)>=0)),'eq',True);g.check(tag+'/reference_energy_order',bool(np.all(np.diff(er)>=0)),'eq',True);g.error(tag+'/all_eigenenergies',et,er,lim['energy_abs'])
  gt=int(np.count_nonzero(et-et[0]<=lim['ground_cluster_diameter']));gr=int(np.count_nonzero(er-er[0]<=lim['ground_cluster_diameter']));g.check(tag+'/ground_rank',gt,'eq',gr,'comparison')
  vt=array(st['dense_ground_vectors'],(d,gt));vr=array(sr['dense_ground_vectors'],(d,gr))[perm];g.error(tag+'/complete_ground_projector',vt@vt.T,vr@vr.T,lim['rdm_spectrum_l1'])
  psi=array(st['native_vector'],(d,));g.check(tag+'/primary_native_method',st['native_method'],'eq','lanczos');g.check(tag+'/native_convergence',st['native_converged'],'eq',True);g.check(tag+'/native_vector_norm',abs(np.dot(psi,psi)-1),'le',lim['rdm_trace_abs']);g.check(tag+'/native_iteration_budget',st['native_iterations'],'le',d)
  g.check(tag+'/native_state_residual_scaled',float(np.linalg.norm(Ht@psi-st['native_energy']*psi)/scale),'le',lim['residual_scaled']);g.check(tag+'/native_external_ground_fidelity',float(np.sum(abs(vr.T@psi)**2)),'ge',lim['native_ground_fidelity_min']);g.check(tag+'/native_external_energy',abs(st['native_energy']-er[0]),'le',lim['energy_abs'])
  g.check(tag+'/all_native_matrixfree_columns',st['native_matrixfree_action_abs'],'le',lim['hamiltonian_abs'])
  for backend,row in [('target',st),('reference',sr)]:
   g.check(tag+'/'+backend+'_dense_eigen_residual_scaled',row['dense_eigen_residual_scaled'],'le',lim['residual_scaled']);g.check(tag+'/'+backend+'_dense_orthogonality',row['dense_orthogonality_abs'],'le',lim['orthogonality_abs'])
 for backend,obj in [('target',t),('reference',r)]:
  energies=np.sort(np.concatenate([array(s['energies']) for s in obj['sectors']]));gap=float(energies[1]-energies[0]);balanced=obj['sectors'][2]
  budgets=[]
  for block in obj['sectors']:
   d=block['dimension'];scale=float(block['operator_scale']);res=float(block['dense_eigen_residual_scaled'])*scale;orth=float(block['dense_orthogonality_abs']);
   if not all(math.isfinite(v) and v>=0 for v in [scale,res,orth]):raise ValueError('Invalid numerical gap budget')
   budgets.append(2*np.sqrt(d)*res+2*d*orth*scale+lim['gap_roundoff_multiplier']*np.finfo(float).eps*d*scale)
  lower_excited=min(float(e)-budgets[j] for j,block in enumerate(obj['sectors']) for k,e in enumerate(block['energies']) if not (j==2 and k==0));gap_lower=lower_excited-(balanced['energies'][0]+budgets[2]);g.check(backend+'/conditional_global_gap_lower',gap_lower,'gt',lim['global_gap_min'])
  g.check(backend+'/global_gap',gap,'gt',lim['global_gap_min']);g.check(backend+'/balanced_is_global_ground',abs(balanced['energies'][0]-energies[0]),'le',lim['energy_abs']);g.check(backend+'/balanced_ground_rank',balanced['ground_multiplicity'],'eq',1);g.check(backend+'/saved_global_gap',abs(obj['global_gap']-gap),'le',lim['energy_abs'])
  obs=obj['observables'];g.check(backend+'/singlet_S_squared',abs(obs['spin_squared']),'le',lim['spin_squared_abs'])
  for name in ['density_up','density_down']:g.error(backend+'/'+name+'_uniform',array(obs[name],(8,)),np.full(8,.25),lim['density_abs'],'qualification')
  g.error(backend+'/density_total_uniform',array(obs['density_total'],(8,)),np.full(8,.5),lim['density_abs'],'qualification')
  g.error(backend+'/physical_spin_rotation_witness',array(obs['cross_Sdot_connected'],(4,4)),3*array(obs['cross_SzSz_connected'],(4,4)),lim['connected_observable_abs'],'qualification')
  partition=obj['partition']
  for part in ['A','B']:
   rho=array(partition['rdm_'+part],(256,256));levels=array(partition['levels_'+part],(256,));own=np.linalg.eigvalsh(rho)
   g.check(backend+'/'+part+'_trace',abs(np.trace(rho)-1),'le',lim['rdm_trace_abs']);g.error(backend+'/'+part+'_hermiticity',rho,rho.T,lim['rdm_hermiticity_abs'],'qualification');g.check(backend+'/'+part+'_PSD_min',float(np.min(own)),'ge',lim['rdm_psd_lower']);g.error(backend+'/'+part+'_complete_saved_spectrum',levels,own,lim['purity_abs'],'qualification');g.check(backend+'/'+part+'_purity',abs(float(np.sum(rho*rho))-partition['purity_'+part]),'le',lim['purity_abs'])
   s2=float(-np.log(np.sum(rho*rho)));nativekey=('native_S2_' if backend=='target' else 'S2_')+part;g.check(backend+'/'+part+'_actual_entropy_function' if backend=='target' else backend+'/'+part+'_entropy',abs(partition[nativekey]-s2),'le',lim['entropy_abs'])
   if spec['t4']==0:g.check(backend+'/'+part+'_decoupled_product_purity',abs(partition['purity_'+part]-1),'le',lim['product_abs'])
   else:g.check(backend+'/'+part+'_nonzero_hybrid_entanglement',partition[nativekey],'gt',lim['hybrid_entropy_min'])
  g.check(backend+'/pure_state_A_B_full_spectrum',float(np.sum(abs(array(partition['levels_A'])-array(partition['levels_B'])))),'le',lim['rdm_spectrum_l1'])
  for name in ['cross_nn_connected','cross_Sdot_connected']:
   values=array(obs[name],(4,4));g.check(backend+'/'+name+('_product_zero' if spec['t4']==0 else '_hybrid_nonzero'),float(np.max(abs(values))),'le' if spec['t4']==0 else 'gt',lim['product_abs'] if spec['t4']==0 else lim['hybrid_connected_min'])
 if t['partition']['carrier_only_metadata'] is not True or t['partition']['carrier_physical_H_used'] is not False or t['partition']['fermionic_permutation_checks']!=784:raise ValueError('Native entropy attribution or sign proof incomplete')
 mapping=t['partition']['native_to_carrier_map'];bal=t['sectors'][2];lookup={pair:i for i,pair in enumerate(labels(bal,True))};expected_map=[[i,lookup[pair]] for i,pair in enumerate((u,d) for u in sorted(bal['basis_up_masks']) for d in sorted(bal['basis_down_masks']))];g.check('exact_mask_lookup_embedding',mapping,'eq',expected_map);g.check('bijective_native_to_entropy_basis',len(mapping)==784 and sorted(a for a,b in mapping)==list(range(784)) and sorted(b for a,b in mapping)==list(range(784)),'eq',True)
 for part in ['A','B']:g.check(part+'/all256_orbital_levels_L1',float(np.sum(abs(array(t['partition']['levels_'+part])-array(r['partition']['levels_'+part])))),'le',lim['rdm_spectrum_l1'],'comparison')
 for name in ['density_up','density_down','density_total','cross_nn_connected','cross_Sdot_connected']:g.error('independent/'+name,t['observables'][name],r['observables'][name],lim['connected_observable_abs'])
 for part in ['A','B']:g.check('independent/native_S2_'+part,abs(t['partition']['native_S2_'+part]-r['partition']['S2_'+part]),'le',lim['entropy_abs'],'comparison')
 g.check('reference/spin_algebra',r['observables']['spin_commutator_abs'],'le',lim['connected_observable_abs']);g.check('reference/closed_N4_union_dimension',r['observables']['union_basis_dimension'],'eq',1820)
 if spec['U']==0:
  levels=gaussian_levels(Kr,cfg['orbital_A_zero_based']);g.check('independent_Gaussian/QuSpin_full_orbital_spectrum_L1',float(np.sum(abs(levels-array(r['partition']['levels_A'])))),'le',lim['gaussian_spectrum_l1'],'comparison');g.check('independent_Gaussian/native_full_orbital_spectrum_L1',float(np.sum(abs(levels-array(t['partition']['levels_A'])))),'le',lim['gaussian_spectrum_l1'],'comparison');g.error('saved_Gaussian_spectrum',r['partition']['gaussian_levels_A'],levels,lim['gaussian_spectrum_l1'],'qualification')
 quality=[x for x in g.rows if x['kind']=='qualification' and not x['passed']];wrong=[x for x in g.rows if x['kind']=='comparison' and not x['passed']]
 return dict(id=ident,status='UNRESOLVED' if quality else ('FAIL' if wrong else 'PASS'),gates=g.rows,quality_failures=len(quality),comparison_failures=len(wrong),primary_state='Actual native Lanczos, never dense replacement',rdm_comparison='Full256 sorted levels, not gauge-fitted entries')

def main():
 p=argparse.ArgumentParser();p.add_argument('--target',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 if a.output.exists():raise ValueError('No overwrite')
 cfg=load(HERE/'manifest.toml');t=load(a.target);r=load(a.reference);out=dict(schema='X17_COMPARISON_V1',catalogue_id='X17',scientific_completions=0)
 try:
  if t['schema']!='X17_NATIVE_RAW_V1' or r['schema']!='X17_QUSPIN_RAW_V1' or t['backend']!='actual_native_lanczos_and_native_renyi_new_RDM_adapter' or r['backend']!='independent_quspin' or t['mode'] not in ('pilot','production') or t['mode']!=r['mode'] or t['threads']!=1 or r['threads']!=1 or str(t['job_id'])!=str(r['job_id']) or not str(t['job_id']).isdigit() or t['scientific_completions']!=0 or r['scientific_completions']!=0:raise ValueError('Wrong producer identity')
  pins={n:h for h,n in (line.split('  ',1) for line in (HERE/'SHA256SUMS').read_text().splitlines())}
  if t['source_sha256']!=pins or r['source_sha256']!=pins or t['source_freeze_sha256']!=sha(HERE/'source_freeze.json') or r['source_freeze_sha256']!=sha(HERE/'source_freeze.json'):raise ValueError('Source freeze identity')
  for name,h in pins.items():
   if sha(HERE/name)!=h:raise ValueError('Changed authored source')
  if t['native_source_sha256']!=cfg['native_source_hashes'] or t['versions']!={'julia':cfg['julia_version']} or r['python']!=cfg['python_version'] or r['versions']!={'quspin':cfg['quspin_version'],'quspin-extensions':cfg['quspin_extensions_version'],'numpy':cfg['numpy_version'],'scipy':cfg['scipy_version']}:raise ValueError('Unpinned native/package/runtime')
  library=load(HERE/'reference_library_pins.json')
  if library['schema']!='X17_QUSPIN_REFERENCE_LIBRARY_PINS_V1' or library['python_version']!=cfg['python_version'] or {n:d['version'] for n,d in library['distributions'].items()}!={'quspin':cfg['quspin_version'],'quspin-extensions':cfg['quspin_extensions_version']}:raise ValueError('Wrong expected reference library identity')
  if r['reference_library_pins_sha256']!=sha(HERE/'reference_library_pins.json') or r['reference_library_sha256']!=library['files'] or r['installed_wheel_record_sha256']!={n:h for n,h in library['files'].items() if n.endswith('/RECORD')}:raise ValueError('Installed independent reference source/extension/RECORD differs')
  specs=[s for s in cfg['cases'] if t['mode']=='production' or s['id'] in cfg['pilot_case_ids']]
  if [x['id'] for x in t['cases']]!=[s['id'] for s in specs] or [x['id'] for x in r['cases']]!=[s['id'] for s in specs]:raise ValueError('Incomplete predeclared fixture grid')
  result=[case(s,tt,rr,cfg) for s,tt,rr in zip(specs,t['cases'],r['cases'])];status='UNRESOLVED' if any(x['status']=='UNRESOLVED' for x in result) else ('FAIL' if any(x['status']=='FAIL' for x in result) else 'PASS')
  out.update(status=status,mode=t['mode'],cases=result,catalogue_status=status if t['mode']=='production' else 'NOT_RUN',scientific_completions=int(t['mode']=='production' and status=='PASS'),pilot_excluded=t['mode']=='pilot',source_freeze_sha256=sha(HERE/'source_freeze.json'),raw_sha256={'target':sha(a.target),'reference':sha(a.reference)},source_sha256=pins,comparison_scope='One X17 idea; six fixed finite-model fixtures, unchanged native Lanczos and S2 plus disclosed complete RDM/spin/certificate observers; no thermodynamic or two-orbital DQMC claim.')
 except Exception as ex:out.update(status='UNRESOLVED',catalogue_status='NOT_RUN' if t.get('mode')=='pilot' else 'UNRESOLVED',reason=type(ex).__name__+': '+str(ex),cases=[])
 with a.output.open('x') as f:json.dump(plain(out),f,indent=2,allow_nan=False);f.write('\n')
 print(json.dumps({k:out[k] for k in ['status','catalogue_status','scientific_completions']}));sys.exit({'PASS':0,'FAIL':1,'UNRESOLVED':2}[out['status']])
if __name__=='__main__':main()
