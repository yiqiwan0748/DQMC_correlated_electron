#!/usr/bin/env python3
"""Copy an explicitly reviewed source preparation into a NEW frozen release.

Do not call until parent and independent reviewer approve the complete source.
Creates no Slurm jobs and runs no scientific code.
"""
import argparse,hashlib,io,json,tarfile,gzip,datetime
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROLES=['manifest.toml','PROTOCOL.md','README.md','catalogue_X17.json','native_source_pins.json','reference_library_pins.json','target.jl','oracle_quspin.py','compare.py','run_campaign.py','admit_production.py','audit_pilot.py','freeze_release.py','pilot.sbatch','production.sbatch','source_snapshot/scripts/two_orbital_open_cluster_ed.jl','source_snapshot/src/noninteracting.jl','source_snapshot/src/realspace_kinetic.jl','source_snapshot/analysis/compute_s2_ed.jl']
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--review-approved',action='store_true');p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args()
 if not a.review_approved:raise ValueError('Explicit completed parent+independent source review is required before freezing')
 a.output_dir.mkdir(parents=True,exist_ok=False);pins=json.loads((HERE/'native_source_pins.json').read_text());files={n:(HERE/n).read_bytes() for n in ROLES}
 if any((HERE/n).is_symlink() for n in ROLES):raise ValueError('Source symlinks are not allowed')
 for n,h in pins.items():
  if sha(files['source_snapshot/'+n])!=h:raise ValueError('Original native bytes changed')
 sums=''.join(sha(b)+'  '+n+'\n' for n,b in sorted(files.items())).encode();files['SHA256SUMS']=sums
 arc=a.output_dir/'orbital-entanglement-v1-source.tar.gz'
 with arc.open('xb') as f,gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as g,tarfile.open(fileobj=g,mode='w|') as tar:
  for n,b in sorted(files.items()):
   b.decode('utf-8');info=tarfile.TarInfo('orbital_entanglement_v1/'+n);info.size=len(b);info.mode=0o644;info.uid=info.gid=0;info.mtime=0;tar.addfile(info,io.BytesIO(b))
 freeze=dict(schema='X17_SOURCE_FREEZE_V1',release='orbital_entanglement_v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),catalogue_ids=['X17'],status='FROZEN_NOT_EXECUTED',archive=arc.name,archive_sha256=sha(arc.read_bytes()),archive_bytes=arc.stat().st_size,files={n:sha(b) for n,b in sorted(files.items())},native_source_sha256=pins,reference_library_pins_sha256=sha(files['reference_library_pins.json']),all_modes='100644',runtime_binaries_included=False,scientific_jobs_submitted=False)
 (a.output_dir/'source_freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
 folder=a.output_dir/'orbital_entanglement_v1';folder.mkdir()
 for n,b in files.items():q=folder/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);q.chmod(0o644)
 (folder/'source_freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');(folder/'source_freeze.json').chmod(0o644);(a.output_dir/'source_freeze.json').chmod(0o644);arc.chmod(0o644);print(json.dumps({'source_dir':str(folder),'freeze_sha256':sha((folder/'source_freeze.json').read_bytes()),'archive_sha256':freeze['archive_sha256']},indent=2))
if __name__=='__main__':main()
