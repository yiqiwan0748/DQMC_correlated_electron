#!/usr/bin/env python3
"""Independent QuSpin fixed-N Hamiltonians/partial traces; no native imports."""
import argparse,contextlib,hashlib,importlib.metadata,io,itertools,json,os,platform,sys,time,tomllib
from pathlib import Path
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
import numpy as np
from scipy.linalg import eigh,eigvalsh
from quspin.basis import spinful_fermion_basis_1d
from quspin.operators import hamiltonian
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def plain(x):
 if isinstance(x,dict):return {str(k):plain(v) for k,v in x.items()}
 if isinstance(x,(list,tuple,np.ndarray)):return [plain(v) for v in x]
 if isinstance(x,np.generic):return x.item()
 return x

def source_map():
 if not (HERE/'source_freeze.json').is_file():raise ValueError('Not frozen/approved for execution')
 pins={}
 for line in (HERE/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1)
  if sha(HERE/name)!=digest:raise ValueError('Changed frozen source '+name)
  pins[name]=digest
 return pins

def reference_library_map():
 # A version label alone cannot identify the actual partial-trace implementation.
 path=HERE/'reference_library_pins.json';expected=json.loads(path.read_text())
 if expected['schema']!='X17_QUSPIN_REFERENCE_LIBRARY_PINS_V1' or expected['python_version']!=platform.python_version():raise ValueError('Reference pin schema/runtime differs')
 observed={}
 for name,spec in expected['distributions'].items():
  dist=importlib.metadata.distribution(name)
  names=sorted(str(p) for p in dist.files if str(p).endswith('.py') or '.so' in p.name or p.name=='RECORD')
  if dist.version!=spec['version'] or names!=spec['files']:raise ValueError('Reference installed file closure differs: '+name)
  for relative in names:
   installed=dist.locate_file(relative)
   if installed.stat().st_size!=expected['bytes'][relative]:raise ValueError('Reference library size differs: '+relative)
   observed[relative]=sha(installed)
 if observed!=expected['files']:raise ValueError('Reference library SHA differs before scientific computation')
 return observed

def op(b,terms,hermitian=False):
 with contextlib.redirect_stdout(io.StringIO()):return hamiltonian(terms,[],basis=b,dtype=np.float64,check_herm=hermitian,check_symm=False,check_pcon=False).tocsr()

def masks(b,M=8):
 out=[]
 for state in b.states:
  s=int(state);up=sum(((s>>(2*M-1-i))&1)<<i for i in range(M));dn=sum(((s>>(M-1-i))&1)<<i for i in range(M));out.append((up,dn))
 if len(set(out))!=b.Ns:raise ValueError('Nonbijective physical mask labels')
 return out

def coo(A):
 a=np.asarray(A);ii,jj=np.nonzero(a);return dict(shape=list(a.shape),row=ii.tolist(),col=jj.tolist(),value=a[ii,jj].tolist())

def independent_h1(cfg,t4):
 # Geometric definition; does not read any native matrix/source output.
 M=8;K=np.zeros((M,M));index=lambda x,y,a:2*(x+2*y)+a
 def bond(x,y,xx,yy,block):
  for a in range(2):
   for bb in range(2):
    i=index(x,y,a);j=index(xx,yy,bb);K[i,j]+=block[a][bb];K[j,i]+=block[a][bb]
 for y in range(2):
  for x in range(2):
   if x+1<2:bond(x,y,x+1,y,[[-cfg['t1'],0],[0,-cfg['t2']]])
   if y+1<2:bond(x,y,x,y+1,[[-cfg['t2'],0],[0,-cfg['t1']]])
   if x+1<2 and y+1<2:bond(x,y,x+1,y+1,[[-cfg['t3'],t4],[t4,-cfg['t3']]])
   if x+1<2 and y-1>=0:bond(x,y,x+1,y-1,[[-cfg['t3'],-t4],[-t4,-cfg['t3']]])
 return K

def symmetry_errors(K):
 ix=lambda x,y,a:2*(x+2*y)+a;ux=np.zeros((8,8));uy=ux.copy();s=ux.copy()
 for x,y,a in itertools.product(range(2),range(2),range(2)):
  eta=1 if a==0 else -1;i=ix(x,y,a);ux[ix(1-x,y,a),i]=eta;uy[ix(x,1-y,a),i]=eta;s[ix(y,x,1-a),i]=1
 return {n:float(np.max(abs(v@K@v.T-K))) for n,v in [('Rx_orbital_gauge',ux),('Ry_orbital_gauge',uy),('transpose_orbital_exchange',s)]}

def sector(K,U,nu,nd,cfg):
 b=spinful_fermion_basis_1d(8,Nf=(int(nu),int(nd)));hop=[[float(K[i,j]),i,j] for i,j in zip(*np.nonzero(K))]
 H=op(b,[['+-|',hop],['|+-',hop],['z|z',[[float(U),i,i] for i in range(8)]]],hermitian=True).toarray();es,vs=eigh(H);scale=max(1.,np.linalg.norm(H,np.inf));ng=int(np.count_nonzero(es-es[0]<=cfg['gates']['ground_cluster_diameter']));ls=masks(b)
 return dict(Nup=nu,Ndown=nd,dimension=b.Ns,basis_up_per_row=[u for u,d in ls],basis_down_per_row=[d for u,d in ls],H=coo(H),energies=es,ground_multiplicity=ng,dense_ground_vectors=vs[:,:ng],dense_eigen_residual_scaled=float(np.max(np.linalg.norm(H@vs-vs*es,axis=0))/scale),dense_orthogonality_abs=float(np.max(abs(vs.T@vs-np.eye(b.Ns)))),operator_scale=float(scale)),b,vs[:,0]

def physical_observables(psi,b,cfg):
 # The all-N4 union is used for sparse physical spin raising/lowering only.
 allb=spinful_fermion_basis_1d(8,Nf=[(nu,4-nu) for nu in range(5)]);alllabels=masks(allb);where={p:i for i,p in enumerate(alllabels)};v=np.zeros(allb.Ns)
 for coeff,pair in zip(psi,masks(b)):v[where[pair]]=coeff
 up=np.asarray([[(u>>i)&1 for u,d in alllabels] for i in range(8)],float);dn=np.asarray([[(d>>i)&1 for u,d in alllabels] for i in range(8)],float)
 # Verify the decoded QuSpin labels against actual independent package n operators.
 for i in range(8):
  for label,arr in [('n|',up),('|n',dn)]:
   if not np.array_equal(op(allb,[[label,[[1.,i]]]]).diagonal(),arr[i]):raise ValueError('QuSpin occupancy map differs')
 n=up+dn;z=(up-dn)/2;p=v*v;mean=n@p;zm=z@p
 plus=[op(allb,[['+|-',[[1.,i,i]]]]) for i in range(8)];pv=[s@v for s in plus];mv=[s.T@v for s in plus]
 nn=np.zeros((4,4));sd=np.zeros((4,4));zz=np.zeros((4,4));A=cfg['orbital_A_zero_based'];B=cfg['orbital_B_zero_based']
 for i,a in enumerate(A):
  for j,bb in enumerate(B):
   nn[i,j]=np.dot(p,n[a]*n[bb])-mean[a]*mean[bb]
   zz[i,j]=np.dot(p,z[a]*z[bb])-zm[a]*zm[bb]
   sd[i,j]=np.dot(p,z[a]*z[bb])+.5*(np.dot(mv[a],mv[bb])+np.dot(pv[a],pv[bb]))-zm[a]*zm[bb]
 # [S+,S-]=2Sz checked as a sparse action identity on the whole closed N4 union.
 Sp=sum(plus);Sm=Sp.T;comm=Sp@Sm-Sm@Sp
 car_error=float(np.max(abs((comm-op(allb,[['z|',[[1.,i] for i in range(8)]],['|z',[[-1.,i] for i in range(8)]]])).data),initial=0.))
 return dict(density_up=up@p,density_down=dn@p,density_total=mean,Sz_mean=zm,cross_nn_connected=nn,cross_Sdot_connected=sd,cross_SzSz_connected=zz,spin_squared=float(np.vdot(Sp@v,Sp@v).real),spin_commutator_abs=car_error,union_basis_dimension=allb.Ns)

def rdm(psi,b,sites):
 with contextlib.redirect_stdout(io.StringIO()):raw=b.partial_trace(psi,sub_sys_A=(tuple(sites),tuple(sites)),return_rdm='A',enforce_pure=True,subsys_ordering=True)
 a=np.asarray(raw);original=list(a.shape)
 if a.ndim==3 and a.shape[0]==1:a=a[0]
 if a.shape!=(256,256):raise ValueError('Unexpected native QuSpin RDM shape '+str(original))
 if np.max(abs(np.imag(a)))>1e-12:raise ValueError('Real model RDM unexpectedly complex')
 a=np.real(a);return a,original

def gaussian_levels(K,A):
 es,v=eigh(K);C=v[:,:2]@v[:,:2].T;c=C[np.ix_(A,A)];nu=eigvalsh(c)
 if np.min(nu)<-1e-12 or np.max(nu)>1+1e-12:raise ValueError('Gaussian correlation eigenvalues invalid')
 # Endpoint roundoff is retained; no eigenvalue clipping before comparison.
 one=np.array([np.prod([nu[i] if bits>>i&1 else 1-nu[i] for i in range(4)]) for bits in range(16)])
 return np.sort(np.outer(one,one).ravel())

def one_case(spec,cfg):
 start=time.time();out=dict(id=spec['id'],U=spec['U'],t4=spec['t4'],status='ORACLE_UNRESOLVED',sectors=[])
 try:
  K=independent_h1(cfg,spec['t4']);out.update(h1=K,symmetry_errors=symmetry_errors(K));balanced=None
  for nu,nd in cfg['spin_sectors']:
   row,b,v=sector(K,spec['U'],nu,nd,cfg);out['sectors'].append(row)
   if (nu,nd)==(2,2):balanced=(row,b,v)
  es=np.sort(np.concatenate([r['energies'] for r in out['sectors']]));out.update(global_ground_energy=float(es[0]),global_gap=float(es[1]-es[0]));r,b,v=balanced
  if out['global_gap']<=cfg['gates']['global_gap_min'] or abs(r['energies'][0]-es[0])>cfg['gates']['energy_abs'] or r['ground_multiplicity']!=1:raise ValueError('No unique balanced global N4 ground; no ensemble substitution')
  ra,sa=rdm(v,b,cfg['orbital_A_zero_based']);rb,sb=rdm(v,b,cfg['orbital_B_zero_based']);la=eigvalsh(ra);lb=eigvalsh(rb)
  partition=dict(rdm_A=ra,rdm_B=rb,levels_A=la,levels_B=lb,purity_A=float(np.sum(ra*ra)),purity_B=float(np.sum(rb*rb)),S2_A=float(-np.log(np.sum(ra*ra))),S2_B=float(-np.log(np.sum(rb*rb))),raw_rdm_shape_A=sa,raw_rdm_shape_B=sb)
  if spec['U']==0:partition['gaussian_levels_A']=gaussian_levels(K,cfg['orbital_A_zero_based'])
  out.update(observables=physical_observables(v,b,cfg),partition=partition,status='ORACLE_READY')
 except Exception as ex:out['reason']=type(ex).__name__+': '+str(ex)
 out['elapsed_seconds']=time.time()-start;return out

def main():
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['pilot','production']);p.add_argument('output',type=Path);a=p.parse_args()
 if a.output.exists():raise ValueError('No overwrite')
 if not os.getenv('SLURM_JOB_ID'):raise ValueError('Scientific execution requires a Slurm compute job')
 cfg=tomllib.loads((HERE/'manifest.toml').read_text());pins=source_map();versions={n:importlib.metadata.version(n) for n in ['quspin','quspin-extensions','numpy','scipy']}
 wanted={'quspin':cfg['quspin_version'],'quspin-extensions':cfg['quspin_extensions_version'],'numpy':cfg['numpy_version'],'scipy':cfg['scipy_version']}
 if versions!=wanted or platform.python_version()!=cfg['python_version']:raise ValueError('Pinned primary runtime required')
 library=reference_library_map()
 specs=[s for s in cfg['cases'] if a.mode=='production' or s['id'] in cfg['pilot_case_ids']];start=time.time()
 data=dict(schema='X17_QUSPIN_RAW_V1',backend='independent_quspin',mode=a.mode,job_id=os.getenv('SLURM_JOB_ID','LOCAL'),scientific_completions=0,versions=versions,python=platform.python_version(),threads=1,source_sha256=pins,source_freeze_sha256=sha(HERE/'source_freeze.json'),reference_library_pins_sha256=sha(HERE/'reference_library_pins.json'),reference_library_sha256=library,installed_wheel_record_sha256={n:h for n,h in library.items() if n.endswith('/RECORD')},cases=[one_case(s,cfg) for s in specs],started_unix=start,finished_unix=time.time())
 with a.output.open('x') as f:json.dump(plain(data),f,indent=2,allow_nan=False);f.write('\n')
if __name__=='__main__':main()
