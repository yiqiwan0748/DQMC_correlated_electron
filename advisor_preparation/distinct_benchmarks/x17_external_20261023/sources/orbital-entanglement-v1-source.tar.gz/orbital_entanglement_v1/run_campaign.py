#!/usr/bin/env python3
"""Compute-node-only serial wrapper; never submits another job."""
import argparse,hashlib,json,os,signal,subprocess,sys,time,tomllib
from pathlib import Path
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['pilot','production'],required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--julia',type=Path,required=True);p.add_argument('--python',type=Path,required=True);a=p.parse_args()
 if not os.getenv('SLURM_JOB_ID') or int(os.getenv('SLURM_CPUS_PER_TASK','0'))!=1 or int(os.getenv('SLURM_MEM_PER_NODE','0'))!=3500:raise ValueError('One-CPU Slurm compute job required')
 cfg=tomllib.loads((HERE/'manifest.toml').read_text());freeze=HERE/'source_freeze.json'
 if not freeze.is_file():raise ValueError('Source preparation has not been reviewed/frozen')
 sums={name:h for h,name in (s.split('  ',1) for s in (HERE/'SHA256SUMS').read_text().splitlines())}
 for name,h in sums.items():
  if sha(HERE/name)!=h:raise ValueError('Changed source before compute '+name)
 a.output.mkdir(parents=True,exist_ok=False);resources=cfg['resources'];started=time.time();cap=resources['pilot_wall_minutes' if a.mode=='pilot' else 'production_wall_minutes']*60;stop=started+cap-resources['termination_guard_seconds'];env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',JULIA_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C');processes=[]
 commands=[('target',[str(a.julia),'--startup-file=no',str(HERE/'target.jl'),a.mode,str(a.output/'target.toml')],resources[a.mode+'_target_timeout_seconds']),('reference',[str(a.python),'-B',str(HERE/'oracle_quspin.py'),a.mode,str(a.output/'reference.json')],resources[a.mode+'_oracle_timeout_seconds']),('comparator',[str(a.python),'-B',str(HERE/'compare.py'),'--target',str(a.output/'target.toml'),'--reference',str(a.output/'reference.json'),'--output',str(a.output/'comparison.json')],resources['comparator_timeout_seconds'])]
 for name,argv,budget in commands:
  remaining=stop-time.time()
  if remaining<=1:raise TimeoutError('Insufficient predeclared job budget')
  timeout=min(budget,remaining);begin=time.time()
  with (a.output/(name+'.stdout.txt')).open('xb') as out,(a.output/(name+'.stderr.txt')).open('xb') as err:
   cmd=['/usr/bin/time','-v','-o',str(a.output/(name+'.resources.txt'))]+argv;proc=subprocess.Popen(cmd,stdout=out,stderr=err,env=env,start_new_session=True)
   try:code=proc.wait(timeout=timeout);timedout=False
   except subprocess.TimeoutExpired:
    timedout=True;os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    code=124
  processes.append(dict(name=name,argv=argv,start_unix=begin,end_unix=time.time(),elapsed_seconds=time.time()-begin,exit_code=code,timeout_seconds=timeout,timed_out=timedout))
  receipt=dict(schema='X17_EXECUTION_RECEIPT_V1',job_id=os.environ['SLURM_JOB_ID'],mode=a.mode,status='RUNNING',source_freeze_sha256=sha(freeze),source_sha256=sums,processes=processes,cpus=1,memory_mb=3500,scientific_completions=0,started_unix=started,finished_unix=time.time())
  (a.output/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
  if code and name!='comparator':raise RuntimeError(name+' failed; original outputs retained and no fallback solver invoked')
 receipt['status']='PROCESSES_COMPLETE';(a.output/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n');sys.exit(processes[-1]['exit_code'])
if __name__=='__main__':main()
