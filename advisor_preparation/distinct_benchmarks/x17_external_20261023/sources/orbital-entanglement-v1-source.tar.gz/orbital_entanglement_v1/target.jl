#!/usr/bin/env julia
using LinearAlgebra, TOML, SHA
BLAS.set_num_threads(1)
haskey(ENV,"SLURM_JOB_ID")||error("Scientific execution requires a Slurm compute job")
const ROOT=@__DIR__
const CFG=TOML.parsefile(joinpath(ROOT,"manifest.toml"))
VERSION==VersionNumber(CFG["julia_version"])||error("Pinned Julia required")
isfile(joinpath(ROOT,"source_freeze.json"))||error("Source is not frozen/approved for execution")
function source_map()
    out=Dict{String,String}()
    for line in eachline(joinpath(ROOT,"SHA256SUMS"))
        h,n=split(line,"  ";limit=2);bytes2hex(sha256(read(joinpath(ROOT,n))))==h||error("Changed source: $n");out[n]=h
    end
    out
end
const PINS=source_map()
for (n,h) in CFG["native_source_hashes"]
    bytes2hex(sha256(read(joinpath(ROOT,"source_snapshot",n))))==h||error("Changed original native source")
end
include(joinpath(ROOT,"source_snapshot/scripts/two_orbital_open_cluster_ed.jl"))
const ED=TwoOrbitalOpenClusterED
module NativeRenyi
include(joinpath(Main.ROOT,"source_snapshot/analysis/compute_s2_ed.jl"))
end
rows(A)=[collect(A[i,:]) for i in axes(A,1)]
labels(b)=[(u,d) for u in b.up_states for d in b.down_states]
function coo(A)
    ij=findall(!iszero,A);Dict("shape"=>collect(size(A)),"row"=>[i[1]-1 for i in ij],"col"=>[i[2]-1 for i in ij],"value"=>[A[i] for i in ij])
end
function symmetry_errors(K)
    index(x,y,a)=2*((x-1)+2*(y-1))+a
    Ux=zeros(8,8);Uy=zeros(8,8);S=zeros(8,8)
    for y in 1:2,x in 1:2,a in 1:2
        i=index(x,y,a);eta=a==1 ? 1. : -1.
        Ux[index(3-x,y,a),i]=eta;Uy[index(x,3-y,a),i]=eta;S[index(y,x,3-a),i]=1.
    end
    Dict("Rx_orbital_gauge"=>maximum(abs,Ux*K*Ux'-K),"Ry_orbital_gauge"=>maximum(abs,Uy*K*Uy'-K),"transpose_orbital_exchange"=>maximum(abs,S*K*S'-K))
end
function sector(K,U,nu,nd)
    h=ED.sector_hamiltonian(K,U,nu,nd;h=CFG["h"]);H=ED.dense_sector_hamiltonian(h);scale=max(1.,opnorm(H,Inf));d=size(H,1)
    f=eigen(Symmetric(H));ng=count(e->e-f.values[1]<=CFG["gates"]["ground_cluster_diameter"],f.values)
    api=ED.ground_state_observables(h;method=:lanczos,atol=CFG["lanczos"]["atol"],rtol=CFG["lanczos"]["rtol"],maxiter=d,require_convergence=true)
    v=api.eigenvector;hv=h*v;res=norm(hv-api.energy*v);fidelity=sum(abs2,f.vectors[:,1:ng]'*v)
    e=zeros(d);work=similar(e);action_error=0.
    for j in 1:d
        fill!(e,0.);e[j]=1.;mul!(work,h,e);action_error=max(action_error,maximum(abs,work-H[:,j]))
    end
    r=Dict("Nup"=>nu,"Ndown"=>nd,"dimension"=>d,"basis_up_masks"=>Int.(h.basis.up_states),"basis_down_masks"=>Int.(h.basis.down_states),"H"=>coo(H),"energies"=>f.values,"ground_multiplicity"=>ng,"dense_ground_vectors"=>rows(f.vectors[:,1:ng]),"dense_eigen_residual_scaled"=>maximum(norm(H*f.vectors[:,i]-f.values[i]*f.vectors[:,i])/scale for i in 1:d),"dense_orthogonality_abs"=>maximum(abs,f.vectors'*f.vectors-I),"native_matrixfree_action_abs"=>action_error,"operator_scale"=>scale,"native_energy"=>api.energy,"native_vector"=>v,"native_residual_scaled"=>res/scale,"native_reported_residual"=>api.residual,"native_converged"=>api.converged,"native_iterations"=>api.iterations,"native_method"=>string(api.method),"native_dense_ground_fidelity"=>fidelity)
    r,h,v
end
function native_partition(psi,b)
    # The typed carrier represents masks ONLY; no carrier Hamiltonian produces the state.
    M=b.nmodes;carrier=NativeRenyi.build_space(M,0.,0.,0.,b.Nup,b.Ndown;boundary="pbc")
    original=Dict(pair=>i for (i,pair) in enumerate(labels(b)));mapped=zeros(length(psi));maprows=Any[];nd=length(carrier.dn_masks)
    for (iu,u) in enumerate(carrier.up_masks),(id,d) in enumerate(carrier.dn_masks)
        k=(iu-1)*nd+id;j=original[(UInt64(u),UInt64(d))];mapped[k]=psi[j];push!(maprows,[k-1,j-1])
    end
    A=Int.(CFG["orbital_A_zero_based"]);B=Int.(CFG["orbital_B_zero_based"]);X=zeros(256,256);proof=0
    for (iu,u) in enumerate(carrier.up_masks),(id,d) in enumerate(carrier.dn_masks)
        ua=NativeRenyi.compressed_bits(u,A);ub=NativeRenyi.compressed_bits(u,B);da=NativeRenyi.compressed_bits(d,A);db=NativeRenyi.compressed_bits(d,B)
        phase=NativeRenyi.within_species_partition_sign(u,A,B)*NativeRenyi.within_species_partition_sign(d,A,B)*NativeRenyi.subsystem_sign(ua,ub,da)
        order=vcat(A,M.+A,B,M.+B);present=[p for p in order if !iszero((UInt64(u)|(UInt64(d)<<M))&(UInt64(1)<<p))]
        explicit=isodd(sum(present[i]>present[j] for i in eachindex(present) for j in (i+1):length(present))) ? -1. : 1.
        phase==explicit||error("Independent occupied-mode permutation proof failed");proof+=1
        ai=Int(ua|(da<<4))+1;bi=Int(ub|(db<<4))+1;X[ai,bi]+=phase*mapped[(iu-1)*nd+id]
    end
    ra=X*X';rb=X'*X
    Dict("rdm_A"=>rows(ra),"rdm_B"=>rows(rb),"levels_A"=>eigvals(Symmetric(ra)),"levels_B"=>eigvals(Symmetric(rb)),"native_S2_A"=>NativeRenyi.renyi2_entropy_sites(mapped,carrier,A),"native_S2_B"=>NativeRenyi.renyi2_entropy_sites(mapped,carrier,B),"purity_A"=>sum(abs2,ra),"purity_B"=>sum(abs2,rb),"native_to_carrier_map"=>maprows,"fermionic_permutation_checks"=>proof,"carrier_only_metadata"=>true,"carrier_physical_H_used"=>false)
end
function connected(psi,b)
    M=b.nmodes;ls=labels(b);lookup=Dict(p=>i for (i,p) in enumerate(ls));cut=(UInt64(1)<<M)-1;p=abs2.(psi)
    up=[Float64((u>>(a-1))&1) for a in 1:M for (u,d) in ls];up=reshape(up,length(ls),M)'
    dn=[Float64((d>>(a-1))&1) for a in 1:M for (u,d) in ls];dn=reshape(dn,length(ls),M)';n=up+dn;z=(up-dn)/2
    means=n*p;zs=z*p;A=Int.(CFG["orbital_A_zero_based"]).+1;B=Int.(CFG["orbital_B_zero_based"]).+1;nn=zeros(4,4);sd=zeros(4,4);zz=zeros(4,4)
    for (i,a) in enumerate(A),(j,bb) in enumerate(B)
        nn[i,j]=sum(p.*n[a,:].*n[bb,:])-means[a]*means[bb]
        zz[i,j]=sum(p.*z[a,:].*z[bb,:])-zs[a]*zs[bb];sd[i,j]=zz[i,j]
        for (k,(u,d)) in enumerate(ls),plus in (true,false)
            whole=u|(d<<M);first=ED._hop(whole,plus ? bb+M : bb,plus ? bb : bb+M);isnothing(first)&&continue
            w,s=first;second=ED._hop(w,plus ? a : a+M,plus ? a+M : a);isnothing(second)&&continue
            w,t=second;q=lookup[(w&cut,w>>M)];sd[i,j]+=.5*psi[q]*psi[k]*s*t
        end
    end
    outbasis=ED.sector_basis(M,b.Nup+1,b.Ndown-1);outlook=Dict(pair=>i for (i,pair) in enumerate(labels(outbasis)));sp=zeros(length(outbasis))
    for (k,(u,d)) in enumerate(ls),a in 1:M
        hop=ED._hop(u|(d<<M),a,a+M);isnothing(hop)&&continue;w,s=hop;sp[outlook[(w&cut,w>>M)]]+=s*psi[k]
    end
    Dict("density_up"=>collect(up*p),"density_down"=>collect(dn*p),"density_total"=>collect(means),"Sz_mean"=>collect(zs),"cross_nn_connected"=>rows(nn),"cross_Sdot_connected"=>rows(sd),"cross_SzSz_connected"=>rows(zz),"spin_squared"=>sum(abs2,sp),"physical_spin_definition"=>"Sdot=SzSz+(SplusSminus+SminusSplus)/2; connected subtraction includes local means")
end
function one_case(spec)
    started=time();result=Dict{String,Any}("id"=>spec["id"],"U"=>spec["U"],"t4"=>spec["t4"],"status"=>"TARGET_UNRESOLVED","sectors"=>Any[])
    try
        par=ED.ModelParameters(CFG["t1"],CFG["t2"],CFG["t3"],spec["t4"]);K=ED.open_cluster_kinetic_matrix(2,2,par);result["h1"]=rows(K);result["symmetry_errors"]=symmetry_errors(K);balanced=nothing
        for pair in CFG["spin_sectors"]
            r,h,v=sector(K,spec["U"],pair...);push!(result["sectors"],r)
            pair==[2,2]&&(balanced=(h,v,r))
        end
        values=sort(vcat([r["energies"] for r in result["sectors"]]...));gap=values[2]-values[1];result["global_ground_energy"]=values[1];result["global_gap"]=gap
        h,v,r=balanced;eligible=gap>CFG["gates"]["global_gap_min"]&&abs(r["energies"][1]-values[1])<CFG["gates"]["energy_abs"]&&r["ground_multiplicity"]==1&&r["native_dense_ground_fidelity"]>=CFG["gates"]["native_ground_fidelity_min"]&&r["native_residual_scaled"]<=CFG["gates"]["residual_scaled"]
        eligible||error("Primary native state/global fixedN qualification failed; no dense substitution")
        result["observables"]=connected(v,h.basis);result["partition"]=native_partition(v,h.basis);result["status"]="TARGET_READY"
    catch ex
        result["reason"]=sprint(showerror,ex,catch_backtrace())
    end
    result["elapsed_seconds"]=time()-started;result
end
length(ARGS)==2||error("Usage: target.jl pilot|production OUTPUT.toml")
mode,output=ARGS;mode in ("pilot","production")||error("Explicit mode");ispath(output)&&error("No overwrite")
started=time();specs=[s for s in CFG["cases"] if mode=="production"||s["id"] in CFG["pilot_case_ids"]]
data=Dict("schema"=>"X17_NATIVE_RAW_V1","backend"=>"actual_native_lanczos_and_native_renyi_new_RDM_adapter","mode"=>mode,"scientific_completions"=>0,"job_id"=>get(ENV,"SLURM_JOB_ID","LOCAL"),"source_sha256"=>PINS,"source_freeze_sha256"=>bytes2hex(sha256(read(joinpath(ROOT,"source_freeze.json")))),"versions"=>Dict("julia"=>string(VERSION)),"threads"=>1,"native_source_sha256"=>CFG["native_source_hashes"],"cases"=>[one_case(s) for s in specs],"started_unix"=>started,"finished_unix"=>time())
open(output,"w") do io;TOML.print(io,data);end
