# Repository Guidelines

## Scope

- Work milestone by milestone. The current implementation covers only the
  noninteracting two-orbital Bloch Hamiltonian and its band energies.
- Do not add DQMC machinery, Hubbard-Stratonovich fields, a real-space kinetic
  matrix, density-of-states calculations, or plotting until a later milestone
  explicitly requests them.

## Frozen Reference

- `reference/square_hubbard.jl` is a frozen one-orbital reference. Never edit,
  reformat, rename, or delete it.

## Model Conventions

- The orbital basis is ordered as `(d_xz, d_yz)`:
  orbital 1 is `d_xz`, and orbital 2 is `d_yz`.
- Momenta are expressed in radians with lattice spacing set to one.
- Keep the Bloch Hamiltonian real and symmetric for this model.

## Engineering Requirements

- Prefer generic real arithmetic when it does not obscure the implementation;
  the default model parameters and ordinary evaluations use `Float64`.
- Add no package dependency without an explicit milestone requirement.
- Use explicit tolerances for floating-point tests and document why they are
  appropriate.
- Run the milestone test suite with `julia --project=. test/runtests.jl`.

## Research explanations (user preference, September 22, 2026)

- Accompany every new or revised research plot and numerical result with
  a calculation explanation that the user can follow and hand-check.
- State the scientific quantity, Hamiltonian and conventions, parameters,
  lattice and boundaries, particle-number or density setting, temperature,
  initial-state/ensemble prescription, and normalization as applicable.
- Explain the equations and the actual numerical pipeline, including energy
  references, tolerances, thresholds, averaging, broadening, resampling,
  continuation, and axis transformations that affect the displayed result.
- Link each figure/result to its input data, source code, reproduction command,
  and verification evidence. Give a worked numerical checkpoint when useful.
- Separate calculated results from illustrative examples, assumptions, and
  interpretations; describe uncertainty and material limitations explicitly.
- Keep plot pages readable and put the detailed notes in a clearly mapped
  appendix or companion text. For this ED update retain both actual-omega and
  omega-minus-U displays for visual comparison.

## Computation estimates (user preference, September 24, 2026)

- Give a runtime estimate before every scientific computation or batch, and
  update it when measured progress changes the estimate.
- State the scope, expected elapsed-time range, estimated finish window with
  timezone, and a useful check-back time. Separate queue delay from runtime.
- Ground estimates in measured timings when available and identify important
  assumptions, especially unknown convergence counts and parallel slowdown.
  Distinguish an expected finish from a solver budget or scheduler time limit;
  hitting a limit does not establish convergence or scientific completion.

## Research writing (user preference, October 15, 2026)

- Use natural, concise, plain language in reports, notes, slides, and other
  research material. Keep technical detail only where it helps explain or
  verify the result; put longer calculation details in companion notes.

## Living project note (user request, October 21, 2026)

- Maintain `docs/alm_trial_project_note.md` as the pedagogical record of this
  intraorbital-Hubbard ALM study. Update relevant sections when verified
  results, model parameters, lattice, state choices, methods, Moreo's feedback
  or the scientific interpretation changes during project work.
- Cover the model, parameters, geometry, reference predictions, our MFT and
  ED results, major advances and remaining questions. Keep the language plain
  and concise. Distinguish the paper's gRISB phase diagram from our restricted
  HF calculation, and accepted results from checkpoints or unfinished work.
- Keep sources, normalization and reproduction links with numerical results.
  Preserve dated update entries; never promote a selected eigenstate to a
  certified ground state or a finite-cluster correlation to an ALM phase.
- Regenerate the PDF with `deliverables/alm_trial_project_note/build_note.py`
  using the existing bundled Python/ReportLab; run `verify_note.py` there.
  Install no dependency. The editable Page and sync metadata are recorded in
  `docs/alm_trial_project_note_metadata.json`. Read the Page and local note
  before updating either, preserve user edits, and synchronize affected parts.
- The Page is `page_7d98f305debc81919eb3a73cbb34c039`:
  https://chatgpt.com/space/page_7d98f305debc81919eb3a73cbb34c039
- This is an ongoing documentation preference, not authorization to enable
  periodic scientific checks. Automatic job checks remain off unless the
  user asks to change that.
