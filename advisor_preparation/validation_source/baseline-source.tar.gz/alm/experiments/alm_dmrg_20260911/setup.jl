using Pkg, Dates
const HERE = @__DIR__
const STATUS = joinpath(HERE,"setup_status.txt")
function status(message)
    open(STATUS,"a") do io
        println(io,now(UTC)," ",message)
    end
    println(now(UTC)," ",message);flush(stdout)
end
try
    status("START Julia $(VERSION), project=$(Base.active_project())")
    Pkg.instantiate()
    status("INSTANTIATED pinned experimental environment")
    Pkg.precompile()
    @eval using ITensors, ITensorMPS
    status("READY ITensors=$(pkgversion(ITensors)), ITensorMPS=$(pkgversion(ITensorMPS))")
catch error
    status("FAILED $(sprint(showerror,error))")
    rethrow()
end
