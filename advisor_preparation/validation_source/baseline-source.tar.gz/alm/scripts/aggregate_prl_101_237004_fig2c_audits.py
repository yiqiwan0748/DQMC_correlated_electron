#!/usr/bin/env python3
"""Aggregate completed Fig. 2(c) audit batches without recomputing numerical data.

Every selected batch must be complete. The union must contain the ten expected
points exactly once. Source snapshots, copied/current inputs, sector censuses,
and Green-probe coverage are checked before publishing either curve directory.
Original batches remain untouched; complete contributing archives and their
hashes accompany the filtered per-curve tables.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import math
from pathlib import Path
import re
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True
from summarize_prl_101_237004_fig2c import (
    ROOT, DEFAULT_INPUT, CURVES, US, FREQUENCIES, QUADRATURE_COLUMNS,
    Inputs, ReportError, number, integer, boolean, same, key, indexed,
)


TABLES = ("quadrature_and_field.csv", "green_depth.csv", "reference_sectors.csv")
REQUIRED_SOURCES = (
    "scripts/audit_prl_101_237004_fig2c.jl",
    "scripts/prl_101_237004_cluster_green.jl",
    "scripts/prl_101_237004_vca_reference_audit.jl",
)
HASH_LINE = re.compile(r"^([0-9a-f]{64})  (.+)$")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_relative(name: str) -> Path:
    path = Path(name)
    if path.is_absolute() or ".." in path.parts:
        raise ReportError(f"unsafe snapshot path: {name}")
    return path


def table(inputs: Inputs, name: str, required=()) -> tuple[list[str], list[dict]]:
    rows = inputs.csv(name, required)
    header = next(csv.reader(io.StringIO(inputs.text(name))))
    return header, rows


def verify_sector(inputs: Inputs, folder: str, prod: dict, summary: dict) -> None:
    metadata = inputs.toml(f"{folder}/metadata.toml")
    rows = inputs.csv(f"{folder}/sectors.csv")
    for name in ("K_up.csv", "K_down.csv", "particle_minima.csv", "stationary_stability.txt"):
        inputs.read(f"{folder}/{name}")
    if metadata.get("sector_count") != 81 or len(rows) != 81:
        raise ReportError(f"incomplete 81-sector audit: {folder}")
    states = {}
    for row in rows:
        nu, nd, n = (integer(row, x) for x in ("Nup", "Ndown", "N"))
        if not (0 <= nu <= 8 and 0 <= nd <= 8 and n == nu + nd) or (nu, nd) in states:
            raise ReportError(f"invalid/duplicate sector: {folder}")
        if integer(row, "dimension") != math.comb(8, nu) * math.comb(8, nd):
            raise ReportError(f"incorrect sector dimension: {folder}")
        number(row, "energy_canonical")
        if number(row, "direct_residual") < 0:
            raise ReportError("negative eigenpair residual")
        states[nu, nd] = row
    target = number(states[4, 4], "energy_canonical")
    mup = number(prod, "mu_prime")
    lower = max((target - number(r, "energy_canonical")) / (8 - integer(r, "N"))
                for r in rows if integer(r, "N") < 8)
    upper = min((number(r, "energy_canonical") - target) / (integer(r, "N") - 8)
                for r in rows if integer(r, "N") > 8)
    margin = min(number(r, "energy_canonical") - integer(r, "N") * mup - (target - 8 * mup)
                 for pair, r in states.items() if pair != (4, 4))
    same(target, float(metadata["target_energy_canonical"]), "sector target energy")
    for value, meta_name, column in ((lower, "mu_lower", "all_N_mu_lower"),
                                     (upper, "mu_upper", "all_N_mu_upper")):
        same(value, float(metadata[meta_name]), "sector chemical-potential bound")
        same(value, number(summary, column), "summary chemical-potential bound")
    same(margin, number(summary, "minimum_competing_grand_energy_margin"), "sector margin", 2e-9)
    same(max(number(r, "direct_residual") for r in rows), number(summary, "max_sector_residual"),
         "sector residual maximum")
    lowest = all(number(r, "energy_canonical") >= target - 1e-9 for r in rows if integer(r, "N") == 8)
    if lowest != boolean(summary, "target_lowest_at_same_N"):
        raise ReportError("same-N sector classification differs")
    for column in ("ratio", "U", "h", "mu", "mu_prime"):
        same(float(metadata["physical_metadata"][column]), number(prod, column), "sector physical metadata")
    same(float(metadata["U"]), number(prod, "U"), "sector U")
    same(float(metadata["J"]), number(prod, "U") / 4, "sector J")


def load_batch(directory: Path) -> dict:
    directory = directory.resolve()
    inputs = Inputs(directory)
    completion = inputs.text("completed.txt")
    match = re.search(r"^Completed .*audited points=(\d+); source and input hashes unchanged\.", completion, re.M)
    if not match:
        raise ReportError(f"missing genuine batch completion record: {directory}")
    expected_count = int(match[1])
    if not 1 <= expected_count <= 10:
        raise ReportError("invalid completed batch point count")
    provenance = inputs.text("provenance.txt")
    source_hashes, original_inputs = {}, []
    for line in provenance.splitlines():
        item = HASH_LINE.fullmatch(line)
        if not item:
            continue
        sha, name = item.groups()
        path = Path(name)
        if path.is_absolute():
            if any(p[0] == path for p in original_inputs):
                raise ReportError("duplicate input provenance path")
            original_inputs.append((path, sha))
        else:
            relative = safe_relative(name)
            if name in source_hashes:
                raise ReportError("duplicate source provenance path")
            if digest(inputs.read(Path("source_snapshot") / relative)) != sha:
                raise ReportError(f"source snapshot hash differs: {directory}/{relative}")
            source_hashes[name] = sha
    if any(name not in source_hashes for name in REQUIRED_SOURCES) or not original_inputs:
        raise ReportError(f"incomplete source/input provenance: {directory}")
    production, point_inputs, copies = {}, {}, []
    for index, (path, sha) in enumerate(original_inputs, 1):
        copy = Path("inputs") / f"{index}_{path.name}"
        if digest(inputs.read(copy)) != sha or digest(inputs.read(path)) != sha:
            raise ReportError(f"copied/current audit input hash differs: {path}")
        for row in inputs.csv(copy):
            point = key(row)
            if point in production:
                raise ReportError("duplicate point among batch inputs")
            production[point] = row
            point_inputs[point] = dict(original=str(path), copy=copy.as_posix(), sha256=sha)
        copies.append(dict(original=str(path), copy=copy.as_posix(), sha256=sha))
    if len(production) != expected_count:
        raise ReportError("batch completion count differs from copied inputs")
    headers, rows = {}, {}
    for filename in TABLES:
        headers[filename], rows[filename] = table(inputs, filename,
                                                 QUADRATURE_COLUMNS if filename == TABLES[0] else ())
    qmap = indexed(rows[TABLES[0]])
    smap = indexed(rows[TABLES[2]])
    if set(qmap) != set(production) or set(smap) != set(production):
        raise ReportError("batch tables have missing/extra points")
    seen = set()
    for row in rows[TABLES[1]]:
        point = key(row)
        spin, omega = row.get("spin"), number(row, "omega")
        identity = (*point, spin, omega)
        if point not in production or spin not in ("up", "down") or omega not in FREQUENCIES or identity in seen:
            raise ReportError("invalid/duplicate Green-depth probe")
        seen.add(identity)
        same(number(row, "h"), number(production[point], "h"), "Green-probe field")
        for column in ("Green_norm_difference", "Green_relative_difference"):
            if number(row, column) < 0:
                raise ReportError("negative Green difference")
        for column in ("block48_cache_sha256", "block96_cache_sha256"):
            if not re.fullmatch(r"[0-9a-f]{64}", row.get(column, "")):
                raise ReportError("invalid Green reference-cache hash")
    if len(seen) != 12 * len(production):
        raise ReportError("incomplete Green-depth probe coverage")
    for point, prod in production.items():
        q, s = qmap[point], smap[point]
        same(number(q, "h"), number(prod, "h"), "quadrature-audited field")
        same(number(s, "h"), number(prod, "h"), "sector-audited field")
        same(number(s, "mu_prime"), number(prod, "mu_prime"), "sector-audited potential")
        for column in QUADRATURE_COLUMNS:
            if column not in ("production_profile", "field_difference_method", "center_refinement_method"):
                number(q, column)
        original = q["production_profile"] == "original"
        if q["production_profile"] not in ("original", "low_frequency") or \
           q["field_difference_method"] != ("held_potential_Omega" if original else "refilled_canonical_F") or \
           q["center_refinement_method"] != ("fixed_relative_d" if original else "refilled_stationary_solution"):
            raise ReportError("inconsistent audit method/profile")
        if integer(q, "production_order") != integer(prod, "quadrature_order") or \
           integer(q, "refined_order") != 2 * integer(q, "production_order"):
            raise ReportError("audit quadrature orders do not match production")
        label = next(label for r, label, _ in CURVES if r == point[0])
        tag = f"{label}_U{point[1]}"
        verify_sector(inputs, f"sectors/{tag}", prod, s)
        for name in ("refined_center.txt", "depth96_center.txt"):
            inputs.read(f"point_diagnostics/{tag}/{name}")
        if not original:
            for name in ("minus_filling.txt", "plus_filling.txt"):
                inputs.read(f"point_diagnostics/{tag}/{name}")
    inventory = {}
    for path in sorted(directory.rglob("*")):
        if path.is_symlink():
            raise ReportError(f"batch contains a symlink: {path}")
        if path.is_file():
            inventory[path.relative_to(directory).as_posix()] = digest(inputs.read(path))
    inputs.unchanged()
    return dict(directory=directory, inputs=inputs, headers=headers, rows=rows,
                production=production, point_inputs=point_inputs, source_hashes=source_hashes,
                input_records=copies, inventory=inventory)


def load_batches(paths: list[Path]) -> list[dict]:
    resolved = [p.resolve() for p in paths]
    if not paths or len(set(resolved)) != len(resolved) or len({p.name for p in resolved}) != len(resolved):
        raise ReportError("select distinct, uniquely named audit batch directories")
    batches, owners, headers = [], {}, None
    for path in resolved:
        batch = load_batch(path)
        if headers is None:
            headers = batch["headers"]
        elif headers != batch["headers"]:
            raise ReportError("batch CSV schemas differ")
        for point in batch["production"]:
            if point in owners:
                raise ReportError(f"duplicate audited point {point}: {owners[point]} and {path}")
            owners[point] = path
        batches.append(batch)
    expected = {(r, u) for r, _, _ in CURVES for u in US}
    if set(owners) != expected:
        raise ReportError(f"ten unique completed points required; missing={sorted(expected-set(owners))}")
    return batches


def write_csv(path: Path, header: list[str], rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=header)
        writer.writeheader()
        writer.writerows(rows)


def aggregate(paths: list[Path], output_root: Path, check_only=False) -> dict:
    output_root = output_root.resolve()
    targets = [output_root / curve[2] for curve in CURVES]
    if any(path.exists() for path in targets):
        raise ReportError("aggregate output already exists; outputs are never overwritten")
    batches = load_batches(paths)
    if any(output_root.is_relative_to(batch["directory"]) for batch in batches):
        raise ReportError("aggregate output cannot be inside a source batch")
    summary = dict(batches=len(batches), points=10, sector_calculations=810, green_probes=120)
    if check_only:
        return summary
    output_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".fig2c-audit-aggregation-", dir=output_root) as temp:
        stage = Path(temp)
        for ratio, label, audit in CURVES:
            folder = stage / audit
            folder.mkdir()
            contributing = [b for b in batches if any(p[0] == ratio for p in b["production"])]
            manifest = dict(kind="completed_audit_batch_aggregation", ratio=ratio,
                            qualification="Copies completed numerical outputs; does not establish numerical acceptance.",
                            created_utc=dt.datetime.now(dt.timezone.utc).isoformat(), batches={}, points=[])
            for batch in contributing:
                name = batch["directory"].name
                archived = folder / "batches" / name
                shutil.copytree(batch["directory"], archived)
                copied_names = {p.relative_to(archived).as_posix() for p in archived.rglob("*") if p.is_file()}
                if copied_names != set(batch["inventory"]):
                    raise ReportError("batch file inventory changed during archive copying")
                for relative, sha in batch["inventory"].items():
                    if digest((archived / relative).read_bytes()) != sha:
                        raise ReportError("batch changed during archive copying")
                manifest["batches"][name] = dict(original=str(batch["directory"]), files_sha256=batch["inventory"],
                    source_sha256=batch["source_hashes"], original_inputs=batch["input_records"])
                for point in sorted(batch["production"]):
                    if point[0] != ratio:
                        continue
                    tag = f"{label}_U{point[1]}"
                    for directory in ("sectors", "point_diagnostics"):
                        shutil.copytree(archived / directory / tag, folder / directory / tag)
                    manifest["points"].append(dict(ratio=point[0], U=point[1], batch=name,
                                                   input=batch["point_inputs"][point]))
            for filename in TABLES:
                rows = [row for b in contributing for row in b["rows"][filename] if key(row)[0] == ratio]
                rows.sort(key=lambda row: (key(row)[1], row.get("spin", ""), float(row.get("omega", 0))))
                write_csv(folder / filename, batches[0]["headers"][filename], rows)
            manifest["points"].sort(key=lambda row: row["U"])
            (folder / "aggregation.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False)+"\n")
            helper_sources = [Path(__file__).resolve(), ROOT / "scripts/summarize_prl_101_237004_fig2c.py"]
            for source in helper_sources:
                destination = folder / "aggregation_source_snapshot" / "scripts" / source.name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
            provenance = [f"Aggregated completed audit batches for ratio={ratio}; audited points=5.",
                          "No numerical calculation or numerical acceptance is asserted by aggregation.",
                          "Each complete batch is preserved under batches/; aggregation.json maps every point and input."]
            for source in helper_sources:
                provenance.append(f"{digest(source.read_bytes())}  {source}")
            (folder / "provenance.txt").write_text("\n".join(provenance)+"\n")
            (folder / "completed.txt").write_text(
                "Completed audit aggregation; audited points=5; source and input hashes verified unchanged.\n"
                "Completion records aggregation of existing numerical results, not acceptance of every refinement.\n")
            output_hashes = {}
            for path in sorted(folder.rglob("*")):
                if path.is_file():
                    output_hashes[path.relative_to(folder).as_posix()] = digest(path.read_bytes())
            (folder / "output_sha256.json").write_text(json.dumps(output_hashes, indent=2)+"\n")
        for batch in batches:
            batch["inputs"].unchanged()
        # Reserve both final directories exclusively. No pre-existing directory
        # or file is replaced, and completion markers are published last.
        reserved = []
        try:
            for target in targets:
                target.mkdir()
                reserved.append(target)
            for target in targets:
                source = stage / target.name
                for item in source.iterdir():
                    if item.name == "completed.txt":
                        continue
                    if item.is_dir():
                        shutil.copytree(item, target / item.name)
                    else:
                        shutil.copy2(item, target / item.name)
            for batch in batches:
                batch["inputs"].unchanged()
            for target in targets:
                with (target / "completed.txt").open("x") as handle:
                    handle.write((stage / target.name / "completed.txt").read_text())
        except Exception:
            # Retain partial output for inspection, without successful top-level
            # completion markers. It cannot qualify as a final report input.
            for target in reserved:
                (target / "completed.txt").unlink(missing_ok=True)
            raise
    return summary


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--batch-root", type=Path)
    parser.add_argument("--batch", action="append", type=Path)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args(argv)
    parent = args.batch_root or args.input_root / "numerical_audit_batches"
    paths = args.batch if args.batch else sorted(p for p in parent.iterdir() if p.is_dir() and not p.name.startswith(".")) if parent.is_dir() else []
    try:
        result = aggregate(paths, args.output_root or args.input_root, args.check_only)
        print(("Validated " if args.check_only else "Aggregated ") + json.dumps(result, sort_keys=True))
    except (ReportError, OSError, KeyError, TypeError) as exc:
        print(f"Audit aggregation not completed: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
