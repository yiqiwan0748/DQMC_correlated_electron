module Arxiv09013544Noninteracting

using LinearAlgebra

# Existing solvers are reused through an explicit convention adapter. Their
# PRL-specific runner is never invoked, and plotting is loaded only by our runner.
include("run_prl_101_237004_fig1.jl")
const FermiTools = PRL101237004Fig1
const PRLModel = FermiTools.PRL101237004Model

export Hoppings, figure_specs, prl_parameters, bloch_hamiltonian, band_energies,
       fourier_bond_hamiltonian, band_path, filling_audit, fermi_contours,
       contour_band_densities, convention_audit

"""Literal Eq. (14) hoppings of arXiv:0901.3544v1, in eV.

In the fixed `(d_xz,d_yz)` basis, `t1` connects d_xz along y, `t2` along x,
and the positive (x+y) interorbital bond is +t4. Therefore h_xy is
`-4t4*sin(kx)*sin(ky)`. This differs from the existing PRL helper convention.
"""
struct Hoppings{T<:Real}
    t1::T
    t2::T
    t3::T
    t4::T
    function Hoppings(t1::T, t2::T, t3::T, t4::T) where {T<:Real}
        all(isfinite, (t1, t2, t3, t4)) ||
            throw(ArgumentError("hoppings must be finite"))
        new{T}(t1, t2, t3, t4)
    end
end
Hoppings(t1::Real, t2::Real, t3::Real, t4::Real) = Hoppings(promote(t1, t2, t3, t4)...)

"""Printed captions are the primary numerical inputs; no unprinted digits are fitted."""
figure_specs() = (
    (figure=5, name="fig5_SK_equal_gaps", hoppings=Hoppings(0.058, 0.22, -0.21, -0.08),
        printed_mu=-0.03, description="Slater–Koster, equal charge-transfer gaps"),
    (figure=6, name="fig6_SK_direct_hopping", hoppings=Hoppings(-0.1051, 0.1472, -0.1909, -0.0874),
        printed_mu=0.081, description="Slater–Koster plus direct Fe–Fe hopping"),
    (figure=7, name="fig7_tabulated_overlap", hoppings=Hoppings(-0.129, 0.05, -0.137, -0.019),
        printed_mu=0.053, description="Tabulated overlap integrals"),
    (figure=8, name="fig8_band_fit", hoppings=Hoppings(-1.0, 1.3, -0.85, -0.85),
        printed_mu=nothing, description="Band-fit hoppings; chemical potential inferred at n=2"),
)

"""Swap t1/t2 and negate t4 to preserve every matrix entry in the PRL helper."""
prl_parameters(p::Hoppings) = PRLModel.PaperHoppingParameters(p.t2, p.t1, p.t3, -p.t4)
bloch_hamiltonian(kx::Real, ky::Real, p::Hoppings) =
    PRLModel.paper_bloch_hamiltonian(kx, ky, prl_parameters(p))
band_energies(kx::Real, ky::Real, p::Hoppings) =
    PRLModel.paper_band_energies(kx, ky, prl_parameters(p))

"""Independent Fourier sum over the directed bonds printed in Eq. (14).

Each listed bond and its Hermitian conjugate contribute 2*cos(k⋅delta).
This oracle deliberately avoids the sin-product formula and the adapter.
"""
function fourier_bond_hamiltonian(kx::Real, ky::Real, p::Hoppings)
    all(isfinite, (kx, ky)) || throw(ArgumentError("momenta must be finite"))
    diagonal = -2p.t3 * (cos(kx + ky) + cos(kx - ky))
    hxx = -2p.t2 * cos(kx) - 2p.t1 * cos(ky) + diagonal
    hyy = -2p.t1 * cos(kx) - 2p.t2 * cos(ky) + diagonal
    hxy = 2p.t4 * (cos(kx + ky) - cos(kx - ky))
    return [hxx hxy; hxy hyy]
end

"""Γ-X-M-Γ with equal segment widths (as printed) and physical arc length.

Both unshifted E and E−μ are returned so the energy-reference choice is explicit.
"""
function band_path(p::Hoppings, mu::Real; points_per_segment::Integer=400)
    points_per_segment >= 1 || throw(ArgumentError("points_per_segment must be positive"))
    isfinite(mu) || throw(ArgumentError("chemical potential must be finite"))
    path = PRLModel.ValidatedBloch.band_path(
        parameters=PRLModel.repository_parameters(prl_parameters(p)),
        points_per_segment=points_per_segment)
    return merge(path, (path_segment=collect(0:3points_per_segment) ./ points_per_segment,
        lower_relative=path.lower_energy .- mu, upper_relative=path.upper_energy .- mu))
end

filling_audit(p::Hoppings, grid::Integer, mu::Real) =
    FermiTools.filling_audit(prl_parameters(p), grid, mu)
fermi_contours(p::Hoppings, mu::Real; angles::Integer=1440) =
    FermiTools.fermi_contours(prl_parameters(p), mu; angles=angles)
contour_band_densities(contours) = FermiTools.contour_band_densities(contours)

"""Check the independent Fourier oracle and LAPACK eigensolver at generic momenta."""
function convention_audit(p::Hoppings; points::Integer=97)
    points >= 2 || throw(ArgumentError("at least two audit momenta are required"))
    matrix_error = 0.0
    eigenvalue_error = 0.0
    for i in 0:points-1
        kx, ky = -pi + 2pi * i / points, -pi + 2pi * mod(37i + 11, points) / points
        oracle = fourier_bond_hamiltonian(kx, ky, p)
        matrix_error = max(matrix_error, maximum(abs, bloch_hamiltonian(kx, ky, p) - oracle))
        eigenvalue_error = max(eigenvalue_error,
            maximum(abs, band_energies(kx, ky, p) - eigvals(Symmetric(oracle))))
    end
    return (; matrix_error, eigenvalue_error)
end

end
