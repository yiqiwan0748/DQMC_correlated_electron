#!/usr/bin/env julia
module PRL101237004Fig2CAudit
using LinearAlgebra, SHA, Dates
include("run_prl_101_237004_fig2c_resolved.jl")
include("prl_101_237004_vca_reference_audit.jl")
const Campaign=PRL101237004Fig2CResolvedCampaign
const Filling=Campaign.Filling
const R=Campaign.R
const V=R.V
const F=R.F
const A=PRL101237004VCAReferenceAudit
function read_rows(path)
    lines=readlines(path);names=split(lines[1],',')
    [Dict(zip(names,split(line,','))) for line in lines[2:end]]
end
function audit(;input=R.OUTPUT,output=joinpath(input,"numerical_audit"),ratio=nothing,point_paths=nothing)
    BLAS.set_num_threads(1)
    ispath(output) && error("audit output exists; use a fresh directory")
    ratios=ratio===nothing ? (-.2,-.5) : (ratio,)
    inputs=point_paths===nothing ?
        [joinpath(input,"scans",Campaign.ratio_label(r)*".csv") for r in ratios] : abspath.(point_paths)
    !isempty(inputs) && all(isfile,inputs) || error("completed scan or point files required")
    rows=vcat(read_rows.(inputs)...)
    sources=unique(vcat(Campaign.SOURCES,["scripts/prl_101_237004_vca_reference_audit.jl","scripts/audit_prl_101_237004_fig2c.jl"]))
    hashes=Dict(s=>V.filehash(joinpath(R.ROOT,s)) for s in sources)
    mkpath(output)
    for s in sources
        target=joinpath(output,"source_snapshot",s)
        mkpath(dirname(target));cp(joinpath(R.ROOT,s),target)
    end
    copies=Dict{String,String}()
    for (i,p) in enumerate(inputs)
        target=joinpath(output,"inputs",string(i)*"_"*basename(p))
        mkpath(dirname(target));cp(p,target);copies[p]=target
    end
    open(joinpath(output,"provenance.txt"),"w") do io
        println(io,"Started ",now(),"; Julia ",VERSION,"; threads=",Threads.nthreads(),"; BLAS=",BLAS.get_num_threads())
        println(io,"Doubled production quadrature order using the refined low-frequency partition. Original centers are checked at fixed relative d=mu_prime-mu; resolved centers re-solve stationarity, including canonical Fermi-shell/cusp occupations.")
        println(io,"Original field points: held-potential Omega differences. Resolved field points: fully re-solved canonical F differences. Field step2e−4/1e−4; block-depth48/96.")
        println(io,"All81 reference particle/spin sectors at actual mu_prime; lowest roots are numerical comparisons, not rigorous certification from residuals.")
        println(io,"Refined frequency breaks=",Filling.FREQUENCY_BREAKS)
        for s in sources;println(io,hashes[s],"  ",s);end
        for p in inputs;println(io,V.filehash(p),"  ",p);end
    end
    convergence=Tuple[];sectors=Tuple[];greens=Tuple[]
    frequencies=(1e-5,.001,.01,.1,1.,10.)
    for row in rows
        U=parse(Float64,row["U"]);r=parse(Float64,row["ratio"]);h=parse(Float64,row["h"])
        mu=parse(Float64,row["mu"]);mup=parse(Float64,row["mu_prime"])
        L=parse(Int,row["physical_L"]);production_order=parse(Int,row["quadrature_order"])
        refined_order=2production_order
        folder=joinpath(input,"runs",Campaign.ratio_label(r),"U"*string(U))
        canonical_sides=isfile(joinpath(folder,"source_snapshot","scripts","run_prl_101_237004_fig2c_resolved.jl"))
        profile=canonical_sides ? "low_frequency" : "original"
        method=canonical_sides ? "refilled_canonical_F" : "held_potential_Omega"
        Campaign.validated_point(folder,U,r;physical_L=L,order=production_order)
        state=R.reference_state(U,r,h;output=input,block_steps=48)
        lat=V.embedding(state;physical_L=L)
        if canonical_sides
            evaluated=Filling.solve_filling(state,lat;mu_initial=mu,mu_prime_initial=mup,
                order=refined_order,quadrature_breaks=Filling.FREQUENCY_BREAKS,
                gradient_atol=2e-8,density_atol=2e-8)
            evaluated.converged || error("refined stationary center failed at U=$U r=$r")
            refined=evaluated.choice.data
        else
            evaluated=Filling.evaluate_relative(state,lat,mup-mu;mu_prime_initial=mup,
                order=refined_order,quadrature_breaks=Filling.FREQUENCY_BREAKS)
            evaluated.valid || error("refined occupation evaluation failed at U=$U r=$r")
            refined=evaluated.data
        end
        detail=joinpath(output,"point_diagnostics",Campaign.ratio_label(r)*"_U"*string(U))
        mkpath(detail)
        open(joinpath(detail,"refined_center.txt"),"w") do io;show(io,"text/plain",evaluated);end
        step=1e-4
        side_values=Float64[]
        for (label,hh) in (("minus",h-step),("plus",h+step))
            ss=R.reference_state(U,r,hh;output=input,block_steps=48)
            if canonical_sides
                solved=Filling.solve_filling(ss,lat;mu_initial=mu,mu_prime_initial=mup,
                    order=refined_order,quadrature_breaks=Filling.FREQUENCY_BREAKS,
                    gradient_atol=2e-8,density_atol=2e-8)
                open(joinpath(detail,label*"_filling.txt"),"w") do io;show(io,"text/plain",solved);end
                solved.converged || error("refined side filling failed at U=$U r=$r h=$hh")
                push!(side_values,solved.choice.data.canonical_energy)
            else
                x=F.evaluate_functional(ss.reference,lat,mu,mup;
                    quadrature=F.imaginary_quadrature(refined_order;breaks=Filling.FREQUENCY_BREAKS))
                push!(side_values,x.omega)
            end
        end
        # The relative-d evaluator may choose another common shift. F is
        # invariant there, but a held-potential curvature needs the center
        # Omega at exactly the same physical potentials as its two sides.
        if canonical_sides
            center_value=refined.canonical_energy
        else
            held_center=F.evaluate_functional(state.reference,lat,mu,mup;
                quadrature=F.imaginary_quadrature(refined_order;breaks=Filling.FREQUENCY_BREAKS))
            center_value=held_center.omega
        end
        gradient=(side_values[2]-side_values[1])/(2step)
        curvature=(sum(side_values)-2center_value)/step^2
        deeper=R.reference_state(U,r,h;output=input,block_steps=96)
        if canonical_sides
            deep_eval=Filling.solve_filling(deeper,lat;mu_initial=refined.mu,mu_prime_initial=refined.mu_prime,
                order=refined_order,quadrature_breaks=Filling.FREQUENCY_BREAKS,
                gradient_atol=2e-8,density_atol=2e-8)
            deep_eval.converged || error("depth96 stationary center failed")
            deep_data=deep_eval.choice.data
        else
            deep_eval=Filling.evaluate_relative(deeper,lat,mup-mu;mu_prime_initial=mup,
                order=refined_order,quadrature_breaks=Filling.FREQUENCY_BREAKS)
            deep_eval.valid || error("depth96 occupation evaluation failed")
            deep_data=deep_eval.data
        end
        open(joinpath(detail,"depth96_center.txt"),"w") do io;show(io,"text/plain",deep_eval);end
        push!(convergence,(r,U,h,production_order,refined_order,profile,method,
            refined.mu,refined.mu_prime,refined.omega,refined.canonical_energy,refined.density,refined.mu_prime_gradient,refined.moment,
            refined.omega-parse(Float64,row["Omega_per_Fe"]),refined.canonical_energy-parse(Float64,row["F_per_Fe"]),
            refined.moment-parse(Float64,row["moment_signed_muB_per_Fe"]),refined.density-parse(Float64,row["density"]),
            gradient,gradient-parse(Float64,row["h_derivative"]),curvature,
            deep_data.canonical_energy-refined.canonical_energy,deep_data.moment-refined.moment,
            deep_data.density-refined.density,deep_data.mu_prime_gradient-refined.mu_prime_gradient,
            canonical_sides ? "refilled_stationary_solution" : "fixed_relative_d"))
        V.write_csv(joinpath(output,"quadrature_and_field.csv"),
            "ratio,U,h,production_order,refined_order,production_profile,field_difference_method,mu_refined,mu_prime_refined,Omega_refined,F_refined,density_refined,mu_prime_gradient_refined,moment_refined,Omega_refined_minus_production,F_refined_minus_production,moment_refined_minus_production,density_refined_minus_production,h_gradient_step1e_4_refined,h_gradient_change,h_curvature_step1e_4_refined,F_depth96_minus48,moment_depth96_minus48,density_depth96_minus48,mu_prime_gradient_depth96_minus48,center_refinement_method",convergence)
        for spin in (:up,:down),w in frequencies
            g=R.C.cluster_green(state.result,complex(mup,w);spin)
            gd=R.C.cluster_green(deeper.result,complex(mup,w);spin)
            push!(greens,(r,U,h,spin,w,norm(g-gd),norm(g-gd)/max(norm(gd),eps()),V.filehash(state.cache),V.filehash(deeper.cache)))
        end
        V.write_csv(joinpath(output,"green_depth.csv"),"ratio,U,h,spin,omega,Green_norm_difference,Green_relative_difference,block48_cache_sha256,block96_cache_sha256",greens)
        sector_audit=A.audit_reference_ground(state.metadata.Kup,state.metadata.Kdown,U,4,4;J=U/4)
        status=A.reference_stability(sector_audit,mup)
        sector_folder=joinpath(output,"sectors",Campaign.ratio_label(r)*"_U"*string(U))
        A.write_reference_audit(sector_audit,sector_folder;physical_metadata=Dict("ratio"=>r,"U"=>U,"h"=>h,"mu"=>mu,"mu_prime"=>mup))
        open(joinpath(sector_folder,"stationary_stability.txt"),"w") do io;show(io,"text/plain",status);end
        target_omega=sector_audit.target.energy-8mup
        margin=minimum(x.energy-x.N*mup-target_omega for x in sector_audit.rows if (x.Nup,x.Ndown)!=(4,4))
        push!(sectors,(r,U,h,mup,sector_audit.target.energy-state.result.E0,
            maximum(x.residual for x in sector_audit.rows),sector_audit.mu_interval...,margin,sector_audit.target_lowest_at_same_N))
        V.write_csv(joinpath(output,"reference_sectors.csv"),
            "ratio,U,h,mu_prime,target_E0_difference,max_sector_residual,all_N_mu_lower,all_N_mu_upper,minimum_competing_grand_energy_margin,target_lowest_at_same_N",sectors)
        println("audited U=",U," r=",r," h=",h," F drift=",last(convergence)[16]," moment drift=",last(convergence)[17]," sector margin=",margin)
        flush(stdout)
    end
    all(V.filehash(joinpath(R.ROOT,s))==hashes[s] for s in sources) || error("audit source changed")
    for p in inputs
        V.filehash(p)==V.filehash(copies[p]) || error("input changed")
    end
    open(joinpath(output,"completed.txt"),"w") do io
        println(io,"Completed ",now(),"; audited points=",length(rows),"; source and input hashes unchanged.")
        println(io,"Max refined-production: F=",maximum(abs(x[16]) for x in convergence),"; moment=",maximum(abs(x[17]) for x in convergence),"; density=",maximum(abs(x[18]) for x in convergence))
        println(io,"Max depth48-96 Green norm difference=",maximum(x[6] for x in greens))
        println(io,"Min competing sector grand energy margin=",minimum(x[9] for x in sectors))
        println(io,"Inspect quadrature/field/sector diagnostics; completion does not assert agreement with the paper or acceptance of every refinement.")
    end
    output
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    isempty(ARGS) || error("use audit(;input,output,ratio) from Julia for alternate paths")
    println(PRL101237004Fig2CAudit.audit())
end
