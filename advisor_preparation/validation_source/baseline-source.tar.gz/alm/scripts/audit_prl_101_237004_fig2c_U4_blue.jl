#!/usr/bin/env julia

# Selected-point numerical audit. Model parameters and the published curve
# never enter the refinement criteria. Production artifacts remain untouched.
using LinearAlgebra, SHA, TOML, Dates
include("prl_101_237004_fig2c_filling.jl")
const Filling=PRL101237004Fig2CFilling
const R=Filling.R
const V=R.V
const F=R.F

function read_selected_csv(path)
    lines=readlines(path)
    names=split(first(lines),',')
    [Dict(names .=> split(line,',')) for line in lines[2:end] if !isempty(line)]
end

function audit_U4_blue()
    isempty(ARGS) || error("selected-point audit has fixed canonical inputs")
    Threads.nthreads() in (1,2) || error("use one or two Julia threads")
    BLAS.set_num_threads(1)
    input=joinpath(R.OUTPUT,"runs","r_minus_0p2","U4.0")
    output=joinpath(R.OUTPUT,"selected_U4_blue_audit")
    ispath(output) && error("audit output exists; preserve its provenance")
    row=only(read_selected_csv(joinpath(input,"result.csv")))
    U,ratio,h,mu,mup=[parse(Float64,row[k]) for k in ("U","ratio","h","mu","mu_prime")]
    U==4. && ratio==-.2 && parse(Float64,row["J"])==1. || error("unexpected physical point")
    all(parse(Int,row[k])==value for (k,value) in (("physical_L",48),("quadrature_order",24),("block_steps",48))) || error("unexpected production settings")
    sources=vcat(R.SOURCES,["scripts/prl_101_237004_fig2c_filling.jl","scripts/audit_prl_101_237004_fig2c_U4_blue.jl"])
    hashes=Dict(s=>V.filehash(joinpath(R.ROOT,s)) for s in sources)
    for source in sources
        source=="scripts/audit_prl_101_237004_fig2c_U4_blue.jl" && continue
        V.filehash(joinpath(input,"source_snapshot",source))==hashes[source] || error("production source differs: $source")
    end
    input_names=("result.csv","field_sides.csv","provenance.txt","completed.txt")
    input_hashes=Dict(name=>V.filehash(joinpath(input,name)) for name in input_names)
    mkpath(output)
    for source in sources
        target=joinpath(output,"source_snapshot",source)
        mkpath(dirname(target));cp(joinpath(R.ROOT,source),target)
    end
    for name in input_names
        target=joinpath(output,"inputs",name)
        mkpath(dirname(target));cp(joinpath(input,name),target)
    end
    known=read_selected_csv(joinpath(input,"field_sides.csv"))
    cache_paths=String[row["reference_cache"]]
    for r in known
        hr=parse(Float64,r["h"])
        any(hr==h+s for s in (-2e-4,2e-4)) && push!(cache_paths,r["reference_cache"])
    end
    copied_cache_hashes=Dict{String,String}()
    for path in unique(cache_paths)
        src=joinpath(R.OUTPUT,path);dst=joinpath(output,path)
        mkpath(dirname(dst));cp(src,dst)
        copied_cache_hashes[path]=V.filehash(src)
    end
    function reference(field;depth=48)
        R.reference_state(U,ratio,field;block_steps=depth,output)
    end
    state=reference(h)
    V.filehash(state.cache)==copied_cache_hashes[row["reference_cache"]] || error("copied reference identity differs")
    lat48=V.embedding(state;physical_L=48)
    lat96=V.embedding(state;physical_L=96)
    evaluations=Tuple[]
    function evaluate(label,s,lat,physical_L,order,physical_mu=mu,reference_mu=mup)
        seconds=@elapsed x=F.evaluate_functional(s.reference,lat,physical_mu,reference_mu;
                                                quadrature=F.imaginary_quadrature(order))
        push!(evaluations,(label,s.metadata.h,physical_L,order,s.metadata.block_steps,
            x.mu,x.mu_prime,x.omega,x.omega+2x.mu,x.density,x.mu_prime_gradient,x.moment,seconds,V.filehash(s.cache)))
        V.write_csv(joinpath(output,"functional_evaluations.csv"),
            "label,h,physical_L,quadrature_order,block_steps,mu,mu_prime,Omega_per_Fe,Omega_plus_2mu,density,mu_prime_gradient,moment_signed_muB_per_Fe,seconds,reference_cache_sha256",evaluations)
        println(now()," ",label," m=",x.moment," n-2=",x.density-2," g=",x.mu_prime_gradient);flush(stdout)
        x
    end
    baseline=evaluate("baseline",state,lat48,48,24)
    abs(baseline.omega-parse(Float64,row["Omega_per_Fe"]))<1e-11 || error("production Omega was not reproduced")
    abs(baseline.moment-parse(Float64,row["moment_signed_muB_per_Fe"]))<1e-11 || error("production moment was not reproduced")
    refined=evaluate("frequency_refined",state,lat48,48,48)
    deep=reference(h;depth=96)
    deep_value=evaluate("depth_refined",deep,lat48,48,48)
    green_rows=Tuple[]
    for spin in (:up,:down),omega in (1e-5,.001,.01,.1,1.,10.)
        g=R.C.cluster_green(state.result,complex(mup,omega);spin)
        gd=R.C.cluster_green(deep.result,complex(mup,omega);spin)
        push!(green_rows,(spin,omega,norm(g-gd),maximum(abs,g-gd),norm(g-gd)/max(norm(gd),eps())))
    end
    V.write_csv(joinpath(output,"green_depth.csv"),
        "spin,imaginary_omega,difference_Frobenius,difference_max_entry,relative_difference_Frobenius",green_rows)
    derivatives=Tuple[]
    for step in (2e-4,1e-4,5e-5)
        minus=reference(h-step);plus=reference(h+step)
        low=evaluate("field_minus_$step",minus,lat48,48,48)
        high=evaluate("field_plus_$step",plus,lat48,48,48)
        gradient=(high.omega-low.omega)/(2step)
        partial_curvature=(high.omega-2refined.omega+low.omega)/step^2
        push!(derivatives,(step,gradient,partial_curvature,
            low.moment,high.moment,(high.moment-low.moment)/(2step)))
        V.write_csv(joinpath(output,"field_derivatives.csv"),
            "step,h_gradient_held_mu_muprime,partial_h_curvature_held_mu_muprime,moment_minus,moment_plus,partial_moment_slope",derivatives)
        println(now()," field step=",step," gradient=",gradient," partial curvature=",partial_curvature);flush(stdout)
    end
    mesh=evaluate("mesh_refined_fixed_variables",state,lat96,96,48)
    mesh_residual_shift=max(abs(mesh.density-refined.density),abs(mesh.mu_prime_gradient-refined.mu_prime_gradient))
    resolve_mesh=mesh_residual_shift>2e-8 || max(abs(mesh.density-2),abs(mesh.mu_prime_gradient))>1e-7
    mesh_filling=nothing
    mesh_resolved=mesh
    if resolve_mesh
        mesh_filling=Filling.solve_filling(state,lat96;mu_initial=mu,mu_prime_initial=mup,
            order=48,gradient_atol=2e-9,density_atol=2e-9)
        open(joinpath(output,"mesh_filling.txt"),"w") do io
            show(io,"text/plain",mesh_filling)
        end
        mesh_filling.converged || error("mesh-refined filling did not converge; inspect saved diagnostics")
        mesh_resolved=evaluate("mesh_refined_filling_resolved",state,lat96,96,48,
            mesh_filling.choice.data.mu,mesh_filling.choice.data.mu_prime)
    end
    richardson=(4derivatives[3][2]-derivatives[2][2])/3
    summary=Dict{String,Any}("created_utc"=>string(now(UTC)),"U"=>U,"J"=>U/4,"ratio"=>ratio,"h"=>h,
        "mu"=>mu,"mu_prime"=>mup,"moment_original"=>baseline.moment,
        "Omega_q48_minus_q24"=>refined.omega-baseline.omega,
        "moment_q48_minus_q24"=>refined.moment-baseline.moment,
        "density_q48_minus_q24"=>refined.density-baseline.density,
        "gradient_q48_minus_q24"=>refined.mu_prime_gradient-baseline.mu_prime_gradient,
        "moment_depth96_minus48"=>deep_value.moment-refined.moment,
        "Omega_depth96_minus48"=>deep_value.omega-refined.omega,
        "max_actual_frequency_Green_difference"=>maximum(r[3] for r in green_rows),
        "h_gradient_Richardson"=>richardson,
        "h_gradient_Richardson_change_from_production"=>richardson-parse(Float64,row["h_derivative"]),
        "mesh_Omega_change_fixed_variables"=>mesh.omega-refined.omega,
        "mesh_moment_change_fixed_variables"=>mesh.moment-refined.moment,
        "mesh_density_change_fixed_variables"=>mesh.density-refined.density,
        "mesh_gradient_change_fixed_variables"=>mesh.mu_prime_gradient-refined.mu_prime_gradient,
        "mesh_filling_resolved"=>resolve_mesh,"mesh_final_mu"=>mesh_resolved.mu,
        "mesh_final_mu_prime"=>mesh_resolved.mu_prime,"mesh_final_density"=>mesh_resolved.density,
        "mesh_final_gradient"=>mesh_resolved.mu_prime_gradient,"mesh_final_moment"=>mesh_resolved.moment,
        "mesh_final_moment_change"=>mesh_resolved.moment-refined.moment,
        "limits"=>"A selected-point convergence audit at the production h. Finite-difference field derivatives hold both potentials fixed. Their partial curvature is not the constrained canonical curvature, so it is not used to certify a corrected minimum. L96 filling is re-solved only when its residual shift exceeds2e-8 or residuals exceed1e-7. No model parameter or published value enters the refinements.")
    open(joinpath(output,"summary.toml"),"w") do io
        TOML.print(io,summary;sorted=true)
    end
    provenance=Dict{String,Any}("julia_version"=>string(VERSION),"Julia_threads"=>Threads.nthreads(),
        "BLAS_threads"=>BLAS.get_num_threads(),"source_sha256"=>hashes,"input_sha256"=>input_hashes,
        "copied_cache_sha256"=>copied_cache_hashes,
        "deep_cache_sha256"=>V.filehash(deep.cache),"deep_cache"=>relpath(deep.cache,output),
        "invocation"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig2c_U4_blue.jl")
    open(joinpath(output,"provenance.toml"),"w") do io
        TOML.print(io,provenance;sorted=true)
    end
    all(V.filehash(joinpath(R.ROOT,s))==hash for (s,hash) in hashes) || error("source changed during audit")
    all(V.filehash(joinpath(input,n))==hash for (n,hash) in input_hashes) || error("production inputs changed during audit")
    files=("functional_evaluations.csv","green_depth.csv","field_derivatives.csv","summary.toml","provenance.toml")
    open(joinpath(output,"completed.toml"),"w") do io
        TOML.print(io,Dict("completed_utc"=>string(now(UTC)),
            "output_sha256"=>Dict(n=>V.filehash(joinpath(output,n)) for n in files));sorted=true)
    end
    println("summary: ",summary)
    return output
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && println(audit_U4_blue())
