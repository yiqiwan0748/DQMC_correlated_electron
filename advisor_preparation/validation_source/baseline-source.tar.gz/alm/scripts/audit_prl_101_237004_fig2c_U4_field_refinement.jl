#!/usr/bin/env julia

# Refine only the already selected U4 blue stationary branch. The bracketing
# derivatives solve filling at each center; no partial-curvature assumption
# is used to locate or classify the constrained field minimum.
include("audit_prl_101_237004_fig2c_U4_blue.jl")
using Serialization

function refine_U4_field()
    isempty(ARGS) || error("bounded field refinement uses fixed audited input")
    Threads.nthreads() in (1,2) || error("use one or two Julia threads")
    BLAS.set_num_threads(1)
    parent=joinpath(R.OUTPUT,"selected_U4_blue_audit")
    parent_summary=TOML.parsefile(joinpath(parent,"summary.toml"))
    U,ratio,h0,mu0,mup0=[parent_summary[k] for k in ("U","ratio","h","mu","mu_prime")]
    output=joinpath(parent,"field_refinement")
    ispath(output) && error("refinement output exists; preserve its provenance")
    sources=vcat(R.SOURCES,["scripts/prl_101_237004_fig2c_filling.jl",
        "scripts/audit_prl_101_237004_fig2c_U4_blue.jl","scripts/audit_prl_101_237004_fig2c_U4_field_refinement.jl"])
    hashes=Dict(s=>V.filehash(joinpath(R.ROOT,s)) for s in sources)
    inputs=("summary.toml","provenance.toml","completed.toml")
    input_hashes=Dict(n=>V.filehash(joinpath(parent,n)) for n in inputs)
    mkpath(output)
    for source in sources
        target=joinpath(output,"source_snapshot",source)
        mkpath(dirname(target));cp(joinpath(R.ROOT,source),target)
    end
    for name in inputs
        target=joinpath(output,"inputs",name)
        mkpath(dirname(target));cp(joinpath(parent,name),target)
    end
    copied=Dict{String,String}()
    for name in readdir(joinpath(parent,"reference_cache"))
        endswith(name,".jls") || continue
        source=joinpath(parent,"reference_cache",name)
        saved=open(deserialize,source)
        saved.metadata.block_steps==48 || continue
        target=joinpath(output,"reference_cache",name)
        mkpath(dirname(target));cp(source,target)
        copied[relpath(source,R.ROOT)]=V.filehash(source)
    end
    reference(h)=R.reference_state(U,ratio,h;block_steps=48,output)
    initial_reference=reference(h0)
    lat=V.embedding(initial_reference;physical_L=48)
    quadrature=F.imaginary_quadrature(48)
    step=5e-5
    derivative_atol=5e-7
    center_rows=Tuple[];side_rows=Tuple[];log_rows=Tuple[]
    cache=Dict{Float64,Any}()
    function at(h)
        get!(cache,Float64(h)) do
            state=reference(h)
            filling=Filling.solve_filling(state,lat;mu_initial=mu0,mu_prime_initial=mup0,
                order=48,gradient_atol=2e-10,density_atol=2e-10)
            open(joinpath(output,"filling_h"*string(reinterpret(UInt64,Float64(h));base=16)*".txt"),"w") do io
                show(io,"text/plain",filling)
            end
            filling.converged || error("center filling did not converge at h=$h")
            x=filling.choice.data
            push!(center_rows,(h,x.mu,x.mu_prime,x.omega,x.canonical_energy,x.density,x.mu_prime_gradient,
                x.moment,filling.functional_evaluations,V.filehash(state.cache)))
            V.write_csv(joinpath(output,"centers.csv"),
                "h,mu,mu_prime,Omega_per_Fe,F_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,filling_evaluations,reference_cache_sha256",center_rows)
            sides=Float64[]
            for hs in (h-step,h+step)
                s=reference(hs)
                y=F.evaluate_functional(s.reference,lat,x.mu,x.mu_prime;quadrature)
                push!(sides,y.omega)
                push!(side_rows,(h,hs,x.mu,x.mu_prime,y.omega,y.density,y.mu_prime_gradient,y.moment,V.filehash(s.cache)))
            end
            V.write_csv(joinpath(output,"sides.csv"),
                "center_h,side_h,held_mu,held_mu_prime,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,reference_cache_sha256",side_rows)
            gradient=(sides[2]-sides[1])/(2step)
            result=(;h=Float64(h),gradient,data=x)
            println(now()," refined center h=",h," gradient=",gradient," m=",x.moment,
                " n-2=",x.density-2," g_muprime=",x.mu_prime_gradient);flush(stdout)
            result
        end
    end
    left=at(h0-5e-5)
    right=at(h0+5e-5)
    left.gradient<0<right.gradient || error("nearby negative-to-positive derivative bracket was not found")
    initial_bracket=(left.h,right.h)
    initial_gradients=(left.gradient,right.gradient)
    slope=(right.gradient-left.gradient)/(right.h-left.h)
    best=abs(left.gradient)<abs(right.gradient) ? left : right
    converged=false
    for iteration in 1:8
        width=right.h-left.h
        proposal=right.h-right.gradient*width/(right.gradient-left.gradient)
        if !isfinite(proposal) || !(left.h+.01width<proposal<right.h-.01width) || iteration%4==0
            proposal=(left.h+right.h)/2
        end
        result=at(proposal)
        abs(result.gradient)<abs(best.gradient) && (best=result)
        push!(log_rows,(iteration,result.h,result.gradient,result.data.canonical_energy,result.data.moment,
            left.h,right.h,left.gradient,right.gradient))
        V.write_csv(joinpath(output,"refinement_history.csv"),
            "iteration,h,gradient,F_per_Fe,moment_signed_muB_per_Fe,bracket_lower,bracket_upper,gradient_lower,gradient_upper",log_rows)
        if result.gradient<0
            left=result
        else
            right=result
        end
        if abs(result.gradient)<=derivative_atol
            best=result;converged=true;break
        end
    end
    summary=Dict{String,Any}("completed_utc"=>string(now(UTC)),"converged"=>converged,
        "U"=>U,"J"=>U/4,"ratio"=>ratio,"physical_L"=>48,"quadrature_order"=>48,"block_steps"=>48,
        "field_step"=>step,"derivative_atol"=>derivative_atol,
        "initial_h"=>h0,"refined_h"=>best.h,"h_change"=>best.h-h0,
        "refined_gradient"=>best.gradient,"refined_mu"=>best.data.mu,"refined_mu_prime"=>best.data.mu_prime,
        "refined_density"=>best.data.density,"refined_mu_prime_gradient"=>best.data.mu_prime_gradient,
        "refined_F"=>best.data.canonical_energy,"refined_moment_signed"=>best.data.moment,
        "refined_moment_abs"=>abs(best.data.moment),
        "moment_signed_change_from_production"=>best.data.moment-parent_summary["moment_original"],
        "initial_sign_bracket"=>collect(initial_bracket),"initial_bracket_gradients"=>collect(initial_gradients),
        "initial_envelope_derivative_slope"=>slope,"final_sign_bracket"=>[left.h,right.h],
        "final_bracket_gradients"=>[left.gradient,right.gradient],
        "limits"=>"Nearby minimum on the same constrained filling branch, certified by a negative-to-positive envelope-derivative bracket and the stated finite-difference gradient tolerance. The finite step is5e-5; this is not a strict exact-derivative or global-minimum certificate. Both filling residuals are explicitly re-solved at every center.")
    open(joinpath(output,"summary.toml"),"w") do io
        TOML.print(io,summary;sorted=true)
    end
    provenance=Dict("source_sha256"=>hashes,"input_sha256"=>input_hashes,"copied_cache_sha256"=>copied,
        "julia_version"=>string(VERSION),"Julia_threads"=>Threads.nthreads(),"BLAS_threads"=>BLAS.get_num_threads(),
        "invocation"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig2c_U4_field_refinement.jl")
    open(joinpath(output,"provenance.toml"),"w") do io
        TOML.print(io,provenance;sorted=true)
    end
    all(V.filehash(joinpath(R.ROOT,s))==hash for (s,hash) in hashes) || error("source changed during refinement")
    all(V.filehash(joinpath(parent,n))==hash for (n,hash) in input_hashes) || error("parent audit changed during refinement")
    converged || error("field refinement did not converge; diagnostics retained")
    names=("summary.toml","provenance.toml","centers.csv","sides.csv","refinement_history.csv")
    open(joinpath(output,"completed.toml"),"w") do io
        TOML.print(io,Dict("completed_utc"=>string(now(UTC)),"output_sha256"=>Dict(n=>V.filehash(joinpath(output,n)) for n in names));sorted=true)
    end
    println("summary: ",summary)
    return output
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && println(refine_U4_field())
