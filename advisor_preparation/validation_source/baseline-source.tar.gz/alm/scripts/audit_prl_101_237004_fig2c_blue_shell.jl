#!/usr/bin/env julia
using LinearAlgebra, SHA, Dates
include("prl_101_237004_fig2c_filling.jl")
const P=PRL101237004Fig2CFilling
const R=P.R
const F=P.F
const BREAKS=(0.,1e-11,1e-9,1e-7,1e-5,.001,.01,.1,1.,10.,100.)

function shell_probe(state,lat,d;order=24)
    ref=state.reference
    region=P.occupation_region(ref,lat,d;mu_prime_initial=.4125,x_atol=1e-12,max_iterations=48)
    q=F.imaginary_quadrature(order;breaks=BREAKS)
    if region.converged
        mup=region.choice.mu_prime
        x=F.evaluate_functional(ref,lat,mup-d,mup;quadrature=q)
        return (;d,mu=mup-d,mu_prime=mup,F=x.omega+2x.mu,omega=x.omega,
            density=x.density,gradient=x.mu_prime_gradient,moment=x.moment,
            fraction=NaN,mismatch_left=0,mismatch_right=0,mup_left=mup,mup_right=mup,
            density_left=x.density,density_right=x.density,gradient_left=x.mu_prime_gradient,
            gradient_right=x.mu_prime_gradient,F_boundary_difference=0.,kind=:interval,order,
            pole_bracket_width=0.,left_inertia_min=region.choice.minimum_reduced_eigenvalue,
            right_inertia_min=region.choice.minimum_reduced_eigenvalue)
    end
    positive=filter(x->x.mismatch>0,region.log)
    negative=filter(x->x.mismatch<0,region.log)
    isempty(positive) && error("no positive count at d=$d")
    isempty(negative) && error("no negative count at d=$d")
    left=positive[argmax(x.mu_prime for x in positive)]
    right=negative[argmin(x.mu_prime for x in negative)]
    right.mu_prime-left.mu_prime<=2e-12 || error("unresolved shell at d=$d")
    shell=(left.mu_prime+right.mu_prime)/2
    fraction=left.mismatch/(left.mismatch-right.mismatch)
    function safe_side(direction,mismatch)
        last=nothing
        delta=(ref.mu_interval[2]-ref.mu_interval[1])*1e-6
        for i in 1:20
            trial=shell+direction*delta
            ref.mu_interval[1]<trial<ref.mu_interval[2] || break
            y=P.occupation_inertia(ref,lat,d,trial)
            y.mismatch==mismatch || break
            last=y
            delta*=2
        end
        last===nothing && error("could not resolve one-sided interval at d=$d")
        last
    end
    a=safe_side(-1,left.mismatch); b=safe_side(1,right.mismatch)
    x=F.evaluate_functional(ref,lat,a.mu,a.mu_prime;quadrature=q)
    y=F.evaluate_functional(ref,lat,b.mu,b.mu_prime;quadrature=q)
    fa=x.omega+2x.mu+a.offset*(shell-a.mu_prime)
    fb=y.omega+2y.mu+b.offset*(shell-b.mu_prime)
    mix(t,s)=(1-fraction)*t+fraction*s
    canonical=mix(fa,fb)
    (;d,mu=shell-d,mu_prime=shell,F=canonical,omega=canonical-2(shell-d),
      density=mix(x.density,y.density),gradient=mix(x.mu_prime_gradient,y.mu_prime_gradient),
      moment=mix(x.moment,y.moment),fraction,mismatch_left=left.mismatch,
      mismatch_right=right.mismatch,mup_left=a.mu_prime,mup_right=b.mu_prime,
      density_left=x.density,density_right=y.density,gradient_left=x.mu_prime_gradient,
      gradient_right=y.mu_prime_gradient,F_boundary_difference=fb-fa,kind=:shell_ensemble,order,
      pole_bracket_width=right.mu_prime-left.mu_prime,
      left_inertia_min=a.minimum_reduced_eigenvalue,right_inertia_min=b.minimum_reduced_eigenvalue)
end

function main()
    BLAS.set_num_threads(1)
    out=joinpath(R.OUTPUT,"blue_shell_audit")
    isdir(out) && error("preserve existing output: $out")
    mkpath(out)
    sources=unique(vcat(R.SOURCES,["scripts/prl_101_237004_fig2c_filling.jl",
        "scripts/audit_prl_101_237004_fig2c_blue_shell.jl"]))
    open(joinpath(out,"provenance.txt"),"w") do io
        println(io,"Created UTC: ",now(UTC),"; Julia: ",VERSION)
        println(io,"Command: OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig2c_blue_shell.jl")
        println(io,"threads=",Threads.nthreads(),"; BLAS=",BLAS.get_num_threads(),"; quadrature breaks=",BREAKS)
        for source in sources
            path=joinpath(R.ROOT,source); dest=joinpath(out,"source_snapshot",source)
            mkpath(dirname(dest)); cp(path,dest)
            println(io,bytes2hex(sha256(read(path))),"  ",source)
        end
    end
    state=R.reference_state(.5,-.2,0.)
    lat=R.V.embedding(state;physical_L=48)
    println("loaded ",state.cache," E0=",state.result.E0);flush(stdout)
    records=NamedTuple[]
    function at(d;order=24)
        x=shell_probe(state,lat,d;order)
        push!(records,x)
        open(joinpath(out,"shell_samples.csv"),"w") do io
            println(io,join(string.(keys(x)),','))
            for row in records
                println(io,join(values(row),','))
            end
        end
        println(x);flush(stdout)
        x
    end
    coarse=[at(d) for d in (-.05,0.,.05)]
    for i in 1:2
        a,b=coarse[i],coarse[i+1]
        signbit(a.gradient)==signbit(b.gradient) && continue
        for j in 1:12
            t=a.d-a.gradient*(b.d-a.d)/(b.gradient-a.gradient)
            if !(a.d+.03(b.d-a.d)<t<b.d-.03(b.d-a.d))
                t=(a.d+b.d)/2
            end
            x=at(t)
            if abs(x.gradient)<2e-8 && abs(x.density-2)<2e-8
                at(t;order=48)
                break
            end
            if signbit(x.gradient)==signbit(a.gradient);a=x;else;b=x;end
        end
    end
    open(joinpath(out,"completed.txt"),"w") do io
        println(io,"Bounded diagnostic completed; shell ensemble is a derived canonical zero-temperature continuation, not a printed PRL setting.")
    end
end
abspath(PROGRAM_FILE)==(@__FILE__) && main()
