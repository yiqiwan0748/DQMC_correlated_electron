#!/usr/bin/env julia
using LinearAlgebra, SHA, Dates
include("prl_101_237004_fig2c_resolved_filling.jl")
const S=PRL101237004Fig2CResolvedFilling
const R=S.R
function main()
    BLAS.set_num_threads(1)
    out=joinpath(R.OUTPUT,"ensemble_filling_regression",isempty(ARGS) ? "attempt1" : only(ARGS))
    ispath(out) && error("preserve existing output: $out")
    mkpath(out)
    sources=unique(vcat(R.SOURCES,["scripts/prl_101_237004_fig2c_filling.jl",
        "scripts/prl_101_237004_fig2c_resolved_filling.jl",
        "scripts/prl_101_237004_fig2c_fermi_shell.jl",
        "scripts/audit_prl_101_237004_fig2c_ensemble_regression.jl"]))
    hashes=Dict(source=>bytes2hex(sha256(read(joinpath(R.ROOT,source)))) for source in sources)
    open(joinpath(out,"provenance.txt"),"w") do io
        println(io,"UTC: ",now(UTC)," Julia:",VERSION," JuliaThreads:",Threads.nthreads()," BLAS:",BLAS.get_num_threads())
        println(io,"Command: OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig2c_ensemble_regression.jl ",isempty(ARGS) ? "" : only(ARGS))
        for source in sources
            dest=joinpath(out,"source_snapshot",source);mkpath(dirname(dest));cp(joinpath(R.ROOT,source),dest)
            println(io,hashes[source],"  ",source)
        end
    end
    open(joinpath(out,"results.csv"),"w") do io
        println(io,"U,ratio,h,status,mu,mu_prime,F_per_Fe,Omega_per_Fe,density,mu_prime_gradient,moment,occupation_policy,fraction,functional_evaluations,inertia_evaluations,seconds,q48_q96_F_difference,q48_q96_density_difference,q48_q96_gradient_difference,q48_q96_moment_difference")
    end
    for (U,r,h) in ((.5,-.2,0.),(1.,-.5,.005))
        state=R.reference_state(U,r,h)
        lat=R.V.embedding(state;physical_L=48)
        println("starting ",(U,r,h)," cache=",state.cache);flush(stdout)
        seconds=@elapsed solved=S.solve_filling(state,lat;mu_initial=R.initial_mu(U,r),order=48,
            gradient_atol=2e-8,density_atol=2e-8)
        logpath=joinpath(out,"filling_U$(U)_r$(r)_h$(h).txt")
        open(logpath,"w") do io
            show(io,MIME("text/plain"),solved);println(io)
        end
        println("done ",(U,r,h)," status=",solved.status," seconds=",seconds);flush(stdout)
        solved.converged || error("failed (see $logpath)")
        x=solved.choice.data
        if x.occupation_policy==:canonical_relative_cusp_ensemble
            deeper=S.solve_filling(state,lat;mu_initial=x.mu,mu_prime_initial=x.mu_prime,
                order=96,gradient_atol=2e-8,density_atol=2e-8,relative_step=1e-6)
            deeper.converged || error("q96 cusp filling invalid")
            y=deeper.choice.data
        else
            deeper=S.evaluate_relative(state,lat,x.mu_prime-x.mu;mu_prime_initial=x.mu_prime,order=96)
            deeper.valid || error("q96 callback invalid")
            y=deeper.data
        end
        open(joinpath(out,"q96_U$(U)_r$(r)_h$(h).txt"),"w") do io
            show(io,MIME("text/plain"),deeper);println(io)
        end
        fraction=hasproperty(x,:shell_fraction) ? x.shell_fraction : NaN
        row=(U,r,h,solved.status,x.mu,x.mu_prime,x.canonical_energy,x.omega,x.density,
            x.mu_prime_gradient,x.moment,x.occupation_policy,fraction,solved.functional_evaluations,
            solved.occupation_evaluations,seconds,y.canonical_energy-x.canonical_energy,
            y.density-x.density,y.mu_prime_gradient-x.mu_prime_gradient,y.moment-x.moment)
        open(joinpath(out,"results.csv"),"a") do io;println(io,join(row,','));end
        println(row);flush(stdout)
        abs(x.omega_reference+x.trace_correction-x.trace_log_integral/(pi*state.reference.nsites)-x.omega)<1e-13 || error("bad additive decomposition")
    end
    for source in sources
        bytes2hex(sha256(read(joinpath(R.ROOT,source))))==hashes[source] || error("source changed during diagnostic")
    end
    write(joinpath(out,"completed.txt"),"Two actual frozen-core filling regressions converged and q96 checked.\n")
end
abspath(PROGRAM_FILE)==(@__FILE__) && main()
