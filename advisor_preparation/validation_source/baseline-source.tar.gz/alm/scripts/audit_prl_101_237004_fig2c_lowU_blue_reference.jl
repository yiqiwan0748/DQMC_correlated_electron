#!/usr/bin/env julia

using LinearAlgebra, SHA, TOML, Dates
include("prl_101_237004_vca_reference_audit.jl")
include("prl_101_237004_vca_geometry.jl")
const A=PRL101237004VCAReferenceAudit
const G=PRL101237004VCAGeometry

function spin_squared_matrix(H,vectors)
    E=A.C.ED
    nmodes=H.basis.nmodes
    destination=E.sector_basis(nmodes,H.basis.Nup+1,H.basis.Ndown-1)
    raised=zeros(Float64,length(destination.states),size(vectors,2))
    for (column,state) in enumerate(H.basis.states),mode in 1:nmodes
        moved=E.apply_fermion_ops(state,((nmodes+mode,false),(mode,true)))
        moved===nothing && continue
        target,sign=moved
        row=destination.indices[target]
        for j in axes(vectors,2)
            raised[row,j]+=sign*vectors[column,j]
        end
    end
    # At M=0, S²=S−S+; this Gram matrix also resolves S in a degenerate
    # energy subspace without assuming the eigensolver picked spin eigenstates.
    transpose(raised)*raised
end

function audit_lowU_blue_reference()
    isempty(ARGS) || error("canonical low-U blue audit takes no arguments")
    Threads.nthreads()==2 || error("run with JULIA_NUM_THREADS=2")
    BLAS.set_num_threads(1)
    root=normpath(joinpath(@__DIR__,".."))
    output=joinpath(root,"results","prl_101_237004","fig2c","lowU_blue_reference_pilot")
    ispath(output) && error("audit output exists; preserve its provenance")
    sources=vcat("scripts/".*["audit_prl_101_237004_fig2c_lowU_blue_reference.jl",
        "prl_101_237004_vca_reference_audit.jl","prl_101_237004_cluster_green.jl",
        "prl_101_237004_ed.jl","prl_101_237004_restarted_lanczos.jl",
        "prl_101_237004_vca_geometry.jl","prl_101_237004_model.jl"],["src/noninteracting.jl"])
    filehash(path)=bytes2hex(sha256(read(path)))
    hashes=Dict(s=>filehash(joinpath(root,s)) for s in sources)
    p=G.Model.slater_koster_parameters(-.2)
    K=G.weiss_kinetics(G.rectangular_cluster(),0.;channel=:stripe_y,p)
    seconds=@elapsed audit=A.audit_reference_ground(K.up,K.down,.5,4,4;J=.125)
    A.write_reference_audit(audit,output;physical_metadata=Dict{String,Any}(
        "U"=>.5,"J"=>.125,"ratio"=>-.2,"h"=>0.,"cluster"=>"open 2x2 Fe",
        "original_PRL_t4"=>true,"hoppings"=>Dict(string(k)=>getproperty(p,k) for k in (:t1,:t2,:t3,:t4)),
        "Julia_threads"=>Threads.nthreads(),"BLAS_threads"=>BLAS.get_num_threads(),
        "all_sector_wall_seconds"=>seconds,"cache_used"=>false))
    sameN=filter(r->r.N==8,audit.rows)
    lowest=minimum(r.energy for r in sameN)
    tolerance=1e-9
    partners=filter(r->abs(r.energy-lowest)<=tolerance,sameN)
    open(joinpath(output,"same_N_spin_comparison.csv"),"w") do io
        println(io,"Nup,Ndown,Sz,energy,residual,energy_above_same_N_minimum,within_degeneracy_tolerance")
        for r in sameN
            println(io,join((r.Nup,r.Ndown,(r.Nup-r.Ndown)/2,r.energy,r.residual,
                r.energy-lowest,abs(r.energy-lowest)<=tolerance),','))
        end
    end
    println("All81 sectors: E0=",audit.target.energy,"; ground Sz partners=",[(r.Nup-r.Ndown)/2 for r in partners],
        "; mu interval=",audit.mu_interval);flush(stdout)
    H=A.C.spin_hamiltonian(K.up,K.down,.5,4,4;J=.125)
    roots=A.C.Lanczos.restarted_lowest(H;nev=4,krylovdim=96,keep=12,max_matvecs=1400,
        atol=1e-10,rtol=0.,seed=29,max_bytes=512*1024^2)
    roots.converged || error("four lowest Sz0 states did not converge")
    S2=spin_squared_matrix(H,roots.vectors)
    ground_indices=findall(e->abs(e-roots.values[1])<=tolerance,roots.values)
    ground_S2=eigvals(Symmetric(S2[ground_indices,ground_indices]))
    open(joinpath(output,"lowest_Sz0_states.csv"),"w") do io
        println(io,"root,energy,gap_from_ground,direct_residual,S_squared_expectation")
        for i in eachindex(roots.values)
            println(io,join((i,roots.values[i],roots.values[i]-roots.values[1],roots.residuals[i],S2[i,i]),','))
        end
    end
    open(joinpath(output,"S_squared_low_subspace.csv"),"w") do io
        for row in eachrow(S2)
            println(io,join(row,','))
        end
    end
    summary=Dict{String,Any}("created_utc"=>string(now(UTC)),"U"=>.5,"J"=>.125,"ratio"=>-.2,"h"=>0.,
        "target_E0"=>audit.target.energy,"target_residual"=>audit.target.residual,
        "maximum_sector_residual"=>maximum(r.residual for r in audit.rows),
        "all_N_mu_lower"=>audit.mu_interval[1],"all_N_mu_upper"=>audit.mu_interval[2],
        "degeneracy_tolerance"=>tolerance,"target_lowest_at_same_N"=>audit.target_lowest_at_same_N,
        "ground_Sz_sectors"=>[(r.Nup-r.Ndown)/2 for r in partners],
        "same_N_spin_multiplet_detected"=>length(partners)>1,
        "lowest_Sz0_energies"=>roots.values,"lowest_Sz0_residuals"=>roots.residuals,
        "number_of_ground_roots_among_four"=>length(ground_indices),
        "ground_subspace_S_squared_eigenvalues"=>ground_S2,
        "four_root_solver_matvecs"=>roots.matvecs,"four_root_solver_seed"=>29,
        "scope"=>"All81 numerical sector minima, plus four lowest Sz0 eigenpairs. S² is computed independently with the total-spin raising operator. If all four roots are degenerate, the ground multiplicity is only a lower bound. Residuals alone are not rigorous lowest-state certificates.",
        "source_sha256"=>hashes,
        "invocation"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig2c_lowU_blue_reference.jl")
    open(joinpath(output,"summary.toml"),"w") do io
        TOML.print(io,summary;sorted=true)
    end
    for source in sources
        target=joinpath(output,"source_snapshot",source)
        mkpath(dirname(target));cp(joinpath(root,source),target)
        filehash(target)==hashes[source] || error("source changed during audit")
    end
    println("Sz0 energies=",roots.values,"; ground S² eigenvalues=",ground_S2)
    println("saved ",output)
    return summary
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && audit_lowU_blue_reference()
