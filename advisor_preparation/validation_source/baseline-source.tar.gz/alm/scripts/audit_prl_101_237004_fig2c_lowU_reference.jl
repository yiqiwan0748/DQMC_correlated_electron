#!/usr/bin/env julia

using LinearAlgebra, SHA, TOML, Dates
include("prl_101_237004_vca_reference_audit.jl")
include("prl_101_237004_vca_geometry.jl")
const A=PRL101237004VCAReferenceAudit
const G=PRL101237004VCAGeometry

function audit_lowU_reference()
    isempty(ARGS) || error("canonical low-U audit takes no arguments")
    Threads.nthreads()==2 || error("run with JULIA_NUM_THREADS=2")
    BLAS.get_num_threads()==1 || error("run with OPENBLAS_NUM_THREADS=1")
    root=normpath(joinpath(@__DIR__,".."))
    output=joinpath(root,"results","prl_101_237004","fig2c","lowU_reference_pilot")
    ispath(output) && error("audit output exists; preserve its provenance")
    sources=vcat("scripts/".*["audit_prl_101_237004_fig2c_lowU_reference.jl",
        "prl_101_237004_vca_reference_audit.jl","prl_101_237004_cluster_green.jl",
        "prl_101_237004_ed.jl","prl_101_237004_restarted_lanczos.jl",
        "prl_101_237004_vca_geometry.jl","prl_101_237004_model.jl"],["src/noninteracting.jl"])
    filehash(path)=bytes2hex(sha256(read(path)))
    hashes=Dict(s=>filehash(joinpath(root,s)) for s in sources)
    c=G.rectangular_cluster(2,2)
    p=G.Model.slater_koster_parameters(-.5)
    K=G.weiss_kinetics(c,0.0;channel=:stripe_y,p)
    seconds=@elapsed audit=A.audit_reference_ground(K.up,K.down,.5,4,4;J=.125)
    A.write_reference_audit(audit,output;physical_metadata=Dict{String,Any}(
        "U"=>.5,"J"=>.125,"ratio"=>-.5,"h"=>0.,"cluster"=>"open 2x2 Fe",
        "original_PRL_t4"=>true,"sites"=>[collect(site) for site in c.sites],
        "hoppings"=>Dict(string(k)=>getproperty(p,k) for k in (:t1,:t2,:t3,:t4)),
        "Julia_threads"=>Threads.nthreads(),"BLAS_threads"=>BLAS.get_num_threads(),
        "wall_seconds"=>seconds,"cache_used"=>false))
    sameN=filter(r->r.N==8,audit.rows)
    minimum_energy=minimum(r.energy for r in sameN)
    tolerance=1e-9
    degenerate=filter(r->abs(r.energy-minimum_energy)<=tolerance,sameN)
    open(joinpath(output,"same_N_spin_comparison.csv"),"w") do io
        println(io,"Nup,Ndown,Sz,energy,residual,energy_above_same_N_minimum,within_degeneracy_tolerance")
        for r in sameN
            println(io,join((r.Nup,r.Ndown,(r.Nup-r.Ndown)/2,r.energy,r.residual,
                r.energy-minimum_energy,abs(r.energy-minimum_energy)<=tolerance),','))
        end
    end
    summary=Dict{String,Any}("created_utc"=>string(now(UTC)),
        "U"=>.5,"J"=>.125,"ratio"=>-.5,"h"=>0.,
        "target_E0"=>audit.target.energy,"target_residual"=>audit.target.residual,
        "maximum_sector_residual"=>maximum(r.residual for r in audit.rows),
        "target_lowest_at_same_N"=>audit.target_lowest_at_same_N,
        "all_N_mu_lower"=>audit.mu_interval[1],"all_N_mu_upper"=>audit.mu_interval[2],
        "degeneracy_tolerance"=>tolerance,
        "ground_Sz_sectors"=>[(r.Nup-r.Ndown)/2 for r in degenerate],
        "ground_particle_sectors"=>[[r.Nup,r.Ndown] for r in degenerate],
        "same_N_spin_multiplet_detected"=>length(degenerate)>1,
        "scope"=>"All81 fixed-spin sectors. Energy equality across different Sz sectors detects possible spin multiplets; absence does not exclude multiple singlets in Sz=0. Sector minima are numerical, not rigorous certificates.",
        "source_sha256"=>hashes,
        "invocation"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig2c_lowU_reference.jl")
    open(joinpath(output,"summary.toml"),"w") do io
        TOML.print(io,summary;sorted=true)
    end
    for source in sources
        target=joinpath(output,"source_snapshot",source)
        mkpath(dirname(target));cp(joinpath(root,source),target)
        filehash(target)==hashes[source] || error("source changed during audit")
    end
    println("E0=",audit.target.energy,"; maximum residual=",summary["maximum_sector_residual"])
    println("ground Sz sectors=",summary["ground_Sz_sectors"],"; all-N mu interval=",audit.mu_interval)
    println("same-N spin energy gaps=",[(r.Nup,r.Ndown,r.energy-minimum_energy) for r in sameN])
    println("saved ",output)
    return summary
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && audit_lowU_reference()
