#!/usr/bin/env julia
module PRL101237004Fig2COriginalFieldRefinement
using LinearAlgebra, Dates, TOML
include("run_prl_101_237004_fig2c_resolved.jl")
const Campaign=PRL101237004Fig2CResolvedCampaign
const Filling=Campaign.Filling
const R=Campaign.R
const V=R.V
const F=R.F
const POINTS=((-0.2,.75),(-0.2,1.),(-0.2,2.),(-0.5,2.),(-0.5,4.))
const SOURCES=unique(vcat(Campaign.SOURCES,["scripts/audit_prl_101_237004_fig2c_original_field_refinement.jl"]))
const DEFAULT_OUTPUT=joinpath(R.OUTPUT,"original_field_refinement")
const SUMMARY_HEADER="ratio,U,production_h,refined_h,h_change,production_moment_abs,refined_moment_abs,moment_abs_change,production_F,refined_F,F_change,refined_density,refined_mu_prime_gradient,refined_h_gradient,field_step,quadrature_order,block_steps,physical_L,field_difference_method,summary_path"

function write_toml(path,record)
    open(path,"w") do io;TOML.print(io,record;sorted=true);end
end

function refine_point(row,output,point_directory)
    U,r,h0,mu0,mup0=[parse(Float64,row[k]) for k in ("U","ratio","h","mu","mu_prime")]
    h0>5e-5 || error("local symmetric bracket requires nonzero h")
    step=5e-5
    derivative_atol=5e-7
    quadrature=F.imaginary_quadrature(48;breaks=Filling.FREQUENCY_BREAKS)
    reference(h)=R.reference_state(U,r,h;block_steps=48,output)
    lat=V.embedding(reference(h0);physical_L=48)
    centers=Tuple[];sides=Tuple[];history=Tuple[]
    cache=Dict{Float64,Any}()
    function at(h)
        get!(cache,Float64(h)) do
            state=reference(h)
            filling=Filling.solve_filling(state,lat;mu_initial=mu0,mu_prime_initial=mup0,
                order=48,quadrature_breaks=Filling.FREQUENCY_BREAKS,
                gradient_atol=2e-10,density_atol=2e-10)
            open(joinpath(point_directory,"filling_h"*string(reinterpret(UInt64,Float64(h));base=16)*".txt"),"w") do io
                show(io,"text/plain",filling)
            end
            filling.converged || error("center filling did not converge at h=$h")
            x=filling.choice.data
            x.occupation_policy==:integer_interval || error("smooth-point refinement encountered an ensemble at h=$h")
            max(abs(x.density-2),abs(x.mu_prime_gradient))<=2e-10 || error("center residual exceeds requested tolerance")
            push!(centers,(h,x.mu,x.mu_prime,x.omega,x.canonical_energy,x.density,x.mu_prime_gradient,
                x.moment,filling.functional_evaluations,relpath(state.cache,output),V.filehash(state.cache)))
            V.write_csv(joinpath(point_directory,"centers.csv"),
                "h,mu,mu_prime,Omega_per_Fe,F_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,filling_evaluations,reference_cache,reference_cache_sha256",centers)
            values=Float64[]
            for hs in (h-step,h+step)
                s=reference(hs)
                y=F.evaluate_functional(s.reference,lat,x.mu,x.mu_prime;quadrature)
                inertia=Filling.BaseFilling.occupation_inertia(s.reference,lat,x.mu_prime-x.mu,x.mu_prime)
                identity=y.mu_prime_gradient-(y.density-2)-inertia.offset
                push!(values,y.omega)
                push!(sides,(h,hs,x.mu,x.mu_prime,y.omega,y.density,y.mu_prime_gradient,y.moment,
                    inertia.mismatch,identity,relpath(s.cache,output),V.filehash(s.cache)))
                V.write_csv(joinpath(point_directory,"sides.csv"),
                    "center_h,side_h,held_mu,held_mu_prime,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,integer_mismatch,density_identity_error,reference_cache,reference_cache_sha256",sides)
                inertia.mismatch==0 || error("held-potential side changes occupation count at h=$hs")
                abs(identity)<=1e-8 || error("side frequency integral fails occupation identity at h=$hs")
            end
            gradient=(values[2]-values[1])/(2step)
            item=(;h=Float64(h),gradient,data=x)
            println(now()," r=",r," U=",U," h=",h," gradient=",gradient," m=",x.moment,
                " n-2=",x.density-2," g_muprime=",x.mu_prime_gradient)
            flush(stdout)
            item
        end
    end
    left,right=at(h0-step),at(h0+step)
    left.gradient<0<right.gradient || error("nearby negative-to-positive field derivative bracket not found")
    initial_bracket=(left.h,right.h)
    initial_gradients=(left.gradient,right.gradient)
    best=abs(left.gradient)<abs(right.gradient) ? left : right
    converged=false
    for iteration in 1:8
        width=right.h-left.h
        proposal=right.h-right.gradient*width/(right.gradient-left.gradient)
        if !isfinite(proposal) || !(left.h+.01width<proposal<right.h-.01width) || iteration%4==0
            proposal=(left.h+right.h)/2
        end
        item=at(proposal)
        abs(item.gradient)<abs(best.gradient) && (best=item)
        push!(history,(iteration,item.h,item.gradient,item.data.canonical_energy,item.data.moment,
            left.h,right.h,left.gradient,right.gradient))
        V.write_csv(joinpath(point_directory,"refinement_history.csv"),
            "iteration,h,gradient,F_per_Fe,moment_signed_muB_per_Fe,bracket_lower,bracket_upper,gradient_lower,gradient_upper",history)
        if item.gradient<0;left=item;else;right=item;end
        if abs(item.gradient)<=derivative_atol
            best=item;converged=true;break
        end
    end
    production_moment=parse(Float64,row["moment_abs_muB_per_Fe"])
    production_F=parse(Float64,row["F_per_Fe"])
    summary=Dict{String,Any}("completed_utc"=>string(now(UTC)),"converged"=>converged,
        "U"=>U,"J"=>U/4,"ratio"=>r,"physical_L"=>48,"quadrature_order"=>48,"block_steps"=>48,
        "quadrature_breaks"=>collect(Filling.FREQUENCY_BREAKS),"field_step"=>step,
        "derivative_atol"=>derivative_atol,"density_atol"=>2e-10,"mu_prime_gradient_atol"=>2e-10,
        "field_difference_method"=>"held_potential_Omega",
        "production_h"=>h0,"refined_h"=>best.h,"h_change"=>best.h-h0,
        "production_moment_abs"=>production_moment,"refined_moment_abs"=>abs(best.data.moment),
        "refined_moment_signed"=>best.data.moment,"moment_abs_change"=>abs(best.data.moment)-production_moment,
        "production_F"=>production_F,"refined_F"=>best.data.canonical_energy,
        "F_change"=>best.data.canonical_energy-production_F,
        "refined_gradient"=>best.gradient,"refined_mu"=>best.data.mu,"refined_mu_prime"=>best.data.mu_prime,
        "refined_density"=>best.data.density,"refined_mu_prime_gradient"=>best.data.mu_prime_gradient,
        "initial_sign_bracket"=>collect(initial_bracket),"initial_bracket_gradients"=>collect(initial_gradients),
        "final_sign_bracket"=>[left.h,right.h],"final_bracket_gradients"=>[left.gradient,right.gradient],
        "limits"=>"Local refinement on the original smooth branch. Every center re-solves density and reference-potential stationarity with expanded q48 integration; side Omega values hold both center potentials fixed. Centers must be integer intervals and sides must have zero mismatch. A negative-to-positive derivative bracket and a5e-7 residual at finite step5e-5 support a nearby minimum; this is not an exact-derivative, global-minimum, or thermodynamic-limit certificate. No figure targets enter the calculation.")
    write_toml(joinpath(point_directory,"summary.toml"),summary)
    converged || error("bounded field refinement exhausted eight iterations; diagnostics retained")
    files=sort(filter(n->isfile(joinpath(point_directory,n)),readdir(point_directory)))
    write_toml(joinpath(point_directory,"completed.toml"),Dict(
        "completed_utc"=>string(now(UTC)),"output_sha256"=>Dict(n=>V.filehash(joinpath(point_directory,n)) for n in files)))
    summary
end

function run(;input=R.OUTPUT,output=DEFAULT_OUTPUT)
    Threads.nthreads() in (1,2) || error("use one or two Julia threads")
    BLAS.set_num_threads(1)
    ispath(output) && error("audit output exists; preserve it and use a fresh output directory")
    hashes=Dict(s=>V.filehash(joinpath(R.ROOT,s)) for s in SOURCES)
    rows=Dict{String,String}[]
    input_hashes=Dict{String,String}()
    for (r,U) in POINTS
        folder=joinpath(input,"runs",Campaign.ratio_label(r),"U"*string(U))
        isfile(joinpath(folder,"source_snapshot","scripts","run_prl_101_237004_fig2c_resolved.jl")) &&
            error("this audit accepts only original smooth-point records")
        line=Campaign.validated_point(folder,U,r;physical_L=48,order=24,block_steps=48)
        push!(rows,Dict(zip(split(Campaign.HEADER,','),split(line,','))))
        for name in ("result.csv","provenance.txt","completed.txt","field_derivatives.csv")
            path=joinpath(folder,name)
            input_hashes[relpath(path,input)]=V.filehash(path)
        end
    end
    mkpath(output)
    for source in SOURCES
        destination=joinpath(output,"source_snapshot",source)
        mkpath(dirname(destination));cp(joinpath(R.ROOT,source),destination)
    end
    for path in keys(input_hashes)
        destination=joinpath(output,"inputs",path)
        mkpath(dirname(destination));cp(joinpath(input,path),destination)
    end
    copied=Dict{String,String}()
    for row in rows
        cache=row["reference_cache"]
        source=joinpath(input,cache);destination=joinpath(output,cache)
        mkpath(dirname(destination));cp(source,destination)
        copied[cache]=V.filehash(source)
    end
    write_toml(joinpath(output,"provenance.toml"),Dict(
        "started_utc"=>string(now(UTC)),"source_sha256"=>hashes,"input_sha256"=>input_hashes,
        "input_root"=>abspath(input),"copied_cache_sha256"=>copied,
        "julia_version"=>string(VERSION),"Julia_threads"=>Threads.nthreads(),"BLAS_threads"=>BLAS.get_num_threads(),
        "invocation"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig2c_original_field_refinement.jl",
        "method"=>"q48 expanded low-frequency partition, block48, physical L48. Refill every center; held-potential Omega sides at h±5e-5. Refine only production h±5e-5, eight iterations maximum. Retain failures; no production inputs are written."))
    results=Tuple[];failures=String[]
    for row in rows
        U=parse(Float64,row["U"]);r=parse(Float64,row["ratio"])
        label=Campaign.ratio_label(r)*"_U"*string(U)
        directory=joinpath(output,"points",label)
        mkpath(directory)
        try
            s=refine_point(row,output,directory)
            push!(results,(r,U,s["production_h"],s["refined_h"],s["h_change"],
                s["production_moment_abs"],s["refined_moment_abs"],s["moment_abs_change"],
                s["production_F"],s["refined_F"],s["F_change"],s["refined_density"],
                s["refined_mu_prime_gradient"],s["refined_gradient"],s["field_step"],48,48,48,
                s["field_difference_method"],relpath(joinpath(directory,"summary.toml"),output)))
            V.write_csv(joinpath(output,"refinement_summary.csv"),SUMMARY_HEADER,results)
        catch err
            push!(failures,label)
            write_toml(joinpath(directory,"failure.toml"),Dict("failed_utc"=>string(now(UTC)),
                "U"=>U,"ratio"=>r,"error"=>sprint(showerror,err,catch_backtrace())))
            println(stderr,"Failed ",label,": ",sprint(showerror,err));flush(stderr)
        end
    end
    all(V.filehash(joinpath(R.ROOT,s))==hash for (s,hash) in hashes) || error("source changed during audit")
    all(V.filehash(joinpath(input,p))==hash for (p,hash) in input_hashes) || error("production input changed during audit")
    if !isempty(failures)
        write_toml(joinpath(output,"failure.toml"),Dict("failed_points"=>failures,
            "completed_points"=>length(results),"source_and_input_hashes_unchanged"=>true))
        error("some point refinements failed; all diagnostics retained")
    end
    write_toml(joinpath(output,"completed.toml"),Dict("completed_utc"=>string(now(UTC)),
        "completed_points"=>length(results),"source_and_input_hashes_unchanged"=>true,
        "output_sha256"=>Dict(n=>V.filehash(joinpath(output,n)) for n in ("provenance.toml","refinement_summary.csv"))))
    output
end

function main(args=ARGS)
    output=DEFAULT_OUTPUT
    for arg in args
        if arg=="--help"
            println("Usage: julia --project=. scripts/audit_prl_101_237004_fig2c_original_field_refinement.jl [--output-dir=PATH]")
            return nothing
        end
        startswith(arg,"--output-dir=") || error("unknown argument: $arg")
        output=abspath(split(arg,'=';limit=2)[2])
    end
    run(;output)
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    println(PRL101237004Fig2COriginalFieldRefinement.main())
end
