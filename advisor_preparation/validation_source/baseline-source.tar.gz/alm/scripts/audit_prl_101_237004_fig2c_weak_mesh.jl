#!/usr/bin/env julia
# Independent finite-mesh sensitivity at the weak red U=.75 point. All field
# differences use the fully refilled canonical branch, including Fermi shells.
using LinearAlgebra, SHA, Dates, Printf
include("run_prl_101_237004_fig2c_resolved.jl")
const Campaign=PRL101237004Fig2CResolvedCampaign
const R=Campaign.R
const V=R.V
const F=R.F
const Filling=Campaign.Filling
const SUMMARY_HEADER="ratio,U,h,baseline_L,audit_L,quadrature_order,frequency_profile,field_derivative_policy,baseline_occupation_policy,L96_occupation_policy,fixed_variable_status,fixed_variable_moment_difference,fixed_variable_density_difference,fixed_variable_gradient_difference,filling_resolved,L96_mu,L96_mu_prime,L96_F,L96_density,L96_mu_prime_gradient,L96_moment_abs,refilled_moment_difference,L96_h_derivative_step2e4,L96_h_derivative_step1e4,L96_zero_curvature,L96_energy_gain,q48_q96_F_difference,q48_q96_moment_difference,nearby_status,nearby_h,nearby_moment_abs,nearby_h_derivative,complete_status,limits"
function read_csv_rows(path)
    lines=readlines(path);names=split(first(lines),',')
    [Dict(zip(names,split(line,','))) for line in lines[2:end]]
end
function weak_mesh_audit(;input=R.OUTPUT,output=joinpath(input,"weak_mesh_audit"))
    Threads.nthreads()<=2 || error("use one or two Julia threads")
    BLAS.get_num_threads()==1 || error("use OPENBLAS_NUM_THREADS=1")
    directory=joinpath(input,"runs","r_minus_0p5","U0.75")
    result_path=joinpath(directory,"result.csv")
    isfile(result_path) && isfile(joinpath(directory,"completed.txt")) || error("completed red U=.75 required")
    Campaign.validated_point(directory,.75,-.5)
    row=only(read_csv_rows(result_path))
    parse(Int,row["quadrature_order"])==48 || error("this audit requires the resolved production profile")
    ispath(output) && error("preserve existing audit output")
    h0=parse(Float64,row["h"]);mu0=parse(Float64,row["mu"]);mup0=parse(Float64,row["mu_prime"])
    sources=unique(vcat(Campaign.SOURCES,["scripts/audit_prl_101_237004_fig2c_weak_mesh.jl"]))
    hashes=Dict(s=>V.filehash(joinpath(R.ROOT,s)) for s in sources)
    input_hash=V.filehash(result_path)
    mkpath(output)
    for source in sources
        destination=joinpath(output,"source_snapshot",source)
        mkpath(dirname(destination));cp(joinpath(R.ROOT,source),destination)
    end
    cache_names=Set([row["reference_cache"]])
    for name in ("result.csv","centers.csv","field_sides.csv","field_derivatives.csv","provenance.txt","completed.txt")
        original=joinpath(directory,name);isfile(original) || continue
        destination=joinpath(output,"production_inputs",name);mkpath(dirname(destination));cp(original,destination)
        if name in ("centers.csv","field_sides.csv")
            foreach(x->push!(cache_names,x["reference_cache"]),read_csv_rows(original))
        end
    end
    cache_rows=Tuple[]
    for name in sort(collect(cache_names))
        source=joinpath(input,name);destination=joinpath(output,"reference_cache",basename(source))
        mkpath(dirname(destination));cp(source,destination)
        push!(cache_rows,(name,relpath(destination,output),V.filehash(source)))
    end
    V.write_csv(joinpath(output,"copied_reference_caches.csv"),"production_cache,audit_cache,sha256",cache_rows)
    provenance=joinpath(output,"provenance.txt")
    open(provenance,"w") do io
        println(io,"Started UTC ",now(UTC),"; Julia ",VERSION,"; threads ",Threads.nthreads(),"; BLAS ",BLAS.get_num_threads())
        println(io,"Command: OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig2c_weak_mesh.jl")
        println(io,"U=.75; J=.1875; ratio=-.5; stripe reference; block48. L96 is a convergence test distinct from the paper's L48 setting.")
        println(io,"Production SHA256 ",input_hash,"; all centers solve n2 and reference-mu stationarity to2e-8.")
        println(io,"Frequency order48 and low-frequency breaks ",Filling.FREQUENCY_BREAKS,"; selected center is independently re-solved at order96.")
        println(io,"All h derivatives use fully re-solved F=Omega+2mu sides. No direct zero-pole half-occupation evaluation is used for a recorded ensemble.")
        println(io,"Nearby estimate: at most two extra centers plus their sides. No global L96 minimum or rigorous thermodynamic error bound is claimed.")
        for source in sort(sources);println(io,hashes[source]," ",source);end
    end
    references=Dict{Float64,Any}();reference_rows=Tuple[]
    function reference(h)
        get!(references,Float64(h)) do
            local s=R.reference_state(.75,-.5,h;output,block_steps=48)
            push!(reference_rows,(h,s.result.E0,s.result.ground_residual,s.result.converged,
                maximum(ch.convergence_error for ch in s.result.channels),s.cache,V.filehash(s.cache)))
            V.write_csv(joinpath(output,"used_references.csv"),"h,E0,ground_residual,probe_flag,probe_error,reference_cache,sha256",reference_rows)
            s
        end
    end
    lattices=Dict(L=>V.embedding(reference(h0);physical_L=L) for L in (48,96))
    centers=Dict{Tuple{Int,Float64,Int},Any}();center_rows=Tuple[]
    function center(L,h;order=48,initial_mu=mu0,initial_mup=mup0)
        local key=(L,Float64(h),order)
        haskey(centers,key) && return centers[key]
        local s=reference(h)
        local seconds,solved
        seconds=@elapsed solved=Filling.solve_filling(s,lattices[L];mu_initial=initial_mu,
            mu_prime_initial=initial_mup,order,gradient_atol=2e-8,density_atol=2e-8)
        local logpath=joinpath(output,"filling_L$(L)_q$(order)_h"*string(reinterpret(UInt64,Float64(h));base=16)*".txt")
        open(logpath,"w") do io;show(io,MIME("text/plain"),solved);println(io);end
        solved.converged || error("mesh filling unresolved L=$L h=$h q=$order: $(solved.status)")
        local x=solved.choice.data
        centers[key]=x
        push!(center_rows,(L,h,order,x.mu,x.mu_prime,x.omega,x.canonical_energy,x.density,x.mu_prime_gradient,
            x.moment,x.occupation_policy,hasproperty(x,:shell_fraction) ? x.shell_fraction : NaN,
            solved.functional_evaluations,solved.occupation_evaluations,seconds))
        V.write_csv(joinpath(output,"centers.csv"),"physical_L,h,order,mu,mu_prime,Omega_per_Fe,F_per_Fe,density,mu_prime_gradient,moment_signed,occupation_policy,shell_fraction,functional_evaluations,occupation_evaluations,seconds",center_rows)
        @printf("%s L%d h=%.9f q%d F=%.12f m=%.9f n=%.11f gmu=%.3g %s\n",string(now()),L,h,order,x.canonical_energy,x.moment,x.density,x.mu_prime_gradient,string(x.occupation_policy));flush(stdout)
        x
    end
    derivative_rows=Tuple[]
    function derivative(L,h,x;step=2e-4,label="selected")
        local lower=center(L,h-step;initial_mu=x.mu,initial_mup=x.mu_prime)
        local upper=center(L,h+step;initial_mu=x.mu,initial_mup=x.mu_prime)
        local gradient=(upper.canonical_energy-lower.canonical_energy)/(2step)
        local curvature=(upper.canonical_energy-2x.canonical_energy+lower.canonical_energy)/step^2
        push!(derivative_rows,(label,L,h,step,48,lower.canonical_energy,x.canonical_energy,upper.canonical_energy,gradient,curvature))
        V.write_csv(joinpath(output,"field_derivatives.csv"),"label,physical_L,h,step,order,F_minus,F_center,F_plus,h_derivative,canonical_curvature",derivative_rows)
        @printf("%s derivative %s L%d h=%.9f step=%.1g g=%+.6g curvature=%+.6g\n",string(now()),label,L,h,step,gradient,curvature);flush(stdout)
        (;gradient,curvature)
    end
    baseline=center(48,h0)
    abs(baseline.canonical_energy-parse(Float64,row["F_per_Fe"]))<2e-9 || error("production F did not reproduce")
    abs(abs(baseline.moment)-parse(Float64,row["moment_abs_muB_per_Fe"]))<2e-6 || error("production moment did not reproduce")
    # Holding both potentials at a degenerate shell does not specify its
    # occupation policy on a new mesh. Report that comparison as undefined,
    # and use the explicitly re-solved canonical branch for the physical test.
    fixed_status="not_evaluated_degenerate_occupation_policy"
    fixed_m=fixed_n=fixed_g=NaN
    fixed_inertia=Filling.BaseFilling.occupation_inertia(reference(h0).reference,lattices[96],
        baseline.mu_prime-baseline.mu,baseline.mu_prime)
    if baseline.occupation_policy==:integer_interval && fixed_inertia.minimum_reduced_eigenvalue>1e-8
        fixed=F.evaluate_functional(reference(h0).reference,lattices[96],baseline.mu,baseline.mu_prime;
            quadrature=F.imaginary_quadrature(48;breaks=Filling.FREQUENCY_BREAKS))
        abs(fixed.mu_prime_gradient-(fixed.density-2)-fixed_inertia.offset)<=1e-8 ||
            error("fixed-potential L96 quadrature identity unresolved")
        fixed_status="integer_policy_fixed_potentials"
        fixed_m=abs(fixed.moment)-abs(baseline.moment)
        fixed_n=fixed.density-baseline.density;fixed_g=fixed.mu_prime_gradient-baseline.mu_prime_gradient
        open(joinpath(output,"fixed_variable_evaluation.txt"),"w") do io;show(io,MIME("text/plain"),fixed);println(io);end
    end
    open(joinpath(output,"fixed_variable_inertia.txt"),"w") do io;show(io,MIME("text/plain"),fixed_inertia);println(io);end
    larger=center(96,h0;initial_mu=baseline.mu,initial_mup=baseline.mu_prime)
    larger96=center(96,h0;order=96,initial_mu=larger.mu,initial_mup=larger.mu_prime)
    coarse=derivative(96,h0,larger;step=2e-4)
    fine=derivative(96,h0,larger;step=1e-4,label="step_check")
    zero=center(96,0.;initial_mu=larger.mu,initial_mup=larger.mu_prime)
    zero_derivative=derivative(96,0.,zero;step=2e-4,label="zero")
    moment_change=abs(larger.moment)-abs(baseline.moment)
    nearby_status=:not_triggered;nearby_h=h0;nearby_m=abs(larger.moment);nearby_g=fine.gradient
    extra_rows=Tuple[]
    if h0>0 && (abs(fine.gradient)>5e-6 || abs(moment_change)>.001)
        nearby_status=:local_estimate_only
        separation=max(5e-4,.1h0)
        trial_h=max(0.,h0-sign(fine.gradient)*separation)
        trial_h==h0 && (trial_h=h0+separation)
        trial=center(96,trial_h;initial_mu=larger.mu,initial_mup=larger.mu_prime)
        trial_g=derivative(96,trial_h,trial;step=1e-4,label="nearby_trial")
        slope=(trial_g.gradient-fine.gradient)/(trial_h-h0)
        push!(extra_rows,(trial_h,trial.mu,trial.mu_prime,trial.canonical_energy,trial.moment,trial_g.gradient,slope,"trial"))
        nearby_h=trial_h;nearby_m=abs(trial.moment);nearby_g=trial_g.gradient
        if isfinite(slope) && slope>0
            estimate=trial_h-trial_g.gradient/slope
            if 0<estimate<max(h0,trial_h)+2separation && abs(estimate-trial_h)>1e-8
                refined=center(96,estimate;initial_mu=trial.mu,initial_mup=trial.mu_prime)
                refined_g=derivative(96,estimate,refined;step=1e-4,label="nearby_secant")
                push!(extra_rows,(estimate,refined.mu,refined.mu_prime,refined.canonical_energy,refined.moment,refined_g.gradient,slope,"secant"))
                nearby_h=estimate;nearby_m=abs(refined.moment);nearby_g=refined_g.gradient
                abs(nearby_g)<=5e-6 && (nearby_status=:nearby_stationarity_resolved)
            else
                nearby_status=:root_estimate_outside_local_window
            end
        else
            nearby_status=:nonpositive_local_curvature
        end
    end
    V.write_csv(joinpath(output,"nearby_stationarity.csv"),"h,mu,mu_prime,F_per_Fe,moment_signed,h_derivative,envelope_curvature_estimate,role",extra_rows)
    limits="Bounded local mesh comparison; no global L96 minimum or thermodynamic error bound; an ensemble fixed-potential comparison is undefined without transporting its occupation policy"
    summary=(-.5,.75,h0,48,96,48,"refined_low_frequency","refilled_canonical_F",baseline.occupation_policy,
        larger.occupation_policy,fixed_status,fixed_m,fixed_n,fixed_g,true,larger.mu,larger.mu_prime,larger.canonical_energy,
        larger.density,larger.mu_prime_gradient,abs(larger.moment),moment_change,coarse.gradient,fine.gradient,
        zero_derivative.curvature,zero.canonical_energy-larger.canonical_energy,
        larger96.canonical_energy-larger.canonical_energy,abs(larger96.moment)-abs(larger.moment),
        nearby_status,nearby_h,nearby_m,nearby_g,"complete",limits)
    V.write_csv(joinpath(output,"weak_mesh_summary.csv"),SUMMARY_HEADER,[summary])
    open(joinpath(output,"summary.txt"),"w") do io
        println(io,"Production h=",h0," classification=",row["stationarity_status"])
        println(io,"Baseline L48=",baseline,"\nRefilled L96=",larger,"\nRefilled L96 q96=",larger96)
        println(io,"Fixed-potential status=",fixed_status,"; changes |m|/n/g=",(fixed_m,fixed_n,fixed_g))
        println(io,"At fixed h after refilling: moment change=",moment_change,"; F change=",larger.canonical_energy-baseline.canonical_energy)
        println(io,"L96 h derivatives=",(coarse,fine),"; zero-field derivative/curvature=",zero_derivative)
        println(io,"L96 gain versus zero=",zero.canonical_energy-larger.canonical_energy,"; nearby=",(nearby_status,nearby_h,nearby_m,nearby_g))
        println(io,limits)
    end
    all(V.filehash(joinpath(R.ROOT,s))==hashes[s] for s in sources) || error("sources changed during audit")
    V.filehash(result_path)==input_hash || error("production input changed during audit")
    open(provenance,"a") do io;println(io,"Completed UTC ",now(UTC),"; hashes verified unchanged.");end
    open(joinpath(output,"completed.txt"),"w") do io
        println(io,"Completed ",now(),"; nearby status: ",nearby_status)
        for name in ("provenance.txt","weak_mesh_summary.csv","summary.txt","centers.csv","field_derivatives.csv","nearby_stationarity.csv","used_references.csv","copied_reference_caches.csv")
            println(io,V.filehash(joinpath(output,name))," ",name)
        end
    end
    output
end
if abspath(PROGRAM_FILE)==(@__FILE__)
    println(weak_mesh_audit())
end
