#!/usr/bin/env julia
module PRL101237004Fig3Audit

using LinearAlgebra, SHA, Dates, Printf
include("prl_101_237004_fig3_campaign.jl")
const D=PRL101237004Fig3Campaign
const R=D.R
const S=D.S
const BREAKS=(0.,1e-11,1e-9,1e-7,1e-5,.001,.01,.1,1.,10.,100.)
const SOURCES=unique(vcat(D.SOURCES,["scripts/audit_prl_101_237004_fig3.jl"]))

function csv(path,rows)
    isempty(rows) && error("cannot write an empty audit table")
    names=propertynames(first(rows))
    mkpath(dirname(path))
    open(path*".partial","w") do io
        println(io,join(string.(names),','))
        for row in rows
            propertynames(row)==names || error("inconsistent audit columns")
            values=string.(getproperty.(Ref(row),names))
            all(!occursin(',',x) && !occursin('\n',x) for x in values) || error("non-scalar CSV value")
            println(io,join(values,','))
        end
    end
    mv(path*".partial",path;force=true)
end
trapz(x,y)=sum((x[i+1]-x[i])*(y[i+1]+y[i])/2 for i in 1:length(x)-1)
function progress(message)
    println(now(UTC)," ",message);flush(stdout)
end

"""Independent auxiliary-pole representation of the CPT resolvent.
For G′=Q(z+μ′−Λ)⁻¹Q† and V=t−t′+(μ′−μ)I,
G=Q[z−(Λ−μ′+Q†VQ)]⁻¹Q†. This does not use S's embedding code.
"""
function auxiliary(data,k,spin)
    p=data.problem
    if data.state===nothing
        diagonal=eigen(Symmetric(p.reference.kinetics[spin]))
        poles,Q=diagonal.values,diagonal.vectors
    else
        expansion=R.C.spectral_data(data.state.result;spin=spin==1 ? :up : :down)
        poles,Q=expansion.poles,expansion.weights
    end
    q=S.reduced_momentum(p.cluster,k...)
    V=S.G.lattice_kinetic(p.cluster,q...,p.parameters)-p.reference.kinetics[spin]+(p.mu_prime-p.mu)*I
    H=Matrix{ComplexF64}(Q'*V*Q)
    for i in eachindex(poles);H[i,i]+=poles[i]-p.mu_prime;end
    eigenpairs=eigen(Hermitian(H))
    amplitudes=Q*eigenpairs.vectors
    # Build the Fourier projector independently of S.periodization_matrix.
    W=zeros(ComplexF64,size(Q,1),2)
    for (i,(x,y)) in enumerate(p.cluster.sites),a in 1:2
        W[2i-2+a,a]=cis(k[1]*x+k[2]*y)/sqrt(p.reference.nsites)
    end
    projected=W'*amplitudes
    (;poles=eigenpairs.values,amplitudes,projected,
      weights=vec(sum(abs2,projected;dims=1)),zeroth=Q*Q')
end
pole_green(amplitudes,poles,z)=(amplitudes.*reshape(inv.(z.-poles),1,:))*amplitudes'
lorentzian(poles,weights,omega,eta)=[sum(weights.*(eta/pi)./((w.-poles).^2 .+eta^2)) for w in omega]
window_weight(poles,weights,a,b,eta)=sum(weights.*(atan.((b.-poles)./eta).-atan.((a.-poles)./eta)))/pi

function selected_pole_audit(data,output;eta=.05)
    rows=NamedTuple[]
    for k in ((.37,.19),(pi,0.)),spin in 1:2
        poles=auxiliary(data,k,spin)
        direct_error=0.;projected_error=0.;minimum_causal=Inf;fold_error=0.
        for omega in (-1.1,-.5,0.,.7,1.3)
            z=complex(omega,eta)
            embedded=S.embedded_green(data.problem,k...,z;spin)
            projected=S.periodized_green(data.problem,k...,z;spin)
            direct_error=max(direct_error,norm(embedded-pole_green(poles.amplitudes,poles.poles,z)))
            projected_error=max(projected_error,norm(projected-pole_green(poles.projected,poles.poles,z)))
            minimum_causal=min(minimum_causal,minimum(eigvals(Hermitian((embedded'-embedded)/(2im*pi)))),
                minimum(eigvals(Hermitian((projected'-projected)/(2im*pi)))))
            # The four unfolded physical momenta must recover the supercell
            # trace/Nc even in a stripe state without primitive translation.
            folded=sum(tr(S.periodized_green(data.problem,k[1]+pi*ix,k[2]+pi*iy,z;spin))
                for ix in 0:1,iy in 0:1)/4
            fold_error=max(fold_error,abs(folded-tr(embedded)/data.problem.reference.nsites))
        end
        coarse=collect(-3.:.01:3.);fine=collect(-3.:.005:3.)
        exact=window_weight(poles.poles,poles.weights,-3.,3.,eta)
        icoarse=trapz(coarse,lorentzian(poles.poles,poles.weights,coarse,eta))
        ifine=trapz(fine,lorentzian(poles.poles,poles.weights,fine,eta))
        high_frequency=real(1e5im*tr(S.periodized_green(data.problem,k...,1e5im;spin)))
        row=(case=data.case.name,kx=k[1],ky=k[2],spin,auxiliary_dimension=length(poles.poles),
            zeroth_matrix_error=norm(poles.zeroth-I),weight_per_spin=sum(poles.weights),
            high_frequency_weight=high_frequency,direct_green_error=direct_error,
            projected_green_error=projected_error,minimum_causal_eigenvalue=minimum_causal,
            folded_trace_error=fold_error,window_exact=exact,window_dx01=icoarse,
            window_dx005=ifine,window_dx005_error=ifine-exact,
            omitted_lorentzian_weight=sum(poles.weights)-exact)
        push!(rows,row)
        direct_error<2e-7 && projected_error<1e-7 || error("auxiliary-pole Green identity failed")
        abs(sum(poles.weights)-2)<2e-9 && norm(poles.zeroth-I)<2e-9 || error("spectral weight sum rule failed")
        minimum_causal>=-2e-10 && fold_error<2e-9 || error("causality or unfolding sum rule failed")
        csv(joinpath(output,"selected_poles.csv"),rows)
        progress("$(data.case.name) auxiliary poles k=$k spin=$spin checked")
    end
    rows
end

"""Zero-broadening density from the independent identity
n=D/(2Nc)+(πNcNk)⁻¹∫₀∞ Re Tr G(iω)dω.
The implementation explicitly inverts G′ then solves the Dyson matrix,
independent of S's G′(I−VG′)⁻¹ implementation. Expanded Gauss quadrature
includes the infinite tail. A common shift holds V and pole residues fixed.
"""
function imaginary_density(problem;physical_L=48,order=48,common_shift=0.)
    c=problem.cluster;nc=problem.reference.nsites;n=2nc
    points=S.G.reduced_momentum_grid(c,physical_L)
    potentials=ntuple(spin->[S.G.lattice_kinetic(c,k...,problem.parameters)-
        problem.reference.kinetics[spin]+(problem.mu_prime-problem.mu)*I for k in points],2)
    quadrature=R.F.imaginary_quadrature(order;breaks=BREAKS)
    contributions=zeros(length(quadrature.nodes))
    Threads.@threads :static for index in eachindex(quadrature.nodes)
        total=0.
        for spin in 1:2
            raw=problem.reference.green(problem.mu_prime+common_shift+im*quadrature.nodes[index],spin)
            G=raw isa Tuple ? first(raw) : raw
            inverse=inv(G)
            for V in potentials[spin]
                total+=real(tr(inv(inverse-V)))
            end
        end
        contributions[index]=quadrature.weights[index]*total
    end
    n/nc+sum(contributions)/(pi*nc*length(points))
end

function density_audit(data,output)
    rows=NamedTuple[]
    if data.case.U==0
        energies=Float64[]
        for k in S.G.reduced_momentum_grid(data.problem.cluster,48)
            append!(energies,eigvals(Hermitian(S.G.lattice_kinetic(data.problem.cluster,k...,data.problem.parameters))))
        end
        below=count(e->e<data.problem.mu-1e-10,energies)
        equal=count(e->abs(e-data.problem.mu)<=1e-10,energies)
        density=2(below+equal/2)/(48^2)
        push!(rows,(case=data.case.name,method="analytic_bare_poles",order=0,common_shift=0.,
            density,canonical_density=density,target_error=density-2.,occupation_policy="half_weight_at_exact_mu"))
    elseif data.case.name=="blue_U0p5"
        # Exact saved final policy is f=1/2. Symmetric side limits realize that
        # policy without numerically resolving an exactly zero-frequency pole.
        for delta in (1e-6,5e-7)
            lower=imaginary_density(data.problem;common_shift=-delta)
            upper=imaginary_density(data.problem;common_shift=delta)
            average=(lower+upper)/2
            for (shift,density) in ((-delta,lower),(delta,upper))
                push!(rows,(case=data.case.name,method="imaginary_axis_side_limit",order=48,common_shift=shift,
                    density,canonical_density=average,target_error=average-2.,occupation_policy="saved_f_half_shell"))
            end
        end
    else
        for order in (48,96)
            density=imaginary_density(data.problem;order)
            push!(rows,(case=data.case.name,method="imaginary_axis_integer_interval",order,common_shift=0.,
                density,canonical_density=density,target_error=density-2.,occupation_policy="saved_integer_interval"))
        end
    end
    maximum(abs(row.target_error) for row in rows)<2e-7 || error("independent zero-broadening density check failed")
    csv(joinpath(output,"density.csv"),rows)
    rows
end

function spectrum_audit(data,output;eta=.05)
    p=data.problem
    omega=collect(-3.:.005:3.)
    selected=1:5:length(omega);sample=omega[selected]
    plan48=S.spectral_plan(p,S.G.reduced_momentum_grid(p.cluster,48))
    plan96=S.spectral_plan(p,S.G.reduced_momentum_grid(p.cluster,96))
    base=S.dos_spectrum(plan48,omega;eta).total
    progress("$(data.case.name) L48 DOS dx=.005 complete")
    mesh=S.dos_spectrum(plan96,sample;eta).total
    progress("$(data.case.name) L96 DOS mesh comparison complete")
    path=D.paper_path(16).points
    pathomega=collect(-2.:.05:2.)
    basepath=S.spectral_grid(S.spectral_plan(p,path),pathomega;eta).total
    depthdos=copy(base[selected]);depthpath=copy(basepath);greenerror=0.
    if data.state!==nothing
        deep=R.reference_state(data.case.U,data.case.ratio,data.meta["h"];block_steps=96,output=dirname(output))
        deep_problem=S.SpectralProblem(deep.reference,deep.cluster,deep.parameters;mu=p.mu,mu_prime=p.mu_prime)
        depthdos=S.dos_spectrum(S.spectral_plan(deep_problem,S.G.reduced_momentum_grid(deep_problem.cluster,48)),sample;eta).total
        depthpath=S.spectral_grid(S.spectral_plan(deep_problem,path),pathomega;eta).total
        for w in range(-3.,3.;length=61),spin in 1:2
            shallow=first(p.reference.green(complex(w+p.mu_prime,eta),spin))
            deeper=first(deep.reference.green(complex(w+p.mu_prime,eta),spin))
            greenerror=max(greenerror,norm(shallow-deeper))
        end
        D.write_toml(joinpath(output,"depth96_reference.toml"),Dict("cache"=>relpath(deep.cache,dirname(output)),
            "sha256"=>D.filehash(deep.cache),"ground_residual"=>deep.result.ground_residual,
            "canonical_E0"=>deep.result.E0,"block_steps"=>96))
        progress("$(data.case.name) block48/96 comparison complete")
    end
    csv(joinpath(output,"dos_comparison.csv"),[(case=data.case.name,omega=w,L48_block48=base[index],
        L96_block48=mesh[j],L48_block96=depthdos[j]) for (j,(index,w)) in enumerate(zip(selected,sample))])
    csv(joinpath(output,"dos_fine.csv"),[(omega=w,dos=base[i]) for (i,w) in enumerate(omega)])
    coarse_integral=trapz(omega[1:2:end],base[1:2:end]);fine_integral=trapz(omega,base)
    # Finite eta has nonzero Lorentzian tails; this finite plotted window is
    # intentionally not called the total-weight or half-filling estimator.
    differences=mesh-base[selected];depthdifference=depthdos-base[selected]
    row=(case=data.case.name,eta,omega_min=first(omega),omega_max=last(omega),omega_step=.005,
        L48_window_weight=fine_integral,window_dx01_dx005_difference=fine_integral-coarse_integral,
        omitted_window_weight_from_exact_sumrule=4-fine_integral,
        mesh_L48_L96_max_abs=maximum(abs,differences),mesh_L48_L96_rms=sqrt(sum(abs2,differences)/length(differences)),
        mesh_L48_L96_integrated_absolute=trapz(sample,abs.(differences)),
        block48_96_DOS_max_abs=maximum(abs,depthdifference),
        block48_96_DOS_integrated_absolute=trapz(sample,abs.(depthdifference)),
        block48_96_path_max_abs=maximum(abs,depthpath-basepath),
        block48_96_cluster_G_max_norm=greenerror,
        minimum_DOS=minimum(base),minimum_path_intensity=minimum(basepath),
        normalization_states_per_Fe=4.,status="complete")
    minimum(base)>-1e-10 && minimum(basepath)>-1e-10 || error("negative spectral intensity")
    csv(joinpath(output,"spectrum_summary.csv"),[row])
    row
end

function audit(;output=joinpath(D.OUTPUT,"numerical_audit"),cases=D.CASES)
    Threads.nthreads()<=2 || error("bounded audit requires one or two Julia threads")
    BLAS.get_num_threads()==1 || error("use OPENBLAS_NUM_THREADS=1")
    isfile(joinpath(output,"completed.txt")) && error("preserve completed audit output")
    hashes=D.snapshot(output,SOURCES)
    D.write_toml(joinpath(output,"provenance.toml"),Dict("started_utc"=>string(now(UTC)),
        "julia"=>string(VERSION),"julia_threads"=>Threads.nthreads(),"blas_threads"=>BLAS.get_num_threads(),
        "command"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig3.jl",
        "source_sha256"=>hashes,"eta"=>.05,"frequency_breaks"=>collect(BREAKS),
        "limits"=>"Fixed saved stationary references; L96 is a mesh check with unchanged mu and mu_prime; eta remains .05; no refitting or new variational optimization; finite-window DOS area excludes Lorentzian tails; selected-k residue checks certify exact total weight."))
    summaries=NamedTuple[]
    for case in cases
        directory=joinpath(output,case.name)
        ispath(directory) && error("preserve existing case audit $directory")
        mkpath(directory)
        data=D.load_case(case;output)
        D.write_toml(joinpath(directory,"input.toml"),data.meta)
        progress("starting independent Fig3 audit $(case.name)")
        poles=selected_pole_audit(data,directory)
        density=density_audit(data,directory)
        progress("$(case.name) zero-broadening density checked")
        summary=spectrum_audit(data,directory)
        push!(summaries,merge(summary,(density_max_target_error=maximum(abs(row.target_error) for row in density),
            residue_max_weight_error=maximum(abs(row.weight_per_spin-2) for row in poles),
            causal_minimum=minimum(row.minimum_causal_eigenvalue for row in poles))))
        csv(joinpath(output,"audit_summary.csv"),summaries)
        D.guard(hashes)
        open(joinpath(directory,"completed.txt"),"w") do io
            println(io,"Completed UTC ",now(UTC))
            for name in ("selected_poles.csv","density.csv","spectrum_summary.csv","dos_comparison.csv","dos_fine.csv","input.toml")
                println(io,D.filehash(joinpath(directory,name))," ",name)
            end
        end
    end
    D.guard(hashes)
    open(joinpath(output,"completed.txt"),"w") do io
        println(io,"Completed UTC ",now(UTC),"; cases ",join(getproperty.(cases,:name),','))
        for name in ("audit_summary.csv","provenance.toml")
            println(io,D.filehash(joinpath(output,name))," ",name)
        end
    end
    output
end

end
if abspath(PROGRAM_FILE)==(@__FILE__)
    println(PRL101237004Fig3Audit.audit())
end
