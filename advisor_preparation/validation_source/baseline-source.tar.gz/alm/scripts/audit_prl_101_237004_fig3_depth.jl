#!/usr/bin/env julia
module PRL101237004Fig3DepthAudit
using LinearAlgebra, Dates, Printf
include("audit_prl_101_237004_fig3.jl")
const A=PRL101237004Fig3Audit
const D=A.D
const R=D.R
const S=D.S
const SOURCES=unique(vcat(A.SOURCES,["scripts/audit_prl_101_237004_fig3_depth.jl"]))

function differences(a,b)
    d=b-a
    (;max_abs=maximum(abs,d),rms=sqrt(sum(abs2,d)/length(d)),
      relative_l2=sqrt(sum(abs2,d)/sum(abs2,b)),
      max_abs_over_peak=maximum(abs,d)/maximum(abs,b),
      baseline_peak=maximum(a),refined_peak=maximum(b))
end
function audit(;output=joinpath(D.OUTPUT,"depth_refinement_audit"),
        original=joinpath(D.OUTPUT,"numerical_audit"),cases=filter(c->c.U>0,D.CASES))
    Threads.nthreads()<=2 && BLAS.get_num_threads()==1 || error("use Julia threads2 and BLAS1")
    ispath(output) && error("preserve existing depth-refinement audit")
    isfile(joinpath(original,"completed.txt")) || error("original audit must be complete")
    hashes=D.snapshot(output,SOURCES)
    D.write_toml(joinpath(output,"provenance.toml"),Dict("started_utc"=>string(now(UTC)),
        "julia"=>string(VERSION),"julia_threads"=>Threads.nthreads(),"blas_threads"=>BLAS.get_num_threads(),
        "source_sha256"=>hashes,"command"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig3_depth.jl",
        "eta"=>.05,"original_audit_completion_sha256"=>D.filehash(joinpath(original,"completed.txt")),
        "limits"=>"Saved h mu and mu_prime held fixed; 96 versus192 Green blocks; no variational refitting; real-axis checks at eta=.05; finite selected meshes provide numerical evidence rather than a rigorous uniform error bound."))
    summaries=NamedTuple[]
    for case in cases
        folder=joinpath(output,case.name);mkpath(folder)
        saved=D.load_case(case;output)
        h,mu,mup=saved.meta["h"],saved.meta["mu"],saved.meta["mu_prime"]
        oldmeta=D.TOML.parsefile(joinpath(original,case.name,"depth96_reference.toml"))
        oldcache=joinpath(original,oldmeta["cache"])
        D.filehash(oldcache)==oldmeta["sha256"] || error("original depth96 cache changed")
        D.copy_identical(oldcache,joinpath(output,"reference_cache",basename(oldcache)))
        baseline=R.reference_state(case.U,case.ratio,h;block_steps=96,output)
        A.progress("$(case.name) building block192 reference")
        seconds=@elapsed refined=R.reference_state(case.U,case.ratio,h;block_steps=192,output)
        A.progress("$(case.name) block192 reference built in $(round(seconds;digits=2))s")
        p96=S.SpectralProblem(baseline.reference,baseline.cluster,baseline.parameters;mu,mu_prime=mup)
        p192=S.SpectralProblem(refined.reference,refined.cluster,refined.parameters;mu,mu_prime=mup)
        q=S.G.reduced_momentum_grid(p96.cluster,48)
        omega=collect(-3.:.025:3.)
        dos96=S.dos_spectrum(S.spectral_plan(p96,q),omega;eta=.05).total
        dos192=S.dos_spectrum(S.spectral_plan(p192,q),omega;eta=.05).total
        dd=differences(dos96,dos192)
        A.csv(joinpath(folder,"dos.csv"),[(omega=w,block96=dos96[i],block192=dos192[i],difference=dos192[i]-dos96[i]) for (i,w) in enumerate(omega)])
        lo,hi=case.name=="blue_U0p5" ? (-2.5,2.5) : case.name=="red_U1" ? (-1.8,3.2) : (-3.,3.)
        pathomega=collect(lo:.025:hi)
        path=D.paper_path(48)
        path96=S.spectral_grid(S.spectral_plan(p96,path.points),pathomega;eta=.05).total
        path192=S.spectral_grid(S.spectral_plan(p192,path.points),pathomega;eta=.05).total
        pd=differences(path96,path192)
        index=argmax(abs.(path192-path96))
        A.csv(joinpath(folder,"path_largest_difference.csv"),[(omega=pathomega[index[1]],
            path_coordinate=path.coordinate[index[2]],kx=path.points[index[2]][1],ky=path.points[index[2]][2],
            block96=path96[index],block192=path192[index],difference=path192[index]-path96[index])])
        fsmax=fsrms=fsrel=fspeak=0.
        if case.name=="blue_U0p5"
            axis=collect(range(-pi,pi;length=97))[1:end-1]
            points=[(kx,ky) for ky in axis for kx in axis]
            fs96=S.spectral_grid(S.spectral_plan(p96,points),[0.];eta=.05).total
            fs192=S.spectral_grid(S.spectral_plan(p192,points),[0.];eta=.05).total
            fd=differences(fs96,fs192)
            fsmax,fsrms,fsrel,fspeak=fd.max_abs,fd.rms,fd.relative_l2,fd.max_abs_over_peak
            A.csv(joinpath(folder,"fermi_surface.csv"),[(kx=k[1],ky=k[2],block96=fs96[i],block192=fs192[i]) for (i,k) in enumerate(points)])
        end
        greenmax=greenrelative=0.;moment0=0.
        for spin in 1:2
            M0=R.C.spectral_moments(refined.result;spin=spin==1 ? :up : :down).zeroth
            moment0=max(moment0,norm(M0-I))
            for w in range(-3.,3.;length=121)
                g96=first(baseline.reference.green(complex(w+mup,.05),spin))
                g192=first(refined.reference.green(complex(w+mup,.05),spin))
                greenmax=max(greenmax,norm(g192-g96))
                greenrelative=max(greenrelative,norm(g192-g96)/norm(g192))
            end
        end
        row=(case=case.name,U=case.U,ratio=case.ratio,h,mu,mu_prime=mup,eta=.05,
            baseline_blocks=96,refined_blocks=192,reference_seconds=seconds,
            dos_max_abs=dd.max_abs,dos_rms=dd.rms,dos_relative_l2=dd.relative_l2,
            dos_max_abs_over_peak=dd.max_abs_over_peak,dos_refined_peak=dd.refined_peak,
            dos_integrated_absolute=A.trapz(omega,abs.(dos192-dos96)),
            path_omega_min=lo,path_omega_max=hi,path_omega_step=.025,path_k_points=length(path.points),
            path_max_abs=pd.max_abs,path_rms=pd.rms,path_relative_l2=pd.relative_l2,
            path_max_abs_over_peak=pd.max_abs_over_peak,path_refined_peak=pd.refined_peak,
            fs_max_abs=fsmax,fs_rms=fsrms,fs_relative_l2=fsrel,fs_max_abs_over_peak=fspeak,
            cluster_G_max_norm=greenmax,cluster_G_max_relative_norm=greenrelative,
            zeroth_moment_matrix_error=moment0,ground_energy_difference=refined.result.E0-baseline.result.E0,
            status="complete")
        push!(summaries,row)
        A.csv(joinpath(output,"depth_summary.csv"),summaries)
        D.write_toml(joinpath(folder,"references.toml"),Dict("case"=>case.name,
            "block96_cache"=>relpath(baseline.cache,output),"block192_cache"=>relpath(refined.cache,output),
            "block96_sha256"=>D.filehash(baseline.cache),"block192_sha256"=>D.filehash(refined.cache),
            "ground_residual96"=>baseline.result.ground_residual,"ground_residual192"=>refined.result.ground_residual))
        D.guard(hashes)
        A.progress("$(case.name) 96→192 path max=$(pd.max_abs) relative-L2=$(pd.relative_l2); DOS max=$(dd.max_abs)")
    end
    D.guard(hashes)
    open(joinpath(output,"completed.txt"),"w") do io
        println(io,"Completed UTC ",now(UTC))
        for name in ("provenance.toml","depth_summary.csv")
            println(io,D.filehash(joinpath(output,name))," ",name)
        end
        for case in cases,name in ("references.toml","dos.csv","path_largest_difference.csv")
            path=joinpath(case.name,name);println(io,D.filehash(joinpath(output,path))," ",path)
        end
    end
    output
end
end
if abspath(PROGRAM_FILE)==(@__FILE__)
    println(PRL101237004Fig3DepthAudit.audit())
end
