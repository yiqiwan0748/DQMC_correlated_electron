#!/usr/bin/env julia
module PRL101237004Fig3RefinedMeshAudit
using LinearAlgebra, Dates
include("audit_prl_101_237004_fig3_depth.jl")
const B=PRL101237004Fig3DepthAudit
const A=B.A
const D=B.D
const R=B.R
const S=B.S
const SOURCES=unique(vcat(B.SOURCES,["scripts/audit_prl_101_237004_fig3_refined_mesh.jl"]))
function audit(;output=joinpath(D.OUTPUT,"refined_mesh_audit"),
        depth=joinpath(D.OUTPUT,"depth_refinement_audit"),cases=filter(c->c.U>0,D.CASES))
    Threads.nthreads()<=2 && BLAS.get_num_threads()==1 || error("use Julia threads2 and BLAS1")
    ispath(output) && error("preserve existing refined mesh audit")
    isfile(joinpath(depth,"completed.txt")) || error("completed depth audit required")
    hashes=D.snapshot(output,SOURCES)
    D.write_toml(joinpath(output,"provenance.toml"),Dict("started_utc"=>string(now(UTC)),
        "julia"=>string(VERSION),"julia_threads"=>Threads.nthreads(),"blas_threads"=>BLAS.get_num_threads(),
        "source_sha256"=>hashes,"depth_completion_sha256"=>D.filehash(joinpath(depth,"completed.txt")),
        "command"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_fig3_refined_mesh.jl",
        "eta"=>.05,"block_steps"=>96,"limits"=>"Fixed saved h mu and mu_prime; no refilling on L96; zero-broadening density at primary L48 uses saved integer or f=1/2 shell policy; U0 analytic mesh result is unchanged and recorded in original numerical_audit; finite-window DOS area excludes spectral tails."))
    rows=NamedTuple[]
    for case in cases
        folder=joinpath(output,case.name);mkpath(folder)
        saved=D.load_case(case;output)
        records=D.TOML.parsefile(joinpath(depth,case.name,"references.toml"))
        source=joinpath(depth,records["block96_cache"])
        D.filehash(source)==records["block96_sha256"] || error("block96 cache changed")
        D.copy_identical(source,joinpath(output,"reference_cache",basename(source)))
        state=R.reference_state(case.U,case.ratio,saved.meta["h"];block_steps=96,output)
        p=S.SpectralProblem(state.reference,state.cluster,state.parameters;mu=saved.meta["mu"],mu_prime=saved.meta["mu_prime"])
        omega=collect(-3.:.005:3.);indices=1:5:length(omega);sample=omega[indices]
        baseline=S.dos_spectrum(S.spectral_plan(p,S.G.reduced_momentum_grid(p.cluster,48)),omega;eta=.05).total
        larger=S.dos_spectrum(S.spectral_plan(p,S.G.reduced_momentum_grid(p.cluster,96)),sample;eta=.05).total
        delta=larger-baseline[indices];comparison=B.differences(baseline[indices],larger)
        density=case.name=="blue_U0p5" ?
            (A.imaginary_density(p;common_shift=-1e-6)+A.imaginary_density(p;common_shift=1e-6))/2 :
            A.imaginary_density(p)
        abs(density-2)<2e-7 || error("primary block96 zero-broadening density failed")
        fine=A.trapz(omega,baseline);coarse=A.trapz(omega[1:2:end],baseline[1:2:end])
        zeroth=maximum(norm(R.C.spectral_moments(state.result;spin).zeroth-I) for spin in (:up,:down))
        row=(case=case.name,U=case.U,ratio=case.ratio,h=saved.meta["h"],mu=p.mu,mu_prime=p.mu_prime,
            block_steps=96,eta=.05,physical_L=48,audit_L=96,omega_min=-3.,omega_max=3.,
            fine_omega_step=.005,mesh_omega_step=.025,window_weight=fine,
            omitted_window_weight_from_exact_sumrule=4-fine,frequency_dx01_dx005_difference=fine-coarse,
            mesh_max_abs=comparison.max_abs,mesh_rms=comparison.rms,mesh_relative_l2=comparison.relative_l2,
            mesh_max_abs_over_peak=comparison.max_abs_over_peak,
            mesh_integrated_absolute=A.trapz(sample,abs.(delta)),
            density,density_target_error=density-2.,zeroth_moment_error=zeroth,
            minimum_DOS=min(minimum(baseline),minimum(larger)),status="complete")
        push!(rows,row)
        A.csv(joinpath(output,"mesh_summary.csv"),rows)
        A.csv(joinpath(folder,"dos_comparison.csv"),[(omega=w,L48_block96=baseline[i],L96_block96=larger[j]) for (j,(i,w)) in enumerate(zip(indices,sample))])
        D.write_toml(joinpath(folder,"reference.toml"),Dict("cache"=>relpath(state.cache,output),"sha256"=>D.filehash(state.cache)))
        D.guard(hashes)
        A.progress("$(case.name) block96 mesh max=$(comparison.max_abs) area=$(row.mesh_integrated_absolute); density error=$(density-2)")
    end
    D.guard(hashes)
    open(joinpath(output,"completed.txt"),"w") do io
        println(io,"Completed UTC ",now(UTC))
        for name in ("provenance.toml","mesh_summary.csv")
            println(io,D.filehash(joinpath(output,name))," ",name)
        end
        for case in cases,name in ("reference.toml","dos_comparison.csv")
            path=joinpath(case.name,name);println(io,D.filehash(joinpath(output,path))," ",path)
        end
    end
    output
end
end
if abspath(PROGRAM_FILE)==(@__FILE__)
    println(PRL101237004Fig3RefinedMeshAudit.audit())
end
