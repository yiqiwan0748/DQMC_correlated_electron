#!/usr/bin/env julia
module PRL101237004Milestone3Audit

using LinearAlgebra, SHA, Dates
include("prl_101_237004_geometry.jl")
include("prl_101_237004_momentum_basis.jl")
include("prl_101_237004_momentum_operator.jl")
include("prl_101_237004_momentum_observables.jl")
include("prl_101_237004_restarted_lanczos.jl")
const G = PRL101237004Geometry
const B = PRL101237004MomentumBasis
const H = PRL101237004MomentumOperator
const S = PRL101237004MomentumObservables
const L = PRL101237004RestartedLanczos

"""Direct site-averaged longitudinal moments, obtained from representative
probabilities: xz², yz², xz*yz, and (xz+yz)². No momentum sum is used here.
"""
function onsite_moments(b, vector)
    norm_squared = S._vector_norm_squared(b, vector)
    partial = zeros(Float64, 4, Threads.maxthreadid())
    Threads.@threads :static for block in eachindex(b.up_reps)
        thread = Threads.threadid()
        up = b.up_reps[block]
        @inbounds for row in b.row_offsets[block]:(b.row_offsets[block+1]-1)
            down = b.down_masks[Int(b.row_down_ranks[row])]
            weight = abs2(vector[row])
            for site in 0:(b.torus.ncells-1)
                shift = 2site
                xz = (Int((up >> shift) & 1) - Int((down >> shift) & 1)) / 2
                yz = (Int((up >> (shift+1)) & 1) - Int((down >> (shift+1)) & 1)) / 2
                partial[1,thread] += weight*xz^2
                partial[2,thread] += weight*yz^2
                partial[3,thread] += weight*xz*yz
                partial[4,thread] += weight*(xz+yz)^2
            end
        end
    end
    values = vec(sum(partial; dims=2)) ./ (norm_squared*b.torus.ncells)
    return (xz_z_squared=values[1], yz_z_squared=values[2], xz_yz_z=values[3],
            site_z_squared=values[4], norm_squared=norm_squared)
end

"""Orbital-resolved raw longitudinal structure matrix, with physical spin 1/2.
Entry (a,b,q) is <Sz_a(q) Sz_b(-q)>; its four-entry sum is total raw Szz.
"""
function orbital_structure_factors(b,vector)
    normalization = S._vector_norm_squared(b,vector)
    nq = length(b.torus.momenta)
    function spin_sums(masks)
        sums = zeros(ComplexF64,length(masks),2,nq)
        for (rank,mask) in enumerate(masks), (site,(x,y)) in enumerate(b.torus.cells), orbital in 1:2
            occupied = !iszero(mask & (UInt16(1) << (2(site-1)+orbital-1)))
            occupied || continue
            for (q,(qx,qy)) in enumerate(b.torus.momenta)
                sums[rank,orbital,q] += cis(qx*x+qy*y)/2
            end
        end
        return sums
    end
    up_sums = spin_sums(b.up_masks)
    down_sums = b.Nup==b.Ndown ? up_sums : spin_sums(b.down_masks)
    partial = zeros(ComplexF64,2,2,nq,Threads.maxthreadid())
    Threads.@threads :static for block in eachindex(b.up_reps)
        thread = Threads.threadid()
        up_rank = Int(b.rank_up[Int(b.up_reps[block])+1])
        @inbounds for row in b.row_offsets[block]:(b.row_offsets[block+1]-1)
            down_rank = Int(b.row_down_ranks[row])
            weight = abs2(vector[row])
            for q in 1:nq
                xz = up_sums[up_rank,1,q]-down_sums[down_rank,1,q]
                yz = up_sums[up_rank,2,q]-down_sums[down_rank,2,q]
                partial[1,1,q,thread] += weight*abs2(xz)
                partial[2,2,q,thread] += weight*abs2(yz)
                partial[1,2,q,thread] += weight*xz*conj(yz)
            end
        end
    end
    result = dropdims(sum(partial;dims=4);dims=4)./normalization
    result[2,1,:] .= conj.(result[1,2,:])
    return (momenta=copy(b.torus.momenta),matrix=result,norm_squared=normalization)
end

function wick_orbital_structure(torus,K,population)
    eigensystem = eigen(Symmetric(K))
    occupied = eigensystem.vectors[:,1:population]
    density = occupied*transpose(occupied)
    result = zeros(ComplexF64,2,2,length(torus.momenta))
    for (q,(qx,qy)) in enumerate(torus.momenta), a in axes(K,1), b in axes(K,2)
        ra,rb = torus.cells[(a+1)÷2],torus.cells[(b+1)÷2]
        correlation = ((a==b ? density[a,a] : 0.0)-abs2(density[a,b]))/2
        result[mod1(a,2),mod1(b,2),q] += cis(qx*(ra[1]-rb[1])+qy*(ra[2]-rb[2]))*correlation
    end
    return (momenta=copy(torus.momenta),matrix=result)
end

function _literal_ops(state::UInt64,ops)
    sign = 1.0
    for (mode,creation) in ops
        bit = UInt64(1) << (mode-1)
        occupied = !iszero(state&bit)
        occupied==creation && return nothing
        isodd(count_ones(state&(bit-UInt64(1)))) && (sign=-sign)
        state ⊻= bit
    end
    return state,sign
end

function _literal_column(state,nmodes,K,U,J)
    terms = Dict{UInt64,Float64}()
    add!(destination,value) = (terms[destination]=get(terms,destination,0.0)+value)
    diagonal = 0.0
    occupancy(mode) = Int((state>>(mode-1))&1)
    for site in 0:(nmodes÷2-1)
        x,y,xd,yd = 2site+1,2site+2,nmodes+2site+1,nmodes+2site+2
        nx,ny = occupancy(x)+occupancy(xd),occupancy(y)+occupancy(yd)
        sx,sy = (occupancy(x)-occupancy(xd))/2,(occupancy(y)-occupancy(yd))/2
        diagonal += U*(occupancy(x)*occupancy(xd)+occupancy(y)*occupancy(yd)) +
            (U-2J-J/2)*nx*ny-2J*sx*sy
        for (coefficient,ops) in (
            (-J,((y,false),(yd,true),(xd,false),(x,true))),
            (-J,((yd,false),(y,true),(x,false),(xd,true))),
            ( J,((y,false),(yd,false),(xd,true),(x,true))),
            ( J,((x,false),(xd,false),(yd,true),(y,true))))
            transition = _literal_ops(state,ops)
            transition===nothing || add!(transition[1],coefficient*transition[2])
        end
    end
    add!(state,diagonal)
    for spin_offset in (0,nmodes), source in 1:nmodes, destination in 1:nmodes
        iszero(K[destination,source]) && continue
        transition = _literal_ops(state,((source+spin_offset,false),(destination+spin_offset,true)))
        transition===nothing || add!(transition[1],K[destination,source]*transition[2])
    end
    return terms
end

function _brute_project_destination(b,state,actions)
    mask = (UInt64(1)<<b.nmodes)-UInt64(1)
    best = (typemax(UInt64),typemax(UInt64))
    best_sign,best_group = 0,0
    orbit = UInt64[]
    for (g,(destinations,signs)) in enumerate(actions)
        transformed,sign = G._transform_state(state,destinations,signs)
        push!(orbit,transformed)
        pair = (transformed&mask,transformed>>b.nmodes)
        if pair<best
            best,best_sign,best_group = pair,sign,g
        end
    end
    up,down = UInt16(best[1]),UInt16(best[2])
    # Binary searches avoid the production raw-mask canonicalizer and ranks.
    block = searchsortedfirst(b.up_reps,up)
    down_rank = searchsortedfirst(b.down_masks,down)
    b.up_reps[block]==up && b.down_masks[down_rank]==down || error("independent representative absent")
    packed = b.lookup[down_rank,block]
    iszero(packed) && return nothing
    iszero(packed&3) || error("canonical representative lookup has a phase")
    row = Int(packed>>2)
    orbit_length = length(unique(orbit))
    b.orbit_lengths[row]==orbit_length || error("independent orbit size differs")
    displacement = b.torus.cells[best_group]
    phase = best_sign*cis(b.kx*displacement[1]+b.ky*displacement[2])
    return row,phase,orbit_length
end

function _production_gather_row(operator,row)
    b = operator.basis
    block = searchsortedlast(b.row_offsets,row)
    dr = Int(b.row_down_ranks[row])
    down = b.down_masks[dr]
    Li = Int(b.orbit_lengths[row])
    result = Dict{Int,ComplexF64}(row=>operator.diagonal[row])
    add!(j,value) = (result[j]=get(result,j,0.0im)+value)
    function translated!(move,down_state)
        g,orbit = Int(move.translation),Int(move.orbit)
        mapped = b.translation_masks[Int(down_state)+1,g]
        rank = Int(b.rank_down[Int(mapped)+1])
        packed = b.lookup[rank,orbit]
        iszero(packed) && return
        destination = Int(packed>>2)
        phase = Int(move.phase)+Int(packed&3)+(b.translation_signs[Int(down_state)+1,g]==-1 ? 2 : 0)
        value = move.amplitude*H._phase(eltype(operator),phase)*
            operator.orbit_ratios[Li,Int(b.orbit_lengths[destination])]
        add!(destination,value)
    end
    for entry in operator.down_offsets[dr]:(operator.down_offsets[dr+1]-1)
        move = operator.down_moves[entry]
        packed = b.lookup[Int(move.rank),block]
        iszero(packed) && continue
        destination = Int(packed>>2)
        value = move.amplitude*H._phase(eltype(operator),Int(packed&3))*
            operator.orbit_ratios[Li,Int(b.orbit_lengths[destination])]
        add!(destination,value)
    end
    for entry in operator.up_offsets[block]:(operator.up_offsets[block+1]-1)
        translated!(operator.up_moves[entry],down)
    end
    for site in 1:b.torus.ncells
        move = operator.local_moves[site,block]
        iszero(move.orbit) && continue
        shift = 2(site-1)
        H._single((down>>shift)&0x0003) || continue
        translated!(move,down⊻(UInt16(3)<<shift))
    end
    return result
end

"""Check selected production-size rows against literal 32-spin-mode monomials
and brute-force signed translations. Only small per-row dictionaries are built.
"""
function audit_transition_rows(operator;sample_count=64)
    b = operator.basis
    sample_count>0 || throw(ArgumentError("sample_count must be positive"))
    sample_rows = Int[1,length(b)]
    for orbit_length in 1:b.torus.ncells
        row = findfirst(==(orbit_length),b.orbit_lengths)
        row===nothing || push!(sample_rows,row)
    end
    for index in 1:sample_count
        push!(sample_rows,Int(mod(UInt64(index)*0x9e3779b97f4a7c15,UInt64(length(b))))+1)
    end
    sort!(unique!(sample_rows))
    actions = [G._mode_action(b.torus,:translation,displacement) for displacement in b.torus.cells]
    rows = Tuple[]
    for row in sample_rows
        up,down = B.representative(b,row)
        state = UInt64(up)|(UInt64(down)<<b.nmodes)
        literal = _literal_column(state,b.nmodes,operator.K,operator.U,operator.J)
        expected = Dict{Int,ComplexF64}()
        for (destination,amplitude) in literal
            mapped = _brute_project_destination(b,destination,actions)
            mapped===nothing && continue
            j,phase,orbit_length = mapped
            # Literal application generates column H[j,row]; gather is its
            # conjugate because the validated Hamiltonian is Hermitian.
            coefficient = conj(amplitude*phase*sqrt(Float64(b.orbit_lengths[row])/orbit_length))
            expected[j] = get(expected,j,0.0im)+coefficient
        end
        actual = _production_gather_row(operator,row)
        destinations = union(keys(expected),keys(actual))
        maximum_error = maximum(abs(get(expected,j,0.0im)-get(actual,j,0.0im)) for j in destinations)
        maximum_error<=2e-12 || error("literal transition row $row failed: $maximum_error")
        push!(rows,(row,string(up;base=16),string(down;base=16),Int(b.orbit_lengths[row]),
            length(literal),length(destinations),maximum_error))
    end
    return rows
end

function _rotation_tables(torus)
    nmodes = 2torus.ncells
    bits = zeros(UInt16,nmodes)
    mode_sign = ones(Int8,nmodes)
    for (site,(x,y)) in enumerate(torus.cells)
        target = G.TorusED._site_index(torus,(-y,x))
        bits[2site-1] = UInt16(1) << (2target-1) # xz -> yz
        bits[2site] = UInt16(1) << (2target-2)   # yz -> -xz
        mode_sign[2site] = -1
    end
    masks, signs = zeros(UInt16,65536), ones(Int8,65536)
    for raw in 1:((1 << nmodes)-1)
        mask = UInt16(raw)
        previous = mask & (mask-UInt16(1))
        source = trailing_zeros(mask)+1
        bit = bits[source]
        mapped = masks[Int(previous)+1]
        masks[raw+1] = mapped | bit
        parity = isodd(count_ones(mapped & (bit-UInt16(1)))) ? -1 : 1
        signs[raw+1] = parity*mode_sign[source]*signs[Int(previous)+1]
    end
    return masks, signs
end

"""Contract C4 directly in a rotation-invariant momentum block. The physical
orbital action is xz -> yz and yz -> -xz. `leakage_to_span` is
`||(C4-<C4>)v||/||v||`; `residual_to_nearest_eigenvalue` uses the closest
fourth root of unity instead. No rotated many-body vector is allocated.
"""
function c4_expectation(b, vector)
    G.has_c4_symmetry(b.torus) || throw(ArgumentError("torus does not preserve C4"))
    # A C4 rotation sends k to (-ky,kx); compare finite-group characters.
    all(d -> isapprox(cis(b.kx*d[1]+b.ky*d[2]),
                        cis(-b.ky*d[1]+b.kx*d[2]); atol=2e-12,rtol=0), b.torus.cells) ||
        throw(ArgumentError("C4 maps this momentum block to another block"))
    norm_squared = S._vector_norm_squared(b, vector)
    masks, signs = _rotation_tables(b.torus)
    partial = zeros(ComplexF64,Threads.maxthreadid())
    Threads.@threads :static for block in eachindex(b.up_reps)
        thread = Threads.threadid()
        up = b.up_reps[block]
        rotated_up, up_sign = masks[Int(up)+1], signs[Int(up)+1]
        subtotal = 0.0+0.0im
        @inbounds for row in b.row_offsets[block]:(b.row_offsets[block+1]-1)
            down = b.down_masks[Int(b.row_down_ranks[row])]
            destination, code = B.locate_code(b,rotated_up,masks[Int(down)+1])
            destination != 0 || error("rotation of an admissible orbit was excluded")
            # Rotation conjugates the translation group, preserving orbit size.
            b.orbit_lengths[row] == b.orbit_lengths[destination] || error("C4 changed orbit length")
            factor = sqrt(Float64(b.orbit_lengths[row])/b.orbit_lengths[destination])
            subtotal += conj(vector[destination])*vector[row]*up_sign*signs[Int(down)+1]*B.phase_value(code)*factor
        end
        partial[thread] += subtotal
    end
    expectation = sum(partial)/norm_squared
    roots = ComplexF64[1,im,-1,-im]
    nearest = roots[argmin(abs.(roots .- expectation))]
    # A second scalar pass evaluates the actual norms without subtracting
    # nearly equal O(1) numbers. C4 permutes the normalized translation orbits,
    # so each source supplies exactly one destination coefficient.
    defects = zeros(Float64,2,Threads.maxthreadid())
    Threads.@threads :static for block in eachindex(b.up_reps)
        thread = Threads.threadid()
        up = b.up_reps[block]
        rotated_up, up_sign = masks[Int(up)+1], signs[Int(up)+1]
        @inbounds for row in b.row_offsets[block]:(b.row_offsets[block+1]-1)
            down = b.down_masks[Int(b.row_down_ranks[row])]
            destination,code = B.locate_code(b,rotated_up,masks[Int(down)+1])
            coefficient = up_sign*signs[Int(down)+1]*B.phase_value(code)*vector[row]
            defects[1,thread] += abs2(coefficient-expectation*vector[destination])
            defects[2,thread] += abs2(coefficient-nearest*vector[destination])
        end
    end
    return (expectation=expectation,
        leakage_to_span=sqrt(sum(view(defects,1,:))/norm_squared),
        nearest_eigenvalue=nearest,
        residual_to_nearest_eigenvalue=sqrt(sum(view(defects,2,:))/norm_squared))
end

"""Independent finite-cluster Wick result from the one-body occupied projector.
For identical up/down Slaters, <Sz_a Sz_b>=(δ_ab P_aa-|P_ab|²)/2.
"""
function wick_structure(torus,K,population)
    eigensystem = eigen(Symmetric(K))
    occupied = eigensystem.vectors[:,1:population]
    density = occupied*transpose(occupied)
    raw = zeros(Float64,length(torus.momenta))
    for (q,(qx,qy)) in enumerate(torus.momenta), a in axes(K,1), b in axes(K,2)
        ra, rb = torus.cells[(a+1)÷2], torus.cells[(b+1)÷2]
        correlation = ((a==b ? density[a,a] : 0.0)-abs2(density[a,b]))/2
        raw[q] += cos(qx*(ra[1]-rb[1])+qy*(ra[2]-rb[2]))*correlation
    end
    gap = population==0 || population==size(K,1) ? Inf :
        eigensystem.values[population+1]-eigensystem.values[population]
    return (momenta=copy(torus.momenta),szsz_raw=raw,
            szsz_per_site=raw./torus.ncells,
            energy=2sum(eigensystem.values[1:population]),orbital_gap=gap)
end

_sha(path) = bytes2hex(open(sha256,path))

# The first production job predates extra argument/overflow/translation guards.
# Permit that one source mismatch only when conversion statements and every
# byte outside the constructor's validation preamble remain identical.
function _operator_guard_only_change(snapshot,current)
    function split_operator(text)
        start = findfirst("    size(K) == ",text)
        finish = findfirst("    estimate = b.estimated_bytes",text)
        (start===nothing || finish===nothing || first(start)>=first(finish)) && return nothing
        preamble = text[first(start):prevind(text,first(finish))]
        conversions = ("    K = Matrix{Float64}(K)","    U, J = Float64(U), Float64(J)")
        all(line -> count(line,preamble)==1, conversions) || return nothing
        outside = text[firstindex(text):prevind(text,first(start))] * text[first(finish):end]
        return outside
    end
    a, b = split_operator(snapshot), split_operator(current)
    return a!==nothing && b!==nothing && a==b
end

function validate_provenance(saved,jobdir)
    metadata = saved.metadata
    metadata.model == "PRL101237004 literal Eq1+Eq2" || error("wrong model metadata")
    (metadata.nsites,metadata.Nup,metadata.Ndown)==(8,8,8) || error("wrong cluster or particle sector")
    all(isfinite,(metadata.U,metadata.J,metadata.ratio,metadata.kx,metadata.ky)) || error("nonfinite physical metadata")
    metadata.U>=0 && metadata.J==metadata.U/4 && metadata.ratio==-0.2 || error("unexpected interaction or hopping parameters")
    metadata.kx==0 && metadata.ky==0 || error("audit requires the Gamma block")
    saved.format_version==1 && saved.converged || error("checkpoint is not a completed version-1 solve")
    saved.residuals!==nothing || error("completed checkpoint has no direct residuals")
    all(saved.residuals .<= saved.configuration.atol .+ saved.configuration.rtol.*abs.(saved.values)) ||
        error("checkpoint residual exceeds its recorded tolerance")
    issorted(saved.values) || error("checkpoint roots are not sorted")
    flat_sources = Set(("prl_101_237004_model.jl","prl_101_237004_geometry.jl",
        "two_orbital_tilted_cluster_ed.jl","prl_101_237004_momentum_basis.jl",
        "prl_101_237004_momentum_operator.jl","prl_101_237004_momentum_observables.jl",
        "prl_101_237004_restarted_lanczos.jl"))
    structured_sources = Set(vcat(["scripts/"*name for name in flat_sources],["src/noninteracting.jl"]))
    recorded_sources = Set(keys(metadata.source_hashes))
    legacy = recorded_sources==flat_sources
    legacy || recorded_sources==structured_sources || error("checkpoint core-source inventory differs")
    root = dirname(@__DIR__)
    rows = Tuple[]
    for name in sort(collect(keys(metadata.source_hashes)))
        snapshot = joinpath(jobdir,"source_snapshot",name)
        current = legacy ? joinpath(@__DIR__,name) : joinpath(root,name)
        isfile(snapshot) && isfile(current) || error("missing source provenance file: $name")
        recorded = metadata.source_hashes[name]
        snapshot_sha,current_sha = _sha(snapshot),_sha(current)
        snapshot_sha==recorded || error("snapshot differs from checkpoint source hash: $name")
        status = "exact_source_match"
        if current_sha!=recorded
            basename(name)=="prl_101_237004_momentum_operator.jl" &&
                _operator_guard_only_change(read(snapshot,String),read(current,String)) ||
                error("current source changed beyond the allowed operator validation preamble: $name")
            status = "validation_preamble_differs_numerical_body_identical"
        end
        push!(rows,(name,recorded,snapshot_sha,current_sha,status))
    end
    if legacy
        # The original flat snapshot omitted this transitive include. A later
        # supplement can establish its present identity, but cannot retroactively
        # add a recorded production hash. Preserve that distinction in the CSV.
        name = "src/noninteracting.jl"
        snapshot = joinpath(jobdir,"source_snapshot",name)
        current = joinpath(root,name)
        isfile(snapshot) || error("legacy job needs the explicit transitive-source supplement")
        snapshot_sha,current_sha = _sha(snapshot),_sha(current)
        snapshot_sha==current_sha || error("legacy noninteracting source supplement differs from current source")
        push!(rows,(name,"not_recorded_in_original_checkpoint",snapshot_sha,current_sha,
            "legacy_transitive_source_supplement_matches_current"))
    end
    return rows
end

function _csv(path,header,rows)
    temporary = path*".partial"
    open(temporary,"w") do io
        println(io,header)
        for row in rows
            println(io,join(row,','))
        end
    end
    mv(temporary,path;force=true)
end

function audit_job(jobdir; include_free=true, include_diagnostics=false)
    jobdir = abspath(jobdir)
    isfile(joinpath(jobdir,"energies.csv")) || error("job has not written completed energies.csv")
    checkpoint = joinpath(dirname(jobdir),"checkpoints",basename(jobdir)*".jls")
    isfile(checkpoint) || error("completed job checkpoint is missing")
    saved = L.read_lanczos_checkpoint(checkpoint)
    provenance = validate_provenance(saved,jobdir)
    torus = G.standard_eight_site_torus()
    b = B.build_momentum_basis(torus,8,8,saved.metadata.kx,saved.metadata.ky)
    saved.dimension==length(b) && size(saved.vectors,1)==length(b) || error("checkpoint dimension differs from reconstructed basis")
    saved.scalar_type==string(eltype(saved.vectors)) || error("checkpoint scalar metadata differs")
    vector = @view saved.vectors[:,1]
    onsite = onsite_moments(b,vector)
    structure = S.spin_structure_factors(b,vector)
    sumrule = sum(structure.szsz_per_site)/torus.ncells
    discrepancy = abs(sumrule-onsite.site_z_squared)
    discrepancy<=2e-11 || error("independent real-space/Fourier sum rule failed: $discrepancy")
    c4 = c4_expectation(b,vector)
    metrics = Tuple[("U",saved.metadata.U),("J",saved.metadata.J),
        ("ground_energy",saved.values[1]),("recorded_direct_residual",saved.residuals[1]),
        ("norm_squared",onsite.norm_squared),
        ("onsite_xz_z_squared",onsite.xz_z_squared),("onsite_yz_z_squared",onsite.yz_z_squared),
        ("onsite_xz_yz_z",onsite.xz_yz_z),("onsite_total_z_squared",onsite.site_z_squared),
        ("fourier_mean_Szz_per_site",sumrule),("onsite_fourier_sumrule_error",discrepancy),
        ("C4_expectation_real",real(c4.expectation)),("C4_expectation_imag",imag(c4.expectation)),
        ("C4_leakage_to_state_span",c4.leakage_to_span),
        ("C4_nearest_eigenvalue_real",real(c4.nearest_eigenvalue)),
        ("C4_nearest_eigenvalue_imag",imag(c4.nearest_eigenvalue)),
        ("C4_residual_to_nearest_eigenvalue",c4.residual_to_nearest_eigenvalue)]
    if include_diagnostics
        K = G.paper_kinetic_matrix(torus,G.PRLModel.slater_koster_parameters(saved.metadata.ratio))
        orbital = orbital_structure_factors(b,vector)
        wick_orbital = wick_orbital_structure(torus,K,8)
        orbital_total_error = maximum(abs(real(sum(orbital.matrix[:,:,q]))-structure.szsz_raw[q]) for q in eachindex(torus.momenta))
        orbital_total_error<=2e-10 || error("orbital-resolved sum differs from total Szz")
        label = "U"*replace(string(saved.metadata.U),'.'=>'p')
        _csv(joinpath(jobdir,"orbital_structure_diagnostic.csv"),
            "state,qx_over_pi,qy_over_pi,Sxz_xz_raw,Syz_yz_raw,Sxz_yz_raw_real,Sxz_yz_raw_imag,total_Szz_raw",
            [(name,q[1]/pi,q[2]/pi,real(result.matrix[1,1,i]),real(result.matrix[2,2,i]),
                real(result.matrix[1,2,i]),imag(result.matrix[1,2,i]),real(sum(result.matrix[:,:,i])))
             for (name,result) in ((label,orbital),("U0_Wick",wick_orbital)) for (i,q) in enumerate(result.momenta)])
        operator = H.momentum_hamiltonian(b,K,saved.metadata.U;J=saved.metadata.J)
        samples = audit_transition_rows(operator;sample_count=128)
        max_error = maximum(row[end] for row in samples)
        _csv(joinpath(jobdir,"literal_transition_audit.csv"),
            "row,up_hex,down_hex,orbit_length,literal_destinations,reduced_destinations,maximum_coefficient_error",samples)
        append!(metrics,[("orbital_total_Szz_reconstruction_error",orbital_total_error),
            ("literal_transition_sampled_rows",length(samples)),("literal_transition_maximum_coefficient_error",max_error)])
    end
    if include_free
        K = G.paper_kinetic_matrix(torus,G.PRLModel.slater_koster_parameters(saved.metadata.ratio))
        wick = wick_structure(torus,K,8)
        wick.orbital_gap>1e-10 || error("U=0 benchmark is not a closed shell")
        free = S.free_slater_start(b,K)
        measured = S.spin_structure_factors(b,free.vector)
        max_difference = maximum(abs.(wick.szsz_raw-measured.szsz_raw))
        max_difference<=2e-10 || error("U=0 Wick and projected-Slater spin results differ")
        operator = H.momentum_hamiltonian(b,K,0.0)
        work = similar(free.vector)
        mul!(work,operator,free.vector)
        energy = dot(free.vector,work)
        axpy!(-energy,free.vector,work)
        residual = norm(work)
        residual<=2e-10 || error("U=0 Slater is not an eigenvector: $residual")
        append!(metrics,[("U0_Wick_energy",wick.energy),("U0_projected_energy",energy),
            ("U0_direct_residual",residual),("U0_projection_weight",free.projection_weight),
            ("U0_orbital_gap",wick.orbital_gap),("U0_max_Wick_Slater_raw_Szz_error",max_difference)])
        _csv(joinpath(jobdir,"audit_u0_wick.csv"),"qx_over_pi,qy_over_pi,Wick_Szz_raw,Slater_Szz_raw,absolute_difference",
            [(q[1]/pi,q[2]/pi,wick.szsz_raw[i],measured.szsz_raw[i],abs(wick.szsz_raw[i]-measured.szsz_raw[i])) for (i,q) in enumerate(wick.momenta)])
    end
    _csv(joinpath(jobdir,"independent_audit.csv"),"quantity,value",metrics)
    _csv(joinpath(jobdir,"audit_source_provenance.csv"),"source,checkpoint_sha256,snapshot_sha256,current_sha256,status",provenance)
    open(joinpath(jobdir,"audit_metadata.txt"),"w") do io
        println(io,"Audited: ",now())
        println(io,"Checkpoint: ",checkpoint)
        println(io,"Checkpoint SHA256: ",_sha(checkpoint))
        println(io,"Audit script SHA256: ",_sha(@__FILE__))
        println(io,"Julia: ",VERSION,"; threads: ",Threads.nthreads(),"; BLAS threads: ",BLAS.get_num_threads())
        println(io,"Physical metadata, snapshot hashes, basis dimension, and recorded direct residuals validated.")
        println(io,"A current operator hash mismatch is accepted only for its validation preamble; the numeric conversions and remaining source must be identical. See audit_source_provenance.csv.")
        println(io,"For a legacy flat snapshot, src/noninteracting.jl is an explicit later supplement: its current identity is checked, but its hash was not recorded in the original checkpoint.")
        println(io,"C4 residual/leakage norms are accumulated directly in a second permutation pass; no full rotated vector or cancellation-prone 1-|<C4>|^2 subtraction is used.")
        println(io,"Direct onsite/Fourier sum-rule tolerance: 2e-11; U0 Wick and eigenvector tolerance: 2e-10.")
    end
    println("Audit passed: ",jobdir,"; onsite sum-rule error=",discrepancy,"; <C4>=",c4.expectation)
    return (onsite=onsite,structure=structure,c4=c4,metrics=metrics,provenance=provenance)
end

"""Small independent checks, with no production checkpoint or output writes."""
function self_test()
    operator_source = read(joinpath(@__DIR__,"prl_101_237004_momentum_operator.jl"),String)
    extra_guard = replace(operator_source,"    K = Matrix{Float64}(K)"=>
        "    true || error(\"extra argument guard\")\n    K = Matrix{Float64}(K)")
    @assert _operator_guard_only_change(operator_source,extra_guard)
    @assert !_operator_guard_only_change(operator_source,operator_source*"\n# changed outside guards\n")
    torus = G.periodic_square_torus()
    b = B.build_momentum_basis(torus,1,1,0,0)
    vector = ComplexF64[complex(sin(i),cos(3i)) for i in eachindex(b.orbit_lengths)]
    expanded = B.expand_momentum_vector(b,vector)
    states = UInt64[UInt64(up)|(UInt64(down)<<b.nmodes) for down in b.down_masks for up in b.up_masks]
    full = (;nmodes=b.nmodes,Nup=1,Ndown=1,states,indices=Dict(s=>i for (i,s) in enumerate(states)))
    action = G.symmetry_action(full,torus;kind=:c4)
    expected = dot(expanded,G.apply_symmetry(action,expanded))/sum(abs2,expanded)
    actual = c4_expectation(b,vector)
    @assert isapprox(actual.expectation,expected;atol=2e-12,rtol=0)
    rotated_full = G.apply_symmetry(action,expanded)
    @assert isapprox(actual.leakage_to_span,norm(rotated_full-expected*expanded)/norm(expanded);atol=2e-12,rtol=0)
    @assert isapprox(actual.residual_to_nearest_eigenvalue,
        norm(rotated_full-actual.nearest_eigenvalue*expanded)/norm(expanded);atol=2e-12,rtol=0)
    direct = zeros(4)
    for (row,state) in enumerate(states), site in 0:3
        xz = (Int((state>>(2site))&1)-Int((state>>(b.nmodes+2site))&1))/2
        yz = (Int((state>>(2site+1))&1)-Int((state>>(b.nmodes+2site+1))&1))/2
        direct .+= abs2(expanded[row]).*[xz^2,yz^2,xz*yz,(xz+yz)^2]
    end
    direct ./= 4sum(abs2,expanded)
    onsite = onsite_moments(b,vector)
    @assert isapprox(collect(onsite)[1:4],direct;atol=2e-12,rtol=0)
    structure = S.spin_structure_factors(b,vector)
    @assert isapprox(sum(structure.szsz_per_site)/4,onsite.site_z_squared;atol=2e-12,rtol=0)
    K = G.paper_kinetic_matrix(torus)
    free = S.free_slater_start(b,K)
    wick = wick_structure(torus,K,1)
    @assert isapprox(S.spin_structure_factors(b,free.vector).szsz_raw,wick.szsz_raw;atol=2e-12,rtol=0)
    # A partially filled one-body degeneracy need not choose a C4 eigen-Slater.
    # Construct an actual C4=+1 vector with the independent full-space action.
    rotated = copy(expanded)
    projected_c4 = copy(expanded)
    for _ in 1:3
        rotated = G.apply_symmetry(action,rotated)
        projected_c4 .+= rotated
    end
    reduced_c4 = zeros(ComplexF64,length(b))
    for row in eachindex(reduced_c4)
        up,down = B.representative(b,row)
        index = full.indices[UInt64(up)|(UInt64(down)<<b.nmodes)]
        reduced_c4[row] = projected_c4[index]*sqrt(Float64(b.orbit_lengths[row]))
    end
    @assert isapprox(c4_expectation(b,reduced_c4).expectation,1;atol=2e-12,rtol=0)
    @assert c4_expectation(b,reduced_c4).residual_to_nearest_eigenvalue<2e-12
    println("Independent audit small-space self-test passed.")
    return true
end

"""A separate four-site diagnostic with the unchanged original-PRL hoppings.
The final column rescales physical per-Fe Szz by eight solely for comparison
with the established eight-site plotting scale; it is not raw four-site Szz.
"""
function periodic_2x2_diagnostic(output)
    torus = G.periodic_square_torus()
    b = B.build_momentum_basis(torus,4,4,0,0)
    K = G.paper_kinetic_matrix(torus)
    # Independent full-Fock dense energies recorded in milestone 2.
    reference = Dict(0.5=>-5.0254122793938025,1.0=>-3.5847179170623735)
    rows = Tuple[]
    for U in (0.5,1.0)
        operator = H.momentum_hamiltonian(b,K,U;J=U/4)
        result = L.restarted_lowest(operator;nev=1,krylovdim=36,keep=6,
            max_matvecs=400,atol=1e-12,rtol=0.0,seed=29,max_bytes=128*1024^2)
        result.converged || error("four-site diagnostic did not converge")
        abs(result.values[1]-reference[U])<2e-11 || error("four-site energy differs from independent milestone-2 dense result")
        vector = @view result.vectors[:,1]
        structure = S.spin_structure_factors(b,vector)
        spin_squared = S.total_spin_squared(b,vector)
        abs(spin_squared)<2e-11 || error("four-site ground state is not a singlet")
        for (i,q) in enumerate(structure.momenta)
            push!(rows,("periodic_2x2",4,U,U/4,q[1]/pi,q[2]/pi,result.values[1],
                result.residuals[1],spin_squared,structure.szsz_raw[i],structure.szsz_per_site[i],
                8structure.szsz_per_site[i]))
        end
    end
    output = abspath(output)
    mkpath(dirname(output))
    _csv(output,"cluster,nsites,U,J,qx_over_pi,qy_over_pi,ground_energy,direct_residual,total_spin_squared,Szz_raw_four_sites,Szz_per_Fe,eight_times_Szz_per_Fe",rows)
    open(splitext(output)[1]*"_metadata.txt","w") do io
        println(io,"Separate finite-size diagnostic; no published reference or eight-site result was changed.")
        println(io,"Original PRL Slater-Koster hoppings at pdpi/pdsigma=-0.2, including original t4=-0.07899972000000001.")
        println(io,"The later t4 factor-of-two erratum is intentionally not applied to this original-figure diagnostic.")
        println(io,"Ground energies agree within 2e-11 with independent milestone-2 full-space dense diagonalization.")
        println(io,"eight_times_Szz_per_Fe is a common-scale comparison, not a claim that the published figure used four sites.")
        println(io,"Created: ",now(),"; audit script SHA256: ",_sha(@__FILE__))
    end
    foreach(println,rows)
    return rows
end

function main(arguments=ARGS)
    arguments==["--self-test"] && return self_test()
    length(arguments)==1 && startswith(arguments[1],"--periodic-2x2=") &&
        return periodic_2x2_diagnostic(split(arguments[1],'=';limit=2)[2])
    jobdir = nothing
    include_free = true
    include_diagnostics = false
    for argument in arguments
        if startswith(argument,"--job-dir=")
            jobdir = split(argument,'=';limit=2)[2]
        elseif argument=="--skip-free"
            include_free=false
        elseif argument=="--diagnostics"
            include_diagnostics=true
        else
            throw(ArgumentError("use --job-dir=PATH [--skip-free] [--diagnostics], or --self-test"))
        end
    end
    jobdir===nothing && throw(ArgumentError("--job-dir=PATH is required"))
    return audit_job(jobdir;include_free,include_diagnostics)
end

end # module
if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Milestone3Audit.main()
end
