#!/usr/bin/env julia

# Independent common-shift and integration audit at one fixed Weiss field.
# The physical and reference chemical potentials move together only in the
# plateau test. All frequency/mesh refinements hold both potentials fixed.
using LinearAlgebra, SHA, Printf, Dates
include("prl_101_237004_vca_campaign.jl")
const V = PRL101237004VCACampaign
const F = V.F

function audit_functional(;output=joinpath(V.DEFAULT_OUTPUT,"functional_audit"))
    Threads.nthreads()==2 || error("run this bounded audit with JULIA_NUM_THREADS=2")
    BLAS.get_num_threads()==1 || error("run this bounded audit with OPENBLAS_NUM_THREADS=1")
    isfile(joinpath(output,"completed.txt")) && error("completed audit exists; preserve its provenance")
    mkpath(output)
    sources=vcat(V.SCAN_SOURCES,["scripts/audit_prl_101_237004_vca_functional.jl"])
    hashes=Dict(source=>V.filehash(joinpath(V.ROOT,source)) for source in sources)
    for source in sources
        destination=joinpath(output,"source_snapshot",source)
        mkpath(dirname(destination))
        if isfile(destination)
            V.filehash(destination)==hashes[source] || error("audit snapshot differs: $source")
        else
            cp(joinpath(V.ROOT,source),destination)
        end
    end
    provenance=joinpath(output,"provenance.txt")
    open(provenance,"w") do io
        println(io,"Started: ",now())
        println(io,"Julia: ",VERSION,"; Julia threads: ",Threads.nthreads(),"; BLAS threads: ",BLAS.get_num_threads())
        println(io,"BLAS configuration: ",BLAS.get_config())
        println(io,"Working directory: ",pwd())
        println(io,"Exact invocation: OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_vca_functional.jl")
        println(io,"Parameters: U=1; J=0.25; pdpi/pdsigma=-0.2; h=0.045; channel=stripe_y; reference=open2x2; Nup=Ndown=4; block_steps=48; seed=7.")
        println(io,"Stationarity: physical mu=0.85; L=48 physical Fe per axis; order=24; initial=0.85; gradient_atol=1e-7; scan_points=9; x_atol=1e-8; max_iterations=40; edge_fraction=0.03.")
        println(io,"No digitized figure values enter this audit. Common shifts test a plateau; fixed-variable refinements test integration accuracy.")
        println(io,"Source SHA256:")
        for source in sort(sources)
            println(io,hashes[source],"  ",source)
        end
    end
    state=V.reference_state(0.045,:stripe_y;block_steps=48)
    state.result.converged || error("reference Green functions failed their recorded convergence probes")
    cachehash=V.filehash(state.cache)
    open(provenance,"a") do io
        println(io,"Reference cache: ",state.cache)
        println(io,"Reference cache SHA256: ",cachehash)
        println(io,"Reference canonical E0: ",state.result.E0,"; direct ground residual: ",state.result.ground_residual)
        println(io,"Reference charge interval from immediate neighbor sectors: ",state.result.mu_interval)
        println(io,"Largest reference half-depth probe difference: ",maximum(ch.convergence_error for ch in state.result.channels))
        println(io,"Reference metadata: ",state.metadata)
    end
    lat=V.embedding(state;physical_L=48)
    println(now()," reference loaded; finding stationary mu_prime"); flush(stdout)
    stationarity_seconds=@elapsed solved=V.stationary_point(state,lat;mu=.85,order=24,initial=.85)
    baseline=solved.choice.data
    V.write_csv(joinpath(output,"stationarity_evaluations.csv"),
        "mu_prime,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe",
        [(x,solved.search.evaluation_cache[x].omega,solved.search.evaluation_cache[x].density,
          solved.search.evaluation_cache[x].mu_prime_gradient,solved.search.evaluation_cache[x].moment)
         for x in sort(collect(keys(solved.search.evaluation_cache)))])
    V.write_csv(joinpath(output,"stationary_roots.csv"),
        "mu_prime,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,status,iterations,bracket_lower,bracket_upper",
        [(r.mu_prime,r.data.omega,r.data.density,r.gradient,r.data.moment,r.status,r.iterations,r.bracket...) for r in solved.search.roots])
    open(provenance,"a") do io
        println(io,"Stationarity status: ",solved.search.status,"; evaluations: ",solved.search.evaluations,"; elapsed seconds: ",stationarity_seconds)
        println(io,"Selected stationary mu_prime: ",baseline.mu_prime,"; baseline: ",baseline)
        println(io,"Selection is the certified root nearest initial mu_prime=0.85; all roots found on the full scalar scan are saved.")
    end
    @printf("%s stationary mu_prime=%.12f Omega=%.12f n=%.12f gradient=%.3g\n",
        string(now()),baseline.mu_prime,baseline.omega,baseline.density,baseline.mu_prime_gradient)
    flush(stdout)
    shifts=Tuple[]
    for delta in (-.05,-.02,-.005,0.,.005,.02,.05)
        seconds=@elapsed x=F.evaluate_functional(state.reference,lat,.85+delta,baseline.mu_prime+delta;
            quadrature=F.imaginary_quadrature(24))
        push!(shifts,(delta,x.mu,x.mu_prime,x.omega,x.density,x.mu_prime_gradient,x.moment,
            x.omega+2delta,x.omega+2delta-baseline.omega,x.density-baseline.density,
            x.mu_prime_gradient-baseline.mu_prime_gradient,x.moment-baseline.moment,48,24,seconds))
        V.write_csv(joinpath(output,"common_shifts.csv"),
            "delta,mu,mu_prime,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,Omega_plus_2delta,Omega_shift_corrected_drift,density_drift,gradient_drift,moment_drift,physical_L,quadrature_order,seconds",shifts)
        @printf("%s delta=%+.3f n=%.12f gradient=%.3g corrected_Omega_drift=%.3g moment_drift=%.3g\n",
            string(now()),delta,x.density,x.mu_prime_gradient,x.omega+2delta-baseline.omega,x.moment-baseline.moment)
        flush(stdout)
    end
    refinements=Tuple[]
    for (physical_L,order) in ((48,24),(48,48),(48,72),(96,48))
        target=physical_L==48 ? lat : V.embedding(state;physical_L)
        seconds=@elapsed x=F.evaluate_functional(state.reference,target,.85,baseline.mu_prime;
            quadrature=F.imaginary_quadrature(order))
        push!(refinements,(physical_L,order,x.frequency_points,x.k_points,x.mu,x.mu_prime,
            x.omega,x.density,x.mu_prime_gradient,x.moment,x.omega-baseline.omega,
            x.density-baseline.density,x.mu_prime_gradient-baseline.mu_prime_gradient,
            x.moment-baseline.moment,seconds))
        V.write_csv(joinpath(output,"fixed_variable_convergence.csv"),
            "physical_L,quadrature_order,frequency_points,k_points,mu,mu_prime,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,Omega_drift_from_L48_q24,density_drift_from_L48_q24,gradient_drift_from_L48_q24,moment_drift_from_L48_q24,seconds",refinements)
        @printf("%s L=%d order=%d Omega_drift=%.3g density_drift=%.3g moment_drift=%.3g\n",
            string(now()),physical_L,order,x.omega-baseline.omega,x.density-baseline.density,x.moment-baseline.moment)
        flush(stdout)
    end
    all(V.filehash(joinpath(V.ROOT,s))==hashes[s] for s in sources) || error("source changed during audit")
    V.filehash(state.cache)==cachehash || error("reference cache changed during audit")
    open(provenance,"a") do io
        println(io,"Completed: ",now(),"; original source and cache hashes verified unchanged.")
        println(io,"All comparisons reuse one canonical reference Green function. L96 is a separate momentum refinement, not the paper's L48 setting.")
    end
    open(joinpath(output,"completed.txt"),"w") do io
        println(io,"Completed ",now())
        for name in ("provenance.txt","stationarity_evaluations.csv","stationary_roots.csv","common_shifts.csv","fixed_variable_convergence.csv")
            println(io,V.filehash(joinpath(output,name)),"  ",name)
        end
    end
    output
end

if abspath(PROGRAM_FILE)==@__FILE__
    println(audit_functional())
end
