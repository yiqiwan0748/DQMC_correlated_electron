#!/usr/bin/env julia

# Refine the stripe-field stationary point without fitting figure data.
# Each h candidate independently makes mu_prime stationary; side evaluations
# for the partial h derivative keep that candidate's mu_prime fixed.
using LinearAlgebra, SHA, Printf, Dates
include("prl_101_237004_vca_campaign.jl")
const V = PRL101237004VCACampaign
const F = V.F

function audit_minimum(;output=joinpath(V.DEFAULT_OUTPUT,"minimum_audit"))
    Threads.nthreads()==2 || error("run with JULIA_NUM_THREADS=2")
    BLAS.get_num_threads()==1 || error("run with OPENBLAS_NUM_THREADS=1")
    isfile(joinpath(output,"completed.txt")) && error("completed audit exists; preserve its provenance")
    mkpath(output)
    sources=vcat(V.SCAN_SOURCES,["scripts/audit_prl_101_237004_vca_minimum.jl"])
    hashes=Dict(source=>V.filehash(joinpath(V.ROOT,source)) for source in sources)
    for source in sources
        destination=joinpath(output,"source_snapshot",source)
        mkpath(dirname(destination))
        if isfile(destination)
            V.filehash(destination)==hashes[source] || error("audit snapshot differs: $source")
        else
            cp(joinpath(V.ROOT,source),destination)
        end
    end
    provenance=joinpath(output,"provenance.txt")
    open(provenance,"w") do io
        println(io,"Started: ",now(),"; Julia: ",VERSION)
        println(io,"Threads: Julia=",Threads.nthreads(),"; BLAS=",BLAS.get_num_threads(),"; ",BLAS.get_config())
        println(io,"Working directory: ",pwd())
        println(io,"Exact invocation: OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_vca_minimum.jl")
        println(io,"Parameters: U=1; J=.25; pdpi/pdsigma=-.2; stripe_y; open2x2 reference; Nup=Ndown=4; block_steps=48; seed=7.")
        println(io,"Physical mu=.85 fixed; L48 physical lattice; quadrature order24 for search.")
        println(io,"At each h: mu_prime stationarity gradient_atol=1e-9; full scan_points=9; initial follows nearest prior root, initially .85.")
        println(io,"Partial h derivative: central difference d=2e-4 at fixed optimized mu_prime. Search bracket [.04,.05], at most six candidates, derivative target1e-6.")
        println(io,"Final comparison: d=1e-4 at orders24 and48, with the same h and mu_prime; order48 center verifies moment and mu_prime gradient.")
        println(io,"No fitted or digitized figure data enters this calculation. Finite-difference stationarity is numerical evidence, not a strict error bound on the true derivative.")
        for source in sort(sources)
            println(io,hashes[source],"  ",source)
        end
    end

    states=Dict{Float64,Any}()
    caches=Dict{String,String}()
    reference_rows=Tuple[]
    function reference(h)
        h=Float64(h)
        haskey(states,h) && return states[h]
        state=V.reference_state(h,:stripe_y;block_steps=48)
        state.result.converged || error("Green function failed convergence at h=$h")
        digest=V.filehash(state.cache)
        caches[state.cache]=digest
        states[h]=state
        push!(reference_rows,(h,state.result.E0,state.result.ground_residual,
            maximum(ch.convergence_error for ch in state.result.channels),
            state.result.mu_interval...,state.cache,digest))
        V.write_csv(joinpath(output,"references.csv"),
            "h,canonical_E0,ground_residual,maximum_green_half_depth_difference,mu_prime_lower,mu_prime_upper,cache,cache_sha256",reference_rows)
        state
    end
    lat=V.embedding(reference(.04);physical_L=48)
    quadratures=Dict(order=>F.imaginary_quadrature(order) for order in (24,48))
    evaluations=Tuple[]
    function evaluate_at(h,mup,order,role,candidate)
        state=reference(h)
        seconds=@elapsed data=F.evaluate_functional(state.reference,lat,.85,mup;quadrature=quadratures[order])
        push!(evaluations,(candidate,role,h,mup,order,data.omega,data.density,
            data.mu_prime_gradient,data.moment,seconds,state.cache))
        V.write_csv(joinpath(output,"functional_evaluations.csv"),
            "candidate,role,h,mu_prime,quadrature_order,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,seconds,reference_cache",evaluations)
        data
    end
    scan_rows=Tuple[]
    root_rows=Tuple[]
    candidates=NamedTuple[]
    history=Tuple[]
    function candidate(h,bracket)
        # Explicit locals prevent these side evaluations from capturing the
        # outer search bracket or the later verification-loop temporaries.
        local id,state,initial,seconds,solved,center,d,left,right,gradient,partial_curvature,item
        id=length(candidates)+1
        state=reference(h)
        initial=isempty(candidates) ? .85 : candidates[argmin(abs(x.h-h) for x in candidates)].mu_prime
        seconds=@elapsed solved=V.stationary_point(state,lat;mu=.85,order=24,initial,gradient_atol=1e-9)
        center=solved.choice.data
        for mup in sort(collect(keys(solved.search.evaluation_cache)))
            x=solved.search.evaluation_cache[mup]
            push!(scan_rows,(id,h,mup,x.omega,x.density,x.mu_prime_gradient,x.moment))
        end
        for root in solved.search.roots
            push!(root_rows,(id,h,root.mu_prime,root.data.omega,root.data.density,
                root.gradient,root.status,root.iterations,root.bracket...))
        end
        V.write_csv(joinpath(output,"mu_prime_evaluations.csv"),
            "candidate,h,mu_prime,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe",scan_rows)
        V.write_csv(joinpath(output,"mu_prime_roots.csv"),
            "candidate,h,mu_prime,Omega_per_Fe,density,mu_prime_gradient,status,iterations,bracket_lower,bracket_upper",root_rows)
        d=2e-4
        left=evaluate_at(h-d,center.mu_prime,24,"h_minus_d",id)
        right=evaluate_at(h+d,center.mu_prime,24,"h_plus_d",id)
        gradient=(right.omega-left.omega)/(2d)
        partial_curvature=(right.omega-2center.omega+left.omega)/d^2
        item=(;id,h=Float64(h),mu_prime=center.mu_prime,center,left,right,d,gradient,partial_curvature)
        push!(candidates,item)
        push!(history,(id,h,center.mu_prime,center.omega,center.density,center.mu_prime_gradient,
            center.moment,d,gradient,partial_curvature,bracket...,solved.search.evaluations,
            length(solved.search.roots),seconds))
        V.write_csv(joinpath(output,"candidate_history.csv"),
            "candidate,h,mu_prime,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe,h_difference_step,h_derivative,partial_h_curvature,bracket_lower,bracket_upper,mu_prime_evaluations,mu_prime_root_count,stationarity_seconds",history)
        @printf("%s candidate%d h=%.12f mu_prime=%.12f Omega=%.12f h_derivative=%+.7g mu_prime_gradient=%.3g\n",
            string(now()),id,h,center.mu_prime,center.omega,gradient,center.mu_prime_gradient)
        flush(stdout)
        item
    end

    left=candidate(.04,(.04,.05))
    right=candidate(.05,(.04,.05))
    left.gradient<0<right.gradient || error("requested interval does not bracket a local minimum")
    selected=abs(left.gradient)<abs(right.gradient) ? left : right
    for iteration in 1:4
        width=right.h-left.h
        previous,current=candidates[end-1],candidates[end]
        denominator=current.gradient-previous.gradient
        proposal=current.h-current.gradient*(current.h-previous.h)/denominator
        if !(left.h+1e-3width<proposal<right.h-1e-3width)
            proposal=(left.h+right.h)/2
        end
        point=candidate(proposal,(left.h,right.h))
        if abs(point.gradient)<abs(selected.gradient)
            selected=point
        end
        if point.gradient<0
            left=point
        else
            right=point
        end
        (abs(point.gradient)<=1e-6 || right.h-left.h<=4e-6) && break
    end
    status=abs(selected.gradient)<=1e-6 ? :derivative_tolerance :
        right.h-left.h<=4e-6 ? :bracket_tolerance : :candidate_budget
    # Estimate the local envelope curvature from two independently optimized
    # candidates. This is only a scale for interpreting derivative changes.
    neighbors=filter(x->x.id!=selected.id && abs(x.h-selected.h)>1e-6,candidates)
    neighbor=neighbors[argmin(abs(x.h-selected.h) for x in neighbors)]
    envelope_curvature=(selected.gradient-neighbor.gradient)/(selected.h-neighbor.h)
    refinements=Tuple[]
    checks=NamedTuple[]
    for (d,order) in ((2e-4,24),(1e-4,24),(1e-4,48))
        if d==selected.d && order==24
            lo,center,hi=selected.left,selected.center,selected.right
        else
            lo=evaluate_at(selected.h-d,selected.mu_prime,order,"verification_minus",selected.id)
            hi=evaluate_at(selected.h+d,selected.mu_prime,order,"verification_plus",selected.id)
            center=evaluate_at(selected.h,selected.mu_prime,order,"verification_center",selected.id)
        end
        gradient=(hi.omega-lo.omega)/(2d)
        partial_curvature=(hi.omega-2center.omega+lo.omega)/d^2
        shift=-gradient/envelope_curvature
        push!(checks,(;d,order,gradient,partial_curvature,shift,center))
        push!(refinements,(selected.h,selected.mu_prime,d,order,gradient,
            gradient-selected.gradient,partial_curvature,envelope_curvature,shift,
            selected.h+shift,center.omega,center.density,center.mu_prime_gradient,center.moment))
        V.write_csv(joinpath(output,"derivative_verification.csv"),
            "h,mu_prime,h_difference_step,quadrature_order,h_derivative,derivative_change_from_search,partial_h_curvature,envelope_curvature_estimate,inferred_h_correction,corrected_h_estimate,Omega_per_Fe,density,mu_prime_gradient,moment_signed_muB_per_Fe",refinements)
        @printf("%s verify d=%.1g order%d h_derivative=%+.7g inferred_h_correction=%+.3g\n",
            string(now()),d,order,gradient,shift)
        flush(stdout)
    end
    richardson_gradient=(4checks[2].gradient-checks[1].gradient)/3
    all(V.filehash(joinpath(V.ROOT,s))==hashes[s] for s in sources) || error("source changed during audit")
    all(V.filehash(path)==digest for (path,digest) in caches) || error("cache changed during audit")
    open(joinpath(output,"summary.txt"),"w") do io
        println(io,"Search status: ",status,"; candidate count: ",length(candidates))
        println(io,"Selected h: ",selected.h,"; mu_prime: ",selected.mu_prime)
        println(io,"Remaining sign bracket for the d=2e-4 derivative: ",(left.h,right.h))
        println(io,"Selected center: ",selected.center)
        println(io,"Selected central derivative (d=2e-4): ",selected.gradient)
        println(io,"Envelope curvature estimate from candidate ",neighbor.id,": ",envelope_curvature)
        println(io,"Richardson derivative estimate from d=2e-4 and1e-4 at order24: ",richardson_gradient)
        println(io,"Richardson inferred h: ",selected.h-richardson_gradient/envelope_curvature)
        println(io,"Derivative target reached: ",abs(selected.gradient)<=1e-6)
        println(io,"Verification data: ",checks)
        println(io,"A negative-to-positive derivative bracket and positive local curvature support a local minimum on this stationary mu_prime branch.")
        println(io,"The search and Richardson correction are finite-difference estimates; no strict true-derivative or h-error bound is claimed.")
        println(io,"All physical mu values remain .85; side derivatives hold mu_prime fixed. Moment is signed for the +h Weiss convention; compare its magnitude to the paper.")
    end
    open(provenance,"a") do io
        println(io,"Completed: ",now(),"; source/cache hashes verified unchanged; search status: ",status)
    end
    open(joinpath(output,"completed.txt"),"w") do io
        println(io,"Completed ",now())
        for name in ("provenance.txt","references.csv","functional_evaluations.csv","mu_prime_evaluations.csv",
                     "mu_prime_roots.csv","candidate_history.csv","derivative_verification.csv","summary.txt")
            println(io,V.filehash(joinpath(output,name)),"  ",name)
        end
    end
    output
end

if abspath(PROGRAM_FILE)==@__FILE__
    println(audit_minimum())
end
