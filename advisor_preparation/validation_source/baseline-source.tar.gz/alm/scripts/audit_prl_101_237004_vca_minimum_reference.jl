#!/usr/bin/env julia

# Independent reference-state audit at the final finite-difference minimum.
# Reuse the earlier audit's numerical helpers without running its campaign.
include("audit_prl_101_237004_vca_sectors.jl")

function audit_minimum_reference()
    isempty(ARGS) || error("canonical minimum audit takes no arguments")
    check_audit_threads()
    h=0.04630403476683797
    mup=0.8622314233131982
    out=joinpath(V.DEFAULT_OUTPUT,"minimum_reference_audit")
    ispath(out) && error("audit output already exists; preserve its provenance")
    input=joinpath(V.DEFAULT_OUTPUT,"minimum_audit")
    input_names=("candidate_history.csv","summary.txt","completed.txt")
    input_hashes=Dict(name=>V.filehash(joinpath(input,name)) for name in input_names)
    history=readlines(joinpath(input,"candidate_history.csv"))
    selected=Dict(split(first(history),',').=>split(last(history),','))
    parse(Float64,selected["h"])==h && parse(Float64,selected["mu_prime"])==mup ||
        error("canonical minimum differs from this bounded audit's fixed target")
    hashes=audit_source_hashes()
    hashes["scripts/audit_prl_101_237004_vca_minimum_reference.jl"]=V.filehash(@__FILE__)
    mkpath(out)
    for (source,hash) in hashes
        destination=joinpath(out,"source_snapshot",source)
        mkpath(dirname(destination))
        cp(joinpath(V.ROOT,source),destination)
        V.filehash(destination)==hash || error("source snapshot changed during copy")
    end
    for name in input_names
        destination=joinpath(out,"minimum_inputs",name)
        mkpath(dirname(destination))
        cp(joinpath(input,name),destination)
    end
    kinetics=V.G.weiss_kinetics(V.G.rectangular_cluster(),h;channel=:stripe_y)
    seconds=@elapsed audit=A.audit_reference_ground(kinetics.up,kinetics.down,1.0,4,4;J=.25)
    A.write_reference_audit(audit,out;physical_metadata=Dict{String,Any}(
        "h"=>h,"mu_prime"=>mup,"channel"=>"stripe_y","cluster"=>"open 2x2 Fe",
        "weiss_convention"=>"+h sum_i p_i(n_up-n_down), both orbitals, no factor 1/2",
        "original_PRL_t4"=>true,"ratio_pdpi_pdsigma"=>-.2,
        "Julia_threads"=>Threads.nthreads(),"BLAS_threads"=>BLAS.get_num_threads(),
        "all_sector_wall_seconds"=>seconds))
    stability=A.reference_stability(audit,mup)
    V.write_csv(joinpath(out,"stationary_sector_comparisons.csv"),
        "Nup,Ndown,N,Omega_difference_from_target",
        [(r.Nup,r.Ndown,r.N,r.omega_difference) for r in stability.differences])
    println(now()," all81 sectors done; mu interval=",audit.mu_interval,
        "; stable at selected mu_prime=",stability.stable);flush(stdout)
    shallow=V.reference_state(h,:stripe_y;block_steps=48)
    deep=V.reference_state(h,:stripe_y;block_steps=96)
    all(r.K_up==audit.K_up && r.K_down==audit.K_down for r in (shallow.result,deep.result)) ||
        error("cached reference kinetics differ")
    green_rows=Tuple[];moment_rows=Tuple[]
    for spin in (:up,:down)
        for omega in AUDIT_FREQUENCIES
            gs=V.C.cluster_green(shallow.result,im*omega;mu_prime=mup,spin)
            gd=V.C.cluster_green(deep.result,im*omega;mu_prime=mup,spin)
            ds=V.C.green_mu_derivative(shallow.result,im*omega;mu_prime=mup,spin)
            dd=V.C.green_mu_derivative(deep.result,im*omega;mu_prime=mup,spin)
            push!(green_rows,(spin,omega,norm(gs-gd),maximum(abs,gs-gd),norm(gs-gd)/norm(gd),norm(ds-dd)))
        end
        ms=V.C.spectral_moments(shallow.result;spin,mu_prime=mup)
        md=V.C.spectral_moments(deep.result;spin,mu_prime=mup)
        ps,pd=pole_moments(shallow.result,spin,mup),pole_moments(deep.result,spin,mup)
        for order in 0:2
            push!(moment_rows,(spin,order,norm(ms[order+1]-md[order+1]),
                norm(ps[order+1]-ms[order+1]),norm(pd[order+1]-md[order+1])))
        end
    end
    V.write_csv(joinpath(out,"green_depth.csv"),
        "spin,imaginary_omega,difference_Frobenius,difference_max_entry,relative_difference_Frobenius,mu_derivative_difference_Frobenius",green_rows)
    V.write_csv(joinpath(out,"moments_depth.csv"),
        "spin,moment_order,exact_moment_difference_48_96,pole_moment_error_48,pole_moment_error_96",moment_rows)
    minimum_other=minimum(r.omega_difference for r in stability.differences if (r.Nup,r.Ndown)!=(4,4))
    summary=(h,mup,audit.target.energy,audit.target.residual,maximum(r.residual for r in audit.rows),
        stability.stable,minimum_other,audit.mu_interval...,audit.target_lowest_at_same_N,
        abs(audit.target.energy-shallow.result.E0),abs(shallow.result.E0-deep.result.E0),
        maximum(r[3] for r in green_rows),maximum(r[5] for r in green_rows),
        maximum(r[6] for r in green_rows),maximum(max(r[4],r[5]) for r in moment_rows))
    V.write_csv(joinpath(out,"summary.csv"),
        "h,mu_prime,target_E0,target_residual,maximum_sector_residual,stable_against_all_computed_sectors,minimum_other_sector_Omega_difference,all_N_mu_lower,all_N_mu_upper,target_lowest_at_same_N,target_E0_difference_from_cache,E0_difference_48_96,max_green_difference_Frobenius,max_green_relative_difference,max_mu_derivative_difference_Frobenius,max_pole_moment_error",[summary])
    provenance=Dict{String,Any}("created_utc"=>string(now(UTC)),"julia_version"=>string(VERSION),
        "Julia_threads"=>Threads.nthreads(),"BLAS_threads"=>BLAS.get_num_threads(),
        "invocation"=>"OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. scripts/audit_prl_101_237004_vca_minimum_reference.jl",
        "source_sha256"=>hashes,"minimum_input_sha256"=>input_hashes,
        "cache_sha256"=>Dict(relpath(s.cache,V.ROOT)=>V.filehash(s.cache) for s in (shallow,deep)),
        "requested_depths"=>[48,96],"imaginary_frequencies"=>collect(AUDIT_FREQUENCIES),
        "krylov_dimensions_48"=>[c.krylov_dimension for c in shallow.result.channels],
        "krylov_dimensions_96"=>[c.krylov_dimension for c in deep.result.channels],
        "limits"=>"Reference grand-ground sufficiency is conditional on numerically computed sector minima. Direct residuals alone do not rigorously certify lowest roots. Green comparisons cover both spin matrices at the six stated imaginary frequencies and this one selected h/mu_prime. This does not further refine the finite-difference h minimum.")
    open(joinpath(out,"provenance.toml"),"w") do io
        TOML.print(io,provenance;sorted=true)
    end
    all(V.filehash(joinpath(V.ROOT,s))==hash for (s,hash) in hashes) || error("source changed during audit")
    all(V.filehash(joinpath(input,n))==hash for (n,hash) in input_hashes) || error("minimum inputs changed during audit")
    names=("metadata.toml","provenance.toml","summary.csv","green_depth.csv","moments_depth.csv",
           "sectors.csv","particle_minima.csv","stationary_sector_comparisons.csv","K_up.csv","K_down.csv")
    open(joinpath(out,"completed.toml"),"w") do io
        TOML.print(io,Dict("completed_utc"=>string(now(UTC)),
            "output_sha256"=>Dict(n=>V.filehash(joinpath(out,n)) for n in names));sorted=true)
    end
    println("summary: ",summary)
    return out
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && println(audit_minimum_reference())
