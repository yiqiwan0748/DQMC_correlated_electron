#!/usr/bin/env julia

# Re-evaluate every completed Fig. 2(b) point with twice the imaginary-axis
# quadrature order, keeping both chemical potentials fixed. Also check the
# common chemical-potential plateau at the zero-field state and endpoints.
include("prl_101_237004_vca_campaign.jl")
using .PRL101237004VCACampaign
using LinearAlgebra, Dates, SHA
const V=PRL101237004VCACampaign

function read_scan(path)
    isfile(path) || error("completed scan required: $path")
    lines=readlines(path)
    names=split(first(lines),',')
    [Dict(zip(names,split(line,','))) for line in lines[2:end]]
end

function main(;output_dir=joinpath(V.DEFAULT_OUTPUT,"scan_audit"),
              scan_dir=joinpath(V.DEFAULT_OUTPUT,"scans","fig2b_L48_q24"))
    isempty(ARGS) || error("CLI takes no arguments; use main(;output_dir,scan_dir) from Julia for alternate paths")
    BLAS.set_num_threads(1)
    out=abspath(output_dir)
    ispath(out) && error("audit directory already exists: $out")
    input=abspath(scan_dir)
    inputs=[joinpath(input,string(c)*".csv") for c in (:stripe_y,:neel)]
    scans=read_scan.(inputs)
    sources=vcat([relpath(@__FILE__,V.ROOT)],V.SCAN_SOURCES)
    hashes=Dict(source=>V.filehash(joinpath(V.ROOT,source)) for source in sources)
    mkpath(out)
    for source in sources
        target=joinpath(out,"source_snapshot",source)
        mkpath(dirname(target))
        cp(joinpath(V.ROOT,source),target)
    end
    rows=Tuple[]; plateau=Tuple[]
    q48=V.F.imaginary_quadrature(48)
    open(joinpath(out,"provenance.txt"),"w") do io
        println(io,"Started: ",now(),"; Julia ",VERSION,"; threads=",Threads.nthreads(),"; BLAS=",BLAS.get_num_threads())
        println(io,"Canonical command: OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. scripts/audit_prl_101_237004_vca_scan.jl")
        println(io,"Input scan directory: ",input,"; output directory: ",out)
        println(io,"Fixed-variable q24 versus q48; neither chemical potential is reoptimized in this audit.")
        println(io,"Common shifts use q48 and retain the original canonical cluster state. A finite set of plateau checks is not a spectral-gap bound.")
        for source in sources
            println(io,hashes[source],"  ",source)
        end
        for path in inputs
            println(io,V.filehash(path),"  ",relpath(path,V.ROOT))
        end
    end
    for (channel,scan,expected) in zip((:stripe_y,:neel),scans,(collect(0:20)./200,collect(0:4)./200))
        length(scan)==length(expected) || error("incomplete scan")
        for (row,h_expected) in zip(scan,expected)
            h=parse(Float64,row["h"])
            h==h_expected && Symbol(row["channel"])==channel || error("wrong field grid/channel")
            parse(Float64,row["U"])==1 && parse(Float64,row["J"])==.25 &&
                parse(Float64,row["ratio"])==-.2 && parse(Int,row["physical_L"])==48 &&
                parse(Int,row["block_steps"])==48 && parse(Int,row["quadrature_order"])==24 || error("wrong scan parameters")
            mu=parse(Float64,row["mu"]); mup=parse(Float64,row["mu_prime"])
            mu==.85 || error("physical mu changed")
            state=V.reference_state(h,channel)
            state.result.converged || error("reference probe convergence failed")
            lat=V.embedding(state;physical_L=48)
            refined=V.F.evaluate_functional(state.reference,lat,mu,mup;quadrature=q48)
            dOmega=refined.omega-parse(Float64,row["Omega_per_Fe"])
            dn=refined.density-parse(Float64,row["density"])
            dg=refined.mu_prime_gradient-parse(Float64,row["mu_prime_gradient"])
            dm=refined.moment-parse(Float64,row["moment_signed_muB_per_Fe"])
            push!(rows,(channel,h,mup,refined.omega,refined.density,refined.mu_prime_gradient,refined.moment,
                dOmega,dn,dg,dm,V.filehash(state.cache)))
            V.write_csv(joinpath(out,"quadrature.csv"),
                "channel,h,mu_prime,Omega_q48,density_q48,mu_prime_gradient_q48,moment_q48,delta_Omega_48_minus_24,delta_density,delta_gradient,delta_moment,reference_cache_sha256",rows)
            if (channel==:stripe_y && h in (0.0,.1)) || (channel==:neel && h==.02)
                for delta in (-.05,-.02,.02,.05)
                    shifted=V.F.evaluate_functional(state.reference,lat,mu+delta,mup+delta;quadrature=q48)
                    push!(plateau,(channel,h,delta,shifted.omega,shifted.density,shifted.mu_prime_gradient,shifted.moment,
                        shifted.omega+2delta-refined.omega,shifted.density-refined.density,shifted.moment-refined.moment))
                end
                V.write_csv(joinpath(out,"common_shifts.csv"),
                    "channel,h,delta_mu_and_mu_prime,Omega,density,mu_prime_gradient,moment,Omega_plus_2delta_minus_baseline,delta_density,delta_moment",plateau)
            end
            println(channel," h=",h," q48-q24 Omega=",dOmega," gradient=",refined.mu_prime_gradient)
            flush(stdout)
        end
    end
    all(V.filehash(joinpath(V.ROOT,source))==hashes[source] for source in sources) || error("source changed during audit")
    open(joinpath(out,"completed.txt"),"w") do io
        println(io,"Completed: ",now(),"; ",length(rows)," fixed-variable refinements and ",length(plateau)," common-shift checks.")
        println(io,"Maximum absolute q48-q24 differences: Omega=",maximum(abs(r[8]) for r in rows),
            "; density=",maximum(abs(r[9]) for r in rows),"; gradient=",maximum(abs(r[10]) for r in rows),
            "; moment=",maximum(abs(r[11]) for r in rows))
        println(io,"Maximum common-shift drifts: corrected Omega=",maximum(abs(r[8]) for r in plateau),
            "; density=",maximum(abs(r[9]) for r in plateau),"; moment=",maximum(abs(r[10]) for r in plateau))
        println(io,"All numerical source hashes verified unchanged.")
    end
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
