#!/usr/bin/env julia

module TwoOrbitalSpinAudit

using SHA

# This inclusion loads only Julia standard libraries, never DEAC or a sampler.
module SpectralChannels
include(joinpath(@__DIR__, "continue_two_orbital_spectrum.jl"))
end
const SC = SpectralChannels

export audit_spins, rebin_data, momentum_indices, main

function usage(io=stdout)
    print(io, """
Usage: julia --project=. audit_two_orbital_spins.jl DATA.jls [options]

Read saved measurements; no DQMC or analytic continuation is performed.
Report actual parameters, sign and density, and orbital-summed up/down G
at X, Y and the momentum average. Differences use a paired ratio jackknife.

  --output-dir=PATH   Save metadata and per-channel CSVs (default: stdout only).
  --tau-stride=INT    Retain every INT-th tau and both endpoints. [1]
  --rebin=INT         Combine adjacent bins within each source chain. [1]
  --minimum-sign=X    Minimum absolute full/delete-one-bin sign. [0.05]
  --help             Print this help.

Rebinning requires equal original Green counts and a factor dividing each
source chain's bin count. Compare errors for several blocking choices; this
report does not establish sampling convergence or a magnetic phase.
Existing output directories are never overwritten.
""")
end

function parse_options(arguments)
    any(arg -> arg in ("--help", "-h"), arguments) && return nothing
    paths = String[]
    output_dir = nothing
    tau_stride, rebin = 1, 1
    minimum_sign = 0.05
    for argument in arguments
        if !startswith(argument, "--")
            push!(paths, argument)
            continue
        end
        parts = split(argument, '='; limit=2)
        length(parts) == 2 && !isempty(parts[2]) || error("Use --name=value: $argument")
        name, value = parts
        if name == "--output-dir"
            output_dir = abspath(value)
        elseif name == "--tau-stride"
            tau_stride = parse(Int, value)
        elseif name == "--rebin"
            rebin = parse(Int, value)
        elseif name == "--minimum-sign"
            minimum_sign = parse(Float64, value)
        else
            error("Unknown option: $name")
        end
    end
    length(paths) == 1 || error("Supply exactly one observable DATA.jls file")
    tau_stride >= 1 && rebin >= 1 || error("tau-stride and rebin must be positive")
    isfinite(minimum_sign) && 0 <= minimum_sign < 1 || error("minimum-sign must lie in [0,1)")
    return (; input=abspath(only(paths)), output_dir, tau_stride, rebin, minimum_sign)
end

function momentum_indices(data)
    # The only intended matching tolerance is roundoff in the stored radian grid.
    atol = 256eps(Float64) * 2pi
    zero_indices = findall(k -> abs(rem2pi(k, RoundNearest)) <= atol, data.momenta)
    pi_indices = findall(k -> abs(abs(rem2pi(k, RoundNearest)) - pi) <= atol, data.momenta)
    length(zero_indices) == 1 && length(pi_indices) == 1 || error(
        "X and Y require unique 0 and pi components; use an even periodic lattice",
    )
    z, p = only(zero_indices), only(pi_indices)
    return (X=(p, z), Y=(z, p))
end

function bin_groups(data, factor)
    factor >= 1 || error("rebin must be positive")
    n = length(data.counts)
    all(==(first(data.counts)), data.counts) || error(
        "Unequal Green bin counts do not support this equal-block jackknife",
    )
    lengths = if haskey(data.metadata, "source_metadata")
        [Int(item["bin_count"]) for item in data.metadata["source_metadata"]]
    elseif get(data.metadata, "chain_count", 1) > 1 && factor > 1
        error("Rebinning pooled data requires source_metadata with chain boundaries")
    else
        [n]
    end
    all(>(0), lengths) && sum(lengths) == n || error("Invalid source-chain bin counts")
    all(length -> length % factor == 0, lengths) || error(
        "rebin=$factor must divide each source chain's bin count $(lengths)",
    )
    groups = UnitRange{Int}[]
    offset = 0
    for length in lengths
        for start in 1:factor:length
            push!(groups, (offset + start):(offset + start + factor - 1))
        end
        offset += length
    end
    length(groups) >= 2 || error("At least two analysis bins must remain")
    return groups
end

function rebin_data(data, factor::Integer)
    groups = bin_groups(data, factor)
    factor == 1 && return data, groups
    greens = zeros(eltype(data.greens), length(groups), size(data.greens)[2:end]...)
    for (output_bin, group) in pairs(groups), input_bin in group
        selectdim(greens, 1, output_bin) .+= selectdim(data.greens, 1, input_bin)
    end
    sign_sums = [sum(view(data.sign_sums, group)) for group in groups]
    counts = [sum(view(data.counts, group)) for group in groups]
    return merge(data, (; greens, sign_sums, counts)), groups
end

statistics(numerators, signs, counts, minimum_sign) = SC.sign_reweighted_statistics(
    numerators, signs, counts, minimum_sign;
    require_noisy=false, require_positive=false,
)

function sign_statistics(data)
    result = statistics(reshape(data.sign_sums, :, 1), data.counts, data.counts, 0.0)
    return (value=only(result.values), se=only(result.standard_errors))
end

function scalar_statistics(data, groups, minimum_sign)
    basic = get(data.payload, "basic_bins", nothing)
    basic isa AbstractDict && haskey(basic, "density") && haskey(basic, "average_sign") ||
        return (status="unavailable",)
    n = length(data.payload["green_counts"])
    for name in ("density", "average_sign")
        values = basic[name]
        values isa AbstractVector{<:Number} && length(values) == n ||
            error("Scalar $name must be a numeric vector matching the Green bin axis")
        all(value -> isfinite(real(value)) && isfinite(imag(value)), values) ||
            error("Scalar $name contains a non-finite value")
    end
    # Signs are real numbers in [-1,1]; allow only Float64 roundoff here.
    sign_tolerance = 256eps(Float64)
    all(value -> abs(value) <= 1 + sign_tolerance && abs(imag(value)) <= sign_tolerance,
        basic["average_sign"]) || error("Scalar average_sign must be real and lie in [-1,1]")
    maximum_density_imaginary = maximum(abs ∘ imag, basic["density"])
    # The standalone serializer stores signed scalar means in equal-size bins.
    if haskey(data.metadata, "source_metadata")
        sizes = [source["measurements_per_bin"] for source in data.metadata["source_metadata"]]
        all(==(first(sizes)), sizes) || error("Scalar source bins have unequal sizes")
    end
    signs = [sum(real.(view(basic["average_sign"], group))) for group in groups]
    counts = length.(groups)
    density = reshape([sum(real.(view(basic["density"], group))) for group in groups], :, 1)
    sign = statistics(reshape(signs, :, 1), counts, counts, 0.0)
    density_result = try
        statistics(density, signs, counts, minimum_sign)
    catch exception
        return (status="density unavailable: " * sprint(showerror, exception),
                sign=only(sign.values), sign_se=only(sign.standard_errors),
                maximum_density_imaginary=maximum_density_imaginary)
    end
    return (status="available", sign=only(sign.values), sign_se=only(sign.standard_errors),
            density=only(density_result.values), density_se=only(density_result.standard_errors),
            maximum_density_imaginary=maximum_density_imaginary)
end

function endpoint(result)
    covariance = result.covariance
    variance = covariance[1,1] + covariance[end,end] + 2covariance[1,end]
    return (value=first(result.values) + last(result.values), se=sqrt(max(0.0, variance)))
end

function channel_statistics(data, mode, kx, ky, time_indices, minimum_sign)
    # Each returned curve is physical: two orbital states per spin.
    up_bins = 2 .* SC.trace_numerator_bins(data, mode, kx, ky, time_indices; spin=:up)
    down_bins = 2 .* SC.trace_numerator_bins(data, mode, kx, ky, time_indices; spin=:down)
    up = statistics(up_bins, data.sign_sums, data.counts, minimum_sign)
    down = statistics(down_bins, data.sign_sums, data.counts, minimum_sign)
    difference = statistics(up_bins .- down_bins, data.sign_sums, data.counts, minimum_sign)
    total = statistics(up_bins .+ down_bins, data.sign_sums, data.counts, minimum_sign)
    z = [se > 0 ? value / se : (iszero(value) ? 0.0 : copysign(Inf, value))
         for (value, se) in zip(difference.values, difference.standard_errors)]
    return (; up, down, difference, total, z, up_endpoint=endpoint(up), down_endpoint=endpoint(down))
end

function audit_spins(data; tau_stride=1, rebin=1, minimum_sign=0.05)
    locations = momentum_indices(data)
    blocked, groups = rebin_data(data, rebin)
    time_indices = SC.selected_tau_indices(length(data.tau), tau_stride)
    channels = Dict{String,Any}()
    for (label, mode, kx, ky) in (
        ("X", :ktrace, locations.X...), ("Y", :ktrace, locations.Y...), ("DOS", :dos, 1, 1),
    )
        channels[label] = try
            (status="available", result=channel_statistics(
                blocked, mode, kx, ky, time_indices, minimum_sign), kx=kx, ky=ky)
        catch exception
            (status="unavailable", reason=sprint(showerror, exception), kx=kx, ky=ky)
        end
    end
    return (; channels, time_indices, tau=data.tau[time_indices], locations,
            rebin, analysis_bins=length(groups), sign=sign_statistics(blocked),
            scalar=scalar_statistics(data, groups, minimum_sign),
            maximum_stabilization_error=data.maximum_stabilization_error)
end

function print_report(io, data, report, input, source_hash)
    println(io, "Source payload = ", input)
    println(io, "Source SHA256 = ", source_hash)
    for key in ("U", "beta", "L", "Ltau", "dtau", "mu_start", "mu_measured",
                "target_density", "t1", "t2", "t3", "t4", "seed", "source_seeds",
                "chain_count", "stabilization_period", "burnin_sweeps", "tuning_sweeps",
                "measurement_count", "bin_count", "measurements_per_bin", "greens_every", "atomic_check")
        println(io, key, " = ", get(data.metadata, key, "not recorded"))
    end
    println(io, "Green axes = ", data.payload["green_axes"])
    println(io, "Green shape = ", size(data.greens))
    println(io, "Rebin factor = ", report.rebin, "; analysis bins = ", report.analysis_bins)
    println(io, "Green average sign = ", report.sign.value, " +/- ", report.sign.se)
    println(io, "Scalar statistics = ", report.scalar)
    println(io, "Maximum Green stabilization correction = ", report.maximum_stabilization_error)
    for label in ("X", "Y", "DOS")
        channel = report.channels[label]
        if channel.status != "available"
            println(io, label, ": ", channel.reason)
            continue
        end
        result = channel.result
        println(io, label, " indices = ", label == "DOS" ? "all momenta" : (channel.kx, channel.ky))
        println(io, label, " max |G_up-G_down| = ", maximum(abs, result.difference.values))
        println(io, label, " max |pointwise difference/SE| = ", maximum(abs, result.z))
        println(io, label, " G_up(0)+G_up(beta) = ", result.up_endpoint, "; expected 2")
        println(io, label, " G_down(0)+G_down(beta) = ", result.down_endpoint, "; expected 2")
        println(io, label, " maximum discarded imaginary component = ",
                max(result.up.maximum_imaginary, result.down.maximum_imaginary))
    end
    println(io, "Errors assume independent analysis bins; compare blocking choices and source chains.")
    println(io, "Pointwise z values are descriptive, not a joint significance or ordering test.")
    println(io, "Zero-field spin equality is expected; this report makes no phase or production-readiness claim.")
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    isnothing(options) && return usage()
    isnothing(options.output_dir) || !ispath(options.output_dir) || error(
        "Refusing to replace existing output: $(options.output_dir)",
    )
    data = SC.load_and_validate_payload(options.input)
    report = audit_spins(data; options.tau_stride, options.rebin, options.minimum_sign)
    source_hash = open(options.input) do io
        bytes2hex(sha256(io))
    end
    print_report(stdout, data, report, options.input, source_hash)
    if !isnothing(options.output_dir)
        mkpath(options.output_dir)
        open(joinpath(options.output_dir, "audit_summary.txt"), "w") do io
            print_report(io, data, report, options.input, source_hash)
        end
        for label in ("X", "Y", "DOS")
            channel = report.channels[label]
            channel.status == "available" || continue
            result = channel.result
            table = hcat(report.tau, result.up.values, result.up.standard_errors,
                         result.down.values, result.down.standard_errors,
                         result.difference.values, result.difference.standard_errors, result.z,
                         result.total.values, result.total.standard_errors)
            SC.write_numeric_csv(joinpath(options.output_dir, label * "_spin_greens.csv"),
                ["tau", "G_up", "G_up_se", "G_down", "G_down_se", "G_up_minus_down",
                 "difference_paired_se", "pointwise_z", "G_total", "G_total_se"], table)
            SC.write_covariance_csv(joinpath(options.output_dir, label * "_difference_covariance.csv"),
                report.tau, result.difference.covariance)
        end
        println("Saved audit = ", options.output_dir)
    end
    return report
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    try
        TwoOrbitalSpinAudit.main()
    catch exception
        println(stderr, "ERROR: ", sprint(showerror, exception))
        exit(1)
    end
end
