#!/usr/bin/env julia

# A small analytic-continuation benchmark with a known interacting answer.
# The two-orbital Hubbard atom has only 16 many-body states, so its imaginary-
# time Green function and delta-function spectral peaks are obtained by exact
# diagonalization before SmoQyDEAC sees the data.

using DelimitedFiles

import SmoQyDEAC

include(joinpath(@__DIR__, "two_orbital_atom_ed.jl"))
using .TwoOrbitalAtomED

function usage()
    println(
        "Usage: julia --threads=auto --project=deac_env ",
        "benchmark_two_orbital_atom_deac.jl U beta mu ",
        "[--error=0.001] [--tau-points=101] ",
        "[--omega-min=-6] [--omega-max=6] [--omega-points=301] ",
        "[--deac-bins=2] [--runs-per-bin=5] [--generations=10000] ",
        "[--base-seed=8675309] [--output-dir=atom_deac_benchmark]",
    )
end

if "--help" in ARGS || "-h" in ARGS
    usage()
    exit()
end
length(ARGS) >= 3 || (usage(); error("U, beta, and mu are required"))

U = parse(Float64, ARGS[1])
beta = parse(Float64, ARGS[2])
mu = parse(Float64, ARGS[3])

options = Dict{String,String}()
for argument in ARGS[4:end]
    startswith(argument, "--") && occursin('=', argument) ||
        error("options must have the form --name=value: $argument")
    name, value = split(argument[3:end], "="; limit=2)
    haskey(options, name) && error("option supplied twice: --$name")
    options[name] = value
end

allowed = Set([
    "error",
    "tau-points",
    "omega-min",
    "omega-max",
    "omega-points",
    "deac-bins",
    "runs-per-bin",
    "generations",
    "base-seed",
    "output-dir",
])
unknown = setdiff(Set(keys(options)), allowed)
isempty(unknown) || error("unknown options: $(join(sort!(collect(unknown)), ", "))")

get_float(name, default) = parse(Float64, get(options, name, string(default)))
get_int(name, default) = parse(Int, get(options, name, string(default)))

reported_error = get_float("error", 1.0e-3)
tau_points = get_int("tau-points", 101)
omega_min = get_float("omega-min", -6.0)
omega_max = get_float("omega-max", 6.0)
omega_points = get_int("omega-points", 301)
deac_bins = get_int("deac-bins", 2)
runs_per_bin = get_int("runs-per-bin", 5)
generations = get_int("generations", 10_000)
base_seed = get_int("base-seed", 8_675_309)
output_dir = abspath(get(options, "output-dir", "atom_deac_benchmark"))

isfinite(reported_error) && reported_error > 0 ||
    error("--error must be finite and positive")
tau_points >= 3 || error("--tau-points must be at least 3")
omega_points >= 3 || error("--omega-points must be at least 3")
omega_min < omega_max || error("omega-min must be smaller than omega-max")
deac_bins > 1 || error("--deac-bins must be at least 2")
runs_per_bin > 0 || error("--runs-per-bin must be positive")
generations > 0 || error("--generations must be positive")

tau = collect(range(0.0, beta; length=tau_points))
omega = collect(range(omega_min, omega_max; length=omega_points))
exact = solve_two_orbital_atom(U, mu, beta, tau)

mkpath(output_dir)
output_file = joinpath(output_dir, "atom_deac.jld2")
checkpoint_file = joinpath(output_dir, "atom_deac_checkpoint.jld2")

println("Exact Hubbard-atom peaks:")
for (frequency, weight) in zip(
    exact.peak_frequencies,
    exact.peak_weights,
)
    println("  omega = $frequency, weight = $weight")
end
println("Running SmoQyDEAC with a stated pointwise error of $reported_error")

result = SmoQyDEAC.DEAC_Std(
    exact.green,
    fill(reported_error, length(tau)),
    beta,
    tau,
    omega,
    "time_fermionic",
    deac_bins,
    runs_per_bin,
    output_file,
    checkpoint_file;
    base_seed=base_seed,
    number_of_generations=generations,
    keep_bin_data=true,
    autoresume_from_checkpoint=true,
    find_fitness_floor=false,
    verbose=false,
)

spectral_matrix = result["A"]
error_matrix = result["σ"]
spectrum = vec(spectral_matrix[:, 1])
spectrum_error = vec(error_matrix[:, 1])
broadened = broaden_spectral_peaks(
    exact,
    omega;
    eta=max(0.05, 2 * (omega[2] - omega[1])),
)

# Reconstruct G(tau) using the same no-leading-minus fermionic kernel. The
# trapezoidal weights are sufficient for this diagnostic on an even omega grid.
weights = fill(omega[2] - omega[1], length(omega))
weights[1] /= 2
weights[end] /= 2
reconstructed = similar(tau)
for (time_index, time) in pairs(tau)
    kernel = similar(omega)
    for (omega_index, frequency) in pairs(omega)
        kernel[omega_index] = frequency >= 0 ?
            exp(-time * frequency) / (1 + exp(-beta * frequency)) :
            exp((beta - time) * frequency) /
                (1 + exp(beta * frequency))
    end
    reconstructed[time_index] = sum(weights .* kernel .* spectrum)
end
maximum_green_error = maximum(abs.(reconstructed .- exact.green))

writedlm(
    joinpath(output_dir, "atom_deac_spectrum.csv"),
    hcat(omega, spectrum, spectrum_error, broadened.spectrum),
    ',',
)
writedlm(
    joinpath(output_dir, "atom_deac_green.csv"),
    hcat(tau, exact.green, reconstructed),
    ',',
)
open(joinpath(output_dir, "README.txt"), "w") do io
    println(io, "Columns in atom_deac_spectrum.csv:")
    println(io, "omega, DEAC_A, DEAC_sigma, exact_Lorentzian_reference")
    println(io, "Columns in atom_deac_green.csv:")
    println(io, "tau, exact_G, G_reconstructed_from_DEAC")
    println(io, "Exact peak frequencies = ", exact.peak_frequencies)
    println(io, "Exact peak weights = ", exact.peak_weights)
    println(io, "DEAC zeroth moment = ", result["zeroth_moment"])
    println(io, "Maximum reconstructed-G error = ", maximum_green_error)
end

println("DEAC zeroth moment = ", result["zeroth_moment"])
println("Exact zeroth moment = ", exact.spectral_zeroth_moment)
println("Maximum reconstructed-G error = ", maximum_green_error)
println("Saved benchmark outputs in $output_dir")
println(
    "This smoke benchmark checks the continuation pipeline. Peak widths and ",
    "fine line shapes are not exact observables of analytic continuation.",
)
