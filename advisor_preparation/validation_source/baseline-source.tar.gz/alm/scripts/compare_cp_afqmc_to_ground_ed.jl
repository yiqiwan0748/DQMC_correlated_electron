#!/usr/bin/env julia

module CompareCPAFQMCToGroundED

include(joinpath(@__DIR__, "two_orbital_cluster_ed.jl"))

using .TwoOrbitalClusterED

export parse_options,
       read_cp_output,
       validate_matched_runs,
       pool_independent_estimates,
       compare_cp_afqmc_to_ground_ed,
       write_comparison,
       run_comparison,
       main

const REQUIRED_SUMMARY_QUANTITIES = (
    "mixed_energy",
    "backpropagated_energy",
    "backpropagated_double_occupancy_per_cell",
    "S_alm_q0",
)

const REQUIRED_METADATA_KEYS = (
    "method",
    "hamiltonian",
    "boundary",
    "l",
    "u",
    "nup",
    "ndown",
    "dtau",
    "seed",
    "trial",
)

const POOL_CONTROL_KEYS = (
    "trial",
    "field_strength",
    "dtau",
    "walkers",
    "warmup",
    "measurements",
    "steps_between",
    "orthogonalize_every",
    "population_control_every",
    "overlap_refresh_every",
    "back_propagation_steps",
    "minimum_backprop_ancestors",
    "block_size",
)

const HELP = """
Compare saved periodic L=2 CP-AFQMC estimates with canonical ground-state ED.

Usage:
  julia --project=. scripts/compare_cp_afqmc_to_ground_ed.jl \\
      --output-dir=results/cp_ground_ed_comparison CP_OUTPUT_DIR [CP_OUTPUT_DIR ...]

Every CP output directory must contain summary.csv and metadata.txt produced by
scripts/run_constrained_path_afqmc.jl. Inputs must use the same L, U, Nup,
Ndown, periodic boundary, and centered two-orbital Hamiltonian. Runs are pooled
only when all recorded controls except the random seed match. The output
directory must not already exist.
"""

_normalize_text(value) = lowercase(join(split(strip(String(value))), " "))

function _parse_integer(value, label)
    parsed = try
        parse(Int, strip(String(value)))
    catch
        throw(ArgumentError("$label must be an integer"))
    end
    return parsed
end

function _parse_real(value, label; nonnegative=false)
    parsed = try
        parse(Float64, strip(String(value)))
    catch
        throw(ArgumentError("$label must be a real number"))
    end
    isfinite(parsed) || throw(ArgumentError("$label must be finite"))
    nonnegative && parsed < 0 && throw(ArgumentError(
        "$label must be nonnegative",
    ))
    return parsed
end

function parse_options(arguments=ARGS)
    any(argument -> argument in ("--help", "-h"), arguments) && return nothing
    output_dir = abspath("results/cp_ground_ed_comparison")
    output_seen = false
    input_dirs = String[]
    for argument in arguments
        if startswith(argument, "--output-dir=")
            output_seen && throw(ArgumentError("duplicate option --output-dir"))
            pieces = split(argument, '='; limit=2)
            length(pieces) == 2 && !isempty(pieces[2]) || throw(ArgumentError(
                "--output-dir must not be empty",
            ))
            output_dir = abspath(pieces[2])
            output_seen = true
        elseif startswith(argument, "--")
            throw(ArgumentError("unknown option $argument"))
        else
            isempty(argument) && throw(ArgumentError(
                "CP output directory must not be empty",
            ))
            push!(input_dirs, abspath(argument))
        end
    end
    isempty(input_dirs) && throw(ArgumentError(
        "provide at least one CP output directory",
    ))
    length(unique(input_dirs)) == length(input_dirs) || throw(ArgumentError(
        "CP output directories must be unique",
    ))
    return (input_dirs=input_dirs, output_dir=output_dir)
end

function _read_metadata(path)
    isfile(path) || throw(ArgumentError("missing CP metadata file: $path"))
    metadata = Dict{String,String}()
    for (line_number, raw_line) in enumerate(eachline(path))
        line = strip(raw_line)
        isempty(line) && continue
        pieces = split(line, '='; limit=2)
        length(pieces) == 2 || throw(ArgumentError(
            "invalid metadata line $line_number in $path",
        ))
        key = lowercase(strip(pieces[1]))
        isempty(key) && throw(ArgumentError(
            "empty metadata key on line $line_number in $path",
        ))
        haskey(metadata, key) && throw(ArgumentError(
            "duplicate metadata key $(pieces[1]) in $path",
        ))
        metadata[key] = strip(pieces[2])
    end
    for key in REQUIRED_METADATA_KEYS
        haskey(metadata, key) || throw(ArgumentError(
            "metadata $path is missing required key $key",
        ))
    end
    return metadata
end

function _read_summary(path)
    isfile(path) || throw(ArgumentError("missing CP summary file: $path"))
    lines = collect(eachline(path))
    isempty(lines) && throw(ArgumentError("empty CP summary file: $path"))
    strip(lines[1]) == "quantity,value,standard_error" || throw(ArgumentError(
        "unexpected CP summary header in $path",
    ))
    summary = Dict{String,NamedTuple{(:value, :standard_error),Tuple{Float64,Float64}}}()
    for (offset, raw_line) in enumerate(lines[2:end])
        line_number = offset + 1
        line = strip(raw_line)
        isempty(line) && continue
        pieces = split(line, ','; keepempty=true)
        length(pieces) == 3 || throw(ArgumentError(
            "invalid summary line $line_number in $path",
        ))
        quantity = strip(pieces[1])
        isempty(quantity) && throw(ArgumentError(
            "empty quantity on line $line_number in $path",
        ))
        haskey(summary, quantity) && throw(ArgumentError(
            "duplicate summary quantity $quantity in $path",
        ))
        isempty(strip(pieces[2])) && continue
        isempty(strip(pieces[3])) && continue
        value = _parse_real(pieces[2], "$quantity value in $path")
        standard_error = _parse_real(
            pieces[3], "$quantity standard error in $path"; nonnegative=true,
        )
        summary[quantity] = (value=value, standard_error=standard_error)
    end
    for quantity in REQUIRED_SUMMARY_QUANTITIES
        haskey(summary, quantity) || throw(ArgumentError(
            "summary $path has no finite value and error for $quantity",
        ))
    end
    return summary
end

function _optional_real(metadata, key, default)
    haskey(metadata, key) || return default
    return _parse_real(metadata[key], "metadata $key")
end

"""
    read_cp_output(directory)

Read and validate one completed CP-AFQMC output. This performs no Monte Carlo
work and does not consume checkpoint files or raw measurements.
"""
function read_cp_output(directory::AbstractString)
    path = abspath(directory)
    isdir(path) || throw(ArgumentError("CP output directory does not exist: $path"))
    metadata = _read_metadata(joinpath(path, "metadata.txt"))
    summary = _read_summary(joinpath(path, "summary.csv"))

    _normalize_text(metadata["method"]) == "constrained-path afqmc" || throw(
        ArgumentError("unsupported method in $path: $(metadata["method"])")
    )
    _normalize_text(metadata["hamiltonian"]) ==
        "centered repulsive two-orbital hubbard" || throw(ArgumentError(
        "unsupported Hamiltonian convention in $path: $(metadata["hamiltonian"])",
    ))
    _normalize_text(metadata["boundary"]) == "periodic" || throw(ArgumentError(
        "CP output must use periodic boundary conditions: $path",
    ))

    L = _parse_integer(metadata["l"], "metadata L in $path")
    L == 2 || throw(ArgumentError(
        "ground-state ED comparison currently requires L=2, got L=$L in $path",
    ))
    U = _parse_real(metadata["u"], "metadata U in $path"; nonnegative=true)
    Nup = _parse_integer(metadata["nup"], "metadata Nup in $path")
    Ndown = _parse_integer(metadata["ndown"], "metadata Ndown in $path")
    0 <= Nup <= 8 || throw(ArgumentError("Nup must lie from 0 to 8 in $path"))
    0 <= Ndown <= 8 || throw(ArgumentError("Ndown must lie from 0 to 8 in $path"))
    particle_number = Nup + Ndown
    1 <= particle_number <= 15 || throw(ArgumentError(
        "two-sided canonical ED requires total particle number from 1 to 15 in $path",
    ))
    dtau = _parse_real(metadata["dtau"], "metadata dtau in $path")
    dtau > 0 || throw(ArgumentError("dtau must be positive in $path"))
    seed = _parse_integer(metadata["seed"], "metadata seed in $path")

    expected_density = particle_number / 4
    if haskey(metadata, "realized_density")
        realized = _parse_real(
            metadata["realized_density"], "realized density in $path",
        )
        isapprox(realized, expected_density; atol=1.0e-10, rtol=0) || throw(
            ArgumentError("realized density is inconsistent with Nup+Ndown in $path")
        )
    end
    density_path = joinpath(path, "summary.csv")
    # Density carries no error in the runner's summary, so it is checked
    # directly here instead of being loaded as a stochastic estimator.
    for raw_line in eachline(density_path)
        pieces = split(strip(raw_line), ','; keepempty=true)
        length(pieces) == 3 || continue
        strip(pieces[1]) == "density" || continue
        isempty(strip(pieces[2])) && throw(ArgumentError(
            "density is empty in $density_path",
        ))
        density = _parse_real(pieces[2], "density in $density_path")
        isapprox(density, expected_density; atol=1.0e-10, rtol=0) || throw(
            ArgumentError("summary density is inconsistent with Nup+Ndown in $path")
        )
    end

    effective_trial = get(metadata, "trial_pattern", metadata["trial"])
    effective_field = haskey(metadata, "trial_field_strength") ?
        _parse_real(metadata["trial_field_strength"],
                    "metadata trial_field_strength in $path") :
        _optional_real(metadata, "field_strength", 0.0)
    controls = Tuple(begin
        key == "trial" ? effective_trial :
        key == "field_strength" ? string(effective_field) :
        get(metadata, key, "<unrecorded>")
    end for key in POOL_CONTROL_KEYS)
    return (
        path=path,
        label=basename(path),
        metadata=metadata,
        summary=summary,
        L=L,
        U=U,
        Nup=Nup,
        Ndown=Ndown,
        N=particle_number,
        density=expected_density,
        dtau=dtau,
        seed=seed,
        trial=effective_trial,
        field_strength=effective_field,
        controls=controls,
    )
end

"""Require every input to describe the same physical finite-size problem."""
function validate_matched_runs(runs)
    isempty(runs) && throw(ArgumentError("provide at least one CP run"))
    reference = first(runs)
    for run in runs[2:end]
        run.L == reference.L || throw(ArgumentError("CP runs have different L"))
        isapprox(run.U, reference.U; atol=64eps(Float64) * max(1, abs(reference.U)),
                 rtol=0) || throw(ArgumentError("CP runs have different U"))
        run.Nup == reference.Nup || throw(ArgumentError(
            "CP runs have different Nup",
        ))
        run.Ndown == reference.Ndown || throw(ArgumentError(
            "CP runs have different Ndown",
        ))
    end
    return (
        L=reference.L,
        U=reference.U,
        Nup=reference.Nup,
        Ndown=reference.Ndown,
        N=reference.N,
        density=reference.density,
        boundary="periodic",
        hamiltonian="centered repulsive two-orbital Hubbard",
    )
end

"""
    pool_independent_estimates(values, standard_errors)

Use an unweighted seed mean. The within-run error is
`sqrt(sum(se_i^2))/n`; the between-seed error is the standard error of the
run means. The reported error is the larger of those two estimates, which is
the convention used by the repository's AFQMC validation driver.
"""
function pool_independent_estimates(values, standard_errors)
    count = length(values)
    count > 0 || throw(ArgumentError("cannot pool zero estimates"))
    length(standard_errors) == count || throw(DimensionMismatch(
        "values and standard_errors must have equal length",
    ))
    all(value -> value isa Real && isfinite(value), values) || throw(
        ArgumentError("pooled values must be finite real numbers")
    )
    all(error -> error isa Real && isfinite(error) && error >= 0,
        standard_errors) || throw(ArgumentError(
        "pooled standard errors must be finite and nonnegative",
    ))
    estimates = Float64.(values)
    errors = Float64.(standard_errors)
    center = sum(estimates) / count
    within = sqrt(sum(abs2, errors)) / count
    between = count == 1 ? missing : sqrt(
        sum(abs2(value - center) for value in estimates) /
        (count * (count - 1)),
    )
    reported = ismissing(between) ? within : max(within, between)
    return (
        mean=center,
        standard_error=reported,
        within_run_standard_error=within,
        between_seed_standard_error=between,
        count=count,
    )
end

function _comparison_row(run_index, run, quantity, summary_quantity,
                         reference, reference_scope, ensemble_sensitive)
    estimate = run.summary[summary_quantity]
    difference = estimate.value - reference
    z_score = estimate.standard_error > 0 ?
        difference / estimate.standard_error : missing
    return (
        run_index=run_index,
        run_label=run.label,
        input_directory=run.path,
        trial=run.trial,
        field_strength=run.field_strength,
        dtau=run.dtau,
        seed=run.seed,
        quantity=quantity,
        estimate=estimate.value,
        standard_error=estimate.standard_error,
        ed_reference=reference,
        difference=difference,
        z_score=z_score,
        reference_scope=reference_scope,
        ensemble_sensitive=ensemble_sensitive,
        estimator_status="stochastic_constrained_path_estimate",
    )
end

function _quantity_specs(exact)
    return (
        (
            quantity="mixed_energy_total",
            summary_quantity="mixed_energy",
            reference=exact.ground_energy,
            scope="canonical_fixed_N_ground_energy",
            sensitive=false,
        ),
        (
            quantity="backpropagated_energy_total",
            summary_quantity="backpropagated_energy",
            reference=exact.ground_energy,
            scope="canonical_fixed_N_ground_energy",
            sensitive=false,
        ),
        (
            quantity="backpropagated_double_occupancy_per_cell",
            summary_quantity="backpropagated_double_occupancy_per_cell",
            reference=exact.double_occupancy,
            scope="equal_weight_complete_fixed_N_ground_manifold",
            sensitive=false,
        ),
        (
            quantity="S_alm_q0",
            summary_quantity="S_alm_q0",
            reference=exact.o_alm_squared / 4,
            scope="equal_weight_complete_fixed_N_ground_manifold",
            sensitive=exact.ground_degeneracy > 1,
        ),
    )
end

function _pool_key(run)
    return run.controls
end

function _pool_label(key)
    return join(
        (string(name, '=', value) for (name, value) in zip(POOL_CONTROL_KEYS, key)),
        ';',
    )
end

"""
    compare_cp_afqmc_to_ground_ed(input_dirs)

Build an in-memory comparison report from existing CP output directories. ED
uses the complete equal-weight canonical ground manifold. The CP target spin
sector must contain the canonical fixed-N ground energy; otherwise a
ground-state comparison would silently use an excited spin sector and is
rejected.
"""
function compare_cp_afqmc_to_ground_ed(input_dirs)
    runs = read_cp_output.(input_dirs)
    problem = validate_matched_runs(runs)
    exact = solve_two_orbital_ground_state(problem.U, problem.N)
    sector_rows = [row for row in exact.sector_ground_energies
                   if row.Nup == problem.Nup && row.Ndown == problem.Ndown]
    isempty(sector_rows) && error("ED did not produce the requested spin sector")
    sector_energy = minimum(row.energy for row in sector_rows)
    sector_tolerance = max(exact.degeneracy_tolerance,
                           256eps(Float64) * max(1, abs(exact.ground_energy)))
    sector_contains_ground = abs(sector_energy - exact.ground_energy) <=
        sector_tolerance
    sector_contains_ground || throw(ArgumentError(
        "CP (Nup,Ndown)=($(problem.Nup),$(problem.Ndown)) does not contain " *
        "the canonical fixed-N ground state at U=$(problem.U)",
    ))

    specs = _quantity_specs(exact)
    per_run = NamedTuple[]
    for (run_index, run) in enumerate(runs), spec in specs
        push!(per_run, _comparison_row(
            run_index,
            run,
            spec.quantity,
            spec.summary_quantity,
            spec.reference,
            spec.scope,
            spec.sensitive,
        ))
    end

    groups = Dict{typeof(_pool_key(first(runs))),Vector{Int}}()
    for (run_index, run) in enumerate(runs)
        push!(get!(groups, _pool_key(run), Int[]), run_index)
    end
    ordered_keys = sort!(collect(keys(groups)); by=_pool_label)
    pooled = NamedTuple[]
    pools = NamedTuple[]
    for (pool_index, key) in enumerate(ordered_keys)
        indices = groups[key]
        selected = runs[indices]
        seeds = [run.seed for run in selected]
        length(unique(seeds)) == length(seeds) || throw(ArgumentError(
            "pool $(_pool_label(key)) contains duplicate random seeds",
        ))
        pool_id = "pool_" * lpad(string(pool_index), 3, '0')
        push!(pools, (
            pool_id=pool_id,
            control_signature=_pool_label(key),
            trial=first(selected).trial,
            field_strength=first(selected).field_strength,
            dtau=first(selected).dtau,
            run_indices=indices,
            seeds=sort(seeds),
        ))
        for spec in specs
            estimates = [run.summary[spec.summary_quantity].value for run in selected]
            errors = [run.summary[spec.summary_quantity].standard_error
                      for run in selected]
            pool = pool_independent_estimates(estimates, errors)
            difference = pool.mean - spec.reference
            z_score = pool.standard_error > 0 ?
                difference / pool.standard_error : missing
            push!(pooled, (
                pool_id=pool_id,
                control_signature=_pool_label(key),
                trial=first(selected).trial,
                field_strength=first(selected).field_strength,
                dtau=first(selected).dtau,
                run_count=length(selected),
                run_indices=join(indices, ';'),
                seeds=join(sort(seeds), ';'),
                quantity=spec.quantity,
                estimate=pool.mean,
                standard_error=pool.standard_error,
                within_run_standard_error=pool.within_run_standard_error,
                between_seed_standard_error=pool.between_seed_standard_error,
                ed_reference=spec.reference,
                difference=difference,
                z_score=z_score,
                reference_scope=spec.scope,
                ensemble_sensitive=spec.sensitive,
                estimator_status="pooled_stochastic_constrained_path_estimate",
            ))
        end
    end

    exact_reference = (
        L=exact.L,
        U=exact.U,
        N=exact.N,
        Nup=problem.Nup,
        Ndown=problem.Ndown,
        density=exact.density,
        ground_energy=exact.ground_energy,
        matched_spin_sector_ground_energy=sector_energy,
        matched_spin_sector_contains_ground=sector_contains_ground,
        ground_degeneracy=exact.ground_degeneracy,
        double_occupancy_per_cell=exact.double_occupancy,
        S_alm_q0=exact.o_alm_squared / 4,
        S_alm_ensemble_sensitive=exact.ground_degeneracy > 1,
        ensemble=exact.ensemble,
        ensemble_policy="equal_weight_complete_fixed_N_ground_manifold",
        boundary="periodic",
        limitation=exact.limitation,
    )
    return (
        problem=problem,
        runs=runs,
        pools=pools,
        exact=exact_reference,
        per_run=per_run,
        pooled=pooled,
        status=exact_reference.S_alm_ensemble_sensitive ?
            "COMPLETE_WITH_ENSEMBLE_WARNING" : "COMPLETE",
    )
end

_csv_value(value::Missing) = ""
_csv_value(value::Nothing) = ""
_csv_value(value) = string(value)

function _csv_field(value)
    text = _csv_value(value)
    if any(character -> character in (',', '"', '\n', '\r'), text)
        return "\"" * replace(text, '"' => "\"\"") * "\""
    end
    return text
end

function _write_named_tuple_csv(path, rows)
    isempty(rows) && throw(ArgumentError("cannot write an empty CSV report"))
    names = propertynames(first(rows))
    all(row -> propertynames(row) == names, rows) || throw(ArgumentError(
        "CSV rows must have identical fields",
    ))
    open(path, "w") do io
        println(io, join(String.(names), ','))
        for row in rows
            println(io, join((_csv_field(getproperty(row, name)) for name in names), ','))
        end
    end
    return path
end

function _write_exact_reference(path, exact)
    rows = [
        (quantity="ground_energy_total", value=exact.ground_energy,
         scope="canonical_fixed_N"),
        (quantity="matched_spin_sector_ground_energy_total",
         value=exact.matched_spin_sector_ground_energy,
         scope="fixed_Nup_Ndown"),
        (quantity="double_occupancy_per_cell",
         value=exact.double_occupancy_per_cell,
         scope=exact.ensemble_policy),
        (quantity="S_alm_q0", value=exact.S_alm_q0,
         scope=exact.ensemble_policy),
    ]
    return _write_named_tuple_csv(path, rows)
end

"""Write a completed in-memory report into a fresh directory atomically."""
function write_comparison(report, output_directory::AbstractString)
    output = abspath(output_directory)
    ispath(output) && throw(ArgumentError(
        "refusing to overwrite output directory: $output",
    ))
    parent = dirname(output)
    mkpath(parent)
    staging = mktempdir(parent; prefix=".$(basename(output)).tmp-")
    try
        _write_named_tuple_csv(joinpath(staging, "per_run_comparison.csv"),
                               report.per_run)
        _write_named_tuple_csv(joinpath(staging, "trial_pooled_comparison.csv"),
                               report.pooled)
        _write_exact_reference(joinpath(staging, "exact_ed_reference.csv"),
                               report.exact)
        open(joinpath(staging, "metadata.txt"), "w") do io
            println(io, "format_version=1")
            println(io, "status=", report.status)
            println(io, "method=postprocess saved constrained-path AFQMC against ED")
            println(io, "L=", report.problem.L)
            println(io, "U=", report.problem.U)
            println(io, "Nup=", report.problem.Nup)
            println(io, "Ndown=", report.problem.Ndown)
            println(io, "N=", report.problem.N)
            println(io, "density=", report.problem.density)
            println(io, "boundary=periodic")
            println(io, "Hamiltonian=centered repulsive two-orbital Hubbard")
            println(io, "input_run_count=", length(report.runs))
            println(io, "pool_count=", length(report.pools))
            println(io, "input_directories=",
                    join((run.path for run in report.runs), ';'))
            println(io, "ed_ground_degeneracy=", report.exact.ground_degeneracy)
            println(io, "ed_ensemble_policy=", report.exact.ensemble_policy)
            println(io, "S_alm_ensemble_sensitive=",
                    report.exact.S_alm_ensemble_sensitive)
            println(io, "pooling=unweighted independent-seed mean")
            println(io, "within_run_error=sqrt(sum(se_i^2))/run_count")
            println(io, "between_seed_error=sample standard error of run means")
            println(io, "reported_pool_error=max(within_run_error,between_seed_error)")
            println(io, "accuracy_gate=none; differences and z_scores are reported")
            println(io, "CP_estimator_status=stochastic constrained-path estimate")
            println(io, "CP_bound_claim=none")
            println(io, "constraint_bias=not removed by seed pooling")
            println(io, "t4_note=periodic L=2 cancels t4 exactly")
        end
        open(joinpath(staging, "status.txt"), "w") do io
            println(io, "status=", report.status)
            println(io, "comparison_verdict=not_assigned")
            println(io, "accuracy_gate=none")
            println(io, "run_count=", length(report.runs))
            println(io, "pool_count=", length(report.pools))
            println(io, "S_alm_ensemble_sensitive=",
                    report.exact.S_alm_ensemble_sensitive)
        end
        ispath(output) && throw(ArgumentError(
            "output directory appeared while the report was being written: $output",
        ))
        mv(staging, output)
    catch
        ispath(staging) && rm(staging; recursive=true)
        rethrow()
    end
    return output
end

function run_comparison(options)
    report = compare_cp_afqmc_to_ground_ed(options.input_dirs)
    output = write_comparison(report, options.output_dir)
    return (report=report, output_dir=output)
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        print(HELP)
        return nothing
    end
    run = run_comparison(options)
    println("Saved ground-state CP-AFQMC/ED comparison to ", run.output_dir)
    println("Status: ", run.report.status)
    if run.report.exact.S_alm_ensemble_sensitive
        println("S_alm_q0 warning: the ED reference uses an equal-weight " *
                "degenerate ground manifold.")
    end
    return run
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end

end # module
