#!/usr/bin/env python3
"""Compare completed spectra with native graphics, without parameter fits."""
from pathlib import Path
import argparse
import bisect
import csv
import hashlib
import json
import math
import statistics
import tomllib
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def interpolate(x, y, point):
    if point < x[0] - 1e-10 or point > x[-1] + 1e-10:
        raise ValueError("comparison point outside calculated grid")
    i = max(0, min(len(x) - 2, bisect.bisect_right(x, point) - 1))
    t = (point - x[i]) / (x[i + 1] - x[i])
    return y[i] * (1 - t) + y[i + 1] * t


def ranks(values):
    order = sorted(range(len(values)), key=values.__getitem__)
    result = [0.] * len(values)
    i = 0
    while i < len(order):
        j = i + 1
        while j < len(order) and values[order[j]] == values[order[i]]:
            j += 1
        rank = (i + j - 1) / 2 + 1
        for k in order[i:j]:
            result[k] = rank
        i = j
    return result


def correlation(x, y):
    mx, my = statistics.mean(x), statistics.mean(y)
    numerator = sum((a - mx) * (b - my) for a, b in zip(x, y))
    denominator = math.sqrt(sum((a - mx) ** 2 for a in x) * sum((b - my) ** 2 for b in y))
    if denominator == 0:
        raise ValueError("constant intensity cannot define rank correlation")
    return numerator / denominator


def top_decile(values):
    cutoff = sorted(values)[math.ceil(.9 * len(values)) - 1]
    return {i for i, value in enumerate(values) if value >= cutoff}


def write_csv(path, rows):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def compare(input_root, source_root, output):
    if (output / "completed.json").exists():
        raise ValueError("completed comparison exists; preserve it or select a new output")
    source_provenance = json.loads((source_root / "provenance.json").read_text())
    paths = [source_root / "provenance.json", source_root / "fig3_metadata.json", Path(__file__)]
    for name, expected in source_provenance["output_sha256"].items():
        path = source_root / name
        if sha(path) != expected:
            raise ValueError(f"source extraction hash differs: {path}")
        paths.append(path)
    metadata = json.loads((source_root / "fig3_metadata.json").read_text())
    complete = tomllib.loads((input_root / "completed.toml").read_text())
    if complete["status"] != "spectral_grids_computed":
        raise ValueError("incomplete spectral grids")
    paths += [input_root / "completed.toml", input_root / "configuration.toml"]
    for name, expected in complete["case_completion_sha256"].items():
        marker = input_root / "cases" / name / "completed.toml"
        if sha(marker) != expected:
            raise ValueError("case completion hash changed")
        paths.append(marker)
        for file, digest in tomllib.loads(marker.read_text())["output_sha256"].items():
            path = marker.parent / file
            if sha(path) != digest:
                raise ValueError("production data changed")
            paths.append(path)
    dos_source = read_csv(source_root / "fig3c_dos_polylines.csv")
    paired, summaries = [], []
    for U, name in [(0., "blue_U0"), (.5, "blue_U0p5"), (1., "blue_U1"), (2., "blue_U2")]:
        calculated = read_csv(input_root / "cases" / name / "dos.csv")
        x = [float(row["omega_minus_mu"]) for row in calculated]
        y = [float(row["DOS_states_per_Fe_per_energy"]) for row in calculated]
        selected = [row for row in dos_source if float(row["U"]) == U]
        differences = []
        accepted = 0
        for row in selected:
            point, reference = float(row["omega_minus_mu"]), float(row["dos_published"])
            outside = point < x[0] or point > x[-1]
            actual = None if outside else interpolate(x, y, point)
            difference = None if outside else actual - reference
            allowance = float(row["dos_extraction_allowance_abs"])
            clipped_or_occluded = row["clipped_at_upper_frame"].lower() == "true" or row["occluded_by_legend"].lower() == "true"
            excluded = clipped_or_occluded or outside
            if not excluded:
                differences.append(difference)
                accepted += abs(difference) <= allowance
            paired.append(dict(U=U, omega_minus_mu=point, DOS_published=reference,
                DOS_calculated=actual, difference=difference, vertical_allowance=allowance,
                within_vertical_allowance=None if outside else abs(difference) <= allowance,
                excluded_clipped_or_occluded=clipped_or_occluded, outside_calculated_window=outside,
                excluded_from_comparison=excluded, source_subpath=row["subpath_index"]))
        # Only interpolate inside an actual native subpath, never across a
        # clipped peak or an absent segment.
        source_zero = None
        for subpath in sorted({row["subpath_index"] for row in selected}):
            points = sorted((float(row["omega_minus_mu"]), float(row["dos_published"]))
                            for row in selected if row["subpath_index"] == subpath)
            for (left, ya), (right, yb) in zip(points, points[1:]):
                if left <= 0 <= right and right > left:
                    source_zero = ya + (yb - ya) * (-left) / (right - left)
        summaries.append(dict(U=U, case=name, points=len(differences),
            excluded_source_vertices=len(selected)-len(differences),
            omega_allowance=.004, dos_allowance=.006,
            max_abs=max(map(abs, differences)), rms=math.sqrt(statistics.mean(d*d for d in differences)),
            median_abs=statistics.median(map(abs, differences)), within_vertical_allowance=accepted,
            source_window_integral=metadata["DOS"][str(U)]["integral_of_retained_segments_in_display_units"],
            source_clipping_gaps=metadata["DOS"][str(U)]["clipping_gaps"],
            calculated_DOS_at_zero=interpolate(x, y, 0.), paper_DOS_at_zero_if_interpolable=source_zero))
    source_cells = read_csv(source_root / "fig3d_color_cells.csv")
    source_map = {(int(row["ix_0based"]), int(row["iy_0based"])): int(row["palette_index_low_to_high"]) for row in source_cells}
    predictions_path = output / "fermi_source_grid_predictions.csv"
    marker = output / "grid_provenance" / "completed.toml"
    prediction_record = tomllib.loads(marker.read_text())
    if sha(predictions_path) != prediction_record["prediction_sha256"]:
        raise ValueError("source-grid predictions changed")
    if sha(source_root / "fig3d_color_cells.csv") != prediction_record["source_grid_sha256"]:
        raise ValueError("prediction/source registration mismatch")
    if sha(input_root / "configuration.toml") != prediction_record["input_configuration_sha256"]:
        raise ValueError("predictions use another production configuration")
    paths += [predictions_path, marker]
    prediction_rows = read_csv(predictions_path)
    shapes, cell_pairs = [], []
    for registration in sorted({row["registration"] for row in prediction_rows}):
        selected = [row for row in prediction_rows if row["registration"] == registration]
        keys = [(int(row["ix"]), int(row["iy"])) for row in selected]
        if len(keys) != 3600 or set(keys) != set(source_map):
            raise ValueError("source/prediction grid is incomplete or duplicated")
        source = [source_map[key] for key in keys]
        # Rounding at 1e-12 only restores machine-level symmetry ties; source
        # colors retain their original64 discrete intensity ranks.
        actual = [round(float(row["A_C4_states_per_Fe_per_energy"]), 12) for row in selected]
        source_top, actual_top = top_decile(source), top_decile(actual)
        shape = dict(registration=registration, points=len(keys),
            spearman_rank=correlation(ranks(source), ranks(actual)),
            top_decile_intersection_over_union=len(source_top & actual_top)/len(source_top | actual_top),
            source_selected_count=len(source_top), calculated_selected_count=len(actual_top))
        shapes.append(shape)
        for i, row in enumerate(selected):
            cell_pairs.append(dict(registration=registration, ix=keys[i][0], iy=keys[i][1],
                kx=row["kx"], ky=row["ky"], source_palette_index=source[i],
                A_calculated=actual[i], source_in_top_decile=i in source_top,
                calculated_in_top_decile=i in actual_top))
    primary = dict(next(shape for shape in shapes if shape["registration"] == "native_cell_centers"))
    primary["registration_audits"] = shapes
    report = dict(status="completed", created_utc=datetime.now(timezone.utc).isoformat(),
        scope="Raw DOS ordinate comparison and Fermi-level intensity shape comparison; no parameter, amplitude, width, or energy fit.",
        primary_production=str(input_root.relative_to(ROOT)),
        spectral_block_steps=tomllib.loads((input_root / "configuration.toml").read_text())["spectral_block_steps"],
        dos=summaries, fermi_shape=primary,
        ridges=dict(source_count=48, rendered_count=49, limits=[
            "Paper does not specify exact per-ridge momenta or amplitude normalization; no pointwise spectral-height accuracy claim.",
            "Source path ordering and frame energy ranges are retained; calculated heatmaps provide the complete data."]),
        limits=["Graphical extraction allowances are not author or solver error bars.",
            "Raw vertical DOS counts keep the horizontal ±0.004 allowance separate; clipped/legend-occluded vertices and four endpoints just outside the calculated window are excluded without extrapolation.",
            "Clipped U2 DOS peak gaps are never interpolated; the source retained-segment integral omits their areas.",
            "The paper's FS colorbar has no stated physical intensity normalization or energy window. Palette ranks are not amplitudes.",
            "Rank correlation and top-decile overlap describe shape only; they do not establish quantitative spectral reproduction.",
            "Native cell centers are the primary registration. Uniform centers and all four corners are predeclared sensitivity checks, not fitted shifts.",
            "The inherited Fig2c stationary fields and mesh limits remain applicable."],
        input_sha256={str(path.relative_to(ROOT)):sha(path) for path in sorted(set(paths))})
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "dos_paired_samples.csv", paired)
    write_csv(output / "fermi_paired_cells.csv", cell_pairs)
    (output / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)+"\n")
    outputs=["report.json", "dos_paired_samples.csv", "fermi_paired_cells.csv", "fermi_source_grid_predictions.csv"]
    (output / "completed.json").write_text(json.dumps(dict(status="completed",
        output_sha256={name:sha(output/name) for name in outputs}), indent=2)+"\n")
    print(json.dumps(dict(dos=summaries, fermi_shape=primary), indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, default=ROOT/"results/prl_101_237004/fig3/refined")
    parser.add_argument("--source-root", type=Path, default=ROOT/"results/prl_101_237004/fig3_reference")
    parser.add_argument("--output-dir", type=Path, default=ROOT/"results/prl_101_237004/fig3/comparison")
    args = parser.parse_args()
    compare(args.input_root.resolve(), args.source_root.resolve(), args.output_dir.resolve())
