#!/usr/bin/env julia

# Offline analytic continuation for the serialized output of
# square_hubbard_two_orbital_observables.jl.
#
# Run this file from a small, separate environment containing SmoQyDEAC.  It
# intentionally does not load the DQMC project or its helper modules.

using Serialization
using DelimitedFiles

const PHYSICAL_TRACE_DEGENERACY = 4.0 # two spins times two orbitals
const RUN_AS_SCRIPT = abspath(PROGRAM_FILE) == @__FILE__

# Keep --help usable from the DQMC project, where SmoQyDEAC is intentionally
# not a dependency.  For a real run, import at top level before the functions
# below are compiled so Julia's world-age rules are respected.
const HELP_REQUESTED = any(argument -> argument in ("-h", "--help"), ARGS)
if RUN_AS_SCRIPT && !HELP_REQUESTED
    try
        import SmoQyDEAC
    catch exception
        error(
            "SmoQyDEAC is unavailable in the active Julia environment. " *
            "Create a separate environment, add SmoQyDEAC there, and run " *
            "this script with --project=that_environment. Original error: " *
            sprint(showerror, exception),
        )
    end
end

function print_usage(io=stdout)
    print(io, """
Usage:
  julia --threads=auto --project=deac_env \\
      scripts/continue_two_orbital_spectrum.jl DATA.jls [options]

The input must have been produced with --measure-greens. The continued
channel is a positive orbital-diagonal trace, divided by four for both
spins or by two for one spin. SmoQyDEAC therefore sees zeroth moment one.
The physical CSV spectrum has weight four (both) or two (up/down).
Single-spin filenames and physical CSV columns identify the selected spin;
the default both-spin filenames and CSV columns remain unchanged.

Options (all value options use --name=value):
  --mode=dos|ktrace|all-k   Continue the momentum-averaged DOS, one momentum,
                            or every momentum.                 [dos]
  --spin=both|up|down       Select both spins or one saved spin channel. [both]
  --kx-index=INT            One-based kx index for ktrace.      [1]
  --ky-index=INT            One-based ky index for ktrace.      [1]
  --tau-stride=INT          Keep every INT-th imaginary-time point; the beta
                            endpoint is always retained.        [5]
  --omega-min=FLOAT         Minimum output energy.              [-15]
  --omega-max=FLOAT         Maximum output energy.              [15]
  --omega-points=INT        Number of output-energy points.     [601]
  --deac-bins=INT           Independent DEAC output bins.       [2]
  --runs-per-bin=INT        DEAC runs in each output bin.       [5]
  --generations=INT         Maximum generations per run.        [10000]
  --base-seed=INT           First DEAC random seed.              [8675309]
  --minimum-sign=FLOAT      Require this |average sign| for the full data and
                            every delete-one-bin sample.         [0.05]
  --output-dir=PATH         Directory for JLD2, CSV, and summaries.
                            [spectral_output]
  -h, --help                Show this help and exit.

The defaults are a continuation smoke test.  For a scientific production
continuation, increase both the number of DEAC realizations and generations.
""")
end

function parse_value(argument::AbstractString)
    pieces = split(argument, "="; limit=2)
    length(pieces) == 2 && !isempty(pieces[2]) || error(
        "value option must use --name=value with a nonempty value: $argument",
    )
    return pieces[1], pieces[2]
end

function parse_options(arguments)
    any(argument -> argument in ("-h", "--help"), arguments) &&
        return nothing

    values = Dict{Symbol,Any}(
        :mode => "dos",
        :spin => "both",
        :kx_index => 1,
        :ky_index => 1,
        :tau_stride => 5,
        :omega_min => -15.0,
        :omega_max => 15.0,
        :omega_points => 601,
        :deac_bins => 2,
        :runs_per_bin => 5,
        :generations => 10_000,
        :base_seed => 8_675_309,
        :minimum_sign => 0.05,
        :output_dir => "spectral_output",
    )
    positional = String[]

    for argument in arguments
        if !startswith(argument, "--")
            push!(positional, argument)
            continue
        end
        name, value = parse_value(argument)
        if name == "--mode"
            values[:mode] = value
        elseif name == "--spin"
            values[:spin] = value
        elseif name == "--kx-index"
            values[:kx_index] = parse(Int, value)
        elseif name == "--ky-index"
            values[:ky_index] = parse(Int, value)
        elseif name == "--tau-stride"
            values[:tau_stride] = parse(Int, value)
        elseif name == "--omega-min"
            values[:omega_min] = parse(Float64, value)
        elseif name == "--omega-max"
            values[:omega_max] = parse(Float64, value)
        elseif name == "--omega-points"
            values[:omega_points] = parse(Int, value)
        elseif name == "--deac-bins"
            values[:deac_bins] = parse(Int, value)
        elseif name == "--runs-per-bin"
            values[:runs_per_bin] = parse(Int, value)
        elseif name == "--generations"
            values[:generations] = parse(Int, value)
        elseif name == "--base-seed"
            values[:base_seed] = parse(Int, value)
        elseif name == "--minimum-sign"
            values[:minimum_sign] = parse(Float64, value)
        elseif name == "--output-dir"
            values[:output_dir] = value
        else
            error("unknown option: $name")
        end
    end

    length(positional) == 1 || error("exactly one DATA.jls input is required")
    input_path = positional[1]
    endswith(lowercase(input_path), ".jls") || error(
        "the serialized observable input must have a .jls extension",
    )
    isfile(input_path) || error("input file does not exist: $input_path")
    values[:mode] in ("dos", "ktrace", "all-k") || error(
        "--mode must be dos, ktrace, or all-k",
    )
    values[:spin] in ("both", "up", "down") || error(
        "--spin must be both, up, or down",
    )
    values[:kx_index] > 0 || error("--kx-index must be positive")
    values[:ky_index] > 0 || error("--ky-index must be positive")
    values[:tau_stride] > 0 || error("--tau-stride must be positive")
    isfinite(values[:omega_min]) || error("--omega-min must be finite")
    isfinite(values[:omega_max]) || error("--omega-max must be finite")
    values[:omega_max] > values[:omega_min] || error(
        "--omega-max must exceed --omega-min",
    )
    values[:omega_points] >= 3 || error("--omega-points must be at least 3")
    values[:deac_bins] >= 2 || error("--deac-bins must be at least 2")
    values[:runs_per_bin] >= 1 || error("--runs-per-bin must be positive")
    values[:generations] >= 1 || error("--generations must be positive")
    values[:base_seed] >= 1 || error("--base-seed must be positive")
    isfinite(values[:minimum_sign]) &&
        0.0 <= values[:minimum_sign] < 1.0 || error(
            "--minimum-sign must be finite and lie in [0,1)",
        )
    !isempty(values[:output_dir]) || error("--output-dir must be nonempty")

    return (
        input_path=abspath(input_path),
        mode=Symbol(values[:mode]),
        spin=Symbol(values[:spin]),
        kx_index=values[:kx_index],
        ky_index=values[:ky_index],
        tau_stride=values[:tau_stride],
        omega_min=values[:omega_min],
        omega_max=values[:omega_max],
        omega_points=values[:omega_points],
        deac_bins=values[:deac_bins],
        runs_per_bin=values[:runs_per_bin],
        generations=values[:generations],
        base_seed=values[:base_seed],
        minimum_sign=values[:minimum_sign],
        output_dir=abspath(values[:output_dir]),
    )
end

function required(dictionary::AbstractDict, key::AbstractString)
    haskey(dictionary, key) || error("observable payload is missing key: $key")
    return dictionary[key]
end

function required_real(dictionary::AbstractDict, key::AbstractString)
    value = required(dictionary, key)
    value isa Real && !(value isa Bool) || error("$key must be real")
    isfinite(value) || error("$key must be finite")
    return Float64(value)
end

function finite_number(value)
    return value isa Number && isfinite(real(value)) && isfinite(imag(value))
end

function load_and_validate_payload(path)
    payload = try
        open(deserialize, path)
    catch exception
        error("could not deserialize $path: $(sprint(showerror, exception))")
    end
    payload isa AbstractDict || error("observable payload must be a dictionary")
    required(payload, "schema_version") == 1 || error(
        "only observable schema_version=1 is supported",
    )

    expected_axes = (
        :bin,
        :spin,
        :destination_orbital,
        :source_orbital,
        :kx_index,
        :ky_index,
        :tau_index,
    )
    axes = required(payload, "green_axes")
    axes isa Tuple || axes isa AbstractVector || error(
        "green_axes must be a tuple or vector",
    )
    Tuple(axes) == expected_axes || error(
        "green_axes do not match the schema expected by this script",
    )
    convention = required(payload, "green_convention")
    convention isa AbstractString && occursin("no leading minus", convention) ||
        error("unsupported Green-function sign convention")

    metadata = required(payload, "metadata")
    metadata isa AbstractDict || error("metadata must be a dictionary")
    beta = required_real(metadata, "beta")
    beta > 0.0 || error("metadata beta must be positive")
    dtau = required_real(metadata, "dtau")
    dtau > 0.0 || error("metadata dtau must be positive")
    L_value = required(metadata, "L")
    L_value isa Integer && !(L_value isa Bool) && L_value > 0 || error(
        "metadata L must be a positive integer",
    )
    L = Int(L_value)
    Ltau_value = required(metadata, "Ltau")
    Ltau_value isa Integer && !(Ltau_value isa Bool) && Ltau_value > 0 || error(
        "metadata Ltau must be a positive integer",
    )
    Ltau = Int(Ltau_value)
    bin_count_value = required(metadata, "bin_count")
    bin_count_value isa Integer && bin_count_value >= 2 || error(
        "metadata bin_count must be an integer of at least two",
    )

    tau_raw = required(payload, "tau")
    tau_raw isa AbstractVector{<:Real} || error("tau must be a real vector")
    tau = Float64.(tau_raw)
    length(tau) == Ltau + 1 || error("tau length must equal Ltau+1")
    all(isfinite, tau) || error("tau contains a non-finite value")
    all(tau[index + 1] > tau[index] for index in 1:(length(tau) - 1)) ||
        error("tau must be strictly increasing")
    tolerance = 256eps(Float64) * max(1.0, beta)
    isapprox(first(tau), 0.0; atol=tolerance, rtol=0.0) || error(
        "tau must start at zero",
    )
    isapprox(last(tau), beta; atol=tolerance, rtol=0.0) || error(
        "tau must end at beta",
    )
    isapprox(dtau * Ltau, beta; atol=tolerance, rtol=0.0) || error(
        "metadata dtau*Ltau does not equal beta",
    )

    momenta_raw = required(payload, "momenta")
    momenta_raw isa AbstractVector{<:Real} || error(
        "momenta must be a real vector",
    )
    momenta = Float64.(momenta_raw)
    length(momenta) == L || error("momenta length must equal L")
    all(isfinite, momenta) || error("momenta contains a non-finite value")

    greens = required(payload, "green_signed_momentum_bins")
    greens === nothing && error(
        "this run contains no unequal-time data; rerun DQMC with --measure-greens",
    )
    greens isa AbstractArray || error(
        "green_signed_momentum_bins must be an array",
    )
    ndims(greens) == 7 || error(
        "green_signed_momentum_bins must have seven axes",
    )
    eltype(greens) <: Number || error("Green bins must contain numbers")
    number_of_bins = size(greens, 1)
    number_of_bins == Int(bin_count_value) || error(
        "Green bin axis disagrees with metadata bin_count",
    )
    size(greens) == (number_of_bins, 2, 2, 2, L, L, length(tau)) || error(
        "Green-bin shape must be (bin,2,2,2,L,L,Ltau+1)",
    )
    all(finite_number, greens) || error("Green bins contain a non-finite value")

    sign_sums = required(payload, "green_sign_sums")
    sign_sums isa AbstractVector{<:Real} || error(
        "green_sign_sums must be a real vector",
    )
    length(sign_sums) == number_of_bins || error(
        "green_sign_sums length disagrees with the Green bin axis",
    )
    sign_sums = Float64.(sign_sums)
    all(isfinite, sign_sums) || error("green_sign_sums contains a non-finite value")

    counts_raw = required(payload, "green_counts")
    counts_raw isa AbstractVector || error("green_counts must be a vector")
    length(counts_raw) == number_of_bins || error(
        "green_counts length disagrees with the Green bin axis",
    )
    all(value -> value isa Integer && !(value isa Bool) && value > 0, counts_raw) ||
        error("every Green bin must contain a positive integer sample count")
    counts = Int.(counts_raw)
    all(abs(sign_sums[bin]) <= counts[bin] + 256eps(Float64) * counts[bin]
        for bin in eachindex(counts)) || error(
            "a Green sign sum exceeds its sample count",
        )

    stabilization = required(payload, "green_maximum_stabilization_errors")
    stabilization isa AbstractArray{<:Real,2} || error(
        "green_maximum_stabilization_errors must be a real matrix",
    )
    size(stabilization) == (number_of_bins, 2) || error(
        "stabilization-error shape must be (bin,spin)",
    )
    all(isfinite, stabilization) || error(
        "stabilization errors contain a non-finite value",
    )
    all(value -> value >= 0, stabilization) || error(
        "stabilization errors must be nonnegative",
    )

    return (
        payload=payload,
        metadata=metadata,
        beta=beta,
        L=L,
        tau=tau,
        momenta=momenta,
        greens=greens,
        sign_sums=sign_sums,
        counts=counts,
        maximum_stabilization_error=maximum(stabilization),
    )
end

function selected_tau_indices(number_of_times, stride)
    indices = collect(1:stride:number_of_times)
    last(indices) == number_of_times || push!(indices, number_of_times)
    length(indices) >= 3 || error(
        "--tau-stride leaves fewer than three imaginary-time points",
    )
    return indices
end

function spin_indices(spin::Symbol)
    spin == :both && return (1, 2)
    spin == :up && return (1,)
    spin == :down && return (2,)
    throw(ArgumentError("spin must be :both, :up, or :down"))
end

physical_trace_factor(spin::Symbol) = 2.0 * length(spin_indices(spin))

"""
    trace_numerator_bins(data, mode, kx_index, ky_index, time_indices; spin=:both)

Extract signed numerator sums for the selected orbital trace, normalized to
unit spectral weight. Spin 1 is up and spin 2 is down. The physical factor
is four for both spins and two for one spin. Sign reweighting happens later,
using the same paired Green-bin denominators for every selected channel.
"""
function trace_numerator_bins(
    data, mode, kx_index, ky_index, time_indices; spin::Symbol=:both,
)
    greens = data.greens
    number_of_bins = size(greens, 1)
    output = zeros(ComplexF64, number_of_bins, length(time_indices))
    L = data.L
    selected_spins = spin_indices(spin)
    physical_factor = physical_trace_factor(spin)

    if mode == :dos
        normalization = physical_factor * L^2
        @inbounds for bin in 1:number_of_bins
            for (selected_index, time_index) in pairs(time_indices)
                value = 0.0 + 0.0im
                for ky in 1:L, kx in 1:L, orbital in 1:2,
                    spin_index in selected_spins
                    value += greens[
                        bin, spin_index, orbital, orbital, kx, ky, time_index,
                    ]
                end
                output[bin, selected_index] = value / normalization
            end
        end
    else
        1 <= kx_index <= L && 1 <= ky_index <= L || error(
            "momentum indices must lie between 1 and L=$L",
        )
        @inbounds for bin in 1:number_of_bins
            for (selected_index, time_index) in pairs(time_indices)
                value = 0.0 + 0.0im
                for orbital in 1:2, spin_index in selected_spins
                    value += greens[
                        bin,
                        spin_index,
                        orbital,
                        orbital,
                        kx_index,
                        ky_index,
                        time_index,
                    ]
                end
                output[bin, selected_index] =
                    value / physical_factor
            end
        end
    end
    all(finite_number, output) || error(
        "the normalized trace numerator contains a non-finite value",
    )
    return output
end

"""
    sign_reweighted_statistics(numerators, sign_sums, counts, minimum_sign;
                               require_noisy=true, require_positive=true)

Use the same-bin ratio jackknife for all imaginary times. The defaults enforce
the noisy positive input required by continuation. Read-only audits may set
`require_noisy=false` for exact data and `require_positive=false` for signed
spin differences; neither option relaxes the full or delete-one-bin sign gate.
"""
function sign_reweighted_statistics(
    numerator_bins, sign_sums, counts, minimum_sign;
    require_noisy::Bool=true, require_positive::Bool=true,
)
    number_of_bins, number_of_times = size(numerator_bins)
    number_of_bins >= 2 || error("at least two Monte Carlo bins are required")
    length(sign_sums) == length(counts) == number_of_bins || error(
        "numerator, sign, and sample-count bin axes must agree",
    )
    isfinite(minimum_sign) && 0 <= minimum_sign < 1 || error(
        "minimum_sign must be finite and lie in [0,1)",
    )
    full_sign_sum = sum(sign_sums)
    full_count = sum(counts)
    full_count > 0 || error("the full Green sample count is zero")
    average_sign = full_sign_sum / full_count
    isfinite(average_sign) && abs(average_sign) > minimum_sign || error(
        "full Green average sign $(average_sign) does not exceed " *
        "--minimum-sign=$(minimum_sign)",
    )

    full_numerator = vec(sum(numerator_bins; dims=1))
    full_ratio = full_numerator ./ full_sign_sum
    all(finite_number, full_ratio) || error(
        "the full sign-reweighted Green function is non-finite",
    )

    leave_one_out_complex = zeros(ComplexF64, number_of_bins, number_of_times)
    for bin in 1:number_of_bins
        denominator = full_sign_sum - sign_sums[bin]
        count = full_count - counts[bin]
        count > 0 || error("deleting Green bin $bin leaves no samples")
        leave_one_out_sign = denominator / count
        isfinite(leave_one_out_sign) &&
            abs(leave_one_out_sign) > minimum_sign || error(
                "delete-one-bin average sign fails at bin $bin: " *
                "$(leave_one_out_sign) does not exceed " *
                "--minimum-sign=$(minimum_sign)",
            )
        @views leave_one_out_complex[bin, :] .=
            (full_numerator .- numerator_bins[bin, :]) ./ denominator
    end
    all(finite_number, leave_one_out_complex) || error(
        "a delete-one-bin Green estimate is non-finite",
    )

    values = real.(full_ratio)
    leave_one_out = real.(leave_one_out_complex)
    center = vec(sum(leave_one_out; dims=1)) ./ number_of_bins
    covariance = zeros(Float64, number_of_times, number_of_times)
    prefactor = (number_of_bins - 1) / number_of_bins
    @inbounds for bin in 1:number_of_bins
        for row in 1:number_of_times
            row_deviation = leave_one_out[bin, row] - center[row]
            for column in 1:number_of_times
                column_deviation = leave_one_out[bin, column] - center[column]
                covariance[row, column] +=
                    prefactor * row_deviation * column_deviation
            end
        end
    end
    # SmoQyDEAC requires exact Hermitian symmetry, while independently
    # accumulated floating-point entries can differ by a few last bits.
    covariance .= (covariance .+ transpose(covariance)) ./ 2
    standard_errors = [sqrt(max(0.0, covariance[index, index]))
                       for index in 1:number_of_times]

    all(isfinite, values) || error("the real Green input is non-finite")
    all(isfinite, covariance) || error("the jackknife covariance is non-finite")
    !require_noisy || maximum(standard_errors) > 0.0 || error(
        "the covariance is identically zero; DEAC_Cov requires noisy Monte Carlo bins",
    )
    !require_positive || any(value -> value > 0.0, values) || error(
        "the normalized positive trace has no positive values",
    )
    require_positive && any(value -> value <= 0.0, values) && @warn(
        "the nominally positive trace has nonpositive noisy points; inspect input CSV",
    )

    maximum_imaginary = max(
        maximum(abs, imag.(full_ratio)),
        maximum(abs, imag.(leave_one_out_complex)),
    )
    return (
        values=values,
        covariance=covariance,
        standard_errors=standard_errors,
        average_sign=average_sign,
        full_sign_sum=full_sign_sum,
        full_count=full_count,
        maximum_imaginary=maximum_imaginary,
    )
end

function write_numeric_csv(path, header, data)
    open(path, "w") do io
        println(io, join(header, ','))
        writedlm(io, data, ',')
    end
end

function write_covariance_csv(path, tau, covariance)
    open(path, "w") do io
        print(io, "tau")
        for value in tau
            print(io, ',', value)
        end
        println(io)
        for row in eachindex(tau)
            print(io, tau[row])
            for column in eachindex(tau)
                print(io, ',', covariance[row, column])
            end
            println(io)
        end
    end
end

function append_summary(path, entries)
    open(path, "a") do io
        for (name, value) in entries
            println(io, name, " = ", value)
        end
    end
end

function physical_column_suffix(spin::Symbol)
    spin_indices(spin) # validate before constructing any output paths
    return spin == :both ? "total" : string(spin)
end

function input_csv_header(spin::Symbol)
    suffix = physical_column_suffix(spin)
    return [
        "tau_index", "tau", "G_normalized", "G_normalized_se",
        "G_physical_$suffix", "G_physical_$(suffix)_se",
    ]
end

function spectrum_csv_header(spin::Symbol)
    suffix = physical_column_suffix(spin)
    return [
        "omega", "A_normalized", "A_normalized_deac_se",
        "A_physical_$suffix", "A_physical_$(suffix)_deac_se",
    ]
end

function channel_label(mode, kx_index, ky_index; spin::Symbol=:both)
    physical_column_suffix(spin)
    base = mode == :dos ? "dos" : "ktrace_kx$(kx_index)_ky$(ky_index)"
    return spin == :both ? base : "$(base)_$spin"
end

function all_k_manifest_name(spin::Symbol)
    physical_column_suffix(spin)
    return spin == :both ? "all_k_manifest.csv" : "all_k_$(spin)_manifest.csv"
end

function continue_channel(data, options, mode, kx_index, ky_index, seed)
    spin = options.spin
    physical_factor = physical_trace_factor(spin)
    label = channel_label(mode, kx_index, ky_index; spin=spin)
    time_indices = selected_tau_indices(length(data.tau), options.tau_stride)
    selected_tau = data.tau[time_indices]
    numerators = trace_numerator_bins(
        data,
        mode,
        kx_index,
        ky_index,
        time_indices;
        spin=spin,
    )
    statistics = sign_reweighted_statistics(
        numerators,
        data.sign_sums,
        data.counts,
        options.minimum_sign,
    )

    input_path = joinpath(options.output_dir, label * "_input.csv")
    covariance_path = joinpath(options.output_dir, label * "_covariance.csv")
    summary_path = joinpath(options.output_dir, label * "_summary.txt")
    output_path = joinpath(options.output_dir, label * ".jld2")
    checkpoint_path = joinpath(options.output_dir, label * "_checkpoint.jld2")
    spectrum_path = joinpath(options.output_dir, label * "_spectrum.csv")

    if isfile(output_path) && isfile(spectrum_path)
        println("Skipping completed channel $label")
        return (label=label, status="skipped", output=output_path)
    end

    input_table = hcat(
        time_indices,
        selected_tau,
        statistics.values,
        statistics.standard_errors,
        physical_factor .* statistics.values,
        physical_factor .* statistics.standard_errors,
    )
    write_numeric_csv(
        input_path,
        input_csv_header(spin),
        input_table,
    )
    write_covariance_csv(
        covariance_path,
        selected_tau,
        statistics.covariance,
    )
    isfile(summary_path) && rm(summary_path)
    endpoint_moment = first(statistics.values) + last(statistics.values)
    endpoint_variance = statistics.covariance[1, 1] +
        statistics.covariance[end, end] + 2statistics.covariance[1, end]
    endpoint_standard_error = sqrt(max(0.0, endpoint_variance))
    # The unit anticommutator sum rule is exact. Allow five statistical
    # standard errors plus the same 1e-8 numerical scale used for the
    # stabilization warning; this is a diagnostic, not a continuation gate.
    endpoint_tolerance = max(1.0e-8, 5endpoint_standard_error)
    endpoint_consistent = abs(endpoint_moment - 1.0) <= endpoint_tolerance
    endpoint_consistent || @warn(
        "selected-spin endpoint spectral-weight sum rule is inconsistent",
        spin=spin,
        measured=endpoint_moment,
        expected=1.0,
        tolerance=endpoint_tolerance,
    )
    append_summary(summary_path, [
        "status" => "DEAC_PENDING",
        "source_payload" => options.input_path,
        "mode" => mode,
        "spin" => spin,
        "orbital_trace" => "d_xz + d_yz",
        "kx_index" => (mode == :dos ? "all" : kx_index),
        "ky_index" => (mode == :dos ? "all" : ky_index),
        "kx" => (mode == :dos ? "all" : data.momenta[kx_index]),
        "ky" => (mode == :dos ? "all" : data.momenta[ky_index]),
        "beta" => data.beta,
        "L" => data.L,
        "selected_tau_points" => length(selected_tau),
        "full_green_samples" => statistics.full_count,
        "green_average_sign" => statistics.average_sign,
        "minimum_sign_gate" => options.minimum_sign,
        "maximum_discarded_imaginary_part" => statistics.maximum_imaginary,
        "endpoint_moment_G0_plus_Gbeta" => endpoint_moment,
        "endpoint_moment_standard_error" => endpoint_standard_error,
        "endpoint_moment_tolerance" => endpoint_tolerance,
        "endpoint_moment_consistent" => endpoint_consistent,
        "physical_endpoint_moment" => physical_factor * endpoint_moment,
        "maximum_unequal_time_stabilization_error" =>
            data.maximum_stabilization_error,
        "omega_min" => options.omega_min,
        "omega_max" => options.omega_max,
        "omega_points" => options.omega_points,
        "deac_bins" => options.deac_bins,
        "runs_per_bin" => options.runs_per_bin,
        "generations" => options.generations,
        "base_seed" => seed,
        "normalized_zeroth_moment_expected" => 1.0,
        "physical_channel_factor" => physical_factor,
        "physical_zeroth_moment_expected" => physical_factor,
        "jld2_output" => output_path,
        "checkpoint" => checkpoint_path,
    ])
    if spin == :both
        # Retain the historical metadata key only for the actual total trace.
        append_summary(summary_path, ["physical_total_factor" => physical_factor])
    end

    omega = collect(range(
        options.omega_min,
        options.omega_max;
        length=options.omega_points,
    ))
    println()
    println("Continuing channel $label")
    println("  average sign = ", statistics.average_sign)
    println("  selected tau points = ", length(selected_tau))
    println("  DEAC realizations = ", options.deac_bins * options.runs_per_bin)
    println("  output = ", output_path)

    result = SmoQyDEAC.DEAC_Cov(
        statistics.values,
        statistics.covariance,
        data.beta,
        selected_tau,
        omega,
        "time_fermionic",
        options.deac_bins,
        options.runs_per_bin,
        output_path,
        checkpoint_path;
        base_seed=seed,
        number_of_generations=options.generations,
        autoresume_from_checkpoint=true,
        keep_bin_data=true,
    )
    result isa AbstractDict || error("SmoQyDEAC returned a non-dictionary result")
    haskey(result, "A") && haskey(result, "σ") && haskey(result, "ωs") ||
        error("SmoQyDEAC result lacks A, σ, or ωs")
    spectrum = result["A"]
    spectrum_error = result["σ"]
    result_omega = result["ωs"]
    spectrum isa AbstractMatrix && size(spectrum, 2) == 1 || error(
        "this wrapper expects one DEAC fitness column",
    )
    size(spectrum_error) == size(spectrum) || error(
        "SmoQyDEAC A and σ shapes differ",
    )
    length(result_omega) == size(spectrum, 1) || error(
        "SmoQyDEAC omega and spectrum lengths differ",
    )
    all(isfinite, spectrum) && all(isfinite, spectrum_error) &&
        all(isfinite, result_omega) || error(
            "SmoQyDEAC returned a non-finite spectrum",
        )

    normalized_spectrum = vec(spectrum[:, 1])
    normalized_error = vec(spectrum_error[:, 1])
    spectrum_table = hcat(
        result_omega,
        normalized_spectrum,
        normalized_error,
        physical_factor .* normalized_spectrum,
        physical_factor .* normalized_error,
    )
    write_numeric_csv(
        spectrum_path,
        spectrum_csv_header(spin),
        spectrum_table,
    )
    append_summary(summary_path, [
        "status" => "DEAC_COMPLETE",
        "deac_zeroth_moment" => get(result, "zeroth_moment", "missing"),
        "deac_zeroth_moment_se" => get(result, "zeroth_moment_σ", "missing"),
        "deac_average_generations" => get(result, "avg_generations", "missing"),
        "deac_runtime_seconds" => get(result, "runtime", "missing"),
        "spectrum_csv" => spectrum_path,
    ])
    println("Saved spectrum CSV = ", spectrum_path)
    return (label=label, status="complete", output=output_path)
end

function main(arguments)
    options = parse_options(arguments)
    if isnothing(options)
        print_usage()
        return nothing
    end
    data = load_and_validate_payload(options.input_path)
    if options.mode == :ktrace
        1 <= options.kx_index <= data.L && 1 <= options.ky_index <= data.L ||
            error("--kx-index and --ky-index must lie between 1 and L=$(data.L)")
    end
    mkpath(options.output_dir)

    println("Validated observable payload = ", options.input_path)
    println("Spin channel = ", options.spin)
    println("Output directory = ", options.output_dir)
    if data.maximum_stabilization_error > 1.0e-8
        @warn(
            "maximum unequal-time stabilization error exceeds 1e-8",
            maximum_error=data.maximum_stabilization_error,
        )
    end

    if options.mode == :dos
        continue_channel(data, options, :dos, 1, 1, options.base_seed)
    elseif options.mode == :ktrace
        continue_channel(
            data,
            options,
            :ktrace,
            options.kx_index,
            options.ky_index,
            options.base_seed,
        )
    else
        manifest_path = joinpath(options.output_dir, all_k_manifest_name(options.spin))
        open(manifest_path, "w") do manifest
            println(manifest, "kx_index,ky_index,kx,ky,status,jld2")
            channel_number = 0
            for ky_index in 1:data.L, kx_index in 1:data.L
                seed = options.base_seed +
                    channel_number * options.deac_bins * options.runs_per_bin
                result = continue_channel(
                    data,
                    options,
                    :ktrace,
                    kx_index,
                    ky_index,
                    seed,
                )
                println(
                    manifest,
                    kx_index, ',', ky_index, ',',
                    data.momenta[kx_index], ',', data.momenta[ky_index], ',',
                    result.status, ',', result.output,
                )
                flush(manifest)
                channel_number += 1
            end
        end
        println("Saved all-k manifest = ", manifest_path)
    end
    return nothing
end

if RUN_AS_SCRIPT
    try
        main(ARGS)
    catch exception
        println(stderr, "ERROR: ", sprint(showerror, exception))
        println(stderr, "Run with --help for usage.")
        exit(1)
    end
end
