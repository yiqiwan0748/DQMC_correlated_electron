#!/usr/bin/env julia

if !isdefined(@__MODULE__, :SlaterJastrowTrials)
    include(joinpath(@__DIR__, "slater_jastrow_trials.jl"))
end

module CorrelatedTrialAFQMC

using LinearAlgebra
using Random: rand, shuffle!
import AltermagnetDQMCTrial
import ..SlaterJastrowTrials

const AF = AltermagnetDQMCTrial
const SJ = SlaterJastrowTrials
const MAX_MODES = 8

export CorrelatedState, exact_trial_oracle, determinant_amplitudes,
       apply_kinetic_to_vector, initialize_correlated_afqmc,
       step_correlated_afqmc!, mixed_correlated_observables,
       backpropagated_trial, measure_correlated_afqmc, transition_observables

mutable struct CorrelatedState{B,O,T<:AbstractFloat}
    base::B
    oracle::O
    overlap_evaluations::Int
    numerical_failures::Int
    numerical_overlap_failures::Int
    minimum_overlap_fraction::T
end

function _check_hamiltonian(H::SJ.ED.SectorHamiltonian)
    SJ._check_dimension(H)
    H.basis.nmodes <= MAX_MODES || throw(ArgumentError(
        "correlated AFQMC oracle is limited to $MAX_MODES spatial modes",
    ))
    H.basis.Nup == H.basis.Ndown || throw(ArgumentError(
        "correlated AFQMC oracle currently requires Nup == Ndown",
    ))
    iszero(H.h) || throw(ArgumentError("the projected Hamiltonian must have zero pinning field"))
    return nothing
end

function _occupied_lists(states, modes)
    return [[mode for mode in 1:modes if SJ.ED._occupied(bits, mode)] for bits in states]
end

function _check_orbitals(H, up, down)
    for (matrix, count) in ((up, H.basis.Nup), (down, H.basis.Ndown))
        matrix isa AbstractMatrix{<:Real} || throw(ArgumentError("orbitals must be real matrices"))
        size(matrix) == (H.basis.nmodes, count) || throw(DimensionMismatch(
            "orbital matrices must match the fixed-particle sector",
        ))
        all(isfinite, matrix) || throw(ArgumentError("orbitals must be finite"))
    end
end

function _minor_logs(orbitals, occupations, ::Type{T}) where {T}
    logs, signs = Vector{T}(undef, length(occupations)), Vector{T}(undef, length(occupations))
    for (index, occupied) in enumerate(occupations)
        logs[index], signs[index] = isempty(occupied) ? (zero(T), one(T)) :
            logabsdet(orbitals[occupied, :])
    end
    return logs, signs
end

function _scaled_amplitudes(H, up, down, up_occupied, down_occupied)
    _check_orbitals(H, up, down)
    T = promote_type(eltype(H), typeof(float(zero(eltype(up)))),
                     typeof(float(zero(eltype(down)))))
    up_logs, up_signs = _minor_logs(up, up_occupied, T)
    down_logs, down_signs = _minor_logs(down, down_occupied, T)
    logs = [u + d for u in up_logs for d in down_logs]
    signs = [u * d for u in up_signs for d in down_signs]
    support = findall(!iszero, signs)
    isempty(support) && throw(ArgumentError("walker determinant has zero sector support"))
    all(isfinite, logs[support]) || throw(ArgumentError("walker minors are nonfinite"))
    scale = maximum(logs[support])
    amplitudes = zeros(T, length(logs))
    for index in support
        amplitudes[index] = signs[index] * exp(logs[index] - scale)
        !iszero(amplitudes[index]) || throw(ArgumentError(
            "scaled determinant amplitude underflowed on nonzero support",
        ))
    end
    return (amplitudes=amplitudes, log_scale=scale)
end

"""
Occupation-basis amplitudes of the unnormalized product determinant, with all
up creators before all down creators and down configurations varying fastest.
This finite Fock-space oracle does not canonicalize or normalize its orbitals.
Unrepresentable amplitudes fail explicitly; propagation uses a log-scaled form.
"""
function determinant_amplitudes(H::SJ.ED.SectorHamiltonian, up, down)
    _check_hamiltonian(H)
    scaled = _scaled_amplitudes(H, up, down,
        _occupied_lists(H.basis.up_states, H.basis.nmodes),
        _occupied_lists(H.basis.down_states, H.basis.nmodes))
    amplitudes = similar(scaled.amplitudes)
    for index in eachindex(amplitudes)
        value = scaled.amplitudes[index]
        amplitudes[index] = iszero(value) ? zero(value) :
            sign(value) * exp(log(abs(value)) + scaled.log_scale)
        isfinite(amplitudes[index]) && (iszero(value) || !iszero(amplitudes[index])) ||
            throw(ArgumentError("unnormalized determinant amplitude is not representable"))
    end
    return amplitudes
end

function _wedge_matrix(one_body, occupations)
    T = eltype(one_body)
    wedge = Matrix{T}(undef, length(occupations), length(occupations))
    for column in eachindex(occupations), row in eachindex(occupations)
        wedge[row, column] = isempty(occupations[row]) ? one(T) :
            det(one_body[occupations[row], occupations[column]])
    end
    all(isfinite, wedge) || throw(ArgumentError("exterior-power kinetic matrix is nonfinite"))
    return wedge
end

"""
Construct an enumerated real correlated-trial oracle, bounded to eight spatial
modes and 5000 fixed-sector configurations. No scalable correlated overlap
algorithm or production AFQMC adapter is implied by this helper.

`kinetic_up` and `kinetic_down` are the exterior powers of `kinetic_half`.
For vector C reshaped with down rows and up columns, its one-body image is
`kinetic_down * C * kinetic_up'`. The normalized trial and H*trial are cached.
"""
function exact_trial_oracle(H::SJ.ED.SectorHamiltonian, trial_state;
                            Lx, Ly, kinetic_half, overlap_tolerance=1.0e-12)
    _check_hamiltonian(H)
    overlap_tolerance isa Real && !(overlap_tolerance isa Bool) &&
        isfinite(overlap_tolerance) && 0 < overlap_tolerance < 1 || throw(ArgumentError(
            "overlap_tolerance must be finite and in (0,1)",
        ))
    T = eltype(H)
    tolerance = T(overlap_tolerance)
    0 < tolerance < 1 || throw(ArgumentError("overlap_tolerance is not representable"))
    modes = H.basis.nmodes
    kinetic_half isa AbstractMatrix{<:Real} && size(kinetic_half) == (modes, modes) ||
        throw(DimensionMismatch("kinetic_half must be a real M-by-M matrix"))
    all(isfinite, kinetic_half) || throw(ArgumentError("kinetic_half must be finite"))
    half = Matrix{T}(kinetic_half)
    all(isfinite, half) || throw(ArgumentError("kinetic_half conversion is nonfinite"))
    trial = Vector{T}(SJ._normalized_state(H, trial_state))
    norm(trial) > 0 && all(isfinite, trial) || throw(ArgumentError("trial conversion failed"))
    trial ./= norm(trial)
    diagonals = SJ.diagonal_observables(H; Lx=Lx, Ly=Ly)
    up_occupied = _occupied_lists(H.basis.up_states, modes)
    down_occupied = _occupied_lists(H.basis.down_states, modes)
    spin_occupations = Matrix{Int8}(undef, length(H.basis), modes)
    for index in axes(spin_occupations, 1)
        up, down = SJ.ED._basis_state(H.basis, index)
        for mode in 1:modes
            spin_occupations[index, mode] =
                Int8(SJ.ED._occupied(up, mode)) - Int8(SJ.ED._occupied(down, mode))
        end
    end
    Htrial = H * trial
    all(isfinite, Htrial) || throw(ArgumentError("H*trial is nonfinite"))
    return (H=H, trial=trial, Htrial=Htrial, diagonals=diagonals,
            spin_occupations=spin_occupations, up_occupied=up_occupied,
            down_occupied=down_occupied, kinetic_half=half,
            kinetic_up=_wedge_matrix(half, up_occupied),
            kinetic_down=_wedge_matrix(half, down_occupied), tolerance=tolerance,
            Lx=Int(Lx), Ly=Int(Ly), trial_phase=1)
end

function _checked_vector(oracle, vector)
    vector isa AbstractVector{<:Real} || throw(ArgumentError("Fock vector must be real"))
    length(vector) == length(oracle.trial) || throw(DimensionMismatch("Fock vector has wrong size"))
    all(isfinite, vector) || throw(ArgumentError("Fock vector must be finite"))
    return vector
end

"""Apply the exact exterior-power kinetic-half map, without normalizing."""
function apply_kinetic_to_vector(oracle, vector; transpose::Bool=false)
    _checked_vector(oracle, vector)
    coefficients = reshape(vector, length(oracle.down_occupied), length(oracle.up_occupied))
    up = transpose ? LinearAlgebra.transpose(oracle.kinetic_up) : oracle.kinetic_up
    down = transpose ? LinearAlgebra.transpose(oracle.kinetic_down) : oracle.kinetic_down
    propagated = vec(down * coefficients * LinearAlgebra.transpose(up))
    all(isfinite, propagated) || throw(ArgumentError("kinetic Fock action is nonfinite"))
    return propagated
end

function _scaled_determinant_amplitudes(oracle, up, down)
    return _scaled_amplitudes(oracle.H, up, down, oracle.up_occupied, oracle.down_occupied)
end

function _contraction(oracle, left, right; context="overlap")
    _checked_vector(oracle, left)
    _checked_vector(oracle, right)
    products = left .* right
    value, magnitude = sum(products), sum(abs, products)
    norm_scale = norm(left) * norm(right)
    isfinite(value) && isfinite(magnitude) && isfinite(norm_scale) || error("$context is nonfinite")
    scale = max(magnitude, norm_scale)
    scale > 0 && abs(value) > oracle.tolerance * scale || error(
        "$context is zero or cancellation-dominated at tolerance $(oracle.tolerance)",
    )
    return (value=value, fraction=abs(value) / scale)
end

function _walker_overlap(state, up, down; context="walker overlap")
    scaled = _scaled_determinant_amplitudes(state.oracle, up, down)
    contracted = _counted_contraction(state, state.oracle.trial, scaled.amplitudes; context=context)
    return (log_overlap=log(abs(contracted.value)) + scaled.log_scale,
            sign=sign(contracted.value), amplitudes=scaled.amplitudes,
            log_scale=scaled.log_scale)
end

function _counted_contraction(state, left, right; context="overlap")
    state.overlap_evaluations += 1
    return try
        contracted = _contraction(state.oracle, left, right; context=context)
        state.minimum_overlap_fraction = min(state.minimum_overlap_fraction, contracted.fraction)
        contracted
    catch
        state.numerical_overlap_failures += 1
        rethrow()
    end
end

"""
Initialize determinant walkers, using a Slater state only as their starting
point. The full correlated state controls every subsequent overlap, constraint,
importance ratio and estimator. Its global phase is aligned to the initializer;
an absent or cancellation-dominated initial overlap is rejected.
"""
function initialize_correlated_afqmc(H::SJ.ED.SectorHamiltonian, parameters::AF.CPAFQMCParameters;
                                    trial_state, initializer::AF.SlaterTrial, Lx, Ly,
                                    overlap_tolerance=1.0e-12)
    _check_hamiltonian(H)
    SJ.diagonal_observables(H; Lx=Lx, Ly=Ly)
    problem = AF.CPAFQMCProblem(H.kinetic, H.U, H.basis.Nup, H.basis.Ndown;
        cell_count=Lx * Ly, lattice_size=Lx == Ly ? Lx : nothing)
    base = AF.initialize_cp_afqmc(problem, parameters; trial=initializer)
    isfinite(exp(base.gamma)) || throw(ArgumentError("HS row factor is not representable"))
    oracle = exact_trial_oracle(H, trial_state; Lx=Lx, Ly=Ly,
        kinetic_half=base.kinetic_half, overlap_tolerance=overlap_tolerance)
    first_walker = first(base.walkers)
    scaled = _scaled_determinant_amplitudes(oracle, first_walker.up, first_walker.down)
    initial = _contraction(oracle, oracle.trial, scaled.amplitudes; context="initial trial overlap")
    if initial.value < 0
        oracle.trial .*= -1
        oracle.Htrial .*= -1
        oracle = merge(oracle, (trial_phase=-1,))
    end
    for walker in base.walkers
        walker.log_overlap = log(abs(initial.value)) + scaled.log_scale
    end
    return CorrelatedState(base, oracle, 1, 0, 0, eltype(H)(initial.fraction))
end

function _apply_kinetic!(state, walker)
    up = state.base.kinetic_half * walker.up
    down = state.base.kinetic_half * walker.down
    overlap = _walker_overlap(state, up, down; context="kinetic trial overlap")
    overlap.sign > 0 || return AF._cp_kill!(state.base, walker)
    walker.log_weight += overlap.log_overlap - walker.log_overlap
    walker.log_overlap = overlap.log_overlap
    walker.up, walker.down = up, down
    return true
end

function _site_ratios(oracle, amplitudes, index, gamma; state=nothing)
    index isa Integer && !(index isa Bool) && 1 <= index <= size(oracle.spin_occupations, 2) ||
        throw(ArgumentError("site index is outside the spatial-mode range"))
    gamma isa Real && isfinite(gamma) || throw(ArgumentError("gamma must be finite"))
    contracted = isnothing(state) ?
        _contraction(oracle, oracle.trial, amplitudes; context="HS denominator") :
        _counted_contraction(state, oracle.trial, amplitudes; context="HS denominator")
    denominator = contracted.value
    denominator > 0 || error("HS denominator must be positive")
    plus = dot(oracle.trial, amplitudes .* exp.(gamma .* view(oracle.spin_occupations, :, index))) /
           denominator
    minus = dot(oracle.trial, amplitudes .* exp.(-gamma .* view(oracle.spin_occupations, :, index))) /
            denominator
    isfinite(plus) && isfinite(minus) || error("HS importance ratio is nonfinite")
    return (plus=plus, minus=minus)
end

function _apply_potential!(state, walker)
    base, oracle = state.base, state.oracle
    scaled = _scaled_determinant_amplitudes(oracle, walker.up, walker.down)
    amplitudes = scaled.amplitudes
    shuffle!(base.rng, base.site_order)
    fields = Vector{Int8}(undef, length(base.site_order))
    factor = exp(base.gamma)
    for index in base.site_order
        ratios = _site_ratios(oracle, amplitudes, index, base.gamma; state=state)
        plus, minus = max(ratios.plus, 0) / 2, max(ratios.minus, 0) / 2
        iszero(plus) && (base.constraint_rejections += 1)
        iszero(minus) && (base.constraint_rejections += 1)
        total = plus + minus
        total > 0 && isfinite(total) || return nothing
        field = rand(base.rng) < plus / total ? Int8(1) : Int8(-1)
        fields[index] = field
        walker.log_weight += log(total)
        up_factor = field > 0 ? factor : inv(factor)
        @views walker.up[index, :] .*= up_factor
        @views walker.down[index, :] .*= inv(up_factor)
        amplitudes .*= exp.(field * base.gamma .* view(oracle.spin_occupations, :, index))
        scale = maximum(abs, amplitudes)
        isfinite(scale) && scale > 0 || error("HS Fock amplitudes are not representable")
        amplitudes ./= scale
    end
    overlap = _walker_overlap(state, walker.up, walker.down; context="post-HS trial overlap")
    overlap.sign > 0 || return nothing
    walker.log_overlap = overlap.log_overlap
    return fields
end

function _stabilize!(state, walker)
    walker.up = AF._cp_canonical_columns(walker.up)
    walker.down = AF._cp_canonical_columns(walker.down)
    overlap = _walker_overlap(state, walker.up, walker.down; context="stabilized trial overlap")
    overlap.sign > 0 || return AF._cp_kill!(state.base, walker)
    walker.log_overlap = overlap.log_overlap
    return true
end

"""
Advance the bounded correlated-trial population by one symmetric time slice.
The constant centered-Hubbard HS factor cancels during population normalization,
as in the existing Slater implementation. Numerical overlap failures abort the
step; they are never silently converted into physical constraint rejections.
The finite numerical cutoff can affect which paths or runs remain accessible,
so its value and failure count must accompany any scientific comparison.
"""
function step_correlated_afqmc!(state::CorrelatedState)
    iszero(state.numerical_failures) || error(
        "a previous step failed; restore the last complete checkpoint before continuing",
    )
    base = state.base
    rejected, killed = base.constraint_rejections, base.killed_walkers
    try
        for walker in base.walkers
            walker.alive || continue
            _apply_kinetic!(state, walker) || continue
            fields = _apply_potential!(state, walker)
            isnothing(fields) && (AF._cp_kill!(base, walker); continue)
            _apply_kinetic!(state, walker) || continue
            if (base.step + 1) % base.parameters.orthogonalize_every == 0
                _stabilize!(state, walker) || continue
            end
            end_id = base.next_lineage_id
            base.next_lineage_id += 1
            AF._cp_append_history!(base, walker, fields, end_id)
        end
        base.step += 1
        live = AF._cp_normalize_weights!(base)
        if base.step % base.parameters.population_control_every == 0
            AF._cp_population_control!(base)
            live = length(base.walkers)
        end
        return (step=base.step, live_walkers=live,
                constraint_rejections=base.constraint_rejections - rejected,
                killed_walkers=base.killed_walkers - killed)
    catch
        state.numerical_failures += 1
        rethrow()
    end
end

function _local_observables(oracle, left, right; left_h=nothing, state=nothing)
    contracted = isnothing(state) ?
        _contraction(oracle, left, right; context="estimator denominator") :
        _counted_contraction(state, left, right; context="estimator denominator")
    denominator = contracted.value
    action = isnothing(left_h) ? oracle.H * left : left_h
    _checked_vector(oracle, action)
    energy = dot(action, right) / denominator
    products = left .* right ./ denominator
    diagonals = map(values -> dot(values, products), oracle.diagonals)
    centered = oracle.H.U * (diagonals.double_occupancy_total -
        (oracle.H.basis.Nup + oracle.H.basis.Ndown) / 2 + oracle.H.basis.nmodes / 4)
    result = merge((energy=energy, kinetic_energy=energy - centered,
                    centered_interaction_energy=centered), diagonals)
    all(isfinite, values(result)) || error("correlated local estimator is nonfinite")
    return result
end

"""Exact finite-Fock transition estimators with the same fields as mixed and BP data."""
transition_observables(oracle, left, right) = _local_observables(oracle, left, right)

"""Exact mixed contractions; no Wick factorization is used for the correlated bra."""
function mixed_correlated_observables(state::CorrelatedState, walker)
    scaled = _scaled_determinant_amplitudes(state.oracle, walker.up, walker.down)
    return _local_observables(state.oracle, state.oracle.trial, scaled.amplitudes;
                              left_h=state.oracle.Htrial, state=state)
end

function _normalize_fock(vector; context="back-propagated Fock state")
    all(isfinite, vector) || error("$context is nonfinite")
    scale = maximum(abs, vector)
    scale > 0 || error("$context is zero")
    normalized = vector ./ scale
    normalized ./= norm(normalized)
    return normalized
end

"""
Back propagate the full correlated bra through the reversed stored HS history.
Exterior powers apply each transposed kinetic half, with positive normalization
after each factor. The returned vector has unit norm; its scalar normalization
cancels from every BP estimator. This is constrained-path back propagation,
not an unbiased pure estimator or a path-restoration algorithm.
"""
function backpropagated_trial(state::CorrelatedState, walker)
    oracle, base = state.oracle, state.base
    left = copy(oracle.trial)
    for fields in Iterators.reverse(walker.fields)
        length(fields) == oracle.H.basis.nmodes && all(field -> field in (-1, 1), fields) ||
            throw(ArgumentError("back-propagation fields must contain M signs"))
        left = _normalize_fock(apply_kinetic_to_vector(oracle, left; transpose=true))
        exponents = base.gamma .* (oracle.spin_occupations * fields)
        support = findall(!iszero, left)
        shift = maximum(exponents[support])
        for index in support
            left[index] *= exp(exponents[index] - shift)
        end
        left = _normalize_fock(left)
        left = _normalize_fock(apply_kinetic_to_vector(oracle, left; transpose=true))
    end
    return left
end

"""
Measure normalized current population weights with full correlated mixed and
optional constrained-path BP estimators. A requested BP history must be full
and meet the existing distinct-ancestor gate. Delta is signed; Delta^2 and the
four orbital-odd fixed form factors are independent exact contractions.
"""
function measure_correlated_afqmc(state::CorrelatedState; backpropagation::Bool=true)
    iszero(state.numerical_failures) || error(
        "cannot measure a partly advanced state after a failed step",
    )
    base, oracle = state.base, state.oracle
    live = [walker for walker in base.walkers if walker.alive]
    isempty(live) && error("there are no live correlated-trial walkers to measure")
    all(walker -> isfinite(walker.log_weight), live) || error("live walker weights are nonfinite")
    largest = maximum(walker.log_weight for walker in live)
    weights = [exp(walker.log_weight - largest) for walker in live]
    weights ./= sum(weights)
    use_bp = backpropagation && base.parameters.back_propagation_steps > 0
    ancestors = use_bp ? length(unique(walker.anchor_id for walker in live)) : 0
    if use_bp
        all(walker -> length(walker.fields) == base.parameters.back_propagation_steps, live) ||
            error("back-propagation history is not full")
        ancestors >= base.parameters.minimum_backprop_ancestors || error(
            "back-propagation ancestry collapsed to $ancestors distinct walkers; " *
            "minimum_backprop_ancestors=$(base.parameters.minimum_backprop_ancestors)",
        )
    end
    mixed = nothing
    backpropagated = nothing
    for (walker, weight) in zip(live, weights)
        local_mixed = mixed_correlated_observables(state, walker)
        weighted = map(value -> weight * value, local_mixed)
        mixed = isnothing(mixed) ? weighted : map(+, mixed, weighted)
        if use_bp
            left = backpropagated_trial(state, walker)
            anchor = _scaled_determinant_amplitudes(oracle, walker.anchor_up, walker.anchor_down)
            local_bp = _local_observables(oracle, left, anchor.amplitudes; state=state)
            weighted_bp = map(value -> weight * value, local_bp)
            backpropagated = isnothing(backpropagated) ? weighted_bp :
                map(+, backpropagated, weighted_bp)
        end
    end
    metadata = (method="bounded exact-Fock correlated-trial CP-AFQMC",
                backpropagation="constrained-path BP without path restoration; not unbiased",
                modes=oracle.H.basis.nmodes, configurations=length(oracle.trial),
                trial_phase=oracle.trial_phase, overlap_tolerance=oracle.tolerance,
                overlap_cutoff="finite numerical cutoff can affect accessible paths; failures abort",
                overlap_evaluations=state.overlap_evaluations,
                numerical_failures=state.numerical_failures,
                numerical_overlap_failures=state.numerical_overlap_failures,
                minimum_overlap_fraction=state.minimum_overlap_fraction)
    return (step=base.step, mixed=mixed, backpropagated=backpropagated,
            distinct_backprop_ancestors=ancestors, metadata=metadata)
end

end # module
