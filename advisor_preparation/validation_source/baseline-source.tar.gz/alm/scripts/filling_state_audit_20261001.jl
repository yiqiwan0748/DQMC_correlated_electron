#!/usr/bin/env julia
# Local T=0 filling and finite-torus shell audit. Uses only Julia stdlib.
using LinearAlgebra, SHA, TOML, Dates, Test
include(joinpath(@__DIR__, "two_orbital_tilted_cluster_ed.jl"))
const G = TwoOrbitalTiltedClusterED
const B = G.ValidatedModel
const ROOT = normpath(joinpath(@__DIR__, ".."))

# Independent analytic implementation, checked against dense Bloch eigenvalues.
@inline function levels(cx, cy, sx, sy)
    a = 2cx + 3.5cy + 3.4cx*cy
    d = 3.5cx + 2cy + 3.4cx*cy
    b = 2.6sx*sy
    m = (a+d)/2
    r = hypot((a-d)/2, b)
    m-r, m+r
end

function count_mesh(nk, anchors)
    k = [-pi + 2pi*j/nk for j in 0:nk-1]
    c, s = cos.(k), sin.(k)
    below, equal = zeros(Int, length(anchors)), zeros(Int, length(anchors))
    for j in 1:nk, i in 1:nk
        lo, hi = levels(c[i],c[j],s[i],s[j])
        for (a, mu) in enumerate(anchors), e in (lo, hi)
            below[a] += e < mu - 1e-12
            equal[a] += abs(e-mu) <= 1e-12
        end
    end
    [Dict("Nk"=>nk, "mu"=>mu, "below_spatial_states"=>below[a],
          "equal_spatial_states"=>equal[a],
          "density_strict"=>2below[a]/nk^2,
          "density_inclusive"=>2(below[a]+equal[a])/nk^2,
          "delta_a_inclusive"=>2(below[a]+equal[a])/nk^2-2,
          "delta_b_inclusive"=>(2(below[a]+equal[a])/nk^2-2)/2,
          "delta_c_inclusive"=>(2(below[a]+equal[a])/nk^2-2)/4)
     for (a,mu) in enumerate(anchors)]
end

function main(out)
    ispath(out) && error("Refusing to overwrite existing audit: $out")
    started = now(UTC)
    checks = Dict{String,Any}()
    @testset "independent Bloch formula and saddle" begin
        for (kx,ky) in ((0.,0.),(pi,0.),(pi,pi),(.37,-1.23),(1.8,2.4))
            independent = collect(levels(cos(kx),cos(ky),sin(kx),sin(ky)))
            @test isapprox(independent, eigvals(Symmetric(G.bloch_hamiltonian(kx,ky))); atol=1e-12,rtol=1e-12)
        end
        @test isapprox(B.band_energies(pi,0.),[-4.9,-1.9]; atol=1e-12,rtol=0)
        step = 1e-4
        upper(x,y) = B.band_energies(x,y)[2]
        e = upper(pi,0.)
        xx = (upper(pi+step,0.)-2*e+upper(pi-step,0.))/step^2
        yy = (upper(pi,step)-2*e+upper(pi,-step))/step^2
        @test isapprox(xx,5.4;atol=1e-5,rtol=0)
        @test isapprox(yy,-.1;atol=1e-5,rtol=0)
        checks["upper_X_energy"] = e
        checks["upper_X_numerical_hessian_diagonal"] = [xx,yy]
        checks["bloch_energy_atol"] = 1e-12
        checks["hessian_atol"] = 1e-5
        checks["hessian_step"] = step
    end
    anchors = [-1.9,-1.8970820299]
    mesh = Any[]
    timings = Dict{String,Float64}()
    for nk in (384,768,1536,3072)
        seconds = @elapsed append!(mesh,count_mesh(nk,anchors))
        timings[string(nk)] = seconds
    end
    torus = G.standard_eight_site_torus()
    kinetic = G.tilted_kinetic_matrix(torus)
    real_levels = eigvals(Symmetric(kinetic))
    rows = Any[]
    for (ki,(kx,ky)) in enumerate(torus.momenta)
        for (band,e) in enumerate(B.band_energies(kx,ky))
            push!(rows,Dict("momentum_index"=>ki,"kx"=>kx,"ky"=>ky,
                           "band"=>band,"energy"=>e,"occupied_per_spin_N6"=>e < -2.35))
        end
    end
    sorted_bloch = sort([r["energy"] for r in rows])
    @testset "finite torus shell and density" begin
        @test isapprox(real_levels,sorted_bloch;atol=1e-12,rtol=1e-12)
        @test count(<(-2.35),sorted_bloch) == 6
        @test isapprox(2sum(sorted_bloch[1:6]),-40.4;atol=1e-12,rtol=0)
        @test isapprox(sorted_bloch[7]-sorted_bloch[6],.5;atol=1e-12,rtol=0)
    end
    strict = count(e->e < -1.9-1e-12,sorted_bloch)
    equal = count(e->abs(e+1.9)<=1e-12,sorted_bloch)
    final_exact = mesh[end-1]
    previous_exact = mesh[end-3]
    report = Dict{String,Any}(
        "started_utc"=>string(started),"completed_utc"=>string(now(UTC)),
        "julia_version"=>string(VERSION),"threads"=>Threads.nthreads(),
        "parameters"=>[-1.,-1.75,-.85,-.65],"U"=>0.,"T"=>0.,
        "density_definition"=>"spin-summed electrons per cell, range 0..4",
        "mesh_normalization"=>"2/Nk^2 times occupied spatial Bloch levels",
        "occupation_equality_atol"=>1e-12,"checks"=>checks,"mesh"=>mesh,
        "mesh_seconds"=>timings,
        "finest_exact_saddle_density_change"=>final_exact["density_inclusive"]-previous_exact["density_inclusive"],
        "source_delta_definition_status"=>"unresolved; (n-2)/4 is an inferred convention, not an explicit primary-source definition",
        "torus"=>Dict("a1"=>[2,2],"a2"=>[-2,2],"Ncells"=>8,"Nup"=>6,"Ndown"=>6,
            "density"=>1.5,"delta_c_if_inferred"=>-.125,"energy"=>2sum(sorted_bloch[1:6]),
            "homo"=>sorted_bloch[6],"lumo"=>sorted_bloch[7],"occupation_gap"=>sorted_bloch[7]-sorted_bloch[6],
            "midgap_mu"=>(sorted_bloch[6]+sorted_bloch[7])/2,
            "electron_count_below_bulk_vH"=>2strict,"electron_count_at_or_below_bulk_vH"=>2(strict+equal),
            "spatial_levels"=>rows),
        "scope"=>"Noninteracting filling and shell diagnostic only; does not infer interacting chemical potential or change the fixed-density model",
        "source_hashes"=>Dict(rel=>bytes2hex(sha256(read(joinpath(ROOT,rel)))) for rel in
            ("scripts/filling_state_audit_20261001.jl","scripts/two_orbital_tilted_cluster_ed.jl","src/noninteracting.jl")))
    mkpath(out)
    open(joinpath(out,"filling_audit.toml"),"w") do io
        TOML.print(io,report;sorted=true)
    end
    open(joinpath(out,"torus_levels.csv"),"w") do io
        println(io,"momentum_index,kx,ky,band,energy,occupied_per_spin_N6")
        for r in rows
            println(io,join([r[k] for k in ("momentum_index","kx","ky","band","energy","occupied_per_spin_N6")],','))
        end
    end
    println("audit_path=",abspath(out))
    for row in mesh
        println("Nk=",row["Nk"]," mu=",row["mu"]," n_inclusive=",row["density_inclusive"]," n_strict=",row["density_strict"])
    end
    println("torus_N12_HOMO=",report["torus"]["homo"]," LUMO=",report["torus"]["lumo"],
            " bulk_vH_counts=",2strict,"..",2(strict+equal))
end

length(ARGS)==1 || error("Usage: julia --project=. scripts/filling_state_audit_20261001.jl NEW_OUTPUT_DIRECTORY")
main(ARGS[1])
