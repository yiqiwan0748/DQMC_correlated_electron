using Plots
using Printf

const ROOT = normpath(joinpath(@__DIR__, ".."))
const M3_CSV = joinpath(ROOT, "results", "realspace_kinetic", "validation_summary.csv")
const M4_META = joinpath(ROOT, "results", "free_fermion", "metadata.txt")
const M5_CSV = joinpath(ROOT, "results", "dqmc_smoke", "validation_summary.csv")
const OUTPUT = joinpath(ROOT, "results", "meeting_prep", "dqmc_feasibility_summary.png")

function csv_data(path)
    lines = readlines(path)
    isempty(lines) && error("empty CSV: $path")
    return split(lines[1], ','), [split(line, ',') for line in lines[2:end] if !isempty(line)]
end

function csv_column(path, name)
    header, rows = csv_data(path)
    index = findfirst(==(name), header)
    isnothing(index) && error("missing column $name in $path")
    return String[row[index] for row in rows]
end

function stored_maximum(path, name)
    values = csv_column(path, name)
    return values[argmax(parse.(Float64, values))]
end

function stored_maximum_where(path, value_name, filter_name, predicate)
    header, rows = csv_data(path)
    value_index = findfirst(==(value_name), header)
    isnothing(value_index) && error("missing column $value_name in $path")
    filter_index = findfirst(==(filter_name), header)
    isnothing(filter_index) && error("missing column $filter_name in $path")
    matches = filter(row -> predicate(row[filter_index]), rows)
    isempty(matches) && error("no matching rows in $path")
    values = String[row[value_index] for row in matches]
    return values[argmax(parse.(Float64, values))], length(values)
end

function csv_cell(path, key_name, key_value, value_name)
    header, rows = csv_data(path)
    key_index = findfirst(==(key_name), header)
    isnothing(key_index) && error("missing column $key_name")
    value_index = findfirst(==(value_name), header)
    isnothing(value_index) && error("missing column $value_name")
    matches = filter(row -> row[key_index] == key_value, rows)
    length(matches) == 1 || error("expected one $key_name=$key_value row in $path")
    return String(only(matches)[value_index])
end

function metadata(path)
    values = Dict{String,String}()
    for line in eachline(path)
        occursin('=', line) || continue
        parts = split(line, '='; limit=2)
        values[String(parts[1])] = String(parts[2])
    end
    return values
end

const SUPERSCRIPT_CHARACTER = Dict(
    '-' => '⁻',
    '0' => '⁰',
    '1' => '¹',
    '2' => '²',
    '3' => '³',
    '4' => '⁴',
    '5' => '⁵',
    '6' => '⁶',
    '7' => '⁷',
    '8' => '⁸',
    '9' => '⁹',
)

function presentation_scientific(value)
    return @sprintf("%.1e", parse(Float64, value))
end

m3_fourier = presentation_scientific(stored_maximum(M3_CSV, "max_fourier_block_error"))
m3_spectrum = presentation_scientific(stored_maximum(M3_CSV, "max_spectrum_error"))
m4 = metadata(M4_META)
m4_product = presentation_scientific(m4["maximum_propagator_product_error"])
m4_safe_g = presentation_scientific(m4["maximum_direct_safe_G_error"])
m4_filling = presentation_scientific(m4["maximum_filling_mismatch"])
m5_u0_recompute = presentation_scientific(csv_cell(
    M5_CSV,
    "case",
    "u0_integration",
    "maximum_greens_recompute_error",
))
m5_interacting_recompute_raw, m5_interacting_cases = stored_maximum_where(
    M5_CSV,
    "maximum_greens_recompute_error",
    "U",
    value -> parse(Float64, value) > 0,
)
m5_interacting_recompute = presentation_scientific(m5_interacting_recompute_raw)

function rectangle!(p, x1, x2, y1, y2; fill, stroke="#CBD5E1", width=1.2)
    plot!(
        p,
        Shape([x1, x2, x2, x1], [y1, y1, y2, y2]);
        seriestype=:shape,
        fillcolor=fill,
        fillalpha=1,
        linecolor=stroke,
        linewidth=width,
        label="",
    )
end

function note!(p, x, y, value; size=16, color="#1F2937", align=:left)
    annotate!(p, x, y, text(value, size, color, align))
end

plotly = plot(
    xlims=(0, 16),
    ylims=(0, 9),
    size=(1920, 1080),
    axis=false,
    ticks=false,
    framestyle=:none,
    legend=false,
    background_color=:white,
    foreground_color_subplot=:white,
)

navy = "#17324D"
blue = "#2F6B9A"
ink = "#1F2937"
muted = "#5B6775"
light_blue = "#EEF5FA"
light_gray = "#F7F8FA"

note!(plotly, 8.0, 8.48, "Two-orbital DQMC code validation"; size=32, color=navy, align=:center)

cards = (
    (0.35, 3.25, "Bloch Hamiltonian H(k)"),
    (3.65, 7.05, "Real-space kinetic matrix K\ndimension 2L² by 2L²"),
    (7.45, 12.05, "Free finite-temperature propagators B\nand Green functions G"),
    (12.45, 15.65, "Two-orbital DQMC kernel"),
)
for (x1, x2, label) in cards
    rectangle!(plotly, x1, x2, 6.73, 7.75; fill=light_blue, stroke="#8EB4D1", width=1.5)
    note!(plotly, (x1 + x2) / 2, 7.24, label; size=17, color=navy, align=:center)
end
for x in (3.45, 7.25, 12.25)
    note!(plotly, x, 7.24, "→"; size=24, color=blue, align=:center)
end

rectangle!(plotly, 0.55, 15.45, 1.72, 6.30; fill=:white, stroke="#AAB4C0", width=1.5)
rectangle!(plotly, 0.55, 15.45, 5.67, 6.30; fill=navy, stroke=navy, width=1.5)
note!(plotly, 0.82, 5.99, "COMPONENT"; size=16, color=:white)
note!(plotly, 5.15, 5.99, "NUMERICAL CHECK"; size=16, color=:white)
plot!(plotly, [4.85, 4.85], [1.72, 6.30]; color="#CBD5E1", linewidth=1.2, label="")

row_bounds = ((4.35, 5.67), (3.03, 4.35), (1.72, 3.03))
for (index, (bottom, top)) in enumerate(row_bounds)
    index % 2 == 0 && rectangle!(plotly, 0.56, 15.44, bottom, top; fill=light_gray, stroke=light_gray, width=0)
    bottom > 1.72 && plot!(plotly, [0.55, 15.45], [bottom, bottom]; color="#D9E0E7", linewidth=1, label="")
end

note!(plotly, 0.82, 5.01, "Real-space kinetic matrix"; size=19, color=navy)
note!(plotly, 5.15, 5.01, "Maximum discrepancy in Fourier blocks and energy spectrum:\n$m3_spectrum."; size=18, color=ink)

note!(plotly, 0.82, 3.69, "Free-fermion calculation"; size=19, color=navy)
note!(plotly, 5.15, 3.69, "Maximum discrepancy in propagators, Green functions, and filling:\n$m4_product."; size=18, color=ink)

note!(plotly, 0.82, 2.38, "Small deterministic DQMC checks"; size=19, color=navy)
note!(plotly, 5.15, 2.38, "Maximum Green-function recomputation correction:\n$m5_u0_recompute at U = 0; $m5_interacting_recompute across two U > 0 cases."; size=18, color=ink)

rectangle!(plotly, 0.55, 15.45, 0.34, 1.38; fill=light_blue, stroke="#6F9FC2", width=1.8)
note!(plotly, 0.82, 1.05, "Validated on small deterministic U = 0 and U > 0 cases."; size=18, color=navy)
note!(plotly, 0.82, 0.67, "Next: map the average fermion sign, then measure altermagnetic correlations."; size=18, color=ink)

mkpath(dirname(OUTPUT))
savefig(plotly, OUTPUT)

println("m3_max_fourier_block_error=$m3_fourier")
println("m3_max_spectrum_error=$m3_spectrum")
println("m4_max_propagator_product_error=$m4_product")
println("m4_max_direct_safe_G_error=$m4_safe_g")
println("m4_max_filling_mismatch=$m4_filling")
println("m5_u0_smoke_recompute_error=$m5_u0_recompute")
println("m5_interacting_case_count=$m5_interacting_cases")
println("m5_interacting_max_recompute_error=$m5_interacting_recompute")
println("output=$OUTPUT")
