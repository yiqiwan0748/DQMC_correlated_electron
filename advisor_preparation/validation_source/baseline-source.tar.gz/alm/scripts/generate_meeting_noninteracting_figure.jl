ENV["GKSwstype"] = "100"

using Plots
using Printf

const REPOSITORY_ROOT = normpath(joinpath(@__DIR__, ".."))
const SOURCE_DIRECTORY = joinpath(REPOSITORY_ROOT, "results", "noninteracting")
const OUTPUT_DIRECTORY = joinpath(REPOSITORY_ROOT, "results", "meeting_prep")

const DOS_SOURCE = joinpath(SOURCE_DIRECTORY, "dos.csv")
const FILLING_SOURCE = joinpath(SOURCE_DIRECTORY, "filling_curve.csv")
const VHS_SOURCE = joinpath(SOURCE_DIRECTORY, "vhs_summary.csv")

const FIGURE_PATH = joinpath(OUTPUT_DIRECTORY, "dos_and_filling_clarified.png")
const CAPTION_PATH = joinpath(OUTPUT_DIRECTORY, "dos_and_filling_caption.md")
const METADATA_PATH = joinpath(OUTPUT_DIRECTORY, "dos_and_filling_metadata.txt")

const BLUE = "#0072B2"
const ORANGE = "#D55E00"

"""Read the repository's simple, unquoted CSV outputs without adding a dependency."""
function read_simple_csv(path)
    lines = readlines(path)
    isempty(lines) && error("CSV file is empty: $path")

    header = String.(split(chomp(first(lines)), ','; keepempty=true))
    columns = Dict(name => String[] for name in header)
    for (row_number, line) in enumerate(Iterators.drop(lines, 1))
        line_number = row_number + 1
        isempty(strip(line)) && continue
        cells = String.(split(chomp(line), ','; keepempty=true))
        length(cells) == length(header) ||
            error("CSV column mismatch in $path at line $line_number")
        for (name, cell) in zip(header, cells)
            push!(columns[name], cell)
        end
    end
    return columns
end

function select_peak(table, Nk, journal_label)
    matches = findall(eachindex(table["Nk"])) do index
        table["Nk"][index] == Nk &&
            table["journal_label"][index] == journal_label
    end
    length(matches) == 1 || error(
        "Expected one Nk=$Nk row for $journal_label in $VHS_SOURCE",
    )
    index = only(matches)
    return (
        peak_order=parse(Int, table["peak_order"][index]),
        mu=parse(Float64, table["mu_vH"][index]),
        mu_text=table["mu_vH"][index],
        filling=parse(Float64, table["filling"][index]),
        filling_text=table["filling"][index],
        delta_calc=parse(Float64, table["delta_c"][index]),
        delta_calc_text=table["delta_c"][index],
        journal_value=parse(Float64, table["journal_value"][index]),
        journal_value_text=table["journal_value"][index],
    )
end

dos_table = read_simple_csv(DOS_SOURCE)
filling_table = read_simple_csv(FILLING_SOURCE)
vhs_table = read_simple_csv(VHS_SOURCE)

Nk = only(unique(dos_table["Nk"]))
energy_bins = only(unique(dos_table["energy_bins"]))
smoothing_width = only(unique(dos_table["smoothing_width"]))

Nk == "800" || error("Expected the persisted primary DOS to use Nk=800")
all(==(Nk), filling_table["Nk"]) ||
    error("The persisted filling curve does not consistently use Nk=$Nk")
length(dos_table["energy"]) == 1600 ||
    error("Expected 1600 persisted DOS points")
length(filling_table["chemical_potential"]) == 2001 ||
    error("Expected 2001 persisted filling points")

dos_energy = parse.(Float64, dos_table["energy"])
dos_density = parse.(Float64, dos_table["dos_per_spin"])
chemical_potentials = parse.(Float64, filling_table["chemical_potential"])
fillings = parse.(Float64, filling_table["filling_including_spin"])

# The journal naming is persisted in vhs_summary.csv. The journal's first vHs
# is peak_order=2 (orange), while its second vHs is peak_order=1 (blue).
first_vhs = select_peak(vhs_table, Nk, "delta_vH")
second_vhs = select_peak(vhs_table, Nk, "delta_vH_2")
first_vhs_400 = select_peak(vhs_table, "400", "delta_vH")

first_vhs.peak_order == 2 || error("Unexpected persisted first-vHs ordering")
second_vhs.peak_order == 1 || error("Unexpected persisted second-vHs ordering")

first_dos_label = @sprintf(
    "first vHs: μ/t = %.3f",
    first_vhs.mu,
)
second_dos_label = @sprintf(
    "second vHs: μ/t = %.3f",
    second_vhs.mu,
)
first_filling_label = @sprintf(
    "first vHs: δcalc = %.3f",
    first_vhs.delta_calc,
)
second_filling_label = @sprintf(
    "second vHs: δcalc = %.3f",
    second_vhs.delta_calc,
)
paper_note = @sprintf(
    "Paper reference: first δ ~ %.3f; second δ ~ %.3f",
    first_vhs.journal_value,
    second_vhs.journal_value,
)

default(
    linewidth=2,
    framestyle=:box,
    guidefontsize=11,
    tickfontsize=9,
    titlefontsize=12,
    legendfontsize=9,
)

dos_plot = plot(
    dos_energy,
    dos_density;
    label="DOS per spin",
    color=:black,
    xlabel="Energy E/t",
    ylabel="DOS",
    title="DOS (Nk=$Nk)",
    legend=:topright,
)
vline!(
    dos_plot,
    [first_vhs.mu];
    linestyle=:dash,
    color=ORANGE,
    label=first_dos_label,
)
vline!(
    dos_plot,
    [second_vhs.mu];
    linestyle=:dash,
    color=BLUE,
    label=second_dos_label,
)

filling_plot = plot(
    chemical_potentials,
    fillings;
    label="n(μ)",
    color=:darkgreen,
    xlabel="Chemical potential μ/t",
    ylabel="filling n",
    title="Zero-temperature filling (including spin)",
    ylim=(-0.1, 4.1),
    legend=:bottomright,
)
hline!(
    filling_plot,
    [2.0];
    linestyle=:dash,
    color=:gray,
    label="half filling, n = 2",
)
scatter!(
    filling_plot,
    [first_vhs.mu],
    [first_vhs.filling];
    marker=:circle,
    markersize=5,
    color=ORANGE,
    label=first_filling_label,
)
scatter!(
    filling_plot,
    [second_vhs.mu],
    [second_vhs.filling];
    marker=:circle,
    markersize=5,
    color=BLUE,
    label=second_filling_label,
)

note_plot = plot(
    ;
    xlim=(0, 1),
    ylim=(0, 1),
    xaxis=false,
    yaxis=false,
    grid=false,
    framestyle=:none,
    legend=false,
)
annotate!(note_plot, 0.5, 0.5, text(paper_note, 9, :darkslategray, :center))

layout = @layout [dos_panel{0.455h}; filling_panel{0.455h}; note_panel{0.09h}]
combined_plot = plot(
    dos_plot,
    filling_plot,
    note_plot;
    layout=layout,
    size=(1200, 950),
    dpi=150,
)

caption = """
# Clarified noninteracting DOS and filling

The DOS was computed on an **$Nk × $Nk momentum grid** using **$energy_bins bins** and Gaussian smoothing with **sigma = $smoothing_width**. The black curve is the persisted per-spin DOS, and the green curve is the persisted zero-temperature filling including spin.

The orange and blue dashed lines are the **calculated maxima of the smoothed DOS**. The circles are the **calculated `n(mu)` values at those maxima**. Their coordinates come only from the persisted noninteracting results.

The paper delta values, `delta_vH` approximately $(first_vhs.journal_value_text) and `delta_vH,2` approximately $(second_vhs.journal_value_text), are quoted only for external comparison; they do not determine any dashed-line or circle coordinate. The calculated values use the numerically inferred convention `delta_calc = (n - 2)/4`.

The unresolved difference at the paper's first vHs is not explained by the recorded `Nk` convergence.
"""

metadata_lines = [
    "artifact=dos_and_filling_clarified.png",
    "generator=scripts/generate_meeting_noninteracting_figure.jl",
    "numerical_source_mode=persisted_csv_only",
    "dos_source=results/noninteracting/dos.csv",
    "filling_source=results/noninteracting/filling_curve.csv",
    "vhs_source=results/noninteracting/vhs_summary.csv",
    "primary_Nk=$Nk",
    "momentum_grid=$(Nk)x$(Nk)",
    "energy_bins=$energy_bins",
    "gaussian_sigma=$smoothing_width",
    "dos_points=$(length(dos_energy))",
    "filling_points=$(length(chemical_potentials))",
    "first_vhs_color=$ORANGE",
    "first_vhs_mu_calc=$(first_vhs.mu_text)",
    "first_vhs_filling_calc=$(first_vhs.filling_text)",
    "first_vhs_delta_calc=$(first_vhs.delta_calc_text)",
    "first_vhs_delta_paper=$(first_vhs.journal_value_text)",
    "second_vhs_color=$BLUE",
    "second_vhs_mu_calc=$(second_vhs.mu_text)",
    "second_vhs_filling_calc=$(second_vhs.filling_text)",
    "second_vhs_delta_calc=$(second_vhs.delta_calc_text)",
    "second_vhs_delta_paper=$(second_vhs.journal_value_text)",
    "delta_calc_convention=(n-2)/4 (inferred numerically)",
    "first_vhs_delta_calc_Nk400=$(first_vhs_400.delta_calc_text)",
    "first_vhs_delta_calc_Nk800=$(first_vhs.delta_calc_text)",
    "first_vhs_difference_status=unresolved; not explained by recorded Nk convergence",
    "paper_values_role=external comparison only; not plotted coordinates",
]

mkpath(OUTPUT_DIRECTORY)
savefig(combined_plot, FIGURE_PATH)
write(CAPTION_PATH, caption)
write(METADATA_PATH, join(metadata_lines, '\n') * "\n")

println("created=$FIGURE_PATH")
println("created=$CAPTION_PATH")
println("created=$METADATA_PATH")
