#!/usr/bin/env julia

module HubbardEDBenchmarks

using LinearAlgebra

export analytic_hubbard_dimer,
       benchmark_hubbard_dimer,
       hubbard_dimer_hamiltonian,
       lorentzian_broaden,
       numerical_hubbard_dimer,
       square_l4_dos_oracle

const DIMER_CONVENTION =
    "-t*sum_sigma(c1_dagger*c2 + c2_dagger*c1) + " *
    "U*sum_i((n_i_up-1/2)*(n_i_down-1/2))"

function _validated_real(value, name::AbstractString; nonnegative=false, nonzero=false)
    value isa Real && !(value isa Bool) ||
        throw(ArgumentError("$name must be a real number"))
    isfinite(value) || throw(ArgumentError("$name must be finite"))
    nonnegative && value < 0 && throw(ArgumentError("$name must be nonnegative"))
    nonzero && iszero(value) && throw(ArgumentError("$name must be nonzero"))
    return Float64(value)
end

function _validated_dimer_parameters(U, t)
    U_value = _validated_real(U, "U"; nonnegative=true)
    # A zero hopping does not describe a bond and has a degenerate ground state
    # at U=0, for which a unique ground-state double occupancy is undefined.
    t_value = _validated_real(t, "t"; nonzero=true)
    return U_value, t_value
end

function _annihilate(state::Int, mode::Int)
    bit = 1 << (mode - 1)
    state & bit == 0 && return nothing
    sign = iseven(count_ones(state & (bit - 1))) ? 1.0 : -1.0
    return state ⊻ bit, sign
end

function _create(state::Int, mode::Int)
    bit = 1 << (mode - 1)
    state & bit != 0 && return nothing
    sign = iseven(count_ones(state & (bit - 1))) ? 1.0 : -1.0
    return state | bit, sign
end

function _add_hop!(hamiltonian, destination::Int, source::Int, amplitude::Float64)
    for ket in 0:15
        annihilated = _annihilate(ket, source)
        isnothing(annihilated) && continue
        intermediate, annihilation_sign = annihilated
        created = _create(intermediate, destination)
        isnothing(created) && continue
        bra, creation_sign = created
        hamiltonian[bra + 1, ket + 1] +=
            amplitude * annihilation_sign * creation_sign
    end
    return hamiltonian
end

function _state_occupations(state::Int)
    occupations = ntuple(mode -> (state >> (mode - 1)) & 1, 4)
    number = sum(occupations)
    doubles = occupations[1] * occupations[3] +
              occupations[2] * occupations[4]
    return occupations, number, doubles
end

"""
    hubbard_dimer_hamiltonian(U, t=1.0)

Construct the full `16 × 16` Fock-space Hamiltonian of a one-orbital,
two-site Hubbard dimer with one hopping bond. The fermion-mode order is
`(site1_up, site2_up, site1_down, site2_down)`, and the interaction uses the
repository's particle-hole-centered convention

`U * sum_i (n_i_up - 1/2) * (n_i_down - 1/2)`.

`U` must be finite and nonnegative. `t` is the signed matrix element in the
displayed convention and must be finite and nonzero.
"""
function hubbard_dimer_hamiltonian(U::Real, t::Real=1.0)
    U_value, t_value = _validated_dimer_parameters(U, t)
    hamiltonian = zeros(Float64, 16, 16)

    for state in 0:15
        occupations, _, _ = _state_occupations(state)
        centered_interaction =
            (occupations[1] - 0.5) * (occupations[3] - 0.5) +
            (occupations[2] - 0.5) * (occupations[4] - 0.5)
        hamiltonian[state + 1, state + 1] = U_value * centered_interaction
    end

    # Include both directions of the single bond for each spin. Building the
    # matrix from Fock-space operations makes the fermionic signs explicit.
    for (left, right) in ((1, 2), (3, 4))
        _add_hop!(hamiltonian, left, right, -t_value)
        _add_hop!(hamiltonian, right, left, -t_value)
    end
    issymmetric(hamiltonian) || error("dimer Hamiltonian is not symmetric")
    return hamiltonian
end

"""
    analytic_hubbard_dimer(U, t=1.0)

Return the analytic benchmark for the centered Hubbard dimer. `spectrum` is
the complete sorted 16-level many-body spectrum, including degeneracies. The
half-filled ground state is the singlet with

`E0 = -sqrt(U^2 + 16t^2)/2`,

and the returned double occupancy is `sum_i <n_i_up*n_i_down>`. A per-site
value is also supplied. Numerically stable rationalized formulas are used for
the singlet-triplet gap and double occupancy at large `U/abs(t)`.
"""
function analytic_hubbard_dimer(U::Real, t::Real=1.0)
    U_value, t_value = _validated_dimer_parameters(U, t)
    hopping_scale = abs(t_value)
    discriminant = hypot(U_value, 4hopping_scale)
    ground_energy = -discriminant / 2
    triplet_energy = -U_value / 2
    singlet_triplet_gap = 8hopping_scale^2 / (discriminant + U_value)
    double_occupancy_total =
        8hopping_scale^2 / (discriminant * (discriminant + U_value))

    # Sector-resolved entries retain the origin of coincident levels. In
    # particular, the three U/2 states occur in N=0, N=2, and N=4 sectors.
    sector_levels = (
        (particle_number=0, total_spin=0.0, label=:vacuum,
         energy=U_value / 2, multiplicity=1),
        (particle_number=1, total_spin=0.5, label=:bonding,
         energy=-hopping_scale, multiplicity=2),
        (particle_number=1, total_spin=0.5, label=:antibonding,
         energy=hopping_scale, multiplicity=2),
        (particle_number=2, total_spin=0.0, label=:lower_singlet,
         energy=-discriminant / 2, multiplicity=1),
        (particle_number=2, total_spin=1.0, label=:triplet,
         energy=-U_value / 2, multiplicity=3),
        (particle_number=2, total_spin=0.0, label=:odd_ionic_singlet,
         energy=U_value / 2, multiplicity=1),
        (particle_number=2, total_spin=0.0, label=:upper_singlet,
         energy=discriminant / 2, multiplicity=1),
        (particle_number=3, total_spin=0.5, label=:bonding_hole,
         energy=-hopping_scale, multiplicity=2),
        (particle_number=3, total_spin=0.5, label=:antibonding_hole,
         energy=hopping_scale, multiplicity=2),
        (particle_number=4, total_spin=0.0, label=:filled,
         energy=U_value / 2, multiplicity=1),
    )
    spectrum = sort!([
        level.energy
        for level in sector_levels
        for _ in 1:level.multiplicity
    ])
    return (
        U=U_value,
        t=t_value,
        convention=DIMER_CONVENTION,
        hilbert_dimension=16,
        sector_levels=sector_levels,
        spectrum=spectrum,
        discriminant=discriminant,
        ground_singlet_energy=ground_energy,
        triplet_energy=triplet_energy,
        singlet_triplet_gap=singlet_triplet_gap,
        ground_double_occupancy_total=double_occupancy_total,
        ground_double_occupancy_per_site=double_occupancy_total / 2,
    )
end

"""
    numerical_hubbard_dimer(U, t=1.0)

Numerically diagonalize the complete 16-state centered Hubbard dimer. The
returned observables are extracted from the numerical eigenpair rather than
copied from the analytic formulas, so this result can serve as an independent
implementation benchmark.
"""
function numerical_hubbard_dimer(U::Real, t::Real=1.0)
    U_value, t_value = _validated_dimer_parameters(U, t)
    hamiltonian = hubbard_dimer_hamiltonian(U_value, t_value)
    decomposition = eigen(Symmetric(hamiltonian))
    spectrum = decomposition.values
    ground_state = decomposition.vectors[:, 1]

    particle_numbers = zeros(Float64, 16)
    double_occupancies = zeros(Float64, 16)
    for state in 0:15
        _, number, doubles = _state_occupations(state)
        particle_numbers[state + 1] = number
        double_occupancies[state + 1] = doubles
    end
    probabilities = abs2.(ground_state)
    ground_particle_number = dot(probabilities, particle_numbers)
    double_occupancy_total = dot(probabilities, double_occupancies)

    # The unique N_up=2, N_down=0 state is the S_z=1 triplet. Pauli blocking
    # removes its hopping matrix elements, but its energy is read from the
    # constructed numerical Hamiltonian rather than inserted analytically.
    polarized_triplet_state = (1 << 0) | (1 << 1)
    triplet_energy = hamiltonian[
        polarized_triplet_state + 1,
        polarized_triplet_state + 1,
    ]
    ground_energy = first(spectrum)
    return (
        U=U_value,
        t=t_value,
        convention=DIMER_CONVENTION,
        hilbert_dimension=length(spectrum),
        hamiltonian=hamiltonian,
        spectrum=spectrum,
        ground_state=ground_state,
        ground_particle_number=ground_particle_number,
        ground_singlet_energy=ground_energy,
        triplet_energy=triplet_energy,
        singlet_triplet_gap=triplet_energy - ground_energy,
        ground_double_occupancy_total=double_occupancy_total,
        ground_double_occupancy_per_site=double_occupancy_total / 2,
    )
end

"""
    benchmark_hubbard_dimer(U, t=1.0; atol=1e-12, rtol=1e-12)

Compare the numerical full spectrum, ground-singlet energy, singlet-triplet
gap, and ground-state double occupancy with the analytic Hubbard-dimer oracle.
The return value contains both results, absolute errors, individual match
flags, and an aggregate `passed` flag for use by command-line runners.
"""
function benchmark_hubbard_dimer(
    U::Real,
    t::Real=1.0;
    atol::Real=1.0e-12,
    rtol::Real=1.0e-12,
)
    absolute_tolerance = _validated_real(atol, "atol"; nonnegative=true)
    relative_tolerance = _validated_real(rtol, "rtol"; nonnegative=true)
    numerical = numerical_hubbard_dimer(U, t)
    analytic = analytic_hubbard_dimer(U, t)

    errors = (
        spectrum=maximum(abs, numerical.spectrum - analytic.spectrum),
        ground_singlet_energy=abs(
            numerical.ground_singlet_energy - analytic.ground_singlet_energy,
        ),
        singlet_triplet_gap=abs(
            numerical.singlet_triplet_gap - analytic.singlet_triplet_gap,
        ),
        ground_double_occupancy_total=abs(
            numerical.ground_double_occupancy_total -
            analytic.ground_double_occupancy_total,
        ),
    )
    matches = (
        spectrum=isapprox(
            numerical.spectrum,
            analytic.spectrum;
            atol=absolute_tolerance,
            rtol=relative_tolerance,
        ),
        ground_singlet_energy=isapprox(
            numerical.ground_singlet_energy,
            analytic.ground_singlet_energy;
            atol=absolute_tolerance,
            rtol=relative_tolerance,
        ),
        singlet_triplet_gap=isapprox(
            numerical.singlet_triplet_gap,
            analytic.singlet_triplet_gap;
            atol=absolute_tolerance,
            rtol=relative_tolerance,
        ),
        ground_double_occupancy_total=isapprox(
            numerical.ground_double_occupancy_total,
            analytic.ground_double_occupancy_total;
            atol=absolute_tolerance,
            rtol=relative_tolerance,
        ),
    )
    return (
        U=numerical.U,
        t=numerical.t,
        atol=absolute_tolerance,
        rtol=relative_tolerance,
        numerical=numerical,
        analytic=analytic,
        errors=errors,
        matches=matches,
        passed=all(values(matches)),
    )
end

"""
    square_l4_dos_oracle(t=1.0; mu=0.0)

Return the exact finite-grid density-of-states oracle for a one-orbital,
nearest-neighbor `4 × 4` periodic square lattice with dispersion
`epsilon(k) = -2t*(cos(kx)+cos(ky))`. Per spin, the five poles have
multiplicities `(1, 4, 6, 4, 1)` among 16 momenta. `poles` are frequencies
relative to `mu`; `weights` integrate to one per spin, while
`spin_summed_weights` integrate to two.
"""
function square_l4_dos_oracle(t::Real=1.0; mu::Real=0.0)
    t_value = _validated_real(t, "t"; nonzero=true)
    mu_value = _validated_real(mu, "mu")
    hopping_scale = abs(t_value)
    poles = [-4hopping_scale, -2hopping_scale, 0.0,
             2hopping_scale, 4hopping_scale] .- mu_value
    multiplicities = [1, 4, 6, 4, 1]
    weights = multiplicities ./ 16
    momenta = [0.0, pi / 2, pi, 3pi / 2]
    return (
        L=4,
        number_of_sites=16,
        t=t_value,
        mu=mu_value,
        dispersion="epsilon(k)=-2t*(cos(kx)+cos(ky))",
        momenta=momenta,
        poles=poles,
        multiplicities=multiplicities,
        weights=weights,
        spin_summed_multiplicities=2 .* multiplicities,
        spin_summed_weights=2 .* weights,
    )
end

function _finite_vector(values, name::AbstractString; nonnegative=false)
    collected = try
        Float64.(collect(values))
    catch
        throw(ArgumentError("$name must be a finite real iterable"))
    end
    isempty(collected) && throw(ArgumentError("$name must be nonempty"))
    all(isfinite, collected) || throw(ArgumentError("$name must be finite"))
    nonnegative && any(<(0), collected) &&
        throw(ArgumentError("$name must be nonnegative"))
    return collected
end

"""
    lorentzian_broaden(omega, poles, weights; eta=0.1)

Broaden weighted delta-function poles with normalized Lorentzians,
`eta / (pi*((omega-pole)^2 + eta^2))`. The returned `density` therefore has
an infinite-window integral equal to `sum(weights)`. Inputs must be nonempty
and finite, weights must be nonnegative, and `eta` must be strictly positive.
"""
function lorentzian_broaden(omega, poles, weights; eta::Real=0.1)
    omega_values = _finite_vector(omega, "omega")
    pole_values = _finite_vector(poles, "poles")
    weight_values = _finite_vector(weights, "weights"; nonnegative=true)
    length(pole_values) == length(weight_values) || throw(ArgumentError(
        "poles and weights must have equal length",
    ))
    sum(weight_values) > 0 || throw(ArgumentError("weights must have positive sum"))
    eta_value = _validated_real(eta, "eta")
    eta_value > 0 || throw(ArgumentError("eta must be positive"))

    density = zeros(Float64, length(omega_values))
    for (pole, weight) in zip(pole_values, weight_values)
        @. density += weight * eta_value /
            (pi * ((omega_values - pole)^2 + eta_value^2))
    end
    return (
        omega=omega_values,
        density=density,
        eta=eta_value,
        total_weight=sum(weight_values),
    )
end

"""
    lorentzian_broaden(oracle, omega; eta=0.1, spin_summed=false)

Convenience overload that broadens the output of [`square_l4_dos_oracle`](@ref).
Set `spin_summed=true` to obtain the DOS normalized to two spin states per site.
"""
function lorentzian_broaden(
    oracle::NamedTuple,
    omega;
    eta::Real=0.1,
    spin_summed::Bool=false,
)
    hasproperty(oracle, :poles) && hasproperty(oracle, :weights) ||
        throw(ArgumentError("oracle must provide poles and weights"))
    weights = if spin_summed
        hasproperty(oracle, :spin_summed_weights) || throw(ArgumentError(
            "oracle does not provide spin_summed_weights",
        ))
        oracle.spin_summed_weights
    else
        oracle.weights
    end
    return lorentzian_broaden(omega, oracle.poles, weights; eta=eta)
end

end # module
