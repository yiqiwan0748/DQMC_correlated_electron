#!/usr/bin/env julia
# Additive, restricted uniform Hartree-Fock comparison for the N=12/8-cell ED result.
# Run: OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=1 julia --project=. scripts/isaac_band_fs_hf_20260928.jl
using LinearAlgebra, Printf, SHA, TOML, Dates

const HF_ROOT = normpath(joinpath(@__DIR__, ".."))
const HF_OUT = joinpath(HF_ROOT, "results/isaac_20260928/band_fs/hf")
const HF_HELPER = joinpath(HF_ROOT, "scripts/literature_transfer/hf_check.jl")
module MatchedHFDefinitions end
let text = read(HF_HELPER, String), marker = "\nmkpath(OUTPUT_HF)\n"
    pieces = split(text, marker)
    length(pieces) == 2 || error("Expected a unique boundary before historical HF execution")
    # Only definitions are evaluated. The historical experiment cannot run here.
    Base.include_string(MatchedHFDefinitions, pieces[1], HF_HELPER)
end
const MH = MatchedHFDefinitions
const DENSITY = 1.5
const HARTREE_SHIFT = MH.U * (DENSITY - 2) / 4

function write_rows(filename, rows)
    isempty(rows) && error("Refusing empty table: " * filename)
    open(joinpath(HF_OUT, filename), "w") do io
        println(io, join(string.(keys(first(rows))), ","))
        for row in rows
            println(io, join([v isa AbstractFloat ? @sprintf("%.17g", v) : string(v) for v in values(row)], ","))
        end
    end
end

function h0_components(kx, ky)
    t1,t2,t3,t4 = MH.TUPLE
    return (c=-(t1+t2)*(cos(kx)+cos(ky))-4t3*cos(kx)*cos(ky),
        z=-(t1-t2)*(cos(kx)-cos(ky)), x=-4t4*sin(kx)*sin(ky))
end

function bands_at(kx, ky, branch, h, mu)
    v = h0_components(kx, ky)
    output = Float64[]
    for spin in (1,-1)
        radius = hypot(v.z - (branch == :AM ? spin*h : 0), v.x)
        center = v.c - (branch == :FM ? spin*h : 0) - mu
        append!(output, (center-radius, center+radius))
    end
    return output
end

function run_calculation()
    mkpath(HF_OUT)
    start = time()
    checks = Dict{String,Any}[]
    function check(name, discrepancy, tolerance)
        ok = isfinite(discrepancy) && abs(discrepancy) <= tolerance
        push!(checks, Dict("name"=>name, "absolute_error"=>abs(discrepancy), "tolerance"=>tolerance, "passed"=>ok))
        ok || error("Check failed: $name; error=$(abs(discrepancy)), tolerance=$tolerance")
    end
    scans = NamedTuple[]
    stationary = NamedTuple[]
    settings = ((192,.025), (384,.025), (384,.0125))
    for (nk, temperature) in settings, kind in (:AM,:FM)
        grid = MH.mesh_hf(nk)
        bound = MH.U*DENSITY/4 + .05
        hs = vcat(1e-5, collect(range(bound/128, bound; length=128)))
        gs = [MH.source_hf(grid, kind, h, DENSITY, temperature).gradient for h in hs]
        append!(scans, [(branch=String(kind), nk=nk, T=temperature, h=h, gradient=g) for (h,g) in zip(hs,gs)])
        roots = [0.0]
        for i in 1:length(hs)-1
            if gs[i]*gs[i+1] < 0
                push!(roots, MH.bracket_root_hf(grid,kind,hs[i],hs[i+1],DENSITY,temperature))
            end
        end
        for h in roots
            r = MH.source_hf(grid,kind,h,DENSITY,temperature;thermo=true)
            step = 1e-4
            rp = MH.source_hf(grid,kind,h+step,DENSITY,temperature;thermo=true)
            rm = MH.source_hf(grid,kind,h-step,DENSITY,temperature;thermo=true)
            curvature = (rp.gradient-rm.gradient)/(2step)
            tag = "$kind Nk=$nk T=$temperature h=$h"
            check(tag*" density", r.density-DENSITY, 2e-11)
            check(tag*" stationarity", r.gradient, 2e-9)
            check(tag*" h=Um/2", h-MH.U*r.m/2, 1e-8)
            check(tag*" free energy double counting", r.F-r.trial_F, 3e-10)
            check(tag*" free energy finite difference", (rp.F-rm.F)/(2step)-r.gradient, 2e-6)
            push!(stationary, (branch=String(kind), nk=nk, T=temperature, n=DENSITY,
                h=h, m=r.m, mu_source=r.mu_source, mu_centered=r.mu_physical,
                F_per_cell=r.F, kinetic_per_cell=r.kinetic, entropy_per_cell=r.entropy,
                density=r.density, gradient=r.gradient, curvature=curvature,
                classification=curvature>0 ? "minimum" : "maximum"))
        end
        @printf("Finished %s Nk=%d T=%.4f roots=%s elapsed=%.2f s\n", String(kind),nk,temperature,string(roots),time()-start)
        flush(stdout)
    end
    write_rows("stationary_points.csv", stationary)
    write_rows("field_scan.csv", scans)

    # A selected minimum within each constrained one-dimensional branch.
    # PM is retained as a stationary reference even where magnetically unstable.
    selected = Dict{Symbol,Any}()
    final_nk, final_T = last(settings)
    for kind in (:AM,:FM)
        candidates = filter(r->r.branch==String(kind) && r.nk==final_nk && r.T==final_T && r.h>0 && r.classification=="minimum", stationary)
        isempty(candidates) && error("No positive-field minimum found for $kind")
        selected[kind] = candidates[argmin([r.F_per_cell for r in candidates])]
    end
    selected[:PM] = first(filter(r->r.branch=="AM" && r.nk==final_nk && r.T==final_T && r.h==0, stationary))

    populations = NamedTuple[]
    branches = Dict{String,Any}()
    for kind in (:AM,:FM,:PM)
        r = selected[kind]
        grid = MH.mesh_hf(final_nk)
        # All populations here use explicit independent symmetric 2x2 eigensystems,
        # not the analytic field derivative that determined the stationary root.
        explicit = MH.independent_hf(grid,kind==:PM ? :AM : kind,r.h,DENSITY,final_T,r.mu_source)
        check("$kind independent density",sum(explicit.populations)-DENSITY,2e-11)
        check("$kind independent moment",explicit.m-r.m,2e-11)
        check("$kind independent canonical free energy",explicit.F-r.F_per_cell,2e-10)
        for a in 1:2
            check("$kind orbital $a total density",sum(explicit.populations[a,:])-DENSITY/2,2e-11)
            for (is,spin) in enumerate(("up","down"))
                push!(populations,(branch=String(kind),orbital=a,spin=spin,population_per_cell=explicit.populations[a,is]))
            end
        end
        branches[String(kind)] = Dict("h"=>r.h,"m"=>r.m,"n"=>DENSITY,"T"=>final_T,"nk"=>final_nk,
            "mu_source"=>r.mu_source,"mu_centered"=>r.mu_centered,"F_per_cell"=>r.F_per_cell,
            "kinetic_per_cell"=>r.kinetic_per_cell,"entropy_per_cell"=>r.entropy_per_cell,
            "orbital1_up"=>explicit.populations[1,1],"orbital1_down"=>explicit.populations[1,2],
            "orbital2_up"=>explicit.populations[2,1],"orbital2_down"=>explicit.populations[2,2],
            "N_up_per_cell"=>sum(explicit.populations[:,1]),"N_down_per_cell"=>sum(explicit.populations[:,2]))
        # Direct matrix checks at generic and symmetry momenta are independent of
        # the exported analytic square-root formula. Tolerance allows roundoff only.
        for (kx,ky) in ((0.,0.),(pi,0.),(pi,pi),(.137,.831),(1.213,-2.44))
            v=h0_components(kx,ky)
            analytic=bands_at(kx,ky,kind,r.h,r.mu_source)
            for (is,spin) in enumerate((1,-1))
                H0=[v.c+v.z v.x;v.x v.c-v.z]
                vertex=kind==:AM ? Diagonal([1.,-1.]) : Matrix{Float64}(I,2,2)
                exact=eigvals(Symmetric(H0-spin*r.h*vertex))-fill(r.mu_source,2)
                check("$kind 2x2 bands k=($kx,$ky) spin=$spin",maximum(abs.(exact-analytic[(2is-1):2is])),2e-13)
            end
        end
        if kind==:AM
            for (kx,ky) in ((.137,.831),(1.213,-2.44),(pi,0.))
                here=bands_at(kx,ky,kind,r.h,r.mu_source)
                swapped=bands_at(ky,kx,kind,r.h,r.mu_source)
                check("AM rotated opposite-spin bands k=($kx,$ky)",maximum(abs.(here[1:2]-swapped[3:4])),2e-13)
            end
        elseif kind==:PM
            es=bands_at(.31,.89,kind,r.h,r.mu_source)
            check("PM spin degeneracy",maximum(abs.(es[1:2]-es[3:4])),2e-13)
        end
    end
    write_rows("populations.csv",populations)

    controls=NamedTuple[]
    for kind in (:AM,:FM)
        points=Dict((r.nk,r.T)=>r for r in stationary if r.branch==String(kind) && r.h>0 && r.classification=="minimum")
        for (label, coarse, fine) in (("mesh_at_T0.025",(192,.025),(384,.025)), ("temperature_at_Nk384",(384,.025),(384,.0125)))
            a,b=points[coarse],points[fine]
            push!(controls,(branch=String(kind),comparison=label,coarse_nk=coarse[1],coarse_T=coarse[2],
                fine_nk=fine[1],fine_T=fine[2],delta_h=b.h-a.h,delta_m=b.m-a.m,
                delta_mu_source=b.mu_source-a.mu_source,delta_F_per_cell=b.F_per_cell-a.F_per_cell))
        end
    end
    write_rows("mesh_temperature_controls.csv",controls)

    # The path coordinate is actual accumulated Euclidean distance in radians.
    # Each of the first four segments has length pi; Gamma-M has length sqrt(2)*pi.
    vertices=((0.,0.),(pi,0.),(pi,pi),(0.,pi),(0.,0.),(pi,pi))
    labels=("Gamma","X","M","Y","Gamma","M")
    pathrows=NamedTuple[]
    pathvertices=NamedTuple[]
    pathpoints=NamedTuple[]
    cumulative=0.0
    index=0
    push!(pathvertices,(label=labels[1],kx=vertices[1][1],ky=vertices[1][2],path_coordinate=0.0))
    for segment in 1:5
        a,b=vertices[segment],vertices[segment+1]
        length_segment=hypot(b[1]-a[1],b[2]-a[2])
        intervals=ceil(Int,160length_segment/pi)
        for j in (segment==1 ? 0 : 1):intervals
            q=j/intervals
            index+=1
            push!(pathpoints,(index=index,kx=a[1]+q*(b[1]-a[1]),ky=a[2]+q*(b[2]-a[2]),path_coordinate=cumulative+q*length_segment))
        end
        cumulative+=length_segment
        push!(pathvertices,(label=labels[segment+1],kx=b[1],ky=b[2],path_coordinate=cumulative))
    end
    for kind in (:AM,:FM,:PM), p in pathpoints
        r=selected[kind]
        es=bands_at(p.kx,p.ky,kind,r.h,r.mu_source)
        for (is,spin) in enumerate(("up","down")), band in 1:2
            energy=es[2is-2+band]
            push!(pathrows,(branch=String(kind),index=p.index,kx=p.kx,ky=p.ky,path_coordinate=p.path_coordinate,
                band=band,spin=spin,energy_minus_mu=energy,source_energy=energy+r.mu_source))
        end
    end
    write_rows("hf_path.csv",pathrows)
    write_rows("hf_path_vertices.csv",pathvertices)
    # Display-only grid includes both periodic endpoints; density integrals above
    # use the midpoint 384x384 mesh and never count duplicated BZ boundaries.
    bz=collect(range(-pi,pi;length=257))
    gridrows=NamedTuple[]
    for kind in (:AM,:FM,:PM), (ix,kx) in enumerate(bz), (iy,ky) in enumerate(bz)
        r=selected[kind]
        es=bands_at(kx,ky,kind,r.h,r.mu_source)
        push!(gridrows,(branch=String(kind),ix=ix,iy=iy,kx=kx,ky=ky,
            E_up_lower=es[1],E_up_upper=es[2],E_down_lower=es[3],E_down_upper=es[4]))
    end
    write_rows("hf_fermi_grid.csv",gridrows)

    summary=Dict("status"=>"completed","created_utc"=>string(now(UTC)),"elapsed_seconds"=>time()-start,
        "U"=>MH.U,"t"=>collect(MH.TUPLE),"density_per_cell"=>DENSITY,"hartree_shift"=>HARTREE_SHIFT,
        "energy_convention"=>"Centered U(n_up-1/2)(n_down-1/2); plotted energy is E_source-mu_source = E_centered-mu_centered",
        "branch_restriction"=>"Uniform collinear AM and FM lines with equal orbital total densities n_x=n_y=n/2; PM also shown. No mixed FM+AM, orbital-charge order, finite-q orders, phase separation or global HF minimum is established.",
        "branch_selection"=>"Lowest F among detected positive-field minima within each line at Nk=384,T=0.0125; h=0 PM is an unstable stationary reference. Negative h is spin-reversed and degenerate.",
        "fermi_surface_definition"=>"Zero contours of real HF eigenvalues minus the finite-temperature density-matched chemical potential; not a zero-temperature extrapolation or an ED result.",
        "density_mesh"=>"Midpoint periodic 384x384 over [-pi,pi)^2; spin and orbital populations sum to 1.5 per cell",
        "path_convention"=>"Gamma-X-M-Y-Gamma-M with actual cumulative Euclidean momentum distance in radians",
        "field_scan"=>"128 positive-field intervals to U*n/4+0.05; empirical sign-change search cannot exclude arbitrarily narrow stationary root pairs",
        "branches"=>branches,"checks_passed"=>length(checks),"helper_source"=>HF_HELPER,
        "helper_sha256"=>bytes2hex(sha256(read(HF_HELPER))),"driver_sha256"=>bytes2hex(sha256(read(@__FILE__))))
    open(joinpath(HF_OUT,"hf_summary.toml"),"w") do io;TOML.print(io,summary);end
    open(joinpath(HF_OUT,"verification.toml"),"w") do io
        TOML.print(io,Dict("status"=>"passed","number_of_checks"=>length(checks),"checks"=>checks,
            "tolerance_rationale"=>"Density, stationary root, independent energy and matrix checks allow solver/Float64 roundoff; the looser 2e-6 finite-difference derivative bound includes central-difference truncation. Mesh and temperature differences are reported separately and are not erased by solver residuals."))
    end
    provenance=Dict{String,Any}(filename=>bytes2hex(sha256(read(joinpath(HF_OUT,filename)))) for filename in readdir(HF_OUT) if filename != "output_hashes.toml" && isfile(joinpath(HF_OUT,filename)))
    open(joinpath(HF_OUT,"output_hashes.toml"),"w") do io;TOML.print(io,provenance);end
    println("Completed matched HF; elapsed ",round(time()-start;digits=3)," s; ",length(checks)," checks passed. Output: ",HF_OUT)
end

run_calculation()
