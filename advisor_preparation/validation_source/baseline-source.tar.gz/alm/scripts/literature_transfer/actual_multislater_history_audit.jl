#!/usr/bin/env julia
# Checkpoint types live under Main.RunMultiSlaterBenchmark. Loading the guarded
# driver defines those types without running a chain or changing its RNG.
if !isdefined(Main,:RunMultiSlaterBenchmark)
    Base.include(Main,joinpath(@__DIR__,"run_multislater_benchmark.jl"))
end
module ActualMultiSlaterHistoryAudit
using LinearAlgebra, Serialization, SHA, Test, Printf
include(joinpath(@__DIR__,"cp_multitrial_oracle.jl"))
const Oracle=CPMultitrialOracle
const Driver=Main.RunMultiSlaterBenchmark
const MC=Driver.MC
const ROOT=Driver.ROOT
const OUT=joinpath(ROOT,"results/literature_transfer/actual_multislater_history_audit")
const ATOL=1e-7 # Long (200–400 slice) Float64 Fock/Slater comparisons; errors exported.
const ANGLE_FLOOR=1e-10 # Refuse a ratio if normalized bra/anchor overlap is unresolved.

digest(path)=bytes2hex(sha256(read(path)))
function object_digest(x)
    io=IOBuffer();serialize(io,x);bytes2hex(sha256(take!(io)))
end
function csv(io,row;header=false)
    header && println(io,join(string.(keys(row)),','))
    println(io,join(("\""*replace(string(v),"\""=>"\"\"")*"\"" for v in values(row)),','))
end

function fixture(state)
    M=size(state.problem.kinetic,1);N=state.problem.Nup
    @assert M==8 && N==3 && state.problem.Ndown==3
    occ=Oracle.B.occupations(M,N)
    occupations=[Float64(i in o) for o in occ,i in 1:M]
    pairs=[(u,d) for u in occ for d in occ]
    nu=[Float64(i in p[1]) for p in pairs,i in 1:M]
    nd=[Float64(i in p[2]) for p in pairs,i in 1:M]
    O=(nu-nd)*repeat([1.,-1.],4)/2
    V=state.problem.U*vec(sum((nu.-.5).*(nd.-.5);dims=2))
    K=Oracle.B.one_spin_generator(state.problem.kinetic,occ)
    # Independently exponentiate physical K; do not reuse checkpoint KH.
    half=exp(Symmetric(-state.parameters.dtau*state.problem.kinetic/2))
    F=Oracle.B.wedge(half,occ)
    T=Oracle.left_fock(state.trial.terms,occ,occ)
    @test abs(norm(T)-1)<2e-11
    @test maximum(abs,half-state.kinetic_half)<2e-12
    (;occ,occupations,O,V,K,F,T)
end

"""Fock coefficients are Ψ[down,up]. Every elementary operation receives a
single global normalization, preserving relative many-body amplitudes.
This contains no Slater QR and never propagates trial components separately.
"""
function fock_history(vector,fields,F,occupations,gamma;reverse_history=false)
    D=size(F,1);Y=reshape(copy(vector),D,D);Y./=norm(Y)
    tmp=similar(Y);next=similar(Y);logs=0.;min_scale=Inf;max_scale=0.
    history=reverse_history ? Iterators.reverse(fields) : fields
    for field in history
        mul!(tmp,F,Y);mul!(next,tmp,F')
        scale=norm(next)
        isfinite(scale) && scale>floatmin(Float64) || error("Fock kinetic normalization nonfinite/underflow")
        min_scale=min(min_scale,scale);max_scale=max(max_scale,scale);logs+=log(scale)
        Y.=next./scale
        spins=occupations*field
        up=exp.(gamma.*spins);down=exp.(-gamma.*spins)
        @inbounds for j in 1:D,i in 1:D;Y[i,j]*=down[i]*up[j];end
        scale=norm(Y)
        isfinite(scale) && scale>floatmin(Float64) || error("Fock HS normalization nonfinite/underflow")
        min_scale=min(min_scale,scale);max_scale=max(max_scale,scale);logs+=log(scale);Y./=scale
        mul!(tmp,F,Y);mul!(next,tmp,F')
        scale=norm(next)
        isfinite(scale) && scale>floatmin(Float64) || error("Fock kinetic normalization nonfinite/underflow")
        min_scale=min(min_scale,scale);max_scale=max(max_scale,scale);logs+=log(scale)
        Y.=next./scale
    end
    (vector=vec(Y),log_scale=logs,minimum_normalization=min_scale,maximum_normalization=max_scale)
end

function fock_estimator(left,right,f)
    left=left/norm(left);right=right/norm(right)
    den=dot(left,right)
    abs(den)>ANGLE_FLOOR || error("Normalized Fock bra-anchor overlap below diagnostic floor: $den")
    Y=reshape(right,56,56)
    kinetic=dot(left,vec(f.K*Y+Y*f.K'))/den
    interaction=dot(left,f.V.*right)/den
    (energy=kinetic+interaction,kinetic=kinetic,interaction=interaction,
     O=dot(left,f.O.*right)/den,O2=dot(left,(f.O.^2).*right)/den,overlap=den)
end

function choose_walkers(state,n)
    # Sample distinct recorded anchors, evenly across their first occurrences.
    firsts=Int[];seen=Set{Int}()
    for (i,w) in enumerate(state.walkers)
        if w.alive && !(w.anchor_id in seen);push!(seen,w.anchor_id);push!(firsts,i);end
    end
    length(firsts)>=n || error("Fewer than $n distinct warmup BP anchors")
    firsts[unique(round.(Int,range(1,length(firsts);length=n)))]
end

function audit_walker(state,index,f,profile)
    started=time();w=state.walkers[index]
    anchor=Oracle.B.slater(w.anchor_up,w.anchor_down,f.occ,f.occ)
    bra=fock_history(f.T,w.fields,f.F,f.occupations,state.gamma;reverse_history=true)
    exact=fock_estimator(bra.vector,anchor,f)
    endpoint=fock_history(anchor,w.fields,f.F,f.occupations,state.gamma)
    saved=Oracle.B.slater(w.up,w.down,f.occ,f.occ)
    savednorm=norm(saved);endpoint_error=norm(endpoint.vector-saved/savednorm)
    endpoint_phase=dot(endpoint.vector,saved/savednorm)
    stored_overlap=dot(f.T,saved)
    stored_overlap>0 || error("Saved walker has nonpositive independent Fock trial overlap")
    log_overlap_error=abs(log(stored_overlap)-w.log_overlap)
    # Core calls modify only diagnostics on an in-memory deep copy. The loaded
    # checkpoint and both RNG objects remain unchanged and are hashed below.
    working=deepcopy(state);rng_before=object_digest(working.rng)
    bpterms=MC.backpropagated_terms(working,working.walkers[index])
    integrated=MC.estimator(working,bpterms,w.anchor_up,w.anchor_down)
    @test object_digest(working.rng)==rng_before
    core_bra=Oracle.left_fock(bpterms,f.occ,f.occ);core_bra./=norm(core_bra)
    bra_error=norm(core_bra-bra.vector);bra_phase=dot(core_bra,bra.vector)
    energy=integrated.kinetic+integrated.interaction
    e_error=abs(energy-exact.energy);o_error=abs(integrated.O-exact.O);o2_error=abs(integrated.O2-exact.O2)
    passed=maximum((e_error,o_error,o2_error,bra_error,endpoint_error,log_overlap_error))<ATOL
    (profile=profile,walker=index,anchor_id=w.anchor_id,step=state.step,
     dtau=state.parameters.dtau,lag_steps=length(w.fields),lag_time=length(w.fields)*state.parameters.dtau,
     status=passed ? "PASS" : "NUMERICAL_DISCREPANCY",normalized_bra_anchor_overlap=exact.overlap,
     integrated_BP_energy=energy,fock_BP_energy=exact.energy,energy_error=e_error,
     integrated_Delta=integrated.O/4,fock_Delta=exact.O/4,Delta_error=o_error/4,
     integrated_S_alm=integrated.O2/4,fock_S_alm=exact.O2/4,S_alm_error=o2_error/4,
     unnormalized_O_error=o_error,unnormalized_O2_error=o2_error,
     normalized_BP_bra_error=bra_error,BP_bra_phase_overlap=bra_phase,
     normalized_endpoint_error=endpoint_error,endpoint_phase_overlap=endpoint_phase,
     cached_log_overlap_error=log_overlap_error,
     BP_Fock_log_normalization=bra.log_scale,
     minimum_elementary_normalization=bra.minimum_normalization,
     maximum_elementary_normalization=bra.maximum_normalization,
     elapsed_seconds=time()-started)
end

function main()
    ispath(OUT) && error("Refusing to overwrite actual-history audit outputs")
    mkpath(OUT);rows=NamedTuple[];profiles=NamedTuple[];errors=NamedTuple[]
    old_threads=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        for (profile,n) in (("baseline",3),("dt_half",3),("history",2))
            run=joinpath(Driver.OUT,"$(profile)_seed61423_initial")
            path=joinpath(run,"warmup_checkpoint.jls")
            before=digest(path)
            for name in ("multislater_cp.jl","multislater_cp_kernels.jl")
                digest(joinpath(@__DIR__,name))==digest(joinpath(run,"source_snapshot",name)) ||
                    error("Current core/kernel differ from checkpoint snapshot: $name")
            end
            state=deserialize(path);rng_before=object_digest(state.rng)
            f=fixture(state);selected=choose_walkers(state,n)
            for index in selected
                try
                    push!(rows,audit_walker(state,index,f,profile))
                catch err
                    push!(errors,(profile=profile,walker=index,status="UNRESOLVED",reason=sprint(showerror,err)))
                end
                open(joinpath(OUT,"walker_checks.csv"),"w") do io
                    for (j,row) in enumerate(rows);csv(io,row;header=j==1);end
                end
            end
            @test object_digest(state.rng)==rng_before
            @test digest(path)==before
            push!(profiles,(profile=profile,checkpoint=path,sha256=before,
                saved_step=state.step,dtau=state.parameters.dtau,
                saved_beta=state.step*state.parameters.dtau,
                lag_steps=state.parameters.back_propagation_steps,
                lag_time=state.parameters.back_propagation_steps*state.parameters.dtau,
                selected_walkers=join(selected,";"),RNG_unchanged=true,checkpoint_unchanged=true))
        end
    finally
        BLAS.set_num_threads(old_threads)
    end
    open(joinpath(OUT,"checkpoint_provenance.csv"),"w") do io
        for (i,r) in enumerate(profiles);csv(io,r;header=i==1);end
    end
    open(joinpath(OUT,"unresolved.csv"),"w") do io
        isempty(errors) && println(io,"profile,walker,status,reason")
        for (i,r) in enumerate(errors);csv(io,r;header=i==1);end
    end
    open(joinpath(OUT,"validation.txt"),"w") do io
        println(io,"selected_walkers=",sum(parse(Int,string(length(split(p.selected_walkers,';')))) for p in profiles))
        println(io,"completed_comparisons=",length(rows))
        println(io,"passed=",count(r->r.status=="PASS",rows))
        println(io,"numerical_discrepancies=",count(r->r.status!="PASS",rows))
        println(io,"unresolved=",length(errors));println(io,"absolute_tolerance=",ATOL)
        println(io,"normalized_overlap_floor=",ANGLE_FLOOR)
        println(io,"No checkpoint file modified; no RNG consumed; core calls used in-memory copies.")
        for p in (@__FILE__,joinpath(@__DIR__,"multislater_cp.jl"),joinpath(@__DIR__,"multislater_cp_kernels.jl"))
            println(io,p," sha256=",digest(p))
        end
    end
    println("Actual-history checks: ",count(r->r.status=="PASS",rows)," pass; ",
        count(r->r.status!="PASS",rows)," discrepancies; ",length(errors)," unresolved.")
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    ActualMultiSlaterHistoryAudit.main()
end
