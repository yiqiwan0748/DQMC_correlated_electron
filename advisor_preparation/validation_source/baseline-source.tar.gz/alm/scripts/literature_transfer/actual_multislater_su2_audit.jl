#!/usr/bin/env julia
# Full-Fock check of new SU(2) observables on two saved paths. No chain replay.
using LinearAlgebra, Test
if !isdefined(Main,:RunMultiSlaterBenchmark)
    Base.include(Main,joinpath(@__DIR__,"run_multislater_benchmark.jl"))
end
module ActualMultiSlaterSU2Audit
using LinearAlgebra, SparseArrays, Serialization, SHA, Test, Printf
include(joinpath(@__DIR__,"actual_multislater_history_audit.jl"))
include(joinpath(@__DIR__,"multislater_su2_diagnostic.jl"))
const A=ActualMultiSlaterHistoryAudit
const D=MultiSlaterSU2Diagnostic
const B=A.Oracle.B
const M=A.MC
const ROOT=A.ROOT
const OUT=joinpath(ROOT,"results/literature_transfer/actual_multislater_su2_audit")
const ATOL=1e-7 # Accumulated Float64 determinants and 200-slice Fock propagation.

mask(o)=sum(UInt64(1)<<(i-1) for i in o;init=UInt64(0))

"""Signed c†_up c_down or c†_down c_up, including global Fock parity.
Modes are up1:8 then down1:8; the down-basis index varies fastest.
"""
function flip_operator(weights,direction)
    source=B.occupations(8,3)
    ou=B.occupations(8,direction==1 ? 4 : 2)
    od=B.occupations(8,direction==1 ? 2 : 4)
    target=Dict((mask(u)|(mask(d)<<8))=>(i-1)*length(od)+j
                for (i,u) in enumerate(ou) for (j,d) in enumerate(od))
    rows=Int[];cols=Int[];values=Float64[]
    column=0
    for u in source,d in source
        column+=1;s=mask(u)|(mask(d)<<8)
        for a in 0:7
            create=UInt64(1)<<(direction==1 ? a : a+8)
            annihilate=UInt64(1)<<(direction==1 ? a+8 : a)
            (iszero(s&annihilate)||!iszero(s&create)) && continue
            middle=s⊻annihilate
            parity=count_ones(s&(annihilate-1))+count_ones(middle&(create-1))
            push!(rows,target[middle|create]);push!(cols,column)
            push!(values,weights[a+1]*(iseven(parity) ? 1. : -1.))
        end
    end
    sparse(rows,cols,values,length(ou)*length(od),length(source)^2)
end

function observables(left,right,z,Jp,Jm,Sp,Sm)
    den=dot(left,right)
    abs(den)/(norm(left)*norm(right))>1e-10 || error("Unresolved normalized Fock overlap")
    O2z=dot(left,(z.^2).*right)/den
    plusminus=dot(Jm*left,Jm*right)/den
    minusplus=dot(Jp*left,Jp*right)/den
    transverse=(plusminus+minusplus)/2
    Stot2=dot(Sp*left,Sp*right)/den
    @test abs(Stot2-dot(Sm*left,Sm*right)/den)<ATOL
    @test abs(plusminus-minusplus)<ATOL # [J+,J-]=2 Sz_total=0 for signs²=1.
    (;O2z,transverse,scalar=O2z+transverse,Stot2,den)
end

function compare_row(profile,walker,kind,exact,actual)
    errors=(z_error=abs(exact.O2z-actual.O2z)/4,
            transverse_error=abs(exact.transverse-(actual.scalar-actual.O2z)),
            scalar_error=abs(exact.scalar-actual.scalar)/12,
            Stot2_error=abs(exact.Stot2-actual.Stot2))
    @test maximum(values(errors))<ATOL
    merge((profile=profile,walker=walker,boundary=kind,
        fock_z=exact.O2z/4,estimator_z=actual.O2z/4,
        fock_transverse=exact.transverse,estimator_transverse=actual.scalar-actual.O2z,
        fock_scalar=exact.scalar/12,estimator_scalar=actual.scalar/12,
        fock_Stot2=exact.Stot2,estimator_Stot2=actual.Stot2,
        scalar_minus_z=(exact.scalar/3-exact.O2z)/4),errors)
end

function singlet_fixture(terms,f,Jp,Jm,Sp,Sm)
    exact=observables(f.T,f.T,f.O,Jp,Jm,Sp,Sm)
    @test norm(Sp*f.T)<2e-11
    @test abs(exact.Stot2)<2e-11
    @test abs(exact.scalar/3-exact.O2z)<2e-11
    sums=zeros(4)
    # Actual 20 x 20 expansion, including singular individual spin overlaps.
    for left in terms,right in terms
        odd=D.component_spin(left.up,left.down,right.up,right.down,repeat([1.,-1.],4))
        even=D.component_spin(left.up,left.down,right.up,right.down,ones(8))
        coefficient=left.coefficient*right.coefficient
        sums.+=coefficient.*[odd.overlap,odd.O2z,odd.scalar,even.scalar]
    end
    @test abs(sums[1]-1)<2e-11
    actual=(O2z=sums[2]/sums[1],scalar=sums[3]/sums[1],Stot2=sums[4]/sums[1])
    compare_row("full_singlet_20term",0,"singlet_to_singlet",exact,actual)
end

function main()
    ispath(OUT) && error("Refusing to overwrite SU2 audit artifacts")
    mkpath(OUT)
    path=joinpath(ROOT,"results/literature_transfer/multislater_cp_benchmark/baseline_seed61423_initial/warmup_checkpoint.jls")
    before=A.digest(path);state=deserialize(path);state_before=A.object_digest(state)
    f=A.fixture(state)
    Jp=flip_operator(repeat([1.,-1.],4),1)
    Jm=flip_operator(repeat([1.,-1.],4),-1)
    Sp=flip_operator(ones(8),1);Sm=flip_operator(ones(8),-1)
    @test norm(Jp'*Jp-Jm'*Jm)<1e-12
    @test norm(Sp'*Sp-Sm'*Sm)<1e-12
    rows=NamedTuple[singlet_fixture(state.trial.terms,f,Jp,Jm,Sp,Sm)]
    selections=A.choose_walkers(state,2)
    for index in selections
        w=state.walkers[index]
        @test length(w.fields)==200
        anchor=B.slater(w.anchor_up,w.anchor_down,f.occ,f.occ)
        endpoint=B.slater(w.up,w.down,f.occ,f.occ)
        left=A.fock_history(f.T,w.fields,f.F,f.occupations,state.gamma;reverse_history=true).vector
        working=deepcopy(state)
        terms=M.backpropagated_terms(working,working.walkers[index])
        for (kind,L,R,actual_terms,up,down) in
            (("BP_b4",left,anchor,terms,w.anchor_up,w.anchor_down),
             ("mixed",f.T,endpoint,working.trial.terms,w.up,w.down))
            exact=observables(L,R,f.O,Jp,Jm,Sp,Sm)
            actual=D.local_observables(working,actual_terms,up,down)
            push!(rows,compare_row("baseline_seed61423_warmup",index,kind,exact,actual))
        end
        @test A.object_digest(working.rng)==A.object_digest(state.rng)
        @test working.step==state.step && working.measurement_count==state.measurement_count
    end
    @test A.digest(path)==before
    @test A.object_digest(state)==state_before
    open(joinpath(OUT,"observable_checks.csv"),"w") do io
        for (j,row) in enumerate(rows);A.csv(io,row;header=j==1);end
    end
    open(joinpath(OUT,"provenance.txt"),"w") do io
        println(io,"checkpoint=",path,"\ncheckpoint_sha256=",before)
        println(io,"walkers=",join(selections,','),"\nstep=",state.step,
            "\nbeta=",state.step*state.parameters.dtau,"\nbp_lag=4.0\nlag_steps=200")
        println(io,"absolute_tolerance=",ATOL,"\ncheckpoint_and_loaded_state_unchanged=true")
        for source in (@__FILE__,joinpath(@__DIR__,"actual_multislater_history_audit.jl"),
                       joinpath(@__DIR__,"multislater_su2_diagnostic.jl"))
            println(io,"source=",source," sha256=",A.digest(source))
        end
    end
    for row in rows
        println(row.boundary," walker",row.walker,": z=",row.fock_z,
            " scalar=",row.fock_scalar," Stot2=",row.fock_Stot2,
            " max_error=",maximum((row.z_error,row.transverse_error,row.scalar_error,row.Stot2_error)))
    end
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    old=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        @testset "Actual 20-term path SU2 Fock audit" ActualMultiSlaterSU2Audit.main()
    finally
        BLAS.set_num_threads(old)
    end
end
