#!/usr/bin/env julia
"""Bounded U-only open-cluster orbital-locking experiment; no production edits."""
module ALMExactLocking20260911
using LinearAlgebra, SparseArrays, Serialization, SHA, Printf, Dates
include(joinpath(@__DIR__,"../two_orbital_open_cluster_ed.jl"))
const ED=TwoOrbitalOpenClusterED
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const DEFAULT_OUT=joinpath(ROOT,"results/literature_transfer/alm_exact_locking_20260911")
const PLAN=joinpath(ROOT,"docs/reading/alm_exact_locking_plan_20260911.md")
const PRIOR=joinpath(ROOT,"results/ed_study_U0_20/open_L2_spin_sectors.csv")
const ATOL=2e-9 # Float64 matrix/sparse actions, D<=3136; much below resolved energy gaps.
const DEGTOL=1e-9 # Complete energy groups; each retained boundary must be well separated.
const CASES=((label="zero",t4=0.),(label="half",t4=-.325),(label="target",t4=-.65))
const QPOINTS=((label="q0",qx=0.,qy=0.),(label="qpi0",qx=pi,qy=0.),
    (label="q0pi",qx=0.,qy=pi),(label="qpipi",qx=pi,qy=pi))
const INPUTS=[@__FILE__,PLAN,PRIOR,joinpath(@__DIR__,"alm_exact_locking_tests_20260911.jl"),joinpath(@__DIR__,"../two_orbital_open_cluster_ed.jl"),
    joinpath(ROOT,"src/noninteracting.jl"),joinpath(ROOT,"src/realspace_kinetic.jl")]
check(condition,message)=condition || error(message)
sha(path)=bytes2hex(sha256(read(path)))
escape_csv(x)="\""*replace(string(x),'"'=>"\"\"")*"\""
function write_csv(path,rows)
    isempty(rows) && return
    ispath(path) && error("Refusing result overwrite: $path")
    open(path,"w") do io
        println(io,join(string.(keys(first(rows))),','))
        for row in rows;println(io,join(escape_csv.(values(row)),','));end
    end
end

"""Independent one-spin exterior-power Hamiltonian using creation/annihilation signs."""
function independent_spin_hopping(K,states)
    m=size(K,1);lookup=Dict(s=>i for(i,s) in enumerate(states))
    rows=Int[];cols=Int[];vals=Float64[]
    for (column,state) in enumerate(states),source in 0:m-1,destination in 0:m-1
        hopping=K[destination+1,source+1];iszero(hopping) && continue
        source_bit=UInt64(1)<<source;destination_bit=UInt64(1)<<destination
        iszero(state&source_bit) && continue
        middle=state⊻source_bit
        !iszero(middle&destination_bit) && continue
        parity=count_ones(state&(source_bit-1))+count_ones(middle&(destination_bit-1))
        push!(rows,lookup[middle|destination_bit]);push!(cols,column)
        push!(vals,iseven(parity) ? hopping : -hopping)
    end
    sparse(rows,cols,vals,length(states),length(states))
end
"""Independent Kronecker construction in up-major/down-minor order."""
function independent_hamiltonian(K,U,basis)
    hu=independent_spin_hopping(K,basis.up_states)
    hd=independent_spin_hopping(K,basis.down_states)
    nu=length(basis.up_states);nd=length(basis.down_states);diagonal=Float64[]
    for up in basis.up_states,down in basis.down_states
        # Direct local occupation sum avoids the production centered-U shortcut.
        push!(diagonal,U*sum((Int((up>>a)&1)-.5)*(Int((down>>a)&1)-.5) for a in 0:basis.nmodes-1))
    end
    kron(hu,spdiagm(0=>ones(nd)))+kron(spdiagm(0=>ones(nu)),hd)+spdiagm(0=>diagonal)
end
function occupations(basis)
    z=zeros(length(basis),basis.nmodes);n=similar(z);d=similar(z);i=0
    for up in basis.up_states,down in basis.down_states
        i+=1
        for a in 0:basis.nmodes-1
            u=Int((up>>a)&1);v=Int((down>>a)&1)
            z[i,a+1]=(u-v)/2;n[i,a+1]=u+v;d[i,a+1]=u*v
        end
    end
    (;z,n,d)
end

"""Local S+ or S- maps, signed in packed (all up, all down) fermion order.
The destination's public basis order remains up-major/down-minor.
"""
function local_spin_maps(basis,direction::Int)
    direction in (-1,1) || error("Spin direction must be ±1")
    m=basis.nmodes;nu=basis.Nup+direction;nd=basis.Ndown-direction
    if !(0<=nu<=m && 0<=nd<=m)
        return (basis=nothing,operators=[spzeros(Float64,0,length(basis)) for _ in 1:m])
    end
    dest=ED.sector_basis(m,nu,nd)
    lookup=Dict((u,d)=>(i-1)*length(dest.down_states)+j for(i,u) in enumerate(dest.up_states) for(j,d) in enumerate(dest.down_states))
    rows=[Int[] for _ in 1:m];cols=[Int[] for _ in 1:m];vals=[Float64[] for _ in 1:m]
    mask=(UInt64(1)<<m)-1;column=0
    for up in basis.up_states,down in basis.down_states
        column+=1;packed=up|(down<<m)
        for a in 0:m-1
            from=direction==1 ? a+m : a;to=direction==1 ? a : a+m
            annihilator=UInt64(1)<<from;creator=UInt64(1)<<to
            iszero(packed&annihilator) && continue
            middle=packed⊻annihilator
            !iszero(middle&creator) && continue
            parity=count_ones(packed&(annihilator-1))+count_ones(middle&(creator-1))
            final=middle|creator;index=lookup[(final&mask,final>>m)]
            push!(rows[a+1],index);push!(cols[a+1],column);push!(vals[a+1],iseven(parity) ? 1. : -1.)
        end
    end
    (basis=dest,operators=[sparse(rows[a],cols[a],vals[a],length(dest),length(basis)) for a in 1:m])
end
function spin_operators(basis)
    plus=local_spin_maps(basis,1);minus=local_spin_maps(basis,-1)
    (;plus,minus,raising=sum(plus.operators),lowering=sum(minus.operators),occupation=occupations(basis),M=(basis.Nup-basis.Ndown)/2)
end
function energy_groups(E)
    groups=UnitRange{Int}[];first=1
    while first<=length(E)
        last=first
        while last<length(E) && abs(E[last+1]-E[first])<=DEGTOL;last+=1;end
        push!(groups,first:last);first=last+1
    end
    groups
end
function resolve_spin(V,ops;energy=0.)
    R=ops.raising*V
    matrix=Symmetric(R'*R+ops.M*(ops.M+1)*Matrix{Float64}(I,size(V,2),size(V,2)))
    result=eigen(matrix);spins=[round((sqrt(max(0.,1+4x))-1)/2;digits=0) for x in result.values]
    quantization=maximum(abs.(result.values.-spins.*(spins.+1)))
    check(quantization<ATOL,"Nonquantized total spin near E=$energy")
    vectors=V*result.vectors
    for j in axes(vectors,2)
        i=argmax(abs.(view(vectors,:,j)));vectors[i,j]<0 && (vectors[:,j].*=-1)
    end
    action=ops.raising'*(ops.raising*vectors)+ops.M*(ops.M+1)*vectors
    residual=maximum(norm(view(action,:,j)-spins[j]*(spins[j]+1)*view(vectors,:,j)) for j in axes(vectors,2))
    check(residual<ATOL,"Spin eigenvector leaks out of resolved low-energy block")
    (;vectors,spins,quantization,residual)
end

"""C_ab=<S_a·S_b>, including both transverse terms, for one normalized state."""
function scalar_correlations(vector,ops)
    Z=ops.occupation.z.*vector
    P=hcat((matrix*vector for matrix in ops.plus.operators)...)
    M=hcat((matrix*vector for matrix in ops.minus.operators)...)
    C=Z'*Z+(P'*P+M'*M)/2
    probabilities=abs2.(vector)
    density=vec(ops.occupation.n'*probabilities)
    doubles=vec(ops.occupation.d'*probabilities)
    contact=.75 .*(density.-2doubles)
    check(maximum(abs,diag(C)-contact)<ATOL,"Local spin contact identity failed")
    check(norm(C-C')<ATOL,"Non-Hermitian scalar covariance")
    check(minimum(eigvals(Hermitian(C)))>=-ATOL,"Scalar covariance is not positive semidefinite")
    (;C,density,doubles,contact)
end
function probe_matrix(qx,qy;Lx=2,Ly=2)
    phi=zeros(ComplexF64,2Lx*Ly,2)
    for y in 0:Ly-1,x in 0:Lx-1,a in 1:2
        phi[2*(x+Lx*y)+a,a]=cis(-qx*x-qy*y)/sqrt(Lx*Ly)
    end
    phi
end
function spinflip_indices(source,destination)
    lookup=Dict((u,d)=>(i-1)*length(destination.down_states)+j for(i,u) in enumerate(destination.up_states) for(j,d) in enumerate(destination.down_states))
    [lookup[(d,u)] for u in source.up_states for d in source.down_states]
end
function prior_energies()
    lines=readlines(PRIOR);header=split(first(lines),',');answer=Dict{Int,Float64}()
    for line in lines[2:end]
        row=Dict(zip(header,split(line,',')))
        if parse(Float64,row["U"])==20 && parse(Int,row["Nup"])>=parse(Int,row["Ndown"])
            answer[round(Int,parse(Float64,row["Sz"]))]=parse(Float64,row["energy"])
        end
    end
    check(length(answer)==4,"Prior U20 target-sector table is incomplete")
    answer
end
function sector_solution(K,U,M;validate_prior=false,prior=Dict())
    up=3+M;down=3-M;op=ED.sector_hamiltonian(K,U,up,down)
    H=ED.dense_sector_hamiltonian(op);independent=independent_hamiltonian(K,U,op.basis)
    h_error=maximum(abs,sparse(H)-independent)
    check(h_error<2e-12,"Independent Kronecker Hamiltonian differs")
    eig=eigen!(Symmetric(copy(H)));E=eig.values;V=eig.vectors
    residual_matrix=independent*V;residual_matrix .-= V.*E'
    all_residual=maximum(sqrt.(vec(sum(abs2,residual_matrix;dims=1))))
    check(all_residual<ATOL,"An original-H eigenpair residual failed")
    check(maximum(abs,vec(sum(abs2,V;dims=1)).-1)<ATOL,"Eigenvector normalization failed")
    groups=energy_groups(E);ops=spin_operators(op.basis);low=NamedTuple[]
    max_spin_residual=0.;max_quantization=0.
    for (i,group) in enumerate(groups[1:min(8,length(groups))])
        resolved=resolve_spin(V[:,group],ops;energy=E[first(group)])
        max_spin_residual=max(max_spin_residual,resolved.residual)
        max_quantization=max(max_quantization,resolved.quantization)
        for j in eachindex(resolved.spins)
            push!(low,(group=i,energy=E[first(group)],spin=resolved.spins[j],vector=resolved.vectors[:,j]))
        end
    end
    g=length(first(groups));ground=resolve_spin(V[:,1:g],ops;energy=E[1])
    check(g<length(E) && E[g+1]-E[1]>100DEGTOL,"Ground-space boundary is unresolved")
    ground_gram=norm(ground.vectors'*ground.vectors-I)
    check(ground_gram<ATOL,"Ground Gram matrix failed")
    prior_error=validate_prior ? abs(E[1]-prior[M]) : 0.
    validate_prior && check(prior_error<2e-8,"New target result disagrees with prior Lanczos energy")
    # Independent spin reversal covers the negative-Sz half of the canonical trace.
    reverse=ED.sector_hamiltonian(K,U,down,up);permutation=spinflip_indices(op.basis,reverse.basis)
    probes=hcat(ground.vectors,[sin(.73i)+cos(.31i) for i in 1:length(op.basis)])
    flipped=zeros(size(probes));flipped[permutation,:].=probes
    reference=zeros(size(probes));reference[permutation,:].=independent*probes
    reversal_error=norm(hcat((reverse*flipped[:,j] for j in axes(flipped,2))...)-reference)/max(1.,norm(probes))
    check(reversal_error<ATOL,"Spin-reversal intertwining failed")
    (;op,H,E,groups,ops,low,ground,ground_gram,h_error,all_residual,max_spin_residual,max_quantization,prior_error,reversal_error)
end

function analyze_case(case,out,prior)
    started=time();model=ED.ModelParameters(t4=case.t4);K=ED.open_cluster_kinetic_matrix(2,2,model)
    K0=ED.open_cluster_kinetic_matrix(2,2,ED.ModelParameters(t4=0.))
    mix=maximum(abs,K[1:2:end,2:2:end]);check(abs(mix-abs(case.t4))<1e-13,"Interorbital hopping activation mismatch")
    check(K[1:2:end,1:2:end]==K0[1:2:end,1:2:end] && K[2:2:end,2:2:end]==K0[2:2:end,2:2:end],"Intraorbital hopping changed")
    sectors=Dict{Int,Any}();alllevels=NamedTuple[];lowrows=NamedTuple[];validation=NamedTuple[]
    for M in 0:3
        println("t4=",case.t4," resolving Sz=",M);flush(stdout)
        sector=sector_solution(K,20.,M;validate_prior=case.label=="target",prior=prior);sectors[M]=sector
        append!(alllevels,[(label=case.label,t4=case.t4,Sz=M,index=i,energy=e) for(i,e) in enumerate(sector.E)])
        append!(lowrows,[(label=case.label,t4=case.t4,Sz=M,group=r.group,energy=r.energy,S=r.spin,S_squared=r.spin*(r.spin+1)) for r in sector.low])
        push!(validation,(label=case.label,t4=case.t4,Sz=M,dimension=length(sector.E),
            independent_H_max_error=sector.h_error,all_eigenpair_max_residual=sector.all_residual,
            spin_quantization_error=sector.max_quantization,spin_action_max_residual=sector.max_spin_residual,
            ground_gram_error=sector.ground_gram,spin_reversal_intertwining_error=sector.reversal_error,
            prior_target_energy_error=sector.prior_error))
    end
    su2_rows=NamedTuple[]
    for M in 0:2
        a=sectors[M];b=sectors[M+1]
        probes=hcat(a.ground.vectors,[sin(.23i)+cos(.43i) for i in 1:length(a.E)])
        raised=a.ops.raising*probes
        discrepancy=hcat((b.op*raised[:,j] for j in axes(raised,2))...)-a.ops.raising*(a.H*probes)
        err=norm(discrepancy)/max(1.,norm(probes));check(err<ATOL,"SU2 Hamiltonian intertwining failed")
        push!(su2_rows,(label=case.label,t4=case.t4,Sz=M,normalized_intertwining_residual=err))
    end
    E0=minimum(s.E[1] for s in values(sectors))
    check(abs(sectors[0].E[1]-E0)<ATOL,"Minimal-Sz sector did not contain the canonical ground state")
    C=zeros(8,8);density=zeros(8);doubles=zeros(8);gfull=0;spin2=0.;ground_sectors=NamedTuple[]
    for M in 0:3
        sector=sectors[M]
        abs(sector.E[1]-E0)<=DEGTOL || continue
        weight=M==0 ? 1 : 2
        for (j,S) in enumerate(sector.ground.spins)
            obs=scalar_correlations(sector.ground.vectors[:,j],sector.ops)
            C .+= weight.*obs.C;density .+= weight.*obs.density;doubles .+= weight.*obs.doubles
            spin2+=weight*S*(S+1);gfull+=weight
            push!(ground_sectors,(label=case.label,t4=case.t4,Sz=M,ground_column=j,S=S,negative_Sz_multiplicity=weight))
        end
    end
    C./=gfull;density./=gfull;doubles./=gfull;spin2/=gfull
    expected_dimension=sum(round(Int,2S+1) for S in sectors[0].ground.spins)
    check(gfull==expected_dimension,"Full canonical SU2 ground multiplet coverage mismatch")
    check(abs(sum(C)-spin2)<ATOL,"Global S² scalar sum failed")
    check(maximum(abs,diag(C)-.75*(density-2doubles))<ATOL,"Ensemble contact identity failed")
    check(minimum(eigvals(Symmetric(C)))>=-ATOL,"Ensemble scalar covariance PSD failed")
    check(abs(sum(density)-6)<ATOL,"Ground-state charge normalization failed")
    odd=collect(1:2:8);even=collect(2:2:8)
    SA2=sum(C[odd,odd]);SB2=sum(C[even,even]);AB=sum(C[odd,even])
    check(abs(SA2+SB2+2AB-spin2)<ATOL,"Orbital-moment sum rule failed")
    check(abs(SA2-SB2)<ATOL,"Square-cluster orbital exchange symmetry failed")
    correlations=NamedTuple[];orbital_q=NamedTuple[]
    for q in QPOINTS
        phi=probe_matrix(q.qx,q.qy);matrix=phi'*C*phi
        s_even=real(sum(matrix));s_odd=real(dot([1.,-1.],matrix*[1.,-1.]))
        check(norm(matrix-matrix')<ATOL && minimum(eigvals(Hermitian(matrix)))>=-ATOL,"Momentum-probe covariance invalid")
        q.label=="q0" && check(abs(s_even-spin2/4)<ATOL,"Global q0 scalar structure-factor sum rule failed")
        push!(correlations,(label=case.label,t4=case.t4,q=q.label,qx=q.qx,qy=q.qy,
            S_even_scalar=s_even,S_odd_scalar=s_odd,S_even_isotropic_z=s_even/3,S_odd_isotropic_z=s_odd/3))
        append!(orbital_q,[(label=case.label,t4=case.t4,q=q.label,orbital_a=a,orbital_b=b,
            real_scalar=real(matrix[a,b]),imag_scalar=imag(matrix[a,b])) for a in 1:2 for b in 1:2])
    end
    check(abs(correlations[2].S_odd_scalar-correlations[3].S_odd_scalar)<ATOL &&
          abs(correlations[2].S_even_scalar-correlations[3].S_even_scalar)<ATOL,"C4 covariance equality failed")
    # Every S=0..3 is represented in Sz=0. The first eight complete groups
    # must expose each lowest S before a tower fit can be reported.
    spin_energies=Float64[]
    for S in 0:3
        entries=filter(r->r.spin==S,sectors[0].low)
        check(!isempty(entries),"Lowest S=$S not resolved in eight energy groups")
        push!(spin_energies,minimum(r.energy for r in entries))
    end
    # Cross-sector ground floors must agree with the resolved spin minima.
    check(maximum(abs(sectors[M].E[1]-minimum(spin_energies[M+1:end])) for M in 0:3)<ATOL,
        "Spin-resolved tower is inconsistent with another Sz-sector ground energy")
    x=[S*(S+1)/2 for S in 0:3];design=hcat(ones(4),x);fit=design\spin_energies
    predictions=design*fit;gap01=spin_energies[2]-spin_energies[1]
    tower=[(label=case.label,t4=case.t4,S=S,energy=spin_energies[S+1],gap_from_S0=spin_energies[S+1]-spin_energies[1],
        fitted_constant=fit[1],fitted_J=fit[2],fitted_energy=predictions[S+1],fit_residual=spin_energies[S+1]-predictions[S+1],
        J_from_S1_S0=gap01) for S in 0:3]
    # Multiplet count is read from the minimal-Sz representation, not counted
    # repeatedly in all magnetic projections of the same SU2 multiplet.
    multiplets=[(label=case.label,t4=case.t4,energy_group=r.group,energy=r.energy,S=r.spin,
        SU2_dimension=round(Int,2r.spin+1)) for r in sectors[0].low]
    summary=(label=case.label,t4=case.t4,U=20.,N=6,cells=4,energy=E0,
        full_ground_degeneracy=gfull,ground_degeneracy_Sz0=size(sectors[0].ground.vectors,2),
        total_spin_squared=spin2,orbital_A_spin_squared=SA2,orbital_B_spin_squared=SB2,
        orbital_spin_dot=AB,S_odd_q0_scalar=correlations[1].S_odd_scalar,
        S_odd_q0_isotropic_z=correlations[1].S_odd_isotropic_z,
        double_occupancy_total=sum(doubles),fitted_J=fit[2],J_from_S1_S0=gap01,
        maximum_tower_fit_residual=maximum(abs,spin_energies-predictions),
        max_interorbital_hopping=mix,elapsed_seconds=time()-started)
    path=joinpath(out,"schmidt_input_t4_$(case.label).jls")
    check(!ispath(path),"Refusing Schmidt input overwrite")
    zero=sectors[0]
    serialize(path,(kinetic=K,U=20.,t4=case.t4,Nup=3,Ndown=3,up_states=zero.op.basis.up_states,
        down_states=zero.op.basis.down_states,H=zero.H,energies=zero.E,
        ground_vectors=zero.ground.vectors,ground_spins=zero.ground.spins,ground_energy=E0,
        ground_degeneracy_Sz0=size(zero.ground.vectors,2),full_ground_degeneracy=gfull,
        source_order="up-major/down-minor; packed up1..up8,down1..down8",
        ground_basis_note="Definite-S real orthonormal columns; repeated same-S degeneracy can retain basis freedom."))
    if case.label=="target"
        references=Dict{Int,Any}()
        for M in 0:1
            sector=sectors[M];vectors=sector.ground.vectors;count=size(vectors,2)
            scalar=zeros(8,8);numbers=zeros(8);double_numbers=zeros(8)
            for j in axes(vectors,2)
                obs=scalar_correlations(vectors[:,j],sector.ops)
                scalar .+= obs.C/count;numbers .+= obs.density/count;double_numbers .+= obs.doubles/count
            end
            spins=sector.ground.spins;labels=unique(spins)
            references[M]=(Sz=M,Nup=3+M,Ndown=3-M,H=sector.H,
                up_states=sector.op.basis.up_states,down_states=sector.op.basis.down_states,
                eigenvectors=vectors,energy=sector.E[1],ground_degeneracy=count,ground_spins=spins,
                total_spin=length(labels)==1 ? only(labels) : missing,
                total_spin_squared=sum(S*(S+1) for S in spins)/count,
                spin_dot=scalar,density=numbers,double_occupancy=double_numbers)
        end
        serialize(joinpath(out,"dmrg_reference_target.jls"),(kinetic=K,U=20.,t4=case.t4,cells=4,N=6,
            sectors=references,source_order="up-major/down-minor; packed up1..up8,down1..down8"))
    end
    realspace=[(label=case.label,t4=case.t4,mode_a=a,mode_b=b,scalar_Cab=C[a,b]) for a in 1:8 for b in 1:8]
    (;summary,alllevels,lowrows,validation,su2_rows,ground_sectors,correlations,orbital_q,tower,multiplets,realspace)
end

function run_study(;output_dir=DEFAULT_OUT)
    ispath(output_dir) && error("Refusing existing study output: $output_dir")
    all(isfile,INPUTS) || error("Missing prospective plan or immutable reference input")
    hashes=Dict(path=>sha(path) for path in INPUTS);prior=prior_energies();mkpath(output_dir)
    snapshot=joinpath(output_dir,"source_snapshot");mkpath(snapshot)
    for path in INPUTS;cp(path,joinpath(snapshot,basename(path)));end
    write_csv(joinpath(output_dir,"source_hashes.csv"),[(path=p,sha256=h) for(p,h) in sort(collect(hashes))])
    open(joinpath(output_dir,"metadata.txt"),"w") do io
        println(io,"started_utc=",now(UTC),"\njulia_version=",VERSION,"\nBLAS_threads=",BLAS.get_num_threads())
        println(io,"system=open2x2; U20; N6; h0; centered intraorbital U only")
        println(io,"hopping_t1_t2_t3=(-1,-1.75,-.85); t4_controls=(0,-.325,-.65)")
        println(io,"ensemble=complete fixed-N ground trace; negative Sz reflected with verified spin reversal")
        println(io,"scalar_structure_normalization=1/Ncells; isotropic_z=scalar/3")
        println(io,"q_labels=spatial probes on an open cluster, not momentum quantum numbers")
        println(io,"absolute_validation_tolerance=",ATOL,"\nenergy_group_tolerance=",DEGTOL)
        println(io,"prior_energy_agreement_tolerance=2e-8 (older Lanczos residuals up to ~6e-9)")
    end
    results=NamedTuple[]
    try
        for case in CASES
            result=analyze_case(case,output_dir,prior);push!(results,result)
            println(result.summary);flush(stdout);GC.gc()
        end
        for (file,key) in (("sector_levels.csv",:alllevels),("low_energy_sector_spin.csv",:lowrows),
            ("validation.csv",:validation),("SU2_intertwining.csv",:su2_rows),("ground_trace_members.csv",:ground_sectors),
            ("structure_factors.csv",:correlations),("orbital_q_covariance.csv",:orbital_q),
            ("spin_tower.csv",:tower),("low_energy_multiplets.csv",:multiplets),("real_space_scalar_covariance.csv",:realspace))
            write_csv(joinpath(output_dir,file),reduce(vcat,[getproperty(r,key) for r in results]))
        end
        write_csv(joinpath(output_dir,"summary.csv"),[r.summary for r in results])
        all(sha(path)==digest for(path,digest) in hashes) || error("Source changed during study")
        write(joinpath(output_dir,"status.txt"),"COMPLETE_VALIDATED; exact finite-cluster locking control; no bulk phase claim\n")
        files=sort([joinpath(dir,file) for(dir,_,names) in walkdir(output_dir) for file in names])
        write_csv(joinpath(output_dir,"artifact_manifest.csv"),[(relative_path=relpath(p,output_dir),bytes=filesize(p),sha256=sha(p)) for p in files])
        results
    catch err
        open(joinpath(output_dir,"status.txt"),"w") do io
            println(io,"FAILED; successful artifacts retained");showerror(io,err,catch_backtrace());println(io)
        end
        rethrow()
    end
end
function main()
    isempty(ARGS) || error("This fixed study accepts no CLI overrides")
    old=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try;run_study();finally;BLAS.set_num_threads(old);end
end
end
if abspath(PROGRAM_FILE)==@__FILE__;ALMExactLocking20260911.main();end
