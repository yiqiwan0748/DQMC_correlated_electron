#!/usr/bin/env julia
using Test, LinearAlgebra, SparseArrays
include(joinpath(@__DIR__,"alm_exact_locking_20260911.jl"))
const A=ALMExactLocking20260911
const TOL=2e-11 # Small (D<=36) exact fixtures; stricter than the D=3136 study bound.
old=BLAS.get_num_threads();BLAS.set_num_threads(1)
try
@testset "independent Hamiltonian and fermionic spin algebra" begin
    K=[.2 -.7 .4 0.;-.7 -.3 .1 .6;.4 .1 .5 -.8;0. .6 -.8 -.4]
    for N in 0:4,up in max(0,N-4):min(4,N)
        down=N-up;b=A.ED.sector_basis(4,up,down)
        op=A.ED.sector_hamiltonian(K,3.7,up,down)
        independent=A.independent_hamiltonian(K,3.7,b)
        @test maximum(abs,Matrix(op)-Matrix(independent))<TOL
        ops=A.spin_operators(b)
        @test norm(ops.lowering'*ops.lowering-ops.raising'*ops.raising-2ops.M*I)<TOL
        if ops.plus.basis!==nothing
            target=ops.plus.basis
            dest=A.ED.sector_hamiltonian(K,3.7,target.Nup,target.Ndown)
            @test norm(Matrix(dest)*ops.raising-ops.raising*Matrix(op))<TOL
            reverse=A.local_spin_maps(target,-1)
            for a in 1:4;@test ops.plus.operators[a]==reverse.operators[a]';end
        end
        if ops.minus.basis!==nothing
            target=ops.minus.basis
            dest=A.ED.sector_hamiltonian(K,3.7,target.Nup,target.Ndown)
            @test norm(Matrix(dest)*ops.lowering-ops.lowering*Matrix(op))<TOL
        end
    end
    # Occupying mode2 introduces the nontrivial sign for 1->3 hopping.
    states=A.ED.sector_basis(4,2,0).up_states;lookup=Dict(s=>i for(i,s) in enumerate(states))
    H=A.independent_spin_hopping(K,states)
    @test H[lookup[0x06],lookup[0x03]]==-K[3,1]
end
@testset "singlet, polarized state and complete degenerate trace" begin
    K=[0. -1.;-1. 0.];U=20.;basis=A.ED.sector_basis(2,1,1)
    H=Matrix(A.ED.sector_hamiltonian(K,U,1,1));eig=eigen(Symmetric(H))
    @test abs(eig.values[1]+sqrt(U^2+16)/2)<TOL
    ops=A.spin_operators(basis);resolved=A.resolve_spin(eig.vectors[:,1:1],ops)
    @test resolved.spins==[0.]
    C=A.scalar_correlations(resolved.vectors[:,1],ops).C
    @test abs(sum(C))<TOL
    @test abs(C[1,1]+C[1,2])<TOL
    polarized=A.spin_operators(A.ED.sector_basis(2,2,0))
    P=A.scalar_correlations([1.],polarized).C
    @test P≈[.75 .25;.25 .75] atol=TOL rtol=0
    @test sum(P)≈2. atol=TOL rtol=0
    # At zero hopping the singly occupied ground manifold contains a singlet
    # and all three triplet states. This catches an accidental singlet-only trace.
    freeH=Matrix(A.ED.sector_hamiltonian(zeros(2,2),U,1,1))
    free=eigen(Symmetric(freeH));g=count(e->abs(e-free.values[1])<A.DEGTOL,free.values)
    zero=A.resolve_spin(free.vectors[:,1:g],ops)
    @test zero.spins≈[0.,1.] atol=TOL rtol=0
    C0=sum(A.scalar_correlations(zero.vectors[:,j],ops).C for j in 1:g)
    ensemble=(C0+2P)/4
    @test ensemble≈[.75 0.;0. .75] atol=TOL rtol=0
    @test sum(ensemble)≈1.5 atol=TOL rtol=0
    @test sum(round(Int,2S+1) for S in zero.spins)==4
end
@testset "target geometry, normalization and immutable prior coverage" begin
    K0=A.ED.open_cluster_kinetic_matrix(2,2,A.ED.ModelParameters(t4=0.))
    Kh=A.ED.open_cluster_kinetic_matrix(2,2,A.ED.ModelParameters(t4=-.325))
    Kt=A.ED.open_cluster_kinetic_matrix(2,2)
    @test iszero(maximum(abs,K0[1:2:end,2:2:end]))
    @test maximum(abs,Kt[1:2:end,2:2:end])==.65
    @test Kh≈(K0+Kt)/2 atol=TOL rtol=0
    @test all(issymmetric,(K0,Kh,Kt))
    for q in A.QPOINTS
        phi=A.probe_matrix(q.qx,q.qy)
        @test phi'*phi≈Matrix{Float64}(I,2,2) atol=TOL rtol=0
    end
    @test Set(keys(A.prior_energies()))==Set(0:3)
    @test abs(A.prior_energies()[0]+27.52313996361078)<TOL
    @test_throws ErrorException A.run_study(output_dir=mktempdir())
end
finally
    BLAS.set_num_threads(old)
end
