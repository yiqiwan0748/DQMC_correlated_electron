#!/usr/bin/env julia
module ALMHFThermodynamicScreen
using LinearAlgebra, Printf, SHA, Dates, Test, TOML

const ROOT = normpath(joinpath(@__DIR__, "../.."))
const OUT = joinpath(ROOT, "results/literature_transfer/alm_hf_thermodynamic_screen_20260911")
const REFERENCE = joinpath(@__DIR__, "hf_check.jl")
const REF_SOURCE = read(REFERENCE, String)
const MARKER = "\nmkpath(OUTPUT_HF)"
@assert length(findall(MARKER, REF_SOURCE)) == 1
# Reuse definitions only: the historical script has an unconditional execution block.
module ReferenceHF end
Base.include_string(ReferenceHF, REF_SOURCE[1:first(findfirst(MARKER, REF_SOURCE))-1], REFERENCE)
include("hf_competition.jl")
const HF = ReferenceHF

function csvline(io, vals)
    println(io, join((x isa AbstractFloat ? @sprintf("%.16g",x) : string(x) for x in vals), ','))
    flush(io)
end

"Lower convex hull indices for points strictly ordered by density."
function lower_hull(ns, fs)
    @assert length(ns)==length(fs) && length(ns)>=2 && all(diff(ns).>0)
    hull=Int[]
    for i in eachindex(ns)
        while length(hull)>=2
            a,b=hull[end-1],hull[end]
            left=(fs[b]-fs[a])*(ns[i]-ns[b])
            right=(fs[i]-fs[b])*(ns[b]-ns[a])
            left>=right || break
            pop!(hull)
        end
        push!(hull,i)
    end
    hull
end

function init_run(tag)
    dir=joinpath(OUT,tag)
    ispath(dir) && error("Refusing to overwrite $dir")
    mkpath(dir)
    provenance=Dict("started_utc"=>string(now(UTC)),"julia"=>string(VERSION),
        "threads"=>Threads.nthreads(),"blas_threads"=>BLAS.get_num_threads(),
        "reference_sha256"=>bytes2hex(sha256(REF_SOURCE)),
        "script_sha256"=>bytes2hex(sha256(read(@__FILE__))),
        "hf_competition_sha256"=>bytes2hex(sha256(read(joinpath(@__DIR__,"hf_competition.jl")))),
        "plan_sha256"=>bytes2hex(sha256(read(joinpath(ROOT,"docs/reading/alm_hf_thermodynamic_screen_plan_20260911.md")))),
        "U"=>20.0,"hoppings"=>collect(HF.TUPLE),"interaction"=>"shifted intraorbital U only",
        "scope"=>"uniform equal-orbital-charge finite-temperature Hartree-Fock branches only")
    open(joinpath(dir,"provenance.toml"),"w") do io;TOML.print(io,provenance);end
    for (name,path) in (("analysis_source.jl",@__FILE__),("reference_hf_check.jl",REFERENCE),
        ("reference_hf_competition.jl",joinpath(@__DIR__,"hf_competition.jl")),
        ("preregistered_plan.md",joinpath(ROOT,"docs/reading/alm_hf_thermodynamic_screen_plan_20260911.md")))
        cp(path,joinpath(dir,name))
    end
    dir
end

function field_scan(g,kind,n,T,scanio;intervals=64)
    hmax=HF.U*n/4+.05
    hs=vcat(1e-5,collect(range(hmax/intervals,hmax;length=intervals)))
    gs=Float64[]
    for h in hs
        r=HF.source_hf(g,kind,h,n,T)
        push!(gs,r.gradient)
        csvline(scanio,(n,T,g.nk,kind,h,r.gradient,r.density-n))
    end
    roots=[0.0]
    for i in 1:length(hs)-1
        if gs[i]*gs[i+1]<0
            push!(roots,HF.bracket_root_hf(g,kind,hs[i],hs[i+1],n,T))
        elseif gs[i]==0;push!(roots,hs[i]);end
    end
    unique(roots)
end

function root_record(g,kind,h,n,T)
    r=HF.source_hf(g,kind,h,n,T;thermo=true)
    step=1e-4
    curvature=(HF.source_hf(g,kind,h+step,n,T).gradient-HF.source_hf(g,kind,h-step,n,T).gradient)/(2step)
    valid=abs(r.density-n)<2e-11 && abs(r.gradient)<2e-9 && abs(r.F-r.trial_F)<2e-9
    @assert valid "Root failed density/SCF/physical-energy check"
    (n=n,T=T,nk=g.nk,kind=kind,classification=curvature>0 ? "minimum" : "maximum",
        h=r.h,m=r.m,F=r.trial_F,mu=r.mu_physical,curvature=curvature,
        density_error=r.density-n,field_residual=r.gradient,stationary_F_error=r.F-r.trial_F,
        kinetic=r.kinetic,entropy=r.entropy)
end

const ROW_KEYS=(:n,:T,:nk,:kind,:classification,:h,:m,:F,:mu,:curvature,:density_error,
    :field_residual,:stationary_F_error,:kinetic,:entropy)

function run_screen(;nk=96,T=.05,expanded=false)
    tag=expanded ? "expanded_Nk$(nk)_T$(T)" : "screen_Nk$(nk)_T$(T)"
    dir=init_run(tag);g=HF.mesh_hf(nk)
    ns=sort(unique(vcat(collect(expanded ? (1.30:.01:1.60) : (1.38:.005:1.48)),[1.4,1.46021875])))
    rows=NamedTuple[];failed=0
    open(joinpath(dir,"stationary_points.csv"),"w") do rio
      open(joinpath(dir,"field_scan.csv"),"w") do sio
       open(joinpath(dir,"failures.txt"),"w") do fio
        csvline(rio,ROW_KEYS);csvline(sio,(:n,:T,:nk,:kind,:h,:gradient,:density_error))
        for n in ns,kind in (:AM,:FM)
            try
                roots=field_scan(g,kind,n,T,sio)
                for h in roots
                    row=root_record(g,kind,h,n,T);push!(rows,row);csvline(rio,values(row))
                end
                println("screen n=",n," ",kind," roots=",roots);flush(stdout)
            catch e
                failed+=1;println(fio,"n=$n kind=$kind error=",sprint(showerror,e));flush(fio)
            end
        end
       end
      end
    end
    # Require a successful AM and FM calculation at every n before assigning hull.
    failed==0 || error("$failed failed points retained; incomplete screen cannot define a hull")
    best=[sort(filter(r->r.n==n,rows),by=r->r.F)[1] for n in ns]
    hull=lower_hull(ns,[r.F for r in best]);pairs=NamedTuple[]
    open(joinpath(dir,"lower_envelope.csv"),"w") do io
        csvline(io,(:n,:kind,:F,:on_hull))
        for (i,r) in enumerate(best);csvline(io,(r.n,r.kind,r.F,i in hull));end
    end
    open(joinpath(dir,"hull_segments.csv"),"w") do io
        csvline(io,(:n_left,:kind_left,:n_right,:kind_right,:slope,:skipped_points,:touches_boundary))
        for j in 1:length(hull)-1
            a,b=hull[j],hull[j+1];l,r=best[a],best[b]
            p=(n_left=l.n,kind_left=l.kind,n_right=r.n,kind_right=r.kind,
                slope=(r.F-l.F)/(r.n-l.n),skipped_points=b-a-1,touches_boundary=a==1||b==length(ns))
            csvline(io,values(p));p.skipped_points>0 && push!(pairs,p)
        end
    end
    println("Candidate hull intervals: ",pairs)
    open(joinpath(dir,"completed.txt"),"w") do io;println(io,now(UTC));end
end

"Follow the high-moment branch identified by the complete bounded screen."
function high_branch(g,kind,n,T)
    # All initial screen points are scanned explicitly; refinements then track this root.
    hmax=HF.U*n/4
    for fraction in (.90,.75,.5,.25,.01)
        a=fraction*hmax;b=hmax+.05
        if HF.source_hf(g,kind,a,n,T).gradient*HF.source_hf(g,kind,b,n,T).gradient<0
            h=HF.bracket_root_hf(g,kind,a,b,n,T)
            return root_record(g,kind,h,n,T)
        end
    end
    error("No bracket for screened high-moment branch")
end

function tangent_values(g,T,nl,nr)
    l=high_branch(g,:FM,nl,T);r=high_branch(g,:AM,nr,T)
    slope=(r.F-l.F)/(nr-nl)
    ((l.mu-r.mu,slope-l.mu),l,r)
end

function refine_tangent(g,T,start,traceio)
    x=collect(start)
    for it in 1:20
        f,l,r=tangent_values(g,T,x...);res=maximum(abs,f)
        csvline(traceio,(it,x[1],x[2],f[1],f[2],l.F,r.F,l.mu,r.mu))
        res<2e-8 && return (left=l,right=r,residual=res,iterations=it)
        # Central density differences also expose compressibility for the Jacobian.
        d=1e-4;J=zeros(2,2)
        for a in 1:2
            xp=copy(x);xm=copy(x);xp[a]+=d;xm[a]-=d
            fp=tangent_values(g,T,xp...)[1];fm=tangent_values(g,T,xm...)[1]
            J[:,a].=(collect(fp)-collect(fm))/(2d)
        end
        dx=-(J\collect(f));accepted=false
        for weight in (1.0,.5,.25,.125,.0625,.03125)
            proposal=x+weight*dx
            if 1.30<proposal[1]<proposal[2]<1.60 && proposal[2]-proposal[1]>.002
                newf=tangent_values(g,T,proposal...)[1]
                if maximum(abs,newf)<res;x=proposal;accepted=true;break;end
            end
        end
        accepted || error("Common tangent line search failed")
    end
    error("Common tangent reached 20-iteration budget")
end

function run_refine(nk,T,nl,nr)
    dir=init_run("refine_Nk$(nk)_T$(T)");g=HF.mesh_hf(nk)
    try
        result=open(joinpath(dir,"tangent_trace.csv"),"w") do io
            csvline(io,(:iteration,:n_left,:n_right,:mu_difference,:tangent_difference,:F_left,:F_right,:mu_left,:mu_right))
            refine_tangent(g,T,(nl,nr),io)
        end
        # All field roots at each endpoint are retained, including unstable roots.
        allroots=NamedTuple[]
        open(joinpath(dir,"endpoint_field_scan.csv"),"w") do sio
         open(joinpath(dir,"endpoint_stationary_points.csv"),"w") do rio
          csvline(sio,(:n,:T,:nk,:kind,:h,:gradient,:density_error));csvline(rio,ROW_KEYS)
          for n in (result.left.n,result.right.n),kind in (:AM,:FM)
            for h in field_scan(g,kind,n,T,sio;intervals=128)
                row=root_record(g,kind,h,n,T);push!(allroots,row);csvline(rio,values(row))
            end
          end
         end
        end
        for selected in (result.left,result.right)
            rivals=filter(r->r.n==selected.n,allroots)
            @assert selected.F<=minimum(r.F for r in rivals)+2e-9
        end
        nm=(result.left.n+result.right.n)/2
        am=high_branch(g,:AM,nm,T);fm=high_branch(g,:FM,nm,T)
        chord=(result.left.F+result.right.F)/2
        props=Dict("nk"=>nk,"T"=>T,"n_left_FM"=>result.left.n,"n_right_AM"=>result.right.n,
            "F_left"=>result.left.F,"F_right"=>result.right.F,"mu_coexist"=>result.left.mu,
            "tangent_residual"=>result.residual,"iterations"=>result.iterations,
            "midpoint_n"=>nm,"midpoint_AM_F"=>am.F,"midpoint_FM_F"=>fm.F,
            "midpoint_mixed_F"=>chord,"midpoint_gain"=>min(am.F,fm.F)-chord)
        # Independent density finite differences, physical energy and entropy audits.
        open(joinpath(dir,"density_derivative_checks.csv"),"w") do io
          csvline(io,(:kind,:n,:step,:F_derivative,:mu,:derivative_error,:dmu_dn))
          for r in (result.left,result.right),d in (1e-4,5e-5)
            p=high_branch(g,r.kind,r.n+d,T);m=high_branch(g,r.kind,r.n-d,T)
            derivative=(p.F-m.F)/(2d);compressibility=(p.mu-m.mu)/(2d)
            @assert abs(derivative-r.mu)<2e-6
            @assert compressibility>0
            csvline(io,(r.kind,r.n,d,derivative,r.mu,derivative-r.mu,compressibility))
          end
        end
        open(joinpath(dir,"summary.toml"),"w") do io;TOML.print(io,props);end
        open(joinpath(dir,"completed.txt"),"w") do io;println(io,now(UTC));end
        println(props)
    catch e
        open(joinpath(dir,"failure.txt"),"w") do io;showerror(io,e,catch_backtrace());end
        rethrow()
    end
end

function run_tests()
    dir=init_run("validation")
    open(joinpath(dir,"checks.txt"),"w") do io
      @testset "Thermodynamic hull, derivative, and independent physical energy" begin
        @test lower_hull([0.,1.,2.],[0.,2.,0.])==[1,3]
        @test lower_hull([0.,1.,2.],[0.,-1.,0.])==[1,2,3]
        @test lower_hull([0.,1.,2.,3.],[0.,1.,2.,3.])==[1,4]
        # An affine shift (including conversion of shifted to unshifted U) leaves the hull invariant.
        ns=[0.,1.,2.,3.];fs=[0.,1.,.2,1.]
        @test lower_hull(ns,fs)==lower_hull(ns,fs.+3 .*ns.-7)
        for kind in (:AM,:FM),h in (0.,.35,6.1),T in (.025,.05)
            g=HF.mesh_hf(18);r=HF.source_hf(g,kind,h,1.4,T;thermo=true)
            ind=HF.independent_hf(g,kind,h,1.4,T,r.mu_source)
            @test isapprox(r.trial_F,ind.F;atol=3e-10,rtol=3e-10)
            cell=HFCompetition.make_grid(1,1,18,18)
            vertex=kind==:AM ? [1.,-1.] : [1.,1.]
            V=h*vertex*[-1. 1.]
            c=HFCompetition.solve_fields(cell,V,1.4,T)
            physical=c.kinetic+20sum((c.rho[:,1].-.5).*(c.rho[:,2].-.5))-T*c.entropy
            @test isapprox(physical,r.trial_F;atol=3e-10,rtol=3e-10)
            @test isapprox(c.kinetic,r.kinetic;atol=3e-10,rtol=3e-10)
            @test isapprox(c.entropy,r.entropy;atol=3e-10,rtol=3e-10)
            println(io,"$kind h=$h T=$T independent_F_error=",physical-r.trial_F)
        end
        for kind in (:AM,:FM)
            g=HF.mesh_hf(48);r=high_branch(g,kind,1.425,.05);d=1e-4
            p=high_branch(g,kind,r.n+d,r.T);m=high_branch(g,kind,r.n-d,r.T)
            @test abs((p.F-m.F)/(2d)-r.mu)<2e-6
            @test abs(r.field_residual)<2e-9
            @test abs(r.density_error)<2e-11
            println(io,"$kind density_derivative_error=",(p.F-m.F)/(2d)-r.mu)
        end
      end
    end
    open(joinpath(dir,"completed.txt"),"w") do io;println(io,now(UTC));end
end

function main(args)
    BLAS.set_num_threads(1)
    isempty(args) && error("Usage: ... test | screen | expanded | refine Nk T nleft nright")
    if args[1]=="test";run_tests()
    elseif args[1]=="screen";run_screen()
    elseif args[1]=="expanded";run_screen(expanded=true)
    elseif args[1]=="refine";run_refine(parse(Int,args[2]),parse(Float64,args[3]),parse(Float64,args[4]),parse(Float64,args[5]))
    else;error("Unknown command");end
end
end
if abspath(PROGRAM_FILE)==@__FILE__;ALMHFThermodynamicScreen.main(ARGS);end
