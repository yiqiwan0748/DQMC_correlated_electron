#!/usr/bin/env julia
"""Additive U-only open-cluster ED bridge; no dense many-body Hamiltonian."""
module ALMMatrixFreeED20260911
using LinearAlgebra, SparseArrays, Random, Serialization, SHA, TOML, Dates
include(joinpath(@__DIR__,"../two_orbital_open_cluster_ed.jl"))
include(joinpath(@__DIR__,"../prl_101_237004_restarted_lanczos.jl"))
const ED=TwoOrbitalOpenClusterED
const Lanczos=PRL101237004RestartedLanczos
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const SEEDS=(597113,806417)
const SECTORS=((4,4),(5,3),(5,4),(6,3))
const CONFIG=(nev=3,krylovdim=128,keep=12,max_matvecs=4000,atol=1e-9,
    rtol=0.,max_bytes=1024^3,wall_seconds=900.)
const DEGTOL=1e-7 # 100 times the requested eigenpair residual; unresolved boundaries are rejected.
const SPINTOL=1e-6 # Registered S² eigenvalue and original-action tolerance.
const QPOINTS=Tuple(("qx$(ix)_qy$(iy)",Float64(qx),Float64(qy))
    for (iy,qy) in enumerate((0.,pi)) for (ix,qx) in enumerate((0.,pi/3,2pi/3,pi)))
check(ok,message)=ok || error(message)
sha(path)=bytes2hex(sha256(read(path)))

"""One-spin exterior-power hopping, signed independently of ED._hop."""
function spin_hopping(K,states)
    m=size(K,1);index=Dict(s=>i for(i,s) in enumerate(states))
    rows=Int[];cols=Int[];vals=Float64[]
    for (j,s) in enumerate(states),b in 0:m-1,a in 0:m-1
        value=K[a+1,b+1];iszero(value) && continue
        annih=UInt64(1)<<b;create=UInt64(1)<<a
        iszero(s&annih) && continue
        middle=s⊻annih;iszero(middle&create) || continue
        parity=count_ones(s&(annih-1))+count_ones(middle&(create-1))
        push!(rows,index[middle|create]);push!(cols,j)
        push!(vals,iseven(parity) ? value : -value)
    end
    sparse(rows,cols,vals,length(states),length(states))
end

struct FactorHamiltonian
    basis::ED.SectorBasis
    kinetic::Matrix{Float64}
    U::Float64
    up_hopping::SparseMatrixCSC{Float64,Int}
    down_hopping::SparseMatrixCSC{Float64,Int}
    diagonal::Vector{Float64}
end
Base.size(H::FactorHamiltonian)=(length(H.diagonal),length(H.diagonal))
Base.size(H::FactorHamiltonian,k::Integer)=size(H)[k]
Base.eltype(::FactorHamiltonian)=Float64
Base.eltype(::Type{FactorHamiltonian})=Float64

function sector_operator(K,U,Nup,Ndown)
    check(size(K,1)==size(K,2) && isapprox(K,K';atol=1e-14,rtol=0),"K must be real symmetric")
    check(all(isfinite,K) && isfinite(U),"Nonfinite model")
    b=ED.sector_basis(K,Nup,Ndown);m=b.nmodes
    d=[Float64(U)*(count_ones(u&v)-(Nup+Ndown)/2+m/4)
        for u in b.up_states for v in b.down_states]
    FactorHamiltonian(b,Matrix{Float64}(K),Float64(U),
        spin_hopping(K,b.up_states),spin_hopping(K,b.down_states),d)
end

"""Apply Tdown*X + X*Tup' + diagonal.*X, X=reshape(x,ndown,nup).
The sparse factors are tiny; the loops allocate no full-vector temporary.
Input and output must not alias. Only the requested fixed-number sector exists.
"""
function LinearAlgebra.mul!(y::AbstractVector,H::FactorHamiltonian,x::AbstractVector)
    length(x)==length(y)==length(H.diagonal) || throw(DimensionMismatch())
    Base.mightalias(x,y) && throw(ArgumentError("mul! input/output must not alias"))
    nd=length(H.basis.down_states);nu=length(H.basis.up_states)
    @inbounds @simd for i in eachindex(y);y[i]=H.diagonal[i]*x[i];end
    a=H.down_hopping
    @inbounds for u in 0:nu-1,d in 1:nd
        offset=u*nd;value=x[offset+d]
        for k in a.colptr[d]:a.colptr[d+1]-1
            y[offset+a.rowval[k]]+=a.nzval[k]*value
        end
    end
    a=H.up_hopping
    @inbounds for u in 1:nu,k in a.colptr[u]:a.colptr[u+1]-1
        source=(u-1)*nd;destination=(a.rowval[k]-1)*nd;value=a.nzval[k]
        @simd for d in 1:nd;y[destination+d]+=value*x[source+d];end
    end
    y
end
Base.:*(H::FactorHamiltonian,x::AbstractVector)=mul!(similar(x),H,x)

struct WallBudgetExceeded <: Exception end
mutable struct DeadlineOperator
    H::FactorHamiltonian
    deadline::Float64
    calls::Int
end
Base.size(H::DeadlineOperator)=size(H.H)
Base.size(H::DeadlineOperator,k::Integer)=size(H.H,k)
Base.eltype(::DeadlineOperator)=Float64
function LinearAlgebra.mul!(y::AbstractVector,H::DeadlineOperator,x::AbstractVector)
    time()>H.deadline && throw(WallBudgetExceeded())
    H.calls+=1;mul!(y,H.H,x)
end
function atomic_serialize(path,value)
    ispath(path) && error("Refusing overwrite: $path")
    mkpath(dirname(path));tmp=path*".tmp"
    open(io->serialize(io,value),tmp,"w");mv(tmp,path)
end

"""Bounded fresh Lanczos arm. A wall cap recovers the last checkpoint only.
Checkpoint reuse is an approximate subspace restart, not bitwise continuation;
this entry point deliberately performs fresh independent starts.
"""
function solve_arm(H;seed,output_dir,config=CONFIG)
    ispath(output_dir) && error("Refusing existing arm directory")
    mkpath(output_dir);checkpoint=joinpath(output_dir,"checkpoint.jls")
    started=time();bounded=DeadlineOperator(H,started+config.wall_seconds,0)
    metadata=(source_sha256=sha(@__FILE__),Nup=H.basis.Nup,Ndown=H.basis.Ndown,
        U=H.U,kinetic=H.kinetic,source_order="up-major/down-minor",seed=seed)
    wall_limited=false;result=nothing
    progress=info->begin
        println("seed=",seed," Nup=",H.basis.Nup," Ndown=",H.basis.Ndown,
            " matvecs=",info.matvecs," E=",info.values,
            " residual=",info.residuals===nothing ? info.residual_estimates : info.residuals)
        flush(stdout)
    end
    try
        result=Lanczos.restarted_lowest(bounded;nev=config.nev,krylovdim=config.krylovdim,
            keep=config.keep,max_matvecs=config.max_matvecs,atol=config.atol,rtol=config.rtol,
            max_bytes=config.max_bytes,seed=seed,checkpoint_path=checkpoint,
            checkpoint_every=config.krylovdim,checkpoint_metadata=metadata,progress=progress)
    catch e
        e isa WallBudgetExceeded || rethrow()
        wall_limited=true
        if isfile(checkpoint)
            c=Lanczos.read_lanczos_checkpoint(checkpoint)
            result=(values=c.values,vectors=c.vectors,matvecs=bounded.calls,restarts=c.restarts)
        end
    end
    if result===nothing
        payload=(status="INCONCLUSIVE_NO_CHECKPOINT",seed=seed,wall_limited=true,
            seconds=time()-started,matvecs=bounded.calls,values=Float64[],vectors=zeros(length(H.diagonal),0),
            residuals=Float64[],converged=false,metadata=metadata)
    else
        values=copy(result.values);vectors=copy(result.vectors)
        residuals=[norm(H*view(vectors,:,j)-values[j]*view(vectors,:,j)) for j in eachindex(values)]
        orthogonality=norm(vectors'*vectors-I)
        converged=all(residuals.<=config.atol.+config.rtol.*abs.(values)) && orthogonality<1e-9
        payload=(status=converged ? "CONVERGED_RITZ_PAIRS" : "INCONCLUSIVE_RESIDUAL",
            seed=seed,wall_limited=wall_limited,seconds=time()-started,matvecs=bounded.calls,
            values=values,vectors=vectors,residuals=residuals,orthogonality=orthogonality,
            converged=converged,metadata=metadata)
    end
    atomic_serialize(joinpath(output_dir,"result.jls"),payload)
    payload
end

function spin_destination(b,direction)
    nu=b.Nup+direction;nd=b.Ndown-direction
    0<=nu<=b.nmodes && 0<=nd<=b.nmodes ? ED.sector_basis(b.nmodes,nu,nd) : nothing
end
@inline function spin_move(up,down,m,a,direction,dest)
    packed=up|(down<<m)
    from=direction==1 ? a+m : a;to=direction==1 ? a : a+m
    annih=UInt64(1)<<from;create=UInt64(1)<<to
    iszero(packed&annih) && return (0,0.)
    middle=packed⊻annih;iszero(middle&create) || return (0,0.)
    parity=count_ones(packed&(annih-1))+count_ones(middle&(create-1))
    state=middle|create;mask=(UInt64(1)<<m)-1
    i=(dest.up_indices[state&mask]-1)*length(dest.down_states)+dest.down_indices[state>>m]
    i,iseven(parity) ? 1. : -1.
end
function local_spin_images(b,v,direction)
    check(b.nmodes<=31,"Packed spin map requires at most31 spatial modes")
    dest=spin_destination(b,direction);dest===nothing && return zeros(0,b.nmodes)
    image=zeros(length(dest),b.nmodes);j=0
    @inbounds for u in b.up_states,d in b.down_states
        j+=1
        for a in 0:b.nmodes-1
            i,sign=spin_move(u,d,b.nmodes,a,direction,dest)
            i==0 || (image[i,a+1]+=sign*v[j])
        end
    end
    image
end
function raising_image(b,v)
    dest=spin_destination(b,1);dest===nothing && return zeros(0)
    result=zeros(length(dest));j=0
    @inbounds for u in b.up_states,d in b.down_states
        j+=1
        for a in 0:b.nmodes-1
            i,sign=spin_move(u,d,b.nmodes,a,1,dest)
            i==0 || (result[i]+=sign*v[j])
        end
    end
    result
end
function raising_adjoint(b,v)
    dest=spin_destination(b,1);result=zeros(length(b));dest===nothing && return result
    j=0
    @inbounds for u in b.up_states,d in b.down_states
        j+=1
        for a in 0:b.nmodes-1
            i,sign=spin_move(u,d,b.nmodes,a,1,dest)
            i==0 || (result[j]+=sign*v[i])
        end
    end
    result
end

"""Resolve S within a candidate degenerate eigenspace, including odd N.
No rounding-to-spin label is accepted without a full S² action check.
"""
function resolve_spin(b,V)
    M=(b.Nup-b.Ndown)/2;R=hcat((raising_image(b,view(V,:,j)) for j in axes(V,2))...)
    eig=eigen(Symmetric(R'*R+M*(M+1)*Matrix{Float64}(I,size(V,2),size(V,2))))
    twoS=[round(Int,sqrt(max(0.,1+4x))-1) for x in eig.values]
    spins=twoS./2;vectors=V*eig.vectors
    quantization=maximum(abs.(eig.values.-spins.*(spins.+1)))
    residuals=[norm(raising_adjoint(b,raising_image(b,view(vectors,:,j)))+
        (M*(M+1)-spins[j]*(spins[j]+1))*view(vectors,:,j)) for j in eachindex(spins)]
    parity=all(isodd(s)==isodd(b.Nup+b.Ndown) && s>=abs(b.Nup-b.Ndown) for s in twoS)
    accepted=parity && quantization<SPINTOL && maximum(residuals)<SPINTOL
    (;vectors,spins,spin_squared=eig.values,quantization,residuals,accepted)
end

function state_observables(b,v;Lx,Ly)
    m=b.nmodes;nc=Lx*Ly;check(m==2nc,"Geometry mismatch")
    check(abs(sum(abs2,v)-1)<1e-9,"State not normalized")
    Z=zeros(length(b),m);density=zeros(m);doubles=zeros(m);zmean=zeros(m);j=0
    @inbounds for up in b.up_states,down in b.down_states
        j+=1;p=abs2(v[j])
        for a in 0:m-1
            u=Int((up>>a)&1);d=Int((down>>a)&1);z=(u-d)/2
            Z[j,a+1]=z*v[j];density[a+1]+=(u+d)*p
            doubles[a+1]+=u*d*p;zmean[a+1]+=z*p
        end
    end
    Czz=Z'*Z;Z=nothing
    plus=local_spin_images(b,v,1);Cplus=plus'*plus;plus=nothing
    minus=local_spin_images(b,v,-1);Cminus=minus'*minus;minus=nothing
    C=Czz+(Cplus+Cminus)/2
    contact_error=maximum(abs,diag(C)-.75*(density-2doubles))
    zcontact_error=maximum(abs,diag(Czz)-.25*(density-2doubles))
    hermitian_error=norm(C-C');minimum_eigenvalue=minimum(eigvals(Symmetric(C)))
    M=(b.Nup-b.Ndown)/2
    spin_squared_raise=sum(abs2,raising_image(b,v))+M*(M+1)
    total_spin_squared=sum(C)
    validation=(contact_error=contact_error,zcontact_error=zcontact_error,
        hermitian_error=hermitian_error,minimum_eigenvalue=minimum_eigenvalue,
        particle_error=abs(sum(density)-b.Nup-b.Ndown),Sz_error=abs(sum(zmean)-M),
        S2_raise_error=abs(total_spin_squared-spin_squared_raise))
    check(contact_error<1e-9 && zcontact_error<1e-9 && hermitian_error<1e-9 && minimum_eigenvalue>=-1e-9,"Spin matrix identities failed")
    check(validation.particle_error<1e-9 && validation.Sz_error<1e-9 && validation.S2_raise_error<1e-8,"Global number/spin identity failed")
    probes=NamedTuple[]
    for(label,qx,qy) in QPOINTS
        phase=[cis(-qx*x-qy*y) for y in 0:Ly-1 for x in 0:Lx-1 for a in 1:2]
        odd=phase.*[isodd(a) ? 1 : -1 for a in 1:m]
        push!(probes,(label=label,qx=qx,qy=qy,
            even_scalar=real(dot(phase,C*phase))/nc,odd_scalar=real(dot(odd,C*odd))/nc,
            even_z=real(dot(phase,Czz*phase))/nc,odd_z=real(dot(odd,Czz*odd))/nc))
    end
    A=1:2:m;B=2:2:m
    (spin_dot=C,SzSz=Czz,density=density,double_occupancy=doubles,Sz_local=zmean,
        total_spin_squared=total_spin_squared,orbital_A_squared=sum(C[A,A]),
        orbital_B_squared=sum(C[B,B]),interorbital_dot=sum(C[A,B]),
        probes=probes,validation=validation)
end

"""Uniform trace over supplied candidate ground columns, not a completeness claim."""
function spin_observables(b,V;Lx,Ly)
    states=[state_observables(b,view(V,:,j);Lx=Lx,Ly=Ly) for j in axes(V,2)]
    isempty(states) && error("Empty state ensemble")
    average(key)=sum(getproperty(s,key) for s in states)/length(states)
    probes=[(label=q[1],qx=q[2],qy=q[3],
        even_scalar=sum(s.probes[i].even_scalar for s in states)/length(states),
        odd_scalar=sum(s.probes[i].odd_scalar for s in states)/length(states),
        even_z=sum(s.probes[i].even_z for s in states)/length(states),
        odd_z=sum(s.probes[i].odd_z for s in states)/length(states)) for(i,q) in enumerate(QPOINTS)]
    (spin_dot=average(:spin_dot),SzSz=average(:SzSz),density=average(:density),
        double_occupancy=average(:double_occupancy),Sz_local=average(:Sz_local),
        total_spin_squared=average(:total_spin_squared),orbital_A_squared=average(:orbital_A_squared),
        orbital_B_squared=average(:orbital_B_squared),interorbital_dot=average(:interorbital_dot),probes=probes,
        per_state=states,ensemble="uniform trace over supplied observed ground columns")
end

csc_payload(A)=(colptr=copy(A.colptr),rowval=copy(A.rowval),nzval=copy(A.nzval),nrows=size(A,1),ncols=size(A,2))
function ground_count(values)
    isempty(values) ? 0 : count(e->e-values[1]<=DEGTOL,values)
end

"""Compare independent starts and export candidate reference arrays without dense H.
The accepted flag means the registered numerical diagnostics passed; finite
Krylov starts do not mathematically certify spectral completeness.
"""
function compare_arms(H,arms;Lx,Ly)
    check(length(arms)==2 && arms[1].seed!=arms[2].seed,"Two distinct starts required")
    b=H.basis
    if any(isempty(a.values) for a in arms)
        return (accepted=false,status="INCONCLUSIVE_NO_RITZ_PAIRS",Nup=b.Nup,Ndown=b.Ndown)
    end
    g=ground_count.(getproperty.(arms,:values))
    boundary=all(g[i]<length(arms[i].values) && arms[i].values[g[i]+1]-arms[i].values[1]>1e-6 for i in 1:2)
    Eerror=maximum(abs.(arms[1].values-arms[2].values))
    G=[a.vectors[:,1:ground_count(a.values)] for a in arms]
    overlap=svdvals(G[1]'*G[2]);subspace_error=g[1]==g[2] ? maximum(abs.(1 .-overlap.^2)) : Inf
    resolved=[resolve_spin(b,x) for x in G]
    observations=[spin_observables(b,r.vectors;Lx=Lx,Ly=Ly) for r in resolved]
    spin_error=maximum(abs,observations[1].spin_dot-observations[2].spin_dot)
    seed_agreement=Eerror<1e-8 && subspace_error<1e-6 && spin_error<1e-6
    fresh_residuals=[norm(H*view(resolved[1].vectors,:,j)-arms[1].values[1]*view(resolved[1].vectors,:,j)) for j in 1:g[1]]
    reasons=String[]
    all(a.converged for a in arms) || push!(reasons,"A start did not converge all requested original-H residuals")
    boundary || push!(reasons,"No next returned level separated by more than1e-6")
    all(==(1),g) || push!(reasons,"Observed fixed-Sz ground degeneracy prevents a pure-state reference")
    seed_agreement || push!(reasons,"Independent starts disagree on levels or ground subspace/observables")
    all(r.accepted for r in resolved) || push!(reasons,"Total-spin label or original S² action is unresolved")
    maximum(fresh_residuals)<1e-8 || push!(reasons,"Spin-resolved ground Hamiltonian residual exceeds1e-8")
    accepted=isempty(reasons)
    o=observations[1]
    lowlevels=NamedTuple[]
    first=1
    while first<=length(arms[1].values)
        last=first
        while last<length(arms[1].values) && arms[1].values[last+1]-arms[1].values[first]<=DEGTOL;last+=1;end
        r=resolve_spin(b,arms[1].vectors[:,first:last])
        for j in eachindex(r.spins)
            push!(lowlevels,(energy=arms[1].values[first],S=r.spins[j],spin_label_accepted=r.accepted,
                S2=r.spin_squared[j],S2_action_residual=r.residuals[j],boundary_resolved=last<length(arms[1].values)))
        end
        first=last+1
    end
    (accepted=accepted,status=accepted ? "ACCEPTED_CANDIDATE_REFERENCE" : "INCONCLUSIVE",acceptance_reasons=reasons,
        kinetic=H.kinetic,U=H.U,Lx=Lx,Ly=Ly,cells=Lx*Ly,N=b.Nup+b.Ndown,Nup=b.Nup,Ndown=b.Ndown,
        Sz=(b.Nup-b.Ndown)/2,up_states=b.up_states,down_states=b.down_states,
        up_hopping=csc_payload(H.up_hopping),down_hopping=csc_payload(H.down_hopping),diagonal=H.diagonal,
        energies=arms[1].values,residuals=arms[1].residuals,eigenvectors=arms[1].vectors,
        ground_vectors=resolved[1].vectors,ground_energy=arms[1].values[1],
        ground_degeneracy_observed=g[1],ground_boundary_resolved=boundary,
        total_spin=resolved[1].spins,total_spin_squared=o.total_spin_squared,
        orbital_A_squared=o.orbital_A_squared,orbital_B_squared=o.orbital_B_squared,interorbital_dot=o.interorbital_dot,
        spin_dot=o.spin_dot,SzSz=o.SzSz,density=o.density,double_occupancy=o.double_occupancy,
        Sz_local=o.Sz_local,probes=o.probes,per_state_observables=o.per_state,
        lowlevels=lowlevels,seed_agreement=seed_agreement,
        diagnostics=(energy_difference=Eerror,ground_subspace_error=subspace_error,
            spin_matrix_difference=spin_error,ground_H_residuals=fresh_residuals,
            spin_action_residuals=resolved[1].residuals,seeds=SEEDS),
        source_sha256=sha(@__FILE__),source_order="up-major/down-minor; packed all up modes then all down modes",
        completeness="Observed manifold only: independent finite Krylov starts and a resolved returned boundary do not prove exhaustive spectral coverage.",
        scalar_convention="q probes are scalar/Ncells (all three components); z/Ncells is separately measured in this fixed Sz sector.")
end

function run_registered(output_dir;plan_path)
    ispath(output_dir) && error("Refusing existing study directory")
    isfile(plan_path) || error("Prospective plan is required")
    mkpath(output_dir);BLAS.set_num_threads(1)
    K=ED.open_cluster_kinetic_matrix(3,2,ED.ModelParameters(t1=-1.,t2=-1.75,t3=-.85,t4=-.65))
    metadata=Dict("source_sha256"=>sha(@__FILE__),"plan_sha256"=>sha(plan_path),
        "lanczos_sha256"=>sha(joinpath(@__DIR__,"../prl_101_237004_restarted_lanczos.jl")),
        "open_ED_sha256"=>sha(joinpath(@__DIR__,"../two_orbital_open_cluster_ed.jl")),
        "julia_version"=>string(VERSION),"started_utc"=>string(now(UTC)),
        "seeds"=>collect(SEEDS),"config"=>Dict(string(k)=>v for(k,v) in pairs(CONFIG)))
    open(io->TOML.print(io,metadata),joinpath(output_dir,"metadata.toml"),"w")
    summaries=Dict{String,Any}()
    for (nu,nd) in SECTORS
        name="N$(nu+nd)_up$(nu)_down$(nd)";H=sector_operator(K,20.,nu,nd)
        arms=[solve_arm(H;seed=seed,output_dir=joinpath(output_dir,name,"seed$seed")) for seed in SEEDS]
        reference=compare_arms(H,arms;Lx=3,Ly=2)
        atomic_serialize(joinpath(output_dir,name,"reference.jls"),reference)
        summaries[name]=Dict("accepted"=>reference.accepted,"status"=>reference.status,
            "dimension"=>length(H.diagonal),"arm_converged"=>[a.converged for a in arms],
            "arm_seconds"=>[a.seconds for a in arms],"arm_matvecs"=>[a.matvecs for a in arms])
        if hasproperty(reference,:ground_energy)
            summaries[name]["ground_energy"]=reference.ground_energy
            summaries[name]["ground_degeneracy_observed"]=reference.ground_degeneracy_observed
            summaries[name]["S2"]=reference.total_spin_squared
            summaries[name]["Sodd_q0_scalar"]=reference.probes[1].odd_scalar
        end
        summaries[name]["reference_file"]="reference.jls"
        summaries[name]["reference_sha256"]=sha(joinpath(output_dir,name,"reference.jls"))
        summaries[name]["acceptance_reasons"]=hasproperty(reference,:acceptance_reasons) ? reference.acceptance_reasons : ["No Ritz pairs from a start"]
        open(io->TOML.print(io,summaries[name]),joinpath(output_dir,name,"reference.toml"),"w")
        H=nothing;arms=nothing;reference=nothing;GC.gc()
    end
    summary=Dict("status"=>all(s["accepted"] for s in values(summaries)) ? "ACCEPTED_CANDIDATE_REFERENCES" : "INCONCLUSIVE",
        "finished_utc"=>string(now(UTC)),"sectors"=>summaries)
    open(io->TOML.print(io,summary),joinpath(output_dir,"summary.toml"),"w")
    summary
end

end

if abspath(PROGRAM_FILE)==@__FILE__
    length(ARGS)==3 && ARGS[1]=="--run-registered" || error("Usage: --run-registered OUTPUT_DIR PLAN_PATH")
    ALMMatrixFreeED20260911.run_registered(abspath(ARGS[2]);plan_path=abspath(ARGS[3]))
end
