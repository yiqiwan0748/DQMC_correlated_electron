#!/usr/bin/env julia
using Test,LinearAlgebra,Random,SparseArrays,Serialization
include(joinpath(@__DIR__,"alm_matrixfree_ed_20260911.jl"))
include(joinpath(@__DIR__,"alm_exact_locking_20260911.jl"))
const MF=ALMMatrixFreeED20260911
const OLD=ALMExactLocking20260911
const ED=MF.ED
BLAS.set_num_threads(1)

@testset "Factorized action and ordering" begin
    rng=MersenneTwister(81321)
    for (lx,ly,nu,nd) in ((1,2,1,1),(2,1,2,1),(2,2,1,1),(2,2,2,1)), U in (0.,20.)
        K=ED.open_cluster_kinetic_matrix(lx,ly)
        H=MF.sector_operator(K,U,nu,nd)
        frozen=ED.sector_hamiltonian(K,U,nu,nd)
        dense=ED.dense_sector_hamiltonian(frozen)
        @test H.basis.up_states==frozen.basis.up_states
        @test H.basis.down_states==frozen.basis.down_states
        @test H.up_hopping≈H.up_hopping' atol=1e-14 rtol=0
        @test H.down_hopping≈H.down_hopping' atol=1e-14 rtol=0
        D=size(H,1);v=randn(rng,D);w=randn(rng,D);v/=norm(v);w/=norm(w)
        @test H*v≈dense*v atol=2e-12 rtol=0
        @test dot(w,H*v)≈dot(H*w,v) atol=2e-12 rtol=0
        Hu=H.up_hopping;Hd=H.down_hopping;X=reshape(v,length(H.basis.down_states),:)
        @test H*v≈vec(Hd*X+X*Hu').+H.diagonal.*v atol=2e-12 rtol=0
        for j in unique((1,cld(D,2),D))
            e=zeros(D);e[j]=1
            @test H*e≈dense[:,j] atol=2e-12 rtol=0
        end
        y=zeros(D);mul!(y,H,v)
        @test @allocated(mul!(y,H,v))<4096 # No allocation proportional to sector dimension.
        @test_throws ArgumentError mul!(v,H,v)
    end
end

@testset "Signed spin images, scalar contacts and half-integer labels" begin
    for (nu,nd) in ((1,1),(2,1),(2,0))
        K=ED.open_cluster_kinetic_matrix(2,1);H=MF.sector_operator(K,20.,nu,nd)
        frozen=ED.sector_hamiltonian(K,20.,nu,nd);eig=eigen(Symmetric(ED.dense_sector_hamiltonian(frozen)))
        b=H.basis;ops=OLD.spin_operators(b)
        rng=MersenneTwister(811+nu+nd);v=randn(rng,length(b));v/=norm(v)
        for direction in (-1,1)
            old=direction==1 ? ops.plus : ops.minus
            @test MF.local_spin_images(b,v,direction)≈hcat((a*v for a in old.operators)...) atol=2e-13 rtol=0
        end
        @test MF.raising_image(b,v)≈ops.raising*v atol=2e-13 rtol=0
        @test MF.raising_adjoint(b,MF.raising_image(b,v))≈ops.raising'*(ops.raising*v) atol=2e-13 rtol=0
        obs=MF.state_observables(b,v;Lx=2,Ly=1);previous=OLD.scalar_correlations(v,ops)
        @test obs.spin_dot≈previous.C atol=2e-12 rtol=0
        @test obs.density≈previous.density atol=2e-12 rtol=0
        @test obs.double_occupancy≈previous.doubles atol=2e-12 rtol=0
        @test obs.total_spin_squared≈obs.orbital_A_squared+obs.orbital_B_squared+2obs.interorbital_dot atol=2e-12 rtol=0
        @test obs.probes[1].even_scalar≈obs.total_spin_squared/2 atol=2e-12 rtol=0
        g=count(e->e-eig.values[1]<1e-8,eig.values)
        r=MF.resolve_spin(b,eig.vectors[:,1:g]);@test r.accepted
        @test all(isodd(round(Int,2s))==isodd(nu+nd) for s in r.spins)
        @test maximum(r.residuals)<2e-11
        dest=MF.spin_destination(b,1)
        if dest!==nothing
            next=MF.sector_operator(K,20.,nu+1,nd-1)
            @test next*MF.raising_image(b,v)≈MF.raising_image(b,H*v) atol=2e-12 rtol=0
        end
    end
end

@testset "Rectangular kinetic rotation and dimension guard" begin
    K=ED.open_cluster_kinetic_matrix(3,2);Krot=ED.open_cluster_kinetic_matrix(2,3)
    Q=zeros(12,12);orbital=[0 -1;1 0]
    for y in 0:1,x in 0:2,a in 1:2,b in 1:2
        Q[2*((1-y)+2*x)+b,2*(x+3*y)+a]=orbital[b,a]
    end
    @test Q*Q'≈I atol=1e-14 rtol=0
    @test Krot≈Q*K*Q' atol=1e-14 rtol=0
    @test [binomial(12,u)*binomial(12,d) for(u,d) in MF.SECTORS]==[245025,174240,392040,203280]
end

@testset "Bounded solver, raw reference and inconclusive degeneracy" begin
    K=ED.open_cluster_kinetic_matrix(2,1);H=MF.sector_operator(K,20.,1,1)
    exact=eigen(Symmetric(ED.dense_sector_hamiltonian(ED.sector_hamiltonian(K,20.,1,1))))
    config=(nev=3,krylovdim=16,keep=5,max_matvecs=150,atol=1e-9,rtol=0.,max_bytes=32*1024^2,wall_seconds=60.)
    mktempdir() do dir
        arms=[MF.solve_arm(H;seed=seed,output_dir=joinpath(dir,string(seed)),config=config) for seed in MF.SEEDS]
        @test all(a.converged for a in arms)
        @test arms[1].values≈exact.values[1:3] atol=2e-10 rtol=0
        @test maximum(arms[1].residuals)<1e-9
        reference=MF.compare_arms(H,arms;Lx=2,Ly=1)
        @test !hasproperty(reference,:H)
        @test reference.ground_energy≈exact.values[1] atol=2e-10 rtol=0
        @test reference.source_order=="up-major/down-minor; packed all up modes then all down modes"
        # This disconnected-orbital fixture has an actual degenerate ground.
        @test !reference.accepted
        @test reference.ground_degeneracy_observed>1
        @test any(reason->occursin("degeneracy",reason),reference.acceptance_reasons)
        @test_throws ErrorException MF.solve_arm(H;seed=MF.SEEDS[1],output_dir=joinpath(dir,string(MF.SEEDS[1])),config=config)
        expired=merge(config,(wall_seconds=-1.,))
        timeout=MF.solve_arm(H;seed=7,output_dir=joinpath(dir,"expired"),config=expired)
        @test timeout.wall_limited && !timeout.converged && isempty(timeout.values)
        @test isfile(joinpath(dir,"expired/result.jls"))
        K2=ED.open_cluster_kinetic_matrix(2,2);H2=MF.sector_operator(K2,20.,1,1)
        config2=merge(config,(krylovdim=64,))
        arms2=[MF.solve_arm(H2;seed=seed,output_dir=joinpath(dir,"unique$seed"),config=config2) for seed in MF.SEEDS]
        unique_reference=MF.compare_arms(H2,arms2;Lx=2,Ly=2)
        @test unique_reference.accepted
        @test unique_reference.ground_degeneracy_observed==1
        @test unique_reference.ground_boundary_resolved
        @test unique_reference.total_spin==[0.]
        @test isempty(unique_reference.acceptance_reasons)
        @test length(unique_reference.probes)==8
    end
end
println("Matrix-free bridge focused tests finished; no registered3×2 eigensolve launched.")
