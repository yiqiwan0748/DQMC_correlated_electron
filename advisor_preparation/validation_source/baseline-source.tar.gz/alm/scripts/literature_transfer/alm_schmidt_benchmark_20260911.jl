#!/usr/bin/env julia
"""
Small-cluster Schmidt compression oracle for existing open-cluster ED vectors.

This module performs no DMRG sweeps, Hamiltonian construction, or scientific runs
when included. Only Julia stdlib LinearAlgebra is used; at most eight spatial
modes (sixteen spin modes) are accepted.
"""
module ALMSchmidtBenchmark
using LinearAlgebra

export fermionic_local_sign, coefficient_blocks, restore_sector_vector,
       schmidt_cut, schmidt_analysis, truncate_cut

const DEFAULT_DISCARDED_WEIGHTS = (1e-4,1e-6,1e-8,1e-10)
const BASIS_CONVENTION = "ED index=(iup-1)*length(down_states)+idown; source creation order all ascending up modes then all ascending down modes; local order (empty,up,down,updown), updown=c_up^dagger*c_down^dagger|0>; spatial modes orbital-fast with x preceding y"

function checked_modes(nmodes)
    nmodes isa Integer && !(nmodes isa Bool) && 1<=nmodes<=8 ||
        throw(ArgumentError("nmodes must be an integer in 1:8; this is a bounded ED oracle"))
    Int(nmodes)
end
function checked_cut(cut,nmodes)
    cut isa Integer && !(cut isa Bool) && 1<=cut<nmodes ||
        throw(ArgumentError("cut must be an integer in 1:nmodes-1"))
    Int(cut)
end
function checked_state(state,nmodes)
    state isa Integer && !(state isa Bool) && 0<=state<(1<<nmodes) ||
        throw(ArgumentError("Fock masks must be integer bit patterns on nmodes modes"))
    UInt64(state)
end

function checked_basis(up_states,down_states,coefficients,nmodes)
    m=checked_modes(nmodes)
    isempty(up_states) && throw(ArgumentError("up_states must not be empty"))
    isempty(down_states) && throw(ArgumentError("down_states must not be empty"))
    us=[checked_state(u,m) for u in up_states]
    ds=[checked_state(d,m) for d in down_states]
    length(unique(us))==length(us) && length(unique(ds))==length(ds) ||
        throw(ArgumentError("Duplicate spin-sector masks are not allowed"))
    nu=count_ones(us[1]);nd=count_ones(ds[1])
    all(u->count_ones(u)==nu,us) && all(d->count_ones(d)==nd,ds) ||
        throw(ArgumentError("Each spin mask list must have one fixed particle count"))
    length(us)==binomial(m,nu) && length(ds)==binomial(m,nd) ||
        throw(ArgumentError("Complete fixed-particle spin bases are required for lossless sector reconstruction"))
    coefficients isa AbstractVector && length(coefficients)==length(us)*length(ds) ||
        throw(ArgumentError("coefficients must be a vector with down-spin index varying fastest"))
    all(z->z isa Number && isfinite(z),coefficients) ||
        throw(ArgumentError("All coefficients must be finite numbers"))
    # The bounded oracle deliberately uses LAPACK-supported Float64/ComplexF64.
    # No arbitrary-precision SVD dependency is introduced.
    T=all(isreal,coefficients) ? Float64 : ComplexF64
    psi=T.(coefficients)
    norm2=sum(abs2,psi)
    isfinite(norm2) && norm2>0 || throw(ArgumentError("The state must have finite nonzero norm"))
    (nmodes=m,Nup=nu,Ndown=nd,up_states=us,down_states=ds,psi=psi,norm2=norm2)
end

@inline function local_sign(u::UInt64,d::UInt64,nmodes::Int)
    # Every down creator on mode i passes every occupied up creator on mode j>i.
    inversions=0
    for i in 0:nmodes-1
        if !iszero(d & (UInt64(1)<<i));inversions+=count_ones(u>>(i+1));end
    end
    isodd(inversions) ? -1 : 1
end

"""
    fermionic_local_sign(up_mask, down_mask, nmodes)

Sign converting the all-up-then-all-down source Fock ordering to interleaved
spatial-mode ordering. It equals (-1)^(number of occupied pairs down_i,up_j
with i<j). The local doubly occupied state is up^dagger down^dagger|0>.
"""
function fermionic_local_sign(up_mask,down_mask,nmodes)
    m=checked_modes(nmodes)
    local_sign(checked_state(up_mask,m),checked_state(down_mask,m),m)
end

@inline function local_code(u::UInt64,d::UInt64,nmodes::Int)
    code=UInt64(0)
    for i in 0:nmodes-1
        code|=((u>>i)&1)<<(2i)
        code|=((d>>i)&1)<<(2i+1)
    end
    code
end

"""
    coefficient_blocks(up_states, down_states, psi; nmodes, cut)

Build the bipartite coefficient matrices in sectors labelled by the left
(Nup,Ndown). Source vector indexing is down-fast. Spatial mode 1 is the least
significant mask bit; cut separates modes 1:cut from cut+1:nmodes.

Each block has `left_charge`, `right_charge`, `left_basis`, `right_basis`, and
`matrix`. Basis labels are base-four local-state encodings, with digits
0=empty, 1=up, 2=down, 3=updown. Matrices include the fermionic reordering sign.
Input normalization is recorded, not silently changed. Mask arrays can have
any order, provided each is the complete fixed-particle basis.
"""
function coefficient_blocks(up_states,down_states,coefficients;nmodes,cut)
    b=checked_basis(up_states,down_states,coefficients,nmodes)
    c=checked_cut(cut,b.nmodes);T=eltype(b.psi)
    spatial_mask=(UInt64(1)<<c)-1
    code_mask=(UInt64(1)<<(2c))-1
    entries=Dict{Tuple{Int,Int},Vector{Tuple{UInt64,UInt64,T}}}()
    k=0
    for u in b.up_states,d in b.down_states
        k+=1
        q=(count_ones(u&spatial_mask),count_ones(d&spatial_mask))
        code=local_code(u,d,b.nmodes)
        push!(get!(entries,q,Tuple{UInt64,UInt64,T}[]),
            (code&code_mask,code>>(2c),local_sign(u,d,b.nmodes)*b.psi[k]))
    end
    blocks=NamedTuple[]
    for q in sort(collect(keys(entries)))
        list=entries[q]
        lb=sort(unique([v[1] for v in list]));rb=sort(unique([v[2] for v in list]))
        li=Dict(x=>i for (i,x) in enumerate(lb));ri=Dict(x=>i for (i,x) in enumerate(rb))
        matrix=zeros(T,length(lb),length(rb))
        for (l,r,a) in list;matrix[li[l],ri[r]]=a;end
        push!(blocks,(left_charge=q,right_charge=(b.Nup-q[1],b.Ndown-q[2]),
            left_basis=lb,right_basis=rb,matrix=matrix))
    end
    (nmodes=b.nmodes,Nup=b.Nup,Ndown=b.Ndown,cut=c,
        up_states=b.up_states,down_states=b.down_states,input_norm2=b.norm2,
        basis_convention=BASIS_CONVENTION,blocks=blocks)
end

"""Restore a `coefficient_blocks` result into its original down-fast ED ordering."""
function restore_sector_vector(partition)
    p=partition;T=eltype(first(p.blocks).matrix)
    lookup=Dict(b.left_charge=>(block=b,
        left=Dict(x=>i for (i,x) in enumerate(b.left_basis)),
        right=Dict(x=>i for (i,x) in enumerate(b.right_basis))) for b in p.blocks)
    result=zeros(T,length(p.up_states)*length(p.down_states))
    spatial_mask=(UInt64(1)<<p.cut)-1;code_mask=(UInt64(1)<<(2p.cut))-1
    k=0
    for u in p.up_states,d in p.down_states
        k+=1;q=(count_ones(u&spatial_mask),count_ones(d&spatial_mask))
        item=lookup[q];code=local_code(u,d,p.nmodes)
        result[k]=local_sign(u,d,p.nmodes)*item.block.matrix[item.left[code&code_mask],item.right[code>>(2p.cut)]]
    end
    result
end

function checked_thresholds(weights)
    vals=Float64.(collect(weights))
    all(w->isfinite(w) && 0<=w<1,vals) ||
        throw(ArgumentError("Discarded-weight thresholds must be finite in [0,1)"))
    length(unique(vals))==length(vals) || throw(ArgumentError("Discarded-weight thresholds must be unique"))
    vals
end

function required_bonds(probabilities,weights)
    # Direct tail sums avoid subtracting two nearly equal numbers at small tails.
    Dict(w=>something(findfirst(k->sum(@view probabilities[k+1:end])<=w,0:length(probabilities)),
                       length(probabilities)+1)-1 for w in weights)
end

"""
    schmidt_cut(up_states, down_states, psi, cut; nmodes,
                discarded_weights=(1e-4,1e-6,1e-8,1e-10), rank_rtol=1e-12)

Return normalized, globally descending singular-value probabilities; entropy
in natural-log units; numerical rank; required total bond dimensions for the
requested discarded weights; and `charge_blocks` (including their matrices).
`numerical_rank` uses singular value > rank_rtol * the largest singular value,
and is explicitly a numerical diagnostic, not an exact-rank theorem. Bond
dimensions count all retained singular vectors across charge sectors.
"""
function schmidt_cut(up_states,down_states,psi,cut;nmodes,
    discarded_weights=DEFAULT_DISCARDED_WEIGHTS,rank_rtol=1e-12)
    isfinite(rank_rtol) && 0<=rank_rtol<1 || throw(ArgumentError("rank_rtol must be finite in [0,1)"))
    weights=checked_thresholds(discarded_weights)
    part=coefficient_blocks(up_states,down_states,psi;nmodes=nmodes,cut=cut)
    charge_blocks=NamedTuple[];probabilities=Float64[]
    for block in part.blocks
        values=svdvals(block.matrix)
        probs=abs2.(values)./part.input_norm2
        append!(probabilities,probs)
        push!(charge_blocks,merge(block,(singular_values=values,probabilities=probs,weight=sum(probs))))
    end
    sort!(probabilities,rev=true)
    entropy=-sum(p*log(p) for p in probabilities if p>0)
    rank=count(p->p>rank_rtol^2*maximum(probabilities),probabilities)
    (cut=part.cut,nmodes=part.nmodes,Nup=part.Nup,Ndown=part.Ndown,
        input_norm2=part.input_norm2,probabilities=probabilities,
        probability_sum=sum(probabilities),entropy=entropy,numerical_rank=rank,
        rank_rtol=Float64(rank_rtol),required_bond_dimensions=required_bonds(probabilities,weights),
        charge_blocks=charge_blocks,basis_convention=BASIS_CONVENTION)
end

"""
    schmidt_analysis(up_states, down_states, psi; nmodes=8, cuts=1:nmodes-1,
        discarded_weights=(1e-4,1e-6,1e-8,1e-10), rank_rtol=1e-12)

Analyze each requested cut in the declared orbital-fast, x-then-y local order.
Returns `.cuts`, a vector of `schmidt_cut` results. This is a Schmidt/DMRG
feasibility diagnostic for one exact state; it is not a DMRG calculation or a
bound on the bond dimension required for another state or larger lattice.
"""
function schmidt_analysis(up_states,down_states,psi;nmodes=8,cuts=1:nmodes-1,
    discarded_weights=DEFAULT_DISCARDED_WEIGHTS,rank_rtol=1e-12)
    b=checked_basis(up_states,down_states,psi,nmodes)
    requested=[checked_cut(c,b.nmodes) for c in cuts]
    length(unique(requested))==length(requested) || throw(ArgumentError("Duplicate cuts are not allowed"))
    results=[schmidt_cut(up_states,down_states,psi,c;nmodes=nmodes,
        discarded_weights=discarded_weights,rank_rtol=rank_rtol) for c in requested]
    (nmodes=b.nmodes,Nup=b.Nup,Ndown=b.Ndown,input_norm2=b.norm2,
        basis_convention=BASIS_CONVENTION,cuts=results)
end

"""
    truncate_cut(up_states, down_states, psi, cut; nmodes=8, max_bond,
                 normalize=false)

Retain the globally largest `max_bond` Schmidt values across all charge
blocks and reconstruct into the original ED sector. Equal singular values
are broken deterministically by left charge and within-block index; a cut
through a degenerate multiplet need not preserve total-spin symmetry.

`discarded_weight` is fractional. Before optional normalization,
`unnormalized_error_norm2 == input_norm2*discarded_weight` up to SVD roundoff.
The returned `.vector` keeps the original norm scale unless normalize=true.
This is a SINGLE-CUT optimal-rank truncation, not repeated MPS compression,
a variational DMRG sweep, or a prediction of global energy accuracy.
"""
function truncate_cut(up_states,down_states,psi,cut;nmodes=8,max_bond,normalize=false)
    max_bond isa Integer && !(max_bond isa Bool) && max_bond>=1 ||
        throw(ArgumentError("max_bond must be a positive integer"))
    part=coefficient_blocks(up_states,down_states,psi;nmodes=nmodes,cut=cut)
    factors=[svd(b.matrix;full=false) for b in part.blocks]
    modes=[(probability=abs2(f.S[j])/part.input_norm2,block=i,mode=j)
           for (i,f) in enumerate(factors) for j in eachindex(f.S)]
    sort!(modes,by=m->(-m.probability,part.blocks[m.block].left_charge,m.mode))
    keep=Int(min(max_bond,length(modes)));counts=zeros(Int,length(factors))
    for m in modes[1:keep];counts[m.block]+=1;end
    truncated=NamedTuple[]
    for (i,block) in enumerate(part.blocks)
        f=factors[i];r=counts[i]
        matrix=r==0 ? zero(block.matrix) : f.U[:,1:r]*Diagonal(f.S[1:r])*f.Vt[1:r,:]
        push!(truncated,merge(block,(matrix=matrix,)))
    end
    raw=restore_sector_vector(merge(part,(blocks=truncated,)))
    discarded=sum(m.probability for m in modes[keep+1:end];init=0.0)
    raw_norm2=sum(abs2,raw);raw_error2=sum(abs2,raw-psi)
    result=normalize ? raw/sqrt(raw_norm2) : raw
    (vector=result,cut=part.cut,max_bond=Int(max_bond),retained_bond=keep,
        input_norm2=part.input_norm2,output_norm2=sum(abs2,result),
        unnormalized_norm2=raw_norm2,unnormalized_error_norm2=raw_error2,
        discarded_weight=discarded,retained_weight=1-discarded,
        reconstruction_error_norm2=sum(abs2,result-psi),normalized=normalize,
        retained_per_charge=Dict(part.blocks[i].left_charge=>counts[i] for i in eachindex(counts)),
        basis_convention=BASIS_CONVENTION)
end

end # module; intentionally no entrypoint or filesystem effects
