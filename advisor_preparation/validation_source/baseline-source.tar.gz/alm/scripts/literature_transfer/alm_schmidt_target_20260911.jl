#!/usr/bin/env julia
"""Postprocess archived exact states only; no Hamiltonian eigensolver or DMRG."""
module ALMSchmidtTarget20260911
using LinearAlgebra, Serialization, SHA, Dates, Printf, TOML
include("alm_schmidt_benchmark_20260911.jl")
using .ALMSchmidtBenchmark

const ROOT=normpath(joinpath(@__DIR__,"../.."))
const DEFAULT_INPUT=joinpath(ROOT,"results/literature_transfer/alm_exact_locking_20260911")
const DEFAULT_OUTPUT=joinpath(ROOT,"results/literature_transfer/alm_schmidt_benchmark_20260911/target_analysis")
const CASES=((label="zero",t4=0.),(label="half",t4=-.325),(label="target",t4=-.65))
const CHIS=(8,16,32,64,128,256)
const DW=(1e-4,1e-6,1e-8,1e-10)
check(condition,message)=condition || error(message)
sha(path)=open(io->bytes2hex(sha256(io)),path)

function write_rows(path,rows)
    isempty(rows) && error("No rows for $path")
    ispath(path) && error("Refusing result overwrite: $path")
    open(path,"w") do io
        println(io,join(string.(keys(first(rows))),','))
        for row in rows
            fields=["\""*replace(string(v),'"'=>"\"\"")*"\"" for v in values(row)]
            println(io,join(fields,','))
        end
    end
end

"""O_z=sum_cells(Sz_xz-Sz_yz), in the original down-fast source sector order."""
function odd_z_diagonal(up_states,down_states;nmodes=8)
    nmodes==8 || throw(ArgumentError("This target integration is fixed to eight spatial modes"))
    result=Float64[]
    for u in up_states,d in down_states
        o=0.0
        for i in 0:nmodes-1
            spin=(Int((u>>i)&1)-Int((d>>i)&1))/2
            o+=(iseven(i) ? 1 : -1)*spin
        end
        push!(result,o)
    end
    result
end

"""Normalized physical moments; raw second moment and connected variance stay separate."""
function state_observables(psi,H,oz;cells=4)
    cells==4 || throw(ArgumentError("The target has four physical cells"))
    check(length(psi)==length(oz)==size(H,1)==size(H,2),"Observable dimensions disagree")
    n2=sum(abs2,psi);check(n2>0 && isfinite(n2),"Invalid state norm")
    p=abs2.(psi)./n2
    o=dot(p,oz);o2=dot(p,abs2.(oz));energy=dot(psi,H*psi)/n2
    check(abs(imag(energy))<2e-10,"Nonreal Hermitian expectation value")
    (norm2=n2,energy=real(energy),O_z_mean=o,O_z_squared=o2,
        Delta=o/cells,S_odd_z=o2/cells,S_odd_z_connected=(o2-o^2)/cells)
end

function input_check(data,case)
    check(data.U==20 && data.Nup==3 && data.Ndown==3,"Unexpected U or particle sector")
    check(data.t4==case.t4 && size(data.kinetic)==(8,8),"Unexpected hopping control or number of modes")
    check(data.source_order=="up-major/down-minor; packed up1..up8,down1..down8","Unknown source Fock convention")
    d=length(data.up_states)*length(data.down_states)
    check(size(data.H)==(d,d) && size(data.ground_vectors,1)==d,"Basis/vector/H dimension mismatch")
    ng=size(data.ground_vectors,2)
    check(ng==length(data.ground_spins)==data.ground_degeneracy_Sz0,"Incomplete Sz0 ground-state labels")
    check(round(Int,sum(2s+1 for s in data.ground_spins))==data.full_ground_degeneracy,
        "Sz0 multiplet labels do not account for the full ground degeneracy")
    check(maximum(abs,data.H-data.H')<2e-11,"Input H is not Hermitian")
    check(maximum(abs,data.ground_vectors'*data.ground_vectors-I)<2e-10,"Ground columns not orthonormal")
end

function run_analysis(;input_dir=DEFAULT_INPUT,output_dir=DEFAULT_OUTPUT)
    # Wait for the producer's complete validation, never consume partially written inputs.
    status=joinpath(input_dir,"status.txt")
    isfile(status) && startswith(read(status,String),"COMPLETE_VALIDATED") ||
        error("Exact producer has not reported COMPLETE_VALIDATED")
    inputs=[joinpath(input_dir,"schmidt_input_t4_$(c.label).jls") for c in CASES]
    all(isfile,inputs) || error("Missing exact-state input")
    ispath(output_dir) && error("Refusing existing target-analysis directory")
    input_hashes=Dict(path=>sha(path) for path in inputs)
    module_path=joinpath(@__DIR__,"alm_schmidt_benchmark_20260911.jl")
    sources=Dict((@__FILE__)=>sha(@__FILE__),module_path=>sha(module_path))
    mkpath(output_dir)
    cp(@__FILE__,joinpath(output_dir,"runner_source.jl"))
    cp(module_path,joinpath(output_dir,"schmidt_module_source.jl"))
    open(joinpath(output_dir,"provenance.toml"),"w") do io
        TOML.print(io,Dict("started_utc"=>string(now(UTC)),"julia_version"=>string(VERSION),
            "scope"=>"Pure exact-state postprocessing and single-cut compression; no new Hamiltonian solution, no DMRG",
            "source_hashes"=>sources,"input_hashes"=>input_hashes,"nmodes"=>8,"cells"=>4,
            "basis_convention"=>ALMSchmidtBenchmark.BASIS_CONVENTION,
            "cut_definition"=>"After orbital-fast local spatial mode c; one mode has local dimension 4",
            "degeneracy_note"=>"Each definite-totalS Sz0 ground column treated as a separate pure state. Same-S degeneracies retain basis freedom. No mixed-state entropy or averaged ground-state vector."))
    end
    states=NamedTuple[];cutrows=NamedTuple[];spectra=NamedTuple[];charge=NamedTuple[];truncrows=NamedTuple[]
    try
        for (case,path) in zip(CASES,inputs)
            data=deserialize(path);input_check(data,case)
            oz=odd_z_diagonal(data.up_states,data.down_states)
            for index in axes(data.ground_vectors,2)
                psi=copy(data.ground_vectors[:,index]);obs=state_observables(psi,data.H,oz)
                residual=norm(data.H*psi-data.ground_energy*psi)
                check(abs(obs.norm2-1)<2e-10 && residual<2e-8,"Input ground state failed norm or original-H residual")
                id=(label=case.label,t4=case.t4,state_index=index,total_spin_label=data.ground_spins[index],
                    Sz=0,ground_degeneracy_Sz0=data.ground_degeneracy_Sz0,
                    full_ground_degeneracy=data.full_ground_degeneracy,state_kind="pure_definite_S_column")
                push!(states,merge(id,(source_ground_energy=data.ground_energy,eigen_residual=residual,),obs))
                analysis=schmidt_analysis(data.up_states,data.down_states,psi;nmodes=8,cuts=1:7,discarded_weights=DW)
                for c in analysis.cuts
                    check(abs(c.probability_sum-1)<2e-10,"Schmidt probabilities are not normalized")
                    push!(cutrows,merge(id,(cut=c.cut,entropy_natural_log=c.entropy,numerical_rank=c.numerical_rank,
                        rank_rtol=c.rank_rtol,probability_sum=c.probability_sum,
                        chi_dw_1e4=c.required_bond_dimensions[1e-4],chi_dw_1e6=c.required_bond_dimensions[1e-6],
                        chi_dw_1e8=c.required_bond_dimensions[1e-8],chi_dw_1e10=c.required_bond_dimensions[1e-10])))
                    local_spectrum=NamedTuple[]
                    for b in c.charge_blocks
                        push!(charge,merge(id,(cut=c.cut,left_Nup=b.left_charge[1],left_Ndown=b.left_charge[2],
                            right_Nup=b.right_charge[1],right_Ndown=b.right_charge[2],
                            left_dimension=size(b.matrix,1),right_dimension=size(b.matrix,2),
                            weight=b.weight,entropy_contribution=-sum(p*log(p) for p in b.probabilities if p>0;init=0.))))
                        for (j,p) in enumerate(b.probabilities)
                            push!(local_spectrum,(left_Nup=b.left_charge[1],left_Ndown=b.left_charge[2],
                                right_Nup=b.right_charge[1],right_Ndown=b.right_charge[2],sector_singular_index=j,
                                singular_value=b.singular_values[j],probability=p))
                        end
                    end
                    sort!(local_spectrum,by=r->(-r.probability,r.left_Nup,r.left_Ndown,r.sector_singular_index))
                    for (rank,r) in enumerate(local_spectrum)
                        push!(spectra,merge(id,(cut=c.cut,global_singular_index=rank,),r))
                    end
                end
                for chi in CHIS
                    t=truncate_cut(data.up_states,data.down_states,psi,4;nmodes=8,max_bond=chi,normalize=true)
                    tobs=state_observables(t.vector,data.H,oz)
                    norm_identity=t.unnormalized_error_norm2-t.input_norm2*t.discarded_weight
                    retained_norm_identity=t.unnormalized_norm2-t.input_norm2*(1-t.discarded_weight)
                    fidelity=abs2(dot(psi,t.vector))/obs.norm2
                    subspace_fidelity=sum(abs2,data.ground_vectors'*t.vector)
                    check(abs(tobs.norm2-1)<2e-10 && abs(norm_identity)<2e-10 && abs(retained_norm_identity)<2e-10,
                        "Truncation norm/discarded-weight identity failed")
                    check(abs(fidelity-(1-t.discarded_weight))<2e-10,"Single-cut state fidelity does not match retained Schmidt weight")
                    check(tobs.energy-data.ground_energy>=-2e-8,"Normalized-state energy falls below the ED ground energy")
                    chi==256 && check(abs(tobs.energy-data.ground_energy)<2e-8 && abs(tobs.S_odd_z-obs.S_odd_z)<2e-9,
                        "Maximum-bond reconstruction is not lossless")
                    push!(truncrows,merge(id,(cut=4,requested_chi=chi,retained_chi=t.retained_bond,
                        discarded_weight=t.discarded_weight,unnormalized_norm2=t.unnormalized_norm2,
                        unnormalized_error_norm2=t.unnormalized_error_norm2,norm_identity_residual=norm_identity,
                        retained_norm_identity_residual=retained_norm_identity,pure_state_fidelity=fidelity,
                        ground_subspace_fidelity=subspace_fidelity,energy_error=tobs.energy-data.ground_energy,
                        S_odd_z_error=tobs.S_odd_z-obs.S_odd_z,
                        S_odd_z_connected_error=tobs.S_odd_z_connected-obs.S_odd_z_connected),tobs))
                end
                println("Analyzed ",case.label," pure state ",index," S=",data.ground_spins[index]);flush(stdout)
            end
            data=nothing;GC.gc()
        end
        for (name,rows) in (("pure_ground_states.csv",states),("cut_summary.csv",cutrows),
            ("singular_spectrum.csv",spectra),("charge_weights.csv",charge),("central_cut_truncations.csv",truncrows))
            write_rows(joinpath(output_dir,name),rows)
        end
        check(all(sha(path)==digest for(path,digest) in input_hashes),"An exact input changed during postprocessing")
        check(all(sha(path)==digest for(path,digest) in sources),"An analysis source changed during postprocessing")
        open(joinpath(output_dir,"summary.toml"),"w") do io
            TOML.print(io,Dict("completed_utc"=>string(now(UTC)),"pure_states"=>length(states),
                "cut_summaries"=>length(cutrows),"spectrum_rows"=>length(spectra),"charge_blocks"=>length(charge),
                "central_truncations"=>length(truncrows),"max_input_eigen_residual"=>maximum(r.eigen_residual for r in states),
                "max_probability_sum_error"=>maximum(abs(r.probability_sum-1) for r in cutrows),
                "max_norm_identity_residual"=>maximum(abs(r.norm_identity_residual) for r in truncrows),
                "max_retained_norm_identity_residual"=>maximum(abs(r.retained_norm_identity_residual) for r in truncrows),
                "limitation"=>"Finite-cluster pure-state Schmidt postprocessing and single-cut compression; no DMRG or thermodynamic-phase inference"))
        end
        write(joinpath(output_dir,"status.txt"),"COMPLETE_VALIDATED_POSTPROCESSING_ONLY\n")
        files=sort([joinpath(dir,file) for(dir,_,names) in walkdir(output_dir) for file in names])
        write_rows(joinpath(output_dir,"artifact_manifest.csv"),[(relative_path=relpath(p,output_dir),bytes=filesize(p),sha256=sha(p)) for p in files])
        (states=states,cuts=cutrows,truncations=truncrows)
    catch err
        open(joinpath(output_dir,"status.txt"),"w") do io
            println(io,"FAILED; existing outputs retained");showerror(io,err,catch_backtrace());println(io)
        end
        rethrow()
    end
end

function main(args=ARGS)
    length(args) in (0,2) || error("Usage: julia .../alm_schmidt_target_20260911.jl [input_directory output_directory]")
    previous=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        isempty(args) ? run_analysis() : run_analysis(input_dir=abspath(args[1]),output_dir=abspath(args[2]))
    finally
        BLAS.set_num_threads(previous)
    end
end
end
if abspath(PROGRAM_FILE)==@__FILE__;ALMSchmidtTarget20260911.main();end
