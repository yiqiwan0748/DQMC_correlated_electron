#!/usr/bin/env julia
"""Read-only ED/DMRG size-comparison postprocessing; no eigensolver imports."""
module ALMSizeBridgeReport20260911
using LinearAlgebra,Serialization,TOML,SHA,Dates,Printf
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const OLD_DEFAULT=joinpath(ROOT,"results/literature_transfer/alm_exact_locking_20260911")
const SECTORS=((4,4),(5,3),(5,4),(6,3))
const DMRG_SEEDS=(314159,271828)
const DMRG_CAPS=(128,256,512,1024,1024)
const ENERGY_ATOL=1e-8
const VARIANCE_ATOL=1e-8
const SPIN_ATOL=1e-6
const NUMBER_ATOL=1e-10
# CSV serialization is lossless here; 1e-9 permits harmless summation-order roundoff.
const SUMMARY_ATOL=1e-9
finite(x)=x isa Real && isfinite(x)
bounded(x,lo,hi)=finite(x) && lo<=x<=hi
integer(r,k)=tryparse(Int,get(r,k,""))
const QPOINTS=Tuple((Float64(x),Float64(y)) for y in (0.,pi) for x in (0.,pi/3,2pi/3,pi))
sha(p)=bytes2hex(sha256(read(p)))
num(s)=something(tryparse(Float64,s),missing)
number(r,k)=haskey(r,k) ? num(r[k]) : missing
truth(x)=x==true || x=="true"
fmt(x)=ismissing(x) ? "unresolved" : x isa Number ? @sprintf("%.9g",x) : string(x)

function csv_fields(line)
    fields=String[];buf=IOBuffer();quoted=false;i=firstindex(line)
    while i<=lastindex(line)
        c=line[i];j=nextind(line,i)
        if c=='"'
            if quoted && j<=lastindex(line) && line[j]=='"';write(buf,'"');i=j
            else;quoted=!quoted;end
        elseif c==',' && !quoted;push!(fields,String(take!(buf)))
        else;write(buf,c);end
        i=nextind(line,i)
    end
    quoted && error("Unterminated CSV quote")
    push!(fields,String(take!(buf)));fields
end
function read_csv(path)
    isfile(path) || return Dict{String,String}[]
    lines=readlines(path);isempty(lines) && return Dict{String,String}[]
    header=csv_fields(first(lines));rows=Dict{String,String}[]
    for line in lines[2:end]
        isempty(strip(line)) && continue;fields=csv_fields(line)
        length(fields)==length(header) || error("Malformed CSV row in $path")
        push!(rows,Dict(zip(header,fields)))
    end
    rows
end
function write_csv(path,rows,columns)
    esc(x)=ismissing(x) ? "" : "\""*replace(string(x),'"'=>"\"\"")*"\""
    open(path,"w") do io
        println(io,join(columns,','))
        for row in rows;println(io,join((esc(get(row,c,missing)) for c in columns),','));end
    end
end
function summary_row(;name,method,Lx,Ly,N,Nup=missing,Ndown=missing,Sz=missing,status,usable=false,reason="")
    Dict{String,Any}("name"=>name,"method"=>method,"Lx"=>Lx,"Ly"=>Ly,"cells"=>Lx*Ly,
        "N"=>N,"density"=>N/(Lx*Ly),"Nup"=>Nup,"Ndown"=>Ndown,"Sz"=>Sz,
        "status"=>status,"usable"=>usable,"reason"=>reason)
end
function matrix_quantities(C,Z,density,doubles;Lx,Ly)
    nc=Lx*Ly;m=2nc;size(C)==(m,m) || error("Wrong spin-matrix dimension")
    all(isfinite,C) || error("Nonfinite spin matrix")
    A=1:2:m;B=2:2:m;odd=[isodd(a) ? 1. : -1. for a in 1:m]
    scalar=dot(odd,C*odd)/nc
    data=Dict{String,Any}("S2"=>sum(C),"orbital_A_squared"=>sum(C[A,A]),
        "orbital_B_squared"=>sum(C[B,B]),"interorbital_dot"=>sum(C[A,B]),
        "Sodd_q0_scalar"=>scalar,"Sodd_q0_order_proxy"=>scalar/nc,
        "Seven_q0_scalar"=>sum(C)/nc,"double_occupancy_total"=>sum(doubles),
        "particle_number_from_density"=>sum(density),
        "contact_error"=>maximum(abs,diag(C)-.75*(density-2doubles)))
    Z===nothing || (data["Sodd_q0_z_raw"]=dot(odd,Z*odd)/nc)
    probes=Dict{String,Any}[]
    for(qx,qy) in QPOINTS
        p=[cis(-qx*x-qy*y) for y in 0:Ly-1 for x in 0:Lx-1 for a in 1:2];o=p.*odd
        push!(probes,Dict("qx"=>qx,"qy"=>qy,"even_scalar"=>real(dot(p,C*p))/nc,
            "odd_scalar"=>real(dot(o,C*o))/nc,"odd_order_proxy"=>real(dot(o,C*o))/nc^2,
            "even_z_raw"=>Z===nothing ? missing : real(dot(p,Z*p))/nc,
            "odd_z_raw"=>Z===nothing ? missing : real(dot(o,Z*o))/nc))
    end
    data,probes
end

function old_reference(old_dir)
    row=summary_row(name="open2x2_N6",method="ED",Lx=2,Ly=2,N=6,Nup=3,Ndown=3,Sz=0.,status="UNRESOLVED_MISSING")
    rows=read_csv(joinpath(old_dir,"summary.csv"));found=filter(r->get(r,"label","")=="target",rows)
    length(found)==1 || return row
    r=only(found)
    for (to,from) in (("energy","energy"),("S2","total_spin_squared"),("orbital_A_squared","orbital_A_spin_squared"),
        ("orbital_B_squared","orbital_B_spin_squared"),("interorbital_dot","orbital_spin_dot"),
        ("Sodd_q0_scalar","S_odd_q0_scalar"),("double_occupancy_total","double_occupancy_total"))
        row[to]=number(r,from)
    end
    row["Sodd_q0_order_proxy"]=row["Sodd_q0_scalar"]/4
    row["Seven_q0_scalar"]=row["S2"]/4
    row["ground_spin"]="0";row["status"]="VALIDATED_PREVIOUS_ED";row["usable"]=true
    row["reason"]="Reused frozen full-eigensystem four-cell result"
    row
end

function read_ed(ed_dir,nu,nd,warnings)
    name="N$(nu+nd)_up$(nu)_down$(nd)";path=joinpath(ed_dir,name,"reference.jls")
    verdict_path=joinpath(ed_dir,name,"reference.toml")
    row=summary_row(name=name,method="ED",Lx=3,Ly=2,N=nu+nd,Nup=nu,Ndown=nd,Sz=(nu-nd)/2,status="UNRESOLVED_MISSING")
    isfile(path) || (row["reason"]="Reference file missing";return row,nothing,Dict{String,Any}[])
    reference=open(deserialize,path) # Trusted retrieved plain-array research artifact only.
    verdict=isfile(verdict_path) ? TOML.parsefile(verdict_path) : Dict{String,Any}()
    accepted=hasproperty(reference,:accepted) && reference.accepted && get(verdict,"accepted",false)
    row["status"]=accepted ? "ACCEPTED_CANDIDATE_ED" : "UNRESOLVED_ED"
    row["usable"]=accepted
    row["reason"]=hasproperty(reference,:acceptance_reasons) ? join(reference.acceptance_reasons,"; ") : "No accepted reference verdict"
    isempty(verdict) && (row["reason"]="Companion verdict missing")
    row["reference_sha256"]=sha(path)
    if get(verdict,"reference_sha256",nothing)!=row["reference_sha256"]
        row["usable"]=false;row["status"]="UNRESOLVED_HASH_MISMATCH";row["reason"]="Companion reference hash missing or differs"
    end
    if !reference_identity(reference,nu,nd)
        row["usable"]=false;row["status"]="UNRESOLVED_REFERENCE_IDENTITY";row["reason"]="Reference does not match the registered geometry, U, and sector"
    end
    probes=Dict{String,Any}[]
    if hasproperty(reference,:spin_dot)
        data,probes=matrix_quantities(reference.spin_dot,reference.SzSz,reference.density,
            reference.double_occupancy;Lx=3,Ly=2);merge!(row,data)
        row["energy"]=reference.ground_energy;row["ground_spin"]=join(reference.total_spin,";")
        row["ground_degeneracy_observed"]=reference.ground_degeneracy_observed
        row["max_eigenpair_residual"]=maximum(reference.residuals)
        row["S2_summary_discrepancy"]=abs(row["S2"]-reference.total_spin_squared)
        row["Sodd_summary_discrepancy"]=abs(row["Sodd_q0_scalar"]-reference.probes[1].odd_scalar)
    end
    row["usable"] || push!(warnings,"$name: "*row["status"]*" — "*row["reason"])
    row,reference,probes
end

function reference_identity(ref,nu,nd)
    ref===nothing && return false
    all(hasproperty(ref,k) && getproperty(ref,k)==v for (k,v) in
        ((:Lx,3),(:Ly,2),(:cells,6),(:U,20.0),(:N,nu+nd),(:Nup,nu),(:Ndown,nd),(:Sz,(nu-nd)/2)))
end

function raw_stage(spinrows,localrows,seed,stage,nu,nd,cap)
    matches(r)=integer(r,"seed")==seed && integer(r,"stage")==stage
    sr=filter(matches,spinrows);lr=filter(matches,localrows)
    length(sr)==144 && length(lr)==12 || return nothing
    all(integer(r,"Nup")==nu && integer(r,"Ndown")==nd && integer(r,"cap")==cap for r in vcat(sr,lr)) || return nothing
    C=fill(NaN,12,12);Z=copy(C);density=fill(NaN,12);doubles=copy(density)
    nup=copy(density);ndown=copy(density);spinz=copy(density)
    seen=Set{Tuple{Int,Int}}();local_seen=Set{Int}()
    for r in sr
        p=integer(r,"p");q=integer(r,"q")
        p isa Int && q isa Int && 1<=p<=12 && 1<=q<=12 || return nothing
        (p,q) in seen && return nothing;push!(seen,(p,q))
        c=number(r,"spin_dot");z=number(r,"SzSz")
        finite(c) && finite(z) || return nothing
        C[p,q]=c;Z[p,q]=z
    end
    for r in lr
        p=integer(r,"mode")
        p isa Int && 1<=p<=12 || return nothing
        p in local_seen && return nothing;push!(local_seen,p)
        values=[number(r,k) for k in ("density","double_occupancy","Nup_local","Ndown_local","Sz_local")]
        all(finite,values) || return nothing
        density[p],doubles[p],nup[p],ndown[p],spinz[p]=values
    end
    (;C,Z,density,doubles,nup,ndown,spinz)
end

function pair_agreement(a,b,ca,cb)
    de=abs(a["energy"]-b["energy"]);dc=maximum(abs,ca-cb);ds=abs(a["S2"]-b["S2"])
    (;energy=de,spin_matrix=dc,S2=ds,passed=bounded(de,0,2ENERGY_ATOL) &&
        bounded(dc,0,2SPIN_ATOL) && bounded(ds,0,2SPIN_ATOL))
end

function dmrg_rows(dmrg_dir,nu,nd,reference,warnings;reference_usable=false,reference_sha256=nothing)
    name="N$(nu+nd)_up$(nu)_down$(nd)";dir=joinpath(dmrg_dir,name)
    toml(name)=isfile(joinpath(dir,name)) ? TOML.parsefile(joinpath(dir,name)) : Dict{String,Any}()
    summary=toml("summary.toml");metadata=toml("metadata.toml")
    stages=read_csv(joinpath(dir,"stages.csv"));spins=read_csv(joinpath(dir,"spin_matrices.csv"))
    locals=read_csv(joinpath(dir,"local_observables.csv"));records=Dict{String,Any}[];probes=Dict{String,Any}[]
    if isempty(stages)
        push!(records,summary_row(name=name,method="DMRG",Lx=3,Ly=2,N=nu+nd,Nup=nu,Ndown=nd,Sz=(nu-nd)/2,
            status="UNRESOLVED_NO_STAGES",reason="DMRG was skipped, is unfinished, or its output is unavailable"))
        return records,probes
    end
    sector_issues=String[]
    get(summary,"status","")=="PASS" || push!(sector_issues,"Runner sector verdict is not PASS")
    all(get(summary,k,nothing)==v for (k,v) in (("N",nu+nd),("Nup",nu),("Ndown",nd),
        ("physical_Sz",(nu-nd)/2),("completed_arms",2),("completed_stages",10))) ||
        push!(sector_issues,"Summary sector identity or completion counts differ")
    truth(get(summary,"initialization_agreement_pass",false)) || push!(sector_issues,"Runner two-start agreement is unavailable or failed")
    reference_usable && reference_identity(reference,nu,nd) && hasproperty(reference,:accepted) && reference.accepted ||
        push!(sector_issues,"Accepted matching ED reference is unavailable")
    reference_sha256 isa String && get(metadata,"reference_sha256",nothing)==reference_sha256 ||
        push!(sector_issues,"DMRG reference hash missing or differs from the compared ED artifact")
    get(metadata,"seeds",nothing)==collect(DMRG_SEEDS) && get(metadata,"caps",nothing)==collect(DMRG_CAPS[1:4]) ||
        push!(sector_issues,"Registered DMRG seeds or caps differ")
    all(get(metadata,k,nothing)==v for (k,v) in (("energy_tolerance",ENERGY_ATOL),
        ("variance_tolerance",VARIANCE_ATOL),("spin_entry_tolerance",SPIN_ATOL),("particle_Sz_tolerance",NUMBER_ATOL))) ||
        push!(sector_issues,"Registered numerical tolerances missing or differ")
    expected=Set((seed,stage) for seed in DMRG_SEEDS for stage in 1:5)
    keys=[(integer(s,"seed"),integer(s,"stage")) for s in stages]
    length(keys)==10 && Set(keys)==expected || push!(sector_issues,"Exactly one of all ten registered stages is required")
    all(begin
        stage=integer(s,"stage")
        stage isa Int && 1<=stage<=5 && integer(s,"cap")==DMRG_CAPS[stage] &&
        integer(s,"N")==nu+nd && integer(s,"Nup")==nu && integer(s,"Ndown")==nd &&
        isequal(number(s,"Sz"),(nu-nd)/2)
    end for s in stages) || push!(sector_issues,"Stage sector identity or cap differs")
    raw_finals=Dict{Int,Any}()
    for s in stages
        seed=integer(s,"seed");stage=integer(s,"stage");cap=integer(s,"cap");final=stage==5
        r=summary_row(name=name,method="DMRG",Lx=3,Ly=2,N=nu+nd,Nup=nu,Ndown=nd,Sz=(nu-nd)/2,
            status=final ? "UNRESOLVED_FINAL" : "INTERMEDIATE_STAGE")
        r["seed"]=something(seed,missing);r["stage"]=something(stage,missing);r["cap"]=something(cap,missing)
        for key in ("energy","energy_error","variance","fock_variance","spin_matrix_error","spin_squared_error","fidelity",
                    "particle_error","sz_error","energy_action_error","sector_leakage")
            r[key]=number(s,key)
        end
        r["reported_stage_pass"]=truth(get(s,"passed",false));r["reported_sector_status"]=get(summary,"status","MISSING")
        issues=String[]
        r["reported_stage_pass"] || push!(issues,"Runner stage verdict is not PASS")
        raw=seed isa Int && stage isa Int && cap isa Int ? raw_stage(spins,locals,seed,stage,nu,nd,cap) : nothing
        r["raw_comparison_gates_pass"]=false
        if raw===nothing
            push!(issues,"Incomplete, inconsistent, or nonfinite raw spin/local tables")
        else
            data,qp=matrix_quantities(raw.C,raw.Z,raw.density,raw.doubles;Lx=3,Ly=2);merge!(r,data)
            discrepancy(a,b)=finite(a) && finite(b) ? abs(a-b) : Inf
            r["S2_summary_discrepancy"]=discrepancy(r["S2"],number(s,"total_spin_squared"))
            r["Sodd_summary_discrepancy"]=discrepancy(r["Sodd_q0_scalar"],number(s,"S_odd_scalar"))
            r["particle_error_recomputed"]=max(abs(sum(raw.nup)-nu),abs(sum(raw.ndown)-nd))
            r["sz_error_recomputed"]=abs(sum(raw.spinz)-(nu-nd)/2)
            r["local_table_consistency_error"]=max(maximum(abs,raw.density-raw.nup-raw.ndown),
                maximum(abs,raw.spinz-(raw.nup-raw.ndown)/2))
            local_bounds=all(-NUMBER_ATOL<=x<=1+NUMBER_ATOL for x in vcat(raw.nup,raw.ndown)) &&
                all(-NUMBER_ATOL<=raw.doubles[p]<=min(raw.nup[p],raw.ndown[p])+NUMBER_ATOL for p in 1:12)
            if reference!==nothing && hasproperty(reference,:ground_energy) && hasproperty(reference,:spin_dot)
                r["energy_error_recomputed"]=discrepancy(r["energy"],reference.ground_energy)
                r["spin_matrix_error_recomputed"]=maximum(abs,raw.C-reference.spin_dot)
                r["spin_squared_error_recomputed"]=abs(r["S2"]-sum(reference.spin_dot))
                r["raw_comparison_gates_pass"]=bounded(r["energy_error_recomputed"],0,ENERGY_ATOL) &&
                    bounded(r["spin_matrix_error_recomputed"],0,SPIN_ATOL) && bounded(r["spin_squared_error_recomputed"],0,SPIN_ATOL) &&
                    bounded(r["particle_error_recomputed"],0,NUMBER_ATOL) && bounded(r["sz_error_recomputed"],0,NUMBER_ATOL) &&
                    bounded(r["contact_error"],0,SPIN_ATOL) && bounded(r["local_table_consistency_error"],0,NUMBER_ATOL) && local_bounds &&
                    bounded(r["S2_summary_discrepancy"],0,SUMMARY_ATOL) && bounded(r["Sodd_summary_discrepancy"],0,SUMMARY_ATOL)
            end
            final && seed isa Int && (raw_finals[seed]=raw)
            for q in qp
                merge!(q,Dict("name"=>name,"method"=>"DMRG","seed"=>seed,"stage"=>stage));push!(probes,q)
            end
        end
        r["raw_comparison_gates_pass"] || push!(issues,"Recomputed energy, spin, number, or table-consistency gates failed")
        # These stored numbers are threshold-checked, not independently recomputed from an MPS.
        r["solver_reported_numeric_gates_pass"]=bounded(r["variance"],-VARIANCE_ATOL,VARIANCE_ATOL) &&
            bounded(r["fock_variance"],0,VARIANCE_ATOL) && bounded(r["energy_action_error"],0,ENERGY_ATOL) &&
            bounded(r["sector_leakage"],0,NUMBER_ATOL) && bounded(r["energy_error"],0,ENERGY_ATOL) &&
            bounded(r["spin_matrix_error"],0,SPIN_ATOL) && bounded(r["spin_squared_error"],0,SPIN_ATOL) &&
            bounded(r["particle_error"],0,NUMBER_ATOL) && bounded(r["sz_error"],0,NUMBER_ATOL)
        r["solver_reported_numeric_gates_pass"] || push!(issues,"Stored numerical diagnostics fail finite-value, sign, or tolerance checks")
        r["postprocessing_stage_gates_pass"]=isempty(issues);r["reason"]=join(issues,"; ")
        push!(records,r)
    end
    finals=filter(r->isequal(get(r,"stage",missing),5),records)
    complete_pair=length(finals)==2 && Set(r["seed"] for r in finals)==Set(DMRG_SEEDS) && all(haskey(raw_finals,s) for s in DMRG_SEEDS)
    agreement_pass=false
    if complete_pair
        a,b=finals
        # Missing/nonfinite energy or S2 must leave the pair unresolved instead of propagating missing.
        if all(finite(get(r,k,missing)) for r in finals for k in ("energy","S2"))
            agreement=pair_agreement(a,b,raw_finals[a["seed"]].C,raw_finals[b["seed"]].C)
            agreement_pass=agreement.passed
            for r in finals
                r["between_start_energy_error"]=agreement.energy;r["between_start_spin_matrix_error"]=agreement.spin_matrix
                r["between_start_S2_error"]=agreement.S2
            end
        end
    end
    complete_pair || push!(sector_issues,"Complete unique registered final seed pair unavailable")
    agreement_pass || push!(sector_issues,"Recomputed two-start agreement unavailable or failed")
    all(r["postprocessing_stage_gates_pass"] for r in finals) || push!(sector_issues,"At least one final arm fails postprocessing gates")
    for r in finals
        r["registered_pair_gates_pass"]=isempty(sector_issues)
        r["usable"]=isempty(sector_issues) && r["postprocessing_stage_gates_pass"]
        r["status"]=r["usable"] ? "VALIDATED_DMRG_FINAL" : "UNRESOLVED_FINAL"
        r["ground_spin"]=r["usable"] ? join(reference.total_spin,";") : missing
        r["reason"]=join(filter(!isempty,[r["reason"];sector_issues]),"; ")
        r["usable"] || push!(warnings,"$name seed$(r["seed"]): "*r["reason"])
    end
    for q in probes
        rr=filter(r->isequal(r["seed"],q["seed"]) && isequal(r["stage"],q["stage"]),records)
        q["status"]=length(rr)==1 ? only(rr)["status"] : "UNRESOLVED_DUPLICATE_STAGE"
    end
    records,probes
end

function threshold_rows(edrows,refs)
    output=Dict{String,Any}[]
    for N in (8,9)
        pair=filter(r->r["N"]==N,edrows);sort!(pair;by=r->r["Sz"])
        r=Dict{String,Any}("N"=>N,"status"=>"UNRESOLVED","interpretation"=>"Both accepted sector references are required")
        if length(pair)==2 && all(x->x["usable"],pair)
            a,b=pair;r["minimum_Sz"]=a["Sz"];r["next_Sz"]=b["Sz"]
            r["energy_threshold"]=b["energy"]-a["energy"]
            sa=only(refs[a["name"]].total_spin);sb=only(refs[b["name"]].total_spin)
            r["minimum_sector_S"]=sa;r["next_sector_S"]=sb;r["status"]="RESOLVED_SECTOR_THRESHOLD"
            r["interpretation"]=sa==sb && abs(r["energy_threshold"])<=1e-8 ?
                "Consistent with members of the same total-spin multiplet" : sa==0 && sb==1 ?
                "Resolved S=0 to S=1 sector-ground threshold" : sa==.5 && sb==1.5 ?
                "Resolved S=1/2 to S=3/2 sector-ground threshold" : "Resolved sector floors with S=$(sa) and S=$(sb); not an assumed singlet-triplet gap"
            if r["energy_threshold"] < -2e-8 || (sa>=b["Sz"] && abs(r["energy_threshold"])>2e-8)
                r["status"]="INCONSISTENT_SECTOR_FLOORS"
                r["interpretation"]="Candidate floors violate the minimum-|Sz| or same-multiplet consistency; ground assignment unresolved"
            end
        end
        push!(output,r)
    end
    output
end

function size_rows(old,edrows)
    byN=Dict(r["N"]=>r for r in edrows if r["Sz"]==(isodd(r["N"]) ? .5 : 0.))
    output=Dict{String,Any}[]
    for(label,a,b,limit) in (("same_density_size",old,get(byN,9,nothing),"Density1.5 fixed; N parity, aspect ratio and size change"),
        ("six_cell_density",get(byN,8,nothing),get(byN,9,nothing),"Six-cell geometry fixed; density changes4/3→1.5 and parity changes"))
        r=Dict{String,Any}("comparison"=>label,"status"=>"UNRESOLVED","limitation"=>limit)
        if a!==nothing && b!==nothing && a["usable"] && b["usable"]
            r["status"]="AVAILABLE_FINITE_CLUSTER_COMPARISON";r["from"]=a["name"];r["to"]=b["name"]
            for key in ("S2","orbital_A_squared","orbital_B_squared","interorbital_dot","Sodd_q0_scalar","Sodd_q0_order_proxy")
                r[key*"_from"]=a[key];r[key*"_to"]=b[key];r[key*"_difference"]=b[key]-a[key]
            end
        end
        push!(output,r)
    end
    output
end

function report(ed_dir,dmrg_dir,out;old_dir=OLD_DEFAULT)
    ispath(out) && error("Refusing existing report output: $out")
    warnings=String[];old=old_reference(old_dir);edrows=Dict{String,Any}[];dmrg=Dict{String,Any}[];probes=Dict{String,Any}[];refs=Dict{String,Any}()
    for(nu,nd) in SECTORS
        row,reference,qp=read_ed(ed_dir,nu,nd,warnings);push!(edrows,row);refs[row["name"]]=reference
        for q in qp;merge!(q,Dict("name"=>row["name"],"method"=>"ED","status"=>row["status"]));push!(probes,q);end
        dr,dq=dmrg_rows(dmrg_dir,nu,nd,reference,warnings;reference_usable=row["usable"],reference_sha256=get(row,"reference_sha256",nothing));append!(dmrg,dr);append!(probes,dq)
    end
    thresholds=threshold_rows(edrows,refs);comparisons=size_rows(old,edrows)
    finals=filter(r->isequal(get(r,"stage",5),5),dmrg);allrows=vcat([old],edrows,finals)
    mkpath(out)
    columns=["name","method","Lx","Ly","cells","N","density","Nup","Ndown","Sz","seed","stage","cap","status","usable","reason","energy","ground_spin","ground_degeneracy_observed","max_eigenpair_residual","S2","orbital_A_squared","orbital_B_squared","interorbital_dot","Sodd_q0_scalar","Sodd_q0_order_proxy","Seven_q0_scalar","Sodd_q0_z_raw","double_occupancy_total","particle_number_from_density","contact_error","energy_error","energy_error_recomputed","variance","fock_variance","spin_matrix_error","spin_matrix_error_recomputed","spin_squared_error","fidelity","S2_summary_discrepancy","Sodd_summary_discrepancy","reported_stage_pass","reported_sector_status","spin_squared_error_recomputed","particle_error_recomputed","sz_error_recomputed","local_table_consistency_error","particle_error","sz_error","energy_action_error","sector_leakage","raw_comparison_gates_pass","solver_reported_numeric_gates_pass","postprocessing_stage_gates_pass","registered_pair_gates_pass","between_start_energy_error","between_start_spin_matrix_error","between_start_S2_error"]
    write_csv(joinpath(out,"sector_comparison.csv"),allrows,columns)
    write_csv(joinpath(out,"dmrg_stage_diagnostics.csv"),dmrg,columns)
    write_csv(joinpath(out,"q_probes.csv"),probes,["name","method","seed","stage","status","qx","qy","even_scalar","odd_scalar","odd_order_proxy","even_z_raw","odd_z_raw"])
    write_csv(joinpath(out,"sector_thresholds.csv"),thresholds,["N","status","minimum_Sz","next_Sz","minimum_sector_S","next_sector_S","energy_threshold","interpretation"])
    comparison_columns=vcat(["comparison","status","from","to","limitation"],
        [k*s for k in ("S2","orbital_A_squared","orbital_B_squared","interorbital_dot","Sodd_q0_scalar","Sodd_q0_order_proxy") for s in ("_from","_to","_difference")])
    write_csv(joinpath(out,"size_density_comparisons.csv"),comparisons,comparison_columns)
    open(joinpath(out,"report.md"),"w") do io
        println(io,"# Open-cluster size bridge results\n")
        println(io,"This report reads completed artifacts and performs no target eigensolve. Accepted six-cell ED references are numerically supported candidate ground states; three roots and two starts do not prove exhaustive spectral coverage. Missing and inconclusive results remain unresolved.\n")
        println(io,"| Reference | Status | E | S | ⟨S²⟩ | ⟨SA²⟩ | ⟨SB²⟩ | ⟨SA·SB⟩ | Sodd(0) | Sodd(0)/Nc |")
        println(io,"|---|---|---:|---:|---:|---:|---:|---:|---:|---:|")
        for r in vcat([old],edrows)
            println(io,"| ",join([fmt(get(r,k,missing)) for k in ("name","status","energy","ground_spin","S2","orbital_A_squared","orbital_B_squared","interorbital_dot","Sodd_q0_scalar","Sodd_q0_order_proxy")]," | ")," |")
        end
        println(io,"\nSodd(q)=Σab ηaηb exp[iq·(ra−rb)]⟨Sa·Sb⟩/Nc uses all three spin components. The final column divides this structure factor by Nc again, giving a finite-size order proxy. Raw fixed-Sz z correlations are measured separately; they are not multiplied by3. The uniform even channel is ⟨S²⟩/Nc.\n")
        for c in comparisons
            println(io,"- ",c["comparison"],": ",c["status"],". ",c["limitation"],".")
            if c["status"]=="AVAILABLE_FINITE_CLUSTER_COMPARISON"
                println(io,"  Sodd(0): ",fmt(c["Sodd_q0_scalar_from"])," → ",fmt(c["Sodd_q0_scalar_to"]),
                    "; Sodd(0)/Nc: ",fmt(c["Sodd_q0_order_proxy_from"])," → ",fmt(c["Sodd_q0_order_proxy_to"]),".")
            end
        end
        println(io,"\nOdd N=9 cannot be a singlet. Its finite total spin contributes to the uniform even channel. The3×2 rectangle permits unequal orbital moments and unequal rotated probes. Two geometries cannot establish long-range order, and these densities do not test the narrow HF coexistence interval or establish phase separation or metallicity.\n")
        for t in thresholds
            println(io,"- N=",t["N"],": ",t["status"],"; ΔE=",fmt(get(t,"energy_threshold",missing)),". ",t["interpretation"],".")
        end
        println(io,"\nDMRG final arms available and usable: ",count(r->r["usable"],finals),"/8. Intermediate or failed arms are retained in dmrg_stage_diagnostics.csv. Raw scalar matrices and local tables independently supply spin, number, contact, and two-start comparison gates; energy differences are recomputed from recorded energies. Stored variance, MPO/Fock energy agreement, and leakage diagnostics are checked for finite values and registered bounds but remain solver-reported quantities. Validation requires both registered final starts and matching sector/reference provenance. This postprocessing does not independently reconstruct an MPS, MPO energy, or variance.\n")
        for w in warnings;println(io,"- Unresolved: ",w);end
    end
    inputs=Dict{String,String}("source"=>sha(@__FILE__))
    for(path,_,files) in (isdir(ed_dir) ? walkdir(ed_dir) : [])
        for f in files
            f in ("reference.jls","reference.toml","summary.toml") && (inputs[abspath(joinpath(path,f))]=sha(joinpath(path,f)))
        end
    end
    for(path,_,files) in (isdir(dmrg_dir) ? walkdir(dmrg_dir) : [])
        for f in files
            f in ("summary.toml","metadata.toml","stages.csv","spin_matrices.csv","local_observables.csv") && (inputs[abspath(joinpath(path,f))]=sha(joinpath(path,f)))
        end
    end
    isfile(joinpath(old_dir,"summary.csv")) && (inputs[abspath(joinpath(old_dir,"summary.csv"))]=sha(joinpath(old_dir,"summary.csv")))
    metadata=Dict("created_utc"=>string(now(UTC)),"ED_directory"=>abspath(ed_dir),"DMRG_directory"=>abspath(dmrg_dir),
        "accepted_ED_sectors"=>count(r->r["usable"],edrows),"usable_DMRG_final_arms"=>count(r->r["usable"],finals),
        "missing_values"=>"Blank CSV fields and explicit unresolved status; never replaced with zero",
        "inputs_sha256"=>inputs,"warnings"=>warnings)
    open(io->TOML.print(io,metadata),joinpath(out,"metadata.toml"),"w")
    println("Report saved: ",abspath(out));metadata
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    length(ARGS) in (4,5) && ARGS[1]=="--report" || error("Usage: --report ED_DIR DMRG_DIR OUTPUT_DIR [OLD_ED_DIR]")
    ALMSizeBridgeReport20260911.report(ARGS[2],ARGS[3],ARGS[4];old_dir=length(ARGS)==5 ? ARGS[5] : ALMSizeBridgeReport20260911.OLD_DEFAULT)
end
