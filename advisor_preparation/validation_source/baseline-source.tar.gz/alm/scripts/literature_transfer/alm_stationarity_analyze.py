#!/usr/bin/env python3
"""Prospectively fixed late-window analysis; no third-party dependencies."""
from __future__ import annotations
import argparse, csv, hashlib, json, math, statistics as stats
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'results/literature_transfer/alm_stationarity_20260911'
SEEDS=(116371,127493,138611,149729)
EXACT=BASE/'exact/exact_schedule_controls.csv'
BLOCKS=(5,10,20,40,80)
GROUND={'E':-19.64329885052183,'S_alm':1.183248801940442,'Delta':0.0}
TOL={'E':.02,'S_alm':.05*GROUND['S_alm'],'Delta':.05}
COL={'E':'exact_mixed_energy','bp_E':'exact_BP_energy','S_alm':'exact_BP_S_odd_q0','Delta':'exact_BP_Delta'}
QUANTITIES=('E','bp_E','S_alm','Delta','S_scalar','Stot2','mixed_scalar','mixed_z','mixed_Stot2','scalar_minus_z')
WINDOWS={'all':(0,640),'window1':(0,160),'window2':(160,320),'window3':(320,480),'window4':(480,640),'primary':(320,640)}
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read_csv(path):
    with Path(path).open(newline='') as f: return list(csv.DictReader(f))
def kv(path): return dict(line.split('=',1) for line in Path(path).read_text().splitlines() if '=' in line)
def write_csv(path,rows):
    with path.open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
def scan(values):
    if not values or any(not math.isfinite(v) for v in values): raise ValueError('Empty or nonfinite series')
    errors={}
    for n in BLOCKS:
        if len(values)%n==0 and len(values)//n>=4:
            means=[stats.mean(values[i:i+n]) for i in range(0,len(values),n)]
            errors[n]=stats.stdev(means)/math.sqrt(len(means))
    if not errors: raise ValueError('Fewer than four complete blocks')
    return {'mean':stats.mean(values),'standard_error':max(errors.values()),'block_errors':errors,'samples':len(values)}
def pool(rows):
    if len(rows)!=4: raise ValueError('Exactly four independent chains are required')
    means=[r['mean'] for r in rows]; errors=[r['standard_error'] for r in rows]
    within=math.sqrt(sum(x*x for x in errors))/4; between=stats.stdev(means)/2
    return {'mean':stats.mean(means),'standard_error':max(within,between),'within_seed_se':within,'between_seed_se':between}
def classify(primary,stationary):
    gates={q:abs(primary[q]['mean']-GROUND[q])+3*primary[q]['standard_error']<=TOL[q] for q in GROUND}
    outside={q:abs(primary[q]['mean']-GROUND[q])-3*primary[q]['standard_error']>TOL[q] for q in ('S_alm','Delta')}
    if stationary and all(gates.values()): outcome='PASS_WITH_STATIONARITY_SCREEN'
    elif stationary and any(outside.values()): outcome='RESOLVED_MAGNETIC_DISCREPANCY'
    else: outcome='INCONCLUSIVE'
    return outcome,gates,outside

def validate_chain(directory,expected_seed,exact):
    meta=kv(directory/'metadata.txt'); completion=kv(directory/'completion.txt')
    if not (directory/'status.txt').read_text().startswith('COMPLETED'): raise ValueError(f'Incomplete chain {directory}')
    if meta.get('scientific')!='true' or int(meta['seed'])!=expected_seed: raise ValueError('Seed/scientific metadata mismatch')
    required={'dtau':.01,'walker_count':128,'warmup_steps':6400,'measurement_count':640,
              'steps_between_measurements':10,'back_propagation_steps':400,'orthogonalize_every':10,
              'population_control_every':10,'overlap_refresh_every':16,'minimum_backprop_ancestors':2}
    if any(float(meta[k])!=v for k,v in required.items()): raise ValueError('Unregistered chain settings')
    if meta.get('trial')!='full_singlet_AM3_20terms' or meta.get('mirror')!='enabled' or meta.get('initialization')!='exact_weighted':
        raise ValueError('Trial, mirror, or initialization mismatch')
    if int(completion['accepted_measurements'])!=640 or int(completion['planned_measurements'])!=640: raise ValueError('Count mismatch')
    sources=read_csv(directory/'source_hashes.csv'); names=[]
    for source in sources:
        path=Path(source['path']); snapshot=directory/'source_snapshot'/source['snapshot']
        if sha(path)!=source['sha256'] or sha(snapshot)!=source['sha256']: raise ValueError(f'Changed source {path}')
        names.append(path.name)
    needed={'alm_stationarity_run.jl','alm_stationarity_analyze.py','alm_stationarity_exact.jl',
            'alm_stationarity_plan_20260911.md','multislater_cp_mirror_validated.jl','multislater_cp_mirror_observables.jl'}
    if not needed.issubset(names): raise ValueError('Missing required provenance sources')
    expected_hashes={'multislater_cp_mirror_validated.jl':'fc482e6298d7aea8fdcb9b8290b09dadd7788c1e87d093c6d549db4a015f788a',
        'multislater_cp_mirror_observables.jl':'53e05ebdff61d0017ba04603e427e388944a64c79021d3f44d76dae87f313b88',
        'multislater_cp.jl':'c78623f8f11e633c0904ec8e6089e861b4c6c7a36e3d612efa1df8f1a6f5601e',
        'full_singlet_am3_20_terms.jls':'193d88a4ec49063ec202a8aee30165b18668bbe28a2a5fef1fb959a83fa85f3c'}
    for name,digest in expected_hashes.items():
        entries=[s['sha256'] for s in sources if Path(s['path']).name==name]
        if entries!=[digest]: raise ValueError(f'Frozen source mismatch {name}')
    # The legacy short exact table is also snapshotted; require this new table specifically.
    if not any(Path(s['path']).resolve()==EXACT.resolve() and s['sha256']==sha(EXACT) for s in sources):
        raise ValueError('New same-time exact table was not a frozen run input')
    rows=read_csv(directory/'samples.csv')
    if len(rows)!=640: raise ValueError('Missing raw rows')
    for i,r in enumerate(rows,1):
        if int(r['sample_index'])!=i or int(r['step'])!=6400+10*i or abs(float(r['beta'])-(64+.1*i))>1e-10:
            raise ValueError('Sample grid mismatch')
        if r['status']!='valid': raise ValueError('Invalid raw status')
        # Some event counters intentionally retain sentinel infinities if no event occurred.
        for q in QUANTITIES+('bp_V','bp_D','effective_population','ancestors'):
            if not math.isfinite(float(r[q])): raise ValueError(f'Nonfinite {q}')
        if abs(float(r['bp_V'])-12*(4*float(r['bp_D'])-1))>=2e-8: raise ValueError('Centered-U identity failed')
        if round(float(r['beta']),10) not in exact: raise ValueError('Missing matching exact row')
    return rows,{'seed':expected_seed,'directory':str(directory),'raw_sha256':sha(directory/'samples.csv'),
                 'resume_parent':meta['resume_parent'],'resumed_prefix_count':int(meta['resumed_prefix_count'])}

def exact_rows():
    rows=read_csv(EXACT)
    if len(rows)!=640: raise ValueError('Exact grid must have 640 rows')
    for i,r in enumerate(rows,1):
        if float(r['dtau'])!=.01 or float(r['bp_lag'])!=4 or float(r['warmup'])!=64 or abs(float(r['beta'])-(64+.1*i))>1e-10:
            raise ValueError('Exact schedule mismatch')
        if r['label']!='full_singlet_AM3_20det' or r['initial_ket']!='same_full_singlet': raise ValueError('Exact trial mismatch')
    return {round(float(r['beta']),10):r for r in rows}

def analyze(chains,out):
    if out.exists(): raise FileExistsError(f'Refusing analysis overwrite {out}')
    if len(chains)!=4 or len(set(p.resolve() for p in chains))!=4: raise ValueError('Four distinct chain directories required')
    exact=exact_rows(); by_seed={}; provenance=[]
    for d in chains:
        seed=int(kv(d/'metadata.txt')['seed'])
        if seed not in SEEDS or seed in by_seed: raise ValueError('Missing, repeated, or unregistered seed')
        by_seed[seed],p=validate_chain(d,seed,exact); provenance.append(p)
    stats_by_key={}; detail=[]; blocks=[]; exact_differences=[]
    for seed,rows in by_seed.items():
        for window,(a,b) in WINDOWS.items():
            selected=rows[a:b]
            for q in QUANTITIES:
                s=scan([float(r[q]) for r in selected]); stats_by_key[seed,window,q]=s
                detail.append(dict(seed=seed,window=window,quantity=q,mean=s['mean'],standard_error=s['standard_error'],samples=s['samples']))
                blocks.extend(dict(seed=seed,window=window,quantity=q,block_size=n,standard_error=se) for n,se in s['block_errors'].items())
                if q in COL:
                    ref=stats.mean(float(exact[round(float(r['beta']),10)][COL[q]]) for r in selected)
                    exact_differences.append(dict(seed=seed,window=window,quantity=q,mean=s['mean'],standard_error=s['standard_error'],exact_discrete_mean=ref,difference=s['mean']-ref))
    pooled={}; pool_rows=[]
    for window in WINDOWS:
        for q in QUANTITIES:
            p=pool([stats_by_key[seed,window,q] for seed in SEEDS]); pooled[window,q]=p
            pool_rows.append(dict(window=window,quantity=q,**p))
    drift_rows=[]; screens={}
    for q in GROUND:
        d=[]
        for seed in SEEDS:
            a=stats_by_key[seed,'window3',q]; b=stats_by_key[seed,'window4',q]
            d.append({'mean':b['mean']-a['mean'],'standard_error':a['standard_error']+b['standard_error']})
        drift=pool(d); drift_budget=abs(drift['mean'])+3*drift['standard_error']
        errors={n:math.sqrt(sum(stats_by_key[seed,'primary',q]['block_errors'][n]**2 for seed in SEEDS))/4 for n in (40,80)}
        ratio=errors[80]/errors[40] if errors[40] else (1. if errors[80]==0 else math.inf)
        p=pooled['primary',q]
        heterogeneous=any(abs(stats_by_key[seed,'primary',q]['mean']-p['mean'])>3*math.hypot(stats_by_key[seed,'primary',q]['standard_error'],p['standard_error']) for seed in SEEDS)
        screens[q]={'drift_bound_pass':drift_budget<=TOL[q],'drift_budget':drift_budget,
                    'block_plateau_pass':2/3<=ratio<=1.5,'block80_to_block40_se_ratio':ratio if math.isfinite(ratio) else None,
                    'seed_consistency_pass':not heterogeneous,'tolerance':TOL[q]}
        drift_rows.append(dict(quantity=q,**drift,drift_budget=drift_budget,tolerance=TOL[q]))
    stationary=all(s['drift_bound_pass'] and s['block_plateau_pass'] and s['seed_consistency_pass'] for s in screens.values())
    primary={q:pooled['primary',q] for q in GROUND}; outcome,gates,outside=classify(primary,stationary)
    summary={'outcome':outcome,'stationarity_screen_pass':stationary,'accuracy_gates':gates,'resolved_outside_magnetic_band':outside,
        'primary':primary,'stationarity_screens':screens,'planned_chains':4,'retained_chains':4,'planned_samples':2560,'retained_samples':2560,
        'primary_samples':1280,'primary_beta_window':[96.1,128.0],'exact_sha256':sha(EXACT),'provenance':provenance,
        'limitation':'Finite-sample screening uncertainties and stationarity diagnostics; no proof of asymptotic coverage, zero constraint bias, or ALM phase stability.'}
    out.mkdir(parents=True)
    for name,rows in [('seed_windows.csv',detail),('block_scan.csv',blocks),('pooled_windows.csv',pool_rows),('same_time_exact.csv',exact_differences),('late_window_drifts.csv',drift_rows)]: write_csv(out/name,rows)
    (out/'scientific_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    lines=['# Bounded ALM solver stationarity result','',f'**{outcome}**','',
        'Primary estimate: four fresh independent seed chains, final 320 rows per chain (beta 96.1–128.0).',
        'All earlier windows and same-time exact controls are retained in the companion CSV files.','',
        '| Quantity | Mean | Screening SE | Exact ground | Original gate |','|---|---:|---:|---:|---|']
    for q,p in primary.items(): lines.append(f"| {q} | {p['mean']:.9g} | {p['standard_error']:.6g} | {GROUND[q]:.12g} | {'PASS' if gates[q] else 'FAIL'} |")
    lines+=['',f'Prospective stationarity screens: {stationary}.',summary['limitation'],
        'A pass only licenses a separately registered population/BP-lag convergence test. A discrepancy does not identify its mechanism. An inconclusive result does not establish absence of altermagnetism.','']
    (out/'report.md').write_text('\n'.join(lines)); print(json.dumps(summary,indent=2)); return summary

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('attempt',nargs='?',default='initial_remote'); parser.add_argument('--chains',nargs=4,type=Path)
    parser.add_argument('--out',type=Path); args=parser.parse_args()
    if not args.attempt.replace('_','').replace('-','').isalnum(): raise ValueError('Unsafe attempt')
    chains=args.chains or [BASE/'chains'/f'stationarity_dt01_seed{s}_{args.attempt}' for s in SEEDS]
    out=args.out or BASE/'analysis'/args.attempt
    try: analyze(chains,out)
    except Exception as error:
        # Validation/incomplete prefixes yield an explicit bounded outcome, never an apparent scientific pass.
        if not out.exists():
            out.mkdir(parents=True); (out/'incomplete_summary.json').write_text(json.dumps({'outcome':'INCONCLUSIVE','reason':str(error)},indent=2)+'\n')
        raise
if __name__=='__main__': main()
