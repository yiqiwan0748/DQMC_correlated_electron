#!/usr/bin/env python3
"""Check decision boundaries and correlated-error logic using synthetic data."""
import importlib.util, math, unittest, tempfile, shutil, contextlib, io
from pathlib import Path
spec=importlib.util.spec_from_file_location('analysis',Path(__file__).with_name('alm_stationarity_analyze.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
class AnalysisTests(unittest.TestCase):
    def test_block_scan_accounts_for_persistent_runs(self):
        values=[float((i//80)%2) for i in range(320)]
        s=a.scan(values)
        self.assertGreater(s['block_errors'][80],s['block_errors'][5])
        self.assertEqual(s['standard_error'],max(s['block_errors'].values()))
        self.assertEqual(set(s['block_errors']),set(a.BLOCKS))
        self.assertEqual(set(a.scan(values[:160])['block_errors']),{5,10,20,40})
    def test_between_seed_floor(self):
        p=a.pool([{'mean':m,'standard_error':0.} for m in (0.,1.,2.,3.)])
        self.assertEqual(p['standard_error'],p['between_seed_se'])
        self.assertGreater(p['standard_error'],0)
        with self.assertRaises(ValueError):a.pool([{'mean':0.,'standard_error':1.}]*3)
    def test_decisions_require_stationarity_and_bounded_error(self):
        p={q:{'mean':x,'standard_error':a.TOL[q]/20} for q,x in a.GROUND.items()}
        self.assertEqual(a.classify(p,True)[0],'PASS_WITH_STATIONARITY_SCREEN')
        self.assertEqual(a.classify(p,False)[0],'INCONCLUSIVE')
        p['S_alm']['mean']+=2*a.TOL['S_alm']
        self.assertEqual(a.classify(p,True)[0],'RESOLVED_MAGNETIC_DISCREPANCY')
        self.assertEqual(a.classify(p,False)[0],'INCONCLUSIVE')
        p['S_alm']['standard_error']=a.TOL['S_alm']
        self.assertEqual(a.classify(p,True)[0],'INCONCLUSIVE')
    def test_accuracy_boundary(self):
        p={q:{'mean':x,'standard_error':0.} for q,x in a.GROUND.items()}
        p['Delta']={'mean':.02,'standard_error':.01}
        self.assertTrue(a.classify(p,True)[1]['Delta'])
        p['Delta']['standard_error']=.0101
        self.assertFalse(a.classify(p,True)[1]['Delta'])
        self.assertFalse(a.classify(p,True)[2]['Delta'])
    def test_nonfinite_and_undersampled_are_rejected(self):
        with self.assertRaises(ValueError):a.scan([float('nan')]*320)
        with self.assertRaises(ValueError):a.scan([0.]*10)
    def test_complete_synthetic_campaign_and_rejection_paths(self):
        # Constant synthetic controls exercise file validation and decision wiring;
        # these fixtures are explicitly not stochastic physics evidence.
        with tempfile.TemporaryDirectory(prefix='alm_stationarity_analysis_') as temp:
            base=Path(temp); exact=base/'exact.csv'; old_exact=a.EXACT; a.EXACT=exact
            try:
                exact_rows=[]
                for i in range(1,641):
                    r={'dtau':.01,'bp_lag':4,'warmup':64,'beta':64+.1*i,
                       'label':'full_singlet_AM3_20det','initial_ket':'same_full_singlet'}
                    r.update({col:a.GROUND.get(q,a.GROUND['E']) for q,col in a.COL.items()});exact_rows.append(r)
                a.write_csv(exact,exact_rows)
                files=[a.ROOT/'scripts/literature_transfer'/name for name in ('alm_stationarity_run.jl','alm_stationarity_analyze.py','alm_stationarity_exact.jl','multislater_cp.jl')]
                files += [a.ROOT/'docs/reading/alm_stationarity_plan_20260911.md',a.ROOT/'results/literature_transfer/trial_symmetry_projection/full_singlet_am3_20_terms.jls',exact]
                for name in ('multislater_cp_mirror_validated.jl','multislater_cp_mirror_observables.jl'):
                    path=a.ROOT/'scripts/literature_transfer'/name
                    if not path.is_file():path=a.ROOT/'results/remote_mirror_return/20260911/scripts/literature_transfer'/name
                    files.append(path)
                chains=[]
                for seed in a.SEEDS:
                    d=base/str(seed); (d/'source_snapshot').mkdir(parents=True);chains.append(d)
                    source_rows=[]
                    for index,path in enumerate(files):
                        name=f'{index}_{path.name}';shutil.copyfile(path,d/'source_snapshot'/name)
                        source_rows.append({'path':str(path),'sha256':a.sha(path),'snapshot':name})
                    a.write_csv(d/'source_hashes.csv',source_rows)
                    metadata={'scientific':'true','seed':seed,'dtau':.01,'walker_count':128,'warmup_steps':6400,
                              'measurement_count':640,'steps_between_measurements':10,'back_propagation_steps':400,
                              'orthogonalize_every':10,'population_control_every':10,'overlap_refresh_every':16,
                              'minimum_backprop_ancestors':2,'trial':'full_singlet_AM3_20terms','mirror':'enabled',
                              'initialization':'exact_weighted','resume_parent':'none','resumed_prefix_count':0}
                    (d/'metadata.txt').write_text('\n'.join(f'{k}={v}' for k,v in metadata.items()))
                    (d/'completion.txt').write_text('accepted_measurements=640\nplanned_measurements=640\n')
                    (d/'status.txt').write_text('COMPLETED synthetic fixture\n')
                    rows=[]
                    for i in range(1,641):
                        r={q:a.GROUND.get(q,0.) for q in a.QUANTITIES}
                        r.update(sample_index=i,step=6400+10*i,beta=64+.1*i,status='valid',bp_V=-12.,bp_D=0.,effective_population=128.,ancestors=128.)
                        rows.append(r)
                    a.write_csv(d/'samples.csv',rows)
                with contextlib.redirect_stdout(io.StringIO()):summary=a.analyze(chains,base/'analysis')
                self.assertEqual(summary['outcome'],'PASS_WITH_STATIONARITY_SCREEN')
                self.assertEqual(summary['primary_samples'],1280)
                self.assertEqual(len(a.read_csv(base/'analysis'/'same_time_exact.csv')),4*6*4)
                with self.assertRaises(FileExistsError):a.analyze(chains,base/'analysis')
                with self.assertRaises(ValueError):a.analyze([chains[0]]*4,base/'duplicate')
                metadata_path=chains[0]/'metadata.txt'
                metadata_path.write_text(metadata_path.read_text().replace('warmup_steps=6400','warmup_steps=1600'))
                with self.assertRaises(ValueError):a.analyze(chains,base/'wrong_schedule')
            finally:a.EXACT=old_exact
if __name__=='__main__':unittest.main()
