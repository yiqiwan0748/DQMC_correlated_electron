#!/usr/bin/env julia
"""Separate exact finite-time controls for the registered beta=64.1–128 schedule."""
module ALMStationarityExact
using LinearAlgebra, Serialization, SHA, Printf, Test
include(joinpath(@__DIR__,"exact_multislater_projection.jl"))
const Ref = ExactMultislaterProjection
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const OUT=joinpath(ROOT,"results/literature_transfer/alm_stationarity_20260911/exact")
const BASE=joinpath(ROOT,"results/literature_transfer")
const CACHE=joinpath(BASE,"trial_symmetry_projection/u12_complete_spectrum.jls")
const TRIAL=joinpath(BASE,"trial_symmetry_projection/full_singlet_am3_20_terms.jls")
const OLD=joinpath(BASE,"exact_multislater_projection/exact_schedule_controls.csv")
const FROZEN=Dict(CACHE=>"02183fe70f620fb39d7ab0cc0bf3f80853a1e1344c63f1f39a7fa5da5c34789d",
    TRIAL=>"193d88a4ec49063ec202a8aee30165b18668bbe28a2a5fef1fb959a83fa85f3c",
    OLD=>"8877a68218c30062de7734036fc72ae1b6d56c7e665302c2c80d92368fa0862d",
    joinpath(@__DIR__,"exact_multislater_projection.jl")=>"715cafdc79b9e1023030d4355a47b4e95540fa25431a21bb292359caa7afc525")
sha(path)=bytes2hex(sha256(read(path)))
function main(;out=OUT)
    ispath(out) && error("Refusing existing exact-control directory: $out")
    all(sha(path)==hash for (path,hash) in FROZEN) || error("Frozen exact input changed")
    cache=deserialize(CACHE);K=Ref.ED.open_cluster_kinetic_matrix(2,2)
    op=Ref.ED.sector_hamiltonian(K,12.,3,3);occupied=Ref.occupations(op.basis.up_states)
    @test cache.K==K && cache.Nup==cache.Ndown==3 && cache.U==12.
    @test cache.up_states==op.basis.up_states && cache.down_states==op.basis.down_states
    exported=deserialize(TRIAL)
    trial=sum(t.coefficient*Ref.determinant_state(t.up,t.down,occupied) for t in exported.terms)
    @test abs(norm(trial)-exported.normalization)<2e-9
    trial./=norm(trial)
    @test norm(Ref.spin_raise(op.basis)*trial)<2e-9
    @test abs(cache.energies[1]+19.64329885052183)<2e-9
    discrete=Ref.projected_discrete(K,op,trial,occupied,.01;max_tick=1280)
    continuous=Ref.projected_continuous(cache.energies,cache.vectors,trial;max_tick=1280)
    # Compare the independently recomputed prefix against the old immutable table.
    lines=readlines(OLD);header=split(first(lines),',');old=Dict{Int,Dict{String,String}}()
    for line in lines[2:end]
        row=Dict(zip(header,split(line,',')))
        if parse(Float64,row["dtau"])==.01 && parse(Float64,row["warmup"])==16 && parse(Float64,row["bp_lag"])==4
            old[round(Int,10parse(Float64,row["beta"]))]=row
        end
    end
    @test length(old)==160
    residual=0.
    for tick in 161:320
        measured=Ref.measure(discrete,trial,op,op.oalm_values,tick,40)
        for (field,column) in ((:mixed,"exact_mixed_energy"),(:bpenergy,"exact_BP_energy"),
            (:spin,"exact_BP_S_odd_q0"),(:delta,"exact_BP_Delta"))
            residual=max(residual,abs(getproperty(measured,field)-parse(Float64,old[tick][column])))
        end
    end
    @test residual<2e-9
    rows=NamedTuple[]
    for tick in 641:1280
        d=Ref.measure(discrete,trial,op,op.oalm_values,tick,40)
        c=Ref.measure(continuous,trial,op,op.oalm_values,tick,40)
        @test abs(c.mixed-c.bpenergy)<2e-9
        push!(rows,Ref.row(.01,"same_full_singlet",64.,tick,40,d,c))
    end
    all(sha(path)==hash for (path,hash) in FROZEN) || error("Exact input changed during generation")
    mkpath(out)
    open(joinpath(out,"exact_schedule_controls.csv"),"w") do io
        println(io,join(string.(keys(first(rows))),','))
        for row in rows
            println(io,join((x isa AbstractFloat ? @sprintf("%.17g",x) : string(x) for x in values(row)),','))
        end
    end
    open(joinpath(out,"validation.txt"),"w") do io
        println(io,"PASSED; rows=640; dt=.01; beta=64.1..128; lag=4; warmup=64")
        println(io,"old_prefix_max_absolute_residual=",residual,"\ntolerance=2e-9")
        println(io,"julia_version=",VERSION)
    end
    open(joinpath(out,"source_hashes.csv"),"w") do io
        println(io,"path,sha256")
        for path in sort(vcat(collect(keys(FROZEN)),[@__FILE__,joinpath(ROOT,"docs/reading/alm_stationarity_plan_20260911.md")]))
            println(io,path,",",sha(path))
        end
    end
    println("Saved exact controls: ",out,"; prefix residual=",residual)
    rows
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    old=ALMStationarityExact.BLAS.get_num_threads();ALMStationarityExact.BLAS.set_num_threads(1)
    try;ALMStationarityExact.main();finally;ALMStationarityExact.BLAS.set_num_threads(old);end
end
