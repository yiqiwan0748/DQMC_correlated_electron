#!/usr/bin/env julia
"""Bounded, include-safe continuation using the unchanged validated mirror solver."""
module ALMStationarityRun
using LinearAlgebra, Serialization, SHA, Printf, Dates
const ROOT = normpath(joinpath(@__DIR__, "../.."))
# Local archived-return tests stage a complete dependency tree. Remote runs use ROOT.
const DEPENDENCY_ROOT = get(ENV, "ALM_STATIONARITY_DEPENDENCY_ROOT", ROOT)
include(joinpath(DEPENDENCY_ROOT, "scripts/literature_transfer/run_multislater_mirror_benchmark.jl"))
const Legacy = RunMultiSlaterMirrorBenchmark
const Mirror = Legacy.Mirror
const CP = Legacy.CP
const ED = Legacy.ED
const SEEDS = (116371,127493,138611,149729)
const PROFILE = (dt=0.01, walkers=128, warmup=64.0, lag=4.0, samples=640, cadence=10, scientific=true)
const OUT = joinpath(ROOT,"results/literature_transfer/alm_stationarity_20260911/chains")
const EXACT = joinpath(ROOT,"results/literature_transfer/alm_stationarity_20260911/exact/exact_schedule_controls.csv")
const PLAN = joinpath(ROOT,"docs/reading/alm_stationarity_plan_20260911.md")
const SOURCES = unique(vcat([@__FILE__,PLAN,EXACT,
    joinpath(@__DIR__,"alm_stationarity_analyze.py"),joinpath(@__DIR__,"alm_stationarity_exact.jl")],
    Legacy.SOURCES, [joinpath(ROOT,"src",name) for name in readdir(joinpath(ROOT,"src")) if endswith(name,".jl")],
    [joinpath(ROOT,name) for name in ("Project.toml","Manifest.toml") if isfile(joinpath(ROOT,name))]))
const QUANTITIES = (:E,:mixed_K,:mixed_V,:mixed_D,:bp_E,:bp_K,:bp_V,:bp_D,:S_alm,:Delta,
    :S_scalar,:Stot2,:mixed_scalar,:mixed_z,:mixed_Stot2,:scalar_minus_z)

hash_file(path) = bytes2hex(sha256(read(path)))
function source_hashes(paths=SOURCES)
    Dict(path=>hash_file(path) for path in paths)
end
function verify_sources(hashes)
    all(isfile(path) && hash_file(path)==digest for (path,digest) in hashes) || error("Run input changed")
    true
end
function parameters(seed,settings=PROFILE)
    CP.CPAFQMCParameters(dtau=settings.dt,walker_count=settings.walkers,
        warmup_steps=round(Int,settings.warmup/settings.dt),measurement_count=settings.samples,
        steps_between_measurements=round(Int,.1/settings.dt),back_propagation_steps=round(Int,settings.lag/settings.dt),
        orthogonalize_every=settings.cadence,population_control_every=settings.cadence,
        overlap_refresh_every=16,minimum_backprop_ancestors=2,error_block_size=5,seed=seed)
end
function fresh_state(seed,settings=PROFILE)
    problem=CP.CPAFQMCProblem(ED.open_cluster_kinetic_matrix(2,2),12.,3,3;lattice_size=2,cell_count=4)
    trial=Mirror.load_trial(Legacy.TRIAL_SOURCE;label="full_singlet_AM3_20terms")
    Mirror.initialize(problem,parameters(seed,settings);trial=trial,initialization=:exact_weighted,enabled=true)
end
function save_checkpoint(path,state,rows,hashes,settings,seed,phase)
    ispath(path) && error("Refusing checkpoint overwrite: $path")
    verify_sources(hashes)
    serialize(path,(state=state,rows=rows,source_hashes=hashes,settings=settings,seed=seed,
        phase=phase,julia_version=string(VERSION),saved_utc=string(now(UTC))))
end
function restored(path,hashes,settings,seed)
    saved=deserialize(path)
    saved.julia_version==string(VERSION) || error("Resume requires same Julia version")
    saved.settings==settings && saved.seed==seed || error("Resume seed/settings mismatch")
    saved.source_hashes==hashes || error("Resume source hash mismatch")
    verify_sources(hashes)
    saved.phase in ("warmup","measurement","paused") || error("Checkpoint is not resumable")
    saved.state.parameters==parameters(seed,settings) || error("Serialized parameter mismatch")
    expected=length(saved.rows)==0 ? min(saved.state.step,round(Int,settings.warmup/settings.dt)) :
        round(Int,settings.warmup/settings.dt)+length(saved.rows)*round(Int,.1/settings.dt)
    saved.state.step==expected || error("Checkpoint step and accepted prefix disagree")
    for (i,row) in enumerate(saved.rows)
        row.sample_index==i || error("Checkpoint row indices disagree")
    end
    saved.state,saved.rows
end
function snapshot(out,hashes)
    dir=joinpath(out,"source_snapshot");mkpath(dir)
    # Numbered names avoid accidental basename collisions across archive/runtime.
    open(joinpath(out,"source_hashes.csv"),"w") do io
        println(io,"path,sha256,snapshot")
        for (i,path) in enumerate(sort(collect(keys(hashes))))
            name=lpad(string(i),3,'0')*"_"*basename(path)
            cp(path,joinpath(dir,name))
            println(io,Legacy.csv(path),",",Legacy.csv(hashes[path]),",",Legacy.csv(name))
        end
    end
end
function run_chain(seed;attempt="initial_remote",resume=nothing,settings=PROFILE,
        output_base=OUT,stop_after=nothing,hashes=source_hashes())
    settings.scientific && (settings==PROFILE && seed in SEEDS || error("Unregistered scientific settings/seed"))
    occursin(r"^[A-Za-z0-9_-]+$",attempt) || error("Unsafe attempt label")
    out=joinpath(output_base,"stationarity_dt01_seed$(seed)_$(attempt)")
    ispath(out) && error("Refusing existing run directory: $out")
    verify_sources(hashes)
    state,rows=isnothing(resume) ? (fresh_state(seed,settings),NamedTuple[]) : restored(resume,hashes,settings,seed)
    mkpath(out);snapshot(out,hashes)
    p=state.parameters;started=time();completed=false;paused=false
    open(joinpath(out,"metadata.txt"),"w") do io
        println(io,"profile=stationarity_dt01\nattempt=",attempt,"\nscientific=",settings.scientific)
        println(io,"started_utc=",now(UTC),"\nroot=",ROOT,"\njulia_version=",VERSION)
        println(io,"trial=full_singlet_AM3_20terms\ninitialization=exact_weighted\nmirror=enabled")
        println(io,"Hamiltonian=centered U-only; U=12; open2x2; Nup=Ndown=3; n=1.5")
        println(io,"resume_parent=",isnothing(resume) ? "none" : abspath(resume))
        println(io,"resume_parent_sha256=",isnothing(resume) ? "none" : hash_file(resume))
        println(io,"resumed_prefix_count=",length(rows))
        for field in fieldnames(typeof(p));println(io,field,"=",getfield(p,field));end
    end
    try
        open(joinpath(out,"warmup.csv"),"w") do io
            for step in (state.step+1):p.warmup_steps
                Mirror.step!(state)
                if step%100==0 || step==p.warmup_steps
                    Legacy.write_named(io,(step=step,beta=step*settings.dt,elapsed_seconds=time()-started);header=position(io)==0)
                end
                if step%400==0 && step<p.warmup_steps
                    save_checkpoint(joinpath(out,@sprintf("checkpoint_warmup_%06d.jls",step)),state,rows,hashes,settings,seed,"warmup")
                    println("seed",seed," warmup beta=",step*settings.dt);flush(stdout)
                end
            end
        end
        isempty(rows) && save_checkpoint(joinpath(out,"warmup_checkpoint.jls"),state,rows,hashes,settings,seed,"measurement")
        open(joinpath(out,"samples.csv"),"w") do io
            for row in rows;Legacy.write_named(io,row;header=position(io)==0);end
            for sample in (length(rows)+1):p.measurement_count
                for _ in 1:p.steps_between_measurements;Mirror.step!(state);end
                row=Legacy.diagnostic_measurement(state,sample)
                Legacy.write_named(io,row;header=position(io)==0)
                for quantity in QUANTITIES
                    isfinite(getproperty(row,quantity)) || error("Nonfinite $sample/$quantity")
                end
                row.status=="valid" || error("Invalid measurement status")
                abs(row.bp_V-12*(4row.bp_D-1))<2e-8 || error("Centered-U identity failure")
                push!(rows,row)
                if sample%40==0 || sample==stop_after
                    save_checkpoint(joinpath(out,@sprintf("checkpoint_measurement_%04d.jls",sample)),state,rows,hashes,settings,seed,"measurement")
                    @printf("seed%d %d/%d beta=%.1f E=%.7f S_z=%.7f Delta=%.7f elapsed=%.1fs\n",
                        seed,sample,p.measurement_count,row.beta,row.E,row.S_alm,row.Delta,time()-started)
                    flush(stdout)
                end
                if sample==stop_after;paused=true;break;end
            end
        end
        if paused
            write(joinpath(out,"status.txt"),"PAUSED; prefix retained for focused resume test\n")
        else
            length(rows)==settings.samples || error("Retained/planned count mismatch")
            save_checkpoint(joinpath(out,"final_checkpoint.jls"),state,rows,hashes,settings,seed,"complete")
            verify_sources(hashes);completed=true
            write(joinpath(out,"status.txt"),"COMPLETED; numerical/source checks passed; scientific gates separate\n")
        end
    catch err
        open(joinpath(out,"status.txt"),"w") do io
            println(io,"FAILED; raw prefix retained");showerror(io,err,catch_backtrace());println(io)
        end
        # A failed state may have advanced beyond its accepted prefix: retained for
        # diagnosis only, never accepted by the resume entry point.
        serialize(joinpath(out,"failure_checkpoint.jls"),(state=state,rows=rows,source_hashes=hashes,
            settings=settings,seed=seed,phase="failed",julia_version=string(VERSION)))
        rethrow()
    finally
        open(joinpath(out,"completion.txt"),"w") do io
            println(io,"accepted_measurements=",length(rows),"\nplanned_measurements=",settings.samples)
            println(io,"completed=",completed,"\npaused=",paused,"\nrun_wall_seconds=",time()-started)
            for (key,value) in pairs(Mirror.diagnostics(state));println(io,key,"=",value);end
        end
    end
    (;out,state,rows)
end
function main(args=ARGS)
    1<=length(args)<=3 || error("Usage: alm_stationarity_run.jl SEED [ATTEMPT [CHECKPOINT]]")
    old=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        run_chain(parse(Int,args[1]);attempt=length(args)>=2 ? args[2] : "initial_remote",
            resume=length(args)==3 ? args[3] : nothing)
    finally;BLAS.set_num_threads(old);end
end
end
if abspath(PROGRAM_FILE)==@__FILE__;ALMStationarityRun.main();end
