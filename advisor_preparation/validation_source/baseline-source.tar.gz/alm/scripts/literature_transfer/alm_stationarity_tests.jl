#!/usr/bin/env julia
# Focused deterministic restart/guard tests; these are not scientific chains.
using Test, LinearAlgebra, Serialization, Random
const ROOT=normpath(joinpath(@__DIR__,"../.."))
function test_dependency_tree()
    runtime=mktempdir(prefix="alm_stationarity_dependencies_")
    archive=joinpath(ROOT,"results/remote_mirror_return/20260911")
    isfile(joinpath(ROOT,"scripts/literature_transfer/run_multislater_mirror_benchmark.jl")) && return ROOT
    # The archived mirror return contains changed files only; merge by symlinks
    # in /tmp, leaving every original source and artifact unchanged.
    mkpath(joinpath(runtime,"scripts/literature_transfer"));mkpath(joinpath(runtime,"docs/reading"))
    for path in readdir(joinpath(ROOT,"scripts");join=true)
        isfile(path) && symlink(path,joinpath(runtime,"scripts",basename(path)))
    end
    names=union(readdir(joinpath(ROOT,"scripts/literature_transfer")),readdir(joinpath(archive,"scripts/literature_transfer")))
    for name in names
        archived=joinpath(archive,"scripts/literature_transfer",name)
        source=isfile(archived) ? archived : joinpath(ROOT,"scripts/literature_transfer",name)
        isfile(source) && symlink(source,joinpath(runtime,"scripts/literature_transfer",name))
    end
    symlink(joinpath(ROOT,"src"),joinpath(runtime,"src"))
    symlink(joinpath(ROOT,"results"),joinpath(runtime,"results"))
    symlink(joinpath(archive,"docs/reading/mirror_correction_remote_plan.md"),joinpath(runtime,"docs/reading/mirror_correction_remote_plan.md"))
    symlink(joinpath(archive,"remote_mirror_continuation"),joinpath(runtime,"remote_mirror_continuation"))
    runtime
end
ENV["ALM_STATIONARITY_DEPENDENCY_ROOT"]=test_dependency_tree()
include(joinpath(@__DIR__,"alm_stationarity_run.jl"))
const Run=ALMStationarityRun
function numerical_state_bytes(state)
    copy=deepcopy(state)
    copy.core.started=0.;copy.core.propagation_seconds=0.;copy.core.measurement_seconds=0.
    io=IOBuffer();serialize(io,copy);take!(io)
end
old=BLAS.get_num_threads();BLAS.set_num_threads(1)
try
    @testset "stationarity registration and resumed trajectory" begin
        @test length(unique(Run.SEEDS))==4
        @test Run.PROFILE.warmup==64 && Run.PROFILE.samples==640
        for seed in Run.SEEDS
            p=Run.parameters(seed)
            @test p.warmup_steps==6400
            @test p.back_propagation_steps==400
            @test p.steps_between_measurements==p.orthogonalize_every==p.population_control_every==10
        end
        # A deterministic stream-prefix collision screen is not a proof of independence.
        words=[rand(Xoshiro(seed),UInt64,16) for seed in Run.SEEDS]
        @test all(words[i]!=words[j] for i in 1:4 for j in (i+1):4)
        settings=(dt=.01,walkers=32,warmup=.2,lag=.1,samples=10,cadence=10,scientific=false)
        out=mktempdir(prefix="alm_stationarity_restart_")
        hashes=Run.source_hashes([@__FILE__,joinpath(@__DIR__,"alm_stationarity_run.jl")])
        whole=Run.run_chain(210719;settings=settings,output_base=out,attempt="whole",hashes=hashes)
        prefix=Run.run_chain(210719;settings=settings,output_base=out,attempt="prefix",hashes=hashes,stop_after=3)
        cp=joinpath(prefix.out,"checkpoint_measurement_0003.jls")
        resumed=Run.run_chain(210719;settings=settings,output_base=out,attempt="resumed",hashes=hashes,resume=cp)
        @test isequal(whole.rows,resumed.rows)
        @test read(joinpath(whole.out,"samples.csv"))==read(joinpath(resumed.out,"samples.csv"))
        # Exact equality is appropriate: serialization must preserve the same
        # trajectory bit-for-bit. Only three wall-clock timing fields are removed.
        @test numerical_state_bytes(whole.state)==numerical_state_bytes(resumed.state)
        @test rand(copy(whole.state.rng),UInt64,32)==rand(copy(resumed.state.rng),UInt64,32)
        @test length(resumed.rows)==10
        warm=Run.run_chain(210719;settings=settings,output_base=out,attempt="warm_resumed",hashes=hashes,resume=joinpath(whole.out,"warmup_checkpoint.jls"))
        @test isequal(warm.rows,whole.rows)
        @test numerical_state_bytes(warm.state)==numerical_state_bytes(whole.state)
        @test_throws ErrorException Run.run_chain(210719;settings=settings,output_base=out,attempt="whole",hashes=hashes)
        @test_throws ErrorException Run.restored(cp,hashes,settings,210720)
        @test_throws ErrorException Run.restored(cp,hashes,merge(settings,(samples=9,)),210719)
        @test_throws ErrorException Run.restored(cp,merge(hashes,Dict((@__FILE__)=>"bad")),settings,210719)
        @test_throws ErrorException Run.restored(joinpath(whole.out,"final_checkpoint.jls"),hashes,settings,210719)
        @test_throws ErrorException Run.run_chain(first(Run.SEEDS);settings=merge(Run.PROFILE,(walkers=32,)),output_base=out,hashes=hashes)
        println("Focused restart artifacts: ",out)
    end
finally
    BLAS.set_num_threads(old)
end
