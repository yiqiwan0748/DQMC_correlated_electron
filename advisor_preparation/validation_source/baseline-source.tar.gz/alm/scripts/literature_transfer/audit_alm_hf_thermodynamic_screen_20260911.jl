#!/usr/bin/env julia
# Additional validation of the completed common-tangent candidates; no new phase search.
include("alm_hf_thermodynamic_screen_20260911.jl")
using .ALMHFThermodynamicScreen, TOML, Test, Printf, Dates, SHA
const A=ALMHFThermodynamicScreen
const AUDITDIR=joinpath(A.OUT,"supporting_line_validation")
ispath(AUDITDIR) && error("Refusing to overwrite existing audit")
mkpath(AUDITDIR)
cp(@__FILE__,joinpath(AUDITDIR,"audit_source.jl"))
open(joinpath(AUDITDIR,"provenance.toml"),"w") do io
    TOML.print(io,Dict("started_utc"=>string(now(UTC)),"julia"=>string(VERSION),
        "analysis_sha256"=>bytes2hex(sha256(read(joinpath(@__DIR__,"alm_hf_thermodynamic_screen_20260911.jl")))),
        "audit_sha256"=>bytes2hex(sha256(read(@__FILE__))),
        "purpose"=>"Post-screen numerical validation at the original density bracket and at common fixed n=1.425; no density search expansion"))
end
open(joinpath(AUDITDIR,"supporting_lines.csv"),"w") do supportio
 open(joinpath(AUDITDIR,"fixed_density_comparison.csv"),"w") do fixio
  A.csvline(supportio,(:nk,:T,:n,:kind,:F,:tangent_F,:excess_F))
  A.csvline(fixio,(:nk,:T,:n,:FM_F,:AM_F,:mixture_F,:gain,:AM_fraction))
  @testset "Supporting-line and fixed-density common-tangent validation" begin
   for nk in (192,384),T in (.05,.025)
    props=TOML.parsefile(joinpath(A.OUT,"refine_Nk$(nk)_T$(T)/summary.toml"))
    nl=props["n_left_FM"];nr=props["n_right_AM"];mu=props["mu_coexist"];fl=props["F_left"]
    g=A.HF.mesh_hf(nk)
    # Original grid plus exact tangent endpoints; inspect both retained magnetic branches.
    ns=sort(unique(vcat(collect(1.38:.005:1.48),[nl,nr,1.46021875])))
    for n in ns,kind in (:AM,:FM)
        r=A.high_branch(g,kind,n,T);line=fl+mu*(n-nl)
        A.csvline(supportio,(nk,T,n,kind,r.F,line,r.F-line))
        @test r.F-line > -3e-9  # Allows density/field root and accumulation errors only.
    end
    n=1.425;fm=A.high_branch(g,:FM,n,T);am=A.high_branch(g,:AM,n,T)
    fraction=(n-nl)/(nr-nl);mixed=(1-fraction)*fl+fraction*props["F_right"]
    @test 0<fraction<1
    @test min(am.F,fm.F)-mixed>0
    A.csvline(fixio,(nk,T,n,fm.F,am.F,mixed,min(am.F,fm.F)-mixed,fraction))
   end
  end
 end
end
open(joinpath(AUDITDIR,"completed.txt"),"w") do io;println(io,now(UTC));end
