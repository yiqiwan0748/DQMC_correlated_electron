#!/usr/bin/env julia
# A bounded orbital-to-band matrix diagnostic. It solves no interacting model.
using LinearAlgebra
using Test
using Printf
using SHA

module RepositoryBands
include(joinpath(@__DIR__, "..", "..", "src", "noninteracting.jl"))
end

const τ0 = Matrix{Float64}(I, 2, 2)
const τ1 = [0.0 1.0; 1.0 0.0]
const τ3 = [1.0 0.0; 0.0 -1.0]
const parameters = (-1.0, -1.75, -0.85, -0.65)
# O(1) 2x2 matrices in Float64; comfortably above accumulated rounding error.
const atol = 2e-12
const degeneracy_cutoff = 1e-10

function independent_h(kx, ky, p=parameters)
    t1, t2, t3, t4 = p
    center = -(t1 + t2) * (cos(kx) + cos(ky)) - 4t3*cos(kx)*cos(ky)
    a = -(t1 - t2) * (cos(kx) - cos(ky))
    b = -4t4*sin(kx)*sin(ky)
    return center*τ0 + a*τ3 + b*τ1, a, b
end

function weights(h, A)
    e = eigen(Symmetric(h))
    B = e.vectors' * A * e.vectors
    total = sum(abs2, A)
    intra = sum(abs2, diag(B)) / total
    inter = (abs2(B[1,2]) + abs2(B[2,1])) / total
    return (; intra, inter, B, e)
end

function main()
    outdir = isempty(ARGS) ? joinpath(@__DIR__, "..", "..", "results", "literature_transfer", "core") : only(ARGS)
    mkpath(outdir)
    nk = 64
    rows = Tuple[]
    max_weight_error = 0.0
    max_commutator_error = 0.0
    degenerate_count = 0
    @testset "orbital-to-band literature transfer" begin
        for jy in 0:nk-1, jx in 0:nk-1
            kx, ky = -π + 2π*jx/nk, -π + 2π*jy/nk
            h, a, b = independent_h(kx, ky)
            @test isapprox(h, RepositoryBands.bloch_hamiltonian(kx,ky); atol, rtol=0)
            r = hypot(a,b)
            if r <= degeneracy_cutoff
                degenerate_count += 1
                push!(rows, (kx, ky, a, b, 2r, true, NaN, NaN, NaN, NaN))
                continue
            end
            w3, w1, w0 = weights(h,τ3), weights(h,τ1), weights(h,τ0)
            errors = [abs(w3.intra-a*a/r^2), abs(w3.inter-b*b/r^2),
                      abs(w1.intra-b*b/r^2), abs(w1.inter-a*a/r^2)]
            max_weight_error = max(max_weight_error, maximum(errors))
            @test maximum(errors) < atol
            for (A,w) in ((τ0,w0),(τ1,w1),(τ3,w3))
                @test isapprox(w.intra+w.inter,1; atol, rtol=0)
                comm = h*A-A*h
                lhs = w.inter*sum(abs2,A)
                rhs = sum(abs2,comm)/(w.e.values[2]-w.e.values[1])^2
                max_commutator_error = max(max_commutator_error, abs(lhs-rhs))
                @test isapprox(lhs,rhs; atol, rtol=0)
            end
            @test isapprox(w0.inter,0; atol, rtol=0)
            # A nonidentity, momentum-dependent commuting matrix is intraband.
            @test isapprox(weights(h,a*τ3+b*τ1).inter,0; atol, rtol=0)
            # Covariant orbital gauge change and orbital relabeling.
            for G in (τ3,τ1)
                wg = weights(G'*h*G,G'*τ3*G)
                @test isapprox(wg.intra,w3.intra; atol, rtol=0)
                @test isapprox(wg.inter,w3.inter; atol, rtol=0)
            end
            # Moreo PRB80 Eqs. 6–9: real matched gauges at k and -k.
            gap = (cos(kx)+cos(ky)) * τ1
            Bg = w3.e.vectors' * gap * w3.e.vectors
            @test isapprox(sum(abs2,Bg),sum(abs2,gap); atol=2e-11,rtol=0)
            push!(rows, (kx, ky, a, b, 2r, false, w3.intra, w3.inter, w1.intra, w1.inter))
        end
        @test degenerate_count == 2 # Γ and M on this periodic mesh.
        for (kx,ky) in ((0.0,0.7),(0.6,0.6),(0.4,-0.9))
            h,a,b = independent_h(kx,ky)
            h_nohybrid,_,_ = independent_h(kx,ky,(-1.0,-1.75,-0.85,0.0))
            if abs(a)>degeneracy_cutoff
                @test isapprox(weights(h_nohybrid,τ3).intra,1;atol,rtol=0)
            end
            h_equal,_,b_equal = independent_h(kx,ky,(-1.0,-1.0,-0.85,-0.65))
            if abs(b_equal)>degeneracy_cutoff
                @test isapprox(weights(h_equal,τ3).inter,1;atol,rtol=0)
            end
        end
        @test isapprox(weights(first(independent_h(0.0,0.7)),τ3).intra,1;atol,rtol=0)
        @test isapprox(weights(first(independent_h(0.6,0.6)),τ3).inter,1;atol,rtol=0)
        # Full pairing covariance uses distinct electron/hole gauges at ±k.
        h,_,_ = independent_h(0.4,-0.9)
        U = eigen(Symmetric(h)).vectors
        Vplus = U*Diagonal(exp.(im .* [0.3,-0.7]))
        Vminus = U*Diagonal(exp.(im .* [-0.2,0.8]))
        P = 0.13τ1 + 0.07τ3
        Hbdg = [h P; P' -transpose(h)]
        Q = zeros(ComplexF64,4,4)
        Q[1:2,1:2],Q[3:4,3:4] = Vplus,conj(Vminus)
        Pband = Vplus'*P*conj(Vminus)
        transformed = Q'*Hbdg*Q
        @test isapprox(transformed[1:2,3:4],Pband;atol,rtol=0)
        @test isapprox(eigvals(Hermitian(transformed)),eigvals(Hermitian(Hbdg));atol,rtol=0)
        @test isapprox(abs2.(Pband),abs2.(U'*P*U);atol,rtol=0)
        @test isapprox(abs2.(Vplus'*τ3*Vplus),abs2.(U'*τ3*U);atol,rtol=0)
        # At exact degeneracy individual band weights depend on the chosen basis.
        angle = π/4
        R = [cos(angle) -sin(angle);sin(angle) cos(angle)]
        @test isapprox(R'*(2τ0)*R,2τ0;atol,rtol=0)
        @test sum(abs2,diag(τ3))/2 == 1
        @test isapprox(sum(abs2,diag(R'*τ3*R))/2,0;atol,rtol=0)
    end
    open(joinpath(outdir,"matrix_weights.csv"),"w") do io
        println(io,"kx,ky,a,b,band_gap,degenerate,tau3_intra,tau3_inter,tau1_intra,tau1_inter")
        for row in rows
            println(io,join(map(x -> x isa AbstractFloat && isnan(x) ? "" : string(x),row),","))
        end
    end
    valid = filter(row -> !row[6],rows)
    mean_inter = sum(row[8] for row in valid)/length(valid)
    open(joinpath(outdir,"summary.csv"),"w") do io
        println(io,"quantity,value")
        for (key,value) in (("nk",nk),("nondegenerate_points",length(valid)),
            ("degenerate_points",degenerate_count),("max_fraction_error",max_weight_error),
            ("max_commutator_error",max_commutator_error),("bz_mean_tau3_inter_fraction",mean_inter))
            println(io,key,",",value)
        end
    end
    open(joinpath(outdir,"provenance.txt"),"w") do io
        println(io,"Julia ",VERSION,"; Float64; no interacting calculation; no added packages")
        println(io,"t1,t2,t3,t4 = ",parameters,"; orbital order dxz,dyz; k in radians")
        println(io,"64x64 periodic mesh [-pi,pi); degeneracy radius cutoff = ",degeneracy_cutoff)
        println(io,"Fraction tolerance = ",atol,"; absolute squared pairing norm tolerance = 2e-11")
        println(io,"Band fractions are undefined at degeneracy. BZ average is not a susceptibility.")
        println(io,"script_sha256 = ",bytes2hex(sha256(read(@__FILE__))))
        source = joinpath(@__DIR__,"..","..","src","noninteracting.jl")
        println(io,"noninteracting_source_sha256 = ",bytes2hex(sha256(read(source))))
        println(io,"Sources: 10.1103/PhysRevB.80.104507 Eqs6-9; 10.1103/PhysRevB.81.144509 SecIIIA")
    end
    @printf("Wrote %d momentum rows; max fraction error %.3g; max commutator error %.3g; BZ mean tau3 inter fraction %.9f\n",length(rows),max_weight_error,max_commutator_error,mean_inter)
end

main()
