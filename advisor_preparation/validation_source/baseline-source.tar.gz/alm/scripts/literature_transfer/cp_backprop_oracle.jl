#!/usr/bin/env julia
"""Isolated deterministic CP estimator/short-HS-path audit; production is read-only."""
module CPBackpropOracle
using LinearAlgebra, Random, Test, SHA, Printf
import AltermagnetDQMCTrial as CP
include(joinpath(@__DIR__,"../two_orbital_open_cluster_ed.jl"))

const ROOT = normpath(joinpath(@__DIR__, "../.."))
const OUT = get(ENV,"CP_ORACLE_OUTPUT",joinpath(ROOT,"results/literature_transfer/cp_backprop_oracle/verified"))
const ATOL = 2e-9 # Float64: tiny sectors, finite products; no stochastic tolerance.

function occupations(M,N)
    [[i for i in 1:M if !iszero(b & (1 << (i-1)))]
     for b in 0:(1<<M)-1 if count_ones(b)==N]
end
mask(o)=sum(1 << (i-1) for i in o;init=0)
function one_spin_generator(K,occ)
    index=Dict(mask(o)=>i for (i,o) in enumerate(occ)); H=zeros(length(occ),length(occ))
    for (col,o) in enumerate(occ), j in o, i in axes(K,1)
        b=mask(o); without=b ⊻ (1 << (j-1))
        iszero(without & (1 << (i-1))) || continue
        parity=count_ones(b & ((1 << (j-1))-1))+count_ones(without & ((1 << (i-1))-1))
        H[index[without | (1 << (i-1))],col] += (-1.0)^parity*K[i,j]
    end
    H
end
wedge(B,occ)=[det(B[a,b]) for a in occ,b in occ]
slater(up,dn,ou,od)=kron([det(up[o,:]) for o in ou],[det(dn[o,:]) for o in od])
function fock_data(K,U,Nu,Nd)
    M=size(K,1); ou=occupations(M,Nu); od=occupations(M,Nd)
    ku=one_spin_generator(K,ou); kd=one_spin_generator(K,od)
    kin=kron(ku,Matrix{Float64}(I,length(od),length(od)))+
        kron(Matrix{Float64}(I,length(ou),length(ou)),kd)
    pairs=[(a,b) for a in ou for b in od]
    nu=[Float64(i in ab[1]) for ab in pairs,i in 1:M]
    nd=[Float64(i in ab[2]) for ab in pairs,i in 1:M]
    interaction=U*vec(sum((nu.-.5).*(nd.-.5);dims=2))
    (;ou,od,kin,interaction,H=kin+Diagonal(interaction),nu,nd)
end

function trial_for(K,Nu,Nd,field)
    CP.SlaterTrial(eigen(Symmetric(K-Diagonal(field))).vectors[:,1:Nu],
                   eigen(Symmetric(K+Diagonal(field))).vectors[:,1:Nd];label="oracle")
end
function order_from_density(cu,cd,w)
    mean=dot(w,diag(cu)-diag(cd))/2
    square=sum(w[i]*w[j]*(CP._cp_same_spin_density_pair(cu,i,j)+
        CP._cp_same_spin_density_pair(cd,i,j)-cu[i,i]*cd[j,j]-cd[i,i]*cu[j,j])/4
        for i in eachindex(w),j in eachindex(w))
    (;mean,square)
end
overlap(trial,u,d)=det(trial.up'*u)*det(trial.down'*d)

"""Direct determinant ratios, independent of the Sherman–Morrison implementation.
The sequential positivity mask is part of finite-step CP, not the HS identity.
"""
function direct_importance(trial,KH,gamma,fields,order,u0,d0)
    u=copy(u0);d=copy(d0); old=overlap(trial,u,d)
    probability=1.;weight=1.;draws=Float64[]; minratio=Inf
    old>0 || return (;allowed=false,probability=0.,weight=0.,draws,u,d,minratio)
    for kinetic in 1:2
        u=KH*u;d=KH*d; new=overlap(trial,u,d)
        new>0 || return (;allowed=false,probability=0.,weight=0.,draws,u,d,minratio)
        weight*=new/old;old=new
        kinetic==2 && break
        for i in order
            ratios=Float64[]
            for s in (1,-1)
                uu=copy(u);dd=copy(d);uu[i,:].*=exp(s*gamma);dd[i,:].*=exp(-s*gamma)
                push!(ratios,overlap(trial,uu,dd)/old)
            end
            minratio=min(minratio,minimum(ratios))
            p=max.(ratios,0.)/2;z=sum(p);chosen=fields[i]==1 ? 1 : 2
            if z==0 || p[chosen]==0
                return (;allowed=false,probability=0.,weight=0.,draws,u,d,minratio)
            end
            pp=p[1]/z
            push!(draws,chosen==1 ? pp/2 : (1+pp)/2)
            probability*=p[chosen]/z;weight*=z
            u[i,:].*=exp(fields[i]*gamma);d[i,:].*=exp(-fields[i]*gamma)
            old=overlap(trial,u,d)
        end
    end
    (;allowed=true,probability,weight,draws,u,d,minratio)
end

mutable struct ReplayRNG <: AbstractRNG
    draws::Vector{Float64}
    order::Vector{Int}
    offset::Int
end
Random.rand(r::ReplayRNG)=(r.offset+=1;r.draws[r.offset])
Random.shuffle!(r::ReplayRNG,v::AbstractVector)=(v.=r.order;v)
function replay_state(problem,trial,params,draws,order)
    s=CP.initialize_cp_afqmc(problem,params;trial)
    rng=ReplayRNG(draws,collect(order),0)
    CP.CPAFQMCState(ntuple(i->i==7 ? rng : getfield(s,i),fieldcount(typeof(s)))...)
end

function check_history(problem,trial,KH,gamma,path,order,cadence;dtau=.1)
    M=size(KH,1);steps=length(path)
    u=copy(trial.up);d=copy(trial.down);draws=Float64[];probability=1.;expectedweight=1.
    for fields in path
        r=direct_importance(trial,KH,gamma,fields,order,u,d)
        r.allowed || return nothing
        append!(draws,r.draws);probability*=r.probability;expectedweight*=r.weight;u=r.u;d=r.d
    end
    maxerror=0.
    for lag in 1:steps
        params=CP.CPAFQMCParameters(dtau=dtau,walker_count=2,warmup_steps=0,measurement_count=1,
            error_block_size=1,back_propagation_steps=lag,minimum_backprop_ancestors=1,
            orthogonalize_every=cadence,overlap_refresh_every=1,population_control_every=9999)
        state=replay_state(problem,trial,params,copy(draws),order)
        state.kinetic_half.=KH;state.gamma=gamma
        walker=state.walkers[1]
        for (step,fields) in enumerate(path)
            @test CP._cp_apply_kinetic!(state,walker)
            actual=CP._cp_apply_potential!(state,walker)
            @test actual==fields
            @test CP._cp_apply_kinetic!(state,walker)
            step%cadence==0 && (@test CP._cp_stabilize!(state,walker))
            CP._cp_append_history!(state,walker,actual,step+10)
            state.step=step
        end
        @test abs(exp(walker.log_weight)/expectedweight-1)<ATOL
        @test abs(probability*expectedweight-
            overlap(trial,u,d)/2.0^(M*steps))<ATOL*max(1.,abs(probability*expectedweight))
        # Endpoint and anchor are only projectively equivalent after QR.
        anchoru=copy(trial.up);anchord=copy(trial.down)
        for fields in path[1:steps-lag]
            anchoru=KH*Diagonal(exp.(gamma.*fields))*KH*anchoru
            anchord=KH*Diagonal(exp.(-gamma.*fields))*KH*anchord
        end
        leftu=copy(trial.up);leftd=copy(trial.down)
        for fields in reverse(path[steps-lag+1:steps])
            leftu=KH*Diagonal(exp.(gamma.*fields))*KH*leftu
            leftd=KH*Diagonal(exp.(-gamma.*fields))*KH*leftd
        end
        lu,ld=CP._cp_backpropagated_left(state,walker)
        cu=CP.transition_density_matrix(lu,walker.anchor_up)
        cd=CP.transition_density_matrix(ld,walker.anchor_down)
        expectedu=anchoru*((leftu'*anchoru)\leftu')
        expectedd=anchord*((leftd'*anchord)\leftd')
        e=max(maximum(abs,cu-expectedu),maximum(abs,cd-expectedd));maxerror=max(maxerror,e)
        @test e<ATOL
        # Deliberate nonorthogonal occupied-basis changes must cancel locally.
        if size(lu,2)>1
            p=size(lu,2);A=Matrix{Float64}(I,p,p);B=copy(A)
            A[1:2,1:2]=[1.7 .3;0. -.8];B[1:2,1:2]=[.8 -.4;.2 1.2]
            @test maximum(abs,CP.transition_density_matrix(lu*A,walker.anchor_up*B)-cu)<ATOL
        end
        if !isnothing(problem.lattice_size)
            # Identical population: this tests public measurement wiring without
            # stochastic noise or population control. Count is only an API fixture.
            state.walkers[2]=CP._cp_copy_walker(walker)
            state.walkers[2].log_weight=walker.log_weight
            observed=CP.measure_cp_afqmc(state;include_order=true)
            ou=occupations(M,problem.Nup);od=occupations(M,problem.Ndown)
            pairs=[(a,b) for a in ou for b in od]
            z=[((i in ab[1])-(i in ab[2]))/2 for ab in pairs,i in 1:M]
            left=slater(leftu,leftd,ou,od);right=slater(anchoru,anchord,ou,od)
            probabilities=left.*right/dot(left,right)
            weight=[isodd(i) ? 1. : -1. for i in 1:M];oval=z*weight
            nc=problem.cell_count
            @test abs(observed.order_measurement.delta_alm-dot(probabilities,oval)/nc)<ATOL
            @test abs(observed.measurement.S_alm_q0-dot(probabilities,oval.^2)/nc)<ATOL
            @test abs(observed.measurement.S_fm_q0-(problem.Nup-problem.Ndown)^2/(4nc))<ATOL
            raw=z'*(probabilities.*z)
            L=problem.lattice_size
            for qy in 0:L-1,qx in 0:L-1
                P=zeros(ComplexF64,M,2)
                for y in 0:L-1,x in 0:L-1,a in 1:2
                    P[2*(x+L*y)+a,a]=cis(2pi*(qx*x+qy*y)/L)/sqrt(nc)
                end
                expected=P'*raw*P
                @test maximum(abs,observed.measurement.structure_factor[:,:,qx+1,qy+1]/4-expected)<ATOL
            end
        end
    end
    (;maxerror,probability,expectedweight)
end

function enumerate_case(name,K,U,Nu,Nd,field,dt,steps;history_limit=12)
    M=size(K,1);fd=fock_data(K,U,Nu,Nd);trial=trial_for(K,Nu,Nd,field)
    psi=slater(trial.up,trial.down,fd.ou,fd.od);@test abs(norm(psi)-1)<ATOL
    problem=CP.CPAFQMCProblem(K,U,Nu,Nd)
    KH=exp(Symmetric(-dt*K/2));gamma=acosh(exp(dt*U/2))
    hs=[[iszero(b & (1 << (i-1))) ? Int8(-1) : Int8(1) for i in 1:M] for b in 0:(1<<M)-1]
    Bu=[KH*Diagonal(exp.(gamma.*s))*KH for s in hs]
    Bd=[KH*Diagonal(exp.(-gamma.*s))*KH for s in hs]
    many=[kron(wedge(u,fd.ou),wedge(d,fd.od)) for (u,d) in zip(Bu,Bd)]
    scalar=exp(-dt*U*M/4)/2.0^M
    F=sum(many)*scalar
    half=exp(Symmetric(-dt*fd.kin/2))
    independent=half*Diagonal(exp.(-dt.*fd.interaction))*half
    hs_error=maximum(abs,F-independent);@test hs_error<ATOL
    w=[isodd(i) ? 1. : -1. for i in 1:M];oval=(fd.nu-fd.nd)*w/2
    expected_den=dot(psi,F^steps*psi)
    expected_E=dot(psi,fd.H*F^steps*psi)/expected_den
    denominators=0.;numE=0.;numO=zeros(steps+1);numO2=zeros(steps+1)
    cpden=zeros(2);cpE=zeros(2);cpO=zeros(2,steps+1);cpO2=zeros(2,steps+1)
    kept=zeros(Int,2);negative=0;small=0;maximum_local=0.;historyrows=NamedTuple[]
    histories_checked=0;orders=(collect(1:M),collect(M:-1:1))
    paths=length(hs)^steps
    for code in 0:paths-1
        indices=digits(code;base=length(hs),pad=steps).+1;path=hs[indices]
        us=[copy(trial.up)];ds=[copy(trial.down)]
        for j in indices
            push!(us,Bu[j]*us[end]);push!(ds,Bd[j]*ds[end])
        end
        den=overlap(trial,us[end],ds[end]);negative+=den<0
        if abs(den)<1e-12
            small+=1
            error("Path overlap too small for this deterministic ratio test: $name/$code")
        end
        ket=slater(us[end],ds[end],fd.ou,fd.od)
        localE=CP.mixed_local_energy(problem,trial.up,trial.down,us[end],ds[end]).total
        exactE=dot(psi,fd.H*ket)/den
        maximum_local=max(maximum_local,abs(localE-exactE));@test abs(localE-exactE)<ATOL*max(1.,abs(exactE))
        densityu=CP.transition_density_matrix(trial.up,us[end])
        densityd=CP.transition_density_matrix(trial.down,ds[end])
        @test abs(tr(densityu)-Nu)<ATOL
        @test abs(tr(densityd)-Nd)<ATOL
        locO=zeros(steps+1);locO2=zeros(steps+1)
        for lag in 0:steps
            lu=copy(trial.up);ld=copy(trial.down)
            for j in reverse(indices[steps-lag+1:steps]);lu=Bu[j]*lu;ld=Bd[j]*ld;end
            anchoru=us[steps-lag+1];anchord=ds[steps-lag+1]
            cu=CP.transition_density_matrix(lu,anchoru);cd=CP.transition_density_matrix(ld,anchord)
            o=order_from_density(cu,cd,w)
            left=slater(lu,ld,fd.ou,fd.od);right=slater(anchoru,anchord,fd.ou,fd.od)
            exactO=dot(left,oval.*right)/dot(left,right)
            exactO2=dot(left,(oval.^2).*right)/dot(left,right)
            @test abs(o.mean-exactO)<ATOL*max(1.,abs(exactO))
            @test abs(o.square-exactO2)<ATOL*max(1.,abs(exactO2))
            locO[lag+1]=o.mean;locO2[lag+1]=o.square
        end
        weight=scalar^steps*den;denominators+=weight;numE+=weight*localE
        numO.+=weight.*locO;numO2.+=weight.*locO2
        for (a,order) in enumerate(orders)
            allowed=true;probability=1.;importance=1.;u=copy(trial.up);d=copy(trial.down)
            for s in path
                r=direct_importance(trial,KH,gamma,s,order,u,d)
                if !r.allowed;allowed=false;break;end
                probability*=r.probability;importance*=r.weight;u=r.u;d=r.d
            end
            allowed || continue
            kept[a]+=1
            @test abs(probability*importance-den/2.0^(M*steps))<ATOL*max(1.,abs(den/2.0^(M*steps)))
            cpden[a]+=weight;cpE[a]+=weight*localE;cpO[a,:].+=weight.*locO;cpO2[a,:].+=weight.*locO2
            if a==1 && histories_checked<history_limit && code%max(1,paths÷(2history_limit))==0
                for cadence in (1,2,7)
                    checked=check_history(problem,trial,KH,gamma,path,order,cadence;dtau=dt)
                    @test !isnothing(checked)
                    push!(historyrows,(case=name,path=code,steps=steps,qr_cadence=cadence,
                        all_lag_density_error=checked.maxerror,importance_probability=checked.probability,
                        importance_weight=checked.expectedweight))
                end
                histories_checked+=1
            end
        end
    end
    @test abs(denominators-expected_den)<ATOL*max(1.,abs(expected_den))
    @test abs(numE/denominators-expected_E)<ATOL
    rows=NamedTuple[]
    for lag in 0:steps
        left=F^lag*psi;right=F^(steps-lag)*psi
        eo=dot(left,oval.*right)/dot(left,right);eo2=dot(left,(oval.^2).*right)/dot(left,right)
        @test abs(numO[lag+1]/denominators-eo)<ATOL
        @test abs(numO2[lag+1]/denominators-eo2)<ATOL
        push!(rows,(case=name,M=M,Nup=Nu,Ndown=Nd,U=U,dtau=dt,steps=steps,lag=lag,
            exact_trotter_energy=expected_E,pathsum_energy=numE/denominators,
            exact_trotter_O=eo,pathsum_O=numO[lag+1]/denominators,
            exact_trotter_O2=eo2,pathsum_O2=numO2[lag+1]/denominators,
            cp_forward_energy=cpE[1]/cpden[1],cp_reverse_energy=cpE[2]/cpden[2],
            cp_forward_O=cpO[1,lag+1]/cpden[1],cp_reverse_O=cpO[2,lag+1]/cpden[2],
            cp_forward_O2=cpO2[1,lag+1]/cpden[1],cp_reverse_O2=cpO2[2,lag+1]/cpden[2]))
    end
    info=(case=name,paths=paths,negative_final_overlap=negative,nearzero_paths=small,
        allowed_forward=kept[1],allowed_reverse=kept[2],hs_identity_error=hs_error,
        max_local_energy_error=maximum_local,history_paths_tested=histories_checked,
        exact_trotter_denominator=expected_den,pathsum_denominator=denominators)
    (;rows,info,historyrows)
end

function writecsv(name,rows)
    open(joinpath(OUT,name),"w") do io
        println(io,join(string.(keys(first(rows))),','))
        for r in rows;println(io,join(string.(values(r)),','));end
    end
end
function target_checks()
    # Target hopping is only a fixture: amplitudes, spin operators and
    # contractions above remain independent of the imported ED implementation.
    K=TwoOrbitalOpenClusterED.open_cluster_kinetic_matrix(2,2)
    problem=CP.CPAFQMCProblem(K,12.,3,3;lattice_size=2,cell_count=4)
    trial=CP.one_body_trial(problem;pattern=:altermagnetic,field_strength=3.)
    dt=.04;KH=exp(Symmetric(-dt*K/2));gamma=acosh(exp(dt*12/2))
    path=[[isodd(i+j) ? Int8(1) : Int8(-1) for i in 1:8] for j in 1:5]
    target=NamedTuple[]
    for cadence in (1,2,7)
        checked=check_history(problem,trial,KH,gamma,path,collect(1:8),cadence;dtau=dt)
        @test !isnothing(checked)
        push!(target,(case="target_open_L2_AM3",U=12.,dtau=dt,steps=5,qr_cadence=cadence,
            all_lag_density_error=checked.maxerror,importance_probability=checked.probability,
            importance_weight=checked.expectedweight))
    end
    target
end
function main()
    isdir(OUT) && !isempty(readdir(OUT)) && error("Refusing to overwrite existing oracle artifacts")
    mkpath(OUT)
    open(joinpath(OUT,"provenance.txt"),"w") do io
        for path in (@__FILE__,joinpath(ROOT,"src/constrained_path_afqmc.jl"))
            println(io,path," sha256=",bytes2hex(sha256(read(path))))
        end
        println(io,"deterministic finite HS path enumeration; no walker simulation; atol=",ATOL)
    end
    results=NamedTuple[];info=NamedTuple[];history=NamedTuple[]
    @testset "Independent short HS path and BP oracle" begin
        for c in (("two_mode",[.13 -.8;-.8 -.21],4.,1,1,[.7,-.5],.15,4),
                  ("four_mode",[.12 -.8 .43 .21;-.8 -.13 -.6 .37;.43 -.6 .24 -.7;.21 .37 -.7 -.18],
                   8.,2,1,[.9,-.6,.4,-.8],.2,3))
            x=enumerate_case(c...)
            append!(results,x.rows);push!(info,x.info);append!(history,x.historyrows)
            writecsv("case_summary.csv",info);writecsv("estimator_comparison.csv",results)
            writecsv("history_checks.csv",history)
        end
        writecsv("target_history_checks.csv",target_checks())
    end
    println("Saved deterministic oracle to ",OUT)
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    CPBackpropOracle.main()
end
