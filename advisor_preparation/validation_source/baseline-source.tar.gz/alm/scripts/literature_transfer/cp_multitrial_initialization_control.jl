#!/usr/bin/env julia
"""Exact 20-term initial-importance-weight control; no CP integration."""
module CPMultitrialInitializationControl
using LinearAlgebra, Serialization, Test, SHA
include(joinpath(@__DIR__,"cp_multitrial_oracle.jl"))
const M=CPMultitrialOracle
const OUT=joinpath(M.ROOT,"results/literature_transfer/cp_multitrial_oracle/initialization_control")
const ATOL=2e-12 # 20-term Gram sums and 3136-component Float64 contractions.

function main()
    ispath(OUT) && error("Refusing to overwrite initialization control")
    source=deserialize(M.SOURCE)
    terms=source.terms
    coefficients=[t.coefficient/source.normalization for t in terms]
    gram=[det(a.up'*b.up)*det(a.down'*b.down) for a in terms,b in terms]
    overlaps=gram'*coefficients
    weights=coefficients.*overlaps
    ou=M.B.occupations(8,3)
    vectors=hcat((M.B.slater(t.up,t.down,ou,ou) for t in terms)...)
    trial=vectors*coefficients
    norms=sqrt.(max.(diag(gram),0.))
    relative=abs.(overlaps)./norms
    # Do not divide by a numerically unresolved overlap or silently discard it.
    resolvable=all(relative .> 1e-12)
    all_nonnegative=all(weights .>= 0.)
    reconstructed=resolvable ? sum(weights[i].*(vectors[:,i]./overlaps[i])
        for i in eachindex(weights)) : fill(NaN,length(trial))
    reconstruction_error=resolvable ? norm(reconstructed-trial) : NaN
    checks=@testset "Exact 20-term initial importance representation" begin
        @test maximum(abs,gram-gram')<ATOL
        @test maximum(abs,gram-vectors'*vectors)<ATOL
        @test maximum(abs,overlaps-vectors'*trial)<ATOL
        @test abs(dot(trial,trial)-1)<ATOL
        @test abs(sum(weights)-1)<ATOL
        @test abs(sum(weights)-dot(coefficients,gram*coefficients))<ATOL
        @test all(isfinite,weights)
        if resolvable
            @test reconstruction_error<ATOL
            @test abs(dot(trial,reconstructed)-1)<ATOL
        end
    end
    mkpath(OUT)
    M.writecsv(joinpath(OUT,"initial_weights.csv"),[
        (term=i,normalized_coefficient=coefficients[i],determinant_norm=norms[i],
         overlap_with_normalized_trial=overlaps[i],relative_overlap=relative[i],
         initial_importance_weight=weights[i],nonnegative=weights[i]>=0.,
         up_source_columns=join(terms[i].up_source_columns,";"),
         down_source_columns=join(terms[i].down_source_columns,";"))
        for i in eachindex(weights)])
    M.writecsv(joinpath(OUT,"gram_checks.csv"),[
        (term_bra=i,term_ket=j,determinant_gram=gram[i,j],
         fock_gram=dot(vectors[:,i],vectors[:,j]))
        for i in eachindex(weights) for j in eachindex(weights)])
    open(joinpath(OUT,"validation.txt"),"w") do io
        println(io,"tests=",Test.get_test_counts(checks))
        println(io,"absolute_tolerance=",ATOL)
        println(io,"sum_weights=",sum(weights))
        println(io,"minimum_weight=",minimum(weights))
        println(io,"maximum_weight=",maximum(weights))
        println(io,"negative_weight_count=",count(<(0.),weights))
        println(io,"exact_zero_weight_count=",count(iszero,weights))
        println(io,"minimum_relative_component_overlap=",minimum(relative))
        println(io,"all_weights_nonnegative=",all_nonnegative)
        println(io,"all_component_overlaps_resolved=",resolvable)
        println(io,"weighted_fock_reconstruction_error=",reconstruction_error)
        println(io,"representation_effective_component_count=",1/sum(abs2,weights))
        println(io,"max_gram_vs_fock_error=",maximum(abs,gram-vectors'*vectors))
        for path in (@__FILE__,M.SOURCE)
            println(io,path," sha256=",bytes2hex(sha256(read(path))))
        end
        println(io,"No components dropped. Positive initialization in expectation requires nonnegative weights and resolvable component overlaps.")
        println(io,"This does not establish finite-walker efficiency or modify the production initialization API.")
    end
    println("sum_weights=",sum(weights)," min_weight=",minimum(weights),
        " all_nonnegative=",all_nonnegative," reconstruction_error=",reconstruction_error)
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    CPMultitrialInitializationControl.main()
end
