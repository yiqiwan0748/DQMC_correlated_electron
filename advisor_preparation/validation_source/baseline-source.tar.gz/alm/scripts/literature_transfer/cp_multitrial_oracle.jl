#!/usr/bin/env julia
"""Tiny-particle multi-Slater numerator oracle; no CP integration or sampling."""
module CPMultitrialOracle
using LinearAlgebra, Serialization, Test, SHA, Printf
import AltermagnetDQMCTrial as CP
include(joinpath(@__DIR__,"cp_backprop_oracle.jl"))
const B=CPBackpropOracle
const ROOT=B.ROOT
const OUT=get(ENV,"CP_MULTITRIAL_OUTPUT",joinpath(ROOT,"results/literature_transfer/cp_multitrial_oracle/verified"))
const SOURCE=joinpath(ROOT,"results/literature_transfer/trial_symmetry_projection/full_singlet_am3_20_terms.jls")
const ATOL=2e-9 # Float64 exterior products on sectors no larger than 3136.
const CANCELLATION_TOL=1e-10 # Refuse ratios losing >10 decimal digits by cancellation.
const RELATIVE_OVERLAP_TOL=1e-12 # Relative to a Slater-norm triangle bound, not an absolute gauge.

function compensated_sum(xs)
    s=0.;c=0.
    for x in xs
        t=s+x;c+=abs(s)>=abs(x) ? (s-t)+x : (x-t)+s;s=t
    end
    s+c
end
minor(S,rows,cols)=isempty(rows) ? 1. : det(S[rows,cols])

"""Return unnormalized overlap, c†c and n_i n_j matrix elements.
Complementary minors are polynomials, so no inverse or component overlap
division is needed, even when rank(S)<N. Designed for tiny N, not optimized.
"""
function spin_numerators(L,R)
    size(L)==size(R) || throw(DimensionMismatch("Slater shapes differ"))
    M,N=size(L);S=L'*R;d=det(S)
    cofactor=zeros(N,N)
    for i in 1:N,j in 1:N
        cofactor[i,j]=(-1.)^(i+j)*minor(S,setdiff(1:N,[i]),setdiff(1:N,[j]))
    end
    one=R*cofactor'*L'
    pair=zeros(M,M)
    for i in 1:M;pair[i,i]=one[i,i];end
    if N>=2
        occupied_pairs=[(a,b) for a in 1:N for b in a+1:N]
        for i in 1:M,j in i+1:M
            terms=Float64[]
            for (a,b) in occupied_pairs,(c,dcol) in occupied_pairs
                sub=minor(S,setdiff(1:N,[a,b]),setdiff(1:N,[c,dcol]))
                lu=L[i,a]*L[j,b]-L[i,b]*L[j,a]
                rv=R[i,c]*R[j,dcol]-R[i,dcol]*R[j,c]
                push!(terms,(-1.)^(a+b+c+dcol)*sub*lu*rv)
            end
            pair[i,j]=pair[j,i]=compensated_sum(terms)
        end
    end
    singular_values=svdvals(S)
    relative_smin=isempty(singular_values) ? 1. :
        minimum(singular_values)/max(maximum(singular_values),floatmin(Float64))
    (;overlap=d,one,pair,relative_smin)
end

function component_numerators(problem,Lup,Ldn,Rup,Rdn,w)
    a=spin_numerators(Lup,Rup);b=spin_numerators(Ldn,Rdn)
    au=diag(a.one);bd=diag(b.one);du=a.overlap;dd=b.overlap
    overlap=du*dd
    kinetic=dd*tr(problem.kinetic*a.one)+du*tr(problem.kinetic*b.one)
    interaction=problem.U*sum((au.-du/2).*(bd.-dd/2))
    O=dot(w,dd.*au-du.*bd)/2
    # Opposite-spin n_i n_j factorizes before division, including singular terms.
    pair=dd.*a.pair+du.*b.pair-au*bd'-bd*au'
    O2=dot(w,pair*w)/4
    regular=min(a.relative_smin,b.relative_smin)>1e-7
    wick_error=NaN
    if regular && abs(overlap)>floatmin(Float64)
        cu=CP.transition_density_matrix(Lup,Rup);cd=CP.transition_density_matrix(Ldn,Rdn)
        e=CP._cp_local_energy_from_densities(problem,cu,cd)
        o=B.order_from_density(cu,cd,w)
        wick_error=maximum(abs,[(e.total*overlap)-(kinetic+interaction),
            o.mean*overlap-O,o.square*overlap-O2])
    end
    (;overlap,kinetic,interaction,energy=kinetic+interaction,O,O2,
     relative_smin=min(a.relative_smin,b.relative_smin),regular,wick_error)
end

"""Overlap-weighted multi-Slater numerator sum. Every term is retained.
There is only one final division, and it is refused at severe total overlap
cancellation. A negative but well-conditioned total overlap is supported.
"""
slater_norm(A)=sqrt(max(0.,det(A'*A)))
function multitrial_estimator(problem,terms,Rup,Rdn,w;cancellation_tol=CANCELLATION_TOL,
    relative_overlap_tol=RELATIVE_OVERLAP_TOL)
    components=[component_numerators(problem,t.up,t.down,Rup,Rdn,w) for t in terms]
    weighted_overlap=[t.coefficient*c.overlap for (t,c) in zip(terms,components)]
    total=compensated_sum(weighted_overlap);mass=sum(abs,weighted_overlap)
    ratio=iszero(mass) ? 0. : abs(total)/mass
    scale=slater_norm(Rup)*slater_norm(Rdn)*sum(abs(t.coefficient)*
        slater_norm(t.up)*slater_norm(t.down) for t in terms)
    relative_overlap=iszero(scale) ? 0. : abs(total)/scale
    numerator=NamedTuple{(:energy,:kinetic,:interaction,:O,:O2)}(Tuple(
        compensated_sum(t.coefficient*getproperty(c,k) for (t,c) in zip(terms,components))
        for k in (:energy,:kinetic,:interaction,:O,:O2)))
    status=iszero(total) ? "zero_total_overlap" : ratio<cancellation_tol ?
        "near_cancelled_total_overlap" : relative_overlap<relative_overlap_tol ?
        "near_zero_total_overlap" : "regular_total_overlap"
    values=status=="regular_total_overlap" ? map(x->x/total,numerator) : nothing
    exact_zero=count(c->iszero(c.overlap),components)
    illconditioned=count(c->c.relative_smin<=1e-12,components)
    errors=[c.wick_error for c in components if isfinite(c.wick_error)]
    (;status,total_overlap=total,absolute_overlap_mass=mass,cancellation_ratio=ratio,
      overlap_scale=scale,relative_total_overlap=relative_overlap,
      numerator,values,exact_zero_components=exact_zero,illconditioned_components=illconditioned,
      maximum_regular_wick_error=isempty(errors) ? NaN : maximum(errors),components)
end

function left_fock(terms,ou,od)
    vectors=[t.coefficient.*B.slater(t.up,t.down,ou,od) for t in terms]
    [compensated_sum(v[i] for v in vectors) for i in eachindex(first(vectors))]
end

function validate_case(name,problem,terms,Rup,Rdn,w)
    M=size(problem.kinetic,1);ou=B.occupations(M,problem.Nup);od=B.occupations(M,problem.Ndown)
    left=left_fock(terms,ou,od);right=B.slater(Rup,Rdn,ou,od)
    pairs=[(u,d) for u in ou for d in od]
    nu=[Float64(i in p[1]) for p in pairs,i in 1:M]
    nd=[Float64(i in p[2]) for p in pairs,i in 1:M]
    oval=(nu-nd)*w/2
    interaction=problem.U*vec(sum((nu.-.5).*(nd.-.5);dims=2))
    # Direct action in tensor-product Fock basis avoids a dense 3136² matrix.
    ku=B.one_spin_generator(problem.kinetic,ou);kd=B.one_spin_generator(problem.kinetic,od)
    matrix=reshape(right,length(od),length(ou))
    kinetic_right=vec(kd*matrix+matrix*ku')
    expected=(energy=dot(left,kinetic_right+interaction.*right),
        kinetic=dot(left,kinetic_right),interaction=dot(left,interaction.*right),
        O=dot(left,oval.*right),O2=dot(left,(oval.^2).*right))
    overlap=dot(left,right)
    observed=multitrial_estimator(problem,terms,Rup,Rdn,w)
    @test abs(observed.total_overlap-overlap)<ATOL*max(1.,abs(overlap))
    errors=Float64[]
    for key in keys(expected)
        error=abs(getproperty(observed.numerator,key)-getproperty(expected,key))
        push!(errors,error)
        @test error<ATOL*max(1.,abs(getproperty(expected,key)))
        if !isnothing(observed.values)
            @test abs(getproperty(observed.values,key)-getproperty(expected,key)/overlap)<
                20ATOL*max(1.,abs(getproperty(expected,key)/overlap))
        end
    end
    finite_wick=observed.maximum_regular_wick_error
    @test !isfinite(finite_wick) || finite_wick<20ATOL
    # Show why a tempting zero-component skip is wrong, without using it.
    retained=[(t,c) for (t,c) in zip(terms,observed.components) if c.relative_smin>1e-12]
    naiveE=sum(t.coefficient*c.energy for (t,c) in retained;init=0.)
    naiveO2=sum(t.coefficient*c.O2 for (t,c) in retained;init=0.)
    (case=name,terms=length(terms),status=observed.status,total_overlap=observed.total_overlap,
     fock_overlap=overlap,cancellation_ratio=observed.cancellation_ratio,
     relative_total_overlap=observed.relative_total_overlap,
     exact_zero_components=observed.exact_zero_components,
     illconditioned_components=observed.illconditioned_components,
     maximum_numerator_error=maximum(errors),maximum_regular_wick_error=finite_wick,
     energy=isnothing(observed.values) ? NaN : observed.values.energy,
     O=isnothing(observed.values) ? NaN : observed.values.O,
     O2=isnothing(observed.values) ? NaN : observed.values.O2,
     dropped_singular_energy_numerator_error=naiveE-expected.energy,
     dropped_singular_O2_numerator_error=naiveO2-expected.O2)
end

function writecsv(path,rows)
    open(path,"w") do io
        println(io,join(string.(keys(first(rows))),','))
        for r in rows;println(io,join(string.(values(r)),','));end
    end
end
function main()
    ispath(OUT) && error("Refusing to overwrite multitrial oracle outputs")
    mkpath(OUT);rows=NamedTuple[]
    checks=@testset "Multi-Slater cofactor and Fock oracle" begin
        K=[.12 -.8 .43 .21;-.8 -.13 -.6 .37;.43 -.6 .24 -.7;.21 .37 -.7 -.18]
        problem=CP.CPAFQMCProblem(K,8.,2,1)
        Q=[1. 1. 1. 1.;1. -1. 1. -1.;1. 1. -1. -1.;1. -1. -1. 1.]/2
        u=Q[:,1:2];d=Q[:,1:1];su=Q[:,[1,3]];sd=Q[:,2:2]
        regular=(coefficient=1.,up=u,down=d)
        w=[.8,-1.1,.4,.6]
        cases=(("regular",[regular]),
            ("singular_up",[regular,(coefficient=.4,up=su,down=d)]),
            ("singular_both",[regular,(coefficient=.7,up=su,down=sd)]),
            ("negative_total",[(coefficient=-1.,up=u,down=d),(coefficient=.4,up=su,down=d)]),
            ("exact_zero_total",[(coefficient=1.,up=su,down=d)]),
            ("near_cancelled_total",[regular,(coefficient=-sqrt(2.)*(1-1e-14),
                up=hcat(Q[:,1],(Q[:,2]+Q[:,3])/sqrt(2.)),down=d)]))
        for (name,terms) in cases
            push!(rows,validate_case(name,problem,terms,u,d,w))
        end
        @test rows[2].exact_zero_components==1
        @test abs(rows[2].dropped_singular_energy_numerator_error)>1e-4
        @test abs(rows[3].dropped_singular_O2_numerator_error)>1e-4
        @test rows[4].total_overlap<0 && rows[4].status=="regular_total_overlap"
        @test rows[5].status=="zero_total_overlap"
        @test rows[6].status=="near_cancelled_total_overlap"

        exported=deserialize(SOURCE)
        terms=[(coefficient=t.coefficient/exported.normalization,up=t.up,down=t.down)
            for t in exported.terms]
        K=B.TwoOrbitalOpenClusterED.open_cluster_kinetic_matrix(2,2)
        problem=CP.CPAFQMCProblem(K,12.,3,3;lattice_size=2,cell_count=4)
        ou=B.occupations(8,3);od=ou
        exact=left_fock(terms,ou,od)
        @test abs(norm(exact)-1)<ATOL
        w=repeat([1.,-1.],4)
        for h in (0.,.5,3.,-3.,6.)
            trial=CP.one_body_trial(problem;pattern=:altermagnetic,field_strength=h)
            push!(rows,validate_case("singlet20_AM$(h)",problem,terms,trial.up,trial.down,w))
        end
        @test rows[7].status!="regular_total_overlap"
        @test rows[8].status!="regular_total_overlap"
        selected=deserialize(joinpath(ROOT,"results/literature_transfer/trial_symmetry_projection/selected_restricted_trial.jls"))
        push!(rows,validate_case("singlet20_restricted",problem,terms,selected.up,selected.down,w))
        # Nonorthogonal spin-resolved propagated walkers, not only trial extrema.
        am=CP.one_body_trial(problem;pattern=:altermagnetic,field_strength=3.)
        for k in 1:3
            field=[sin(i*(k+.3)) for i in 1:8]
            u=exp(Symmetric(-.1K-Diagonal(field)))*am.up
            d=exp(Symmetric(-.1K+Diagonal(field)))*am.down
            push!(rows,validate_case("singlet20_propagated$(k)",problem,terms,u,d,w))
        end
    end
    writecsv(joinpath(OUT,"estimator_checks.csv"),rows)
    open(joinpath(OUT,"validation.txt"),"w") do io
        println(io,"tests=",Test.get_test_counts(checks))
        println(io,"absolute_tolerance=",ATOL)
        println(io,"total_cancellation_threshold=",CANCELLATION_TOL)
        println(io,"relative_overlap_threshold=",RELATIVE_OVERLAP_TOL)
        println(io,"No component discarded; inverse-free complementary minors; no CP integration.")
        for file in (@__FILE__,SOURCE,joinpath(@__DIR__,"cp_backprop_oracle.jl"),joinpath(ROOT,"src/constrained_path_afqmc.jl"))
            println(io,file," sha256=",bytes2hex(sha256(read(file))))
        end
    end
    println("Saved ",length(rows)," deterministic cases to ",OUT)
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    CPMultitrialOracle.main()
end
