#!/usr/bin/env julia
# Deserialize the original concrete type in its original module namespace.
# The driver's PROGRAM_FILE guard prevents any scientific chain from running.
if !isdefined(Main,:RunMultiSlaterBenchmark)
    Base.include(Main,joinpath(@__DIR__,"run_multislater_benchmark.jl"))
end
module CPPopulationStateAudit
using LinearAlgebra, SparseArrays, Serialization, SHA, Test, Printf
const RUN=Main.RunMultiSlaterBenchmark
const MC=RUN.MC
const ED=RUN.ED
const BASE=joinpath(@__DIR__,"..","..","results","literature_transfer")
const INPUT=joinpath(BASE,"multislater_cp_benchmark")
const OUT=joinpath(BASE,"cp_population_state_audit")
const TOL=2e-8 # Accumulated Float64 Fock sums and local-estimator comparisons.

function digest(value)
    buffer=IOBuffer();serialize(buffer,value);bytes2hex(sha256(take!(buffer)))
end
function fock(up,down,occupied)
    du=[det(up[I,:]) for I in occupied]
    dd=[det(down[I,:]) for I in occupied]
    kron(du,dd)
end
function spin_raise(basis)
    target=ED.sector_basis(8,4,2)
    lookup=Dict((u,d)=>(i-1)*length(target.down_states)+j for (i,u) in enumerate(target.up_states) for (j,d) in enumerate(target.down_states))
    rows,cols,vals=Int[],Int[],Float64[];column=0
    for u in basis.up_states,d in basis.down_states
        column+=1;s=u|(d<<8)
        for a in 0:7
            ub=UInt64(1)<<a;db=UInt64(1)<<(a+8)
            (iszero(s&db)||!iszero(s&ub)) && continue
            middle=s⊻db;parity=count_ones(s&(db-1))+count_ones(middle&(ub-1))
            final=middle|ub
            push!(rows,lookup[(final&0xff,final>>8)]);push!(cols,column);push!(vals,iseven(parity) ? 1.0 : -1.0)
        end
    end
    sparse(rows,cols,vals,length(target),length(basis))
end
function add_compensated!(sumvec,correction,x)
    for i in eachindex(sumvec)
        y=x[i]-correction[i];total=sumvec[i]+y
        correction[i]=(total-sumvec[i])-y;sumvec[i]=total
    end
end
function write_csv(path,rows)
    open(path,"w") do io
        println(io,join(string.(keys(first(rows))),","))
        for row in rows
            println(io,join((x isa AbstractFloat ? @sprintf("%.17g",x) : string(x) for x in values(row)),","))
        end
    end
end
function logged_energy(directory,step)
    path=joinpath(directory,"samples.csv")
    isfile(path) || return missing
    lines=readlines(path);length(lines)>=2 || return missing
    columns=split(lines[1],',');istep=findfirst(==("step"),columns);iE=findfirst(==("E"),columns)
    for line in Iterators.reverse(lines[2:end])
        cells=split(replace(line,"\""=>""),',')
        parse(Int,cells[istep])==step && return parse(Float64,cells[iE])
    end
    missing
end

function reconstruct(state,op,occupied,raising,E,V)
    trial=zeros(length(op.basis));comp=zeros(length(trial))
    for t in state.trial.terms
        add_compensated!(trial,comp,t.coefficient.*fock(t.up,t.down,occupied))
    end
    @test abs(norm(trial)-1)<TOL
    trial./=norm(trial)
    live=[w for w in state.walkers if w.alive]
    maxlog=maximum(w.log_weight for w in live)
    weights=[exp(w.log_weight-maxlog) for w in live]
    represented=zeros(length(trial));fill!(comp,0)
    mc_mixed=0.0;direct_local_mixed=0.0;overlap_error=0.0
    min_overlap=Inf;sum_component_norms=0.0
    # This disposable copy receives only estimator diagnostic counters. Neither
    # state, its RNG/history, nor any serialized checkpoint is changed.
    monitor=deepcopy(state)
    rng_before=digest(monitor.rng)
    for (w,weight) in zip(live,weights)
        phi=fock(w.up,w.down,occupied)
        overlap=dot(trial,phi)
        @test overlap>0
        min_overlap=min(min_overlap,overlap/norm(phi))
        term=weight.*phi./overlap
        add_compensated!(represented,comp,term)
        sum_component_norms+=norm(term)
        direct_local_mixed+=weight*dot(trial,op*phi)/overlap
        # Exactly the mixed-energy branch of MC.measure, with no back
        # propagation, measurement call, random draw, or propagation step.
        production=MC.estimator(monitor,monitor.trial.terms,w.up,w.down)
        mc_mixed+=weight*(production.kinetic+production.interaction)
        actual_overlap=MC.total_overlap(monitor.trial.terms,w.up,w.down).total
        overlap_error=max(overlap_error,abs(overlap-actual_overlap)/max(abs(overlap),1e-300))
    end
    @test digest(monitor.rng)==rng_before
    @test monitor.step==state.step && monitor.measurement_count==state.measurement_count
    @test overlap_error<TOL
    @test abs(dot(trial,represented)-sum(weights))<TOL*sum(weights)
    normket=norm(represented);ket=represented/normket
    mixed=dot(trial,op*ket)/dot(trial,ket)
    production_mixed=mc_mixed/sum(weights)
    @test abs(mixed-production_mixed)<TOL
    @test abs(mixed-direct_local_mixed/sum(weights))<TOL
    variational=dot(ket,op*ket)
    coefficients=V'*ket
    @test abs(sum(abs2,coefficients)-1)<TOL
    @test abs(variational-dot(abs2.(coefficients),E))<TOL
    @test variational>=E[1]-TOL
    fidelity=abs2(coefficients[1])
    @test variational-E[1]>=(1-fidelity)*(E[2]-E[1])-TOL
    O=op.oalm_values
    meanO=dot(abs2.(ket),O);S=dot(abs2.(ket),O.^2)/4
    spin2=sum(abs2,raising*ket)
    SS=raising'*raising
    spins=0:3;values=[s*(s+1) for s in spins];spinweights=[];components=[]
    for i in eachindex(values)
        p=copy(ket)
        for j in eachindex(values)
            i==j && continue
            p=(SS*p-values[j]*p)/(values[i]-values[j])
        end
        @test norm(SS*p-values[i]*p)<TOL
        push!(components,p);push!(spinweights,sum(abs2,p))
    end
    @test norm(sum(components)-ket)<TOL
    @test abs(sum(spinweights)-1)<TOL
    @test abs(dot(values,spinweights)-spin2)<TOL
    (;live_walkers=length(live),mixed_energy_fock=mixed,mixed_energy_production=production_mixed,
      mixed_energy_error=mixed-E[1],variational_energy=variational,
      variational_energy_error=variational-E[1],ground_overlap_squared=fidelity,
      pure_S_odd_q0=S,pure_Delta=meanO/4,pure_connected_S_odd_q0=S-meanO^2/4,
      total_spin_squared=spin2,spin0_weight=spinweights[1],spin1_weight=spinweights[2],
      spin2_weight=spinweights[3],spin3_weight=spinweights[4],
      trial_overlap_squared=abs2(dot(trial,ket)),
      minimum_normalized_walker_trial_overlap=min_overlap,
      coherent_sum_norm_over_triangle_bound=normket/sum_component_norms,
      maximum_relative_walker_overlap_error=overlap_error,
      represented_ket_norm=normket,total_scaled_importance_weight=sum(weights))
end

function main()
    mkpath(OUT)
    cache=deserialize(joinpath(BASE,"trial_symmetry_projection","u12_complete_spectrum.jls"))
    op=ED.sector_hamiltonian(cache.K,12.,3,3)
    occupied=[[a for a in 1:8 if !iszero(s&(UInt64(1)<<(a-1)))] for s in op.basis.up_states]
    raising=spin_raise(op.basis)
    records=[];seen=Dict{String,String}()
    for profile in ("baseline","dt_half","population","history"),seed in (61423,72539),stage in ("warmup","final")
        directory=joinpath(INPUT,"$(profile)_seed$(seed)_initial")
        path=joinpath(directory,stage*"_checkpoint.jls")
        isfile(path) || continue
        hash=bytes2hex(sha256(read(path)))
        state=deserialize(path)
        @test state.problem.kinetic==cache.K && state.problem.U==12.
        @test state.problem.Nup==state.problem.Ndown==3
        name="$(profile)_seed$(seed)_$(stage)"
        # Deliberately exclude history and RNG: only the endpoint population,
        # its exact weights and trial determine this instantaneous ket.
        fingerprint=digest((state.step,state.parameters.dtau,state.trial.terms,
                             [(w.alive,w.log_weight,w.up,w.down) for w in state.walkers]))
        if haskey(seen,fingerprint)
            previous=only(filter(r->r.name==seen[fingerprint],records))
            row=merge(previous,(name=name,profile=profile,checkpoint_stage=stage,
                      checkpoint_path=abspath(path),checkpoint_sha256=hash,
                      bp_lag=state.parameters.back_propagation_steps*state.parameters.dtau,
                      duplicate_of=seen[fingerprint]))
        else
            resultpath=joinpath(OUT,name*".jls")
            if isfile(resultpath)
                row=deserialize(resultpath)
                @test row.checkpoint_sha256==hash
            else
                result=reconstruct(state,op,occupied,raising,cache.energies,cache.vectors)
                logged=logged_energy(directory,state.step)
                !ismissing(logged) && (@test abs(logged-result.mixed_energy_production)<TOL)
                row=merge((name=name,profile=profile,seed=seed,checkpoint_stage=stage,
                     checkpoint_path=abspath(path),checkpoint_sha256=hash,duplicate_of="none",
                     step=state.step,beta=state.step*state.parameters.dtau,dtau=state.parameters.dtau,
                     bp_lag=state.parameters.back_propagation_steps*state.parameters.dtau,
                     planned_walkers=state.parameters.walker_count,logged_energy=logged),result)
                serialize(resultpath,row)
            end
            seen[fingerprint]=name
        end
        @test bytes2hex(sha256(read(path)))==hash
        push!(records,row)
        println(name,": E_mix=",row.mixed_energy_fock," E_var=",row.variational_energy,
                " GSweight=",row.ground_overlap_squared," S=",row.pure_S_odd_q0,
                " Delta=",row.pure_Delta," duplicate=",row.duplicate_of);flush(stdout)
    end
    isempty(records) && error("No requested checkpoints available")
    write_csv(joinpath(OUT,"population_state_summary.csv"),records)
end

if abspath(PROGRAM_FILE)==@__FILE__
    old=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        @testset "Instantaneous CP population ket audit" main()
    finally
        BLAS.set_num_threads(old)
    end
end
end
