#!/usr/bin/env julia
module CPProjectionConvergence
using AltermagnetDQMCTrial
using LinearAlgebra, SHA, Test, Printf, DelimitedFiles
include(joinpath(@__DIR__,"cp_trial_audit.jl"))
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const OUT=joinpath(ROOT,"results/literature_transfer/cp_projection_convergence")
const K=CPTrialAudit.K
const SEEDS=(17431,28547)
const LOADED_DRIVER_SHA=bytes2hex(sha256(read(@__FILE__)))

function controls(warm,lag,seed,walkers=256)
    return CPAFQMCParameters(dtau=.01,walker_count=walkers,
        warmup_steps=round(Int,warm/.01),measurement_count=160,
        steps_between_measurements=10,back_propagation_steps=round(Int,lag/.01),
        orthogonalize_every=5,population_control_every=5,overlap_refresh_every=16,
        minimum_backprop_ancestors=2,error_block_size=10,seed=seed)
end

function trial_for(problem,label,orbital_file)
    if label=="am3"
        return one_body_trial(problem;pattern=:altermagnetic,field_strength=3.0)
    end
    isnothing(orbital_file) && error("A screened custom trial requires its orbital matrix file")
    orbitals=Matrix{Float64}(readdlm(orbital_file,','))
    size(orbitals)==(8,6) || error("Custom trial CSV must contain up/down 8x3 matrices concatenated")
    up,down=orbitals[:,1:3],orbitals[:,4:6]
    @test isapprox(up'*up,Matrix{Float64}(I,3,3);atol=2e-10,rtol=0)
    @test isapprox(down'*down,Matrix{Float64}(I,3,3);atol=2e-10,rtol=0)
    return SlaterTrial(up,down;label=label)
end

function record(m,o,dt)
    return (step=m.step,beta=m.step*dt,E=m.mixed_total_energy,
        mixed_K=m.mixed_kinetic_energy,mixed_V=m.mixed_interaction_energy,
        mixed_D=m.mixed_double_occupancy_per_cell,
        bp_E=m.backpropagated_total_energy,bp_K=m.backpropagated_kinetic_energy,
        bp_V=m.backpropagated_interaction_energy,bp_D=m.backpropagated_double_occupancy_per_cell,
        S_alm=m.S_alm_q0,S_fm=m.S_fm_q0,Delta=o.delta_alm,
        mx=o.mx,my=o.my,ancestors=m.distinct_backprop_ancestors)
end

function run_chain(label,warm,lag,seed,orbital_file=nothing,walkers=256)
    suffix=walkers==256 ? "" : "_nw$(walkers)"
    name="$(label)_w$(Int(warm))_b$(Int(lag))$(suffix)_seed$(seed)"
    out=joinpath(OUT,name)
    ispath(out) && error("Refusing to overwrite $out")
    mkpath(out)
    c=controls(warm,lag,seed,walkers)
    p=CPAFQMCProblem(K,12.0,3,3;lattice_size=2,cell_count=4)
    trial=trial_for(p,label,orbital_file)
    open(joinpath(out,"metadata.txt"),"w") do io
        println(io,"Hamiltonian=centered U-only; U=12; boundary=open; L=2; Nup=Ndown=3; density=1.5")
        println(io,"trial=",label,"; projected_trial_field=none")
        for k in fieldnames(typeof(c));println(io,k,"=",getfield(c,k));end
        println(io,"driver_sha256=",LOADED_DRIVER_SHA)
        for (key,path) in (("trial_helper",joinpath(@__DIR__,"cp_trial_audit.jl")),
                          ("solver",joinpath(ROOT,"src/constrained_path_afqmc.jl")),
                          ("preregistered_scope",joinpath(OUT,"preregistered_plan.md")))
            println(io,key,"_sha256=",bytes2hex(sha256(read(path))))
        end
        if !isnothing(orbital_file)
            println(io,"orbital_file=",abspath(orbital_file))
            println(io,"orbital_file_sha256=",bytes2hex(sha256(read(orbital_file))))
        end
        if walkers!=256
            adaptation=joinpath(OUT,"population_adaptation.md")
            println(io,"adaptation_sha256=",bytes2hex(sha256(read(adaptation))))
        end
        println(io,"julia_version=",VERSION)
        println(io,"diagnostic_screen=5percent_S;absolute_Delta_.05;two_SE_margin;unchanged_production_gates")
    end
    state=initialize_cp_afqmc(p,c;trial=trial)
    ms=CPAFQMCMeasurement{Float64}[];os=NamedTuple[];rows=NamedTuple[]
    started=time()
    try
        for _ in 1:c.warmup_steps;step_cp_afqmc!(state);end
        open(joinpath(out,"samples.csv"),"w") do io
            for j in 1:c.measurement_count
                for _ in 1:c.steps_between_measurements;step_cp_afqmc!(state);end
                s=measure_cp_afqmc(state;include_order=true)
                push!(ms,s.measurement);push!(os,s.order_measurement)
                row=record(s.measurement,s.order_measurement,c.dtau);push!(rows,row)
                j==1 && println(io,join(string.(keys(row)),','))
                println(io,join(CPTrialAudit.csv.(values(row)),','));flush(io)
            end
        end
        result=finish_cp_afqmc(state,ms;order_measurements=os)
        CPTrialAudit.write_rows(joinpath(out,"summary.csv"),[(quantity=string(k),value=v)
            for (k,v) in pairs(result.summary) if v isa Number || v isa Missing])
        open(joinpath(out,"diagnostics.txt"),"w") do io
            println(io,"runtime_seconds=",time()-started)
            for (key,value) in pairs(result.diagnostics);println(io,key,"=",value);end
        end
        @testset "$name deterministic identities" begin
            @test isapprox(result.summary.density,1.5;atol=1e-12,rtol=0)
            @test maximum(abs(r.E-r.mixed_K-r.mixed_V) for r in rows)<2e-10
            @test maximum(abs(r.bp_E-r.bp_K-r.bp_V) for r in rows)<2e-10
            @test maximum(abs(r.bp_V-12*(4r.bp_D-1)) for r in rows)<2e-9
            @test maximum(abs(r.S_fm) for r in rows)<2e-9
        end
        write(joinpath(out,"status.txt"),"COMPLETED; scientific screen assessed separately\n")
        s=result.summary
        @printf("%s %.2fs E=%.9f +/- %.6f S=%.7f +/- %.6f Delta=%.6f\n",
            name,time()-started,s.energy,s.energy_standard_error,s.S_alm_q0,
            s.S_alm_q0_standard_error,s.delta_alm);flush(stdout)
    catch err
        open(joinpath(out,"status.txt"),"w") do io
            println(io,"FAILED; all successful-prefix samples retained")
            showerror(io,err,catch_backtrace());println(io)
        end
        rethrow()
    finally
        open(joinpath(out,"completion.txt"),"w") do io
            println(io,"valid_measurements=",length(rows))
            println(io,"planned_measurements=",c.measurement_count)
            println(io,"valid_fraction=",length(rows)/c.measurement_count)
            println(io,"last_step=",state.step)
            println(io,"elapsed_seconds=",time()-started)
        end
    end
end

function main(args=ARGS)
    label=isempty(args) ? "am3" : args[1]
    warm=length(args)>=2 ? parse(Float64,args[2]) : 48.0
    lag=length(args)>=3 ? parse(Float64,args[3]) : 4.0
    orbital_file=length(args)>=4 ? args[4] : nothing
    walkers=length(args)>=5 ? parse(Int,args[5]) : 256
    warm in (16.0,48.0) || error("Warmup outside the initial registered grid")
    lag in (4.0,12.0) || error("BP lag outside the initial registered grid")
    walkers in (256,1024) || error("Walker population outside the bounded adaptation")
    walkers!=256 && (label!="qr26" || warm!=16 || lag!=4) &&
        error("The population-only adaptation is specific to QR26 warm16/BP4")
    for seed in SEEDS;run_chain(label,warm,lag,seed,orbital_file,walkers);end
end
if abspath(PROGRAM_FILE)==@__FILE__;main();end
end
