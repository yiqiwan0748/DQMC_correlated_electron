#!/usr/bin/env python3
"""Report isolated CP time/lag controls; uses only Python's standard library.

Only full, explicitly completed chains enter observable pools. Every run,
including a failed or incomplete one, remains in measurement_health.csv.
Scientific screening outcomes never replace production validation gates.
"""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics as stats

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results/literature_transfer/cp_projection_convergence"
EXACT = ROOT / "results/literature_transfer/trial_symmetry_projection/exact_schedule_controls.csv"
GROUND = ROOT / "results/literature_transfer/ed_estimator_audit/reference.csv"
BLOCKS = (5, 10, 20, 40)
SOLVER = ROOT / "src/constrained_path_afqmc.jl"
TRIAL_HELPER = ROOT / "scripts/literature_transfer/cp_trial_audit.jl"
LABELS = {"am3": "AM_3.0", "qr26": "restricted_qr_26"}
EXACT_COLUMNS = {"E": "exact_mixed_energy", "bp_E": "exact_mixed_energy", "S_alm": "exact_BP_S_odd_q0",
                 "Delta": "exact_BP_Delta"}


def read(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def write(name, rows):
    if not rows:
        return
    with (OUT / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def attributes(path):
    if not path.exists():
        return {}
    return dict(x.split("=", 1) for x in path.read_text().splitlines() if "=" in x)


def block_se(values, block):
    assert len(values) % block == 0
    means = [stats.mean(values[i:i + block]) for i in range(0, len(values), block)]
    assert len(means) >= 4, "At least four complete blocks required"
    return stats.stdev(means) / math.sqrt(len(means))


def selected_se(values):
    return max(block_se(values, b) for b in BLOCKS if len(values) // b >= 4)


def pool(centers, errors):
    within = math.sqrt(sum(e * e for e in errors)) / len(errors)
    between = stats.stdev(centers) / math.sqrt(len(centers)) if len(centers) > 1 else 0.0
    return stats.mean(centers), max(within, between), within, between


ground_row = next(r for r in read(GROUND) if float(r["U"]) == 12.0)
assert (int(ground_row["Nup"]), int(ground_row["Ndown"])) == (3, 3)
reference = dict(E=float(ground_row["energy"]), bp_E=float(ground_row["energy"]),
                 bp_K=float(ground_row["kinetic_energy"]),
                 bp_D=float(ground_row["double_occupancy_per_cell"]),
                 S_alm=float(ground_row["S_odd_q0"]), Delta=0.0)
reference["bp_V"] = reference["E"] - reference["bp_K"]
tolerances = dict(E=0.02, S_alm=0.05 * reference["S_alm"], Delta=0.05)
exact_rows = read(EXACT)
exact_schedules = {}
for row in exact_rows:
    exact_schedules.setdefault((row["label"], row["schedule"]), []).append(row)

health, per_run, blocking, time_drift = [], [], [], []
samples_by_key = {}
for directory in sorted(OUT.iterdir()):
    match = re.fullmatch(r"(.+)_w(\d+)_b(\d+)(?:_nw(\d+))?_seed(\d+)", directory.name)
    if not directory.is_dir() or not match:
        continue
    label, warm, lag, named_walkers, seed = match.groups()
    warm, lag, seed = int(warm), int(lag), int(seed)
    metadata = attributes(directory / "metadata.txt")
    assert metadata["solver_sha256"] == hashlib.sha256(SOLVER.read_bytes()).hexdigest()
    assert metadata["trial_helper_sha256"] == hashlib.sha256(TRIAL_HELPER.read_bytes()).hexdigest()
    walkers = int(metadata["walker_count"])
    assert walkers == (int(named_walkers) if named_walkers else 256)
    diagnostics = attributes(directory / "diagnostics.txt")
    completion = attributes(directory / "completion.txt")
    status_path = directory / "status.txt"
    status = status_path.read_text().splitlines()[0] if status_path.exists() else "RUNNING_OR_NO_FINAL_STATUS"
    samples = read(directory / "samples.csv") if (directory / "samples.csv").exists() else []
    ancestors = [int(s["ancestors"]) for s in samples]
    planned = int(metadata["measurement_count"])
    included = status.startswith("COMPLETED") and len(samples) == planned
    health.append(dict(run=directory.name, status=status, included_in_pool=included, walkers=walkers,
                       saved_valid_measurements=len(samples), planned_measurements=planned,
                       valid_saved_fraction=len(samples) / planned,
                       minimum_distinct_ancestors=min(ancestors) if ancestors else "",
                       median_distinct_ancestors=stats.median(ancestors) if ancestors else "",
                       maximum_distinct_ancestors=max(ancestors) if ancestors else "",
                       elapsed_seconds=completion.get("elapsed_seconds", ""),
                       constraint_rejections=diagnostics.get("constraint_rejections", ""),
                       overlap_inverse_failures=diagnostics.get("overlap_inverse_failures", ""),
                       maximum_overlap_condition=diagnostics.get("maximum_overlap_condition", ""),
                       note="ancestry counts are not a weighted effective sample size"))
    if not included:
        continue
    assert len(samples) == 160
    assert float(metadata["dtau"]) == 0.01 and walkers in (256, 1024)
    assert int(metadata["warmup_steps"]) == warm * 100
    assert int(metadata["back_propagation_steps"]) == lag * 100
    assert int(metadata["seed"]) == seed
    schedule = f"warm{warm}_b{lag}"
    exact = exact_schedules[(LABELS[label], schedule)]
    assert len(exact) == len(samples)
    assert max(abs(float(a["beta"]) - float(b["beta"])) for a, b in zip(samples, exact)) < 2e-12
    assert all(abs(float(r["back_propagation_lag"]) - lag) < 1e-12 for r in exact)
    samples_by_key[(label, warm, lag, walkers, seed)] = samples
    for quantity, ground in reference.items():
        values = [float(r[quantity]) for r in samples]
        assert all(math.isfinite(v) for v in values)
        errors = {b: block_se(values, b) for b in BLOCKS}
        exact_values = [float(r[EXACT_COLUMNS[quantity]]) for r in exact] if quantity in EXACT_COLUMNS else None
        finite = stats.mean(exact_values) if exact_values is not None else ""
        center = stats.mean(values)
        per_run.append(dict(run=directory.name, trial=label, warmup=warm, bp_lag=lag, walkers=walkers,
                            seed=seed, samples=len(values), quantity=quantity,
                            estimate=center, standard_error=max(errors.values()),
                            exact_ground=ground, ground_error=center - ground,
                            exact_finite_history=finite,
                            finite_history_offset=finite - ground if finite != "" else "",
                            cp_minus_exact_finite_history=center - finite if finite != "" else ""))
        for b, error in errors.items():
            blocking.append(dict(run=directory.name, quantity=quantity, block_size=b,
                                 block_count=len(values) // b, standard_error=error))
        if exact_values is not None:
            half = len(values) // 2
            time_drift.append(dict(run=directory.name, quantity=quantity,
                                   second_half_minus_first_half=stats.mean(values[half:]) - stats.mean(values[:half]),
                                   exact_second_half_minus_first_half=stats.mean(exact_values[half:]) - stats.mean(exact_values[:half]),
                                   note="descriptive drift; correlated finite history, not an independent hypothesis test"))

groups = {}
for row in per_run:
    groups.setdefault((row["trial"], row["warmup"], row["bp_lag"], row["walkers"], row["quantity"]), []).append(row)
pooled = []
for (label, warm, lag, walkers, quantity), rows in sorted(groups.items()):
    assert len(set(r["seed"] for r in rows)) == len(rows)
    center, error, within, between = pool([r["estimate"] for r in rows], [r["standard_error"] for r in rows])
    ground, finite = rows[0]["exact_ground"], rows[0]["exact_finite_history"]
    assert all(r["exact_finite_history"] == finite for r in rows)
    pooled.append(dict(trial=label, warmup=warm, bp_lag=lag, walkers=walkers, quantity=quantity,
                       seeds=";".join(str(r["seed"]) for r in rows), seed_count=len(rows),
                       estimate=center, standard_error=error, within_seed_standard_error=within,
                       between_seed_standard_error=between, exact_ground=ground,
                       ground_error=center - ground, exact_finite_history=finite,
                       finite_history_offset=finite - ground if finite != "" else "",
                       cp_minus_exact_finite_history=center - finite if finite != "" else ""))
index = {(r["trial"], r["warmup"], r["bp_lag"], r["walkers"], r["quantity"]): r for r in pooled}

screens = []
for (label, warm, lag, walkers, quantity), row in sorted(index.items()):
    if quantity not in tolerances:
        continue
    tolerance = tolerances[quantity]
    for margin in (2, 3):
        supported = margin == 3 or quantity != "E"
        error_budget = abs(row["ground_error"]) + margin * row["standard_error"]
        screens.append(dict(trial=label, warmup=warm, bp_lag=lag, walkers=walkers, quantity=quantity,
                            SE_multiplier=margin, registered=supported, tolerance=tolerance,
                            absolute_error_plus_margin=error_budget,
                            arm_screen="PASS" if error_budget <= tolerance else "FAIL",
                            seed_count=row["seed_count"],
                            interpretation="finite-arm diagnostic only; independent convergence still required"))

# Same-seed lag pairs use the identical projection stream. Warmup comparisons
# use different sections of that stream, and candidate endpoints can vary both
# controls. Keep these three meanings separate.
contrasts = []
for label, walkers in sorted({(k[0], k[3]) for k in samples_by_key}):
    for wa, ba, wb, bb, kind in ((16, 4, 16, 12, "lag_only"),
                               (48, 4, 48, 12, "lag_only"),
                               (16, 4, 48, 4, "projection_only"),
                               (16, 12, 48, 12, "projection_only"),
                               (16, 4, 48, 12, "compound_endpoint")):
        seeds_a = {k[4] for k in samples_by_key if k[:4] == (label, wa, ba, walkers)}
        seeds_b = {k[4] for k in samples_by_key if k[:4] == (label, wb, bb, walkers)}
        for quantity in tolerances:
            shifts, errors, exact_shifts = [], [], []
            for seed in sorted(seeds_a & seeds_b):
                a = samples_by_key[(label, wa, ba, walkers, seed)]
                b = samples_by_key[(label, wb, bb, walkers, seed)]
                assert len(a) == len(b)
                differences = [float(y[quantity]) - float(x[quantity]) for x, y in zip(a, b)]
                if kind == "lag_only":
                    assert [r["step"] for r in a] == [r["step"] for r in b]
                    if quantity == "E":
                        assert max(abs(v) for v in differences) < 2e-12, "BP lag changed mixed propagation"
                shifts.append(stats.mean(differences))
                # Separated windows share a trajectory. Keep both the zero-
                # covariance estimate and the observed paired-block estimate;
                # negative cross-window covariance can increase the latter.
                error = (selected_se(differences) if kind == "lag_only" else
                         max(selected_se(differences),
                             math.hypot(selected_se([float(r[quantity]) for r in a]),
                                        selected_se([float(r[quantity]) for r in b]))))
                errors.append(error)
                source_a = index[(label, wa, ba, walkers, quantity)]["exact_finite_history"]
                source_b = index[(label, wb, bb, walkers, quantity)]["exact_finite_history"]
                exact_shifts.append(source_b - source_a)
            if not shifts:
                continue
            center, error, within, between = pool(shifts, errors)
            contrasts.append(dict(trial=label, control=kind, warmup_from=wa, lag_from=ba,
                                  warmup_to=wb, lag_to=bb, walkers_from=walkers, walkers_to=walkers, quantity=quantity,
                                  seed_count=len(shifts), cp_shift=center, standard_error=error,
                                  exact_finite_history_shift=stats.mean(exact_shifts),
                                  cp_shift_minus_exact_shift=center - stats.mean(exact_shifts),
                                  within_seed_standard_error=within,
                                  between_seed_standard_error=between,
                                  interpretation="does not independently identify either control" if kind == "compound_endpoint" else "independent control at fixed dt and population"))

# Population controls reuse seed IDs, but a changed walker count consumes the
# RNG differently. These are not matched streams and receive independent errors.
for label, warm, lag in sorted({k[:3] for k in samples_by_key}):
    for quantity in tolerances:
        a = index.get((label, warm, lag, 256, quantity))
        b = index.get((label, warm, lag, 1024, quantity))
        if a is None or b is None:
            continue
        assert a["exact_finite_history"] == b["exact_finite_history"]
        contrasts.append(dict(trial=label, control="population_only", warmup_from=warm, lag_from=lag,
                              warmup_to=warm, lag_to=lag, walkers_from=256, walkers_to=1024,
                              quantity=quantity, seed_count=min(a["seed_count"], b["seed_count"]),
                              cp_shift=b["estimate"] - a["estimate"],
                              standard_error=math.hypot(a["standard_error"], b["standard_error"]),
                              exact_finite_history_shift=0.0,
                              cp_shift_minus_exact_shift=b["estimate"] - a["estimate"],
                              within_seed_standard_error=math.hypot(a["within_seed_standard_error"], b["within_seed_standard_error"]),
                              between_seed_standard_error=math.hypot(a["between_seed_standard_error"], b["between_seed_standard_error"]),
                              interpretation="population-only adaptation; identical seed IDs are not matched random streams"))

for row in contrasts:
    tolerance = tolerances[row["quantity"]]
    row["stability_tolerance"] = tolerance
    for margin in (2, 3):
        budget = abs(row["cp_shift"]) + margin * row["standard_error"]
        row[f"absolute_shift_plus_{margin}SE"] = budget
        if row["control"] == "compound_endpoint":
            outcome = "NOT_AN_INDEPENDENT_CONTROL"
        elif margin == 2 and row["quantity"] == "E":
            outcome = "NOT_REGISTERED"
        else:
            outcome = "PASS" if budget <= tolerance else "FAIL"
        row[f"{margin}SE_shift_screen"] = outcome

write("measurement_health.csv", health)
write("per_run_comparison.csv", per_run)
write("blocking_sensitivity.csv", blocking)
write("time_drift.csv", time_drift)
write("pooled_comparison.csv", pooled)
write("diagnostic_screens.csv", screens)
write("controlled_shifts.csv", contrasts)
summary = dict(completed_chains=sum(r["included_in_pool"] for r in health),
               recorded_chains=len(health),
               saved_measurements=sum(r["saved_valid_measurements"] for r in health),
               planned_measurements=sum(r["planned_measurements"] for r in health),
               summed_run_seconds=sum(float(r["elapsed_seconds"]) for r in health if r["elapsed_seconds"] != ""),
               minimum_ancestors_by_run={r["run"]: r["minimum_distinct_ancestors"] for r in health},
               registered_arm_screen_counts={f"{margin}SE_{q}_{verdict}": sum(
                   r["registered"] and r["SE_multiplier"] == margin and r["quantity"] == q and r["arm_screen"] == verdict
                   for r in screens) for margin in (2, 3) for q in tolerances for verdict in ("PASS", "FAIL")},
               all_matched_schedule_and_stream_checks="PASS",
               unchanged_production_solver_and_trial_helper_hashes="PASS",
               overall="NOT_VALIDATED" if any(r["registered"] and r["arm_screen"] == "FAIL" for r in screens)
               else "NO_ARM_FAILURE_OBSERVED; full convergence still not established")
with (OUT / "status_summary.json").open("w") as stream:
    json.dump(summary, stream, indent=2)
provenance_paths = [EXACT, GROUND, Path(__file__), OUT / "preregistered_plan.md",
                    ROOT / "docs/reading/projection_milestone_plan.md",
                    ROOT / "docs/reading/cp_projection_convergence.md",
                    ROOT / "scripts/literature_transfer/cp_projection_convergence.jl",
                    OUT / "driver_initial_256walkers.jl", SOLVER, TRIAL_HELPER]
adaptation = OUT / "population_adaptation.md"
if adaptation.exists():
    provenance_paths.append(adaptation)
with (OUT / "report_provenance.json").open("w") as stream:
    json.dump(dict(sources=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                            for p in provenance_paths],
                   included_runs=[r["run"] for r in health if r["included_in_pool"]],
                   ground=reference, block_sizes=BLOCKS,
                   uncertainty="max(propagated maximum-block SE, between-seed SE); two seeds do not establish a confidence interval",
                   limitations="fixed dt; only QR26 has population control; finite-arm screens do not certify convergence or replace gates"), stream, indent=2)
with (OUT / "comparison_table.md").open("w") as stream:
    stream.write("| Trial | Walkers | Seeds | Warmup / BP | E (SE) | Sodd (SE) | Delta (SE) | Exact finite-history Sodd / Delta |\n")
    stream.write("|---|---:|---:|---|---:|---:|---:|---:|\n")
    for label, warm, lag, walkers in sorted({k[:4] for k in index}):
        e, s, d = [index[(label, warm, lag, walkers, q)] for q in ("E", "S_alm", "Delta")]
        stream.write(f"| {label} | {walkers} | {e['seed_count']} | {warm} / {lag} | {e['estimate']:.6f} ({e['standard_error']:.6f}) | "
                     f"{s['estimate']:.6f} ({s['standard_error']:.6f}) | {d['estimate']:.6f} ({d['standard_error']:.6f}) | "
                     f"{s['exact_finite_history']:.6f} / {d['exact_finite_history']:.6f} |\n")
print(f"Reported {sum(r['included_in_pool'] for r in health)} completed / {len(health)} recorded chains; "
      f"{len(per_run)} per-run estimates, {len(pooled)} pooled estimates, {len(contrasts)} controls. "
      "All schedule and matched-stream checks passed.")
