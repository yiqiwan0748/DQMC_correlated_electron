#!/usr/bin/env julia

"""Bounded open-cluster CP trial audit; never edits production solver code."""
module CPTrialAudit
using AltermagnetDQMCTrial
using LinearAlgebra, SHA, Test, Printf
include(joinpath(@__DIR__, "..", "two_orbital_open_cluster_ed.jl"))
using .TwoOrbitalOpenClusterED: open_cluster_kinetic_matrix

const ROOT = normpath(joinpath(@__DIR__, "../.."))
const OUTPUT = joinpath(ROOT, "results/literature_transfer/cp_trial_audit")
const K = open_cluster_kinetic_matrix(2, 2)
const TRIALS = ((name="free", pattern=:free, h=0.0),
                (name="am", pattern=:altermagnetic, h=0.5),
                (name="stripe", pattern=:stripe_x, h=0.5))
const EXTRA_TRIALS = ((name="am3", pattern=:altermagnetic, h=3.0),
                      (name="am6", pattern=:altermagnetic, h=6.0),
                      (name="mix02", pattern=:stripe_mix, h=.2),
                      (name="mix05", pattern=:stripe_mix, h=.5))

function make_trial(problem,t)
    if t.pattern==:stripe_mix
        field=.5*[1.,1.,-1.,-1.,1.,1.,-1.,-1.]+t.h*[1.,-.7,.2,-.4,.9,-.1,-.6,.3]
        up=eigen(Symmetric(K-Diagonal(field))).vectors[:,1:3]
        down=eigen(Symmetric(K+Diagonal(field))).vectors[:,1:3]
        return SlaterTrial(up,down;label="stripe_x(h=.5)+generic_spin_field($(t.h))")
    end
    return one_body_trial(problem;pattern=t.pattern,field_strength=t.h)
end

csv(x) = x isa Missing || x isa Nothing ? "" :
    "\"" * replace(string(x), "\""=>"\"\"") * "\""
function write_rows(path, rows)
    isempty(rows) && return
    open(path,"w") do io
        println(io,join(string.(keys(first(rows))),','))
        for r in rows
            println(io,join(csv.(values(r)),','))
        end
    end
end

# Same public stepping sequence as run_cp_afqmc; journal each successful
# measurement so an ancestry failure does not discard the valid prefix.
function run_with_journal(problem,controls,trial,out)
    state=initialize_cp_afqmc(problem,controls;trial=trial)
    measurements=CPAFQMCMeasurement{Float64}[]
    orders=NamedTuple[]
    open(joinpath(out,"partial_measurement_journal.csv"),"w") do io
        println(io,"measurement,step,energy,bp_energy,S_alm_q0,delta_alm,ancestors")
        try
            for _ in 1:controls.warmup_steps;step_cp_afqmc!(state);end
            for j in 1:controls.measurement_count
                for _ in 1:controls.steps_between_measurements;step_cp_afqmc!(state);end
                s=measure_cp_afqmc(state;include_order=true)
                push!(measurements,s.measurement);push!(orders,s.order_measurement)
                m=s.measurement
                println(io,join(csv.((j,m.step,m.mixed_total_energy,
                    m.backpropagated_total_energy,m.S_alm_q0,
                    s.order_measurement.delta_alm,m.distinct_backprop_ancestors)),','))
                flush(io)
            end
        finally
            open(joinpath(out,"measurement_completion.txt"),"w") do status
                println(status,"valid_measurements=",length(measurements))
                println(status,"planned_measurements=",controls.measurement_count)
                println(status,"valid_fraction=",length(measurements)/controls.measurement_count)
                println(status,"last_step=",state.step)
            end
        end
    end
    return finish_cp_afqmc(state,measurements;order_measurements=orders)
end

function profile_controls(profile, seed)
    if profile in ("pilot", "baseline", "admissible")
        dt, nw, warm, samples, bp = .02, 128, 8.0, 80, 2.0
    elseif profile == "refined"
        dt, nw, warm, samples, bp = .01, 256, 16.0, 160, 4.0
    elseif profile == "bp12"
        dt, nw, warm, samples, bp = .01, 256, 16.0, 160, 12.0
    elseif profile == "long"
        dt, nw, warm, samples, bp = .01, 256, 48.0, 240, 8.0
    else
        error("Unknown profile: $profile")
    end
    return CPAFQMCParameters(dtau=dt,walker_count=nw,
        warmup_steps=round(Int,warm/dt),measurement_count=samples,
        steps_between_measurements=round(Int,.1/dt),
        back_propagation_steps=round(Int,bp/dt),
        orthogonalize_every=5,population_control_every=5,
        overlap_refresh_every=16,minimum_backprop_ancestors=2,
        error_block_size=10,seed=seed)
end

function trial_checks(output)
    p=CPAFQMCProblem(K,12.0,3,3;lattice_size=2,cell_count=4)
    plus=one_body_trial(p;pattern=:altermagnetic,field_strength=.5)
    minus=one_body_trial(p;pattern=:altermagnetic,field_strength=-.5)
    project(v)=v*v'
    @testset "trial identity and symmetry controls" begin
        @test norm(project(plus.up)-project(minus.down))<2e-12
        @test norm(project(plus.down)-project(minus.up))<2e-12
        @test maximum(abs,K[1:2:end,2:2:end])>.6 # open cluster retains t4
    end
    rows=NamedTuple[]
    free=one_body_trial(p;pattern=:free)
    for t in (TRIALS...,EXTRA_TRIALS...)
        trl=make_trial(p,t)
        pu,pd=project(trl.up),project(trl.down)
        # Exact spin-square expectation of a spin-separated Slater determinant.
        spin_squared=(p.Nup-p.Ndown)^2/4+(p.Nup+p.Ndown)/2-tr(pu*pd)
        overlap=det(free.up'*trl.up)*det(free.down'*trl.down)
        push!(rows,(trial=t.name,field=t.h,trial_S_squared=spin_squared,
            overlap_probability_with_free=abs2(overlap),
            up_shell_gap=trl.up_shell_gap,down_shell_gap=trl.down_shell_gap,
            projector_distance_from_free=norm(pu-project(free.up))+norm(pd-project(free.down))))
    end
    write_rows(joinpath(output,"trial_identity.csv"),rows)
end

function run_one(profile,U,trial_spec,seed)
    label="$(profile)_U$(Int(U))_$(trial_spec.name)_seed$(seed)"
    out=joinpath(OUTPUT,label)
    ispath(out) && error("Refusing to overwrite $out")
    mkpath(out)
    controls=profile_controls(profile,seed)
    problem=CPAFQMCProblem(K,U,3,3;lattice_size=2,cell_count=4)
    trial=make_trial(problem,trial_spec)
    open(joinpath(out,"metadata.txt"),"w") do io
        println(io,"Hamiltonian=centered U-only; boundary=open; Lx=Ly=2; Nup=Ndown=3; n=1.5")
        println(io,"U=",U,"; trial=",trial_spec.name,"; field=",trial_spec.h)
        if trial_spec.pattern==:stripe_mix
            println(io,"trial_field_vector=",.5*[1.,1.,-1.,-1.,1.,1.,-1.,-1.]+trial_spec.h*[1.,-.7,.2,-.4,.9,-.1,-.6,.3])
        end
        println(io,"No physical trial field in projected Hamiltonian; no accuracy gate assigned")
        for name in fieldnames(typeof(controls));println(io,name,"=",getfield(controls,name));end
        println(io,"script_sha256=",bytes2hex(sha256(read(@__FILE__))))
        println(io,"solver_sha256=",bytes2hex(sha256(read(joinpath(ROOT,"src/constrained_path_afqmc.jl")))))
        println(io,"kinetic_sha256=",bytes2hex(sha256(reinterpret(UInt8,vec(K)))))
    end
    try
        elapsed=@elapsed result=profile=="bp12" ?
            run_with_journal(problem,controls,trial,out) :
            run_cp_afqmc(problem,controls;trial=trial)
        summ=result.summary
        write_rows(joinpath(out,"summary.csv"),[(quantity=string(k),value=v)
            for (k,v) in pairs(summ) if v isa Number || v isa Missing])
        samples=NamedTuple[]
        for (m,o) in zip(result.measurements,result.order_measurements)
            push!(samples,(step=m.step,E=m.mixed_total_energy,
                mixed_K=m.mixed_kinetic_energy,mixed_V=m.mixed_interaction_energy,
                mixed_D=m.mixed_double_occupancy_per_cell,
                bp_E=m.backpropagated_total_energy,bp_K=m.backpropagated_kinetic_energy,
                bp_V=m.backpropagated_interaction_energy,
                bp_D=m.backpropagated_double_occupancy_per_cell,
                S_alm=m.S_alm_q0,S_fm=m.S_fm_q0,delta=o.delta_alm,
                mx=o.mx,my=o.my,ancestors=m.distinct_backprop_ancestors))
        end
        write_rows(joinpath(out,"samples.csv"),samples)
        qrows=NamedTuple[]
        for j in 1:2,i in 1:2
            push!(qrows,(qx=summ.spin_structure_momenta_x[i],qy=summ.spin_structure_momenta_y[j],
                odd=summ.orbital_odd_spin_structure_factor[i,j],
                odd_se=summ.orbital_odd_spin_structure_factor_standard_error[i,j],
                even=summ.orbital_even_spin_structure_factor[i,j],
                even_se=summ.orbital_even_spin_structure_factor_standard_error[i,j]))
        end
        write_rows(joinpath(out,"spin_structure.csv"),qrows)
        open(joinpath(out,"diagnostics.txt"),"w") do io
            println(io,"runtime_seconds=",elapsed)
            for (key,value) in pairs(result.diagnostics);println(io,key,"=",value);end
        end
        # These are deterministic estimator identities, not an accuracy gate.
        @testset "$label estimator identities" begin
            @test isapprox(summ.density,1.5;atol=1e-12,rtol=0)
            @test maximum(abs(m.E-m.mixed_K-m.mixed_V) for m in samples)<2e-10
            @test maximum(abs(m.bp_E-m.bp_K-m.bp_V) for m in samples)<2e-10
            @test maximum(abs(m.bp_V-U*(4m.bp_D-1)) for m in samples)<2e-9
            @test maximum(abs(m.S_fm) for m in samples)<2e-9
        end
        write(joinpath(out,"status.txt"),"COMPLETED; diagnostic only; no accuracy verdict\n")
        @printf("%s %.2fs E=%.9f +/- %.6f S=%.7f +/- %.6f Delta=%.6f\n",
            label,elapsed,summ.energy,summ.energy_standard_error,summ.S_alm_q0,
            summ.S_alm_q0_standard_error,summ.delta_alm)
        flush(stdout)
    catch err
        open(joinpath(out,"status.txt"),"w") do io
            println(io,"FAILED; preserved partial outputs")
            showerror(io,err,catch_backtrace());println(io)
        end
        rethrow()
    end
end

function main(args=ARGS)
    profile=isempty(args) ? "pilot" : args[1]
    mkpath(OUTPUT)
    trial_checks(OUTPUT)
    if profile=="pilot"
        run_one(profile,12.0,TRIALS[1],8121)
    else
        selected=length(args)>=2 ? filter(t->t.name==args[2],collect((TRIALS...,EXTRA_TRIALS...))) : collect(TRIALS)
        isempty(selected) && error("Unknown trial")
        couplings=profile=="baseline" ? (2.0,12.0) : (12.0,)
        for U in couplings, t in selected, seed in (8121,9137)
            # The pilot is exactly the baseline free/U12/8121 chain. Reuse its
            # saved result rather than count the same random stream twice.
            if profile=="baseline" && U==12.0 && t.name=="free" && seed==8121
                continue
            end
            run_one(profile,U,t,seed)
        end
    end
end
if abspath(PROGRAM_FILE)==@__FILE__;main();end
end
