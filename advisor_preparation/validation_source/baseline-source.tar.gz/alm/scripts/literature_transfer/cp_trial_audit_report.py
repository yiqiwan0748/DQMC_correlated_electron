#!/usr/bin/env python3
"""Postprocess the bounded CP audit with standard-library CSV/statistics only.

Optional first argument: JSON mapping U strings to zero-field ED values with
keys energy, double_per_cell, S_alm_q0, kinetic, interaction. Without it only
archived exact energies and the archived U2 zero-field observables are used.
No runs are pooled across trial families, couplings, or refinement profiles.
"""
import csv
import json
import math
import pathlib
import statistics
import sys
import hashlib

ROOT = pathlib.Path(__file__).resolve().parents[2]
OUT = ROOT / "results/literature_transfer/cp_trial_audit"
REF = {
    2.0: dict(energy=-12.544971382957154, kinetic=-12.05596334612564,
              interaction=-0.48900803683151395,
              double_per_cell=0.1888739953960607, S_alm_q0=0.1551873324629091),
    12.0: dict(energy=-19.643298850521827),
}
if len(sys.argv) > 1:
    REF.update({float(k): v for k, v in json.load(open(sys.argv[1])).items()})
else:
    reference_path = ROOT / "results/literature_transfer/ed_estimator_audit/reference.csv"
    if reference_path.exists():
        for row in csv.DictReader(open(reference_path)):
            U = float(row["U"])
            if U not in REF:
                continue
            energy, kinetic = float(row["energy"]), float(row["kinetic_energy"])
            REF[U] = dict(energy=energy, kinetic=kinetic,
                         interaction=energy - kinetic,
                         double_per_cell=float(row["double_occupancy_per_cell"]),
                         S_alm_q0=float(row["S_odd_q0"]))
        with open(OUT / "ed_references_used.json", "w") as stream:
            json.dump(dict(source=str(reference_path),
                           sha256=hashlib.sha256(reference_path.read_bytes()).hexdigest(),
                           references=REF), stream, indent=2)


def read(path):
    with open(path) as stream:
        return list(csv.DictReader(stream))


def write(name, rows):
    if not rows:
        return
    with open(OUT / name, "w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def block_se(values, block):
    means = [statistics.mean(values[i:i + block])
             for i in range(0, len(values), block)]
    assert len(values) % block == 0
    return statistics.stdev(means) / math.sqrt(len(means))


def pool(values, errors):
    within = math.sqrt(sum(e * e for e in errors)) / len(errors)
    between = statistics.stdev(values) / math.sqrt(len(values)) if len(values) > 1 else 0
    return statistics.mean(values), max(within, between), within, between


specs = {
    "energy": ("E", "energy"),
    "bp_energy": ("bp_E", "energy"),
    "bp_kinetic": ("bp_K", "kinetic"),
    "bp_interaction": ("bp_V", "interaction"),
    "bp_double_per_cell": ("bp_D", "double_per_cell"),
    "S_alm_q0": ("S_alm", "S_alm_q0"),
    "delta_alm": ("delta", None),
}
runs, blocks = [], []
for directory in sorted(OUT.iterdir()):
    if not directory.is_dir() or not (directory / "samples.csv").exists():
        continue
    name = directory.name.split("_")
    if len(name) != 4:
        continue
    profile = "baseline" if name[0] == "pilot" else name[0]
    U, trial, seed = float(name[1][1:]), name[2], int(name[3][4:])
    samples = read(directory / "samples.csv")
    metadata = (directory / "metadata.txt").read_text().splitlines()
    controls = dict(line.split("=", 1) for line in metadata if "=" in line)
    for quantity, (column, key) in specs.items():
        values = [float(x[column]) for x in samples]
        errors = {b: block_se(values, b) for b in (5, 10, 20, 40)}
        center = statistics.mean(values)
        # At least four blocks enter the enlarged error estimate. The 40-sample
        # two-block baseline error is shown separately, never treated as robust.
        selected = max(errors[b] for b in errors if len(values) // b >= 4)
        exact = REF[U].get(key, "") if key else ""
        row = dict(run=directory.name, profile=profile, U=U, trial=trial,
                   seed=seed, samples=len(samples), dtau=float(controls["dtau"]),
                   walkers=int(controls["walker_count"]),
                   warmup_time=int(controls["warmup_steps"]) * float(controls["dtau"]),
                   bp_time=int(controls["back_propagation_steps"]) * float(controls["dtau"]),
                   quantity=quantity, estimate=center, standard_error=selected,
                   ed_reference=exact, difference=center - exact if exact != "" else "",
                   reference_scope="zero_field_fixed_3_3" if key else "not_assigned",
                   verdict="diagnostic_no_accuracy_gate")
        runs.append(row)
        for b, error in errors.items():
            blocks.append(dict(run=directory.name, quantity=quantity,
                               block_size=b, block_count=len(values) // b,
                               standard_error=error))

groups = {}
for row in runs:
    groups.setdefault((row["profile"], row["U"], row["trial"], row["quantity"]), []).append(row)
pooled = []
for (profile, U, trial, quantity), rows in sorted(groups.items()):
    assert len({r["seed"] for r in rows}) == len(rows), "Duplicate seed in pool"
    center, se, within, between = pool([r["estimate"] for r in rows],
                                      [r["standard_error"] for r in rows])
    exact = rows[0]["ed_reference"]
    pooled.append(dict(profile=profile, U=U, trial=trial, quantity=quantity,
                       seeds=";".join(str(r["seed"]) for r in rows),
                       seed_count=len(rows), estimate=center, standard_error=se,
                       within_seed_standard_error=within, between_seed_standard_error=between,
                       ed_reference=exact, difference=center - exact if exact != "" else "",
                       difference_per_cell=(center - exact) / 4 if exact != "" and "energy" in quantity else "",
                       verdict="diagnostic_no_accuracy_gate"))
write("per_run_comparison.csv", runs)
write("blocking_sensitivity.csv", blocks)
write("pooled_comparison.csv", pooled)

# Compare to the unconstrained, continuous-time exact estimator at the same
# asymmetric projection times. Its offset from the true ground expectation
# is kept separate from the remaining CP/numerical/sampling discrepancy.
bp_path = ROOT / "results/literature_transfer/ed_estimator_audit/exact_back_propagation.csv"
if bp_path.exists():
    exact_rows = read(bp_path)
    schedule_map = {"admissible": "baseline", "refined": "refined", "bp12": "refined_lag12"}
    exact_columns = {"energy": "exact_mixed_energy", "S_alm_q0": "exact_BP_S_odd_q0", "delta_alm": "exact_BP_Delta"}
    finite = []
    for row in pooled:
        if row["U"] != 12 or row["trial"] != "am3" or row["profile"] not in schedule_map or row["quantity"] not in exact_columns:
            continue
        selected = [x for x in exact_rows if x["schedule"] == schedule_map[row["profile"]]]
        target = statistics.mean(float(x[exact_columns[row["quantity"]]]) for x in selected)
        ground = 0.0 if row["quantity"] == "delta_alm" else REF[12][row["quantity"]]
        finite.append(dict(profile=row["profile"], quantity=row["quantity"],
                           seeds=row["seeds"], seed_count=row["seed_count"],
                           cp_estimate=row["estimate"], cp_standard_error=row["standard_error"],
                           exact_matching_finite_time=target, exact_ground=ground,
                           finite_projection_offset=target - ground,
                           residual_cp_numerical_sampling_offset=row["estimate"] - target,
                           exact_source=str(bp_path),
                           source_sha256=hashlib.sha256(bp_path.read_bytes()).hexdigest()))
    write("finite_projection_comparison.csv", finite)

paired = []
for seed in (8121, 9137):
    early = OUT / f"refined_U12_am3_seed{seed}/samples.csv"
    late = OUT / f"bp12_U12_am3_seed{seed}/samples.csv"
    if not early.exists() or not late.exists():
        continue
    a, b = read(early), read(late)
    assert [x["step"] for x in a] == [x["step"] for x in b]
    for column in ("E", "S_alm", "delta"):
        values = [float(y[column]) - float(x[column]) for x, y in zip(a, b)]
        if column == "E":
            assert max(abs(x) for x in values) < 2e-12, "BP changed the mixed projection path"
        paired.append(dict(seed=seed, quantity=column, samples=len(values),
                           mean_bp12_minus_bp4=statistics.mean(values),
                           paired_block_standard_error=max(block_se(values, block) for block in (5, 10, 20, 40)),
                           maximum_absolute_difference=max(abs(x) for x in values)))
write("paired_backpropagation_shift.csv", paired)

health = []
for directory in sorted(OUT.iterdir()):
    if not directory.is_dir() or not (directory / "metadata.txt").exists():
        continue
    lines = (directory / "metadata.txt").read_text().splitlines()
    controls = dict(line.split("=", 1) for line in lines if "=" in line)
    if (directory / "samples.csv").exists():
        samples = read(directory / "samples.csv")
        ancestors = [int(x["ancestors"]) for x in samples]
    elif (directory / "partial_measurement_journal.csv").exists():
        samples = read(directory / "partial_measurement_journal.csv")
        ancestors = [int(x["ancestors"]) for x in samples]
    else:
        samples, ancestors = [], []
    status = (directory / "status.txt").read_text().splitlines()[0] if (directory / "status.txt").exists() else "RUNNING_OR_NO_FINAL_STATUS"
    health.append(dict(run=directory.name, status=status,
                       saved_valid_measurements=len(samples),
                       planned_measurements=int(controls["measurement_count"]),
                       valid_saved_fraction=len(samples) / int(controls["measurement_count"]),
                       minimum_distinct_ancestors=min(ancestors) if ancestors else "",
                       median_distinct_ancestors=statistics.median(ancestors) if ancestors else "",
                       walkers=int(controls["walker_count"]),
                       note="distinct ancestry is not a weighted effective sample size"))
write("measurement_health.csv", health)

with open(OUT / "comparison_table.md", "w") as stream:
    stream.write("| Profile | U | Trial | E−E_ED (total) | pooled SE | S_alm(0) | pooled SE | S−S_ED |\n")
    stream.write("|---|---:|---|---:|---:|---:|---:|---:|\n")
    index = {(r["profile"], r["U"], r["trial"], r["quantity"]): r for r in pooled}
    for row in pooled:
        if row["quantity"] != "energy":
            continue
        spin = index[(row["profile"], row["U"], row["trial"], "S_alm_q0")]
        sd = f'{spin["difference"]:+.6f}' if spin["difference"] != "" else "unavailable"
        stream.write(f'| {row["profile"]} | {row["U"]:g} | {row["trial"]} | '
                     f'{row["difference"]:+.6f} | {row["standard_error"]:.6f} | '
                     f'{spin["estimate"]:.6f} | {spin["standard_error"]:.6f} | {sd} |\n')
print(f"Wrote {len(runs)} per-run and {len(pooled)} pooled observable rows to {OUT}")
