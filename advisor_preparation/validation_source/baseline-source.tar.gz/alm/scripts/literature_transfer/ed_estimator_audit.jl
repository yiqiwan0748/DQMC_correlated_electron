#!/usr/bin/env julia
# Bounded, isolated estimator audit. Existing ED and CP code is read-only.
module EDEstimatorAudit

using LinearAlgebra, Printf, Test, SparseArrays
import AltermagnetDQMCTrial as CP
include(joinpath(@__DIR__, "..", "two_orbital_open_cluster_ed.jl"))
const ED = TwoOrbitalOpenClusterED
const OUT = joinpath(@__DIR__, "..", "..", "results", "literature_transfer", "ed_estimator_audit")
const NC = 4
# Float64, dimension 3136, spectral width below 100. These absolute bounds
# accommodate accumulated LAPACK/linear-solve roundoff, not approximation error.
const ATOL = 2e-9
const DEGTOL = 1e-9
const QPOINTS = (("q0", 0.0, 0.0), ("qpi0", pi, 0.0),
                 ("qpipi", pi, pi), ("generic", pi/3, pi/5))

"""Independent occupation oracle: inspect each public bit pattern directly.
No production diagonal-observable or Fock-sign helper is called here.
Rows use the documented up-major/down-minor basis order.
"""
function fock_oracle(basis)
    nu = zeros(Int, length(basis), 8)
    nd = similar(nu)
    k = 0
    for up in basis.up_states, down in basis.down_states
        k += 1
        for a in 1:8
            nu[k,a] = Int((up >> (a-1)) & 1)
            nd[k,a] = Int((down >> (a-1)) & 1)
        end
    end
    z = (nu - nd) / 2
    doubles = vec(sum(nu .* nd; dims=2))
    return (; nu, nd, z, doubles)
end

# Phases refer to physical open-cluster coordinates. Generic q is a probe,
# not a translation quantum number. O_a(q)=sum_r exp(-iq.r) Sz_ra/sqrt(Nc).
function probe(qx, qy)
    P = zeros(ComplexF64, 8, 2)
    for y in 0:1, x in 0:1, a in 1:2
        P[2*(x+2y)+a,a] = cis(-qx*x-qy*y)/sqrt(NC)
    end
    P
end

function write_csv(path, rows)
    isempty(rows) && return
    open(path, "w") do io
        println(io, join(string.(keys(first(rows))), ","))
        for r in rows
            println(io, join((v isa AbstractFloat ? @sprintf("%.16g",v) : string(v)
                              for v in values(r)), ","))
        end
    end
end

"""S+ using a separate packed 16-mode canonical fermion ordering:
up1..up8,down1..down8. Apply down annihilation before up creation.
"""
function spin_raise(b0, b1)
    destinations = Dict((u,d) => (i-1)*length(b1.down_states)+j
                       for (i,u) in enumerate(b1.up_states)
                       for (j,d) in enumerate(b1.down_states))
    rows, cols, vals = Int[], Int[], Float64[]
    k = 0
    for u in b0.up_states, d in b0.down_states
        k += 1
        s = u | (d << 8)
        for a in 0:7
            annihilator, creator = UInt64(1) << (a+8), UInt64(1) << a
            iszero(s & annihilator) && continue
            !iszero(s & creator) && continue
            middle = s ⊻ annihilator
            parity = count_ones(s & (annihilator-1)) + count_ones(middle & (creator-1))
            final = middle | creator
            push!(rows, destinations[(final & 0xff, final >> 8)])
            push!(cols, k)
            push!(vals, iseven(parity) ? 1.0 : -1.0)
        end
    end
    sparse(rows, cols, vals, length(b1), length(b0))
end

function slater_fock(basis, up, down)
    determinants(states, orbitals) = [det(orbitals[[a for a in 1:8 if !iszero(s & (UInt64(1)<<(a-1)))],:]) for s in states]
    du, dd = determinants(basis.up_states, up), determinants(basis.down_states, down)
    # kron puts down-spin states in the minor index, as documented by ED.
    kron(du,dd)
end

"""Second-quantized spatial reflection, including orbital and Fock signs.
Mirror x sends d_xz -> -d_xz, d_yz -> d_yz; mirror y changes the d_yz sign.
The diagonal mirror exchanges x,y and d_xz,d_yz. These are exact
open-cluster symmetries at zero field.
"""
function reflection(basis, name)
    perm, signs = zeros(Int,8), ones(Int,8)
    for y in 0:1, x in 0:1, a in 1:2
        i=2*(x+2y)+a
        if name == :mirror_x
            perm[i]=2*((1-x)+2y)+a
            signs[i]=a==1 ? -1 : 1
        elseif name == :mirror_y
            perm[i]=2*(x+2*(1-y))+a
            signs[i]=a==2 ? -1 : 1
        elseif name == :diagonal_mirror
            perm[i]=2*(y+2x)+(3-a)
        else
            error("unknown reflection")
        end
    end
    T=zeros(8,8)
    for i in 1:8; T[perm[i],i]=signs[i]; end
    function transform(s)
        occupied=[a for a in 1:8 if !iszero(s & (UInt64(1)<<(a-1)))]
        permuted_modes=perm[occupied]
        inversions=sum(permuted_modes[i]>permuted_modes[j] for i in 1:length(permuted_modes) for j in i+1:length(permuted_modes))
        sign=prod(signs[occupied])*(iseven(inversions) ? 1 : -1)
        mask=sum(UInt64(1)<<(a-1) for a in permuted_modes)
        mask,sign
    end
    ids=Dict((u,d)=>(i-1)*length(basis.down_states)+j
             for (i,u) in enumerate(basis.up_states) for (j,d) in enumerate(basis.down_states))
    dest,values=Int[],Float64[]
    for u in basis.up_states, d in basis.down_states
        tu,su=transform(u); td,sd=transform(d)
        push!(dest,ids[(tu,td)]);push!(values,su*sd)
    end
    T,sparse(dest,collect(1:length(basis)),values,length(basis),length(basis))
end

function commutator_columns(op, G, E0)
    hcat((op * G[:,i] - E0*G[:,i] for i in axes(G,2))...)
end

function mixed_stripe_trial(K, strength)
    stripe=[isodd(div(a-1,2)%2) ? -1.0 : 1.0 for a in 1:8]
    perturbation=[1.0,-0.7,0.2,-0.4,0.9,-0.1,-0.6,0.3]
    field=0.5stripe+strength*perturbation
    up=eigen(Symmetric(K-Diagonal(field)))
    down=eigen(Symmetric(K+Diagonal(field)))
    (up=up.vectors[:,1:3],down=down.vectors[:,1:3],
     up_shell_gap=up.values[4]-up.values[3],down_shell_gap=down.values[4]-down.values[3])
end

function projection_controls(E,V,psi,oalm,ng,forbidden_ground,pattern,field,projectionrows,bprows)
    coefficients=V'*psi
    # Zero coefficients protected by a verified opposite reflection exactly.
    # Then remove whole degenerate-energy blocks below the stated numerical
    # weight cutoff; record the omitted weight rather than asserting it is zero.
    # Blockwise treatment is invariant under eigenvector rotations in a block.
    forbidden_ground && (coefficients[1:ng] .= 0.0)
    discarded_weight=0.0
    first=1
    while first<=length(E)
        last=first
        while last<length(E) && abs(E[last+1]-E[first])<=DEGTOL; last+=1; end
        blockweight=sum(abs2,view(coefficients,first:last))
        if blockweight<1e-24
            discarded_weight+=blockweight
            coefficients[first:last].=0.0
        end
        first=last+1
    end
    @test discarded_weight < 1e-20
    support=findall(!iszero,coefficients)
    support_floor=minimum(E[support])
    gaps=E .- support_floor
    function projected(tau)
        amplitudes=zeros(length(E))
        # Work on support only: forbidden lower energies must remain zero.
        amplitudes[support].=coefficients[support].*exp.(-tau.*gaps[support])
        amplitudes ./= norm(amplitudes)
        amplitudes,V*amplitudes
    end
    for tau in (0.0,2.0,4.0,8.0,16.0,32.0,64.0,128.0)
        pure_coeff,state=projected(tau)
        mixed_coeff,_=projected(tau/2)
        mixed_energy=dot(abs2.(mixed_coeff),E)
        pure_energy=dot(abs2.(pure_coeff),E)
        probabilities=abs2.(state)
        mean_o=dot(probabilities,oalm)
        raw=dot(probabilities,oalm.^2)/NC
        connected=raw-mean_o^2/NC
        @test mixed_energy >= support_floor-ATOL
        @test pure_energy >= support_floor-ATOL
        @test connected > -ATOL
        push!(projectionrows,(U=12.0,pattern=string(pattern),field=field,tau=tau,
            mixed_energy=mixed_energy,pure_energy=pure_energy,
            pure_S_odd_q0=raw,pure_connected_S_odd_q0=connected,
            pure_Delta=mean_o/NC,ground_overlap_weight=sum(abs2,coefficients[1:ng]),
            support_floor=support_floor,ground_forbidden_by_reflection=forbidden_ground,
            discarded_energy_block_weight=discarded_weight,block_weight_cutoff=1e-24))
    end
    if pattern==:altermagnetic && field==3.0
        # Exact counterpart of a finite-history BP estimator, not a CP result.
        for (label,betas,lag) in (("baseline",8.1:0.1:16.0,2.0),
                                 ("refined",16.1:0.1:32.0,4.0),
                                 ("refined_lag12",16.1:0.1:32.0,12.0))
            _,left=projected(lag)
            for beta in betas
                mixed_coeff,_=projected(beta/2)
                _,right=projected(beta-lag)
                denominator=dot(left,right)
                @test denominator>0
                odd=dot(left,(oalm.^2).*right)/(NC*denominator)
                delta=dot(left,oalm.*right)/(NC*denominator)
                push!(bprows,(U=12.0,pattern=string(pattern),field=field,
                    schedule=label,beta=beta,back_propagation_lag=lag,
                    exact_mixed_energy=dot(abs2.(mixed_coeff),E),
                    exact_BP_S_odd_q0=odd,exact_BP_Delta=delta))
            end
        end
    end
end

function run_point(U, rows, matrices, contacts, peaks, checks, trialrows, symmetryrows,projectionrows,bprows)
    start = time()
    K = ED.open_cluster_kinetic_matrix(2,2)
    @test maximum(abs, K[1:2:end,2:2:end]) > 0.6 # t4 survives OBC.
    op = ED.sector_hamiltonian(K,U,3,3)
    oracle = fock_oracle(op.basis)
    Z, doubles = oracle.z, oracle.doubles
    signs = repeat([1.0,-1.0], NC)
    oalm = Z*signs
    @test oalm == op.oalm_values
    @test doubles == op.double_occupancies
    @test all(iszero, vec(sum(Z;dims=2))) # fixed Sz=0 operator identity
    @test oracle.nu.^2 == oracle.nu
    @test oracle.nd.^2 == oracle.nd
    @test Z.^2 == (oracle.nu+oracle.nd-2oracle.nu.*oracle.nd)/4
    @test op.diagonal == U.*(doubles .- 1) # shifted intraorbital U, N=6,M=8

    H = ED.dense_sector_hamiltonian(op)
    @test issymmetric(H)
    decomposition = eigen!(Symmetric(H)) # complete 3136-state spectrum
    E, V = decomposition.values, decomposition.vectors
    E0 = E[1]
    ng = count(e -> abs(e-E0)<=DEGTOL,E)
    G = V[:,1:ng]
    gap = E[ng+1]-E0
    @test gap > 100DEGTOL
    @test size(V) == (3136,3136)
    probabilities = vec(sum(abs2,G;dims=2))/ng
    @test abs(sum(probabilities)-1) < ATOL
    mean_z = Z' * probabilities
    raw_real = Z' * (probabilities .* Z)
    connected_real = raw_real - mean_z*mean_z'
    maximum_ground_residual = maximum(norm.(eachcol(commutator_columns(op,G,E0))))
    @test maximum_ground_residual < ATOL
    residual_max = 0.0
    for n in unique([1,ng,ng+1,div(length(E),2),length(E)])
        residual_max = max(residual_max,norm(op*V[:,n] - E[n]*V[:,n]))
    end
    @test residual_max < ATOL

    # The z-probes preserve (Nup,Ndown). Independently check SU(2), then
    # identify each Sz=0 ground vector's total spin through ||S+g||².
    adjacent = ED.sector_hamiltonian(K,U,4,2)
    raising = spin_raise(op.basis,adjacent.basis)
    t = [sin(0.73i)+cos(0.31i) for i in 1:length(op.basis)]
    t ./= norm(t)
    su2_error = norm(adjacent*(raising*t) - raising*(op*t))
    @test su2_error < ATOL
    total_s2 = sum(abs2,raising*G)/ng
    @test total_s2 < ATOL # measured singlet; do not presume fixed Sz=0 is S=0.

    symmetries=Dict()
    for name in (:mirror_x,:mirror_y,:diagonal_mirror)
        onebody,manybody=reflection(op.basis,name)
        @test maximum(abs,onebody*K-K*onebody) < ATOL
        @test norm(manybody*(manybody*t)-t) < ATOL
        @test norm(op*(manybody*t)-manybody*(op*t)) < ATOL
        parity=real(tr(G'*manybody*G))/ng
        if ng==1; @test abs(abs(parity)-1)<ATOL; end
        symmetries[name]=(matrix=manybody,ground_parity=parity)
        push!(symmetryrows,(U=U,state="ground",field=0.0,symmetry=string(name),
            expectation=parity,eigenvector_residual=norm(manybody*G-parity*G)))
    end

    # Open ED exports one eigenvector. Compare its observables only after
    # resolving the full ground space above; skip ensemble equality if degenerate.
    production = ED.ground_state_observables(op; maxiter=500,atol=1e-12,rtol=1e-12)
    @test abs(production.energy-E0) < ATOL
    mean_o = dot(probabilities,oalm)
    var_o = dot(probabilities,oalm.^2)-mean_o^2
    D = dot(probabilities,doubles)
    if ng == 1
        @test abs(production.oalm-mean_o) < 2e-7
        @test abs(production.oalm_variance-var_o) < 2e-7
        @test abs(production.double_occupancy-D) < 2e-7
    end

    for a in 1:8, b in 1:8
        push!(contacts,(U=U,mode_a=a,mode_b=b,
            raw=raw_real[a,b],connected=connected_real[a,b],
            local_contact=a==b ? raw_real[a,b] : 0.0))
    end

    # Projected inverse Q(H-E0)^(-1)Q computed by an independent linear
    # solve; adding Pg makes the dense matrix strictly positive definite.
    R = ED.dense_sector_hamiltonian(op)
    for i in axes(R,1); R[i,i] -= E0; end
    R .+= G*G'
    factor = cholesky!(Symmetric(R))
    eigengaps = E[ng+1:end] .- E0
    q0_odd = q0_chi_odd = q0_even = 0.0
    peak_closure = first_moment_error = resolvent_error = imaginary_hermiticity = 0.0

    for (label,qx,qy) in QPOINTS
        P = probe(qx,qy)
        O = Z*P
        means = transpose(probabilities)*O
        C = O'*(probabilities.*O) - means'*means
        pair_C = P'*connected_real*P
        @test maximum(abs,C-pair_C) < ATOL
        @test maximum(abs,C-C') < ATOL
        @test minimum(eigvals(Hermitian(C))) > -ATOL
        for a in 1:2, b in 1:2
            imaginary_hermiticity = max(imaginary_hermiticity,abs(C[a,b]-conj(C[b,a])))
        end

        elastic = zeros(ComplexF64,2,2)
        positive = zeros(ComplexF64,2,2)
        moment1 = zeros(ComplexF64,2,2)
        direct_moment1 = zeros(ComplexF64,2,2)
        chi = zeros(ComplexF64,2,2)
        chi_solve = zeros(ComplexF64,2,2)
        weights = zeros(ComplexF64,length(E),2,2)
        for g in eachcol(G)
            B = O.*g
            A = V'*B
            Am = V'*conj.(B) # both ±q retained in the response definition
            elastic .+= (A[1:ng,:]'*A[1:ng,:])/ng
            positive .+= (A[ng+1:end,:]'*A[ng+1:end,:])/ng
            moment1 .+= (A[ng+1:end,:]'*(eigengaps.*A[ng+1:end,:]))/ng
            HB = hcat((op*B[:,a]-E0*B[:,a] for a in 1:2)...)
            direct_moment1 .+= (B'*HB)/ng
            Aq, Amq = A[ng+1:end,:], Am[ng+1:end,:]
            # chi_ab = W_ab(q)/omega + W_ba(-q)/omega, per physical cell.
            chi .+= (Aq'*(Aq./eigengaps) + transpose(Amq'*(Amq./eigengaps)))/ng
            Bq = B-G*(G'*B)
            Bm = conj.(Bq)
            X = factor\Bq
            Xm = factor\Bm
            chi_solve .+= (Bq'*X + transpose(Bm'*Xm))/ng
            @test norm(hcat((op*X[:,a]-E0*X[:,a] for a in 1:2)...)-Bq) < ATOL
            @test norm(G'*X) < ATOL
            for n in eachindex(E), a in 1:2, b in 1:2
                weights[n,a,b] += conj(A[n,a])*A[n,b]/ng
            end
        end
        elastic_connected = elastic-means'*means
        closure_error = maximum(abs,C-elastic_connected-positive)
        m1_error = maximum(abs,moment1-direct_moment1)
        solve_error = maximum(abs,chi-chi_solve)
        peak_closure = max(peak_closure,closure_error)
        first_moment_error = max(first_moment_error,m1_error)
        resolvent_error = max(resolvent_error,solve_error)
        @test closure_error < ATOL
        @test m1_error < ATOL
        @test solve_error < ATOL
        @test maximum(abs,chi-chi') < ATOL
        @test minimum(eigvals(Hermitian(chi))) > -ATOL
        # Degenerate elastic covariance is kept, never called a finite T=0
        # susceptibility. All actual points here resolve to unique singlets.
        if ng == 1
            @test maximum(abs,elastic_connected) < ATOL
        end

        for n in eachindex(E)
            w=weights[n,:,:]
            # Retain every state, including zero weights: no spectral cutoff.
            push!(peaks,(U=U,q=label,state=n,omega=max(0.0,E[n]-E0),
                ground_manifold=n<=ng,
                weight_xx=real(w[1,1]),weight_yy=real(w[2,2]),
                weight_xy_real=real(w[1,2]),weight_xy_imag=imag(w[1,2]),
                weight_even=real(sum(w)),
                weight_odd=real(w[1,1]+w[2,2]-w[1,2]-w[2,1])))
        end
        for a in 1:2, b in 1:2
            push!(matrices,(U=U,q=label,qx=qx,qy=qy,orbital_a=a,orbital_b=b,
                covariance_real=real(C[a,b]),covariance_imag=imag(C[a,b]),
                elastic_connected_real=real(elastic_connected[a,b]),
                elastic_connected_imag=imag(elastic_connected[a,b]),
                positive_weight_real=real(positive[a,b]),positive_weight_imag=imag(positive[a,b]),
                first_moment_real=real(moment1[a,b]),first_moment_imag=imag(moment1[a,b]),
                chi_regular_real=real(chi[a,b]),chi_regular_imag=imag(chi[a,b])))
        end
        odd = real(C[1,1]+C[2,2]-C[1,2]-C[2,1])
        even = real(sum(C))
        # Direct squared diagonal-channel estimator, including contacts/crosses.
        for v in ([1.0,-1.0],[1.0,1.0])
            ov=O*v
            @test abs(real(v'*C*v)-(dot(probabilities,abs2.(ov))-abs2(dot(probabilities,ov)))) < ATOL
        end
        if label == "q0"
            q0_odd,q0_even = odd,even
            q0_chi_odd = real(chi[1,1]+chi[2,2]-chi[1,2]-chi[2,1])
            @test abs(q0_even) < ATOL
            @test abs(q0_odd-var_o/NC) < ATOL
            @test abs(real(sum(chi))) < ATOL
            @test q0_chi_odd > ATOL # t4 breaks conservation of Oalm.
        end

        if iszero(U)
            free = eigen(Symmetric(K))
            density = free.vectors[:,1:3]*free.vectors[:,1:3]'
            # Independent Wick result, using physical Sz=(nu-nd)/2.
            wick_real = (Diagonal(diag(density))-density.*transpose(density))/2
            @test maximum(abs,raw_real-wick_real) < ATOL
            @test maximum(abs,C-P'*wick_real*P) < ATOL
            if label != "generic"
                production_tensor = CP._cp_orbital_spin_structure_factor(density,density,2)
                ix,iy=round(Int,qx/pi)+1,round(Int,qy/pi)+1
                @test maximum(abs,C-production_tensor[:,:,ix,iy]/4) < ATOL
                channels = CP._cp_spin_structure_channels(production_tensor)
                @test abs(odd-channels.orbital_odd[ix,iy]) < ATOL
                @test abs(even-channels.orbital_even[ix,iy]) < ATOL
            end
        end
    end

    problem=CP.CPAFQMCProblem(K,U,3,3;lattice_size=2,cell_count=NC)
    for (pattern,field) in ((:free,0.0),(:altermagnetic,0.5),(:stripe_x,0.5),
                            (:altermagnetic,3.0),(:altermagnetic,6.0),(:stripe_x,3.0),
                            (:stripe_mix,0.2),(:stripe_mix,0.5))
        trial=pattern==:stripe_mix ? mixed_stripe_trial(K,field) :
            CP.one_body_trial(problem;pattern,field_strength=field)
        psi=slater_fock(op.basis,trial.up,trial.down)
        @test abs(norm(psi)-1) < ATOL
        overlap=sum(abs2,G'*psi)
        push!(trialrows,(U=U,pattern=string(pattern),field=field,
            squared_ground_subspace_overlap=overlap,
            variational_energy=dot(psi,op*psi),shell_gap_up=trial.up_shell_gap,
            shell_gap_down=trial.down_shell_gap))
        forbidden_ground=false
        for name in (:mirror_x,:mirror_y,:diagonal_mirror)
            manybody=symmetries[name].matrix
            expectation=dot(psi,manybody*psi)
            push!(symmetryrows,(U=U,state=string(pattern),field=field,symmetry=string(name),
                expectation=expectation,eigenvector_residual=norm(manybody*psi-expectation*psi)))
            # If the trial is an exact opposite-parity eigenvector, its
            # overlap with the unique ground state must vanish algebraically.
            if ng==1 && abs(abs(expectation)-1)<ATOL &&
               abs(expectation+symmetries[name].ground_parity)<ATOL
                @test overlap < ATOL^2
                forbidden_ground=true
            end
        end
        if U==12 && ((pattern==:free) || (pattern==:altermagnetic && field in (0.5,3.0)) ||
                     (pattern==:stripe_mix && field==0.5))
            projection_controls(E,V,psi,oalm,ng,forbidden_ground,pattern,field,projectionrows,bprows)
        end
        if iszero(U) && pattern==:free
            @test abs(overlap-1) < ATOL
            @test abs(E0-2sum(eigvals(Symmetric(K))[1:3])) < ATOL
        end
    end
    push!(rows,(U=U,dimension=length(E),Nup=3,Ndown=3,density_per_cell=1.5,
        energy=E0,ground_degeneracy=ng,same_sector_gap=gap,total_spin_squared=total_s2,
        double_occupancy_total=D,double_occupancy_per_cell=D/NC,
        kinetic_energy=E0-U*(D-1),S_odd_q0=q0_odd,S_even_q0=q0_even,
        chi_odd_q0_regular=q0_chi_odd,mean_Oalm=mean_o,
        production_lanczos_residual=production.residual,elapsed_seconds=time()-start))
    push!(checks,(U=U,ground_residual=maximum_ground_residual,
        sampled_spectrum_residual=residual_max,SU2_intertwining_error=su2_error,
        max_zeroth_moment_error=peak_closure,max_first_moment_error=first_moment_error,
        max_resolvent_error=resolvent_error,max_covariance_hermiticity_error=imaginary_hermiticity))
    write_csv(joinpath(OUT,"reference.csv"),rows)
    write_csv(joinpath(OUT,"trial_overlaps.csv"),trialrows)
    write_csv(joinpath(OUT,"reflection_symmetries.csv"),symmetryrows)
    write_csv(joinpath(OUT,"exact_projection.csv"),projectionrows)
    write_csv(joinpath(OUT,"exact_back_propagation.csv"),bprows)
    @printf("U=%g: E=%.14g, degeneracy=%d, gap=%.9g, Sodd0=%.9g, chiOdd0=%.9g, %.1fs\n",
            U,E0,ng,gap,q0_odd,q0_chi_odd,time()-start)
    flush(stdout)
    nothing
end

function main()
    mkpath(OUT)
    previous_threads=BLAS.get_num_threads()
    BLAS.set_num_threads(2) # local bounded run; other research tasks run alongside.
    rows,matrices,contacts,peaks,checks,trialrows,symmetryrows,projectionrows,bprows = [],[],[],[],[],[],[],[],[]
    try
        @testset "Open-cluster ED covariance and Lehmann estimator audit" begin
            for U in (0.0,2.0,12.0)
                run_point(U,rows,matrices,contacts,peaks,checks,trialrows,symmetryrows,projectionrows,bprows)
                GC.gc()
            end
        end
        write_csv(joinpath(OUT,"orbital_covariance_and_response.csv"),matrices)
        write_csv(joinpath(OUT,"real_space_spin_covariance.csv"),contacts)
        write_csv(joinpath(OUT,"complete_lehmann_weights.csv"),peaks)
        write_csv(joinpath(OUT,"validation.csv"),checks)
        println("Saved estimator audit to ",abspath(OUT))
    finally
        BLAS.set_num_threads(previous_threads)
    end
end

if abspath(PROGRAM_FILE)==@__FILE__
    main()
end
end
