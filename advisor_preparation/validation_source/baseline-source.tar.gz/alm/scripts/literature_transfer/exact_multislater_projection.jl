#!/usr/bin/env julia
# Exact finite-dimensional Strang-splitting controls; no stochastic sampling.
module ExactMultislaterProjection
using LinearAlgebra, SparseArrays, Serialization, Test, Printf, SHA
include(joinpath(@__DIR__,"..","two_orbital_open_cluster_ed.jl"))
const ED=TwoOrbitalOpenClusterED
const BASE=normpath(joinpath(@__DIR__,"..","..","results","literature_transfer"))
const OUT=joinpath(BASE,"exact_multislater_projection")
const TOL=2e-9
const LABEL="full_singlet_AM3_20det"

function write_csv(name,rows)
    path=joinpath(OUT,name)
    buffer=IOBuffer()
    println(buffer,join(string.(keys(first(rows))),","))
    for row in rows
        println(buffer,join((x isa AbstractFloat ? @sprintf("%.17g",x) : string(x) for x in values(row)),","))
    end
    bytes=take!(buffer)
    if isfile(path)
        read(path)==bytes || error("Refusing to overwrite different prior data: $path")
    else
        write(path,bytes)
    end
end

occupations(states)=[[a for a in 1:8 if !iszero(s&(UInt64(1)<<(a-1)))] for s in states]
function determinant_state(up,down,occupied)
    du=[det(up[I,:]) for I in occupied]
    dd=[det(down[I,:]) for I in occupied]
    kron(du,dd) # down index varies fastest
end
function wedge3(onebody,occupied)
    [det(onebody[I,J]) for I in occupied,J in occupied]
end

function spin_raise(basis)
    target=ED.sector_basis(8,4,2)
    lookup=Dict((u,d)=>(i-1)*length(target.down_states)+j for (i,u) in enumerate(target.up_states) for (j,d) in enumerate(target.down_states))
    rows,cols,values=Int[],Int[],Float64[];column=0
    for u in basis.up_states,d in basis.down_states
        column+=1;s=u|(d<<8)
        for a in 0:7
            upbit=UInt64(1)<<a;downbit=UInt64(1)<<(a+8)
            (iszero(s&downbit)||!iszero(s&upbit)) && continue
            middle=s⊻downbit
            parity=count_ones(s&(downbit-1))+count_ones(middle&(upbit-1))
            final=middle|upbit
            push!(rows,lookup[(final&0xff,final>>8)]);push!(cols,column)
            push!(values,iseven(parity) ? 1.0 : -1.0)
        end
    end
    sparse(rows,cols,values,length(target),length(basis))
end

function source_and_initialization(basis,occupied)
    exported=deserialize(joinpath(BASE,"trial_symmetry_projection","full_singlet_am3_20_terms.jls"))
    termvectors=[determinant_state(t.up,t.down,occupied) for t in exported.terms]
    raw=sum(t.coefficient*v for(t,v) in zip(exported.terms,termvectors))
    normalization=norm(raw);trial=raw/normalization
    @test abs(normalization-exported.normalization)<TOL
    coefficients=[t.coefficient/normalization for t in exported.terms]
    overlaps=[dot(trial,v) for v in termvectors]
    weights=coefficients.*overlaps
    @test minimum(weights)>0
    @test abs(sum(weights)-1)<TOL
    @test norm(sum(w*v/o for(w,v,o) in zip(weights,termvectors,overlaps))-trial)<TOL
    rows=[(term=i,normalized_coefficient=coefficients[i],overlap=overlaps[i],
           determinant_norm=norm(termvectors[i]),positive_importance_weight=weights[i]) for i in eachindex(weights)]
    write_csv("initialization_reference.csv",rows)
    reconstruction=[]
    for population in (128,256)
        counts=floor.(Int,population.*weights)
        order=sortperm(population.*weights.-counts;rev=true)
        counts[order[1:population-sum(counts)]].+=1
        @test minimum(counts)>=1 && sum(counts)==population
        perwalker=population.*weights./counts
        ket=sum((counts[i]/population)*perwalker[i]*termvectors[i]/overlaps[i] for i in eachindex(weights))
        @test norm(ket-trial)<TOL
        push!(reconstruction,(population=population,minimum_term_count=minimum(counts),
             maximum_term_count=maximum(counts),fock_reconstruction_residual=norm(ket-trial),
             total_importance_weight=sum(counts.*perwalker)/population))
    end
    write_csv("initialization_reconstruction.csv",reconstruction)
    trial
end

function projected_discrete(K,op,trial,occupied,dt;max_tick=320)
    stride=round(Int,.1/dt)
    @test abs(stride*dt-.1)<1e-14
    half=wedge3(exp(Symmetric(-dt*K/2)),occupied)
    @test norm(half-half')<TOL
    Vdiag=reshape(exp.(-dt.*op.diagonal),56,56)
    psi=reshape(copy(trial),56,56)
    states=zeros(length(trial),max_tick+1);states[:,1]=trial
    logs=zeros(max_tick+1);logscale=0.0
    # The interaction diagonal already includes the centered U(D-1) constant.
    # Each complete slice is K_half * V_full * K_half.
    for step in 1:max_tick*stride
        psi=half*psi*half'
        psi .*= Vdiag
        psi=half*psi*half'
        scale=norm(psi)
        @test isfinite(scale) && scale>0
        psi ./= scale;logscale+=log(scale)
        if step%stride==0
            tick=div(step,stride)
            states[:,tick+1].=vec(psi);logs[tick+1]=logscale
        end
    end
    (;states,logs)
end

function projected_continuous(E,V,trial;max_tick=320)
    amplitudes=V'*trial
    @test norm(V*amplitudes-trial)<TOL
    @test abs(amplitudes[1])>.9
    times=collect(0:max_tick)./10
    coefficients=amplitudes.*exp.(-(E.-E[1])*times')
    norms=sqrt.(sum(abs2,coefficients;dims=1))
    logs=vec(log.(norms)).-E[1].*times
    coefficients ./= norms
    (;states=V*coefficients,logs)
end

function measure(paths,trial,op,oalm,tick,lag_tick)
    left=view(paths.states,:,lag_tick+1)
    right=view(paths.states,:,tick-lag_tick+1)
    endstate=view(paths.states,:,tick+1)
    denominator=dot(left,right);mixedden=dot(trial,endstate)
    @test denominator>0 && mixedden>0
    full_log=paths.logs[tick+1]+log(mixedden)
    split_log=paths.logs[lag_tick+1]+paths.logs[tick-lag_tick+1]+log(denominator)
    @test abs(full_log-split_log)<TOL
    mixed=dot(trial,op*endstate)/mixedden
    bpenergy=dot(left,op*right)/denominator
    spin=dot(left,oalm.^2 .*right)/(4denominator)
    delta=dot(left,oalm.*right)/(4denominator)
    @test abs(delta)<TOL
    if lag_tick==0;@test abs(mixed-bpenergy)<TOL;end
    (;mixed,bpenergy,spin,delta,full_log)
end

function row(dt,initial,warm,tick,lag_tick,result,continuous)
    (dtau=dt,label=LABEL,initial_ket=initial,warmup=warm,bp_lag=lag_tick/10,beta=tick/10,
     exact_mixed_energy=result.mixed,exact_BP_energy=result.bpenergy,
     exact_BP_S_odd_q0=result.spin,exact_BP_Delta=result.delta,
     continuous_mixed_energy=continuous.mixed,continuous_BP_energy=continuous.bpenergy,
     continuous_BP_S_odd_q0=continuous.spin,continuous_BP_Delta=continuous.delta,
     exact_log_overlap=result.full_log)
end

function free_oracle(K,op,trial,occupied)
    one=eigen(Symmetric(K));q=one.vectors[:,1:3]
    psi=determinant_state(q,q,occupied)
    Efree=2sum(one.values[1:3]);dt=.02
    half=wedge3(exp(Symmetric(-dt*K/2)),occupied)
    whole=wedge3(exp(Symmetric(-dt*K)),occupied)
    @test norm(half*half-whole)<TOL
    evolved=half*reshape(psi,56,56)*half'
    evolved=half*evolved*half'
    @test norm(vec(evolved)-exp(-dt*Efree)*psi)<TOL
    freeop=ED.sector_hamiltonian(K,0.,3,3)
    @test norm(freeop*psi-Efree*psi)<TOL
    # A general non-eigenstate checks the generator and Fock ordering.
    epsilon=1e-5
    plus=wedge3(exp(Symmetric(-epsilon*K)),occupied)
    minus=wedge3(exp(Symmetric(epsilon*K)),occupied)
    derivative=vec(plus*reshape(trial,56,56)*plus'-minus*reshape(trial,56,56)*minus')/(2epsilon)
    @test norm(derivative+freeop*trial)<2e-7 # centered derivative O(epsilon²)
end

function main()
    mkpath(OUT)
    cache=deserialize(joinpath(BASE,"trial_symmetry_projection","u12_complete_spectrum.jls"))
    K=ED.open_cluster_kinetic_matrix(2,2);op=ED.sector_hamiltonian(K,12.,3,3)
    @test cache.K==K && cache.Nup==cache.Ndown==3 && cache.U==12.
    @test cache.up_states==op.basis.up_states && cache.down_states==op.basis.down_states
    occupied=occupations(op.basis.up_states)
    trial=source_and_initialization(op.basis,occupied)
    raising=spin_raise(op.basis)
    @test norm(raising*trial)<TOL
    oalm=op.oalm_values
    free_oracle(K,op,trial,occupied)
    continuous=projected_continuous(cache.energies,cache.vectors,trial)
    schedule_rows=[];short_rows=[];summaries=[];convergence=[];paths_by_dt=Dict()
    for dt in (.02,.01,.005)
        paths=projected_discrete(K,op,trial,occupied,dt)
        paths_by_dt[dt]=paths
        for tick in (0,1,4,10,80,160,320)
            @test norm(raising*paths.states[:,tick+1])<TOL
            @test abs(norm(paths.states[:,tick+1])-1)<TOL
        end
        for (warm,ticks) in ((8.,81:160),(16.,161:320)),lag_tick in (40,80)
            selected=[]
            for tick in ticks
                exact=measure(paths,trial,op,oalm,tick,lag_tick)
                ct=measure(continuous,trial,op,oalm,tick,lag_tick)
                @test abs(ct.bpenergy-ct.mixed)<TOL # continuous H commutes, discrete H need not.
                r=row(dt,"same_full_singlet",warm,tick,lag_tick,exact,ct)
                push!(schedule_rows,r);push!(selected,r)
            end
            push!(summaries,(dtau=dt,label=LABEL,initial_ket="same_full_singlet",warmup=warm,bp_lag=lag_tick/10,
                samples=length(selected),exact_mean_mixed_energy=sum(r.exact_mixed_energy for r in selected)/length(selected),
                exact_mean_BP_energy=sum(r.exact_BP_energy for r in selected)/length(selected),
                exact_mean_BP_S_odd_q0=sum(r.exact_BP_S_odd_q0 for r in selected)/length(selected),
                exact_mean_BP_Delta=sum(r.exact_BP_Delta for r in selected)/length(selected),
                continuous_mean_mixed_energy=sum(r.continuous_mixed_energy for r in selected)/length(selected),
                continuous_mean_BP_S_odd_q0=sum(r.continuous_BP_S_odd_q0 for r in selected)/length(selected)))
        end
        for tick in (0,1,2,4,8,10),lag_tick in 0:tick
            exact=measure(paths,trial,op,oalm,tick,lag_tick)
            ct=measure(continuous,trial,op,oalm,tick,lag_tick)
            push!(short_rows,row(dt,"same_full_singlet",0.,tick,lag_tick,exact,ct))
        end
        println("Completed exact discrete controls dt=",dt);flush(stdout)
    end
    for (coarse,fine) in ((.02,.01),(.01,.005))
        ec=norm(paths_by_dt[coarse].states[:,5]-continuous.states[:,5])
        ef=norm(paths_by_dt[fine].states[:,5]-continuous.states[:,5])
        @test 3.7<ec/ef<4.3
        push!(convergence,(beta=.4,coarse_dt=coarse,fine_dt=fine,coarse_state_error=ec,fine_state_error=ef,
                          error_ratio=ec/ef,expected_second_order_ratio=4.))
    end
    write_csv("exact_schedule_controls.csv",schedule_rows)
    write_csv("exact_schedule_summary.csv",summaries)
    write_csv("exact_short_time_controls.csv",short_rows)
    write_csv("trotter_convergence.csv",convergence)
    println.(summaries)
end

if abspath(PROGRAM_FILE)==@__FILE__
    old=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        @testset "Exact discrete multislater projection" main()
    finally
        BLAS.set_num_threads(old)
    end
end
end
