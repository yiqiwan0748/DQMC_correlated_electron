#!/usr/bin/env julia
# Additional lag-zero scalar controls; preserves all earlier reference data.
module ExactMultislaterScalarReference
using LinearAlgebra, Serialization, Test, Printf, SHA
include(joinpath(@__DIR__,"actual_multislater_su2_audit.jl"))
include(joinpath(@__DIR__,"exact_multislater_projection.jl"))
const A=ActualMultiSlaterSU2Audit
const P=ExactMultislaterProjection
const OUT=joinpath(P.BASE,"exact_multislater_scalar_reference")

function write_csv(path,rows)
    open(path,"w") do io
        println(io,join(string.(keys(first(rows))),','))
        for row in rows
            println(io,join((v isa AbstractFloat ? @sprintf("%.17g",v) : string(v) for v in values(row)),','))
        end
    end
end

function main()
    ispath(OUT) && error("Refusing to overwrite extra scalar references")
    mkpath(OUT)
    source=joinpath(P.BASE,"trial_symmetry_projection/u12_complete_spectrum.jls")
    cache=deserialize(source)
    op=P.ED.sector_hamiltonian(cache.K,12.,3,3)
    occupied=P.occupations(op.basis.up_states)
    terms=deserialize(joinpath(P.BASE,"trial_symmetry_projection/full_singlet_am3_20_terms.jls"))
    trial=sum(t.coefficient*P.determinant_state(t.up,t.down,occupied) for t in terms.terms)
    trial./=norm(trial)
    ground=cache.vectors[:,1]
    # The history oracle orders occupations by integer bit mask, while the ED
    # solver enumerates lexicographic occupied-index tuples. Convert source
    # columns explicitly; target rows need no conversion in inner products.
    oracle_occ=A.B.occupations(8,3)
    lookup=Dict(A.mask(o)=>i for (i,o) in enumerate(oracle_occ))
    spinperm=[lookup[A.mask(o)] for o in occupied]
    permutation=[(u-1)*56+d for u in spinperm for d in spinperm]
    @test sort(permutation)==collect(1:3136)
    Jp=A.flip_operator(repeat([1.,-1.],4),1)[:,permutation]
    Jm=A.flip_operator(repeat([1.,-1.],4),-1)[:,permutation]
    Sp=A.flip_operator(ones(8),1)[:,permutation]
    Sm=A.flip_operator(ones(8),-1)[:,permutation]
    edraising=P.spin_raise(op.basis)
    @test norm(Sp'*Sp-edraising'*edraising)<2e-11
    @assert norm(Sp*trial)<2e-11 && norm(Sp*ground)<2e-11
    @test norm(Sp*trial)<2e-11 && norm(Sp*ground)<2e-11
    pure=A.observables(trial,trial,op.oalm_values,Jp,Jm,Sp,Sm)
    exact=A.observables(ground,ground,op.oalm_values,Jp,Jm,Sp,Sm)
    trialscalar=pure.scalar/12;groundscalar=exact.scalar/12
    function row(label,beta,dt,right)
        result=A.observables(trial,right,op.oalm_values,Jp,Jm,Sp,Sm)
        @test abs(result.scalar/3-result.O2z)<2e-9
        @test abs(result.Stot2)<2e-9
        (reference=label,beta=beta,dtau=dt,mixed_scalar=result.scalar/12,
         mixed_z=result.O2z/4,mixed_Stot2=result.Stot2,
         trial_scalar=trialscalar,exact_ground_scalar=groundscalar,
         twice_mixed_minus_trial=result.scalar/6-trialscalar)
    end
    rows=[row("trial",0.,0.,trial),row("exact_ground_right",Inf,0.,ground)]
    paths=P.projected_discrete(cache.K,op,trial,occupied,.02)
    schedule=[]
    for tick in 161:320
        right=view(paths.states,:,tick+1)
        @test norm(Sp*right)<2e-9
        push!(schedule,row("discrete_dt02_warm16_lag0",tick/10,.02,right))
    end
    append!(rows,schedule)
    write_csv(joinpath(OUT,"mixed_scalar_controls.csv"),rows)
    summary=(reference="discrete_dt02_warm16_lag0",dtau=.02,warmup=16.,samples=160,
        beta_first=16.1,beta_last=32.,
        mean_mixed_scalar=sum(r.mixed_scalar for r in schedule)/160,
        trial_scalar=trialscalar,exact_ground_scalar=groundscalar,
        twice_mean_mixed_minus_trial=2sum(r.mixed_scalar for r in schedule)/160-trialscalar)
    write_csv(joinpath(OUT,"schedule_summary.csv"),[summary])
    open(joinpath(OUT,"provenance.txt"),"w") do io
        println(io,"Exact fixed (3,3) U12 open2x2; same full-singlet trial on both boundaries.")
        println(io,"Lag0; dt.02 symmetric K_half V K_half, every.1 measurement beta16.1:32.")
        println(io,"twice_mixed_minus_trial is an extrapolated diagnostic, not an exact identity.")
        println(io,"No prior data overwritten; no Monte Carlo; no new diagonalization.")
        for path in (@__FILE__,source,joinpath(@__DIR__,"exact_multislater_projection.jl"))
            println(io,path," sha256=",bytes2hex(sha256(read(path))))
        end
    end
    println(rows[1]);println(rows[2]);println(summary)
end
if abspath(PROGRAM_FILE)==@__FILE__
    old=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        @testset "Additional exact scalar references" main()
    finally
        BLAS.set_num_threads(old)
    end
end
end
