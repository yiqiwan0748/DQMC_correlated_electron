#!/usr/bin/env julia
# Constrained, uniform U-only Hartree–Fock comparison; no gRISB or QMC.
using LinearAlgebra, Printf, Test

const U = 20.0
const TUPLE = (-1.0,-1.75,-0.85,-0.65)
const OUTPUT_HF = normpath(joinpath(@__DIR__,"../../results/literature_transfer/hf"))
fermi_hf(x) = x >= 0 ? exp(-x)/(1+exp(-x)) : 1/(1+exp(x))
softplus_hf(x) = max(x,0) + log1p(exp(-abs(x)))

function mesh_hf(nk)
    t1,t2,t3,t4=TUPLE
    c=Float64[]; z=Float64[]; x=Float64[]
    for ix in 0:nk-1, iy in 0:nk-1
        kx=-pi+2pi*(ix+.5)/nk;ky=-pi+2pi*(iy+.5)/nk
        push!(c,-(t1+t2)*(cos(kx)+cos(ky))-4t3*cos(kx)*cos(ky))
        push!(z,-(t1-t2)*(cos(kx)-cos(ky)))
        push!(x,-4t4*sin(kx)*sin(ky))
    end
    return (nk=nk,c=c,z=z,x=x,lastmu=Ref(-2.0))
end

function source_hf(grid,kind,h,n,T;thermo=false)
    count=length(grid.c); es=Vector{Float64}(undef,4count); dh=similar(es)
    j=0
    for spin in (1,-1), i in 1:count
        z=grid.z[i]-(kind==:AM ? spin*h : 0.0)
        radius=hypot(z,grid.x[i])
        for b in (-1,1)
            j+=1
            es[j]=grid.c[i]+b*radius-(kind==:FM ? spin*h : 0.0)
            dh[j]=kind==:FM ? -spin : -spin*b*z/radius
        end
    end
    lo=minimum(es)-40T;hi=maximum(es)+40T;mu=clamp(grid.lastmu[],lo,hi)
    density=0.0
    for iteration in 1:80
        total=0.0;deriv=0.0
        for e in es
            f=fermi_hf((e-mu)/T);total+=f;deriv+=f*(1-f)/T
        end
        density=total/count;deriv/=count
        abs(density-n)<5e-13 && break
        if density<n;lo=mu;else;hi=mu;end
        proposal=mu+(n-density)/max(deriv,1e-14)
        mu=lo<proposal<hi ? proposal : (lo+hi)/2
        iteration==80 && error("Chemical-potential convergence failed")
    end
    grid.lastmu[]=mu
    moment=0.0;kinetic=0.0;entropy=0.0;omega=0.0
    for i in eachindex(es)
        f=fermi_hf((es[i]-mu)/T)
        moment-=f*dh[i]/(2count)
        if thermo
            kinetic+=f*(es[i]-h*dh[i])/count
            omega-=T*softplus_hf((mu-es[i])/T)/count
            if 0<f<1;entropy-=(f*log(f)+(1-f)*log1p(-f))/count;end
        end
    end
    # n_x=n_y=n/2, m_x=±m_y=m. Shifted-U constant is retained.
    constant=U*(n-2)^2/8
    # Do not expose skipped thermodynamic accumulators as computed results.
    F=thermo ? omega+mu*n+2h^2/U+constant : nothing
    Etrial=thermo ? kinetic-T*entropy+constant-U*moment^2/2 : nothing
    return (h=h,m=moment,gradient=-2moment+4h/U,mu_source=mu,
        mu_physical=mu+U*(n-2)/4,density=density,F=F,
        trial_F=Etrial,kinetic=thermo ? kinetic : nothing,
        entropy=thermo ? entropy : nothing)
end

function bracket_root_hf(grid,kind,a,b,n,T)
    fa=source_hf(grid,kind,a,n,T).gradient
    fb=source_hf(grid,kind,b,n,T).gradient
    @assert fa*fb<0
    # Safeguarded secant with bisection fallback; bracket width sets h accuracy.
    for iteration in 1:65
        trial=(a*fb-b*fa)/(fb-fa)
        trial=(a+.1*(b-a)<trial<b-.1*(b-a)) ? trial : (a+b)/2
        ft=source_hf(grid,kind,trial,n,T).gradient
        if abs(ft)<2e-11 || b-a<2e-9;return trial;end
        if fa*ft<=0;b=trial;fb=ft;else;a=trial;fa=ft;end
    end
    error("Field stationarity convergence failed")
end

function independent_hf(grid,kind,h,n,T,mu)
    # Explicit 2x2 eigenvectors and orbital/spin occupations, independent of dh.
    populations=zeros(2,2);kinetic=0.0;entropy=0.0
    for (is,spin) in enumerate((1,-1)), i in eachindex(grid.c)
        H0=[grid.c[i]+grid.z[i] grid.x[i];grid.x[i] grid.c[i]-grid.z[i]]
        vertex=kind==:AM ? Diagonal([1.0,-1.0]) : Matrix{Float64}(I,2,2)
        solution=eigen(Symmetric(H0-spin*h*vertex))
        for b in 1:2
            f=fermi_hf((solution.values[b]-mu)/T);v=solution.vectors[:,b]
            populations[:,is].+=abs2.(v)*f/grid.nk^2
            kinetic+=dot(v,H0*v)*f/grid.nk^2
            if 0<f<1;entropy-=(f*log(f)+(1-f)*log1p(-f))/grid.nk^2;end
        end
    end
    orbital_m=populations[:,1]-populations[:,2]
    m=kind==:AM ? (orbital_m[1]-orbital_m[2])/2 : sum(orbital_m)/2
    interaction=U*sum((populations[a,1]-.5)*(populations[a,2]-.5) for a in 1:2)
    return (m=m,F=kinetic+interaction-T*entropy,populations=populations)
end

mkpath(OUTPUT_HF)
rows=NamedTuple[];scanrows=NamedTuple[]
@testset "Uniform HF stationary branches and independent audits" begin
    for nk in (96,192,384), n in (1.4,1.46021875), T in (.05,.025), kind in (:AM,:FM)
        grid=mesh_hf(nk)
        # |m|<=n/2 for n<2, so a nonzero stationary h cannot exceed U*n/4.
        # A 128-interval scan on every mesh is empirical completeness, not proof
        # against arbitrarily narrow stationary pairs between adjacent samples.
        hs=vcat(1e-5,collect(range((U*n/4+.05)/128,U*n/4+.05;length=128)))
        values=[source_hf(grid,kind,h,n,T).gradient for h in hs]
        for (h,g) in zip(hs,values)
            push!(scanrows,(kind=kind,n=n,T=T,nk=nk,h=h,gradient=g))
        end
        roots=[0.0]
        for i in 1:length(hs)-1
            if values[i]*values[i+1]<0
                push!(roots,bracket_root_hf(grid,kind,hs[i],hs[i+1],n,T))
            end
        end
        for h in roots
            r=source_hf(grid,kind,h,n,T;thermo=true)
            step=1e-4
            plus=source_hf(grid,kind,h+step,n,T;thermo=true)
            minus=source_hf(grid,kind,h-step,n,T;thermo=true)
            curvature=(plus.gradient-minus.gradient)/(2step)
            classification=curvature>0 ? "minimum" : "maximum"
            # h residual tolerances exceed density/root solver errors.
            @test abs(r.density-n)<2e-11
            @test abs(r.gradient)<2e-9
            @test abs(r.h-U*r.m/2)<1e-8
            @test isapprox(r.F,r.trial_F;atol=2e-10,rtol=2e-10)
            # Finite-difference F derivative is a separate double-count check.
            @test abs((plus.F-minus.F)/(2step)-r.gradient)<2e-6
            push!(rows,merge((kind=kind,n=n,T=T,nk=nk,classification=classification,curvature=curvature),r))
        end
        println("Finished Nk=",nk," n=",n," T=",T," ",kind," roots=",roots)
        flush(stdout)
    end
    for kind in (:AM,:FM), h in (0.0,.35,6.1)
        grid=mesh_hf(24);r=source_hf(grid,kind,h,1.4,.05;thermo=true)
        independent=independent_hf(grid,kind,h,1.4,.05,r.mu_source)
        @test isapprox(r.m,independent.m;atol=2e-12,rtol=2e-12)
        @test isapprox(r.trial_F,independent.F;atol=2e-11,rtol=2e-11)
        @test isapprox(sum(independent.populations[1,:]),.7;atol=2e-12)
        @test isapprox(sum(independent.populations[2,:]),.7;atol=2e-12)
    end
end
for (filename,data) in (("stationary_points.csv",rows),("field_scan.csv",scanrows))
    open(joinpath(OUTPUT_HF,filename),"w") do io
        println(io,join(string.(keys(first(data))),","))
        for row in data
            println(io,join([v isa AbstractFloat ? @sprintf("%.16g",v) : string(v) for v in values(row)],","))
        end
    end
end
open(joinpath(OUTPUT_HF,"summary.md"),"w") do io
    println(io,"# Constrained uniform Hartree–Fock comparison\n")
    println(io,"U=20; shifted intraorbital interaction; n_x=n_y. Positive-field branches shown; negative fields are symmetry partners. These are finite-temperature self-consistent HF results, not gRISB or a quantitative digitization of the published curve.\n")
    println(io,"| n | T | Nk | branch | h | m | fixed-density F/site | type |")
    println(io,"|---:|---:|---:|---|---:|---:|---:|---|")
    for r in rows
        @printf(io,"| %.8f | %.3f | %d | %s | %.9f | %.9f | %.10f | %s |\n",r.n,r.T,r.nk,string(r.kind),r.h,r.m,r.F,r.classification)
    end
    println(io,"\nAll stationary points detected by 128 field intervals on each mesh are listed; h=0 is included. The scan cannot rigorously exclude narrower stationary-point pairs. Compare both T and Nk before interpreting precision. See docs/reading/transfer_hf.md for definitions and limitations.")
end
println("Wrote ",OUTPUT_HF)
