#!/usr/bin/env julia

"""Independent finite-lattice and fixed-density response checks for the HF milestone."""
module HFCompetitionAudit

using LinearAlgebra
using Printf
using Test
using Serialization

include(joinpath(@__DIR__, "hf_competition.jl"))
const HF = HFCompetition

module ReferenceKinetic
include(joinpath(@__DIR__, "../../src/noninteracting.jl"))
include(joinpath(@__DIR__, "../../src/realspace_kinetic.jl"))
end

const OUTPUT = normpath(joinpath(@__DIR__, "../../results/literature_transfer/hf_competition_audit"))

fermi(x) = x >= 0 ? exp(-x)/(1+exp(-x)) : 1/(1+exp(x))

"""
Construct an independent finite-lattice Slater-state oracle. `V` has one row
per spatial orbital and columns for up/down spin. A common chemical potential
fixes total particle number in expectation, with no fixed spin population.
"""
function finite_solution(K, V, ncells, density, temperature)
    size(V) == (size(K,1),2) || throw(DimensionMismatch("potential dimensions"))
    temperature > 0 || throw(ArgumentError("positive temperature required"))
    eigensystems = [eigen(Hermitian(K + Diagonal(V[:,s]))) for s in 1:2]
    energies = vcat((e.values for e in eigensystems)...)
    lo = minimum(energies) - 45temperature
    hi = maximum(energies) + 45temperature
    for _ in 1:90
        mu = (lo+hi)/2
        number = sum(fermi((e-mu)/temperature) for e in energies)/ncells
        if number < density
            lo = mu
        else
            hi = mu
        end
    end
    mu = (lo+hi)/2
    rho = zeros(size(V))
    kinetic = 0.0
    entropy = 0.0
    band_energy = 0.0
    for s in 1:2
        eigensystem = eigensystems[s]
        occupations = fermi.((eigensystem.values .- mu)/temperature)
        gamma = eigensystem.vectors * Diagonal(occupations) * eigensystem.vectors'
        rho[:,s] .= real.(diag(gamma))
        kinetic += real(tr(K*gamma))/ncells
        band_energy += dot(occupations,eigensystem.values)/ncells
        for f in occupations
            if 0 < f < 1
                entropy -= (f*log(f)+(1-f)*log1p(-f))/ncells
            end
        end
    end
    return (;rho, kinetic, entropy, mu, band_energy,
        density=sum(rho)/ncells, free_band=band_energy-temperature*entropy)
end

"""Repeat a local supercell potential on an independently constructed square torus."""
function repeat_potential(V, L, cellx, celly)
    L % cellx == L % celly == 0 || throw(ArgumentError("incommensurate cells"))
    size(V) == (2cellx*celly,2) || throw(DimensionMismatch("supercell potential"))
    full = zeros(eltype(V),2L^2,2)
    for y in 0:L-1, x in 0:L-1, a in 1:2
        p = 2(x+L*y)+a
        c = 2(mod(x,cellx)+cellx*mod(y,celly))+a
        full[p,:] .= V[c,:]
    end
    return full
end

function average_cells(rho, L, cellx, celly)
    localrho = zeros(eltype(rho),2cellx*celly,2)
    copies = L^2/(cellx*celly)
    for y in 0:L-1, x in 0:L-1, a in 1:2
        p = 2(x+L*y)+a
        c = 2(mod(x,cellx)+cellx*mod(y,celly))+a
        localrho[c,:] .+= rho[p,:]/copies
    end
    return localrho
end

"""Bloch projection of an independently built finite real-space matrix."""
function finite_bloch_block(K, L, cellx, celly, kx, ky)
    copies = L^2/(cellx*celly)
    plane = zeros(ComplexF64,2L^2,2cellx*celly)
    for y in 0:L-1, x in 0:L-1, a in 1:2
        p = 2(x+L*y)+a
        localx, localy = mod(x,cellx), mod(y,celly)
        c = 2(localx+cellx*localy)+a
        plane[p,c] = cis(kx*(x-localx)+ky*(y-localy))/sqrt(copies)
    end
    return plane' * K * plane
end

"""
Evaluate the complete local collinear HF stability matrix on a chosen
supercell, at fixed density. `occupation(V)` returns the per-orbital spin
populations after adjusting a common chemical potential.

The independent-particle susceptibility is chi=-d rho/d V. The response to a
uniform potential vanishes at fixed density. In the active response space,
HF curvature has the same inertia as I+sqrt(chi)*W*sqrt(chi), where
W=U*[0 I; I 0]. Negative eigenvalues identify an unstable onsite collinear
mode in this supercell. Positive values do not establish stability at omitted
wavevectors, noncollinear order, phase separation or beyond HF.
"""
function local_stability(occupation, V, U; step=1e-4, response_tolerance=2e-6)
    shape = size(V)
    shape[2] == 2 || throw(DimensionMismatch("two spin columns required"))
    dimension = length(V)
    response = zeros(dimension,dimension)
    for j in 1:dimension
        plus,minus = copy(V),copy(V)
        plus[j] += step
        minus[j] -= step
        response[:,j] .= -vec(occupation(plus)-occupation(minus))/(2step)
    end
    asymmetry = maximum(abs,response-response')
    fixed_density_error = maximum(abs,sum(response;dims=1))
    asymmetry <= response_tolerance || error("response reciprocity failed: $asymmetry")
    fixed_density_error <= response_tolerance || error("fixed-density response failed: $fixed_density_error")
    response = Matrix(Symmetric((response+response')/2))
    spectrum = eigen(Symmetric(response))
    minimum(spectrum.values) >= -response_tolerance || error("negative free susceptibility")
    square_root = spectrum.vectors * Diagonal(sqrt.(max.(spectrum.values,0))) * spectrum.vectors'
    W = zeros(dimension,dimension)
    orbital_count = shape[1]
    for i in 1:orbital_count
        W[i,i+orbital_count] = W[i+orbital_count,i] = U
    end
    curvature = eigen(Symmetric(I + square_root*W*square_root))
    return (;minimum_curvature=minimum(curvature.values),
        maximum_curvature=maximum(curvature.values),
        asymmetry, fixed_density_error,
        min_free_response=minimum(spectrum.values),
        active_response_rank=count(>(response_tolerance),spectrum.values),
        density_mode=reshape(square_root*curvature.vectors[:,1],shape),
        response, curvature_values=curvature.values)
end

function run_reference_checks()
    mkpath(OUTPUT)
    @testset "Independent real-space and fixed-density HF oracle" begin
        # The centered midpoint mesh with odd counts 1x3 contains the allowed
        # phases 0 and 0,+/-2pi/3 of a periodic L=6 torus (no boundary twist).
        L=6; cellx=6; celly=2
        g=HF.make_grid(cellx,celly,1,3)
        K=ReferenceKinetic.realspace_kinetic_matrix(L)
        for (block,(tx,ty)) in zip(g.K,g.thetas)
            oracle=finite_bloch_block(K,L,cellx,celly,tx/cellx,ty/celly)
            @test isapprox(block,oracle;atol=2e-12,rtol=2e-12)
        end
        for amplitude in (0.0,0.4,3.0)
            V=[amplitude*(sin(.7p)+.4*cos(.31p)*(s==1 ? 1 : -1))
               for p in 1:g.d,s in 1:2]
            n=52/36; T=.12
            direct=finite_solution(K,repeat_potential(V,L,cellx,celly),L^2,n,T)
            folded=HF.solve_fields(g,V,n,T)
            @test abs(direct.density-n)<2e-12
            @test isapprox(folded.rho,average_cells(direct.rho,L,cellx,celly);atol=2e-11,rtol=2e-11)
            @test isapprox(folded.mu,direct.mu;atol=2e-11,rtol=2e-11)
            @test isapprox(folded.kinetic,direct.kinetic;atol=2e-11,rtol=2e-11)
            @test isapprox(folded.entropy,direct.entropy;atol=2e-11,rtol=2e-11)
            @test isapprox(folded.bandF,direct.free_band;atol=2e-11,rtol=2e-11)
        end
        # Independent physical energy of an arbitrary, nonstationary HF trial.
        input=HF.seed_density(g,"mixed",52/36;noise=.03,seed=816)
        U=12.; n=52/36; T=.12
        actual=HF.evaluate(g,input,U,n,T)
        V=repeat_potential(U*(input[:,[2,1]].-.5),L,cellx,celly)
        direct=finite_solution(K,V,L^2,n,T)
        independentF=direct.kinetic+U*sum((direct.rho[:,1].-.5).*(direct.rho[:,2].-.5))/L^2-T*direct.entropy
        @test isapprox(actual.physicalF,independentF;atol=3e-11,rtol=3e-11)
        # Atomic fixed-density paramagnet: spin response eigenvalue beta/4,
        # yielding the exact local mean-field instability at U=4T.
        atomK=zeros(1,1);atomV=zeros(1,2)
        occupation=v->finite_solution(atomK,v,1,1.,1.).rho
        for U in (0.,3.,5.)
            result=local_stability(occupation,atomV,U;step=1e-4)
            @test isapprox(result.minimum_curvature,1-U/4;atol=2e-8,rtol=2e-8)
            @test result.fixed_density_error<2e-10
            @test result.asymmetry<2e-10
        end
    end
end

function audit_candidate(path;step=1e-4,tag="screen")
    saved=deserialize(path)
    saved.solution.converged || error("Only converged candidates receive a stability classification")
    g=HF.make_grid(saved.grid...)
    rho=saved.solution.rho;U=saved.U;n=saved.n;T=saved.T
    base=HF.evaluate(g,rho,U,n,T)
    base.residual<1e-6 || error("Candidate has lost self-consistency: $(base.residual)")
    occupation=v->HF.solve_fields(g,v,n,T;mu0=base.mu).rho
    result=local_stability(occupation,base.V,U;step=step)
    # Independently perturb along the potentially unstable density mode and
    # evaluate physical trial free energy, not the off-stationary functional.
    direction=U*result.density_mode[:,[2,1]]
    direction./=max(maximum(abs,direction),1e-12)
    probes=NamedTuple[]
    for amplitude in (-.02,-.005,.005,.02)
        r=HF.solve_fields(g,base.V+amplitude*direction,n,T;mu0=base.mu)
        F=r.kinetic+U*sum((r.rho[:,1].-.5).*(r.rho[:,2].-.5))/g.Ns-T*r.entropy
        push!(probes,(amplitude=amplitude,deltaF=F-base.physicalF))
    end
    destination=joinpath(OUTPUT,tag*"_"*saved.label)
    mkpath(destination)
    serialize(joinpath(destination,"stability.jls"),(source=abspath(path),U=U,n=n,T=T,step=step,
        grid=saved.grid,base=base,result=result,probes=probes))
    open(joinpath(destination,"summary.csv"),"w") do io
        println(io,"label,U,n,T,Nkx,Nky,step,F,residual,min_curvature,reciprocity_error,fixed_density_error,min_chi_eigenvalue")
        println(io,join((saved.label,U,n,T,g.Nkx,g.Nky,step,base.physicalF,base.residual,
            result.minimum_curvature,result.asymmetry,result.fixed_density_error,result.min_free_response),","))
    end
    open(joinpath(destination,"physical_energy_probes.csv"),"w") do io
        println(io,"potential_amplitude,delta_physical_F")
        for r in probes;println(io,join(values(r),","));end
    end
    println("Stability ",saved.label," mesh=",g.Nkx,"x",g.Nky,
        " min_curvature=",result.minimum_curvature," reciprocity=",result.asymmetry,
        " min_deltaF=",minimum(r.deltaF for r in probes))
    return result
end

function main(args=ARGS)
    if isempty(args) || args[1]=="test"
        run_reference_checks()
    elseif args[1]=="candidate"
        length(args)>=2 || error("candidate requires serialized solution")
        tag=length(args)>=3 ? args[3] : "screen"
        step=length(args)>=4 ? parse(Float64,args[4]) : 1e-4
        audit_candidate(args[2];tag=tag,step=step)
    else
        error("Usage: hf_competition_audit.jl [test|candidate checkpoint [tag [step]]]")
    end
end

end # module

if abspath(PROGRAM_FILE)==@__FILE__
    HFCompetitionAudit.main()
end
