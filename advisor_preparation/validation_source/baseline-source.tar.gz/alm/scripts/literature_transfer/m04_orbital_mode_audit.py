#!/usr/bin/env python3
"""Read-only postprocessing of saved exact-cluster orbital matrices; stdlib only."""
import cmath
import csv
import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path('/home/yiqiwan/code/AltermagnetDQMCTrial')
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'results/literature_transfer/m04_20260914'
SOURCE = ROOT / 'results/literature_transfer/ed_estimator_audit'
ATOL = 2e-10  # Conservative for rounded CSV matrices with norms below 50.
IDENTITY = [[1+0j, 0j], [0j, 1+0j]]


def read_csv(name):
    with (SOURCE / name).open() as stream:
        return list(csv.DictReader(stream))


def product(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2)] for i in range(2)]


def difference(a, b):
    return [[a[i][j]-b[i][j] for j in range(2)] for i in range(2)]


def trace(a):
    return a[0][0]+a[1][1]


def norm(a):
    return math.sqrt(sum(abs(z)**2 for row in a for z in row))


def hermitize(a):
    return [[(a[i][j]+a[j][i].conjugate())/2 for j in range(2)] for i in range(2)]


def eigen_summary(a):
    center = (a[0][0].real+a[1][1].real)/2
    halfgap = math.sqrt(((a[0][0].real-a[1][1].real)/2)**2+abs(a[0][1])**2)
    low, high = center-halfgap, center+halfgap
    assert low > -ATOL
    assert halfgap > ATOL, 'Leading mode is not uniquely defined.'
    projector = [[(a[i][j]-low*IDENTITY[i][j])/(2*halfgap) for j in range(2)] for i in range(2)]
    residual = norm(difference(product(a, projector), [[high*z for z in row] for row in projector]))
    idempotency = norm(difference(product(projector, projector), projector))
    assert residual < ATOL and idempotency < ATOL
    odd = (a[0][0]+a[1][1]-a[0][1]-a[1][0]).real
    even = (a[0][0]+a[1][1]+a[0][1]+a[1][0]).real
    odd_overlap = (projector[0][0]+projector[1][1]-projector[0][1]-projector[1][0]).real/2
    assert -ATOL < odd_overlap < 1+ATOL
    return {
        'eigenvalue_min': low, 'eigenvalue_max': high,
        'odd_channel_unnormalized': odd, 'even_channel_unnormalized': even,
        'odd_rayleigh_unit_vector': odd/2,
        'leading_mode_odd_overlap_squared': odd_overlap,
        'leading_mode_xz_weight': projector[0][0].real,
        'odd_channel_if_orbital_cross_terms_dropped': trace(a).real,
        'odd_channel_cross_term_contribution': -(a[0][1]+a[1][0]).real,
        'eigenprojector_residual': residual, 'projector_idempotency_error': idempotency,
    }, projector


raw_matrices = read_csv('orbital_covariance_and_response.csv')
realspace = read_csv('real_space_spin_covariance.csv')
references = {float(r['U']): r for r in read_csv('reference.csv')}
groups = {}
for row in raw_matrices:
    key = (float(row['U']), row['q'])
    groups.setdefault(key, []).append(row)

qpoints = {'q0': (0., 0.), 'qpi0': (math.pi, 0.),
           'qpipi': (math.pi, math.pi), 'generic': (math.pi/3, math.pi/5)}
assert len(groups) == 12
assert set(k[1] for k in groups) == set(qpoints)
results = []
max_fourier_residual = max_hermiticity = max_q0_reference_error = 0.
for (u, label), rows in sorted(groups.items()):
    assert len(rows) == 4
    matrices = {}
    for name, prefix in [('covariance', 'covariance'), ('static_response', 'chi_regular')]:
        a = [[0j, 0j], [0j, 0j]]
        seen = set()
        for r in rows:
            i, j = int(r['orbital_a'])-1, int(r['orbital_b'])-1
            assert (i, j) not in seen
            seen.add((i, j))
            a[i][j] = complex(float(r[prefix+'_real']), float(r[prefix+'_imag']))
        herm_error = max(abs(a[i][j]-a[j][i].conjugate()) for i in range(2) for j in range(2))
        assert herm_error < ATOL
        max_hermiticity = max(max_hermiticity, herm_error)
        matrices[name] = hermitize(a)
    qx, qy = qpoints[label]
    fourier = [[0j, 0j], [0j, 0j]]
    source_rows = [r for r in realspace if float(r['U']) == u]
    assert len(source_rows) == 64
    for r in source_rows:
        ma, mb = int(r['mode_a'])-1, int(r['mode_b'])-1
        cell_a, a = divmod(ma, 2)
        cell_b, b = divmod(mb, 2)
        xa, ya = cell_a % 2, cell_a // 2
        xb, yb = cell_b % 2, cell_b // 2
        fourier[a][b] += float(r['connected'])*cmath.exp(1j*(qx*(xa-xb)+qy*(ya-yb)))/4
    fourier_residual = norm(difference(fourier, matrices['covariance']))
    assert fourier_residual < ATOL
    max_fourier_residual = max(max_fourier_residual, fourier_residual)
    c, pc = eigen_summary(matrices['covariance'])
    chi, pchi = eigen_summary(matrices['static_response'])
    leading_overlap = trace(product(pc, pchi)).real
    assert -ATOL < leading_overlap < 1+ATOL
    if label == 'q0':
        err = max(abs(c['odd_channel_unnormalized']-float(references[u]['S_odd_q0'])),
                  abs(chi['odd_channel_unnormalized']-float(references[u]['chi_odd_q0_regular'])))
        assert err < ATOL
        max_q0_reference_error = max(max_q0_reference_error, err)
    comm = difference(product(matrices['covariance'], matrices['static_response']),
                      product(matrices['static_response'], matrices['covariance']))
    results.append({'U': u, 'q_label': label, 'qx_over_pi': qx/math.pi, 'qy_over_pi': qy/math.pi,
                    'covariance': c, 'static_response': chi,
                    'leading_mode_overlap_squared_C_chi': leading_overlap,
                    'normalized_C_chi_commutator_frobenius': norm(comm)/(norm(matrices['covariance'])*norm(matrices['static_response'])),
                    'reconstructed_fourier_residual': fourier_residual})

rankings = []
for u in sorted(references):
    subset = [r for r in results if r['U'] == u]
    for kind in ('covariance', 'static_response'):
        ordered = sorted(subset, key=lambda r: r[kind]['eigenvalue_max'], reverse=True)
        tier = 0
        tier_value = None
        ranked = []
        for r in ordered:
            value = r[kind]['eigenvalue_max']
            if tier_value is None or abs(value-tier_value) > ATOL:
                tier += 1
                tier_value = value
            ranked.append({'q': r['q_label'], 'largest_eigenvalue': value,
                           'rank_tier_tied_within_absolute_tolerance': tier})
        rankings.append({'U': u, 'matrix': kind, 'ranking_of_only_four_sampled_probes':
                         ranked})

manifest = {}
for path in [SOURCE / name for name in ['orbital_covariance_and_response.csv',
             'real_space_spin_covariance.csv', 'reference.csv']] + [Path(__file__)]:
    manifest[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
payload = {
    'status': 'completed_saved_data_postprocessing_only', 'date': '2026-09-14',
    'source_manifest_sha256': manifest,
    'scope': 'Open 2x2; 4 cells; dxz,dyz; t=(-1,-1.75,-0.85,-0.65); shifted intraorbital U only; U=0,2,12; Nup=Ndown=3; n=1.5; unique zero-temperature singlet.',
    'normalization': 'Physical Sz=(nup-ndown)/2; Oa(q)=sum_r exp(-iq.r) Sz_ra/sqrt(4). C=<Odag O>c; chi is saved regular static Lehmann response. Eigenvalues use unit-norm orbital vectors. Physical even/odd channels use (1,+/-1), hence are twice their unit-vector Rayleigh quotient.',
    'basis_warning': 'These are eigenmodes of the two-by-two orbital-density response, not one-electron bands. A simple orbital 2x2 density covariance rotation is not a fermion orbital-to-band transformation.',
    'limitations': ['Only four Fourier probes of an open cluster; q is not a translation quantum number.',
                    'No new ED spectrum, interacting simulation, source pairing result, finite-size scaling, or spontaneous order is reproduced.',
                    'No full Brillouin-zone maximum inferred. The source equal-time/Lehmann audit was already complete.',
                    'CP magnetic accuracy and density gates unchanged; correlated lattice extension remains unvalidated.'],
    'validation': {'absolute_tolerance': ATOL, 'matrices_examined': 24,
                   'maximum_fourier_reconstruction_residual': max_fourier_residual,
                   'maximum_hermiticity_residual': max_hermiticity,
                   'maximum_q0_reference_error': max_q0_reference_error},
    'results': results, 'sampled_probe_rankings': rankings,
}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'ed_orbital_mode_audit.json').write_text(json.dumps(payload, indent=2, allow_nan=False)+'\n')
print(json.dumps({'validation': payload['validation'], 'sampled_probe_rankings': rankings,
                  'lowest_leading_mode_overlap': min(results, key=lambda r: r['leading_mode_overlap_squared_C_chi']),
                  'U12_qpi0': next(r for r in results if r['U']==12 and r['q_label']=='qpi0')}, indent=2))
