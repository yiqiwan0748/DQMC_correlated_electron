using LinearAlgebra
using DelimitedFiles

# Independent LAPACK eigensolver check of the closed-form projector calculation.
source = "/home/yiqiwan/code/AltermagnetDQMCTrial/results/literature_transfer/ed_estimator_audit/orbital_covariance_and_response.csv"
data, header = readdlm(source, ',', Any; header=true)
cols = Dict(String(v) => i for (i,v) in enumerate(vec(header)))
groups = sort(unique([(Float64(data[i,cols["U"]]), String(data[i,cols["q"]])) for i in axes(data,1)]))
output_dir = isempty(ARGS) ? "/home/yiqiwan/code/AltermagnetDQMCTrial/results/literature_transfer/m04_20260914" : ARGS[1]
mkpath(output_dir)
open(joinpath(output_dir, "independent_eigensolver.csv"), "w") do io
    println(io, "U,q,matrix,eigenvalue_min,eigenvalue_max,leading_xz_weight,leading_odd_weight,eigen_residual")
    odd = [1.0,-1.0]/sqrt(2.0)
    for (u,q) in groups, (kind,prefix) in [("covariance","covariance"),("static_response","chi_regular")]
        A=zeros(ComplexF64,2,2)
        for row in eachrow(data)
            if Float64(row[cols["U"]])==u && String(row[cols["q"]])==q
                a=Int(row[cols["orbital_a"]]); b=Int(row[cols["orbital_b"]])
                A[a,b]=complex(Float64(row[cols[prefix*"_real"]]),Float64(row[cols[prefix*"_imag"]]))
            end
        end
        @assert norm(A-A') < 2e-10
        eig=eigen(Hermitian((A+A')/2))
        v=eig.vectors[:,end]
        residual=norm(A*v-eig.values[end]*v)
        @assert residual < 2e-10
        println(io,join((u,q,kind,eig.values[1],eig.values[2],abs2(v[1]),abs2(dot(odd,v)),residual),','))
    end
end
println("Independent LAPACK eigensystems written for 24 matrices.")
