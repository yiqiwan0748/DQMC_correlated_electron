#!/usr/bin/env julia
# Isolated M05 diagnostic: one atom, two orbitals, canonical N=2, all Sz sectors.
# Reuses the validated source-interaction solver; never changes the lattice model.
using LinearAlgebra, Printf, SHA, TOML
include(joinpath(@__DIR__, "..", "prl_101_237004_ed.jl"))
using .PRL101237004ED

const M05_ATOL = 2e-12 # 6x6 Float64 blocks, U<=4: conservative eigensolver roundoff.
const M05_ROOT = normpath(joinpath(@__DIR__, "..", ".."))

function tensor_operators()
    c0 = [0.0 1.0; 0.0 0.0]
    p = [1.0 0.0; 0.0 -1.0]
    eye = Matrix{Float64}(I, 2, 2)
    # Tensor convention: lowest bit is x-up, then y-up, x-down, y-down.
    c = [reduce(kron, [j == i ? c0 : j < i ? p : eye for j in 4:-1:1]) for i in 1:4]
    n = [x' * x for x in c]
    nx, ny = n[1] + n[3], n[2] + n[4]
    sx, sy = (n[1] - n[3])/2, (n[2] - n[4])/2
    px, py = c[1]'*c[3], c[2]'*c[4]
    dotspin = sx*sy + (px*py' + px'*py)/2
    plus, z = px+py, sx+sy
    pair = c[1]'*c[3]'*c[4]*c[2]
    obs = Dict("double_occupancy" => n[1]*n[3]+n[2]*n[4],
        "spin_squared" => z*z+(plus*plus'+plus'*plus)/2,
        "spin_dot" => dotspin, "orbital_odd_equal_time" => (sx-sy)^2,
        "orbital_even_equal_time" => z*z, "interorbital_density" => nx*ny)
    (; c, obs, dotspin, pair, nx, ny)
end

function compare_one_model(U, J, target, operators, indices)
    states = indices .- 1
    H = zeros(6,6)
    covered = zeros(Int,6)
    for nup in 0:2
        op = sector_hamiltonian(zeros(2,2), U, nup, 2-nup; J=J)
        positions = [findfirst(==(Int(s)), states) for s in op.basis.states]
        H[positions,positions] = Matrix(op)
        covered[positions] .+= 1
    end
    @assert all(==(1),covered) "Canonical trace must cover each of six states once."
    D = operators.obs["double_occupancy"]
    if target
        @assert J == 0
        # J=0 in reused source solver retains U'=U; remove it explicitly.
        H -= U*(operators.nx*operators.ny)[indices,indices]
        literal = U*D
    else
        literal = U*D + (U-2J-J/2)*(operators.nx*operators.ny) -
            2J*operators.dotspin + J*(operators.pair+operators.pair')
    end
    residual = maximum(abs,H-literal[indices,indices])
    @assert residual <= M05_ATOL
    @assert maximum(abs,H-H') <= M05_ATOL
    S2 = operators.obs["spin_squared"][indices,indices]
    @assert maximum(abs,H*S2-S2*H) <= M05_ATOL
    (; H, residual)
end

function thermal(H, obs, beta)
    e = eigen(Symmetric(H))
    weights = exp.(-beta*(e.values.-minimum(e.values)))
    weights ./= sum(weights)
    Dict(k => sum(weights .* diag(e.vectors'*A*e.vectors)) for (k,A) in obs)
end

function state_counting(U,J,target,beta)
    if target
        w = exp(-beta*U)
        z = 4+2w
        d, s2, dotspin, odd, even = 2w/z, 6/z, 0.0, 2/z, 2/z
    else
        # Relative to triplet energy U-3J; degeneracies 3, 1, 1, 1.
        # One singly occupied singlet and one pair state have gap 2J;
        # the other pair state has gap 4J. Independent of solver eigenvectors.
        w, v = exp(-2beta*J), exp(-4beta*J)
        z = 3+2w+v
        d, s2, dotspin, odd, even = (w+v)/z, 6/z, 0.75*(1-w)/z, (1+w)/z, 2/z
    end
    Dict("double_occupancy"=>d,"spin_squared"=>s2,"spin_dot"=>dotspin,
        "orbital_odd_equal_time"=>odd,"orbital_even_equal_time"=>even,
        "interorbital_density"=>1-d)
end

function main()
    out = isempty(ARGS) ? joinpath(M05_ROOT,"results","literature_transfer","m05_20260915") : abspath(ARGS[1])
    mkpath(out)
    operators = tensor_operators()
    indices = [s+1 for s in 0:15 if count_ones(s)==2]
    obs = Dict(k=>A[indices,indices] for (k,A) in operators.obs)
    models = [("source_J0",4.0,0.0,false),("source_J0p4",4.0,0.4,false),
        ("source_J1",4.0,1.0,false),("target_U_only",4.0,0.0,true),
        ("source_U0",0.0,0.0,false),("target_U0",0.0,0.0,true)]
    keys_order = sort(collect(keys(obs)))
    maximum_formula_error = 0.0
    maximum_shift_error = 0.0
    maximum_literal_error = 0.0
    rows = 0
    open(joinpath(out,"atomic_ensemble.csv"),"w") do io
        println(io,"model,U,J,Uprime,beta,N,",join(keys_order,","),",max_state_counting_error,constant_shift_error")
        for (label,U,J,target) in models
            block = compare_one_model(U,J,target,operators,indices)
            maximum_literal_error = max(maximum_literal_error,block.residual)
            for beta in (0.0,0.25,1.0,4.0,20.0)
                actual = thermal(block.H,obs,beta)
                expected = state_counting(U,J,target,beta)
                error = maximum(abs(actual[k]-expected[k]) for k in keys_order)
                # Two-orbital centered intraorbital interaction at fixed N=2
                # differs from unshifted by -U*N/2+2U/4 = -U/2.
                shifted = thermal(block.H-U/2*I,obs,beta)
                shift_error = maximum(abs(actual[k]-shifted[k]) for k in keys_order)
                @assert error <= M05_ATOL
                @assert shift_error <= M05_ATOL
                @assert abs(actual["interorbital_density"]+actual["double_occupancy"]-1) <= M05_ATOL
                @assert abs(3actual["orbital_even_equal_time"]-actual["spin_squared"]) <= M05_ATOL
                maximum_formula_error = max(maximum_formula_error,error)
                maximum_shift_error = max(maximum_shift_error,shift_error)
                values = [label,U,J,target ? 0.0 : U-2J,beta,2,
                    [actual[k] for k in keys_order]...,error,shift_error]
                println(io,join(values,","))
                rows += 1
            end
        end
    end
    source_path = joinpath(M05_ROOT,"results","literature_transfer","sources","10.1007_s11467-011-0222-z.pdf")
    inputs = [abspath(@__FILE__),joinpath(M05_ROOT,"scripts","prl_101_237004_ed.jl"),source_path]
    summary = Dict("status"=>"passed","date"=>"2026-09-15","row_count"=>rows,
        "observable_comparisons"=>rows*length(obs),"absolute_tolerance"=>M05_ATOL,
        "max_formula_error"=>maximum_formula_error,"max_shift_error"=>maximum_shift_error,
        "max_literal_matrix_error"=>maximum_literal_error,
        "geometry"=>"One isolated atom, two orbitals dxz/dyz; no hopping, crystal field, SOC or external field.",
        "ensemble"=>"Canonical N=2, all Sz sectors, finite beta including beta=0 high-temperature control; kb=hbar=1.",
        "normalization"=>"Sz=(nup-ndown)/2; D is sum of intraorbital doublons per atom; all moments equal-time.",
        "source_version"=>"Published review PDF, Sec3.2 Eq5, restricted to two orbitals.",
        "new_work"=>"Canonical thermal observables with independent multiplet state counting; atomic spectra were already tested in repository.",
        "limits"=>"Atomic comparison, n=2, not target lattice at n=1.46021875. No static susceptibility, lattice order, or review figures reproduced.",
        "inputs"=>[Dict("path"=>p,"sha256"=>bytes2hex(sha256(read(p)))) for p in inputs])
    open(io->TOML.print(io,summary),joinpath(out,"validation.toml"),"w")
    @printf("PASS: %d rows, %d independent observable comparisons; max error %.3e, tolerance %.3e\n",rows,rows*length(obs),maximum_formula_error,M05_ATOL)
end

if abspath(PROGRAM_FILE)==@__FILE__
    main()
end
