"""Independent Decimal check of M06 saved-density projections (standard library)."""
import csv
import hashlib
import json
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 50
ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results/literature_transfer/m06_20260921"
HF = ROOT / "results/literature_transfer/hf_competition/control_U12.0_n1.46021875_T0.05"
TOL = Decimal("2e-12")
errors = []
for summary in csv.DictReader((OUT / "saved_hf_summary.csv").open()):
    sites = {}
    for row in csv.DictReader((HF / (summary["candidate"] + "_density.csv")).open()):
        key = (int(row["x"]), int(row["y"]))
        sites.setdefault(key, {})[int(row["orbital"])] = (
            Decimal(row["rho_up"]), Decimal(row["rho_down"]))
    vectors = []
    for (x, y), d in sites.items():
        xu, xd = d[1]; yu, yd = d[2]
        vectors.append((xu+xd+yu+yd, xu+xd-yu-yd,
                        xu-xd+yu-yd, xu-xd-yu+yd,
                        (xu-xd-yu+yd) * ((-1)**x) / 2))
    means = [sum(v[j] for v in vectors) / len(vectors) for j in range(5)]
    for key, value in zip(("n_mean", "p_mean", "m_mean", "q_mean", "abs_Delta_pi0"),
                          means[:4]+[abs(means[4])]):
        err = abs(Decimal(summary[key])-value)
        assert err <= TOL, (summary["candidate"], key, err)
        errors.append(float(err))
    for key, value in (("M_m_over_2", means[2]/2), ("Delta_q_over_2",means[3]/2)):
        err = abs(Decimal(summary[key])-value)
        assert err <= TOL
        errors.append(float(err))
result = {"method": "50-digit Decimal direct occupation sums and exact (-1)^x Fourier weights",
          "comparisons": len(errors), "tolerance": float(TOL), "max_residual": max(errors),
          "scope": "Independent saved-density projection check; no HF solver or stability claim",
          "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT / "independent_validation.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
