#!/usr/bin/env julia
# Read-only audit of source Eq. (13) and saved HF occupations; no solver calls.
using DelimitedFiles, SHA, TOML, Test

const ROOT = normpath(joinpath(@__DIR__, "..", ".."))
const OUT = joinpath(ROOT, "results", "literature_transfer", "m06_20260921")
const BATCH = "control_U12.0_n1.46021875_T0.05"
const HF = joinpath(ROOT, "results", "literature_transfer", "hf_competition")
const TOL = 2e-12 # Conservative rounding bound for four-term sums and <=12-site Float64 DFTs.
const CHANNELS = ("n", "p", "m", "q")
const SIGNS = ((1,1), (1,-1), (-1,1), (-1,-1))
const errors = Dict{String,Float64}()

function check(name, residual; tolerance=TOL)
    errors[name] = max(get(errors, name, 0.0), Float64(residual))
    @test residual <= tolerance
end

# Independent literal definitions, ordered as (xz up, xz down, yz up, yz down).
function channels(v)
    nx, ny = v[1]+v[2], v[3]+v[4]
    mx, my = v[1]-v[2], v[3]-v[4]
    [nx+ny, nx-ny, mx+my, mx-my]
end

function audit(label, rhos, coords, Lx, Ly)
    @test length(coords) == Lx*Ly == size(rhos, 2)
    @test all(-TOL .<= rhos .<= 1+TOL)
    c = reduce(hcat, (channels(rhos[:,i]) for i in axes(rhos,2)))
    reconstructed = [sum((1,a,s,a*s).*c[:,i])/4 for (a,s) in SIGNS, i in axes(c,2)]
    check("occupation_reconstruction", maximum(abs.(reconstructed-rhos)))
    spinflip = reduce(hcat, (channels(rhos[[2,1,4,3],i]) for i in axes(rhos,2)))
    exchange = reduce(hcat, (channels(rhos[[3,4,1,2],i]) for i in axes(rhos,2)))
    check("spin_reversal", maximum(abs.(spinflip-[1,1,-1,-1].*c)))
    check("orbital_exchange", maximum(abs.(exchange-[1,-1,1,-1].*c)))
    modes = Dict((px,py)=>[sum(c[j,i]*cis(-2pi*(px*x/Lx+py*y/Ly))
                    for (i,(x,y)) in enumerate(coords))/(Lx*Ly) for j in 1:4]
                 for px in 0:Lx-1 for py in 0:Ly-1)
    inv = [sum(modes[(px,py)][j]*cis(2pi*(px*x/Lx+py*y/Ly))
                for px in 0:Lx-1 for py in 0:Ly-1) for j in 1:4, (x,y) in coords]
    check("fourier_inverse", maximum(abs.(inv-c)))
    for j in 1:4
        check("parseval", abs(sum(abs2, c[j,:])/(Lx*Ly)-sum(abs2(v[j]) for v in values(modes))))
    end
    return c, modes
end

function writecsv(path, header, rows)
    open(path,"w") do io
        println(io, join(header,','))
        for row in rows
            println(io, join(row,','))
        end
    end
end

function main()
    mkpath(OUT)
    inputs = [abspath(@__FILE__), joinpath(HF,"all_candidates.csv"),
              joinpath(ROOT,"results/literature_transfer/sources/10.1103_PhysRevB.81.014511.pdf")]
    fourier_rows, occupation_rows, summaries = [], [], []
    synthetic_cases = (("source_mixed_Q", .37,.08,.06,.10,(1,0),(0,1)),
                       ("source_uniform_compensated", .365,0.,0.,.15,(0,0),(0,0)))
    for (label,ns,ms,ps,qs,Q1,Q2) in synthetic_cases
        coords = [(x,y) for x in 0:1 for y in 0:1]
        # Literal source ansatz; n_s is per spin/orbital, other coefficients /2.
        rhos = [ns+s*ms*(-1)^(Q1[1]*x+Q1[2]*y)/2+
                  a*ps*(-1)^(Q2[1]*x+Q2[2]*y)/2+
                  a*s*qs*(-1)^((Q1[1]+Q2[1])*x+(Q1[2]+Q2[2])*y)/2
                for (a,s) in SIGNS, (x,y) in coords]
        c, modes = audit(label,rhos,coords,2,2)
        expected = ((0,0)=>4ns, Q2=>2ps, Q1=>2ms,
                    (mod(Q1[1]+Q2[1],2),mod(Q1[2]+Q2[2],2))=>2qs)
        for ((px,py),v) in modes, j in 1:4
            prediction = (px,py)==expected[j].first ? expected[j].second : 0.0
            check("source_fourier_amplitude_and_forbidden_leakage",abs(v[j]-prediction))
            push!(fourier_rows,(label,2,2,px,py,CHANNELS[j],real(v[j]),imag(v[j]),abs(v[j]),prediction))
        end
        for (i,(x,y)) in enumerate(coords)
            push!(occupation_rows,(label,x,y,rhos[:,i]...,c[:,i]...))
        end
    end
    metadata, head = readdlm(joinpath(HF,"all_candidates.csv"),',',Any;header=true)
    index = Dict(String(name)=>i for (i,name) in enumerate(vec(head)))
    amrow = only([r for r in eachrow(metadata) if r[index["batch"]]==BATCH && r[index["label"]]=="AM"])
    for label in ("AM","AM_perturbed","FM","random1")
        path = joinpath(HF,BATCH,label*"_density.csv"); push!(inputs,path)
        raw = readdlm(path,',',Float64;skipstart=1)
        row = only([r for r in eachrow(metadata) if r[index["batch"]]==BATCH && r[index["label"]]==label])
        Lx,Ly = Int(row[index["Lx"]]),Int(row[index["Ly"]])
        coords = [(x,y) for x in 0:Lx-1 for y in 0:Ly-1]
        @test size(raw,1)==2Lx*Ly
        rhos = zeros(4,Lx*Ly)
        for (i,(x,y)) in enumerate(coords), a in 1:2
            rr = only([r for r in eachrow(raw) if r[1]==x && r[2]==y && r[3]==a])
            rhos[2a-1,i],rhos[2a,i] = rr[4],rr[5]
        end
        c,modes = audit(label,rhos,coords,Lx,Ly)
        n,p,m,q = real.(modes[(0,0)])
        check("saved_density", abs(n-row[index["n"]]);tolerance=2e-10)
        check("saved_M_normalization", abs(m/2-row[index["M"]]))
        check("saved_Delta_normalization", abs(q/2-row[index["Delta"]]))
        mode=(Int(row[index["leading_px"]]),Int(row[index["leading_py"]]))
        odd=string(row[index["leading_odd"]])=="true"
        check("saved_leading_mode",abs(abs(modes[mode][odd ? 4 : 3])/2-row[index["leading_amplitude"]]))
        f=row[index["F_physical"]]
        push!(summaries,(label,n,p,m,q,m/2,q/2,maximum(c[1,:])-minimum(c[1,:]),
              abs(modes[(Lx÷2,0)][4])/2,f,f-amrow[index["F_physical"]],
              row[index["converged"]],row[index["residual"]]))
        for ((px,py),v) in sort(collect(modes);by=first),j in 1:4
            push!(fourier_rows,(label,Lx,Ly,px,py,CHANNELS[j],real(v[j]),imag(v[j]),abs(v[j]),""))
        end
        for (i,(x,y)) in enumerate(coords)
            push!(occupation_rows,(label,x,y,rhos[:,i]...,c[:,i]...))
        end
    end
    writecsv(joinpath(OUT,"occupation_channels.csv"),("case","x","y","xz_up","xz_down","yz_up","yz_down","n","p","m","q"),occupation_rows)
    writecsv(joinpath(OUT,"fourier_channels.csv"),("case","Lx","Ly","px","py","channel","real","imag","magnitude","synthetic_prediction"),fourier_rows)
    writecsv(joinpath(OUT,"saved_hf_summary.csv"),("candidate","n_mean","p_mean","m_mean","q_mean","M_m_over_2","Delta_q_over_2","total_site_charge_range","abs_Delta_pi0","saved_F","saved_F_minus_AM","saved_converged","saved_residual"),summaries)
    provenance=Dict("date"=>"2026-09-21","tolerance"=>TOL,"density_tolerance"=>2e-10,
      "tolerance_reason"=>"2e-12 bounds four-term arithmetic and <=12-cell DFT rounding; density 2e-10 checks saved chemical-potential constraint, not a new convergence claim.",
      "max_residuals"=>errors,"inputs"=>Dict(relpath(p,ROOT)=>bytes2hex(sha256(read(p))) for p in inputs),
      "scope"=>"Two synthetic source Eq13 fixtures and postprocessing four saved 6x2 HF candidate densities. No solver, model changes, new variational search, thermodynamic limit, or source phase reproduction.",
      "normalization"=>"Channels are n=sum rho, p=nx-ny, m=mx+my, q=mx-my with ma=rho_up-rho_down. DFT=mean exp(-ik.r) channel. Physical Sz=ma/2; saved M=m/2 and Delta=q/2. Source n=4ns and channels=2 times source amplitude/phase.",
      "existing_gates"=>"Unchanged: saved HF candidates are approximate stationary branches and do not establish a correlated ground state or global minimum.")
    open(joinpath(OUT,"validation.toml"),"w") do io; TOML.print(io,provenance); end
    println("M06 audit complete; maximum check residual (including saved density) = ",maximum(values(errors)))
end

@testset "M06 source-to-target occupation channel audit" main()
