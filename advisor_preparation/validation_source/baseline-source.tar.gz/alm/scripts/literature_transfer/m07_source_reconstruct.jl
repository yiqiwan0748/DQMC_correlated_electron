# Bounded published-source fixed-field check; no SCF, no target-model extension.
using LinearAlgebra, SHA
BLAS.set_num_threads(1)
# Override output/meshes for an incremental refinement; ordinary runs reproduce all meshes.
const OUT=get(ENV, "MOREO_M07_SOURCE_OUT", normpath(joinpath(@__DIR__, "../../results/literature_transfer/m07_20260922/source_reconstruction")))
const MESHES=parse.(Int, split(get(ENV, "MOREO_M07_SOURCE_MESHES", "64,128,256,512"), ','))
@assert all(L > 0 && iseven(L) for L in MESHES)
const EXISTING=get(ENV, "MOREO_M07_SOURCE_EXISTING", "")
mkpath(OUT)
const DENSITY=[1.590,1.586,0.824]
const MOMENT=[0.04,0.15,0.014]
const TEMP=0.0005 # eV, auxiliary regularization; not a source parameter.
const WIDTH=0.005 # eV Gaussian sigma, source Fig. 1.
fermi(x)=x>=0 ? exp(-x)/(1+exp(-x)) : 1/(1+exp(x))
function h0(x,y)
    cx,cy,sx,sy=cos(x),cos(y),sin(x),sin(y)
    # Source PRB81 014511 Eqs(5)-(10), Table I; no chemical potential included.
    a=.12cx+.04cy+.12cx*cy
    b=.04cx+.12cy+.12cx*cy
    c=.4*(cx+cy)+1.2cx*cy+.4
    ab=-.04sx*sy
    ac=im*(-.4sx+.4sx*cy)
    bc=im*(-.4sy+.4sy*cx)
    ComplexF64[a ab ac; ab b bc; conj(ac) conj(bc) c]
end
function hstripe(x,y,U;qx=pi,qy=0.,n=DENSITY,m=MOMENT)
    J=U/4; Up=U-2J
    v=U*n/2+(Up-J/2)*(sum(n).-n)
    w=-(U*m+J*(sum(m).-m))/2
    h=zeros(ComplexF64,6,6)
    h[1:3,1:3]=h0(x,y)+Diagonal(v)
    h[4:6,4:6]=h0(x+qx,y+qy)+Diagonal(v)
    h[1:3,4:6]=Diagonal(w);h[4:6,1:3]=Diagonal(w)
    h
end
function sample(L,U)
    N=L^2; E=zeros(6,N); W=zeros(3,6,N); M=zeros(3,6,N)
    normerr=0.; residual=0.
    for jy in 0:L-1, jx in 0:L-1
        k=jx+L*jy+1;x=-pi+2pi*(jx+.5)/L;y=-pi+2pi*(jy+.5)/L
        h=hstripe(x,y,U); ee=eigen(Hermitian(h));E[:,k]=ee.values
        for a in 1:3,b in 1:6
            W[a,b,k]=abs2(ee.vectors[a,b])+abs2(ee.vectors[a+3,b])
            M[a,b,k]=2real(ee.vectors[a,b]*conj(ee.vectors[a+3,b]))
        end
        normerr=max(normerr,maximum(abs.(sum(W[:,:,k],dims=2).-2)))
        if k%101==1;residual=max(residual,maximum(abs.(h*ee.vectors-ee.vectors*Diagonal(ee.values))));end
    end
    lo=minimum(E)-.1; hi=maximum(E)+.1
    for _ in 1:65
        mu=(lo+hi)/2; d=sum(fermi((e-mu)/TEMP) for e in E)/N
        d<4 ? (lo=mu) : (hi=mu)
    end
    mu=(lo+hi)/2; occ=zeros(3); mag=zeros(3); fs=zeros(3); deeper=zeros(3)
    for k in 1:N,b in 1:6
        eps=E[b,k]-mu;f=fermi(eps/TEMP)
        g0=exp(-eps^2/(2WIDTH^2))/(sqrt(2pi)*WIDTH)
        gm=exp(-(eps+.05)^2/(2WIDTH^2))/(sqrt(2pi)*WIDTH)
        for a in 1:3
            occ[a]+=W[a,b,k]*f/N;mag[a]+=M[a,b,k]*f/N
            fs[a]+=W[a,b,k]*g0/N;deeper[a]+=W[a,b,k]*gm/N
        end
    end
    (;L,U,mu,occ,mag,fs,deeper,normerr,residual,minweight=minimum(W))
end
# Independent matrix covariance with x/y and xz/yz exchanged; source spin state rotates too.
perm=[2,1,3,5,4,6]
covariance_error=maximum(maximum(abs.(hstripe(x,y,.7)[perm,perm]-hstripe(y,x,.7;qx=0.,qy=pi,n=DENSITY[[2,1,3]],m=MOMENT[[2,1,3]]))) for (x,y) in ((.31,-1.23),(2.2,.71),(-.43,1.77)))
rows=[]
# Optional prior CSV rows are read unchanged, so a refinement can preserve completed work.
# The input columns and fixed thermal/broadening parameters are explicitly checked.
if !isempty(EXISTING)
    lines=readlines(EXISTING)
    @assert first(lines)=="U,L,T,sigma,mu,n_xz,n_yz,n_xy,m_xz,m_yz,m_xy,A_xz_0,A_yz_0,A_xy_0,A_xz_minus005,A_yz_minus005,A_xy_minus005,max_normalization_error,max_eigen_residual,min_weight"
    for line in lines[2:end]
        a=parse.(Float64,split(line,','))
        @assert length(a)==20 && a[3]==TEMP && a[4]==WIDTH
        push!(rows,(U=a[1],L=Int(a[2]),mu=a[5],occ=a[6:8],mag=a[9:11],fs=a[12:14],deeper=a[15:17],normerr=a[18],residual=a[19],minweight=a[20]))
    end
end
for U in (0.,.7),L in MESHES
    t=@elapsed r=sample(L,U); filter!(old -> (old.U,old.L)!=(U,L),rows); push!(rows,r)
    println((U=U,L=L,seconds=t,mu=r.mu,n=r.occ,m=r.mag,A0=r.fs,Aminus05=r.deeper));flush(stdout)
end
sort!(rows;by=r -> (r.U,r.L))
open(joinpath(OUT,"source_fixed_field_summary.csv"),"w") do io
    println(io,"U,L,T,sigma,mu,n_xz,n_yz,n_xy,m_xz,m_yz,m_xy,A_xz_0,A_yz_0,A_xy_0,A_xz_minus005,A_yz_minus005,A_xy_minus005,max_normalization_error,max_eigen_residual,min_weight")
    for r in rows
        println(io,join((r.U,r.L,TEMP,WIDTH,r.mu,r.occ...,r.mag...,r.fs...,r.deeper...,r.normerr,r.residual,r.minweight),","))
    end
end
open(joinpath(OUT,"validation.txt"),"w") do io
    println(io,"source=PRB81 180514(R) Fig1 fixed rounded source fields; kinetic=PRB81 014511 Eqs5-10 TableI")
    println(io,"n_input=",DENSITY,";m_input=",MOMENT)
    println(io,"full_BZ normalization: factor spin2 times folding1/2 =1; weight includes rows alpha and alpha+3; total orbital spectral weight2")
    println(io,"auxiliary_T_eV=",TEMP,";source_Gaussian_sigma_eV=",WIDTH,"; no self-consistency, field fitting, digitization, or ground-state selection")
    println(io,"covariance_error=",covariance_error)
    println(io,"tolerance=2e-12 normalization,covariance,eigenresidual,number; Float64 6x6 matrices and accumulated finite-sum rounding")
    passed=all(r.normerr<2e-12 && r.residual<2e-12 && r.minweight>=0 && abs(sum(r.occ)-4)<2e-12 for r in rows) && covariance_error<2e-12
    println(io,"passed=",passed)
    println(io,"validated_meshes=",sort(unique(r.L for r in rows)))
    latest=last(filter(r -> r.U==.7,rows))
    println(io,"occupation_output_minus_reported_input_L",latest.L,"=",latest.occ-DENSITY)
    println(io,"magnetization_output_minus_reported_input_L",latest.L,"=",latest.mag-MOMENT)
    println(io,"source_fields_held_fixed=true; auxiliary_temperature_held_fixed=true")
    println(io,"recomputed_meshes=",MESHES)
    println(io,"prior_rows_loaded=",!isempty(EXISTING))
    if !isempty(EXISTING);println(io,"prior_csv_sha256=",bytes2hex(sha256(read(EXISTING))));end
    for U in (0.,.7)
        set=filter(r -> r.U==U,rows); finest=last(set)
        if U==0.
            symmetry_error=maximum(maximum(abs.([r.occ[1]-r.occ[2],r.fs[1]-r.fs[2],r.deeper[1]-r.deeper[2]])) for r in set)
            println(io,"U0_xz_yz_max_occupation_or_spectral_difference=",symmetry_error)
            @assert symmetry_error<2e-12
        end
        println(io,"U=",U,"; finest_L=",finest.L,"; n=",finest.occ,"; A0=",finest.fs,"; Aminus005=",finest.deeper)
        if length(set)>1
            previous=set[end-1]
            println(io,"U=",U,"; refinement=",previous.L,"->",finest.L,"; relative_change_A0=",(finest.fs.-previous.fs)./finest.fs)
            println(io,"U=",U,"; refinement=",previous.L,"->",finest.L,"; occupation_change=",finest.occ.-previous.occ)
            println(io,"U=",U,"; refinement=",previous.L,"->",finest.L,"; relative_change_Aminus005=",(finest.deeper.-previous.deeper)./finest.deeper)
        end
    end
    println(io,"Warning: finite-temperature regularization and finite momentum mesh can alter occupation outputs; reported rounded mean fields are not self-consistently solved here.")
    @assert passed
end
open(joinpath(OUT,"reconstruction_report.md"),"w") do io
    r=last(filter(r -> r.U==.7,rows)); b=last(filter(r -> r.U==0.,rows))
    println(io,"# M07 fixed-field source reconstruction\n")
    println(io,"The largest completed mesh is ",r.L,"×",r.L,". This reconstructs the qualitative source spectral contrast from fixed published mean fields; it does not solve self-consistency or select a ground state.\n")
    println(io,"Source kinetic: PRB 81, 014511 (2010), Eqs. (5)–(10) and Table I. Inputs from PRB 81, 180514(R), Fig. 1: n=(1.590,1.586,0.824), m=(0.040,0.150,0.014), U=0.7 eV, J=U/4, U′=U−2J, Q=(π,0). Auxiliary T=0.0005 eV and source Gaussian σ=0.005 eV remain fixed across meshes. The xy occupation is inferred from total n=4.\n")
    println(io,"At L=",r.L,": n=",r.occ,"; A(μ)=",r.fs," eV⁻¹; A(μ−0.05 eV)=",r.deeper," eV⁻¹.\n")
    println(io,"A_xz(μ)/A_yz(μ)=",r.fs[1]/r.fs[2],"; n_xz−n_yz=",r.occ[1]-r.occ[2],". Source occupation residual=",r.occ-DENSITY,". This persistent mismatch prevents a claim of reproducing the source’s numerical occupations.\n")
    println(io,"All stored rows pass normalization 2 per orbital, nonnegative spectral weights, sampled eigensolver residual, total n=4, and the zero-field xz/yz equality checks at 2e−12. Independent rotated-Q/orbital matrix covariance also passes. The tolerance bounds floating-point algebra; it does not certify mesh convergence or physical accuracy.\n")
    set=filter(r -> r.U==.7,rows)
    if length(set)>1
        p=set[end-1]
        println(io,"For ",p.L,"→",r.L,", relative A(μ) changes (using the final value as denominator) are ",100 .* abs.((r.fs.-p.fs)./r.fs)," percent for xz,yz,xy. Occupation changes are ",r.occ.-p.occ,".\n")
    end
    println(io,"The CSV retains all completed meshes. validation.txt reports the actual refinements and input provenance. Near-μ orbital contrast and integrated orbital occupation are different observables; a successful contrast reconstruction is not a many-body phase reproduction.\n")
    println(io,"Normal execution computes meshes 64,128,256,512. MOREO_M07_SOURCE_OUT changes the destination; MOREO_M07_SOURCE_MESHES selects a comma-separated subset. MOREO_M07_SOURCE_EXISTING optionally supplies an earlier matching CSV whose rows are retained without recomputation.\n")
end
