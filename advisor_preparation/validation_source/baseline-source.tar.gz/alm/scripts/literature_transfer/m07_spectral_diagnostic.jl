#!/usr/bin/env julia
# M07: one-body spectra of a saved uniform HF field, not a new HF/QMC solve.
using LinearAlgebra, Printf, Test, SHA, TOML
const REPO=get(ENV,"MOREO_REPO",normpath(joinpath(@__DIR__,"../..")))
const OUT=get(ENV,"MOREO_M07_OUT",joinpath(REPO,"results/literature_transfer/m07_20260922"))
module Kinetic
include(joinpath(get(ENV,"MOREO_REPO",normpath(joinpath(@__DIR__,"../.."))),"src/noninteracting.jl"))
end
const DENSITY=1.46021875
const TEMP=.05
const U=12.0
const INPUT=joinpath(REPO,"results/literature_transfer/hf_competition/control_U12.0_n1.46021875_T0.05/AM_density.csv")
fermi(x)=x>=0 ? exp(-x)/(1+exp(-x)) : 1/(1+exp(x))
gauss(x,eta)=exp(-.5*(x/eta)^2)/(sqrt(2pi)*eta)

function saved_density()
    r=zeros(2,2);counts=zeros(Int,2);spread=0.
    rows=[split(line,',') for line in readlines(INPUT)[2:end]]
    for f in rows
        a=parse(Int,f[3]);counts[a]+=1
        r[a,1]+=parse(Float64,f[4]);r[a,2]+=parse(Float64,f[5])
    end
    r ./= counts
    for f in rows, s in 1:2
        a=parse(Int,f[3]);spread=max(spread,abs(parse(Float64,f[3+s])-r[a,s]))
    end
    r,spread
end

function onebody(kx,ky,V,s)
    h=Kinetic.bloch_hamiltonian(kx,ky)
    h[1,1]+=V[1,s];h[2,2]+=V[2,s]
    c=(h[1,1]+h[2,2])/2;z=(h[1,1]-h[2,2])/2;r=hypot(z,h[1,2])
    # At degeneracy the two equal-energy projectors are summed; this gauge
    # distributes their total orbital weight equally between the two labels.
    q=r>1e-13 ? z/r : 0.
    (e=(c-r,c+r),wx=((1-q)/2,(1+q)/2),matrix=h)
end

function samples(nk,V)
    energies=zeros(2,nk*nk,2);weights=similar(energies);sector=zeros(nk*nk)
    j=0
    for ix in 0:nk-1,iy in 0:nk-1
        j+=1;kx=-pi+2pi*(ix+.5)/nk;ky=-pi+2pi*(iy+.5)/nk
        # Equal angular halves of BZ; diagonal boundary split evenly.
        dx=abs(2ix+1-nk);dy=abs(2iy+1-nk)
        sector[j]=dx>dy ? 1. : (dx<dy ? 0. : .5)
        for s in 1:2
            v=onebody(kx,ky,V,s)
            energies[:,j,s].=v.e;weights[:,j,s].=v.wx
        end
    end
    energies,weights,sector
end

function analyze(nk,V,label)
    e,wx,sector=samples(nk,V);N=nk^2
    lo=minimum(e)-40TEMP;hi=maximum(e)+40TEMP
    for _ in 1:65
        mid=(hi+lo)/2
        if sum(fermi((x-mid)/TEMP) for x in e)/N<DENSITY;lo=mid;else;hi=mid;end
    end
    mu=(hi+lo)/2;rho=zeros(2,2);norm=zeros(2,2)
    for s in 1:2,j in 1:N,b in 1:2
        v=[wx[b,j,s],1-wx[b,j,s]]
        rho[:,s].+=v*fermi((e[b,j,s]-mu)/TEMP)/N
        norm[:,s].+=v/N
    end
    @test abs(sum(rho)-DENSITY)<3e-11
    @test maximum(abs,norm.-1)<3e-11
    spectral=NamedTuple[]
    for eta in (.10,.05),omega in (-.2,0.,.2)
        a=zeros(2,2);x=zeros(2,2);y=zeros(2,2)
        for s in 1:2,j in 1:N,b in 1:2
            v=[wx[b,j,s],1-wx[b,j,s]]*gauss(omega-(e[b,j,s]-mu),eta)/N
            a[:,s].+=v;x[:,s].+=v*sector[j];y[:,s].+=v*(1-sector[j])
        end
        @test maximum(abs,a-x-y)<3e-11
        for region in ("all","Xsector","Ysector")
            m=region=="all" ? a : region=="Xsector" ? x : y
            ax=sum(m[1,:]);ay=sum(m[2,:])
            push!(spectral,(label=label,nk=nk,eta=eta,omega=omega,region=region,
                A_xz_up=m[1,1],A_xz_down=m[1,2],A_yz_up=m[2,1],A_yz_down=m[2,2],
                A_xz=ax,A_yz=ay,contrast=(ax-ay)/(ax+ay)))
        end
        if label!="charge_control"
            @test abs(sum(a[1,:])-sum(a[2,:]))<3e-11
            @test abs(a[1,1]-a[2,2])<3e-11
            @test abs(sum(x[1,:])-sum(y[2,:]))<3e-11
        end
    end
    total=(label=label,nk=nk,mu=mu,n_xz=sum(rho[1,:]),n_yz=sum(rho[2,:]),
        M=sum(rho[:,1]-rho[:,2])/2,Delta=((rho[1,1]-rho[1,2])-(rho[2,1]-rho[2,2]))/2,
        normalization_error=maximum(abs,norm.-1))
    total,spectral
end

function csvwrite(path,rows)
    open(path,"w") do io
        println(io,join(string.(keys(first(rows))),","))
        for row in rows
            println(io,join([v isa AbstractFloat ? @sprintf("%.16g",v) : string(v) for v in values(row)],","))
        end
    end
end

mkpath(OUT)
rho,spread=saved_density();V=U*(rho[:,[2,1]].-.5)
cases=[("saved_AM",V),("reversed_AM",V[:,[2,1]]),("unpolarized",zeros(2,2)),
       ("charge_control",[-.35 -.35;.35 .35])]
totals=NamedTuple[];spec=NamedTuple[];independent_errors=Float64[]
ts=@testset "M07 orbital-projected spectra" begin
    @test spread<2e-12
    for (_,v) in cases,(kx,ky) in ((.37,1.12),(-1.43,.59),(2.11,-.77),(0.,0.)),s in 1:2
        d=onebody(kx,ky,v,s);sol=eigen(Symmetric(d.matrix))
        @test maximum(abs,collect(d.e)-sol.values)<3e-12
        if abs(sol.values[2]-sol.values[1])>1e-12
            err=maximum(abs,collect(d.wx)-abs2.(sol.vectors[1,:]));push!(independent_errors,err)
            @test err<3e-12
        end
        # Matrix Gaussian spectral function at one energy: complete degenerate
        # projector avoids attributing meaning to arbitrary individual vectors.
        explicit=sol.vectors*Diagonal(gauss.(sol.values.-.3,.15))*sol.vectors'
        analytic=sum(d.wx[b]*gauss(d.e[b]-.3,.15) for b in 1:2)
        @test abs(explicit[1,1]-analytic)<3e-11
    end
    meshes=isempty(ARGS) ? (96,192,384,768) : Tuple(parse.(Int,split(ARGS[1],',')))
    for nk in meshes,(label,v) in cases
        elapsed=@elapsed begin
            total,s=analyze(nk,v,label);push!(totals,total);append!(spec,s)
        end
        @printf("%s Nk=%d %.3fs n_xz=%.10f n_yz=%.10f\n",label,nk,elapsed,total.n_xz,total.n_yz)
        flush(stdout)
    end
    for nk in meshes
        a=filter(r->r.nk==nk && r.label=="saved_AM",spec)
        b=filter(r->r.nk==nk && r.label=="reversed_AM",spec)
        @test length(a)==length(b)
        @test maximum(abs(a[i].A_xz_up-b[i].A_xz_down) for i in eachindex(a))<3e-11
        c=only(filter(r->r.nk==nk && r.label=="charge_control",totals))
        @test abs(c.n_xz-c.n_yz)>.01
    end
end
csvwrite(joinpath(OUT,"target_occupations.csv"),totals)
csvwrite(joinpath(OUT,"target_spectral_weights.csv"),spec)
open(joinpath(OUT,"target_validation.toml"),"w") do io
    TOML.print(io,Dict("passed"=>ts.n_passed,"failed"=>ts.anynonpass,"max_eigenvector_weight_error"=>maximum(independent_errors),
        "source_input_sha256"=>bytes2hex(sha256(read(INPUT))),"saved_spatial_spread"=>spread,
        "input_rho_xz_up"=>rho[1,1],"input_rho_xz_down"=>rho[1,2],"U"=>U,"T"=>TEMP,"n"=>DENSITY,
        "exchange_energy"=>U*(rho[1,1]-rho[1,2])/2,"saved_field_only_no_new_self_consistency"=>true,
        "tolerance"=>3e-11,"tolerance_reason"=>"Float64 accumulation over up to O(10^6) positive spectral terms; eigensolver controls 3e-12."))
end
