#!/usr/bin/env julia
using LinearAlgebra, Test, Printf, SHA, TOML
BLAS.set_num_threads(1)
const OUT = length(ARGS)>0 ? abspath(ARGS[1]) : @__DIR__
mkpath(OUT)
const PDF = "/home/yiqiwan/code/AltermagnetDQMCTrial/results/literature_transfer/sources/10.1103_PhysRevB.79.104510.pdf"
const PARAMS = (t1=.5,t2=.15,t3=-.175,t4=-.2,t5=.8,t6=-.45,t7=.46,t8=.005,t9=-.8,t10=-.4,t17=.9,dxy=-.6,dx2y2=-2.)
function h4(kx,ky)
 p=PARAMS; cx=cos(kx);cy=cos(ky);sx=sin(kx);sy=sin(ky)
 h=zeros(ComplexF64,4,4)
 h[1,1]=-2p.t2*cx-2p.t1*cy-4p.t3*cx*cy
 h[2,2]=-2p.t1*cx-2p.t2*cy-4p.t3*cx*cy
 h[1,2]=-4p.t4*sx*sy
 # cos(k+π)=-cos(k); below are exactly the published shifted diagonals.
 h[3,3]=2p.t5*(cx+cy)-4p.t6*cx*cy+p.dxy
 h[1,3]=-4im*p.t7*sx+8im*p.t8*sx*cy
 h[2,3]=-4im*p.t7*sy+8im*p.t8*sy*cx
 h[4,4]=2p.t17*(cx+cy)-4p.t9*cx*cy+p.dx2y2
 h[1,4]=-4im*p.t10*sy; h[2,4]=4im*p.t10*sx
 for i=1:4,j=i+1:4 h[j,i]=conj(h[i,j]) end
 return h
end
fermi(x)= x>40 ? exp(-x) : x< -40 ? 1.0 : 1/(1+exp(x))
function getmu(L,T)
 e=Matrix{Float64}(undef,4,L*L); index=0
 for ix=0:L-1,iy=0:L-1
  index+=1; e[:,index]=eigvals(Hermitian(h4(-pi+2pi*ix/L,-pi+2pi*iy/L)))
 end
 density(mu)=2sum(x->fermi((x-mu)/T),e)/(L*L)
 lo=minimum(e)-1;hi=maximum(e)+1
 for _=1:70
  mid=(lo+hi)/2
  if density(mid)>4 hi=mid else lo=mid end
 end
 mu=(lo+hi)/2
 return mu,density(mu)
end
function crossing(theta,band,mu)
 f(r)=eigvals(Hermitian(h4(r*cos(theta),r*sin(theta))))[band]-mu
 lo=0.;hi=1.5
 @assert f(lo)>0 && f(hi)<0
 for _=1:70
  mid=(lo+hi)/2
  if f(mid)>0 lo=mid else hi=mid end
 end
 r=(lo+hi)/2; kx=r*cos(theta);ky=r*sin(theta)
 E=eigen(Hermitian(h4(kx,ky)));v=E.vectors[:,band]
 return (r=r,kx=kx,ky=ky,energy=E.values[band],traceweight=sum(abs2,v),coherentweight=abs2(sum(v)),xz=abs2(v[1]),yz=abs2(v[2]),xy=abs2(v[3]),x2y2=abs2(v[4]))
end
function csv(path,rows)
 open(path,"w") do io
  names=keys(first(rows));println(io,join(string.(names),","))
  for row in rows println(io,join((getproperty(row,n) for n in names),",")) end
 end
end
function main()
 chemical=NamedTuple[];weights=NamedTuple[]
 for L in (128,256,512)
  elapsed=@elapsed begin
   mu,n=getmu(L,.002)
   push!(chemical,(L=L,T=.002,mu=mu,density=n))
   for theta in range(-pi,pi;length=65)[1:64],band=1:2
    c=crossing(theta,band,mu)
    push!(weights,merge((L=L,theta=theta,band=band),c))
   end
  end
  println("L=$L elapsed=$(elapsed) mu=$(last(chemical).mu)")
 end
 csv(joinpath(OUT,"source_chemical_potential.csv"),chemical)
 csv(joinpath(OUT,"source_hole_pocket_weights.csv"),weights)
 finalweights=filter(x->x.L==512,weights)
 checkpoint=NamedTuple[];err=Dict{String,Float64}()
 maxerr(k,x)=(err[k]=max(get(err,k,0.),x))
 m=ones(ComplexF64,4)
 # Arbitrary orbital rephasing: d'=D*d, H'=D*H*D†, probe m'=D*m.
 D=Diagonal(exp.(im.*[.17,.8,-1.3,2.2]))
 tests=@testset "M08 published free source coherent spectral audit" begin
  @test norm(h4(0,0)-Diagonal([-.6,-.6,4.4,4.8])) < 2e-14
  for row in chemical @test isapprox(row.density,4.;atol=2e-12,rtol=0) end
  for row in weights
   @test abs(row.energy-chemical[findfirst(x->x.L==row.L,chemical)].mu)<2e-12
   @test abs(row.traceweight-1)<2e-12
   @test row.coherentweight>=0 && row.coherentweight<=4+2e-12
  end
  for (kx,ky) in ((.3,.7),(.4,.4),(.4,-.4),(pi/2,pi/2),(0.,0.))
   H=h4(kx,ky);F=eigen(Hermitian(H));V=F.vectors;E=F.values
   @test norm(H-H') <2e-12
   maxerr("eigen_residual",norm(H*V-V*Diagonal(E)))
   @test norm(H*V-V*Diagonal(E)) < 2e-12
   w=[abs2(dot(m,V[:,j])) for j=1:4]
   @test abs(sum(w)-4)<2e-12
   maxerr("weight_sum_residual",abs(sum(w)-4))
   for j=1:4 push!(checkpoint,(kx=kx,ky=ky,band=j,E=E[j],traceweight=1.,coherentweight=w[j])) end
   Hnew=D*H*D';mnew=D*m
   for omega in (-1.,0.,1.),eta in (.05,.02)
    G=inv((omega+im*eta)*I-H)
    # Hermitian spectral matrix, not entrywise imaginary part (offdiagonal entries are complex).
    A=-(G-G')/(2im*pi)
    Aeig=V*Diagonal(eta ./ (pi.*((omega.-E).^2 .+eta^2)))*V'
    maxerr("spectral_matrix_resolvent_error",norm(A-Aeig))
    @test norm(A-Aeig)<2e-10
    @test minimum(eigvals(Hermitian(A)))>=-2e-12
    traceweight=real(tr(A));coherent=real(dot(m,A*m))
    @test coherent>=-2e-12
    Gnew=inv((omega+im*eta)*I-Hnew)
    Anew=-(Gnew-Gnew')/(2im*pi)
    @test abs(real(tr(Anew))-traceweight)<2e-10
    gauge=real(dot(mnew,Anew*mnew))
    maxerr("gauge_probe_covariance_error",abs(gauge-coherent))
    @test abs(gauge-coherent)<2e-10
   end
   # Exact Lorentzian integrated spectral sum rule over all frequencies: sum projectors=I.
   @test norm(V*V'-I)<2e-12
  end
 end
 csv(joinpath(OUT,"source_checkpoints.csv"),checkpoint)
 # Angular weights under the same per-spin normalization as one spin eigenstate in Eq21.
 extrema=NamedTuple[]
 for band=1:2
  rows=filter(x->x.band==band,finalweights)
  ws=getproperty.(rows,:coherentweight)
  push!(extrema,(band=band,weight_min=minimum(ws),weight_max=maximum(ws),theta_min=rows[argmin(ws)].theta,theta_max=rows[argmax(ws)].theta))
 end
 csv(joinpath(OUT,"source_weight_extrema.csv"),extrema)
 function refinement(a,b)
  ra=filter(x->x.L==a,weights);rb=filter(x->x.L==b,weights)
  return maximum(abs.(getproperty.(ra,:coherentweight).-getproperty.(rb,:coherentweight)))
 end
 report=Dict("doi"=>"10.1103/PhysRevB.79.104510","source_version"=>"published journal PDF on official UTK group website","source_pdf_sha256"=>bytes2hex(sha256(read(PDF))),"source_equations"=>"Eqs. (3)-(12), Table I, Eqs. (20)-(21); Sec II C5 and Fig8 mechanism","calculation"=>"U=0 source four-orbital orbital interference audit, not interacting phase reproduction","orbital_order"=>["xz","yz","xy","x2-y2"],"parameters_eV"=>Dict(string(k)=>v for (k,v) in pairs(PARAMS)),"interaction"=>"U=Uprime=J=0","momentum_basis"=>"published effective four-orbital mixed momentum block: xz,yz at kprime and xy,x2-y2 at kprime+(pi,pi)","geometry"=>"square-lattice periodic Bloch momentum mesh, lattice spacing1, radians","density"=>4.,"density_normalization"=>"2/L^2 sum over 4 orbital bands and L^2 k points; factor2 spin","temperature_eV"=>.002,"temperature_note"=>"auxiliary numerical Fermi smoothing for chemical potential; source discusses ground state, this is an explicitly controlled approximation","occupation"=>"Fermi-Dirac, chemical potential bisected to n4 at each mesh","spectral_eta_eV"=>[.05,.02],"spectral_energy_reference"=>"absolute Eq3-12 one-particle energy, without chemical-potential subtraction in selected resolvent checks; Fermi contours use E=mu","normalization"=>"per spin. Trace per nondegenerate eigenstate is1. Coherent m=ones(4) weight is |sum v|^2; full-frequency sum4. Spin sum doubles both.","probe_note"=>"coherent equal-amplitude orbital probe in printed basis, not universal experimental ARPES matrix element and not orbital DOS","errors"=>err,"mesh_mu_change_256_512_eV"=>abs(chemical[3].mu-chemical[2].mu),"mesh_max_weight_change_256_512"=>refinement(256,512),"mesh_max_weight_change_128_256"=>refinement(128,256),"tests_passed"=>true,"tests_count"=>tests.n_passed,"float_control"=>"Float64; eigen/projector and roots tolerances2e-12; resolvent2e-10 permits eta amplification","limitations"=>["No interaction, self-consistent magnetism, ED, VCA or target-model calculation here.","Fig8 qualitative angular anisotropy reproduced, plotted points not digitized; no claim of numerical curve replication.","Finite mesh and auxiliary finite-temperature chemical potential; contours approximate zero-temperature source filling.","No actual dipole/photoelectron final-state matrix elements; equal-phase orbital probe specified explicitly."])
 open(joinpath(OUT,"source_summary.toml"),"w") do io TOML.print(io,report;sorted=true) end
 println(report["errors"])
 println("weight changes: ",report["mesh_max_weight_change_128_256"]," -> ",report["mesh_max_weight_change_256_512"])
 println(extrema)
end
main()
