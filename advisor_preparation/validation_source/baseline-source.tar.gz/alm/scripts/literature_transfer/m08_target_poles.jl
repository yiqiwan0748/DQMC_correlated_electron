#!/usr/bin/env julia
# Isolated M08 diagnostic: unbroadened poles of a SAVED fixed HF field.
using LinearAlgebra, Printf, Test, TOML, SHA
const REPO=get(ENV,"MOREO_REPO","/home/yiqiwan/code/AltermagnetDQMCTrial")
const OUT=get(ENV,"MOREO_M08_OUT",joinpath(REPO,"results/literature_transfer/m08_20260924/target"))
module Kinetic
include(joinpath(get(ENV,"MOREO_REPO","/home/yiqiwan/code/AltermagnetDQMCTrial"),"src/noninteracting.jl"))
end
const INPUT=joinpath(REPO,"results/literature_transfer/hf_competition/control_U12.0_n1.46021875_T0.05/AM_density.csv")
const DENSITY=1.46021875
const TEMP=.05
const HUBBARD=12.
fermi(x)=x>=0 ? exp(-x)/(1+exp(-x)) : 1/(1+exp(x))
function saved()
    rows=[split(x,',') for x in readlines(INPUT)[2:end]]
    rho=zeros(2,2);counts=zeros(Int,2)
    for f in rows
        a=parse(Int,f[3]);counts[a]+=1
        rho[a,1]+=parse(Float64,f[4]);rho[a,2]+=parse(Float64,f[5])
    end
    rho./=counts
    spread=maximum(abs(parse(Float64,f[3+s])-rho[parse(Int,f[3]),s]) for f in rows,s in 1:2)
    rho,spread
end
function matrix(kx,ky,V,s)
    h=Kinetic.bloch_hamiltonian(kx,ky)
    h[1,1]+=V[1,s];h[2,2]+=V[2,s]
    h
end
function poles(kx,ky,V,s)
    h=matrix(kx,ky,V,s);c=(h[1,1]+h[2,2])/2
    r=hypot((h[1,1]-h[2,2])/2,h[1,2])
    (c-r,c+r)
end
function writecsv(path,rows)
    open(path,"w") do io
        println(io,join(keys(first(rows)),","))
        for r in rows
            println(io,join([v isa AbstractFloat ? @sprintf("%.16g",v) : string(v) for v in values(r)],","))
        end
    end
end
function mesh(nk,V,label)
    es=Array{Float64}(undef,2,nk*nk,2);j=0
    direct=Inf;central=Inf
    for ix in 0:nk-1,iy in 0:nk-1
        j+=1;x=-pi+2pi*(ix+.5)/nk;y=-pi+2pi*(iy+.5)/nk
        e1=poles(x,y,V,1);e2=poles(x,y,V,2)
        es[:,j,1].=e1;es[:,j,2].=e2
        direct=min(direct,e1[2]-e1[1],e2[2]-e2[1])
        both=sort([e1...,e2...]);central=min(central,both[3]-both[2])
    end
    lo=minimum(es)-40TEMP;hi=maximum(es)+40TEMP
    for _ in 1:64
        mu=(hi+lo)/2;n=sum(fermi((e-mu)/TEMP) for e in es)/nk^2
        if n<DENSITY;lo=mu;else;hi=mu;end
    end
    mu=(hi+lo)/2
    nlow=sum(fermi((es[1,j,s]-mu)/TEMP) for j in 1:nk^2,s in 1:2)/nk^2
    nhigh=sum(fermi((es[2,j,s]-mu)/TEMP) for j in 1:nk^2,s in 1:2)/nk^2
    @test abs(nlow+nhigh-DENSITY)<3e-11
    lmin=minimum(es[1,:,:]);lmax=maximum(es[1,:,:]);umin=minimum(es[2,:,:]);umax=maximum(es[2,:,:])
    (case=label,nk=nk,mu=mu,n_lower=nlow,n_upper=nhigh,
        direct_same_spin_min=direct,direct_middle_sorted_min=central,
        lower_min=lmin,lower_max=lmax,upper_min=umin,upper_max=umax,
        indirect_upper_minus_lower=umin-lmax,min_sampled_abs_E_minus_mu=minimum(abs.(es.-mu)))
end
function crossings(V,mu,label)
    vertices=[(0.,0.),(pi,0.),(pi,pi),(0.,0.)];rows=NamedTuple[]
    for segment in 1:3,s in 1:2,b in 1:2
        a=vertices[segment];z=vertices[segment+1]
        k(t)=(a[1]+t*(z[1]-a[1]),a[2]+t*(z[2]-a[2]))
        f(t)=poles(k(t)...,V,s)[b]-mu
        for j in 0:255
            l=j/256;r=(j+1)/256;fl=f(l);fr=f(r)
            if fl*fr<0
                for _ in 1:55
                    m=(l+r)/2
                    if fl*f(m)<=0;r=m;else;l=m;fl=f(l);end
                end
                t=(l+r)/2;kx,ky=k(t);res=f(t)
                dt=1e-6;velocity=(f(t+dt)-f(t-dt))/(2dt)/hypot(z[1]-a[1],z[2]-a[2])
                @test abs(res)<3e-12
                push!(rows,(case=label,segment=segment,spin=s,band=b,kx=kx,ky=ky,
                    E_minus_mu=res,path_group_velocity=velocity))
            end
        end
    end
    @test !isempty(rows)
    rows
end
mkpath(OUT);rho,spread=saved();V=HUBBARD*(rho[:,[2,1]].-.5)
rows=NamedTuple[];roots=NamedTuple[];probe=NamedTuple[];maxres=0.;maxgauge=0.;maxeig=0.
testresult=@testset "M08 unbroadened target poles and probe covariance" begin
    @test spread<2e-12
    @test abs(sum(rho)-DENSITY)<3e-11
    meshes=isempty(ARGS) ? (96,192,384,768) : Tuple(parse.(Int,split(ARGS[1],',')))
    for nk in meshes
        tm=@elapsed r=mesh(nk,V,"saved_AM")
        push!(rows,r);@printf("Nk=%d %.3fs mu=%.12f direct=%.10f indirect=%.10f\n",nk,tm,r.mu,r.direct_same_spin_min,r.indirect_upper_minus_lower);flush(stdout)
    end
    r=last(rows);append!(roots,crossings(V,r.mu,"saved_AM"))
    # Zero-field control at modest grid; no nonlinear HF solve.
    p=mesh(192,zeros(2,2),"zero_field");push!(rows,p)
    append!(roots,crossings(zeros(2,2),p.mu,"zero_field"))
    # Check symmetry-point values separately from midpoint grids. A separate
    # analytic bound establishes the minimum direct separation at X/Y; this
    # loop does not prove the individual bands' global extrema.
    for (x,y) in ((0.,0.),(pi,0.),(0.,pi),(pi,pi),(.37,1.12)),s in 1:2
        h=matrix(x,y,V,s);eig=eigen(Symmetric(h));e=poles(x,y,V,s)
        global maxeig=max(maxeig,maximum(abs.(collect(e)-eig.values)))
        @test maximum(abs.(collect(e)-eig.values))<3e-12
        @test maximum(abs.(collect(e)-collect(poles(x,y,V[:,[2,1]],3-s))))<3e-12
        @test maximum(abs.(collect(e)-collect(poles(-y,x,V,3-s))))<3e-12
    end
    # Source Eq20-like probe (1,1) is a coherent channel, not the orbital trace.
    # Use spectral MATRIX -Im G/pi with retarded Lorentzian eta, not M07 Gaussian.
    # Values are diagnostics, not an ARPES matrix-element prediction.
    for (label,v,mu) in (("saved_AM",V,r.mu),("zero_field",zeros(2,2),p.mu)),
        (kx,ky) in ((pi/2,pi/2),(.37,1.12)),s in 1:2,eta in (.1,.05)
        h=matrix(kx,ky,v,s);e=eigen(Symmetric(h));omega=0.;z=complex(mu+omega,eta)
        A=e.vectors*Diagonal((eta/pi)./((mu.+omega.-e.values).^2 .+eta^2))*e.vectors'
        Ares=-imag.(inv(z*I-h))/pi
        global maxres=max(maxres,maximum(abs.(A-Ares)))
        @test maximum(abs.(A-Ares))<3e-11
        m=ones(2);D=Diagonal([1.,-1.]);Ag=D*A*D;mg=D*m
        trA=tr(A);coh=dot(m,A*m);cov=dot(mg,Ag*mg);wrong=dot(m,Ag*m)
        global maxgauge=max(maxgauge,abs(cov-coh))
        @test abs(cov-coh)<3e-12
        @test abs(trA-tr(Ag))<3e-12
        @test coh>=-3e-12
        weights=abs2.(e.vectors'*m)
        @test abs(sum(weights)-2)<3e-12
        push!(probe,(case=label,kx=kx,ky=ky,spin=s,omega=omega,eta=eta,
            orbital_trace=trA,coherent_probe=coh,transformed_probe=cov,
            untransformed_probe_after_basis_change=wrong,pole_weight_lower=weights[1],pole_weight_upper=weights[2]))
    end
end
writecsv(joinpath(OUT,"band_gap_mesh.csv"),rows)
writecsv(joinpath(OUT,"fermi_crossings.csv"),roots)
writecsv(joinpath(OUT,"spectral_probe_checks.csv"),probe)
special=NamedTuple[]
for (name,x,y) in (("Gamma",0.,0.),("X",pi,0.),("Y",0.,pi),("M",pi,pi)),s in 1:2
    e=poles(x,y,V,s);push!(special,(point=name,spin=s,lower=e[1],upper=e[2],gap=e[2]-e[1]))
end
writecsv(joinpath(OUT,"symmetry_point_poles.csv"),special)
open(joinpath(OUT,"validation.toml"),"w") do io
    TOML.print(io,Dict("passed"=>testresult.n_passed,"failed"=>testresult.anynonpass,
        "source_input_sha256"=>bytes2hex(sha256(read(INPUT))),"U"=>HUBBARD,"n"=>DENSITY,"T"=>TEMP,
        "saved_spatial_spread"=>spread,"max_eigenvalue_error"=>maxeig,"max_resolvent_error"=>maxres,
        "max_probe_covariance_error"=>maxgauge,"fixed_field_no_new_self_consistency"=>true,
        "energy_reference"=>"shifted Hubbard U(n_up-1/2)(n_down-1/2); raw band energy; spectral omega measured from fitted mu",
        "algebra_tolerance"=>3e-12,"accumulation_tolerance"=>3e-11,
        "tolerance_reason"=>"Float64 small-matrix eigensolver/resolvent and accumulated Fermi occupations; mesh errors reported separately"))
end
