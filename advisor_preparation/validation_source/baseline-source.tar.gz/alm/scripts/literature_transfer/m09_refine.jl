using LinearAlgebra, Test, TOML
const ROOT="/home/yiqiwan/code/AltermagnetDQMCTrial"
include(joinpath(ROOT,"scripts/literature_transfer/target_response_check.jl"))
const R=LiteratureTargetResponse
const OUT=isempty(ARGS) ? joinpath(ROOT,"results/literature_transfer/m09_20260925") : ARGS[1]
mkpath(OUT)
elapsed=@elapsed @testset "M09 refined local momentum patch" begin
    open(joinpath(OUT,"target_fine_patch.csv"),"w") do io
        println(io,"nk,mu,qx_over_pi,qy_over_pi,chi_xx,chi_yy,chi_xy,lambda_max,chi_odd")
        saved=Dict{Tuple{Int,Int},Float64}()
        for nk in (384,768)
            tm=@elapsed begin
                g=R.make_grid(nk);mu=R.chemical_potential(g,1.46021875,20.)
                @test abs(R.density(g,mu,20.)-1.46021875)<2e-12
                for a in -2:2,b in 0:16
                    sx=nk÷2+a*(nk÷192);sy=b*(nk÷384)
                    c=R.response(g,sx,sy,mu,20.); l=c.chi_largest_orbital_eigenvalue
                    @test l+2e-12>=c.chi_odd/2
                    if nk==384
                        saved[(a,b)]=l
                    else
                        # Fixed-T quadrature acceptance, not a q-continuum bound.
                        @test abs(l-saved[(a,b)])<2e-5
                    end
                    println(io,join((nk,mu,2sx/nk,2sy/nk,c.chi_xx,c.chi_yy,c.chi_xy,l,c.chi_odd),','))
                end
                for (sx,sy) in ((0,0),(nk÷2,nk÷48))
                    c=R.response(g,sx,sy,mu,20.);d=R.response(g,sy,sx,mu,20.)
                    @test abs(c.chi_xx-d.chi_yy)<2e-11
                    @test abs(c.chi_xy-d.chi_xy)<2e-11
                end
            end
            println("fine patch nk=",nk," seconds=",tm);flush(stdout)
        end
    end
end
open(joinpath(OUT,"fine_validation.toml"),"w") do io
    TOML.print(io,Dict("passed"=>true,"elapsed_seconds"=>elapsed,"momentum_scope"=>"local 5x17 patch only; no global or continuous-q maximum established"))
end
