using LinearAlgebra, Test, Printf, TOML
const ROOT = "/home/yiqiwan/code/AltermagnetDQMCTrial"
include(joinpath(ROOT,"scripts/literature_transfer/target_response_check.jl"))
const R = LiteratureTargetResponse
const OUT = isempty(ARGS) ? joinpath(ROOT,"results/literature_transfer/m09_20260925") : ARGS[1]
mkpath(OUT)

# Published M09 Eqs. (2)-(7), Table I; energies exclude chemical potential.
function source_h(kx,ky)
    t1,t2,t3,t4,t5,t6,t7,t8,d = .02,.06,.03,-.01,.2,.3,-.2,.1,.4
    a=2t2*cos(kx)+2t1*cos(ky)+4t3*cos(kx)*cos(ky)
    b=2t1*cos(kx)+2t2*cos(ky)+4t3*cos(kx)*cos(ky)
    c=2t5*(cos(kx)+cos(ky))+4t6*cos(kx)*cos(ky)+d
    z=4t4*sin(kx)*sin(ky)
    x=2im*t7*sin(kx)+4im*t8*sin(kx)*cos(ky)
    y=2im*t7*sin(ky)+4im*t8*sin(ky)*cos(kx)
    return ComplexF64[a z x;z b y;conj(x) conj(y) c]
end
function source_grid(nk)
    energies=zeros(3,nk^2); vectors=zeros(ComplexF64,3,3,nk^2)
    for iy in 0:nk-1, ix in 0:nk-1
        i=ix+nk*iy+1
        f=eigen(Hermitian(source_h(2pi*ix/nk,2pi*iy/nk)))
        energies[:,i]=f.values; vectors[:,:,i]=f.vectors
    end
    (;nk,energies,vectors)
end
# Static physical Sz response restricted to diagonal orbital densities.
# This is the diagonal-density block, NOT the full 9x9 RPA tensor.
function source_chi(g,sx,sy,mu,beta)
    C=zeros(3,3); nk=g.nk
    for iy in 0:nk-1, ix in 0:nk-1
        i=ix+nk*iy+1; j=mod(ix+sx,nk)+nk*mod(iy+sy,nk)+1
        for n in 1:3,m in 1:3
            w=R.divided_fermi(g.energies[n,i],g.energies[m,j],mu,beta)
            for a in 1:3,b in 1:3
                va=conj(g.vectors[a,m,j])*g.vectors[a,n,i]
                vb=conj(g.vectors[b,m,j])*g.vectors[b,n,i]
                C[a,b]+=w*real(va*conj(vb))
            end
        end
    end
    C/(2nk^2)
end
function field_moment(nk,mu,beta,h,v)
    moment=0.0
    for iy in 0:nk-1,ix in 0:nk-1,s in (-1,1)
        f=eigen(Hermitian(source_h(2pi*ix/nk,2pi*iy/nk)-s*h/2*Diagonal(v)))
        for n in 1:3
            moment+=s/2*R.fermi(f.values[n],mu,beta)*sum(v.*abs2.(f.vectors[:,n]))
        end
    end
    moment/nk^2
end
elapsed=@elapsed @testset "M09 bounded response audit" begin
    @test source_h(.3,.7) ≈ source_h(.3,.7)' atol=1e-14 rtol=0
    g=source_grid(12); mu=R.chemical_potential(g,4.,50.); C=source_chi(g,0,0,mu,50.)
    v=[1.,-1.,0.]; exact=dot(v,C*v)
    errors=Float64[]
    open(joinpath(OUT,"source_field_check.csv"),"w") do io
        println(io,"h,bubble,field_derivative,absolute_error")
        for h in (1e-3,5e-4,2.5e-4)
            fd=(field_moment(12,mu,50.,h,v)-field_moment(12,mu,50.,-h,v))/(2h)
            push!(errors,abs(fd-exact));println(io,join((h,exact,fd,errors[end]),','))
        end
    end
    @test errors[end]<2e-5
    @test errors[end]<errors[1]/10
    conserved=sum(e->50*R.fermi(e,mu,50.)*(1-R.fermi(e,mu,50.)),g.energies)/(2g.nk^2)
    @test isapprox(sum(C),conserved;atol=2e-12,rtol=0)
    V=copy(g.vectors)
    for i in axes(V,3),n in 1:3
        V[:,n,i].*=cis(.37i+.19n)
    end
    Cq=source_chi(g,3,0,mu,50.)
    @test isapprox(Cq,source_chi((;nk=12,energies=g.energies,vectors=V),3,0,mu,50.);atol=2e-12,rtol=0)
    open(joinpath(OUT,"source_bare_response.csv"),"w") do io
        println(io,"nk,beta,density,mu,qx_over_pi,qy_over_pi,total_spin_chi,lambda_max,chi_xx,chi_yy,chi_zz,chi_xy,chi_xz,chi_yz")
        for nk in (48,96,192)
            tm=@elapsed begin
                gs=source_grid(nk); mus=R.chemical_potential(gs,4.,50.)
                @test abs(R.density(gs,mus,50.)-4)<2e-12
                for (sx,sy) in ((0,0),(nk÷4,0),(nk÷2,0),(nk÷2,nk÷2))
                    cs=source_chi(gs,sx,sy,mus,50.)
                    @test minimum(eigvals(Symmetric(cs))) > -2e-12
                    println(io,join((nk,50.,4.,mus,2sx/nk,2sy/nk,sum(cs),eigmax(Symmetric(cs)),cs[1,1],cs[2,2],cs[3,3],cs[1,2],cs[1,3],cs[2,3]),','))
                end
            end
            println("source nk=",nk," seconds=",tm);flush(stdout)
        end
    end
    open(joinpath(OUT,"target_stripe_patch.csv"),"w") do io
        println(io,"nk,beta,density,mu,qx_over_pi,qy_over_pi,chi_xx,chi_yy,chi_xy,lambda_max,chi_odd")
        for nk in (192,384)
            tm=@elapsed begin
                gt=R.make_grid(nk); mut=R.chemical_potential(gt,1.46021875,20.)
                @test abs(R.density(gt,mut,20.)-1.46021875)<2e-12
                qs=[(nk÷2+a*nk÷48,b*nk÷48) for a in -2:2 for b in -2:2]
                push!(qs,(0,0))
                for (sx,sy) in qs
                    c=R.response(gt,sx,sy,mut,20.)
                    @test c.chi_largest_orbital_eigenvalue+2e-12 >= c.chi_odd/2
                    println(io,join((nk,20.,1.46021875,mut,2sx/nk,2sy/nk,c.chi_xx,c.chi_yy,c.chi_xy,c.chi_largest_orbital_eigenvalue,c.chi_odd),','))
                end
                c0=R.response(gt,0,0,mut,20.)
                @test abs(c0.chi_even-20c0.equal_time_even)<2e-11
                cx=R.response(gt,nk÷2,0,mut,20.);cy=R.response(gt,0,nk÷2,mut,20.)
                @test abs(cx.chi_xx-cy.chi_yy)<2e-11
                @test abs(cx.chi_xy-cy.chi_xy)<2e-11
            end
            println("target nk=",nk," seconds=",tm);flush(stdout)
        end
    end
end
open(joinpath(OUT,"validation.toml"),"w") do io
    TOML.print(io,Dict("passed"=>true,"elapsed_seconds"=>elapsed,"scope"=>"source U0 bare diagonal-spin response and target U0 local stripe-momentum refinement; no interacting RPA or phase reproduction"))
end
