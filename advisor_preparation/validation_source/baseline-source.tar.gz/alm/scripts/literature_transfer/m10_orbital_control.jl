using LinearAlgebra, Test, TOML
const ROOT="/home/yiqiwan/code/AltermagnetDQMCTrial"
include(joinpath(ROOT,"scripts/literature_transfer/target_response_check.jl"))
const R=LiteratureTargetResponse
const OUT=isempty(ARGS) ? joinpath(ROOT,"results/literature_transfer/m10_20260926") : ARGS[1]
mkpath(OUT)
const OPS=([1. 0;0 1.],[1. 0;0 -1.],[1. 1;1 1.])
const LABELS=("total_spin","orbital_odd","all_orbital_entries")
function no_mixing(g)
    V=zeros(2,2,g.nk^2)
    V[1,1,:].=1;V[2,2,:].=1
    (;nk=g.nk,energies=copy(g.energies),vectors=V)
end
function s_grid(nk)
    E=zeros(2,nk^2)
    for iy in 0:nk-1,ix in 0:nk-1
        x,y=2pi*ix/nk,2pi*iy/nk;i=ix+nk*iy+1
        E[1,i]=-.1*(cos(x)+cos(y))+2.8*cos(x)*cos(y)
        E[2,i]=-.2*(cos(x)+cos(y))+1.2*cos(x)*cos(y)+2.8
    end
    no_mixing((;nk,energies=E))
end
# Fixed Hermitian orbital probe Gamma. Physical spin factors give 1/(2N).
function measures(g,sx,sy,mu,beta,G)
    S=0.;chi=0.;nk=g.nk
    for iy in 0:nk-1,ix in 0:nk-1
        i=ix+nk*iy+1;j=mod(ix+sx,nk)+nk*mod(iy+sy,nk)+1
        for n in 1:2,m in 1:2
            x1,x2=g.vectors[1,n,i],g.vectors[2,n,i]
            y1,y2=g.vectors[1,m,j],g.vectors[2,m,j]
            w=abs2(conj(y1)*(G[1,1]*x1+G[1,2]*x2)+conj(y2)*(G[2,1]*x1+G[2,2]*x2))
            f=R.fermi(g.energies[n,i],mu,beta);fp=R.fermi(g.energies[m,j],mu,beta)
            S+=w*f*(1-fp)
            chi+=w*R.divided_fermi(g.energies[n,i],g.energies[m,j],mu,beta)
        end
    end
    (;S=S/(2nk^2),chi=chi/(2nk^2))
end
# Independent finite real-space Wick trace, retaining contact and cross terms.
function wick(g,sx,sy,mu,beta,G)
    nk=g.nk;N=nk^2;P=zeros(ComplexF64,2N,2N);A=zeros(ComplexF64,2N,2N)
    for ry in 0:nk-1,rx in 0:nk-1,syi in 0:nk-1,sxi in 0:nk-1
        r=rx+nk*ry;s=sxi+nk*syi
        for ky in 0:nk-1,kx in 0:nk-1,n in 1:2,a in 1:2,b in 1:2
            i=kx+nk*ky+1
            P[2r+a,2s+b]+=cis(2pi*(kx*(rx-sxi)+ky*(ry-syi))/nk)*g.vectors[a,n,i]*conj(g.vectors[b,n,i])*R.fermi(g.energies[n,i],mu,beta)/N
        end
    end
    for ry in 0:nk-1,rx in 0:nk-1,a in 1:2,b in 1:2
        r=rx+nk*ry;A[2r+a,2r+b]=cis(2pi*(sx*rx+sy*ry)/nk)*G[a,b]
    end
    real(tr(P*A*(I-P)*A'))/(2N)
end
elapsed=@elapsed @testset "M10 source and isospectral target control" begin
    dpar=R.ModelParameters(-1.,1.3,-.85,-.85)
    # Source's nonhybridized s model: orbital and band contractions coincide.
    open(joinpath(OUT,"source_equal_time.csv"),"w") do io
        println(io,"model,nk,beta,mu,measured_density,qx_over_pi,qy_over_pi,probe,S_orbital,S_band,chi_orbital")
        for nk in (16,32,64),model in ("d","s")
            g=model=="d" ? R.make_grid(nk,dpar) : s_grid(nk)
            mu=model=="d" ? 1.54 : 1.95;gb=no_mixing(g)
            for (sx,sy) in ((0,0),(nk÷2,0),(nk÷2,nk÷2),(nk÷4,nk÷4)),j in (1,3)
                a=measures(g,sx,sy,mu,20.,OPS[j]);b=measures(gb,sx,sy,mu,20.,OPS[j])
                if model=="s"
                    @test abs(a.S-b.S)<2e-13
                    @test abs(a.chi-b.chi)<2e-13
                end
                println(io,join((model,nk,20.,mu,R.density(g,mu,20.),2sx/nk,2sy/nk,LABELS[j],a.S,b.S,a.chi),','))
            end
        end
    end
    # Independent Wick evaluation, two source models and the target.
    errors=Float64[]
    for (name,g,mu) in (("source_d",R.make_grid(4,dpar),1.54),("source_s",s_grid(4),1.95),("target",R.make_grid(4),-1.9))
        for (sx,sy) in ((0,0),(2,0),(1,1)),G in OPS
            a=measures(g,sx,sy,mu,20.,G).S;b=wick(g,sx,sy,mu,20.,G)
            push!(errors,abs(a-b));@test isapprox(a,b;atol=2e-12,rtol=0)
        end
    end
    open(joinpath(OUT,"target_isospectral.csv"),"w") do io
        println(io,"nk,beta,density,mu,qx_over_pi,qy_over_pi,model,probe,equal_time_S,static_chi,beta_S")
        for nk in (96,192,384)
            tm=@elapsed begin
                g=R.make_grid(nk);mu=R.chemical_potential(g,1.46021875,20.);gb=no_mixing(g)
                @test abs(R.density(g,mu,20.)-1.46021875)<2e-12
                @test R.density(g,mu,20.)==R.density(gb,mu,20.)
                for (sx,sy) in ((0,0),(nk÷2,0),(nk÷2,nk÷2)),j in 1:3
                    a=measures(g,sx,sy,mu,20.,OPS[j]);b=measures(gb,sx,sy,mu,20.,OPS[j])
                    for (model,c) in (("target",a),("isospectral_control",b))
                        println(io,join((nk,20.,1.46021875,mu,2sx/nk,2sy/nk,model,LABELS[j],c.S,c.chi,20c.S),','))
                    end
                    if j in (1,2)
                        old=R.response(g,sx,sy,mu,20.)
                        @test abs(a.S-(j==1 ? old.equal_time_even : old.equal_time_odd))<2e-11
                        @test abs(a.chi-(j==1 ? old.chi_even : old.chi_odd))<2e-11
                    end
                    if sx==sy==0
                        if j==1
                            @test abs(a.chi-b.chi)<2e-11
                            @test abs(a.chi-20a.S)<2e-11
                        end
                        if j in (1,2)
                            @test abs(b.chi-20b.S)<2e-11
                        end
                    end
                end
            end
            println("target nk=",nk," seconds=",tm);flush(stdout)
        end
    end
    # A basis transformation, unlike the artificial comparison model, must keep
    # the observable transformed. Check with an independent constant rotation.
    g=R.make_grid(8);V=copy(g.vectors);Q=[cos(.37) -sin(.37);sin(.37) cos(.37)]
    for i in axes(V,3);V[:,:,i]=Q'*V[:,:,i];end
    gr=(;nk=8,energies=g.energies,vectors=V)
    for G in OPS
        a=measures(g,4,0,-1.9,20.,G);b=measures(gr,4,0,-1.9,20.,Q'*G*Q)
        @test abs(a.S-b.S)<2e-12
        @test abs(a.chi-b.chi)<2e-12
    end
    open(joinpath(OUT,"independent_checks.toml"),"w") do io
        TOML.print(io,Dict("max_realspace_wick_error"=>maximum(errors),"wick_checks"=>length(errors),"passed"=>true))
    end
end
open(joinpath(OUT,"validation.toml"),"w") do io
    TOML.print(io,Dict("elapsed_seconds"=>elapsed,"passed"=>true,"scope"=>"source Eq24 selected noninteracting contractions and artificial equal-spectrum target comparison; no interacting phase reproduction"))
end
