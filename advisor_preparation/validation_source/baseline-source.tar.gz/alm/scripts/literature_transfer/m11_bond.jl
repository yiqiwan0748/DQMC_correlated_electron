using LinearAlgebra, Test, TOML
BLAS.set_num_threads(1)
const OUT=isempty(ARGS) ? "/home/yiqiwan/code/AltermagnetDQMCTrial/results/literature_transfer/m11_20260927" : ARGS[1]
mkpath(OUT)
function annihilator(m)
    C=zeros(256,256)
    for b in 0:255
        if (b>>m)&1==1
            s=isodd(count_ones(b&((1<<m)-1))) ? -1. : 1.
            C[(b ⊻ (1<<m))+1,b+1]=s
        end
    end
    C
end
const C=[annihilator(m) for m in 0:7]
const n=[x'*x for x in C]
const number=sum(n)
const sz=[(n[2a-1]-n[2a])/2 for a in 1:4]
const sp=[C[2a-1]'*C[2a] for a in 1:4]
dotspin(a,b)=sz[a]*sz[b]+(sp[a]*sp[b]'+sp[a]'*sp[b])/2
const exchange=sum(dotspin(a,b) for a in 1:2,b in 3:4)
const totalsp=sum(sp)
const doub=sum(n[2a-1]*n[2a] for a in 1:4)
function kinetic(t1,t2)
    H=zeros(256,256)
    for a in 0:1,s in 0:1
        m=2a+s+1;j=m+4;t=a==0 ? -t1 : -t2
        H+=t*(C[m]'*C[j]+C[j]'*C[m])
    end
    H
end
function localinteraction(U,J,Up)
    H=U*doub
    for a in (1,3)
        b=a+1
        H+=(Up-J/2)*(n[2a-1]+n[2a])*(n[2b-1]+n[2b])-2J*dotspin(a,b)
        P=C[2a-1]'*C[2a]'*C[2b]*C[2b-1]
        H+=J*(P+P')
    end
    H
end
sector(N)=[b+1 for b in 0:255 if count_ones(b)==N]
function ground(H,N)
    ix=sector(N);A=H[ix,ix];f=eigen(Symmetric(A));e=f.values[1];v=f.vectors[:,1]
    (;E=e,residual=norm(A*v-e*v),dim=length(ix))
end
elapsed=@elapsed @testset "M11 exact bond controls" begin
    for a in 1:8,b in 1:8
        @test norm(C[a]*C[b]'+C[b]'*C[a]-(a==b ? I : zeros(256,256)))<1e-13
    end
    # Independent isolated one-site Kanamori N=2 multiplet oracle.
    A=localinteraction(3.,.6,1.8);ix=[b+1 for b in 0:15 if count_ones(b)==2]
    @test isapprox(eigvals(Symmetric(A[ix,ix])),[1.2,1.2,1.2,2.4,2.4,3.6];atol=1e-12,rtol=0)
    # Noninteracting full-spin sector minima must equal filled one-particle levels.
    K=kinetic(-1.,-1.75);levels=sort([-1.75,-1.,1.,1.75,-1.75,-1.,1.,1.75])
    for N in 0:8
        @test abs(ground(K,N).E-sum(levels[1:N]))<1e-11
    end
    maxres=0.
    open(joinpath(OUT,"binding.csv"),"w") do io
        println(io,"model,U,JH,Uprime,extra_J,N0,E_N,E_Np1,E_Np2,mu1,mu2,EB,max_residual,shifted_EB")
        for (model,U,J,Up,t1,t2,N0) in (("source_terms_bond",3.,.6,1.8,-1.,1.3,4),("target_terms_bond",12.,0.,0.,-1.,-1.75,2))
            Hbase=kinetic(t1,t2)+localinteraction(U,J,Up)
            for lambda in (0.,.285,.6,1.2,2.,4.)
                H=Hbase+lambda*exchange
                @test norm(H-H')<1e-12
                @test norm(H*number-number*H)<1e-11
                @test norm(H*totalsp-totalsp*H)<1e-10
                gs=[ground(H,N0+j) for j in 0:2];E=[x.E for x in gs]
                res=maximum(x.residual for x in gs);maxres=max(maxres,res)
                @test res<1e-10
                eb=E[3]+E[1]-2E[2]
                shifted=H-U/2*number+U*I # four orbitals, U/4 constant each
                Es=[ground(shifted,N0+j).E for j in 0:2];ebs=Es[3]+Es[1]-2Es[2]
                @test abs(eb-ebs)<2e-10
                @test abs(eb-((E[3]-E[2])-(E[2]-E[1])))<1e-12
                println(io,join((model,U,J,Up,lambda,N0,E[1],E[2],E[3],E[2]-E[1],E[3]-E[2],eb,res,ebs),','))
            end
        end
    end
    open(joinpath(OUT,"controls.toml"),"w") do io
        TOML.print(io,Dict("max_eigenpair_residual"=>maxres,"source_exchange_ratio"=>(1+1.3^2)/(2*(.85^2+.85^2)),"source_ratio_scope"=>"main-text hopping ratio only, not an added NNN bond or a target-derived coupling","passed"=>true))
    end
end
open(joinpath(OUT,"validation.toml"),"w") do io
    TOML.print(io,Dict("passed"=>true,"elapsed_seconds"=>elapsed,"scope"=>"two-site controlled comparison only; all spin sectors retained; no eight-site source replication or target-lattice phase claim"))
end
