using LinearAlgebra,Test,TOML
BLAS.set_num_threads(1)
const R="/home/yiqiwan/code/AltermagnetDQMCTrial"
include(joinpath(R,"src/noninteracting.jl"))
const out=isempty(ARGS) ? joinpath(R,"results/literature_transfer/m12_20260928") : ARGS[1]
mkpath(out)
function realspace(L,p)
 H=zeros(2L^2,2L^2)
 ix(x,y,a)=2*(mod(x,L)+L*mod(y,L))+a
 for x in 0:L-1,y in 0:L-1
  for (dx,dy,T) in ((1,0,[-p.t1 0.;0. -p.t2]),(0,1,[-p.t2 0.;0. -p.t1]),(1,1,[-p.t3 p.t4;p.t4 -p.t3]),(1,-1,[-p.t3 -p.t4;-p.t4 -p.t3]))
   for a in 1:2,b in 1:2
    i=ix(x,y,a);j=ix(x+dx,y+dy,b);H[i,j]+=T[a,b];H[j,i]+=T[a,b]
   end
  end
 end
 H
end
elapsed=@elapsed @testset "M12 spectral asymmetry" begin
 open(joinpath(out,"moments.csv"),"w") do io
  println(io,"model,L,mean,m3_bloch,m3_realspace,max_spectrum_error,pairing_residual")
  for (name,p) in (("source",ModelParameters(-1.,1.3,-.85,-.85)),("target",DEFAULT_PARAMETERS),("target_NN_control",ModelParameters(-1.,-1.75,0.,0.)))
   ms=Float64[]
   for L in (6,8,12)
    es=sort(vcat([band_energies(2pi*x/L,2pi*y/L,p) for x in 0:L-1 for y in 0:L-1]...))
    H=realspace(L,p);er=eigvals(Symmetric(H));m1=sum(es)/length(es);m3=sum(es.^3)/length(es);mr=tr(H*H*H)/size(H,1)
    err=maximum(abs.(es-er));pair=maximum(abs.(es+reverse(es)))
    @test err<1e-11
    @test abs(m1)<1e-12
    @test abs(m3-mr)<1e-10
    if name=="target_NN_control"
     @test abs(m3)<1e-10
     @test pair<1e-11
    else
     @test abs(m3)>1
     @test pair>1
    end
    push!(ms,m3);println(io,join((name,L,m1,m3,mr,err,pair),','))
   end
   @test maximum(ms)-minimum(ms)<1e-10
  end
 end
end
open(joinpath(out,"validation.toml"),"w") do io
 TOML.print(io,Dict("passed"=>true,"elapsed_seconds"=>elapsed,"scope"=>"U=0 single-particle odd spectral moments; no interacting phase or source-figure replication"))
end
