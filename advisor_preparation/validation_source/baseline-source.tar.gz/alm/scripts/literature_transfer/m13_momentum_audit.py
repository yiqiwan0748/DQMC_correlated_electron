from pathlib import Path
from fractions import Fraction as F
import csv,json,math,time,hashlib
start=time.perf_counter();R=Path('/home/yiqiwan/code/AltermagnetDQMCTrial');O=Path('/tmp/m13_20260929');O.mkdir(exist_ok=True)
p=R/'results/literature_transfer/m09_20260925/target_fine_patch.csv';rows=list(csv.DictReader(p.open()));rows=[r for r in rows if int(r['nk'])==768]
assert len(rows)==85
for r in rows:
 r['qx']=F(r['qx_over_pi']).limit_denominator(384)/2;r['qy']=F(r['qy_over_pi']).limit_denominator(384)/2;r['lam']=float(r['lambda_max'])
peak=max(rows,key=lambda r:r['lam']);assert peak['qx']==F(1,2) and peak['qy']==F(11,384)
assert abs(peak['lam']-.1867940505815708)<1e-14
output=[];checks=2
for L in [4,6,8,12,16,24,32,48,64,96,192,384]:
 allowed=[r for r in rows if (r['qx']*L).denominator==1 and (r['qy']*L).denominator==1]
 best=max(allowed,key=lambda r:r['lam']);q=peak['qy'];dist=[abs(F(j,L)-q) for j in range(L)];dm=min(dist);nearest=[F(j,L) for j,x in enumerate(dist) if x==dm]
 # Independent complex phase test of the exact rational compatibility test.
 for r in rows:
  rat=(r['qx']*L).denominator==1 and (r['qy']*L).denominator==1
  phase=abs(complex(math.cos(2*math.pi*float(r['qx'])*L),math.sin(2*math.pi*float(r['qx'])*L))-1)<1e-10 and abs(complex(math.cos(2*math.pi*float(r['qy'])*L),math.sin(2*math.pi*float(r['qy'])*L))-1)<1e-10
  assert rat==phase;checks+=1
 assert best['lam']<=peak['lam']+1e-14;checks+=1
 output.append({'L':L,'allowed_patch_points':len(allowed),'peak_representable':L%384==0,'nearest_qy_over_pi':';'.join(str(2*x) for x in nearest),'nearest_error_over_pi':str(2*dm),'best_allowed_qx_over_pi':str(2*best['qx']),'best_allowed_qy_over_pi':str(2*best['qy']),'imported_lambda_best_allowed':best['lam'],'relative_loss_in_patch':1-best['lam']/peak['lam']})
with (O/'momentum_compatibility.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=output[0].keys());w.writeheader();w.writerows(output)
source=[('Fig1a','2.42','2.27'),('Fig2a','2.48','2.41'),('Fig2b','1.84','1.81'),('Fig3a','2.365','2.361'),('Fig3c','2.141','2.139')]
with (O/'source_caption_amplitudes.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['source_panel','nmax_printed','nmin_printed','delta_n_exact_decimal'])
 from decimal import Decimal as D
 for panel,a,b in source:w.writerow([panel,a,b,str(D(a)-D(b))])
summary={'passed':True,'checks':checks,'elapsed_seconds':time.perf_counter()-start,'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'best_sampled_q_over_pi':['1','11/192'],'best_lambda_reused':peak['lam'],'source_scope':'Arithmetic audit of printed extrema only; no HF reproduction or curve digitization','target_scope':'Allowed-wavevector audit of archived Nk768 local patch, not susceptibilities recomputed on each finite L','phase_check_tolerance':1e-10}
(O/'validation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));print((O/'momentum_compatibility.csv').read_text())
