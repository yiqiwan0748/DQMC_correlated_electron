"""Isolated real multi-Slater constrained-path solver for the M≤8, Nσ≤3 audit.

This module does not extend or modify the production single-Slater API.
"""
module MultiSlaterCP
using LinearAlgebra, Random, Serialization
import AltermagnetDQMCTrial as CP
include(joinpath(@__DIR__, "multislater_cp_kernels.jl"))
const KERNEL=MultiSlaterCPKernels
const Term=NamedTuple{(:coefficient,:up,:down),Tuple{Float64,Matrix{Float64},Matrix{Float64}}}
const CANCELLATION_TOL=1e-10
const RELATIVE_OVERLAP_TOL=1e-12
function compensated_sum(xs)
    s=c=0.0
    for x in xs;s,c=KERNEL.accumulate(s,c,x);end
    return s+c
end

"""Q, log|det R|, sign(det R), retaining the occupied-basis gauge exactly."""
function qr_gauge(A; positive=false)
    m,n=size(A)
    n==0 && return (zeros(Float64,m,0),0.0,1.0)
    F=qr(Matrix{Float64}(A));Q=Matrix(F.Q[:,1:n]);R=Matrix(F.R)
    diagonal=diag(R)
    all(isfinite,diagonal) && all(!iszero,diagonal) || error("Rank-deficient/nonfinite Slater columns")
    magnitude=sum(log(abs(x)) for x in diagonal)
    phase=prod(sign(x) for x in diagonal)
    if positive
        for j in 1:n
            diagonal[j]<0 && (@views Q[:,j].*=-1.0)
        end
        phase=1.0
    end
    return Q,magnitude,phase
end

struct MultiSlaterTrial
    terms::Vector{Term}
    label::String
    initial_importance_weights::Vector{Float64}
    component_overlaps::Vector{Float64}
    norm_triangle_bound::Float64
end

function MultiSlaterTrial(input;label="multislater")
    isempty(input) && error("Trial needs at least one component")
    terms=Term[]
    shapeup=size(first(input).up);shapedown=size(first(input).down)
    for term in input
        size(term.up)==shapeup && size(term.down)==shapedown || error("Component shapes differ")
        all(isfinite,term.up) && all(isfinite,term.down) && isfinite(term.coefficient) || error("Nonfinite trial")
        up,lu,su=qr_gauge(term.up;positive=true)
        down,ld,sd=qr_gauge(term.down;positive=true)
        c=Float64(term.coefficient)*su*sd*exp(lu+ld)
        push!(terms,(coefficient=c,up=up,down=down))
    end
    overlaps=[KERNEL.trial_overlap(terms,t.up,t.down) for t in terms]
    norm2=compensated_sum(t.coefficient*o for (t,o) in zip(terms,overlaps))
    isfinite(norm2) && norm2>0 || error("Trial has nonpositive or unresolved norm")
    normalization=sqrt(norm2)
    terms=[(coefficient=t.coefficient/normalization,up=t.up,down=t.down) for t in terms]
    overlaps./=normalization
    weights=[t.coefficient*o for (t,o) in zip(terms,overlaps)]
    abs(sum(weights)-1)<2e-11 || error("Trial normalization failed")
    return MultiSlaterTrial(terms,String(label),weights,overlaps,sum(abs(t.coefficient) for t in terms))
end

function load_trial(path;label="singlet20")
    source=deserialize(path)
    # Recompute the full Gram normalization; source normalization is not assumed.
    return MultiSlaterTrial(source.terms;label=label)
end

mutable struct Walker
    up::Matrix{Float64}
    down::Matrix{Float64}
    log_weight::Float64
    log_overlap::Float64
    alive::Bool
    anchor_up::Matrix{Float64}
    anchor_down::Matrix{Float64}
    anchor_id::Int
    fields::Vector{Vector{Int8}}
    field_end_ids::Vector{Int}
end

mutable struct State
    problem::CP.CPAFQMCProblem{Float64}
    parameters::CP.CPAFQMCParameters{Float64}
    trial::MultiSlaterTrial
    walkers::Vector{Walker}
    kinetic_half::Matrix{Float64}
    gamma::Float64
    rng::Xoshiro
    site_order::Vector{Int}
    step::Int
    next_lineage_id::Int
    constraint_rejections::Int
    killed_walkers::Int
    population_controls::Int
    initialization::Symbol
    initial_component_counts::Vector{Int}
    minimum_overlap_cancellation_ratio::Float64
    minimum_relative_total_overlap::Float64
    maximum_backprop_log_span::Float64
    started::Float64
    propagation_seconds::Float64
    measurement_seconds::Float64
    measurement_count::Int
    minimum_distinct_ancestors::Int
end

"""Exact deterministic representation using positive importance weights.

With ni copies of Di, each copy receives Nw*wi/ni. The weighted physical
ket sum is Ts; integer allocation changes neither its coefficients nor sign.
"""
function initialization_counts(weights,N)
    all(>(0),weights) || error("Exact-weighted initialization requires strictly positive component importance weights")
    N>=length(weights) || error("Exact-weighted initialization needs at least one walker per component")
    remaining=N-length(weights)
    expected=remaining.*weights./sum(weights)
    counts=ones(Int,length(weights)).+floor.(Int,expected)
    deficit=N-sum(counts)
    order=sortperm(expected.-floor.(expected);rev=true)
    for j in 1:deficit;counts[order[j]]+=1;end
    return counts
end

function initialize(problem::CP.CPAFQMCProblem,parameters::CP.CPAFQMCParameters;
                    trial::MultiSlaterTrial,initialization=:exact_weighted)
    problem isa CP.CPAFQMCProblem{Float64} && parameters isa CP.CPAFQMCParameters{Float64} ||
        error("This bounded implementation supports Float64")
    m=size(problem.kinetic,1)
    m<=8 && problem.Nup<=3 && problem.Ndown<=3 || error("Outside the audited M≤8, Nσ≤3 scope")
    for t in trial.terms
        size(t.up)==(m,problem.Nup) && size(t.down)==(m,problem.Ndown) || error("Trial/problem shapes differ")
    end
    weights=trial.initial_importance_weights
    all(>(0),weights) || error("Initialization has nonpositive component importance; no clipping allowed")
    rng=Xoshiro(parameters.seed);N=parameters.walker_count
    indices=Int[];counts=zeros(Int,length(weights))
    if initialization==:exact_weighted
        counts=initialization_counts(weights,N)
        for i in eachindex(counts);append!(indices,fill(i,counts[i]));end
    elseif initialization==:categorical
        cumulative=cumsum(weights./sum(weights))
        for _ in 1:N
            i=length(weights)==1 ? 1 : min(searchsortedfirst(cumulative,rand(rng)),length(weights))
            push!(indices,i);counts[i]+=1
        end
    else
        error("initialization must be :exact_weighted or :categorical")
    end
    walkers=Walker[]
    for (id,i) in enumerate(indices)
        t=trial.terms[i];up=copy(t.up);down=copy(t.down)
        overlap=trial.component_overlaps[i]
        isfinite(overlap) && !iszero(overlap) || error("Unresolved initial component overlap")
        abs(overlap)/trial.norm_triangle_bound>=RELATIVE_OVERLAP_TOL || error("Initial component has unresolved norm-relative trial overlap")
        if overlap<0
            if size(up,2)>0;@views up[:,1].*=-1
            elseif size(down,2)>0;@views down[:,1].*=-1
            else;error("Cannot orient an empty determinant");end
        end
        logweight=initialization==:exact_weighted ? log(N*weights[i]/counts[i]) : 0.0
        push!(walkers,Walker(up,down,logweight,log(abs(overlap)),true,
            copy(up),copy(down),id,Vector{Vector{Int8}}(),Int[]))
    end
    kinetic,_=CP.dense_slice_propagators(problem.kinetic,parameters.dtau/2)
    gamma=CP.hubbard_stratonovich_alpha(problem.U,parameters.dtau)
    return State(problem,parameters,trial,walkers,kinetic,gamma,rng,collect(1:m),0,N+1,
        0,0,0,initialization,counts,1.0,1.0,0.0,time(),0.0,0.0,0,typemax(Int))
end

function total_overlap(terms,up,down)
    info=KERNEL.trial_overlap_diagnostics(terms,up,down)
    return (total=info.overlap,mass=info.absolute_overlap_sum,ratio=info.cancellation_ratio,
            scale=info.overlap_scale,relative=info.relative_overlap)
end

function guard_overlap!(state,total,mass,scale)
    all(isfinite,(total,mass,scale)) || error("Nonfinite total trial overlap")
    ratio=iszero(mass) ? 0.0 : abs(total)/mass
    relative=iszero(scale) ? 0.0 : abs(total)/scale
    state.minimum_overlap_cancellation_ratio=min(state.minimum_overlap_cancellation_ratio,ratio)
    state.minimum_relative_total_overlap=min(state.minimum_relative_total_overlap,relative)
    if !iszero(total)
        ratio>=CANCELLATION_TOL || error("Numerically unresolved total trial-overlap cancellation; no component discarded")
        relative>=RELATIVE_OVERLAP_TOL || error("Numerically unresolved norm-relative total trial overlap; no component discarded")
    end
end

function checked_overlap!(state,terms,up,down;require_positive=false)
    info=total_overlap(terms,up,down)
    guard_overlap!(state,info.total,info.mass,info.scale)
    require_positive && info.total<=0 && error("Expected positive total overlap")
    return info
end

function kill!(state,w)
    w.alive=false;w.log_weight=-Inf;state.killed_walkers+=1
    return false
end

function kinetic!(state,w)
    up=state.kinetic_half*w.up;down=state.kinetic_half*w.down
    overlap=checked_overlap!(state,state.trial.terms,up,down).total
    overlap>0 || return kill!(state,w)
    newlog=log(overlap)
    w.log_weight+=newlog-w.log_overlap;w.log_overlap=newlog
    w.up=up;w.down=down
    return true
end

function potential!(state,w)
    shuffle!(state.rng,state.site_order)
    fields=Vector{Int8}(undef,length(state.site_order))
    ep=exp(state.gamma);em=inv(ep)
    for i in state.site_order
        proposal=KERNEL.trial_local_hs_overlaps(state.trial.terms,w.up,w.down,i,ep,em)
        current=proposal.overlap
        all(isfinite,(current,proposal.plus,proposal.minus)) || error("Nonfinite local HS total overlap")
        current>0 && isfinite(current) || error("Nonpositive current importance overlap")
        # The Gram determinant obeys the same rank-one row-scaling polynomial,
        # with squared scale because both bra and ket are the walker itself.
        gu=KERNEL.spin_overlap_diagonal(w.up,w.up,i)
        gd=KERNEL.spin_overlap_diagonal(w.down,w.down,i)
        normscale(u,d)=state.trial.norm_triangle_bound*sqrt(max(0.0,u*d))
        guard_overlap!(state,current,proposal.absolute_overlap_sum,normscale(gu.overlap,gd.overlap))
        guard_overlap!(state,proposal.plus,proposal.plus_absolute_overlap_sum,
            normscale(gu.overlap+(ep^2-1)*gu.diagonal,gd.overlap+(em^2-1)*gd.diagonal))
        guard_overlap!(state,proposal.minus,proposal.minus_absolute_overlap_sum,
            normscale(gu.overlap+(em^2-1)*gu.diagonal,gd.overlap+(ep^2-1)*gd.diagonal))
        pplus=isfinite(proposal.plus) && proposal.plus>0 ? proposal.plus/current/2 : 0.0
        pminus=isfinite(proposal.minus) && proposal.minus>0 ? proposal.minus/current/2 : 0.0
        iszero(pplus) && (state.constraint_rejections+=1)
        iszero(pminus) && (state.constraint_rejections+=1)
        normalization=pplus+pminus
        isfinite(normalization) && normalization>0 || return nothing
        plus=rand(state.rng)<pplus/normalization
        fields[i]=plus ? Int8(1) : Int8(-1)
        w.log_weight+=log(normalization)
        @views w.up[i,:].*=plus ? ep : em
        @views w.down[i,:].*=plus ? em : ep
    end
    info=checked_overlap!(state,state.trial.terms,w.up,w.down;require_positive=true)
    w.log_overlap=log(info.total)
    return fields
end

slice(A,kinetic,gamma,fields,spin)=CP._cp_apply_slice_matrix(A,kinetic,gamma,fields,spin)

function append_history!(state,w,fields,end_id)
    history=state.parameters.back_propagation_steps
    history==0 && return
    if length(w.fields)==history
        oldest=popfirst!(w.fields)
        w.anchor_up=CP._cp_canonical_columns(slice(w.anchor_up,state.kinetic_half,state.gamma,oldest,1))
        w.anchor_down=CP._cp_canonical_columns(slice(w.anchor_down,state.kinetic_half,state.gamma,oldest,-1))
        w.anchor_id=popfirst!(w.field_end_ids)
    end
    push!(w.fields,copy(fields));push!(w.field_end_ids,end_id)
end

function stabilize!(state,w)
    w.up=CP._cp_canonical_columns(w.up);w.down=CP._cp_canonical_columns(w.down)
    info=checked_overlap!(state,state.trial.terms,w.up,w.down)
    info.total>0 || return kill!(state,w)
    w.log_overlap=log(info.total)
    return true
end

function normalize_weights!(state)
    live=[w.log_weight for w in state.walkers if w.alive]
    isempty(live) && error("All multi-Slater CP walkers died")
    largest=maximum(live)
    shift=largest+log(sum(exp(x-largest) for x in live)/length(live))
    for w in state.walkers;w.alive && (w.log_weight-=shift);end
    return length(live)
end

function copy_walker(w)
    Walker(copy(w.up),copy(w.down),0.0,w.log_overlap,true,copy(w.anchor_up),copy(w.anchor_down),
        w.anchor_id,[copy(f) for f in w.fields],copy(w.field_end_ids))
end

function population_control!(state)
    live=[w for w in state.walkers if w.alive]
    isempty(live) && error("Population control has no live walkers")
    largest=maximum(w.log_weight for w in live)
    weights=[exp(w.log_weight-largest) for w in live]
    spacing=sum(weights)/state.parameters.walker_count
    start=rand(state.rng)*spacing;source=1;cumulative=weights[1]
    next=Walker[]
    for j in 1:state.parameters.walker_count
        point=start+(j-1)*spacing
        while point>cumulative && source<length(live);source+=1;cumulative+=weights[source];end
        push!(next,copy_walker(live[source]))
    end
    state.walkers=next;state.population_controls+=1
end

function step!(state)
    start=time();oldreject=state.constraint_rejections;olddead=state.killed_walkers
    try
        for w in state.walkers
            w.alive || continue
            kinetic!(state,w) || continue
            fields=potential!(state,w)
            isnothing(fields) && (kill!(state,w);continue)
            kinetic!(state,w) || continue
            if (state.step+1)%state.parameters.orthogonalize_every==0
                stabilize!(state,w) || continue
            end
            id=state.next_lineage_id;state.next_lineage_id+=1
            append_history!(state,w,fields,id)
        end
        state.step+=1;live=normalize_weights!(state)
        if state.step%state.parameters.population_control_every==0
            population_control!(state);live=length(state.walkers)
        end
        return (;step=state.step,live_walkers=live,constraint_rejections=state.constraint_rejections-oldreject,
                 killed_walkers=state.killed_walkers-olddead)
    finally
        state.propagation_seconds+=time()-start
    end
end

"""Propagate the entire bra, retaining signed log determinant factors per term.

Only a final common coefficient scale is removed, which cancels in every ratio.
"""
function backpropagated_terms(state,w)
    terms=state.trial.terms
    up=[copy(t.up) for t in terms];down=[copy(t.down) for t in terms]
    logs=[iszero(t.coefficient) ? -Inf : log(abs(t.coefficient)) for t in terms]
    signs=[sign(t.coefficient) for t in terms]
    for (count,fields) in enumerate(Iterators.reverse(w.fields))
        for j in eachindex(terms)
            up[j]=slice(up[j],state.kinetic_half,state.gamma,fields,1)
            down[j]=slice(down[j],state.kinetic_half,state.gamma,fields,-1)
            if count%state.parameters.orthogonalize_every==0 || count==length(w.fields)
                up[j],lu,su=qr_gauge(up[j]);down[j],ld,sd=qr_gauge(down[j])
                logs[j]+=lu+ld;signs[j]*=su*sd
            end
        end
    end
    finite=[x for x in logs if isfinite(x)];largest=maximum(finite)
    state.maximum_backprop_log_span=max(state.maximum_backprop_log_span,largest-minimum(finite))
    result=Term[]
    for j in eachindex(terms)
        coefficient=signs[j]*exp(logs[j]-largest)
        !iszero(signs[j]) && iszero(coefficient) && error("Back-propagated component coefficient underflow; no terms discarded")
        push!(result,(coefficient=coefficient,up=up[j],down=down[j]))
    end
    return result
end

function estimator(state,terms,up,down)
    info=checked_overlap!(state,terms,up,down;require_positive=true)
    weights=repeat([1.0,-1.0],state.problem.cell_count)
    length(weights)==size(up,1) || error("q=0 orbital estimator requires two orbitals per cell")
    components=[KERNEL.component_numerators(state.problem,t.up,t.down,up,down,weights) for t in terms]
    keys=(:kinetic,:interaction,:double_occupancy,:O,:O2)
    values=map(keys) do key
        compensated_sum(t.coefficient*getproperty(c,key) for (t,c) in zip(terms,components))/info.total
    end
    all(isfinite,values) || error("Nonfinite multi-Slater estimator")
    return NamedTuple{keys}(Tuple(values))
end

function measure(state)
    started=time()
    try
        live=[w for w in state.walkers if w.alive]
        isempty(live) && error("No live walkers to measure")
        usebp=state.parameters.back_propagation_steps>0
        ancestors=usebp ? length(unique(w.anchor_id for w in live)) : 0
        if usebp
            all(length(w.fields)==state.parameters.back_propagation_steps for w in live) || error("Back-propagation history is not full")
            ancestors>=state.parameters.minimum_backprop_ancestors || error("Back-propagation ancestry collapsed to $ancestors")
            state.minimum_distinct_ancestors=min(state.minimum_distinct_ancestors,ancestors)
        end
        maxlog=maximum(w.log_weight for w in live)
        weights=[exp(w.log_weight-maxlog) for w in live];normalization=sum(weights)
        mixed=zeros(5);bp=zeros(5)
        for (w,weight) in zip(live,weights)
            mixed.+=weight.*collect(values(estimator(state,state.trial.terms,w.up,w.down)))
            if usebp
                terms=backpropagated_terms(state,w)
                bp.+=weight.*collect(values(estimator(state,terms,w.anchor_up,w.anchor_down)))
            end
        end
        mixed./=normalization;bp./=normalization
        cells=state.problem.cell_count
        delta=usebp ? bp[4]/cells : missing
        fm=(state.problem.Nup-state.problem.Ndown)/(2cells)
        state.measurement_count+=1
        return (step=state.step,beta=state.step*state.parameters.dtau,
            E=mixed[1]+mixed[2],mixed_K=mixed[1],mixed_V=mixed[2],mixed_D=mixed[3]/cells,
            bp_E=usebp ? bp[1]+bp[2] : missing,bp_K=usebp ? bp[1] : missing,
            bp_V=usebp ? bp[2] : missing,bp_D=usebp ? bp[3]/cells : missing,
            S_alm=usebp ? bp[5]/cells : missing,
            S_fm=usebp ? (state.problem.Nup-state.problem.Ndown)^2/(4cells) : missing,
            Delta=delta,mx=usebp ? fm+delta : missing,my=usebp ? fm-delta : missing,
            ancestors=ancestors,status="valid")
    finally
        state.measurement_seconds+=time()-started
    end
end

function diagnostics(state)
    return (step=state.step,elapsed_seconds=time()-state.started,
        propagation_seconds=state.propagation_seconds,measurement_seconds=state.measurement_seconds,
        measurement_count=state.measurement_count,live_walkers=count(w->w.alive,state.walkers),
        constraint_rejections=state.constraint_rejections,killed_walkers=state.killed_walkers,
        population_controls=state.population_controls,initialization=string(state.initialization),
        trial_components=length(state.trial.terms),initial_component_counts=state.initial_component_counts,
        minimum_overlap_cancellation_ratio=state.minimum_overlap_cancellation_ratio,
        minimum_relative_total_overlap=state.minimum_relative_total_overlap,
        maximum_backprop_log_span=state.maximum_backprop_log_span,
        minimum_distinct_ancestors=state.minimum_distinct_ancestors==typemax(Int) ? missing : state.minimum_distinct_ancestors)
end
end
