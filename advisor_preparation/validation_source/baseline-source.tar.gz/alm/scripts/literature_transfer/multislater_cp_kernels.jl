"""Small real multi-Slater kernels. No component overlap division or cutoff.
Float64, occupied column counts 0–3; intended for the bounded CP milestone.
"""
module MultiSlaterCPKernels

using LinearAlgebra: tr
export spin_overlap, component_overlap, trial_overlap, trial_overlap_diagnostics,
       spin_overlap_diagonal, spin_diagonal_numerators, trial_local_hs_overlaps,
       spin_numerators!, spin_numerators, component_numerators,
       component_energy_numerators

# Row-major padded 3×3 S=L'R. Unused occupied rows/columns are zero.
# The fixed tuple avoids a heap-allocated matrix in the propagation hot path.
@inline function overlap_entries(L::AbstractMatrix{Float64},R::AbstractMatrix{Float64})
    N=size(L,2)
    N<=3 || throw(ArgumentError("kernels support at most three occupied columns"))
    if N==3
        a=b=c=d=e=f=g=h=i=0.
        @inbounds for k in axes(L,1)
            l1=L[k,1];l2=L[k,2];l3=L[k,3];r1=R[k,1];r2=R[k,2];r3=R[k,3]
            a+=l1*r1;b+=l1*r2;c+=l1*r3;d+=l2*r1;e+=l2*r2;f+=l2*r3
            g+=l3*r1;h+=l3*r2;i+=l3*r3
        end
        return (a,b,c,d,e,f,g,h,i)
    elseif N==2
        a=b=d=e=0.
        @inbounds for k in axes(L,1)
            l1=L[k,1];l2=L[k,2];r1=R[k,1];r2=R[k,2]
            a+=l1*r1;b+=l1*r2;d+=l2*r1;e+=l2*r2
        end
        return (a,b,0.,d,e,0.,0.,0.,0.)
    elseif N==1
        a=0.
        @inbounds for k in axes(L,1);a+=L[k,1]*R[k,1];end
        return (a,0.,0.,0.,0.,0.,0.,0.,0.)
    end
    (0.,0.,0.,0.,0.,0.,0.,0.,0.)
end
@inline function determinant(S,N)
    a,b,c,d,e,f,g,h,i=S
    N==3 && return a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)
    N==2 && return a*e-b*d
    N==1 && return a
    1.
end
@inline function adjugate(S,N)
    a,b,c,d,e,f,g,h,i=S
    N==3 && return (e*i-f*h,c*h-b*i,b*f-c*e,
                    f*g-d*i,a*i-c*g,c*d-a*f,d*h-e*g,b*g-a*h,a*e-b*d)
    N==2 && return (e,-b,0.,-d,a,0.,0.,0.,0.)
    N==1 && return (1.,0.,0.,0.,0.,0.,0.,0.,0.)
    (0.,0.,0.,0.,0.,0.,0.,0.,0.)
end
@inline spin_overlap(L,R)=determinant(overlap_entries(L,R),size(L,2))
@inline component_overlap(Lu,Ld,Ru,Rd)=spin_overlap(Lu,Ru)*spin_overlap(Ld,Rd)

@inline function accumulate(s,c,x)
    t=s+x
    c+=abs(s)>=abs(x) ? (s-t)+x : (x-t)+s
    t,c
end
@inline function trial_overlap(terms,Ru,Rd)
    s=c=0.
    @inbounds for term in terms
        x=term.coefficient*component_overlap(term.up,term.down,Ru,Rd)
        s,c=accumulate(s,c,x)
    end
    s+c
end
function trial_overlap_diagnostics(terms,Ru,Rd)
    s=c=mass=norm_bound=0.
    walker_norm=sqrt(max(0.,spin_overlap(Ru,Ru)*spin_overlap(Rd,Rd)))
    @inbounds for term in terms
        x=term.coefficient*component_overlap(term.up,term.down,Ru,Rd)
        s,c=accumulate(s,c,x);mass+=abs(x)
        norm_bound+=abs(term.coefficient)*sqrt(max(0.,
            spin_overlap(term.up,term.up)*spin_overlap(term.down,term.down)))
    end
    value=s+c;scale=walker_norm*norm_bound
    (overlap=value,absolute_overlap_sum=mass,overlap_scale=scale,
     cancellation_ratio=iszero(mass) ? 0. : abs(value)/mass,
     relative_overlap=iszero(scale) ? 0. : abs(value)/scale)
end

@inline function one_entry(L,R,A,N,i,j)
    N==0 && return 0.
    @inbounds if N==3
        r1=R[i,1];r2=R[i,2];r3=R[i,3]
        return (r1*A[1]+r2*A[4]+r3*A[7])*L[j,1]+
               (r1*A[2]+r2*A[5]+r3*A[8])*L[j,2]+
               (r1*A[3]+r2*A[6]+r3*A[9])*L[j,3]
    elseif N==2
        return (R[i,1]*A[1]+R[i,2]*A[4])*L[j,1]+
               (R[i,1]*A[2]+R[i,2]*A[5])*L[j,2]
    else
        return R[i,1]*L[j,1]
    end
end
@inline function spin_overlap_diagonal(L,R,i)
    N=size(L,2);S=overlap_entries(L,R);A=adjugate(S,N)
    (overlap=determinant(S,N),diagonal=one_entry(L,R,A,N,i,i))
end
function spin_diagonal_numerators(L,R)
    N=size(L,2);S=overlap_entries(L,R);A=adjugate(S,N)
    diagonal=Vector{Float64}(undef,size(L,1))
    @inbounds for i in eachindex(diagonal);diagonal[i]=one_entry(L,R,A,N,i,i);end
    (overlap=determinant(S,N),diagonal=diagonal)
end

"""Exact rank-one-HS candidate overlaps; ep=exp(gamma), em=exp(-gamma).
No normalized component densities are formed, including at singular overlap.
"""
@inline function trial_local_hs_overlaps(terms,Ru,Rd,i,ep,em)
    s=cs=p=cp=m=cm=mass=plus_mass=minus_mass=0.
    @inbounds for term in terms
        a=spin_overlap_diagonal(term.up,Ru,i)
        b=spin_overlap_diagonal(term.down,Rd,i)
        x=term.coefficient*a.overlap*b.overlap
        xp=term.coefficient*(a.overlap+(ep-1)*a.diagonal)*(b.overlap+(em-1)*b.diagonal)
        xm=term.coefficient*(a.overlap+(em-1)*a.diagonal)*(b.overlap+(ep-1)*b.diagonal)
        s,cs=accumulate(s,cs,x);p,cp=accumulate(p,cp,xp);m,cm=accumulate(m,cm,xm)
        mass+=abs(x);plus_mass+=abs(xp);minus_mass+=abs(xm)
    end
    (overlap=s+cs,plus=p+cp,minus=m+cm,absolute_overlap_sum=mass,
     plus_absolute_overlap_sum=plus_mass,minus_absolute_overlap_sum=minus_mass)
end

@inline function pair_entry(L,R,S,N,i,j)
    @inbounds if N==3
        # Hodge-dual form of all nine second complementary minors:
        # cross(L_i,L_j)' S cross(R_i,R_j).
        l1=L[i,2]*L[j,3]-L[i,3]*L[j,2]
        l2=L[i,3]*L[j,1]-L[i,1]*L[j,3]
        l3=L[i,1]*L[j,2]-L[i,2]*L[j,1]
        r1=R[i,2]*R[j,3]-R[i,3]*R[j,2]
        r2=R[i,3]*R[j,1]-R[i,1]*R[j,3]
        r3=R[i,1]*R[j,2]-R[i,2]*R[j,1]
        return l1*(S[1]*r1+S[2]*r2+S[3]*r3)+
               l2*(S[4]*r1+S[5]*r2+S[6]*r3)+
               l3*(S[7]*r1+S[8]*r2+S[9]*r3)
    elseif N==2
        return (L[i,1]*L[j,2]-L[i,2]*L[j,1])*(R[i,1]*R[j,2]-R[i,2]*R[j,1])
    end
    0.
end
function spin_numerators!(one,pair,L,R)
    N=size(L,2);M=size(L,1);S=overlap_entries(L,R);A=adjugate(S,N)
    @inbounds for j in 1:M,i in 1:M;one[i,j]=one_entry(L,R,A,N,i,j);end
    @inbounds for i in 1:M
        pair[i,i]=one[i,i]
        for j in i+1:M;pair[i,j]=pair[j,i]=pair_entry(L,R,S,N,i,j);end
    end
    determinant(S,N)
end
function spin_numerators(L,R)
    M=size(L,1);one=Matrix{Float64}(undef,M,M);pair=similar(one)
    overlap=spin_numerators!(one,pair,L,R)
    (;overlap,one,pair)
end
function spin_onebody(L,R)
    N=size(L,2);M=size(L,1);S=overlap_entries(L,R);A=adjugate(S,N)
    one=Matrix{Float64}(undef,M,M)
    @inbounds for j in 1:M,i in 1:M;one[i,j]=one_entry(L,R,A,N,i,j);end
    (overlap=determinant(S,N),one=one)
end

function energy_parts(problem,a,b)
    du=a.overlap;dd=b.overlap;K=problem.kinetic
    kinetic=doubles=centered=0.
    @inbounds for i in axes(K,1)
        nu=a.one[i,i];nd=b.one[i,i]
        doubles+=nu*nd;centered+=(nu-du/2)*(nd-dd/2)
        for j in axes(K,2)
            kinetic+=K[i,j]*(dd*a.one[j,i]+du*b.one[j,i])
        end
    end
    interaction=problem.U*centered
    (overlap=du*dd,kinetic=kinetic,interaction=interaction,
     energy=kinetic+interaction,double_occupancy=doubles)
end
function component_energy_numerators(problem,Lu,Ld,Ru,Rd)
    energy_parts(problem,spin_onebody(Lu,Ru),spin_onebody(Ld,Rd))
end
function component_numerators(problem,Lu,Ld,Ru,Rd,w)
    a=spin_numerators(Lu,Ru);b=spin_numerators(Ld,Rd)
    parts=energy_parts(problem,a,b);du=a.overlap;dd=b.overlap;O=O2=0.
    @inbounds for i in eachindex(w)
        O+=w[i]*(dd*a.one[i,i]-du*b.one[i,i])/2
        for j in eachindex(w)
            O2+=w[i]*w[j]*(dd*a.pair[i,j]+du*b.pair[i,j]-
                a.one[i,i]*b.one[j,j]-b.one[i,i]*a.one[j,j])/4
        end
    end
    (;parts...,O,O2)
end
end
