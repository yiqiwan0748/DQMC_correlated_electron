# Isolated boundary-weight adaptation; frozen solver remains read-only.
module MultiSlaterCPMirror
using Random, SHA
include(joinpath(@__DIR__,"multislater_cp.jl"))
const B=MultiSlaterCP
const CP=B.CP
const MultiSlaterTrial=B.MultiSlaterTrial
const load_trial=B.load_trial
const CORE_SHA="c78623f8f11e633c0904ec8e6089e861b4c6c7a36e3d612efa1df8f1a6f5601e"

mutable struct MirrorState
    core::B.State
    enabled::Bool
    pre_events::Int
    post_events::Int
    cumulative_log_correction::Float64
    minimum_correction_factor::Float64
end
function Base.getproperty(s::MirrorState,name::Symbol)
    name in fieldnames(MirrorState) ? getfield(s,name) : getproperty(getfield(s,:core),name)
end
function initialize(problem,parameters;trial,initialization=:exact_weighted,enabled=true)
    bytes2hex(sha256(read(joinpath(@__DIR__,"multislater_cp.jl"))))==CORE_SHA || error("Frozen core hash changed")
    MirrorState(B.initialize(problem,parameters;trial=trial,initialization=initialization),enabled,0,0,0.,1.)
end

"""Zhang IV.A: negative lookahead only; zero overlap invokes no mirror factor."""
function mirror_log_factor(current,bad)
    isfinite(current) && current>0 && isfinite(bad) || error("Invalid mirror overlap")
    bad>=0 && return 0.0
    value=-log1p(-bad/current)
    isfinite(value) || error("Unresolved mirror correction; no clipping")
    return value
end

function record_correction!(s,w,current,bad,kind)
    bad>=0 && return
    value=mirror_log_factor(current,bad)
    w.log_weight+=value
    s.cumulative_log_correction+=value
    s.minimum_correction_factor=min(s.minimum_correction_factor,exp(value))
    if kind==:pre;s.pre_events+=1
    elseif kind==:post;s.post_events+=1
    else;error("Unknown correction kind");end
end

# Preserve both cancellation and norm-relative guards, including proposals.
function guarded_proposal(core,w,i,ep,em)
    k=B.KERNEL
    p=k.trial_local_hs_overlaps(core.trial.terms,w.up,w.down,i,ep,em)
    gu=k.spin_overlap_diagonal(w.up,w.up,i)
    gd=k.spin_overlap_diagonal(w.down,w.down,i)
    scale(u,d)=core.trial.norm_triangle_bound*sqrt(max(0.,u*d))
    B.guard_overlap!(core,p.overlap,p.absolute_overlap_sum,scale(gu.overlap,gd.overlap))
    B.guard_overlap!(core,p.plus,p.plus_absolute_overlap_sum,
        scale(gu.overlap+(ep^2-1)*gu.diagonal,gd.overlap+(em^2-1)*gd.diagonal))
    B.guard_overlap!(core,p.minus,p.minus_absolute_overlap_sum,
        scale(gu.overlap+(em^2-1)*gu.diagonal,gd.overlap+(ep^2-1)*gd.diagonal))
    p.overlap>0 || error("Nonpositive current importance overlap")
    return p
end

function potential!(s::MirrorState,w)
    s.enabled || return B.potential!(s.core,w)
    c=s.core
    shuffle!(c.rng,c.site_order)
    fields=Vector{Int8}(undef,length(c.site_order))
    ep=exp(c.gamma);em=inv(ep)
    for i in c.site_order
        p=guarded_proposal(c,w,i,ep,em)
        pplus=p.plus>0 ? p.plus/p.overlap/2 : 0.
        pminus=p.minus>0 ? p.minus/p.overlap/2 : 0.
        iszero(pplus) && (c.constraint_rejections+=1)
        iszero(pminus) && (c.constraint_rejections+=1)
        normalization=pplus+pminus
        isfinite(normalization) && normalization>0 || return nothing
        # With a surviving branch at most one alternative is negative.
        record_correction!(s,w,p.overlap,min(p.plus,p.minus),:pre)
        plus=rand(c.rng)<pplus/normalization
        fields[i]=plus ? Int8(1) : Int8(-1)
        w.log_weight+=log(normalization)
        @views w.up[i,:].*=plus ? ep : em
        @views w.down[i,:].*=plus ? em : ep
        # The second application is an overlap probe, not a second move.
        probe=guarded_proposal(c,w,i,ep,em)
        record_correction!(s,w,probe.overlap,plus ? probe.plus : probe.minus,:post)
    end
    info=B.checked_overlap!(c,c.trial.terms,w.up,w.down;require_positive=true)
    w.log_overlap=log(info.total)
    return fields
end

function step!(s::MirrorState)
    s.enabled || return B.step!(s.core)
    c=s.core;started=time();oldreject=c.constraint_rejections;olddead=c.killed_walkers
    try
        for w in c.walkers
            w.alive || continue
            B.kinetic!(c,w) || continue
            fields=potential!(s,w)
            isnothing(fields) && (B.kill!(c,w);continue)
            B.kinetic!(c,w) || continue
            if (c.step+1)%c.parameters.orthogonalize_every==0
                B.stabilize!(c,w) || continue
            end
            id=c.next_lineage_id;c.next_lineage_id+=1
            B.append_history!(c,w,fields,id)
        end
        c.step+=1;live=B.normalize_weights!(c)
        if c.step%c.parameters.population_control_every==0
            B.population_control!(c);live=length(c.walkers)
        end
        return (;step=c.step,live_walkers=live,
            constraint_rejections=c.constraint_rejections-oldreject,killed_walkers=c.killed_walkers-olddead)
    finally
        c.propagation_seconds+=time()-started
    end
end
measure(s::MirrorState)=B.measure(s.core)
function diagnostics(s::MirrorState)
    merge(B.diagnostics(s.core),(mirror_enabled=s.enabled,mirror_pre_events=s.pre_events,
        mirror_post_events=s.post_events,cumulative_mirror_log_correction=s.cumulative_log_correction,
        minimum_mirror_factor=s.minimum_correction_factor))
end
end
