#!/usr/bin/env julia
module MirrorCorrectionTests
using LinearAlgebra,Random,Test,SHA
include(joinpath(@__DIR__,"multislater_cp_mirror.jl"))
const M=MultiSlaterCPMirror
const B=M.B
const CP=M.CP
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const OUT=joinpath(ROOT,"results/literature_transfer/mirror_correction_implementation")

# Independent dense-determinant local-update replay. No optimized kernel call.
function direct_potential(s,w)
    rng=copy(s.rng);order=copy(s.site_order);shuffle!(rng,order)
    up=copy(w.up);down=copy(w.down);weight=exp(w.log_weight)
    fields=zeros(Int8,length(order));pre=post=0
    overlap(u,d)=sum(t.coefficient*det(t.up'*u)*det(t.down'*d) for t in s.trial.terms)
    function moved(u,d,i,x)
        a=copy(u);b=copy(d)
        a[i,:].*=exp(s.gamma*x);b[i,:].*=exp(-s.gamma*x)
        return a,b
    end
    for i in order
        old=overlap(up,down)
        plus=overlap(moved(up,down,i,1)...)
        minus=overlap(moved(up,down,i,-1)...)
        raw=[max(plus,0.),max(minus,0.)]./(2old)
        sum(raw)>0 || return nothing
        bad=min(plus,minus)
        if bad<0;weight*=old/(old-bad);pre+=1;end
        x=rand(rng)<raw[1]/sum(raw) ? Int8(1) : Int8(-1)
        weight*=sum(raw)
        up,down=moved(up,down,i,x);fields[i]=x
        current=overlap(up,down)
        ahead=overlap(moved(up,down,i,x)...)
        if ahead<0;weight*=current/(current-ahead);post+=1;end
    end
    return (;up,down,weight,fields,rng,pre,post)
end

function main()
    ispath(OUT) && error("Refusing to overwrite mirror tests")
    mkpath(OUT)
    suite=@testset "Mirror boundary correction deterministic checks" begin
        for old in (.01,1.,7.),bad in (-5.,-.1,0.,.1)
            @test isapprox(exp(M.mirror_log_factor(old,bad)),bad<0 ? old/(old-bad) : 1.;atol=2e-15,rtol=2e-14)
        end
        @test_throws ErrorException M.mirror_log_factor(0.,-1.)
        @test_throws ErrorException M.mirror_log_factor(1.,NaN)
        @test_throws ErrorException M.mirror_log_factor(-1.,-1.)
        trial=M.MultiSlaterTrial([(coefficient=1.,up=reshape([1.,1.],2,1),down=zeros(2,0))])
        problem=CP.CPAFQMCProblem(zeros(2,2),12.,1,0;lattice_size=1,cell_count=1)
        controls(seed)=CP.CPAFQMCParameters(dtau=.02,walker_count=2,warmup_steps=0,
            measurement_count=1,steps_between_measurements=1,back_propagation_steps=2,
            orthogonalize_every=2,population_control_every=2,minimum_backprop_ancestors=1,
            error_block_size=1,seed=seed)
        totalpre=totalpost=0
        for seed in 11:30, a in (-.4,-.8,.2)
            s=M.initialize(problem,controls(seed);trial=trial)
            w=first(s.walkers);w.up=reshape([a,1.],2,1);w.log_weight=0.
            w.log_overlap=log(B.total_overlap(s.trial.terms,w.up,w.down).total)
            expected=direct_potential(s,w)
            @test !isnothing(expected)
            fields=M.potential!(s,w)
            @test fields==expected.fields
            @test isapprox(w.up,expected.up;atol=3e-15,rtol=3e-14)
            @test isapprox(exp(w.log_weight),expected.weight;atol=3e-14,rtol=3e-13)
            @test s.pre_events==expected.pre
            @test s.post_events==expected.post
            @test rand(copy(s.rng),UInt64,8)==rand(expected.rng,UInt64,8)
            totalpre+=s.pre_events;totalpost+=s.post_events
        end
        @test totalpre>0
        @test totalpost>0
        # With mirror disabled the exact frozen algorithm and RNG are used.
        s=M.initialize(problem,controls(917);trial=trial,enabled=false)
        base=deepcopy(s.core)
        for _ in 1:6
            M.step!(s);B.step!(base)
            @test s.step==base.step
            for (a,b) in zip(s.walkers,base.walkers)
                @test a.up==b.up
                @test a.down==b.down
                @test a.log_weight==b.log_weight
                @test a.fields==b.fields
                @test a.anchor_up==b.anchor_up
            end
            @test rand(copy(s.rng),UInt64,8)==rand(copy(base.rng),UInt64,8)
        end
    end
    counts=Test.get_test_counts(suite)
    open(joinpath(OUT,"validation.txt"),"w") do io
        println(io,"status=PASS; focused deterministic tests only")
        println(io,counts)
        println(io,"No scientific mirror Monte Carlo campaign has run.")
        for f in ("multislater_cp_mirror.jl","multislater_cp_mirror_tests.jl","multislater_cp.jl")
            println(io,f," sha256=",bytes2hex(sha256(read(joinpath(@__DIR__,f)))))
        end
    end
end
end
if abspath(PROGRAM_FILE)==@__FILE__;MirrorCorrectionTests.main();end
