#!/usr/bin/env julia
"""Independent checks for new multi-Slater CP kernels and integration.
No production source edits; each mode writes a fresh, separate output path.
"""
module MultiSlaterCPOracle
using LinearAlgebra, Random, Serialization, Test, SHA, Printf
import AltermagnetDQMCTrial as CP
include(joinpath(@__DIR__,"multislater_cp_kernels.jl"))
include(joinpath(@__DIR__,"cp_multitrial_oracle.jl"))
include(joinpath(@__DIR__,"multislater_cp.jl"))
const Fast=MultiSlaterCPKernels
const Slow=CPMultitrialOracle
const Integrated=MultiSlaterCP
const ROOT=Slow.ROOT
const BASE=joinpath(ROOT,"results/literature_transfer/multislater_cp_oracle")
const ATOL=2e-11 # Small real polynomial contractions; no sampling tolerance.

function compare_spin(L,R)
    a=Fast.spin_numerators(L,R);b=Slow.spin_numerators(L,R)
    ed=abs(a.overlap-b.overlap);eg=maximum(abs,a.one-b.one);ep=maximum(abs,a.pair-b.pair)
    scale=max(1.,abs(b.overlap),maximum(abs,b.one),maximum(abs,b.pair))
    @test max(ed,eg,ep)<ATOL*scale
    @test abs(Fast.spin_overlap(L,R)-b.overlap)<ATOL*scale
    diagonal=Fast.spin_diagonal_numerators(L,R)
    @test abs(diagonal.overlap-b.overlap)<ATOL*scale
    @test maximum(abs,diagonal.diagonal-diag(b.one))<ATOL*scale
    for i in axes(L,1)
        d=Fast.spin_overlap_diagonal(L,R,i)
        @test abs(d.overlap-b.overlap)<ATOL*scale
        @test abs(d.diagonal-b.one[i,i])<ATOL*scale
    end
    (;overlap_error=ed,one_error=eg,pair_error=ep)
end

function benchmark(terms,Ru,Rd,iterations,local_hs)
    answer=0.
    if local_hs
        for j in 1:iterations
            v=Fast.trial_local_hs_overlaps(terms,Ru,Rd,mod1(j,size(Ru,1)),1.7,1/1.7)
            answer+=v.overlap+v.plus+v.minus
        end
    else
        for _ in 1:iterations;answer+=Fast.trial_overlap(terms,Ru,Rd);end
    end
    answer
end
function kernel_checks(out=joinpath(BASE,"kernel_checks"))
    ispath(out) && error("Refusing to overwrite kernel checks")
    mkpath(out);rows=NamedTuple[];rng=Xoshiro(81137)
    checks=@testset "Fast cofactor kernels versus independent minors" begin
        for N in 0:3,case in ("regular","singular","near_orthogonal","gauge")
            L=randn(rng,8,N);R=randn(rng,8,N)
            if case in ("singular","near_orthogonal") && N>0
                L=Matrix{Float64}(I,8,8)[:,1:N]
                R=copy(L);R[:,N].=0.;R[N+1,N]=1.
                case=="near_orthogonal" && (R[N,N]=1e-14)
            end
            baseline=Fast.spin_numerators(L,R)
            if case=="gauge" && N>0
                A=Matrix{Float64}(I,N,N)+.1randn(rng,N,N)
                B=Matrix{Float64}(I,N,N)+.1randn(rng,N,N);A[:,1].*=-1.
                factor=det(A)*det(B);L=L*A;R=R*B
                gauged=Fast.spin_numerators(L,R)
                @test abs(gauged.overlap-factor*baseline.overlap)<ATOL*max(1.,abs(gauged.overlap))
                @test maximum(abs,gauged.one-factor*baseline.one)<ATOL*max(1.,maximum(abs,gauged.one))
                @test maximum(abs,gauged.pair-factor*baseline.pair)<ATOL*max(1.,maximum(abs,gauged.pair))
            end
            e=compare_spin(L,R)
            push!(rows,(case=case,N=N,overlap_error=e.overlap_error,one_error=e.one_error,pair_error=e.pair_error))
        end
        # Rank-one N=3 overlap: first cofactors vanish, second minors survive.
        L=Matrix{Float64}(I,8,8)[:,1:3];R=copy(L)
        R[:,2].=0.;R[4,2]=1.;R[:,3].=0.;R[5,3]=1.
        e=compare_spin(L,R)
        push!(rows,(case="rank_one",N=3,overlap_error=e.overlap_error,one_error=e.one_error,pair_error=e.pair_error))

        export_data=deserialize(Slow.SOURCE)
        terms=[(coefficient=t.coefficient/export_data.normalization,up=t.up,down=t.down) for t in export_data.terms]
        K=Slow.B.TwoOrbitalOpenClusterED.open_cluster_kinetic_matrix(2,2)
        problem=CP.CPAFQMCProblem(K,12.,3,3;lattice_size=2,cell_count=4)
        w=repeat([1.,-1.],4)
        for h in (0.,3.,-3.)
            walker=CP.one_body_trial(problem;pattern=:altermagnetic,field_strength=h)
            diagnostics=Fast.trial_overlap_diagnostics(terms,walker.up,walker.down)
            exact=Slow.multitrial_estimator(problem,terms,walker.up,walker.down,w)
            @test abs(diagnostics.overlap-exact.total_overlap)<ATOL
            @test abs(diagnostics.overlap_scale-exact.overlap_scale)<ATOL
            for term in terms
                a=Fast.component_numerators(problem,term.up,term.down,walker.up,walker.down,w)
                b=Slow.component_numerators(problem,term.up,term.down,walker.up,walker.down,w)
                energy=Fast.component_energy_numerators(problem,term.up,term.down,walker.up,walker.down)
                for key in (:overlap,:kinetic,:interaction,:energy,:O,:O2)
                    @test abs(getproperty(a,key)-getproperty(b,key))<ATOL*max(1.,abs(getproperty(b,key)))
                end
                for key in (:overlap,:kinetic,:interaction,:energy,:double_occupancy)
                    @test abs(getproperty(energy,key)-getproperty(a,key))<ATOL*max(1.,abs(getproperty(a,key)))
                end
            end
            for i in 1:8
                ep=exp(.7);em=inv(ep)
                v=Fast.trial_local_hs_overlaps(terms,walker.up,walker.down,i,ep,em)
                @test abs(v.overlap-exact.total_overlap)<ATOL
                for (s,key) in ((1,:plus),(-1,:minus))
                    u=copy(walker.up);d=copy(walker.down);u[i,:].*=exp(.7s);d[i,:].*=exp(-.7s)
                    slow=Slow.multitrial_estimator(problem,terms,u,d,w)
                    @test abs(getproperty(v,key)-slow.total_overlap)<ATOL*max(1.,abs(slow.total_overlap))
                end
            end
        end
    end
    Slow.writecsv(joinpath(out,"spin_kernel_checks.csv"),rows)
    export_data=deserialize(Slow.SOURCE)
    terms=[(coefficient=t.coefficient/export_data.normalization,up=t.up,down=t.down) for t in export_data.terms]
    u=terms[1].up;d=terms[1].down
    timings=NamedTuple[]
    for local_hs in (false,true)
        benchmark(terms,u,d,2,local_hs)
        measured=@timed benchmark(terms,u,d,10000,local_hs)
        push!(timings,(operation=local_hs ? "20_term_HS_both_candidates" : "20_term_overlap",
            iterations=10000,seconds=measured.time,bytes=measured.bytes,
            microseconds_per_call=measured.time*1e6/10000,checksum=measured.value))
    end
    Slow.writecsv(joinpath(out,"timing.csv"),timings)
    open(joinpath(out,"validation.txt"),"w") do io
        println(io,"tests=",Test.get_test_counts(checks));println(io,"atol=",ATOL)
        for path in (@__FILE__,joinpath(@__DIR__,"multislater_cp_kernels.jl"),Slow.SOURCE)
            println(io,path," sha256=",bytes2hex(sha256(read(path))))
        end
        println(io,"Benchmark is a local microbenchmark after compilation, not an end-to-end CP runtime promise.")
    end
    println("Saved kernel checks to ",out)
end

function controls(dt,lag,cadence;walkers=20,seed=1)
    CP.CPAFQMCParameters(dtau=dt,walker_count=walkers,warmup_steps=0,
        measurement_count=1,error_block_size=1,back_propagation_steps=lag,
        minimum_backprop_ancestors=1,orthogonalize_every=cadence,
        population_control_every=9999,seed=seed)
end
function vector_terms(terms,ou,od)
    Slow.left_fock(terms,ou,od)
end
function vector_overlap(T,u,d,ou,od)
    dot(T,Slow.B.slater(u,d,ou,od))
end
function check_initial_representation(state,ou,od)
    T=vector_terms(state.trial.terms,ou,od)
    weight=[exp(w.log_weight) for w in state.walkers]
    reconstructed=zeros(length(T))
    for (v,w) in zip(weight,state.walkers)
        phi=Slow.B.slater(w.up,w.down,ou,od);overlap=dot(T,phi)
        @test overlap>0
        reconstructed.+=v/sum(weight).*phi./overlap
    end
    @test norm(reconstructed-T)<ATOL
    @test abs(norm(T)-1)<ATOL
    norm(reconstructed-T)
end

"""Use actual Xoshiro draws/order, but compute candidate probabilities and
importance accumulation from independent Fock overlaps. Replay actual kernels.
"""
function importance_replay(problem,trial;seed=817,cadence=2,steps=4,dt=.08)
    MC=Integrated;ou=Slow.B.occupations(size(problem.kinetic,1),problem.Nup)
    od=Slow.B.occupations(size(problem.kinetic,1),problem.Ndown)
    state=MC.initialize(problem,controls(dt,2,cadence;walkers=max(20,length(trial.terms)),seed);trial)
    initial_error=check_initial_representation(state,ou,od)
    T=vector_terms(trial.terms,ou,od);w=state.walkers[1]
    initial_logweight=w.log_weight;rawu=copy(w.up);rawd=copy(w.down)
    initial_overlap=vector_overlap(T,rawu,rawd,ou,od)
    probability=1.;importance=1.;max_matrix_error=0.;max_weight_error=0.
    min_candidate_ratio=Inf
    for step in 1:steps
        start=vector_overlap(T,w.up,w.down,ou,od)
        u=state.kinetic_half*w.up;d=state.kinetic_half*w.down
        after=vector_overlap(T,u,d,ou,od);@test after>0
        importance*=after/start
        @test MC.kinetic!(state,w)
        max_matrix_error=max(max_matrix_error,maximum(abs,u-w.up),maximum(abs,d-w.down))
        rng=copy(state.rng);order=copy(state.site_order);shuffle!(rng,order)
        draws=[rand(rng) for _ in order];fields=Vector{Int8}(undef,length(order))
        for (i,draw) in zip(order,draws)
            current=vector_overlap(T,u,d,ou,od)
            candidates=Float64[]
            for sign in (1,-1)
                up=copy(u);dn=copy(d);up[i,:].*=exp(sign*state.gamma);dn[i,:].*=exp(-sign*state.gamma)
                push!(candidates,vector_overlap(T,up,dn,ou,od))
            end
            min_candidate_ratio=min(min_candidate_ratio,minimum(candidates)/current)
            probabilities=max.(candidates,0.)/(2current);normalization=sum(probabilities)
            @test normalization>0
            plus=draw<probabilities[1]/normalization;choice=plus ? 1 : 2
            fields[i]=plus ? Int8(1) : Int8(-1)
            probability*=probabilities[choice]/normalization;importance*=normalization
            u[i,:].*=exp(fields[i]*state.gamma);d[i,:].*=exp(-fields[i]*state.gamma)
        end
        actual=MC.potential!(state,w)
        @test actual==fields
        @test state.site_order==order
        max_matrix_error=max(max_matrix_error,maximum(abs,u-w.up),maximum(abs,d-w.down))
        before=vector_overlap(T,u,d,ou,od)
        u=state.kinetic_half*u;d=state.kinetic_half*d
        after=vector_overlap(T,u,d,ou,od);@test after>0
        importance*=after/before
        @test MC.kinetic!(state,w)
        rawu=state.kinetic_half*Diagonal(exp.(state.gamma.*fields))*state.kinetic_half*rawu
        rawd=state.kinetic_half*Diagonal(exp.(-state.gamma.*fields))*state.kinetic_half*rawd
        if step%cadence==0;@test MC.stabilize!(state,w);end
        MC.append_history!(state,w,fields,step+100);state.step=step
        error=abs(exp(w.log_weight-initial_logweight)/importance-1)
        max_weight_error=max(max_weight_error,error);@test error<20ATOL
    end
    expected=vector_overlap(T,rawu,rawd,ou,od)/initial_overlap/2.0^(size(rawu,1)*steps)
    @test abs(probability*importance-expected)<20ATOL*max(abs(expected),1e-8)
    @test max_matrix_error<ATOL
    # The actual back-propagated term list must equal the ordered raw bra up
    # to one common positive scalar, even after repeated per-term QR.
    bp=MC.backpropagated_terms(state,w)
    rawterms=[(coefficient=t.coefficient,up=copy(t.up),down=copy(t.down)) for t in trial.terms]
    for f in reverse(w.fields)
        rawterms=[(coefficient=t.coefficient,
            up=state.kinetic_half*Diagonal(exp.(state.gamma.*f))*state.kinetic_half*t.up,
            down=state.kinetic_half*Diagonal(exp.(-state.gamma.*f))*state.kinetic_half*t.down) for t in rawterms]
    end
    rawleft=vector_terms(rawterms,ou,od);actualleft=vector_terms(bp,ou,od)
    scale=dot(actualleft,rawleft)/dot(rawleft,rawleft)
    bp_error=norm(actualleft-scale*rawleft)/norm(actualleft)
    @test scale>0 && bp_error<20ATOL
    a=Slow.multitrial_estimator(problem,bp,w.anchor_up,w.anchor_down,
        repeat([1.,-1.],problem.cell_count))
    integrated=MC.estimator(state,bp,w.anchor_up,w.anchor_down)
    @test a.status=="regular_total_overlap"
    for key in (:kinetic,:interaction,:O,:O2)
        @test abs(getproperty(integrated,key)-getproperty(a.values,key))<20ATOL*max(1.,abs(getproperty(a.values,key)))
    end
    (seed=seed,cadence=cadence,steps=steps,dtau=dt,trial_terms=length(trial.terms),
     initial_representation_error=initial_error,max_walker_matrix_error=max_matrix_error,
     max_importance_relative_error=max_weight_error,minimum_candidate_ratio=min_candidate_ratio,
     full_path_probability=probability,accumulated_importance=importance,
     exact_probability_times_weight=expected,bp_relative_fock_error=bp_error)
end

function finite_path_sum()
    MC=Integrated;K=[.13 -.8;-.8 -.21];U=4.;dt=.15;steps=4
    p=CP.CPAFQMCProblem(K,U,1,1;lattice_size=1,cell_count=1)
    trial=MC.MultiSlaterTrial([(coefficient=1.,up=reshape([.8,.6],2,1),down=reshape([.8,.6],2,1)),
        (coefficient=.35,up=reshape([.3,.95],2,1),down=reshape([.3,.95],2,1))];label="two_term_positive_toy")
    fd=Slow.B.fock_data(K,U,1,1);T=vector_terms(trial.terms,fd.ou,fd.od)
    half=exp(Symmetric(-dt*fd.kin/2));F=half*Diagonal(exp.(-dt.*fd.interaction))*half
    KH=exp(Symmetric(-dt*K/2));gamma=acosh(exp(dt*U/2))
    hs=[Int8[a,b] for a in (-1,1) for b in (-1,1)]
    Bu=[KH*Diagonal(exp.(gamma.*f))*KH for f in hs]
    Bd=[KH*Diagonal(exp.(-gamma.*f))*KH for f in hs]
    scalar=exp(-dt*U*2/4)/4
    oval=(fd.nu-fd.nd)*[1.,-1.]/2
    den=dot(T,F^steps*T)
    expected_E=dot(T,fd.H*F^steps*T)/den
    rows=NamedTuple[]
    for lag in 1:steps,cadence in (1,2,7)
        denominator=energy=bpenergy=spin=moment=0.;max_bp_error=0.
        state=MC.initialize(p,controls(dt,lag,cadence;walkers=2);trial)
        initial=[MC.copy_walker(w) for w in state.walkers]
        for termindex in eachindex(trial.terms),code in 0:4^steps-1
            indices=digits(code;base=4,pad=steps).+1
            w=MC.copy_walker(initial[termindex]);w.log_weight=0.
            ru=copy(w.up);rd=copy(w.down)
            for (step,index) in enumerate(indices)
                w.up=Bu[index]*w.up;w.down=Bd[index]*w.down
                ru=Bu[index]*ru;rd=Bd[index]*rd
                step%cadence==0 && (@test MC.stabilize!(state,w))
                MC.append_history!(state,w,hs[index],step+100)
            end
            state.walkers=[w];state.step=steps
            # All toy coefficients/overlaps are positive, so the complete signed
            # sum is also the unconstrained/no-rejection importance path sum.
            d=vector_overlap(T,ru,rd,fd.ou,fd.od);@test d>0
            pathweight=trial.terms[termindex].coefficient*scalar^steps*d
            observed=MC.measure(state)
            denominator+=pathweight;energy+=pathweight*observed.E
            bpenergy+=pathweight*observed.bp_E;spin+=pathweight*observed.S_alm
            moment+=pathweight*observed.Delta
        end
        left=F^lag*T;right=F^(steps-lag)*T
        exactBP=dot(left,fd.H*right)/den;exactS=dot(left,(oval.^2).*right)/den
        exactO=dot(left,oval.*right)/den
        @test abs(denominator-den)<20ATOL
        @test abs(energy/denominator-expected_E)<20ATOL
        @test abs(bpenergy/denominator-exactBP)<20ATOL
        @test abs(spin/denominator-exactS)<20ATOL
        @test abs(moment/denominator-exactO)<20ATOL
        push!(rows,(lag=lag,qr_cadence=cadence,initial_components=2,HS_histories_per_component=256,
            exact_denominator=den,enumerated_denominator=denominator,
            exact_mixed_energy=expected_E,enumerated_mixed_energy=energy/denominator,
            exact_BP_energy=exactBP,enumerated_BP_energy=bpenergy/denominator,
            exact_BP_O2=exactS,enumerated_BP_O2=spin/denominator,
            exact_BP_O=exactO,enumerated_BP_O=moment/denominator))
    end
    (;rows,problem=p,trial)
end

function integration_checks(out=joinpath(BASE,"integration_checks"))
    ispath(out) && error("Refusing to overwrite integration checks")
    mkpath(out);replay=NamedTuple[];paths=NamedTuple[]
    checks=@testset "Independent integrated multi-Slater importance and BP oracle" begin
        toy=finite_path_sum();append!(paths,toy.rows)
        for cadence in (1,2,7)
            push!(replay,importance_replay(toy.problem,toy.trial;seed=817+cadence,cadence,dt=.15))
        end
        exported=deserialize(Slow.SOURCE)
        trial=Integrated.MultiSlaterTrial(exported.terms;label="singlet20_oracle")
        K=Slow.B.TwoOrbitalOpenClusterED.open_cluster_kinetic_matrix(2,2)
        p=CP.CPAFQMCProblem(K,12.,3,3;lattice_size=2,cell_count=4)
        for cadence in (1,2,7)
            push!(replay,importance_replay(p,trial;seed=917+cadence,cadence,steps=4,dt=.04))
        end
        # Validate newly exposed candidate absolute masses independently.
        ru=trial.terms[1].up;rd=trial.terms[1].down
        for i in 1:8
            v=Fast.trial_local_hs_overlaps(trial.terms,ru,rd,i,1.7,1/1.7)
            for (s,key) in ((1,:plus_absolute_overlap_sum),(-1,:minus_absolute_overlap_sum))
                u=copy(ru);d=copy(rd);u[i,:].*=1.7^s;d[i,:].*=1.7^-s
                expected=sum(abs(t.coefficient*det(t.up'*u)*det(t.down'*d)) for t in trial.terms)
                @test abs(getproperty(v,key)-expected)<ATOL
            end
        end
    end
    Slow.writecsv(joinpath(out,"finite_HS_path_sum.csv"),paths)
    Slow.writecsv(joinpath(out,"actual_importance_replay.csv"),replay)
    open(joinpath(out,"validation.txt"),"w") do io
        println(io,"tests=",Test.get_test_counts(checks));println(io,"base_atol=",ATOL)
        for path in (@__FILE__,joinpath(@__DIR__,"multislater_cp.jl"),joinpath(@__DIR__,"multislater_cp_kernels.jl"),Slow.SOURCE)
            println(io,path," sha256=",bytes2hex(sha256(read(path))))
        end
        println(io,"Actual integrated estimator/history and realized HS sampling checked; no population-control or long-time statistical validation.")
    end
    println("Saved integration checks to ",out)
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    if "integration" in ARGS
        MultiSlaterCPOracle.integration_checks()
    else
        MultiSlaterCPOracle.kernel_checks()
    end
end
