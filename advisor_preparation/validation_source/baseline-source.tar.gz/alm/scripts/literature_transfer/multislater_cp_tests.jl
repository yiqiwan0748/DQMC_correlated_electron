#!/usr/bin/env julia
"""Focused deterministic integration checks; no Monte Carlo campaign."""
module MultiSlaterCPTests
using LinearAlgebra, Serialization, Test, SHA
include(joinpath(@__DIR__,"multislater_cp.jl"))
include(joinpath(@__DIR__,"cp_multitrial_oracle.jl"))
const M=MultiSlaterCP
const O=CPMultitrialOracle
const CP=M.CP
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const OUT=joinpath(ROOT,"results/literature_transfer/multislater_cp_implementation")
const SOURCE=joinpath(ROOT,"results/literature_transfer/trial_symmetry_projection/full_singlet_am3_20_terms.jls")
const ATOL=2e-9

function main()
    ispath(OUT) && error("Refusing to overwrite implementation tests")
    mkpath(OUT)
    try
        suite=@testset "Isolated multi-Slater CP integration" begin
            K=O.B.TwoOrbitalOpenClusterED.open_cluster_kinetic_matrix(2,2)
            p=CP.CPAFQMCProblem(K,12.,3,3;lattice_size=2,cell_count=4)
            trial=M.load_trial(SOURCE)
            occupations=O.B.occupations(8,3)
            vector=O.left_fock(trial.terms,occupations,occupations)
            @test isapprox(norm(vector),1.;atol=2e-11,rtol=0)
            @test all(>(0),trial.initial_importance_weights)
            @test isapprox(sum(trial.initial_importance_weights),1.;atol=2e-12,rtol=0)
            c=CP.CPAFQMCParameters(dtau=.02,walker_count=32,warmup_steps=0,
                measurement_count=1,steps_between_measurements=1,back_propagation_steps=6,
                orthogonalize_every=2,population_control_every=2,minimum_backprop_ancestors=2,
                error_block_size=1,seed=39177)
            state=M.initialize(p,c;trial=trial)
            @test state.initialization==:exact_weighted
            @test sum(state.initial_component_counts)==32
            @test minimum(state.initial_component_counts)>=1
            represented=zeros(length(vector))
            for walker in state.walkers
                overlap=M.total_overlap(trial.terms,walker.up,walker.down).total
                @test overlap>0
                represented.+=exp(walker.log_weight).*O.B.slater(walker.up,walker.down,occupations,occupations)./overlap/32
            end
            @test norm(represented-vector)<2e-11

            # Same random stream and population/history logic must reduce to
            # the established one-term implementation, including anchor rolls.
            @testset "One-term reduction through QR, resampling and history" begin
                q=CP.CPAFQMCProblem(K,2.,3,3;lattice_size=2,cell_count=4)
                single=CP.one_body_trial(q;pattern=:altermagnetic,field_strength=.5)
                multi=M.MultiSlaterTrial([(coefficient=1.,up=single.up,down=single.down)])
                controls=CP.CPAFQMCParameters(dtau=.02,walker_count=8,warmup_steps=0,
                    measurement_count=1,steps_between_measurements=1,back_propagation_steps=4,
                    orthogonalize_every=2,population_control_every=2,minimum_backprop_ancestors=2,
                    error_block_size=1,seed=92713)
                a=M.initialize(q,controls;trial=multi)
                b=CP.initialize_cp_afqmc(q,controls;trial=single)
                for step in 1:12
                    M.step!(a);CP.step_cp_afqmc!(b)
                    @test a.step==b.step
                    @test a.population_controls==b.population_controls
                    for (x,y) in zip(a.walkers,b.walkers)
                        @test x.alive==y.alive
                        @test x.fields==y.fields
                        @test x.field_end_ids==y.field_end_ids
                        @test x.anchor_id==y.anchor_id
                        @test maximum(abs,x.up-y.up)<ATOL
                        @test maximum(abs,x.down-y.down)<ATOL
                        @test abs(x.log_weight-y.log_weight)<ATOL
                        @test abs(x.log_overlap-y.log_overlap)<ATOL
                        @test maximum(abs,x.anchor_up-y.anchor_up)<ATOL
                        @test maximum(abs,x.anchor_down-y.anchor_down)<ATOL
                    end
                    if step>=4
                        x=M.measure(a);r=CP.measure_cp_afqmc(b;include_order=true)
                        y=r.measurement;order=r.order_measurement
                        @test abs(x.E-y.mixed_total_energy)<ATOL
                        @test abs(x.bp_E-y.backpropagated_total_energy)<ATOL
                        @test abs(x.S_alm-y.S_alm_q0)<ATOL
                        @test abs(x.Delta-order.delta_alm)<ATOL
                        @test abs(x.mx-order.mx)<ATOL
                        @test abs(x.my-order.my)<ATOL
                        @test x.ancestors==y.distinct_backprop_ancestors
                    end
                end
            end

            @testset "Twenty-term BP signed QR gauges and positive endpoint" begin
                # A fixed noncommuting history has an independent dense-Fock
                # reference. Its components acquire unequal QR determinants.
                w=M.copy_walker(first(state.walkers))
                fields=[Int8[isodd(i+div(i+k,3)+k) ? 1 : -1 for i in 1:8] for k in 1:18]
                w.fields=fields
                raw=[(coefficient=t.coefficient,up=copy(t.up),down=copy(t.down)) for t in trial.terms]
                for f in Iterators.reverse(fields)
                    raw=[(coefficient=t.coefficient,
                        up=M.slice(t.up,state.kinetic_half,state.gamma,f,1),
                        down=M.slice(t.down,state.kinetic_half,state.gamma,f,-1)) for t in raw]
                end
                stabilized=M.backpropagated_terms(state,w)
                vr=O.left_fock(raw,occupations,occupations)
                vs=O.left_fock(stabilized,occupations,occupations)
                factor=dot(vr,vs)/dot(vs,vs)
                @test factor>0
                @test norm(vr-factor*vs)/norm(vr)<2e-10
                @test length(stabilized)==20
                naive=[(coefficient=t.coefficient,up=CP._cp_canonical_columns(r.up),
                    down=CP._cp_canonical_columns(r.down)) for (t,r) in zip(trial.terms,raw)]
                vn=O.left_fock(naive,occupations,occupations)
                @test norm(vr/norm(vr)-vn/norm(vn))>1e-4
                endpoint_up=copy(w.anchor_up);endpoint_down=copy(w.anchor_down)
                for f in fields
                    endpoint_up=M.slice(endpoint_up,state.kinetic_half,state.gamma,f,1)
                    endpoint_down=M.slice(endpoint_down,state.kinetic_half,state.gamma,f,-1)
                end
                left_overlap=M.total_overlap(raw,w.anchor_up,w.anchor_down).total
                right_overlap=M.total_overlap(trial.terms,endpoint_up,endpoint_down).total
                @test isapprox(left_overlap,right_overlap;atol=2e-10*max(1.,abs(right_overlap)),rtol=0)
                @test left_overlap>0
                unscaled=M.estimator(state,raw,w.anchor_up,w.anchor_down)
                scaled=M.estimator(state,stabilized,w.anchor_up,w.anchor_down)
                for key in keys(unscaled)
                    @test isapprox(getproperty(unscaled,key),getproperty(scaled,key);atol=ATOL,rtol=0)
                end
            end
        end
        open(joinpath(OUT,"validation.txt"),"w") do io
            println(io,"status=PASS")
            println(io,"tests=",Test.get_test_counts(suite))
            println(io,"absolute_tolerance=",ATOL,"; bounded Float64 determinant/Fock contractions")
            for path in (@__FILE__,joinpath(@__DIR__,"multislater_cp.jl"),
                joinpath(@__DIR__,"multislater_cp_kernels.jl"),SOURCE,
                joinpath(ROOT,"src/constrained_path_afqmc.jl"))
                println(io,path," sha256=",bytes2hex(sha256(read(path))))
            end
        end
    catch error
        open(joinpath(OUT,"FAILED.txt"),"w") do io
            showerror(io,error,catch_backtrace());println(io)
        end
        rethrow()
    end
end
end
if abspath(PROGRAM_FILE)==@__FILE__;MultiSlaterCPTests.main();end
