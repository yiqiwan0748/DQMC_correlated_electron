#!/usr/bin/env julia
# Read-only replay of frozen CP paths with extra rotational-spin diagnostics.
# Checkpoints were written with this exact Main module path. Loading it there
# preserves Julia Serialization's type identity without touching saved files.
if !isdefined(Main,:RunMultiSlaterBenchmark)
    Base.include(Main,joinpath(@__DIR__,"run_multislater_benchmark.jl"))
end
module MultiSlaterSU2Diagnostic
using LinearAlgebra, Random, Serialization, SHA, Test, Printf
const R=Main.RunMultiSlaterBenchmark
const M=R.MC
const K=M.KERNEL
const ROOT=R.ROOT
const OUT=joinpath(ROOT,"results/literature_transfer/multislater_su2_diagnostic")
const PLAN=joinpath(ROOT,"docs/reading/multislater_su2_diagnostic_plan.md")
const CORE=joinpath(@__DIR__,"multislater_cp.jl")
const CORE_SHA="c78623f8f11e633c0904ec8e6089e861b4c6c7a36e3d612efa1df8f1a6f5601e"

"""Unnormalized spin squares, valid at singular individual spin overlaps."""
function spin_parts(a,b,weights)
    du=a.overlap;dd=b.overlap;O=O2z=transverse=0.0
    for i in eachindex(weights)
        O+=weights[i]*(dd*a.one[i,i]-du*b.one[i,i])/2
        for j in eachindex(weights)
            scale=weights[i]*weights[j]
            O2z+=scale*(dd*a.pair[i,j]+du*b.pair[i,j]-
                a.one[i,i]*b.one[j,j]-b.one[i,i]*a.one[j,j])/4
            transverse+=scale*(a.one[j,i]*((i==j ? dd : 0.0)-b.one[i,j])+
                b.one[j,i]*((i==j ? du : 0.0)-a.one[i,j]))/2
        end
    end
    return (;overlap=du*dd,O,O2z,transverse,scalar=O2z+transverse)
end

function component_spin(Lu,Ld,Ru,Rd,weights)
    spin_parts(K.spin_numerators(Lu,Ru),K.spin_numerators(Ld,Rd),weights)
end

function local_observables(state,terms,up,down)
    info=M.checked_overlap!(state,terms,up,down;require_positive=true)
    odd=repeat([1.0,-1.0],state.problem.cell_count)
    even=ones(size(up,1))
    rows=map(terms) do t
        a=K.spin_numerators(t.up,up);b=K.spin_numerators(t.down,down)
        energy=K.energy_parts(state.problem,a,b)
        orbital=spin_parts(a,b,odd);total=spin_parts(a,b,even)
        (kinetic=energy.kinetic,interaction=energy.interaction,doubles=energy.double_occupancy,
         O=orbital.O,O2z=orbital.O2z,scalar=orbital.scalar,Stot2=total.scalar)
    end
    quantities=keys(first(rows))
    values=map(quantities) do q
        M.compensated_sum(t.coefficient*getproperty(v,q) for (t,v) in zip(terms,rows))/info.total
    end
    all(isfinite,values) || error("Nonfinite SU2 local diagnostic")
    return NamedTuple{quantities}(values)
end

function measure(state)
    live=[w for w in state.walkers if w.alive]
    all(length(w.fields)==state.parameters.back_propagation_steps for w in live) || error("Incomplete BP history")
    ancestors=length(unique(w.anchor_id for w in live))
    ancestors>=state.parameters.minimum_backprop_ancestors || error("Insufficient BP ancestry")
    state.minimum_distinct_ancestors=min(state.minimum_distinct_ancestors,ancestors)
    maxlog=maximum(w.log_weight for w in live)
    weights=[exp(w.log_weight-maxlog) for w in live];normalization=sum(weights)
    mixed=zeros(7);bp=zeros(7)
    for (w,weight) in zip(live,weights)
        mixed.+=weight.*collect(values(local_observables(state,state.trial.terms,w.up,w.down)))
        left=M.backpropagated_terms(state,w)
        bp.+=weight.*collect(values(local_observables(state,left,w.anchor_up,w.anchor_down)))
    end
    mixed./=normalization;bp./=normalization
    cells=state.problem.cell_count
    state.measurement_count+=1
    return (step=state.step,beta=state.step*state.parameters.dtau,
        E=mixed[1]+mixed[2],bp_E=bp[1]+bp[2],S_alm=bp[5]/cells,Delta=bp[4]/cells,
        S_scalar=bp[6]/(3cells),Stot2=bp[7],scalar_minus_z=bp[6]/(3cells)-bp[5]/cells,
        mixed_scalar=mixed[6]/(3cells),mixed_z=mixed[5]/cells,mixed_Stot2=mixed[7],
        ancestors=ancestors,bp_K=bp[1],bp_V=bp[2],bp_D=bp[3]/cells,status="valid")
end

function read_original(path)
    lines=readlines(path);header=split(first(lines),',')
    rows=Dict{String,String}[]
    for line in lines[2:end]
        values=[strip(v,'"') for v in split(line,',')]
        push!(rows,Dict(zip(header,values)))
    end
    rows
end

function replay(seed)
    seed in (61423,72539) || error("Unregistered SU2 replay seed")
    out=joinpath(OUT,"baseline_seed$(seed)")
    ispath(out) && error("Refusing to overwrite $out")
    mkpath(out)
    original=joinpath(ROOT,"results/literature_transfer/multislater_cp_benchmark/baseline_seed$(seed)_initial")
    source=joinpath(original,"warmup_checkpoint.jls")
    final=joinpath(original,"final_checkpoint.jls")
    samples=joinpath(original,"samples.csv")
    observed=read_original(samples)
    state=deserialize(source)
    @assert bytes2hex(sha256(read(CORE)))==CORE_SHA
    initial_hashes=Dict(p=>bytes2hex(sha256(read(p))) for p in
        (@__FILE__,PLAN,CORE,joinpath(@__DIR__,"multislater_cp_kernels.jl"),source,final,samples))
    open(joinpath(out,"metadata.txt"),"w") do io
        println(io,"seed=",seed,"; adaptation=spin_scalar_diagnostic; original_z_gate_unchanged")
        for (path,hash) in sort(collect(initial_hashes));println(io,path," sha256=",hash);end
    end
    started=time();count=0;errors=Dict(q=>0.0 for q in (:E,:bp_E,:S_alm,:Delta))
    try
        open(joinpath(out,"samples.csv"),"w") do io
            for (j,expected) in enumerate(observed)
                for _ in 1:state.parameters.steps_between_measurements;M.step!(state);end
                row=measure(state)
                R.write_named(io,row;header=j==1)
                @assert row.step==parse(Int,expected["step"])
                @assert row.beta==parse(Float64,expected["beta"])
                @assert row.ancestors==parse(Int,expected["ancestors"])
                for q in keys(errors)
                    errors[q]=max(errors[q],abs(getproperty(row,q)-parse(Float64,expected[string(q)])))
                    @assert errors[q]<2e-8
                end
                count=j
                if j%40==0
                    @printf("SU2 seed%d %d/%d scalar=%.7f z=%.7f Stot2=%.7f elapsed=%.1fs\n",
                        seed,j,length(observed),row.S_scalar,row.S_alm,row.Stot2,time()-started)
                    flush(stdout)
                end
            end
        end
        endpoint=deserialize(final)
        @assert state.step==endpoint.step
        @assert state.constraint_rejections==endpoint.constraint_rejections
        @assert state.population_controls==endpoint.population_controls
        @assert state.killed_walkers==endpoint.killed_walkers
        @assert rand(copy(state.rng),UInt64,32)==rand(copy(endpoint.rng),UInt64,32)
        for (a,b) in zip(state.walkers,endpoint.walkers)
            for key in (:up,:down,:log_weight,:log_overlap,:alive,:anchor_up,:anchor_down,
                        :anchor_id,:fields,:field_end_ids)
                @assert getproperty(a,key)==getproperty(b,key)
            end
        end
        @assert all(hash==bytes2hex(sha256(read(path))) for (path,hash) in initial_hashes)
        open(joinpath(out,"validation.txt"),"w") do io
            println(io,"status=PASS; full measurement-time replay")
            println(io,"endpoint_walker_and_rng_equality=EXACT")
            println(io,"measurements=",count)
            for (q,e) in sort(collect(errors));println(io,"max_original_",q,"_difference=",e);end
            println(io,"comparison_tolerance=2e-8; Float64 contractions far below scientific tolerance")
        end
    catch err
        open(joinpath(out,"FAILED.txt"),"w") do io
            showerror(io,err,catch_backtrace());println(io)
        end
        rethrow()
    finally
        open(joinpath(out,"completion.txt"),"w") do io
            println(io,"retained_measurements=",count)
            println(io,"planned_measurements=",length(observed))
            println(io,"elapsed_seconds=",time()-started)
        end
    end
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    MultiSlaterSU2Diagnostic.replay(parse(Int,ARGS[1]))
end
