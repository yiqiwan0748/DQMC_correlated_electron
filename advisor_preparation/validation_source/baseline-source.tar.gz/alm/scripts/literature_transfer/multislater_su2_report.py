#!/usr/bin/env python3
"""Summarize separately registered SU2 replay diagnostics, without gate substitution."""
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics as stats

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/literature_transfer/multislater_su2_diagnostic'
GROUND=1.183248801940442
BLOCKS=(5,10,20,40)
QUANTITIES=('S_alm','S_scalar','Stot2','Delta','scalar_minus_z','mixed_scalar','mixed_z','mixed_Stot2','extrapolated_scalar')

def read(path):
    with path.open() as f:
        return list(csv.DictReader(f))

def write(name,rows):
    if not rows:
        return
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def block_se(values,b):
    assert len(values)%b==0 and len(values)//b>=4
    blocks=[stats.mean(values[j:j+b]) for j in range(0,len(values),b)]
    return stats.stdev(blocks)/math.sqrt(len(blocks))

TRIAL_SOURCE=ROOT/'results/literature_transfer/trial_symmetry_projection/full_singlet_exact_pure_projection.csv'
TRIAL=float(next(r for r in read(TRIAL_SOURCE) if float(r['tau'])==0)['S_odd_q0'])
MIXED_SOURCE=ROOT/'results/literature_transfer/exact_multislater_scalar_reference/mixed_scalar_controls.csv'
BP_SOURCE=ROOT/'results/literature_transfer/exact_multislater_projection/exact_schedule_controls.csv'
mixed_controls=read(MIXED_SOURCE)
matched_mixed=[r for r in mixed_controls if r['reference']=='discrete_dt02_warm16_lag0']
matched_bp=[r for r in read(BP_SOURCE) if float(r['dtau'])==.02 and
            float(r['warmup'])==16 and float(r['bp_lag'])==4]
assert len(matched_mixed)==len(matched_bp)==160
ground_right=next(r for r in mixed_controls if r['reference']=='exact_ground_right')
assert abs(float(ground_right['trial_scalar'])-TRIAL)<2e-14

rows=[];blocking=[];health=[];hashes={}
for seed in (61423,72539):
    directory=OUT/f'baseline_seed{seed}'
    samples=read(directory/'samples.csv') if (directory/'samples.csv').exists() else []
    completed=(directory/'validation.txt').exists()
    health.append(dict(seed=seed,saved_measurements=len(samples),planned_measurements=160,
                       endpoint_and_replay_validated=completed,completed_pool=completed and len(samples)==160))
    if not completed:
        continue
    assert len(samples)==160
    for sample,exact_mixed,exact_bp in zip(samples,matched_mixed,matched_bp):
        assert abs(float(sample['beta'])-float(exact_mixed['beta']))<1e-12
        assert abs(float(sample['beta'])-float(exact_bp['beta']))<1e-12
    for path in (directory/'samples.csv',directory/'validation.txt',directory/'metadata.txt'):
        hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    for q in QUANTITIES:
        values=[2*float(x['mixed_scalar'])-TRIAL if q=='extrapolated_scalar' else float(x[q]) for x in samples]
        assert all(math.isfinite(x) for x in values)
        errors={b:block_se(values,b) for b in BLOCKS}
        rows.append(dict(seed=seed,quantity=q,mean=stats.mean(values),standard_error=max(errors.values()),
                         minimum=min(values),maximum=max(values)))
        for b,error in errors.items():
            blocking.append(dict(seed=seed,quantity=q,block_size=b,block_count=160//b,standard_error=error))
pooled=[]
for q in QUANTITIES:
    selected=[r for r in rows if r['quantity']==q]
    if not selected:
        continue
    center=stats.mean(r['mean'] for r in selected)
    within=math.sqrt(sum(r['standard_error']**2 for r in selected))/len(selected)
    between=stats.stdev(r['mean'] for r in selected)/math.sqrt(len(selected)) if len(selected)>1 else 0
    error=max(within,between)
    exact=GROUND if q in ('S_alm','S_scalar','mixed_scalar','mixed_z','extrapolated_scalar') else 0.0
    registered=q in ('S_alm','S_scalar','Delta')
    tolerance=.05 if q=='Delta' else .05*GROUND if q in ('S_alm','S_scalar') else ''
    budget=abs(center-exact)+3*error
    pooled.append(dict(quantity=q,seeds=len(selected),mean=center,standard_error=error,
                       within_seed_standard_error=within,between_seed_standard_error=between,
                       exact_ground_reference=exact,ground_difference=center-exact,
                       registered_screen=registered,tolerance=tolerance,
                       absolute_error_plus_3SE=budget if registered else '',
                       screen=('PASS' if budget<=tolerance else 'FAIL') if registered else
                              'EXPLORATORY_NO_PASS_GATE' if q=='extrapolated_scalar' else 'DIAGNOSTIC_ONLY',
                       scope='post-results MoreoEq7 exploration; trial dependence untested' if q=='extrapolated_scalar' else
                             'new scalar diagnostic cannot replace original z accuracy gate'))
write('per_seed.csv',rows);write('blocking.csv',blocking);write('pooled.csv',pooled);write('health.csv',health)
same_boundary=[]
for row in pooled:
    q=row['quantity']
    if q in ('S_alm','S_scalar'):
        exact=stats.mean(float(r['exact_BP_S_odd_q0']) for r in matched_bp)
    elif q=='mixed_scalar':
        exact=stats.mean(float(r['mixed_scalar']) for r in matched_mixed)
    elif q=='mixed_z':
        exact=stats.mean(float(r['mixed_z']) for r in matched_mixed)
    elif q=='extrapolated_scalar':
        exact=stats.mean(float(r['twice_mixed_minus_trial']) for r in matched_mixed)
    else:
        exact=0.0
    same_boundary.append(dict(quantity=q,CP_mean=row['mean'],standard_error=row['standard_error'],
                              exact_same_time_discrete_reference=exact,difference=row['mean']-exact,
                              scope='diagnostic comparison only; same Ts bra, initial Ts ket, and actual measurement times'))
write('same_boundary_comparison.csv',same_boundary)
for path in (Path(__file__),ROOT/'docs/reading/multislater_su2_diagnostic_plan.md',
             ROOT/'scripts/literature_transfer/multislater_su2_diagnostic.jl',
             ROOT/'scripts/literature_transfer/multislater_su2_tests.jl',OUT/'fock_tests/validation.txt'):
    hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
for path in (TRIAL_SOURCE,MIXED_SOURCE,BP_SOURCE,ROOT/'docs/reading/multislater_su2_extrapolation_note.md'):
    hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
for path in (ROOT/'docs/reading/multislater_su2_diagnostic.md',
             ROOT/'results/literature_transfer/actual_multislater_su2_audit/observable_checks.csv',
             ROOT/'results/literature_transfer/actual_multislater_su2_audit/validation.txt',
             ROOT/'results/literature_transfer/exact_multislater_scalar_reference/validation.txt'):
    hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
with (OUT/'provenance.json').open('w') as f:
    json.dump(dict(hashes=hashes,ground_S=GROUND,trial_scalar=TRIAL,
                   exact_ground_right_mixed_scalar=float(ground_right['mixed_scalar']),
                   exact_ground_right_extrapolated_scalar=float(ground_right['twice_mixed_minus_trial']),
                   scope='post-baseline prospective SU2 diagnostic; no replacement of original z observable'),f,indent=2)
with (OUT/'comparison_table.md').open('w') as f:
    f.write('| Quantity | Seeds | Mean | SE | Exact ground | Diagnostic status |\n|---|---:|---:|---:|---:|---|\n')
    for r in pooled:
        f.write(f"| {r['quantity']} | {r['seeds']} | {r['mean']:.7f} | {r['standard_error']:.7f} | {r['exact_ground_reference']:.7f} | {r['screen']} |\n")
print(f'Reported {sum(r["completed_pool"] for r in health)} complete replay seeds; original gates unchanged.')
