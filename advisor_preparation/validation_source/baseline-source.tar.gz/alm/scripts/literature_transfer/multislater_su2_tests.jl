#!/usr/bin/env julia
# Independent tiny-Fock validation of transverse spin numerator polynomials.
using LinearAlgebra, Test, SHA
include(joinpath(@__DIR__,"multislater_su2_diagnostic.jl"))
const D=MultiSlaterSU2Diagnostic
const OUT=joinpath(D.OUT,"fock_tests")

function act(bits,operators)
    phase=1.0;result=bits
    for (create,mode) in operators
        bit=UInt64(1)<<(mode-1);occupied=!iszero(result&bit)
        create==occupied && return nothing
        isodd(count_ones(result&(bit-1))) && (phase=-phase)
        result=xor(result,bit)
    end
    return result,phase
end

function fock_operators(M,Nup,Ndown,w)
    up=[UInt64(i) for i in 0:(2^M-1) if count_ones(i)==Nup]
    down=[UInt64(i) for i in 0:(2^M-1) if count_ones(i)==Ndown]
    states=[u|(d<<M) for u in up for d in down]
    index=Dict(s=>i for (i,s) in enumerate(states));dim=length(states)
    z=[sum(w[i]*(!iszero(s&(UInt64(1)<<(i-1)))-!iszero(s&(UInt64(1)<<(M+i-1)))) for i in 1:M)/2 for s in states]
    transverse=zeros(dim,dim)
    for (column,s) in enumerate(states),i in 1:M,j in 1:M
        # Operators are applied rightmost first, including Fock parity signs.
        for ops in (((false,j),(true,M+j),(false,M+i),(true,i)),
                    ((false,M+j),(true,j),(false,i),(true,M+i)))
            target=act(s,ops)
            isnothing(target) && continue
            row,phase=target
            transverse[index[row],column]+=w[i]*w[j]*phase/2
        end
    end
    return (;up,down,z,transverse,scalar=Diagonal(z.^2)+transverse)
end

function fock_vector(U,V,up,down)
    M=size(U,1)
    rows(mask)=[i for i in 1:M if !iszero(mask&(UInt64(1)<<(i-1)))]
    [det(U[rows(u),:])*det(V[rows(d),:]) for u in up for d in down]
end

function main()
    ispath(OUT) && error("Refusing to overwrite SU2 Fock tests")
    mkpath(OUT)
    try
        suite=@testset "Independent SU2 Fock numerator oracle" begin
            Q=[1. 1. 1. 1.;1. -1. 1. -1.;1. 1. -1. -1.;1. -1. -1. 1.]/2
            for N in 1:3,weights in ([1.,-1.,1.,-1.],ones(4),[.7,-1.2,.3,.5])
                f=fock_operators(4,N,N,weights)
                @test maximum(abs,f.scalar-f.scalar')<1e-13
                rightup=Q[:,1:N];rightdown=Q[:,1:N]
                shifted=vcat(collect(1:(N-1)),[N+1])
                regularup=exp(Symmetric([.1 .2 0. .1;.2 -.1 .15 0.;0. .15 .07 .2;.1 0. .2 -.04]))*rightup
                for (Lu,Ld) in ((rightup,rightdown),(regularup,rightdown),
                    (Q[:,shifted],rightdown),(Q[:,shifted],Q[:,shifted]))
                    left=fock_vector(Lu,Ld,f.up,f.down)
                    right=fock_vector(rightup,rightdown,f.up,f.down)
                    result=D.component_spin(Lu,Ld,rightup,rightdown,weights)
                    @test abs(result.overlap-dot(left,right))<5e-12
                    @test abs(result.O-dot(left,f.z.*right))<5e-12
                    @test abs(result.O2z-dot(left,(f.z.^2).*right))<5e-12
                    @test abs(result.transverse-dot(left,f.transverse*right))<5e-12
                    @test abs(result.scalar-dot(left,f.scalar*right))<5e-12
                    # Nonorthogonal occupied-basis gauge with negative determinant.
                    A=Matrix{Float64}(I,N,N);A[1,1]=-1.7
                    B=Matrix{Float64}(I,N,N);B[1,1]=.6
                    transformed=D.component_spin(Lu*A,Ld*B,rightup,rightdown,weights)
                    for key in keys(result)
                        @test isapprox(getproperty(transformed,key),det(A)*det(B)*getproperty(result,key);atol=5e-12,rtol=0)
                    end
                end
            end
            # Both spin overlaps vanish but exchange survives. Dropping this
            # component destroys the transverse numerator.
            E=Matrix{Float64}(I,4,4)
            zero=D.component_spin(E[:,2:2],E[:,1:1],E[:,1:1],E[:,2:2],ones(4))
            @test zero.overlap==0.0
            @test abs(zero.transverse)>0.5
            @test zero.O2z==0.0
            # A global singlet must give scalar=3*z for every spatial pattern.
            pattern=[.7,-1.2,.3,.5]
            f=fock_operators(4,1,1,pattern)
            a=fock_vector(E[:,1:1],E[:,2:2],f.up,f.down)
            b=fock_vector(E[:,2:2],E[:,1:1],f.up,f.down)
            singlet=(a+b)/sqrt(2)
            @test isapprox(dot(singlet,f.scalar*singlet),3dot(singlet,(f.z.^2).*singlet);atol=5e-12,rtol=0)
            total=fock_operators(4,1,1,ones(4))
            @test norm(total.scalar*singlet)<5e-12
            # Mixed total-spin square vanishes for arbitrary right vectors
            # when the exact bra is this singlet: it cannot certify the ket.
            @test abs(dot(singlet,total.scalar*a))<5e-12
        end
        open(joinpath(OUT,"validation.txt"),"w") do io
            println(io,"status=PASS")
            println(io,"tests=",Test.get_test_counts(suite))
            println(io,"absolute_tolerance=5e-12; tiny exact Fock operators and Float64 determinant contractions")
            for p in (@__FILE__,joinpath(@__DIR__,"multislater_su2_diagnostic.jl"),D.PLAN,D.CORE)
                println(io,p," sha256=",bytes2hex(sha256(read(p))))
            end
        end
    catch err
        open(joinpath(OUT,"FAILED.txt"),"w") do io
            showerror(io,err,catch_backtrace());println(io)
        end
        rethrow()
    end
end
main()
