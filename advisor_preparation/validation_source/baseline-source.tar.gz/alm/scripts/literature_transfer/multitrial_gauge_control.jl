#!/usr/bin/env julia
using LinearAlgebra, Serialization, Test, SHA
include(joinpath(@__DIR__,"cp_multitrial_oracle.jl"))
const M=CPMultitrialOracle
const CP=M.CP
const OUT=joinpath(M.ROOT,"results/literature_transfer/multitrial_gauge_control")

function main()
    ispath(OUT) && error("Refusing to replace gauge-control outputs")
    source=deserialize(M.SOURCE)
    terms=[(coefficient=t.coefficient/source.normalization,up=t.up,down=t.down) for t in source.terms]
    # Determinant coefficients must transform with every occupied-basis change.
    modified=[]
    for (i,t) in enumerate(terms)
        A=[1.4 .2sin(i) 0.;0. -.8 .1;.1 .3 1.2]
        B=[.7 0. .1;.2 1.3 .2cos(i);0. .1 -1.1]
        push!(modified,(coefficient=t.coefficient/(det(A)*det(B)),up=t.up*A,down=t.down*B))
    end
    C=[1.5 .3 0.;0. -.7 .2;.1 0. 1.1]
    D=[.6 .1 0.;0. 1.4 .2;.1 0. .9]
    factor=det(C)*det(D)
    K=M.B.TwoOrbitalOpenClusterED.open_cluster_kinetic_matrix(2,2)
    p=CP.CPAFQMCProblem(K,12.,3,3;lattice_size=2,cell_count=4)
    w=repeat([1.,-1.],4)
    rows=NamedTuple[]
    checks=@testset "Multi-Slater occupied-basis gauge control" begin
        ou=M.B.occupations(8,3)
        @test norm(M.left_fock(terms,ou,ou)-M.left_fock(modified,ou,ou))<2e-9
        for field in (0.,3.,-3.,6.)
            trial=CP.one_body_trial(p;pattern=:altermagnetic,field_strength=field)
            a=M.multitrial_estimator(p,terms,trial.up,trial.down,w)
            b=M.multitrial_estimator(p,modified,trial.up*C,trial.down*D,w)
            @test a.status==b.status
            @test isapprox(b.total_overlap,factor*a.total_overlap;atol=2e-9,rtol=0)
            @test isapprox(b.overlap_scale,abs(factor)*a.overlap_scale;atol=2e-9,rtol=0)
            @test isapprox(b.absolute_overlap_mass,abs(factor)*a.absolute_overlap_mass;atol=2e-9,rtol=0)
            @test isapprox(b.relative_total_overlap,a.relative_total_overlap;atol=2e-9,rtol=0)
            for q in keys(a.numerator)
                @test isapprox(getproperty(b.numerator,q),factor*getproperty(a.numerator,q);atol=2e-9,rtol=0)
                if !isnothing(a.values)
                    @test isapprox(getproperty(a.values,q),getproperty(b.values,q);atol=2e-9,rtol=0)
                end
            end
            push!(rows,(field=field,status=a.status,original_overlap=a.total_overlap,
                regauged_overlap=b.total_overlap,expected_factor=factor,
                maximum_numerator_scaling_error=maximum(abs(getproperty(b.numerator,q)-factor*getproperty(a.numerator,q)) for q in keys(a.numerator))))
        end
    end
    mkpath(OUT)
    M.writecsv(joinpath(OUT,"gauge_checks.csv"),rows)
    open(joinpath(OUT,"validation.txt"),"w") do io
        println(io,"tests=",Test.get_test_counts(checks))
        println(io,"absolute_tolerance=2e-9 for accumulated Float64 determinant/minor roundoff")
        for path in (@__FILE__,joinpath(@__DIR__,"cp_multitrial_oracle.jl"),M.SOURCE)
            println(io,path," sha256=",bytes2hex(sha256(read(path))))
        end
    end
end
main()
