#!/usr/bin/env julia
# A field-imposed transport-symmetry transfer from PRB 93, 085144 (2016).
# No interacting calculation, Monte Carlo, or material conductivity is performed.
using LinearAlgebra
using Printf
using Test

const PARAMETERS = (-1.0, -1.75, -0.85, -0.65)
const TEMPERATURE = 0.1
const DENSITY = 1.5
const TARGET_DENSITY = 1.46021875
const OUTPUT = normpath(joinpath(@__DIR__, "../../results/literature_transfer/nematic"))

function band_data(kx, ky, spin, hc, hs)
    t1,t2,t3,t4 = PARAMETERS
    cx,cy,sx,sy = cos(kx),cos(ky),sin(kx),sin(ky)
    center = -(t1+t2)*(cx+cy)-4t3*cx*cy
    dz = -(t1-t2)*(cx-cy)-hc-spin*hs
    dx = -4t4*sx*sy
    radius = hypot(dz,dx)
    radius > 1e-13 || error("Degenerate band point: velocity needs subspace treatment")
    dcx,dcy = (t1+t2)*sx+4t3*sx*cy, (t1+t2)*sy+4t3*cx*sy
    drx = (dz*(t1-t2)*sx + dx*(-4t4*cx*sy))/radius
    dry = (dz*(-(t1-t2)*sy) + dx*(-4t4*sx*cy))/radius
    return ((center-radius,dcx-drx,dcy-dry),(center+radius,dcx+drx,dcy+dry))
end

function matrix_energies(kx,ky,spin,hc,hs)
    t1,t2,t3,t4=PARAMETERS
    ex=-2t1*cos(kx)-2t2*cos(ky)-4t3*cos(kx)*cos(ky)-hc-spin*hs
    ey=-2t2*cos(kx)-2t1*cos(ky)-4t3*cos(kx)*cos(ky)+hc+spin*hs
    xy=-4t4*sin(kx)*sin(ky)
    eigvals(Symmetric([ex xy;xy ey]))
end

fermi(x) = x>=0 ? exp(-x)/(1+exp(-x)) : 1/(1+exp(x))

function sample(nk,hc,hs,wanted_density=DENSITY)
    # Midpoint periodic grid excludes sin(k)=0 degeneracies and is invariant
    # under kx<->ky. Each spin/band occupies exactly nk^2 states.
    energy=Matrix{Float64}(undef,2nk^2,2)
    vx=similar(energy);vy=similar(energy)
    for (is,spin) in enumerate((1,-1))
        i=0
        for ix in 0:nk-1, iy in 0:nk-1
            kx=-pi+2pi*(ix+0.5)/nk;ky=-pi+2pi*(iy+0.5)/nk
            for (e,x,y) in band_data(kx,ky,spin,hc,hs)
                i+=1;energy[i,is]=e;vx[i,is]=x;vy[i,is]=y
            end
        end
    end
    lo=minimum(energy)-20TEMPERATURE;hi=maximum(energy)+20TEMPERATURE
    density(mu)=sum(fermi((e-mu)/TEMPERATURE) for e in energy)/nk^2
    for _ in 1:65
        mu=(lo+hi)/2
        if density(mu)<wanted_density;lo=mu;else;hi=mu;end
    end
    mu=(lo+hi)/2
    w=zeros(2,2)
    for is in 1:2, i in axes(energy,1)
        occupation=fermi((energy[i,is]-mu)/TEMPERATURE)
        factor=occupation*(1-occupation)/TEMPERATURE/nk^2
        w[is,1]+=vx[i,is]^2*factor;w[is,2]+=vy[i,is]^2*factor
    end
    return (nk=nk,hc=hc,hs=hs,mu=mu,density=density(mu),up_x=w[1,1],up_y=w[1,2],down_x=w[2,1],down_y=w[2,2],charge_x=sum(w[:,1]),charge_y=sum(w[:,2]))
end

mkpath(OUTPUT)
checks=@testset "Independent band velocity and transport symmetry" begin
    # 1e-8 allows central-difference truncation at step 1e-5 and eigensolver
    # rounding. The grid symmetry checks use 2e-11 for accumulated Float64 sums.
    for (kx,ky) in ((0.37,1.12),(-1.43,0.59),(2.11,-0.77)), spin in (-1,1), (hc,hs) in ((0.0,0.35),(0.35,0.0),(0.0,0.0))
        data=band_data(kx,ky,spin,hc,hs);step=1e-5
        ex=(matrix_energies(kx+step,ky,spin,hc,hs)-matrix_energies(kx-step,ky,spin,hc,hs))/(2step)
        ey=(matrix_energies(kx,ky+step,spin,hc,hs)-matrix_energies(kx,ky-step,spin,hc,hs))/(2step)
        exact=matrix_energies(kx,ky,spin,hc,hs)
        for b in 1:2
            @test isapprox(data[b][1],exact[b];atol=1e-12,rtol=1e-12)
            @test isapprox(data[b][2],ex[b];atol=1e-8,rtol=1e-8)
            @test isapprox(data[b][3],ey[b];atol=1e-8,rtol=1e-8)
        end
    end
end

rows=NamedTuple[]
@testset "Grid transport cancellation and positive control" begin
    for wanted_density in (DENSITY,TARGET_DENSITY), nk in (96,192,384), (label,hc,hs) in (("unperturbed",0.0,0.0),("orbital_magnetic",0.0,0.35),("magnetic_reversed",0.0,-0.35),("orbital_charge",0.35,0.0))
        row=sample(nk,hc,hs,wanted_density);push!(rows,merge((label=label,wanted_density=wanted_density),row))
        @test abs(row.density-wanted_density)<2e-11
        @test min(row.up_x,row.up_y,row.down_x,row.down_y)>0
        if hc==0
            @test isapprox(row.up_x,row.down_y;atol=2e-11,rtol=2e-11)
            @test isapprox(row.up_y,row.down_x;atol=2e-11,rtol=2e-11)
            @test isapprox(row.charge_x,row.charge_y;atol=2e-11,rtol=2e-11)
        else
            @test isapprox(row.up_x,row.down_x;atol=2e-11,rtol=2e-11)
            @test isapprox(row.up_y,row.down_y;atol=2e-11,rtol=2e-11)
            @test abs(row.charge_x-row.charge_y)>1e-3
        end
    end
    for wanted_density in (DENSITY,TARGET_DENSITY), nk in (96,192,384)
        a=only(filter(r->r.nk==nk && r.wanted_density==wanted_density && r.label=="orbital_magnetic",rows))
        b=only(filter(r->r.nk==nk && r.wanted_density==wanted_density && r.label=="magnetic_reversed",rows))
        @test isapprox(a.up_x,b.down_x;atol=2e-11,rtol=2e-11)
        @test isapprox(a.up_y,b.down_y;atol=2e-11,rtol=2e-11)
        @test abs(a.up_x-a.up_y)>1e-3
    end
end

open(joinpath(OUTPUT,"transport_weights.csv"),"w") do io
    names=keys(first(rows));println(io,join(string.(names),","))
    for r in rows
        println(io,join([v isa AbstractFloat ? @sprintf("%.16g",v) : string(v) for v in values(r)],","))
    end
end
open(joinpath(OUTPUT,"summary.md"),"w") do io
    println(io,"# Orbital-magnetic and orbital-charge transport symmetry\n")
    println(io,"Field-imposed band diagnostic inspired by Mukherjee et al., Physical Review B 93, 085144 (2016), Figs.4 and7. No spontaneous Hubbard or OSDC phase is reproduced.\n")
    println(io,"Target hoppings: ",PARAMETERS,"; T=",TEMPERATURE,"; densities=",(DENSITY,TARGET_DENSITY),". H_sigma=H0-(hc+sigma*hs) tau_z. Common constant relaxation time; weights omit the common e^2 tau/hbar^2 factor.\n")
    println(io,"| Source (Nk=384) | density | mu | up x | up y | total x | total y |")
    println(io,"|---|---:|---:|---:|---:|---:|---:|")
    for r in filter(r->r.nk==384,rows)
        @printf(io,"| %s | %.8f | %.9f | %.9f | %.9f | %.9f | %.9f |\n",r.label,r.wanted_density,r.mu,r.up_x,r.up_y,r.charge_x,r.charge_y)
    end
    println(io,"\nThe orbital-magnetic source produces opposite spin-resolved longitudinal anisotropies, which cancel in the charge sum. The charge-nematic source produces an uncancelled charge anisotropy. These finite-temperature positive band weights do not diagnose insulating versus metallic phases.\n")
    println(io,"Symmetry cancellation survives all three meshes. Absolute quadrature convergence is recorded below independently of symmetry checks.\n")
    for wanted_density in (DENSITY,TARGET_DENSITY), label in ("unperturbed","orbital_magnetic","orbital_charge")
        coarse=only(filter(r->r.nk==192 && r.wanted_density==wanted_density && r.label==label,rows));fine=only(filter(r->r.nk==384 && r.wanted_density==wanted_density && r.label==label,rows))
        err=maximum(abs.([coarse.up_x-fine.up_x,coarse.up_y-fine.up_y,coarse.charge_x-fine.charge_x,coarse.charge_y-fine.charge_y]))
        @printf(io,"- %s at n=%.8f: largest absolute weight shift Nk192→384 = %.4g.\n",label,wanted_density,err)
    end
    println(io,"\nSee docs/reading/transfer_nematic.md for derivation, assumptions, source scope, and why this differs from the published stripe OSDC calculation.")
end
println("Wrote ",OUTPUT)
