#!/usr/bin/env julia
# Isolated interpretation of one finite cluster; no effective-model substitution.
module OrbitalMomentControl
using LinearAlgebra, SparseArrays, Serialization, Test, Printf
include(joinpath(@__DIR__,"ed_estimator_audit.jl"))
const A=EDEstimatorAudit
const ED=A.ED
const OUT=joinpath(@__DIR__,"..","..","results","literature_transfer","orbital_moment_control")
const CACHE=joinpath(@__DIR__,"..","..","results","literature_transfer","trial_symmetry_projection","u12_complete_spectrum.jls")
const TOL=2e-9 # Float64 dimension3136 matrix actions; not a fit-error tolerance.

function orbital_raise(initial,final,orbital)
    rows,columns,values=Int[],Int[],Float64[]
    lookup=Dict((u,d)=>(i-1)*length(final.down_states)+j
                for (i,u) in enumerate(final.up_states) for (j,d) in enumerate(final.down_states))
    column=0
    for up in initial.up_states, down in initial.down_states
        column+=1
        packed=up|(down<<8)
        for mode in orbital:2:8
            ub=UInt64(1)<<(mode-1);db=UInt64(1)<<(mode+7)
            iszero(packed&db) && continue
            !iszero(packed&ub) && continue
            intermediate=packed⊻db
            exponent=count_ones(packed&(db-1))+count_ones(intermediate&(ub-1))
            result=intermediate|ub
            push!(rows,lookup[(result&0xff,result>>8)])
            push!(columns,column);push!(values,iseven(exponent) ? 1.0 : -1.0)
        end
    end
    sparse(rows,columns,values,length(final),length(initial))
end

function charge_commutator_norm(op,charge)
    square=0.0
    for column in eachindex(op.diagonal)
        for p in op.column_pointers[column]:op.column_pointers[column+1]-1
            square+=abs2(op.hopping_values[p]*(charge[op.row_indices[p]]-charge[column]))
        end
    end
    sqrt(square)
end

function main()
    mkpath(OUT)
    cache=deserialize(CACHE)
    K=ED.open_cluster_kinetic_matrix(2,2)
    @test cache.K==K && cache.U==12.0 && cache.Nup==cache.Ndown==3
    op=ED.sector_hamiltonian(K,12.,3,3)
    E,V=cache.energies,cache.vectors;g=V[:,1];E0=E[1]
    @test norm(op*g-E0*g)<TOL
    fock=A.fock_oracle(op.basis)
    za=vec(sum(fock.z[:,1:2:end];dims=2))
    zb=vec(sum(fock.z[:,2:2:end];dims=2))
    na=vec(sum((fock.nu+fock.nd)[:,1:2:end];dims=2))
    @test all(iszero,za+zb)
    destination=ED.sector_basis(8,4,2)
    ra=orbital_raise(op.basis,destination,1)
    rb=orbital_raise(op.basis,destination,2)
    @test ra+rb==A.spin_raise(op.basis,destination)
    sa2=ra'*ra+spdiagm(0=>za.^2+za)
    sb2=rb'*rb+spdiagm(0=>zb.^2+zb)
    @test issymmetric(sa2) && issymmetric(sb2)
    @test norm(sa2*spdiagm(0=>na)-spdiagm(0=>na)*sa2)<TOL
    sa=dot(g,sa2*g);sb=dot(g,sb2*g)
    cross=dot(abs2.(g),za.*zb)+real(dot(ra*g,rb*g))
    Sodd=dot(abs2.(g),(za-zb).^2)/4
    @test abs(sa-3Sodd)<TOL
    @test abs(sb-sa)<TOL
    @test abs(cross+sa)<TOL
    @test norm((ra+rb)*g)<TOL
    navg=dot(abs2.(g),na);nvar=dot(abs2.(g),(na.-navg).^2)
    commnorm=charge_commutator_norm(op,na)
    @test commnorm>1.0
    @test nvar>1e-6
    nohybrid=copy(K);nohybrid[1:2:end,2:2:end].=0;nohybrid[2:2:end,1:2:end].=0
    @test charge_commutator_norm(ED.sector_hamiltonian(nohybrid,12.,3,3),na)==0

    spins=(0.0,.5,1.,1.5,2.)
    lambdas=[s*(s+1) for s in spins]
    components=[];weights=[];joint=[]
    for (i,s) in enumerate(spins)
        p=copy(g)
        for j in eachindex(spins)
            i==j && continue
            p=(sa2*p-lambdas[j]*p)/(lambdas[i]-lambdas[j])
        end
        weight=sum(abs2,p)
        @test norm(sa2*p-lambdas[i]*p)<TOL
        @test abs(dot(g,p)-weight)<TOL
        push!(components,p);push!(weights,weight)
        for n in 0:6
            push!(joint,(orbital_spin=s,orbital_particle_number=n,weight=sum(abs2,p[na.==n])))
        end
    end
    @test norm(sum(components)-g)<TOL
    @test abs(sum(weights)-1)<TOL
    @test abs(sum(lambdas.*weights)-sa)<TOL
    @test weights[end]<TOL # Six total electrons and total singlet exclude SA=2.
    for i in eachindex(spins),j in 1:i-1
        @test abs(dot(components[i],components[j]))<TOL
    end

    # First four levels are nondegenerate within Sz=0, with total S=0..3.
    gaps=E[2:4].-E0
    for i in 1:4
        @test abs(sum(abs2,(ra+rb)*V[:,i])-(i-1)*i)<TOL
    end
    x=[1.,3.,6.]
    Jfit=dot(x,gaps)/dot(x,x);Jfirst=gaps[1]
    fitrows=[(total_spin=s,gap=gaps[s],J_from_first_gap=Jfirst,
              prediction_from_first=Jfirst*x[s],residual_from_first=gaps[s]-Jfirst*x[s],
              fitted_J=Jfit,fitted_prediction=Jfit*x[s],fit_residual=gaps[s]-Jfit*x[s],
              fractional_fit_residual=(gaps[s]-Jfit*x[s])/gaps[s]) for s in 1:3]

    # Complete orbital-spin source amplitudes, normalized per physical cell.
    orbital_sources=hcat(za.*g,zb.*g)/2
    amplitudes=V'*orbital_sources
    covariance=orbital_sources'*orbital_sources
    @test maximum(abs,amplitudes'*amplitudes-covariance)<TOL
    lowest=amplitudes[2,:]
    matrix=conj.(lowest)*transpose(lowest)
    lowest_odd_weight=real(matrix[1,1]+matrix[2,2]-matrix[1,2]-matrix[2,1])
    @test abs(sum(lowest))<TOL
    @test lowest_odd_weight<=Sodd+TOL
    matrixrows=[(orbital_a=a,orbital_b=b,amplitude_a=lowest[a],amplitude_b=lowest[b],
                 first_triplet_weight=matrix[a,b],complete_equal_time_weight=covariance[a,b])
                for a in 1:2 for b in 1:2]

    summary=[(U=12.,N=6,cells=4,energy=E0,
        orbital_A_spin_squared=sa,orbital_B_spin_squared=sb,
        orbital_spin_dot=cross,S_odd_q0=Sodd,ideal_two_spin_three_halves_S_odd=1.25,
        mean_N_A=navg,variance_N_A=nvar,H_N_A_commutator_frobenius=commnorm,
        ground_charge_commutator_norm=norm(op*(na.*g)-E0*(na.*g)),
        first_triplet_odd_weight=lowest_odd_weight,
        first_triplet_fraction_of_odd_weight=lowest_odd_weight/Sodd,
        fitted_J=Jfit,J_from_first_triplet_gap=Jfirst)]
    A.write_csv(joinpath(OUT,"orbital_moment_summary.csv"),summary)
    A.write_csv(joinpath(OUT,"orbital_spin_weights.csv"),[(spin=s,spin_squared=s*(s+1),weight=w) for(s,w) in zip(spins,weights)])
    A.write_csv(joinpath(OUT,"joint_orbital_charge_spin_weights.csv"),joint)
    A.write_csv(joinpath(OUT,"coupled_spin_gap_fit.csv"),fitrows)
    A.write_csv(joinpath(OUT,"ground_to_first_triplet_orbital_matrix.csv"),matrixrows)
    println(only(summary));println("Orbital spin weights: ",collect(zip(spins,weights)))
end

if abspath(PROGRAM_FILE)==@__FILE__
    old=BLAS.get_num_threads();BLAS.set_num_threads(2)
    try
        @testset "Finite-cluster orbital moment interpretation" main()
    finally
        BLAS.set_num_threads(old)
    end
end
end
