#!/usr/bin/env julia
# Isolated literature-transfer calculation. It does not change the target model.
using LinearAlgebra, Printf
include(joinpath(@__DIR__, "..", "prl_101_237004_ed.jl"))
using .PRL101237004ED

const OUTDIR = joinpath(@__DIR__, "..", "..", "results", "literature_transfer", "osmp")
const ATOL = 1e-10 # <=16x16 Float64 matrices, energies O(10); resolves roundoff only.

# Two sites, (a,b) orbitals each, N=6. b lies delta below a and is filled
# in the atomic low-energy manifold. Only a1<->b2 and b1<->a2 hopping.
function hamiltonian(t, U, J, delta, nu, nd; intraorbital_only=false)
    K = diagm([0.0, -delta, 0.0, -delta])
    K[1,4] = K[4,1] = t
    K[2,3] = K[3,2] = t
    op = sector_hamiltonian(K, U, nu, nd; J=J, max_dimension=32)
    H = dense_hamiltonian(op)
    if intraorbital_only
        iszero(J) || error("U-only control requires J=0")
        # The reused solver with J=0 includes U'=U. Explicitly remove it.
        for (i,s) in enumerate(op.basis.states), x in (1,3)
            n(a) = Int((s >> (a-1)) & 1) + Int((s >> (a+3)) & 1)
            H[i,i] -= U*n(x)*n(x+1)
        end
        # U(n_up-1/2)(n_down-1/2) differs by a fixed-N constant;
        # use the target's convention even though gaps are unchanged.
        H -= (U*(nu+nd)/2 - U)*I
    end
    @assert maximum(abs, H-H') <= ATOL
    return H, op.basis
end

# Construct S+ between Sz=0 (3,3) and Sz=1 (4,2), using audited Fock signs.
function spin_raise(b0, b1)
    P = zeros(length(b1.states), length(b0.states))
    for (j,s) in enumerate(b0.states), a in 1:4
        q = apply_fermion_ops(s, ((a+4,false),(a,true)))
        q === nothing && continue
        sf,sign = q
        P[b1.indices[sf],j] += sign
    end
    P
end

function splitting(t,U,J,delta; intraorbital_only=false)
    H0,b0 = hamiltonian(t,U,J,delta,3,3; intraorbital_only)
    H1,b1 = hamiltonian(t,U,J,delta,4,2; intraorbital_only)
    P=spin_raise(b0,b1)
    # For Sz=0, S^2 = S- S+. Resolve spin first, including exact degeneracies.
    ss=eigen(Symmetric(P'*P))
    Qs=ss.vectors[:,abs.(ss.values).<ATOL]
    Qt=ss.vectors[:,abs.(ss.values.-2).<ATOL]
    @assert size(Qs,2)+size(Qt,2)==size(H0,1)
    @assert maximum(abs, H0*(P'*P)-(P'*P)*H0) <= ATOL
    Es=minimum(eigvals(Symmetric(Qs'*H0*Qs)))
    Et=minimum(eigvals(Symmetric(Qt'*H0*Qt)))
    @assert isapprox(Et,minimum(eigvals(Symmetric(H1)));atol=ATOL,rtol=0)
    (singlet=Es,triplet=Et,gap=Et-Es,dimension=size(H0,1))
end

function main()
    mkpath(OUTDIR)
    U,delta=4.0,1.0
    rows=[]
    for ratio in (0.0,0.1,0.2,0.25), t in (0.05,0.025,0.0125)
        J=ratio*U
        ex=splitting(t,U,J,delta)
        # Two hopping directions in the isolated quantum two-orbital model.
        # Each S channel has denominator D_T=U-3J+delta or D_S=U-J+delta.
        p2=-2t^2*(1/(U-3J+delta)-1/(U-J+delta))
        e0=6U-10J-4delta
        # At t=0 the low atomic manifold has one half-filled and one full
        # orbital/site. At finite t higher crystal-field configurations also
        # enter, so the second-order expression is not an exact 2x2 solution.
        atomic=splitting(0.0,U,J,delta)
        @assert isapprox(atomic.singlet,e0;atol=ATOL,rtol=0)
        @assert isapprox(atomic.triplet,e0;atol=ATOL,rtol=0)
        @assert ratio==0 ? abs(ex.gap)<=ATOL : ex.gap<0
        push!(rows,(ratio=ratio,J=J,t=t,ex=ex,p2=p2,err=abs(ex.gap-p2)))
    end
    # True perturbative verification: fourth-order residual decreases ~16x
    # when hopping halves; this tests approximation order rather than mirrors code.
    for ratio in (0.1,0.2,0.25)
        r=filter(x->x.ratio==ratio,rows)
        for k in 1:2
            factor=r[k].err/r[k+1].err
            @assert 15.0<factor<17.0
        end
    end
    controls=[(t=t,ex=splitting(t,U,0.0,delta;intraorbital_only=true)) for t in (0.0,0.05,0.1,0.3)]
    @assert all(abs(r.ex.gap)<=ATOL for r in controls)
    open(joinpath(OUTDIR,"hund_exchange.csv"),"w") do io
        println(io,"U,delta,J_over_U,J,t,E_singlet,E_triplet,exact_triplet_minus_singlet,second_order_gap,absolute_residual,sector_dimension")
        for r in rows
            @printf(io,"%.8g,%.8g,%.8g,%.8g,%.8g,%.14g,%.14g,%.14g,%.14g,%.14g,%d\n",U,delta,r.ratio,r.J,r.t,r.ex.singlet,r.ex.triplet,r.ex.gap,r.p2,r.err,r.ex.dimension)
        end
    end
    open(joinpath(OUTDIR,"intraorbital_only_control.csv"),"w") do io
        println(io,"U,delta,t,E_singlet,E_triplet,triplet_minus_singlet")
        for r in controls
            @printf(io,"%.8g,%.8g,%.8g,%.14g,%.14g,%.14g\n",U,delta,r.t,r.ex.singlet,r.ex.triplet,r.ex.gap)
        end
    end
    open(joinpath(OUTDIR,"report.md"),"w") do io
        println(io,"# Half-full hopping exchange benchmark\n")
        println(io,"A two-site, two-orbital, six-electron toy calculation reproduces the Hund-split virtual denominators in Lin et al., PRL127,077204(2021), Eqs7 and11, and Communications Physics6,199(2023), Eqs1–2. It is not their three-orbital material calculation or a calculation of the target altermagnetic phase.\n")
        println(io,"The two-orbital Kanamori interaction uses U'=U-2J and pair hopping J. The separate U-only control explicitly removes U'; simply setting J=0 in this solver would leave the wrong interaction.\n")
        println(io,"With a filled lower orbital and a half-filled upper orbital on each site, the isolated interorbital channels give D_T=U-3J+delta and D_S=U-J+delta. The second-order gap is E_T-E_S=-2t²(1/D_T-1/D_S). Positive J lowers the triplet; J=0 removes this exchange splitting. The factor2 counts both directions of the bond.\n")
        println(io,"Validation passed: real symmetry; [H,S²]=0; S=1 consistency between Sz=0 and1; exact atomic-limit energies; fourth-order convergence of the perturbative residual; degenerate spin channels for the actual intraorbital-U-only control. Float64 roundoff tolerance1e-10 applies to matrices no larger than16×16 and O(10) energies. The perturbative residual is checked separately and is not treated as roundoff.\n")
        println(io,"This establishes the interaction dependence of a local virtual process. It neither rules out nor establishes orbital-compensated altermagnetism from the target's intraorbital U and full lattice hopping. No phase diagram, DMRG, or QMC campaign was run.")
    end
    println("Saved ",length(rows)," Hund points and ",length(controls)," U-only controls to ",OUTDIR)
end
if abspath(PROGRAM_FILE) == @__FILE__
    main()
end
