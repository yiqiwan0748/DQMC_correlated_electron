#!/usr/bin/env julia
# Plot saved data only. No HF solver is loaded or evaluated.
ENV["GKSwstype"] = "100"
using Plots, TOML, SHA, Dates, Printf

const REPO = normpath(joinpath(@__DIR__,"../.."))
const SOURCE_DIR = joinpath(REPO,"results/literature_transfer/alm_hf_thermodynamic_screen_20260911")
const FIGURE_DIR = joinpath(SOURCE_DIR,"figure")
ispath(FIGURE_DIR) && error("Refusing to overwrite existing figure outputs")
mkpath(FIGURE_DIR)

function read_numeric_csv(path)
    lines=readlines(path);header=split(first(lines),',')
    [Dict(String(k)=>String(v) for (k,v) in zip(header,split(line,','))) for line in lines[2:end]]
end

support_path=joinpath(SOURCE_DIR,"supporting_line_validation/supporting_lines.csv")
fixed_path=joinpath(SOURCE_DIR,"supporting_line_validation/fixed_density_comparison.csv")
tangent_path=joinpath(SOURCE_DIR,"refine_Nk384_T0.025/summary.toml")
rows=filter(r->parse(Int,r["nk"])==384 && parse(Float64,r["T"])==.025,read_numeric_csv(support_path))
fixed=only(filter(r->parse(Int,r["nk"])==384 && parse(Float64,r["T"])==.025,read_numeric_csv(fixed_path)))
tangent=TOML.parsefile(tangent_path)
nl=tangent["n_left_FM"];nr=tangent["n_right_AM"]
nstar=parse(Float64,fixed["n"]);gain=parse(Float64,fixed["gain"])
@assert length(rows)==48 && all(parse(Float64,r["excess_F"]) > -3e-9 for r in rows)
@assert nl<nstar<nr && gain>0

# Preserve exactly the original saved ordinates; plotting units are a transparent factor 1000.
open(joinpath(FIGURE_DIR,"alm_hf_common_tangent_source_data.csv"),"w") do io
    println(io,"nk,T,n,kind,F,tangent_F,excess_F,plotted_excess_milli_t1")
    for r in rows
        columns=[r[k] for k in ("nk","T","n","kind","F","tangent_F","excess_F")]
        println(io,join(columns,','),',',@sprintf("%.16g",1000parse(Float64,r["excess_F"])))
    end
end

default(fontfamily="DejaVu Sans",linewidth=2.6,grid=false,framestyle=:box,
    guidefontsize=13,tickfontsize=11,legendfontsize=11,titlefontsize=14)
p=plot(size=(1120,790),dpi=200,xlims=(1.378,1.482),ylims=(-1.0,34.5),
    xlabel="Electron density n (per physical site)",
    ylabel="Free-energy excess  [10^-3 |t1| per site]",
    title="Charge coexistence candidate at the FM-AM crossing\nU/|t1| = 20     T/|t1| = 0.025     momentum grid: 384 x 384\nRestricted uniform Hartree-Fock; not a quantum phase result",
    legend=:top,legend_columns=2,legend_background_color=:white,
    margin=8Plots.mm,top_margin=10Plots.mm,bottom_margin=10Plots.mm)
vspan!(p,[nl,nr],color="#EFF2F5",alpha=.75,label="")
for (kind,color,marker,label) in (("FM","#126C99",:circle,"Uniform ferromagnet"),
                                 ("AM","#C45034",:diamond,"Uniform altermagnet"))
    subset=sort(filter(r->r["kind"]==kind,rows),by=r->parse(Float64,r["n"]))
    ns=[parse(Float64,r["n"]) for r in subset]
    excess=1000 .* [parse(Float64,r["excess_F"]) for r in subset]
    plot!(p,ns,excess,color=color,marker=marker,markersize=3.2,markerstrokewidth=0,
        label=label)
end
# The zero line is the candidate mixture only inside the coexistence interval.
plot!(p,[nl,nr],[0.,0.],color="#17202A",linewidth=3.5,label="")
scatter!(p,[nl,nr],[0.,0.],color=["#126C99","#C45034"],markersize=6,
    markerstrokecolor=:white,markerstrokewidth=1.0,label="")
plot!(p,[nl,nl],[0.,5.1],color="#126C99",linestyle=:dash,linewidth=1.1,label="")
plot!(p,[nr,nr],[0.,5.1],color="#C45034",linestyle=:dash,linewidth=1.1,label="")
annotate!(p,nl,6.0,text("FM endpoint\nn = 1.3947",10,"#126C99",:center))
annotate!(p,nr,6.0,text("AM endpoint\nn = 1.4547",10,"#C45034",:center))
plot!(p,[nstar,nstar],[0.,1000gain],color="#17202A",linewidth=1.8,label="")
scatter!(p,[nstar],[1000gain],color="#17202A",markersize=4,label="")
annotate!(p,nstar,9.2,text("At n = 1.425:\nmixture gain = 0.00385 / site",11,"#17202A",:center))
annotate!(p,(nl+nr)/2,1.05,text("Common tangent / candidate mixture",10,"#17202A",:center))
savefig(p,joinpath(FIGURE_DIR,"alm_hf_common_tangent.png"))
savefig(p,joinpath(FIGURE_DIR,"alm_hf_common_tangent.pdf"))
cp(@__FILE__,joinpath(FIGURE_DIR,"plot_source.jl"))
open(joinpath(FIGURE_DIR,"provenance.toml"),"w") do io
    TOML.print(io,Dict("created_utc"=>string(now(UTC)),"julia"=>string(VERSION),
        "Plots"=>string(pkgversion(Plots)),"nk"=>384,"T"=>.025,"U"=>20,
        "ordinate"=>"1000*(saved uniform F/site - saved common tangent F/site)",
        "line_semantics"=>"Straight segments connect saved points; no new HF evaluations or fitted interpolation",
        "supporting_lines_sha256"=>bytes2hex(sha256(read(support_path))),
        "fixed_density_sha256"=>bytes2hex(sha256(read(fixed_path))),
        "tangent_summary_sha256"=>bytes2hex(sha256(read(tangent_path))),
        "plot_script_sha256"=>bytes2hex(sha256(read(@__FILE__)))))
end
println("Saved figure and its 48-point source table to ",FIGURE_DIR)
