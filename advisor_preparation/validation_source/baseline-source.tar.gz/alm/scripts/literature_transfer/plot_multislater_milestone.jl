#!/usr/bin/env julia
# Static scientific figure from completed, provenance-separated CP summaries.
using Plots, Printf
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const DATA=joinpath(ROOT,"results/literature_transfer/multislater_cp_benchmark")
const OUT=joinpath(ROOT,"results/literature_transfer/multislater_milestone")

function main()
    lines=readlines(joinpath(DATA,"pooled_comparison.csv"))
    header=split(strip(first(lines)),',')
    rows=[Dict(header .=> split(strip(s),',')) for s in lines[2:end] if !isempty(strip(s))]
    profiles=["baseline","dt_half","population","history"]
    labels=["Baseline\ndt=.02, N=128, b=4","Half step\ndt=.01, N=128, b=4",
            "Population\ndt=.02, N=256, b=4","History\ndt=.02, N=128, b=8"]
    num(r,k)=parse(Float64,r[k])
    function panel(q,title,ylabel;subtract_ground=false)
        r=[only(filter(x->x["profile"]==p && x["attempt"]=="initial" && x["quantity"]==q,rows)) for p in profiles]
        all(x->parse(Int,x["seed_count"])==2,r) || error("All registered seeds must finish before plotting")
        ground=num(first(r),"exact_ground");offset=subtract_ground ? ground : 0.
        tolerance=num(first(r),"diagnostic_tolerance")
        p=plot(;title=title,ylabel=ylabel,xticks=(1:4,labels),xlims=(.55,4.45),
            legend=q=="S_alm" ? :topright : :bottomleft)
        q=="S_alm" && ylims!(p,(.86,1.40))
        hspan!(p,[ground-tolerance-offset,ground+tolerance-offset];label="Accuracy band (before 3-SE margin)",
            color=:seagreen,alpha=.12)
        hline!(p,[ground-offset];label="Exact ground",color=:seagreen,linestyle=:dash)
        scatter!(p,(1:4).-0.06,[num(x,"estimate")-offset for x in r];
            yerror=[num(x,"standard_error") for x in r],label="CP, two seeds, ±1 SE",color=:steelblue,
            markersize=5)
        scatter!(p,(1:4).+0.06,[num(x,"exact_same_step_and_time")-offset for x in r];
            label="Exact same step and times",markershape=:rect,markersize=5,
            markercolor=:white,markerstrokecolor=:darkorange,markerstrokewidth=2)
        p
    end
    fig=plot(panel("E","Mixed energy","E - E0";subtract_ground=true),
        panel("bp_E","Back-propagated energy (diagnostic)","BP energy - E0";subtract_ground=true),
        panel("S_alm","Orbital-odd spin correlation","Sodd,z(0) = <O_z²>/4"),
        panel("Delta","Signed orbital-odd moment","Delta = <O_z>/4");
        layout=(2,2),size=(1450,1050),margin=7Plots.mm,guidefontsize=10,
        tickfontsize=8,titlefontsize=12,legendfontsize=8,
        plot_title="20-determinant singlet CP | open 2×2, U=12, Nup=Ndown=3 | warmup 16",
        plot_titlefontsize=14,background_color=:white)
    mkpath(OUT)
    savefig(fig,joinpath(OUT,"multislater_cp_controls.png"))
    savefig(fig,joinpath(OUT,"multislater_cp_controls.pdf"))
    cp(joinpath(DATA,"pooled_comparison.csv"),joinpath(OUT,"figure_data.csv");force=true)
    println("Saved static scientific figure and its complete data to ",OUT)
end
main()
