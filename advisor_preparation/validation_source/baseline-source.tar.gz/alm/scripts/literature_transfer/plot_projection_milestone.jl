#!/usr/bin/env julia
# Static scientific figure: exact trial controls and independently pooled CP data.
using Plots, Printf
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const OUT=joinpath(ROOT,"results/literature_transfer/projection_milestone")

function main()
    lines=readlines(joinpath(OUT,"figure_data.csv"))
    header=split(strip(first(lines)),',')
    rows=[Dict(header .=> split(strip(s),',')) for s in lines[2:end] if !isempty(strip(s))]
    getrows(panel,series=nothing)=filter(r->r["panel"]==panel && (isnothing(series)||r["series"]==series),rows)
    number(r,key)=parse(Float64,r[key])
    overlap=getrows("overlap")
    ys=[number(r,"y") for r in overlap]
    p1=bar(1:4,ys;orientation=:horizontal,yticks=(1:4,[r["label"] for r in overlap]),
        yflip=true,xlims=(0,1.15),ylims=(.5,4.5),legend=false,
        color=[:steelblue,:darkorange,:gray55,:seagreen],linewidth=0,
        xlabel="Squared overlap with exact ground state",title="Exact trial content",grid=:x)
    for (i,y) in enumerate(ys)
        annotate!(p1,y+.02,i,text(@sprintf("%.2f%%",100y),9,:left))
    end

    p2=plot(;yscale=:log10,xlims=(0,33),ylims=(1e-15,2),yticks=[1e-14,1e-10,1e-6,1e-2,1.],
        xlabel="Back-propagation lag b",ylabel="Relative error in Sodd(0)",
        title="Exact limit: right state fully projected",legend=:bottomleft)
    for (series,label,color) in (("AM3","AM3",:steelblue),("restricted_QR26","Restricted singlet",:darkorange))
        r=getrows("exact_lag",series)
        plot!(p2,[number(x,"x") for x in r],[number(x,"y") for x in r];
            label=label,marker=:circle,markersize=3,color=color,linewidth=2)
    end
    hline!(p2,[.05];label="5% target",color=:black,linestyle=:dash,linewidth=1)

    function comparison(panel,ground,tolerance,title,ylabel)
        cp=getrows(panel,"CP");ex=getrows(panel,"Exact same times")
        labels=[replace(replace(replace(replace(r["label"],"am3 "=>"AM3\n"),"qr26 "=>"Singlet\n")," b"=>" / ")," N"=>"\nN=") for r in cp]
        labels=replace.(labels,"w"=>"")
        x=[number(r,"x") for r in cp]
        p=plot(;xticks=(x,labels),xlims=(.5,length(x)+.5),title=title,ylabel=ylabel,
            xlabel="Trial; warmup / history; walker count",legend=:bottomleft)
        hspan!(p,[ground-tolerance,ground+tolerance];color=:seagreen,alpha=.12,
            label="Diagnostic target band")
        hline!(p,[ground];label="Exact ground",color=:seagreen,linestyle=:dash)
        scatter!(p,x.-.07,[number(r,"y") for r in cp];
            yerror=[number(r,"error") for r in cp],label="CP ±1 SE",color=:steelblue,markersize=4)
        scatter!(p,x.+.07,[number(r,"y") for r in ex];label="Exact same times",
            markershape=:rect,markercolor=:white,markerstrokecolor=:darkorange,
            markerstrokewidth=2,markersize=5)
        p
    end
    p3=comparison("cp_S",1.183248801940442,.05*1.183248801940442,"Spin correlation: finite history and CP","Sodd(0)")
    p4=comparison("cp_Delta",0.,.05,"Signed moment: finite history and CP","Delta")
    fig=plot(p1,p2,p3,p4;layout=(2,2),size=(1450,1050),margin=7Plots.mm,
        guidefontsize=10,titlefontsize=12,tickfontsize=9,legendfontsize=8,
        plot_title="Open 2×2 U-only Hubbard benchmark | U=12; Nup=Ndown=3; n=1.5",
        plot_titlefontsize=14,background_color=:white)
    savefig(fig,joinpath(OUT,"trial_and_projection_controls.png"))
    savefig(fig,joinpath(OUT,"trial_and_projection_controls.pdf"))
    println("Saved scientific figure to ",OUT)
end
main()
