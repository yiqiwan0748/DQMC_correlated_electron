#!/usr/bin/env julia
# Scientific summary of two different, explicitly labeled benchmark settings.
using Plots
using Printf

const ROOT=normpath(joinpath(@__DIR__,"../.."))
const OUT=joinpath(ROOT,"results/literature_transfer/stability_milestone")

function read_plain_csv(path)
    lines=readlines(path)
    headers=split(first(lines),',')
    [Dict(headers .=> split(line,',')) for line in lines[2:end] if !isempty(strip(line))]
end

function main()
    hf=read_plain_csv(joinpath(ROOT,"results/literature_transfer/hf_competition/all_candidates.csv"))
    screen=filter(r->r["batch"]=="primary_screen" && r["converged"]=="true",hf)
    baseline=only(r for r in screen if r["label"]=="AM")
    f0=parse(Float64,baseline["F_physical"])
    selected=["AM","FM","random1","random2","stripe_x","Neel","q23pi_odd","PM"]
    names=["Uniform AM","Uniform FM","Modulated A","Modulated B","Stripe","Néel","Finite-q orbital odd","Paramagnetic"]
    energies=[parse(Float64,only(r for r in screen if r["label"]==label)["F_physical"])-f0 for label in selected]
    p1=bar(1:length(selected),energies;orientation=:horizontal,
        yticks=(1:length(selected),names),yflip=true,legend=false,
        xlabel="Free energy minus AM (per site)",
        title="HF screening: U=12, n=52/36, T=0.05\n6×2 cell; common 24×24 momentum grid",
        color=[:steelblue;fill(:gray55,length(selected)-1)],
        linewidth=0,xlims=(0,maximum(energies)*1.18),ylims=(.3,length(selected)+.6),grid=:x)
    for (i,value) in enumerate(energies)
        annotate!(p1,value+.015,i,text(@sprintf("%.3f",value),8,:left))
    end

    ed=read_plain_csv(joinpath(ROOT,"results/literature_transfer/ed_estimator_audit/trial_overlaps.csv"))
    pairs=[("free",0.0),("altermagnetic",.5),("stripe_x",.5),("altermagnetic",3.0),("altermagnetic",6.0)]
    labels=["Free trial","AM field 0.5","Stripe field 0.5","AM field 3","AM field 6"]
    overlap=[parse(Float64,only(r for r in ed if parse(Float64,r["U"])==12 && r["pattern"]==pattern && parse(Float64,r["field"])==field)["squared_ground_subspace_overlap"]) for (pattern,field) in pairs]
    shown=max.(overlap,1e-28)
    p2=scatter(shown,1:length(pairs);yticks=(1:length(pairs),labels),yflip=true,
        xscale=:log10,xlims=(1e-29,1.0),xticks=([1e-28,1e-21,1e-14,1e-7,1.0],["10⁻²⁸","10⁻²¹","10⁻¹⁴","10⁻⁷","1"]),
        xlabel="Squared overlap with exact ground state",
        title="Exact cluster: U=12, n=1.5\nOpen 2×2; N↑=N↓=3",
        color=:steelblue,markersize=6,legend=false,grid=:x,ylims=(.3,length(pairs)+.6))
    for i in eachindex(overlap)
        label=overlap[i]<1e-28 ? "<10⁻²⁸" : @sprintf("%.3f",overlap[i])
        annotate!(p2,shown[i],i-.19,text(label,8,:center))
    end
    figure=plot(p1,p2;layout=(1,2),size=(1300,530),margin=8Plots.mm,
        titlefontsize=10,guidefontsize=10,tickfontsize=9,background_color=:white)
    mkpath(OUT)
    savefig(figure,joinpath(OUT,"stability_and_trial_overlap.png"))
    savefig(figure,joinpath(OUT,"stability_and_trial_overlap.pdf"))
    open(joinpath(OUT,"figure_data.csv"),"w") do io
        println(io,"panel,label,value,displayed_value")
        for (name,e) in zip(names,energies);println(io,"HF,",name,",",e,",",e);end
        for (name,e,s) in zip(labels,overlap,shown);println(io,"ED,",name,",",e,",",s);end
    end
    println("Wrote scientific figure and exact plotting data to ",OUT)
end

main()
