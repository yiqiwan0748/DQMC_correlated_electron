#!/usr/bin/env julia
using Plots

root = normpath(joinpath(@__DIR__, "..", ".."))
out = joinpath(root, "results", "literature_transfer", "target_response")
lines = readlines(joinpath(out, "momentum_response.csv"))
header = split(first(lines), ',')
col(name) = findfirst(==(name), header)
odd, optimum = fill(NaN, 24, 24), fill(NaN, 24, 24)
for line in lines[2:end]
    v = parse.(Float64, split(line, ','))
    v[col("density")] == 1.46021875 || continue
    ix = mod(round(Int, 12v[col("qx_over_pi")]) + 12, 24) + 1
    iy = mod(round(Int, 12v[col("qy_over_pi")]) + 12, 24) + 1
    odd[iy, ix] = v[col("chi_odd")]
    optimum[iy, ix] = 2v[col("chi_largest_orbital_eigenvalue")]
end
@assert all(isfinite, odd) && all(isfinite, optimum)
axis = collect(-12:11) ./ 12
default(fontfamily="sans-serif", titlefontsize=11, guidefontsize=10,
    tickfontsize=9, framestyle=:box, grid=false, background_color=:white)
settings = (; xlabel="qx / π", ylabel="qy / π", aspect_ratio=:equal,
    color=:viridis, clims=(0.10, 0.39), xlims=(-1.05, 1.0), ylims=(-1.05, 1.0),
    xticks=[-1, -0.5, 0, 0.5, 1], yticks=[-1, -0.5, 0, 0.5, 1],
    colorbar_title="response (1/t)")
p1 = heatmap(axis, axis, odd; settings...,
    title="Fixed orbital-odd operator: χodd(q)")
p2 = heatmap(axis, axis, optimum; settings...,
    title="Best orbital-diagonal spin combination: 2λmax(q)")
scatter!(p1, [0.0], [0.0]; marker=:circle, markersize=4, markercolor=:white,
    markerstrokecolor=:black, label=false)
scatter!(p2, [-1.0, 0.0], [0.0, -1.0]; marker=:diamond, markersize=5,
    markercolor=:white, markerstrokecolor=:black, label=false)
p = plot(p1, p2; layout=(1, 2), size=(1100, 490),
    plot_title="Free-fermion baseline | n=1.46021875, T/t=0.05 | 96² k points, 24² q points",
    plot_titlefontsize=12, bottom_margin=6Plots.mm, left_margin=6Plots.mm)
savefig(p, joinpath(out, "orbital_response.png"))
savefig(p, joinpath(out, "orbital_response.pdf"))
println("Saved orbital_response.png and orbital_response.pdf; source data: momentum_response.csv")
