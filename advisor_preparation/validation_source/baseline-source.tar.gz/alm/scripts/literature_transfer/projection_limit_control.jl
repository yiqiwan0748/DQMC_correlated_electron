#!/usr/bin/env julia
"""Hold BP lag fixed and take the right projection to the exact ground state."""
module ProjectionLimitControl
using LinearAlgebra, Serialization, SHA, Test
include(joinpath(@__DIR__,"symmetry_mixture_control.jl"))
const M=SymmetryMixtureControl
const A=M.Audit
const CP=M.CP
const OUT=joinpath(M.ROOT,"results/literature_transfer/projection_limit_control")

function main()
    ispath(OUT) && error("Refusing to replace previous asymptotic-control outputs")
    data=deserialize(M.CACHE)
    E,V,K=data.energies,data.vectors,data.K
    g=V[:,1]; gaps=E.-E[1]
    op=A.ED.sector_hamiltonian(K,12.,3,3)
    o=A.fock_oracle(op.basis).z*repeat([1.,-1.],4)
    exactS=dot(g,(o.^2).*g)/4
    p=CP.CPAFQMCProblem(K,12.,3,3;lattice_size=2,cell_count=4)
    am=CP.one_body_trial(p;pattern=:altermagnetic,field_strength=3.)
    v=A.slater_fock(op.basis,am.up,am.down)
    even=v+M.flip(v); even./=norm(even)
    selected=deserialize(joinpath(M.ROOT,"results/literature_transfer/trial_symmetry_projection/selected_restricted_trial.jls"))
    q=A.slater_fock(op.basis,selected.up,selected.down)
    rows=NamedTuple[]; poles=NamedTuple[]
    checks=@testset "fixed-lag exact projection limit" begin
        for (name,psi) in (("AM3",v),("spin_flip_even_AM3",even),("restricted_QR26",q))
            a=V'psi
            @test abs(a[1])>1e-4
            # With a nondegenerate ground state, this expression follows
            # directly from a spectral expansion of the left propagated bra.
            # Unlike the earlier wrong-symmetry controls, no support cutoff
            # is needed: every trial here has substantial ground overlap.
            Scoeff=(a.*(V'*((o.^2).*g)))/(4a[1])
            Dcoeff=(a.*(V'*(o.*g)))/(4a[1])
            for j in 2:length(E)
                if abs(Scoeff[j])>1e-5 || abs(Dcoeff[j])>1e-5
                    push!(poles,(trial=name,index=j,gap=gaps[j],S_coefficient=Scoeff[j],Delta_coefficient=Dcoeff[j]))
                end
            end
            for b in (0.,2.,4.,8.,12.,16.,24.,32.,48.,64.,96.,128.)
                left=V*(a.*exp.(-b.*gaps))
                den=dot(left,g)
                s=dot(left,(o.^2).*g)/(4den)
                delta=dot(left,o.*g)/(4den)
                @test isapprox(s,dot(Scoeff,exp.(-b.*gaps));atol=2e-9,rtol=0)
                @test isapprox(delta,dot(Dcoeff,exp.(-b.*gaps));atol=2e-9,rtol=0)
                name!="AM3" && (@test abs(delta)<2e-9)
                push!(rows,(trial=name,lag=b,exact_Sodd=s,ground_Sodd=exactS,
                    S_error=s-exactS,exact_Delta=delta,
                    S_within_5_percent=abs(s-exactS)<=.05exactS,
                    Delta_within_0p05=abs(delta)<=.05))
            end
        end
    end
    mkpath(OUT)
    A.write_csv(joinpath(OUT,"fixed_lag_limit.csv"),rows)
    A.write_csv(joinpath(OUT,"correction_poles.csv"),poles)
    open(joinpath(OUT,"validation.txt"),"w") do io
        println(io,"tests=",Test.get_test_counts(checks))
        println(io,"absolute_tolerance=2e-9; accumulated Float64 spectral roundoff")
        println(io,"script_sha256=",bytes2hex(sha256(read(@__FILE__))))
        println(io,"spectrum_sha256=",bytes2hex(sha256(read(M.CACHE))))
        println(io,"This exact continuous-time limit is not a CP convergence claim.")
    end
    println("Saved fixed-lag limits to ",OUT)
end
if abspath(PROGRAM_FILE)==@__FILE__;main();end
end
