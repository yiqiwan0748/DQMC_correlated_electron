#!/usr/bin/env python3
"""Independent consolidation of completed chains; never alters raw records."""
from pathlib import Path
import csv
import hashlib
import json
import math
import statistics as st

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/literature_transfer/projection_milestone'
RUNS = ROOT / 'results/literature_transfer/cp_projection_convergence'
EXACT = ROOT / 'results/literature_transfer/trial_symmetry_projection'
GROUND = {'E': -19.64329885052183, 'S_alm': 1.183248801940442, 'Delta': 0.0}
TOL = {'E': .02, 'S_alm': .05*GROUND['S_alm'], 'Delta': .05}
EXACT_COLUMN = {'E':'exact_mean_mixed_energy', 'S_alm':'exact_mean_BP_S_odd_q0', 'Delta':'exact_mean_BP_Delta'}
LABEL = {'am3':'AM_3.0', 'qr26':'restricted_qr_26'}


def read(path):
    with path.open() as f:
        return list(csv.DictReader(f))


def write(path, rows):
    if not rows:
        return
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def se(values, block):
    assert len(values) % block == 0
    means = [st.mean(values[j:j+block]) for j in range(0,len(values),block)]
    assert len(means) >= 4
    return st.stdev(means)/math.sqrt(len(means))


def main():
    exact = {(r['label'], r['schedule']):r for r in read(EXACT/'exact_schedule_summary.csv')}
    complete, unfinished, blocks, grouped = [], [], [], {}
    for d in sorted(RUNS.iterdir()):
        if not d.is_dir() or not (d/'metadata.txt').exists():
            continue
        status = (d/'status.txt').read_text() if (d/'status.txt').exists() else 'IN_PROGRESS'
        if not status.startswith('COMPLETED'):
            unfinished.append({'run':d.name,'status':status})
            continue
        meta = dict(line.split('=',1) for line in (d/'metadata.txt').read_text().splitlines() if '=' in line)
        rows = read(d/'samples.csv')
        assert len(rows)==int(meta['measurement_count'])==160
        trial = meta['trial'].split(';')[0]
        dt = float(meta['dtau'])
        warm = round(int(meta['warmup_steps'])*dt)
        lag = round(int(meta['back_propagation_steps'])*dt)
        walkers = int(meta['walker_count'])
        seed = int(meta['seed'])
        for j,r in enumerate(rows,1):
            assert abs(float(r['beta'])-(warm+j*.1))<1e-10
        key = (trial,warm,lag,walkers)
        exact_row = exact[(LABEL[trial],f'warm{warm}_b{lag}')]
        entry = {'run':d.name,'trial':trial,'warmup':warm,'lag':lag,'walkers':walkers,'seed':seed,
                 'samples':len(rows),'minimum_ancestors':min(int(r['ancestors']) for r in rows)}
        complete.append(entry)
        for q in GROUND:
            values = [float(r[q]) for r in rows]
            errors = {b:se(values,b) for b in (5,10,20,40)}
            grouped.setdefault((key,q),[]).append((st.mean(values),max(errors.values()),seed,float(exact_row[EXACT_COLUMN[q]])))
            blocks.extend(dict(run=d.name,quantity=q,block_size=b,block_count=len(rows)//b,standard_error=e) for b,e in errors.items())
    pooled = []
    for ((trial,warm,lag,walkers),q), group in sorted(grouped.items()):
        means, errors, seeds, targets = zip(*group)
        assert len(seeds)==len(set(seeds))
        within=math.sqrt(sum(e*e for e in errors))/len(errors)
        between=st.stdev(means)/math.sqrt(len(means)) if len(means)>1 else 0.
        error=max(within,between)
        center=st.mean(means)
        finite=st.mean(targets)
        pooled.append(dict(trial=trial,warmup=warm,lag=lag,walkers=walkers,quantity=q,
            seeds=';'.join(str(s) for s in seeds),seed_count=len(seeds),mean=center,standard_error=error,
            within_seed_error=within,between_seed_error=between,exact_finite_time=finite,
            exact_ground=GROUND[q],finite_time_offset=finite-GROUND[q],
            residual_from_finite_time=center-finite,error_from_ground=center-GROUND[q],
            diagnostic_tolerance=TOL[q],screen_2se=abs(center-GROUND[q])+2*error<=TOL[q],
            screen_3se=abs(center-GROUND[q])+3*error<=TOL[q]))
    write(OUT/'independent_completed_runs.csv',complete)
    write(OUT/'independent_blocking.csv',blocks)
    write(OUT/'independent_comparison.csv',pooled)
    (OUT/'run_accounting.json').write_text(json.dumps(dict(completed=len(complete),unfinished=unfinished,
        total_samples=sum(r['samples'] for r in complete),
        note='Two seeds and four coarsest blocks do not establish asymptotic confidence coverage. Screening is not a production gate.'),indent=2)+'\n')

    figure=[]
    for i,(name,path,label) in enumerate([
        ('AM3',EXACT/'projection_trial_metadata.csv','AM_3.0'),
        ('Restricted singlet',EXACT/'projection_trial_metadata.csv','restricted_qr_26'),
        ('Spin-flip even',EXACT/'projection_trial_metadata.csv','AM_3.0_spinflip_even'),
        ('Full singlet',EXACT/'full_singlet_projector.csv','AM_3.0_full_singlet')],1):
        r=next(r for r in read(path) if r['label']==label)
        figure.append(dict(panel='overlap',series=name,x=i,y=float(r['squared_ground_overlap']),error=0,label=name))
    for r in read(ROOT/'results/literature_transfer/projection_limit_control/fixed_lag_limit.csv'):
        if r['trial'] in ('AM3','restricted_QR26') and float(r['lag'])<=32:
            figure.append(dict(panel='exact_lag',series=r['trial'],x=float(r['lag']),
                y=max(abs(float(r['S_error']))/GROUND['S_alm'],1e-14),error=0,label=r['trial']))
    groups=sorted({(r['trial'],r['warmup'],r['lag'],r['walkers']) for r in pooled})
    for i,g in enumerate(groups,1):
        trial,warm,lag,nw=g
        label=f'{trial} w{warm} b{lag} N{nw}'
        for q,panel in (('S_alm','cp_S'),('Delta','cp_Delta')):
            r=next(r for r in pooled if (r['trial'],r['warmup'],r['lag'],r['walkers'],r['quantity'])==(*g,q))
            figure.append(dict(panel=panel,series='CP',x=i,y=r['mean'],error=r['standard_error'],label=label))
            figure.append(dict(panel=panel,series='Exact same times',x=i,y=r['exact_finite_time'],error=0,label=label))
    write(OUT/'figure_data.csv',figure)
    print(f'Consolidated {len(complete)} completed chains and {len(pooled)} quantity groups; {len(unfinished)} unfinished.')


if __name__=='__main__':
    main()
