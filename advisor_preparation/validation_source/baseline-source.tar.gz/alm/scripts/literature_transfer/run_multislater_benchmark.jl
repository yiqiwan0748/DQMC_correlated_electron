#!/usr/bin/env julia
module RunMultiSlaterBenchmark
using LinearAlgebra, Serialization, SHA, Printf
import AltermagnetDQMCTrial as CP
include(joinpath(@__DIR__,"multislater_cp.jl"))
include(joinpath(@__DIR__,"..","two_orbital_open_cluster_ed.jl"))
const MC=MultiSlaterCP
const ED=TwoOrbitalOpenClusterED
const ROOT=normpath(joinpath(@__DIR__,"../.."))
const OUT=joinpath(ROOT,"results/literature_transfer/multislater_cp_benchmark")
const TRIAL_SOURCE=joinpath(ROOT,"results/literature_transfer/trial_symmetry_projection/full_singlet_am3_20_terms.jls")
const PLAN=joinpath(ROOT,"docs/reading/multislater_milestone_plan.md")
const SOURCES=[@__FILE__,joinpath(@__DIR__,"multislater_cp.jl"),
    joinpath(@__DIR__,"multislater_cp_kernels.jl"),PLAN,TRIAL_SOURCE,
    joinpath(ROOT,"src/constrained_path_afqmc.jl")]
const LOADED_HASHES=Dict(p=>bytes2hex(sha256(read(p))) for p in SOURCES)

csv(x)="\""*replace(string(x),"\""=>"\"\"")*"\""
function write_named(io,row;header=false)
    header && println(io,join(string.(keys(row)),','))
    println(io,join(csv.(values(row)),','));flush(io)
end

function profile(name)
    name=="smoke" && return (dt=.02,nw=32,warm=2.,lag=.5,samples=20,seeds=(41213,))
    name=="baseline" && return (dt=.02,nw=128,warm=16.,lag=4.,samples=160,seeds=(61423,72539))
    name=="dt_half" && return (dt=.01,nw=128,warm=16.,lag=4.,samples=160,seeds=(61423,72539))
    name=="population" && return (dt=.02,nw=256,warm=16.,lag=4.,samples=160,seeds=(61423,72539))
    name=="history" && return (dt=.02,nw=128,warm=16.,lag=8.,samples=160,seeds=(61423,72539))
    error("Unknown registered profile: $name")
end

function run_chain(name,seed;attempt="initial")
    a=profile(name)
    seed in a.seeds || error("Seed outside registered profile")
    out=joinpath(OUT,"$(name)_seed$(seed)_$(attempt)")
    ispath(out) && error("Refusing to overwrite $out")
    mkpath(out)
    pars=CP.CPAFQMCParameters(dtau=a.dt,walker_count=a.nw,
        warmup_steps=round(Int,a.warm/a.dt),measurement_count=a.samples,
        steps_between_measurements=round(Int,.1/a.dt),back_propagation_steps=round(Int,a.lag/a.dt),
        orthogonalize_every=5,population_control_every=5,overlap_refresh_every=16,
        minimum_backprop_ancestors=2,error_block_size=5,seed=seed)
    snapshot=joinpath(out,"source_snapshot");mkpath(snapshot)
    open(joinpath(out,"metadata.txt"),"w") do io
        println(io,"profile=",name);println(io,"attempt=",attempt)
        println(io,"Hamiltonian=centered U-only; U=12; open2x2; Nup=Ndown=3; n=1.5")
        println(io,"trial=full_singlet_AM3_20terms")
        println(io,"initialization=exact_weighted; initial_ket=full_singlet_AM3_20terms")
        println(io,"julia_version=",VERSION)
        for k in fieldnames(typeof(pars));println(io,k,"=",getfield(pars,k));end
        for p in SOURCES
            println(io,"sha256 ",p," ",LOADED_HASHES[p])
            endswith(p,".jls") || cp(p,joinpath(snapshot,basename(p)))
        end
        println(io,"Scientific screen: inherited3SE precision; S5percent; Delta0.05; E0.02. Smoke exempt.")
    end
    rows=NamedTuple[];state=nothing;started=time()
    try
        problem=CP.CPAFQMCProblem(ED.open_cluster_kinetic_matrix(2,2),12.,3,3;lattice_size=2,cell_count=4)
        trial=MC.load_trial(TRIAL_SOURCE;label="full_singlet_AM3_20terms")
        state=MC.initialize(problem,pars;trial=trial,initialization=:exact_weighted)
        open(joinpath(out,"warmup.csv"),"w") do io
            for step in 1:pars.warmup_steps
                MC.step!(state)
                if step%100==0 || step==pars.warmup_steps
                    write_named(io,(step=step,beta=step*a.dt,elapsed_seconds=time()-started);
                        header=position(io)==0)
                end
            end
        end
        serialize(joinpath(out,"warmup_checkpoint.jls"),state)
        open(joinpath(out,"samples.csv"),"w") do io
            for j in 1:pars.measurement_count
                for _ in 1:pars.steps_between_measurements;MC.step!(state);end
                row=MC.measure(state)
                # Journal before acceptance checks: a failed measurement is evidence.
                write_named(io,row;header=j==1)
                for q in (:E,:mixed_K,:mixed_V,:mixed_D,:bp_E,:bp_K,:bp_V,:bp_D,:S_alm,:Delta)
                    isfinite(getproperty(row,q)) || error("Nonfinite measurement $j/$q")
                end
                push!(rows,row)
                if j%20==0
                    @printf("%s seed%d %d/%d E=%.7f S=%.7f Delta=%.7f elapsed=%.1fs\n",
                        name,seed,j,pars.measurement_count,row.E,row.S_alm,row.Delta,time()-started)
                    flush(stdout)
                end
            end
        end
        serialize(joinpath(out,"final_checkpoint.jls"),state)
        # The fixed-N centered-U sum rule independently constrains the double
        # occupancy and interaction numerators. Absolute 2e-8 accommodates
        # accumulated Float64 history roundoff, far below physical targets.
        maximum(abs(r.bp_V-12*(4r.bp_D-1)) for r in rows)<2e-8 ||
            error("Centered-interaction/double-occupancy sum rule failed")
        all(LOADED_HASHES[p]==bytes2hex(sha256(read(p))) for p in SOURCES) ||
            error("Source changed during run; original snapshot retained")
        write(joinpath(out,"status.txt"),"COMPLETED; normalization/source checks passed; scientific accuracy assessed separately\n")
    catch err
        open(joinpath(out,"status.txt"),"w") do io
            println(io,"FAILED; successful prefix and error retained")
            showerror(io,err,catch_backtrace());println(io)
        end
        if !isnothing(state)
            serialize(joinpath(out,"failure_checkpoint.jls"),state)
        end
        rethrow()
    finally
        open(joinpath(out,"completion.txt"),"w") do io
            println(io,"accepted_measurements=",length(rows))
            println(io,"planned_measurements=",a.samples)
            println(io,"run_wall_seconds=",time()-started)
            if !isnothing(state)
                for (k,v) in pairs(MC.diagnostics(state));println(io,k,"=",v);end
            end
        end
    end
    return rows
end

function main(args=ARGS)
    name=isempty(args) ? "smoke" : args[1]
    selected=length(args)>=2 ? (parse(Int,args[2]),) : profile(name).seeds
    attempt=length(args)>=3 ? args[3] : "initial"
    old=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        for seed in selected;run_chain(name,seed;attempt=attempt);end
    finally
        BLAS.set_num_threads(old)
    end
end
if abspath(PROGRAM_FILE)==@__FILE__;main();end
end
