#!/usr/bin/env julia
# Reuse the frozen checkpoint types without modifying or invoking the original
# runner. This file owns only the new, explicitly named matched-cadence arm.
if !isdefined(Main,:RunMultiSlaterBenchmark)
    Base.include(Main,joinpath(@__DIR__,"run_multislater_benchmark.jl"))
end
module RunMultiSlaterMatchedStep
using LinearAlgebra, Serialization, SHA, Printf
import AltermagnetDQMCTrial as CP
const ORIGINAL=Main.RunMultiSlaterBenchmark
const MC=ORIGINAL.MC
const ED=ORIGINAL.ED
const ROOT=ORIGINAL.ROOT
const OUT=ORIGINAL.OUT
const TRIAL_SOURCE=ORIGINAL.TRIAL_SOURCE
const NOTE=joinpath(ROOT,"docs/reading/multislater_matched_step_adaptation.md")
const SOURCES=unique(vcat(ORIGINAL.SOURCES,[@__FILE__,NOTE,
    joinpath(@__DIR__,"../two_orbital_open_cluster_ed.jl")]))
const LOADED_HASHES=Dict(p=>bytes2hex(sha256(read(p))) for p in SOURCES)

function run_chain(seed;attempt="initial")
    seed in (61423,72539) || error("Seed outside the prospective matched-step control")
    name="dt_half_matched"
    out=joinpath(OUT,"$(name)_seed$(seed)_$(attempt)")
    ispath(out) && error("Refusing to overwrite $out")
    mkpath(out)
    pars=CP.CPAFQMCParameters(dtau=.01,walker_count=128,warmup_steps=1600,
        measurement_count=160,steps_between_measurements=10,
        back_propagation_steps=400,orthogonalize_every=10,
        population_control_every=10,overlap_refresh_every=16,
        minimum_backprop_ancestors=2,error_block_size=5,seed=seed)
    snapshot=joinpath(out,"source_snapshot");mkpath(snapshot)
    open(joinpath(out,"metadata.txt"),"w") do io
        println(io,"profile=",name);println(io,"attempt=",attempt)
        println(io,"Hamiltonian=centered U-only; U=12; open2x2; Nup=Ndown=3; n=1.5")
        println(io,"trial=full_singlet_AM3_20terms")
        println(io,"initialization=exact_weighted; initial_ket=full_singlet_AM3_20terms")
        println(io,"adaptation=matched physical resampling and QR cadence; original arms preserved")
        println(io,"julia_version=",VERSION)
        for k in fieldnames(typeof(pars));println(io,k,"=",getfield(pars,k));end
        for p in SOURCES
            println(io,"sha256 ",p," ",LOADED_HASHES[p])
            endswith(p,".jls") || cp(p,joinpath(snapshot,basename(p)))
        end
        println(io,"Scientific screen: inherited3SE precision; S5percent; Delta0.05; E0.02.")
    end
    rows=NamedTuple[];state=nothing;started=time()
    try
        problem=CP.CPAFQMCProblem(ED.open_cluster_kinetic_matrix(2,2),12.,3,3;lattice_size=2,cell_count=4)
        trial=MC.load_trial(TRIAL_SOURCE;label="full_singlet_AM3_20terms")
        state=MC.initialize(problem,pars;trial=trial,initialization=:exact_weighted)
        open(joinpath(out,"warmup.csv"),"w") do io
            for step in 1:pars.warmup_steps
                MC.step!(state)
                if step%100==0 || step==pars.warmup_steps
                    ORIGINAL.write_named(io,(step=step,beta=step*pars.dtau,elapsed_seconds=time()-started);
                        header=position(io)==0)
                end
            end
        end
        serialize(joinpath(out,"warmup_checkpoint.jls"),state)
        open(joinpath(out,"samples.csv"),"w") do io
            for j in 1:pars.measurement_count
                for _ in 1:pars.steps_between_measurements;MC.step!(state);end
                row=MC.measure(state)
                # Persist each result before any finite-value acceptance test.
                ORIGINAL.write_named(io,row;header=j==1)
                for q in (:E,:mixed_K,:mixed_V,:mixed_D,:bp_E,:bp_K,:bp_V,:bp_D,:S_alm,:Delta)
                    isfinite(getproperty(row,q)) || error("Nonfinite measurement $j/$q")
                end
                push!(rows,row)
                if j%20==0
                    @printf("%s seed%d %d/%d E=%.7f S=%.7f Delta=%.7f elapsed=%.1fs\n",
                        name,seed,j,pars.measurement_count,row.E,row.S_alm,row.Delta,time()-started)
                    flush(stdout)
                end
            end
        end
        serialize(joinpath(out,"final_checkpoint.jls"),state)
        # Same absolute accumulated-roundoff tolerance as the original driver.
        maximum(abs(r.bp_V-12*(4r.bp_D-1)) for r in rows)<2e-8 ||
            error("Centered-interaction/double-occupancy sum rule failed")
        all(LOADED_HASHES[p]==bytes2hex(sha256(read(p))) for p in SOURCES) ||
            error("Source changed during run; original snapshot retained")
        write(joinpath(out,"status.txt"),"COMPLETED; normalization/source checks passed; scientific accuracy assessed separately\n")
    catch err
        open(joinpath(out,"status.txt"),"w") do io
            println(io,"FAILED; successful prefix and error retained")
            showerror(io,err,catch_backtrace());println(io)
        end
        !isnothing(state) && serialize(joinpath(out,"failure_checkpoint.jls"),state)
        rethrow()
    finally
        open(joinpath(out,"completion.txt"),"w") do io
            println(io,"accepted_measurements=",length(rows))
            println(io,"planned_measurements=",pars.measurement_count)
            println(io,"run_wall_seconds=",time()-started)
            if !isnothing(state)
                for (k,v) in pairs(MC.diagnostics(state));println(io,k,"=",v);end
            end
        end
    end
    rows
end
function main(args=ARGS)
    seeds=isempty(args) ? (61423,72539) : (parse(Int,args[1]),)
    attempt=length(args)>=2 ? args[2] : "initial"
    old=BLAS.get_num_threads();BLAS.set_num_threads(1)
    try
        for seed in seeds;run_chain(seed;attempt);end
    finally
        BLAS.set_num_threads(old)
    end
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    RunMultiSlaterMatchedStep.main()
end
