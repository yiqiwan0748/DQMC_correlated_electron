#!/usr/bin/env python3
"""Pool completed coherent-trial CP chains and match every exact time slice."""
from pathlib import Path
import csv
import hashlib
import json
import math
import statistics as st

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/literature_transfer/multislater_cp_benchmark'
EXACT=ROOT/'results/literature_transfer/exact_multislater_projection/exact_schedule_controls.csv'
GROUND={'E':-19.64329885052183,'bp_E':-19.64329885052183,'S_alm':1.183248801940442,'Delta':0.}
TOL={'E':.02,'bp_E':.02,'S_alm':.05*GROUND['S_alm'],'Delta':.05}
ECOL={'E':'exact_mixed_energy','bp_E':'exact_BP_energy','S_alm':'exact_BP_S_odd_q0','Delta':'exact_BP_Delta'}

def read(p):
    with p.open() as f: return list(csv.DictReader(f))

def write(name,rows):
    if not rows: return
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def blocking(x):
    values={}
    for b in (5,10,20,40,80):
        if len(x)%b==0 and len(x)//b>=4:
            means=[st.mean(x[i:i+b]) for i in range(0,len(x),b)]
            values[b]=st.stdev(means)/math.sqrt(len(means))
    assert values, 'Insufficient complete blocks'
    return values

def main():
    exact_rows=read(EXACT)
    key=lambda dt,w,b,t:(round(float(dt),10),round(float(w),10),round(float(b),10),round(float(t),10))
    references={key(r['dtau'],r['warmup'],r['bp_lag'],r['beta']):r for r in exact_rows}
    health=[];runs=[];blocks=[];groups={};loaded={}
    for d in sorted(OUT.iterdir()):
        if not d.is_dir() or not (d/'metadata.txt').exists(): continue
        meta=dict(s.split('=',1) for s in (d/'metadata.txt').read_text().splitlines() if '=' in s)
        status=(d/'status.txt').read_text().splitlines()[0] if (d/'status.txt').exists() else 'RUNNING'
        samples=read(d/'samples.csv') if (d/'samples.csv').exists() else []
        health.append(dict(run=d.name,profile=meta['profile'],status=status,
            saved_samples=len(samples),planned=int(meta['measurement_count']),
            minimum_ancestors=min((int(r['ancestors']) for r in samples),default=0)))
        if not status.startswith('COMPLETED') or meta['profile']=='smoke': continue
        dt=float(meta['dtau']);warm=int(meta['warmup_steps'])*dt;lag=int(meta['back_propagation_steps'])*dt
        nw=int(meta['walker_count']);seed=int(meta['seed']);n=int(meta['measurement_count'])
        assert len(samples)==n
        # Distinct implementation versions and explicit attempts are never pooled.
        codehash=hashlib.sha256((d/'source_snapshot/multislater_cp.jl').read_bytes()).hexdigest()
        kernelhash=hashlib.sha256((d/'source_snapshot/multislater_cp_kernels.jl').read_bytes()).hexdigest()
        group=(meta['profile'],meta['attempt'],dt,nw,warm,lag,n,codehash,kernelhash)
        loaded[(group,seed)]=samples
        exact=[]
        for j,r in enumerate(samples,1):
            beta=float(r['beta'])
            assert abs(beta-(warm+j*dt*int(meta['steps_between_measurements'])))<1e-9
            exact.append(references[key(dt,warm,lag,beta)])
        for q in GROUND:
            x=[float(r[q]) for r in samples];assert all(math.isfinite(v) for v in x)
            bs=blocking(x);error=max(bs.values());mean=st.mean(x)
            ex=st.mean(float(r[ECOL[q]]) for r in exact)
            row=dict(run=d.name,profile=meta['profile'],attempt=meta['attempt'],dtau=dt,
                walkers=nw,warmup=warm,bp_lag=lag,samples=n,seed=seed,quantity=q,
                estimate=mean,standard_error=error,exact_same_step_and_time=ex,exact_ground=GROUND[q],
                residual_from_discrete_exact=mean-ex,source_sha256=codehash,kernel_sha256=kernelhash)
            runs.append(row);groups.setdefault((group,q),[]).append(row)
            blocks.extend(dict(run=d.name,quantity=q,block_size=b,block_count=n//b,standard_error=e) for b,e in bs.items())
    pooled=[]
    for (group,q),rr in sorted(groups.items()):
        name,attempt,dt,nw,warm,lag,n,sh,kh=group
        seeds=[r['seed'] for r in rr];assert len(seeds)==len(set(seeds))
        mean=st.mean(r['estimate'] for r in rr)
        within=math.sqrt(sum(r['standard_error']**2 for r in rr))/len(rr)
        between=st.stdev(r['estimate'] for r in rr)/math.sqrt(len(rr)) if len(rr)>1 else 0.
        error=max(within,between);ex=st.mean(r['exact_same_step_and_time'] for r in rr)
        pooled.append(dict(profile=name,attempt=attempt,dtau=dt,walkers=nw,warmup=warm,bp_lag=lag,
            samples_per_seed=n,seeds=';'.join(map(str,seeds)),seed_count=len(seeds),quantity=q,
            estimate=mean,standard_error=error,within_seed_error=within,between_seed_error=between,
            exact_same_step_and_time=ex,exact_ground=GROUND[q],discrete_exact_offset=ex-GROUND[q],
            residual_from_discrete_exact=mean-ex,ground_error=mean-GROUND[q],
            diagnostic_tolerance=TOL[q],screen_3se=abs(mean-GROUND[q])+3*error<=TOL[q],
            source_sha256=sh,kernel_sha256=kh))
    # A history-only change must consume no extra propagation random numbers.
    paired=[];control_pairs={}
    for (g,seed),a in loaded.items():
        if g[0]!='baseline': continue
        for (h,s),b in loaded.items():
            if h[0]!='history' or seed!=s or (g[1:5],g[6:])!=(h[1:5],h[6:]): continue
            assert len(a)==len(b)
            assert max(abs(float(x['E'])-float(y['E'])) for x,y in zip(a,b))<2e-10
            for q in GROUND:
                delta=[float(y[q])-float(x[q]) for x,y in zip(a,b)]
                paired.append(dict(seed=seed,quantity=q,comparison='history_minus_baseline',
                    mean=st.mean(delta),paired_standard_error=max(blocking(delta).values())))
    # All controls share measurement times and registered seed labels. Pair
    # their blocks directly, without assuming independent within-pair noise.
    for (g,seed),a in loaded.items():
        if g[0]!='baseline': continue
        for (h,s),b in loaded.items():
            if h[0] not in ('dt_half','dt_half_matched','population','history') or seed!=s: continue
            if (g[1],g[4],g[6:])!=(h[1],h[4],h[6:]): continue
            assert len(a)==len(b)
            for q in GROUND:
                delta=[float(y[q])-float(x[q]) for x,y in zip(a,b)]
                control_pairs.setdefault((h[0],h[1],q),[]).append(
                    (seed,st.mean(delta),max(blocking(delta).values())))
    controls=[]
    for (name,attempt,q),rr in sorted(control_pairs.items()):
        within=math.sqrt(sum(r[2]**2 for r in rr))/len(rr)
        between=st.stdev(r[1] for r in rr)/math.sqrt(len(rr)) if len(rr)>1 else 0.
        controls.append(dict(comparison=name+'_minus_baseline',attempt=attempt,quantity=q,
            seed_count=len(rr),mean_shift=st.mean(r[1] for r in rr),
            paired_standard_error=max(within,between),within_pair_error=within,
            between_pair_error=between))
    write('measurement_health.csv',health);write('per_run_comparison.csv',runs)
    write('blocking_sensitivity.csv',blocks);write('pooled_comparison.csv',pooled)
    write('paired_history_shifts.csv',paired)
    write('parameter_shifts.csv',controls)
    summary={'recorded_runs':len(health),'completed_runs':sum(r['status'].startswith('COMPLETED') for r in health),
        'scientific_completed_chains':len(runs)//4,'scientific_samples':sum(r['samples'] for r in runs if r['quantity']=='E'),
        'exact_source_sha256':hashlib.sha256(EXACT.read_bytes()).hexdigest(),
        'screening_note':'Three-SE diagnostic precision screen; limited seeds/blocks; no automatic production qualification.',
        'arms':[dict(profile=g[0],attempt=g[1],dtau=g[2],walkers=g[3],warmup=g[4],bp_lag=g[5],samples=g[6]) for g in sorted({g for g,q in groups})]}
    (OUT/'status_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
