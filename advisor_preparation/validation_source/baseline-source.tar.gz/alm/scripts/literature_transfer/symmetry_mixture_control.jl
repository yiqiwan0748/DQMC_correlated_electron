#!/usr/bin/env julia
"""Exact control: incoherent opposite-AM averaging versus coherent projection.

This is a finite-dimensional oracle, not a multideterminant CP implementation.
It consumes the separately generated U=12 spectrum and does not modify it.
"""
module SymmetryMixtureControl

using LinearAlgebra, Serialization, SHA, Test, Printf
import AltermagnetDQMCTrial as CP
include(joinpath(@__DIR__, "ed_estimator_audit.jl"))
const Audit = EDEstimatorAudit
const ROOT = normpath(joinpath(@__DIR__, "../.."))
const OUT = joinpath(ROOT, "results/literature_transfer/symmetry_mixture_control")
const CACHE = joinpath(ROOT, "results/literature_transfer/trial_symmetry_projection/u12_complete_spectrum.jls")
# Dimension 3136 and Float64 eigensystem/projections: allow accumulated
# roundoff well above machine epsilon, well below any scientific tolerance.
const ATOL = 2e-9

# In the documented up-major/down-minor (3,3) basis, a pi rotation about y
# swaps the up/down occupation masks with net sign (-1)^(3+3*3)=+1.
flip(v) = vec(transpose(reshape(v, 56, 56)))

function main()
    ispath(OUT) && error("Refusing to replace previous mixture-control outputs")
    cache = deserialize(CACHE)
    mkpath(OUT)
    E, V, K = cache.energies, cache.vectors, cache.K
    op = Audit.ED.sector_hamiltonian(K, 12.0, 3, 3)
    oracle = Audit.fock_oracle(op.basis)
    o = oracle.z * repeat([1.0,-1.0],4)
    p = CP.CPAFQMCProblem(K,12.0,3,3;lattice_size=2,cell_count=4)
    plus = CP.one_body_trial(p;pattern=:altermagnetic,field_strength=3.0)
    minus = CP.one_body_trial(p;pattern=:altermagnetic,field_strength=-3.0)
    v = Audit.slater_fock(op.basis,plus.up,plus.down); v ./= norm(v)
    independently_minus = Audit.slater_fock(op.basis,minus.up,minus.down)
    fv = flip(v)
    even = (v + fv)/norm(v + fv)
    odd = (v - fv)/norm(v - fv)
    raise = Audit.spin_raise(op.basis,Audit.ED.sector_hamiltonian(K,12.0,4,2).basis)
    c = V'v; ce = V'even; co = V'odd
    gaps = E .- E[1]
    project(a,t) = begin
        z = a .* exp.(-t.*gaps)
        V*(z/norm(z))
    end
    function expectation(a,beta,b)
        left, right = project(a,b), project(a,beta-b)
        den = dot(left,right)
        weighted = abs2.(a).*exp.(-beta.*gaps)
        (energy=dot(weighted,E)/sum(weighted),
         Sodd=dot(left,(o.^2).*right)/(4den),
         Delta=dot(left,o.*right)/(4den))
    end
    rows=NamedTuple[]
    identities=@testset "coherent projection versus incoherent mixture" begin
        @test isapprox(norm(v),1;atol=ATOL,rtol=0)
        @test isapprox(abs(dot(independently_minus,fv)),1;atol=ATOL,rtol=0)
        @test norm(flip(fv)-v)<ATOL
        @test norm(flip(V[:,1])-V[:,1])<ATOL
        @test norm(flip(o.*v)+o.*fv)<ATOL
        @test norm(flip((o.^2).*v)-(o.^2).*fv)<ATOL
        @test norm(op*fv-flip(op*v))<ATOL
        @test norm(flip(even)-even)<ATOL
        @test norm(flip(odd)+odd)<ATOL
        @test abs(dot(even,odd))<ATOL
        @test abs(co[1])<ATOL
        @test abs2(ce[1])>abs2(c[1])
        for beta in (0.0,2.0,8.0,16.0,32.0,64.0,128.0)
            lags = unique([beta/2; filter(b->b<=beta,[4.0,12.0])])
            for b in sort(lags)
                a=expectation(c,beta,b)
                reversed=expectation(V'fv,beta,b)
                e=expectation(ce,beta,b)
                @test isapprox(a.energy,reversed.energy;atol=ATOL,rtol=0)
                @test isapprox(a.Sodd,reversed.Sodd;atol=ATOL,rtol=0)
                @test abs(a.Delta+reversed.Delta)<ATOL
                @test abs(e.Delta)<ATOL
                push!(rows,(total_projection=beta,lag=b,symmetric_insertion=b==beta/2,
                    single_E=a.energy,single_Sodd=a.Sodd,single_Delta=a.Delta,
                    incoherent_E=(a.energy+reversed.energy)/2,
                    incoherent_Sodd=(a.Sodd+reversed.Sodd)/2,
                    incoherent_Delta=(a.Delta+reversed.Delta)/2,
                    coherent_even_E=e.energy,coherent_even_Sodd=e.Sodd,
                    coherent_even_Delta=e.Delta))
            end
        end
    end
    Audit.write_csv(joinpath(OUT,"mixture_vs_coherent.csv"),rows)
    Audit.write_csv(joinpath(OUT,"trial_content.csv"),[
        (trial="single_AM3",ground_weight=abs2(c[1]),spin_squared=norm(raise*v)^2,
         spin_flip_expectation=dot(v,fv)),
        (trial="coherent_spin_flip_even_AM3",ground_weight=abs2(ce[1]),spin_squared=norm(raise*even)^2,
         spin_flip_expectation=dot(even,flip(even))),
        (trial="coherent_spin_flip_odd_AM3",ground_weight=abs2(co[1]),spin_squared=norm(raise*odd)^2,
         spin_flip_expectation=dot(odd,flip(odd)))])
    open(joinpath(OUT,"validation.txt"),"w") do io
        println(io,"tests=",Test.get_test_counts(identities))
        println(io,"absolute_tolerance=",ATOL)
        println(io,"spectrum_sha256=",bytes2hex(sha256(read(CACHE))))
        println(io,"script_sha256=",bytes2hex(sha256(read(@__FILE__))))
        println(io,"Interpretation: spin-flip even permits S=0 and S=2; it is not full singlet projection.")
        println(io,"Interpretation: ensemble symmetry averaging cancels Delta but leaves spin-even Sodd unchanged.")
        println(io,"No CP result or production multideterminant capability is asserted.")
    end
    println("Saved ",length(rows)," exact comparisons to ",OUT)
end

if abspath(PROGRAM_FILE)==@__FILE__;main();end
end
