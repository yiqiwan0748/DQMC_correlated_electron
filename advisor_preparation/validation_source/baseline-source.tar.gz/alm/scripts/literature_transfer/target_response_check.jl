#!/usr/bin/env julia
# Standalone literature-transfer milestone. No production solver is modified.
module LiteratureTargetResponse

using LinearAlgebra
using Test
using Printf

include(joinpath(@__DIR__, "..", "..", "src", "noninteracting.jl"))
include(joinpath(@__DIR__, "..", "..", "src", "realspace_kinetic.jl"))

const TARGET_DENSITY = 1.46021875

fermi(e, mu, beta) = (x = beta * (e - mu); x >= 0 ? exp(-x) / (1 + exp(-x)) : 1 / (1 + exp(x)))
function divided_fermi(e1, e2, mu, beta)
    # The derivative limit avoids cancellation and treats exact degeneracies
    # without dropping their physical intraband/degenerate response.
    if abs(e2 - e1) <= 1e-9
        f = fermi((e1 + e2) / 2, mu, beta)
        return beta * f * (1 - f)
    end
    return (fermi(e1, mu, beta) - fermi(e2, mu, beta)) / (e2 - e1)
end

function make_grid(nk, p=DEFAULT_PARAMETERS)
    energies = zeros(2, nk^2)
    vectors = zeros(2, 2, nk^2)
    for iy in 0:nk-1, ix in 0:nk-1
        kx, ky = 2pi * ix / nk, 2pi * iy / nk
        i = ix + nk * iy + 1
        H = bloch_hamiltonian(kx, ky, p)
        center = (H[1, 1] + H[2, 2]) / 2
        d, b = (H[1, 1] - H[2, 2]) / 2, H[1, 2]
        r = hypot(d, b)
        theta = r == 0 ? 0.0 : atan(b, d) / 2
        s, c = sincos(theta)
        energies[:, i] .= (center - r, center + r)
        vectors[:, :, i] .= [-s c; c s]
    end
    return (; nk, p, energies, vectors)
end

density(g, mu, beta) = 2sum(e -> fermi(e, mu, beta), g.energies) / g.nk^2
function chemical_potential(g, n, beta)
    lo, hi = minimum(g.energies) - 50 / beta, maximum(g.energies) + 50 / beta
    for _ in 1:70
        mid = (lo + hi) / 2
        if density(g, mid, beta) < n
            lo = mid
        else
            hi = mid
        end
    end
    return (lo + hi) / 2
end

"""
Static free-fermion orbital spin susceptibility, per physical cell.
S_alpha^z(q)=sum_k(c†_{k+q,alpha,up}c_{k,alpha,up}
                   -c†_{k+q,alpha,down}c_{k,alpha,down})/2.
chi_ab(q)=N^-1 integral_0^beta <S_a(q,tau) S_b(-q,0)>_c dtau.
Both spin copies give the prefactor 2*(1/2)^2=1/2.
Return even/odd contractions as well as the complete real 2x2 matrix.
"""
function response(g, sx, sy, mu, beta)
    nk, E, V = g.nk, g.energies, g.vectors
    c11 = c22 = c12 = 0.0
    s11 = s22 = s12 = 0.0
    for iy in 0:nk-1, ix in 0:nk-1
        i = ix + nk * iy + 1
        j = mod(ix + sx, nk) + nk * mod(iy + sy, nk) + 1
        for n in 1:2, m in 1:2
            w = divided_fermi(E[n, i], E[m, j], mu, beta)
            a = V[1, m, j] * V[1, n, i]
            b = V[2, m, j] * V[2, n, i]
            c11 += w * a * a
            c22 += w * b * b
            c12 += w * a * b
            # Moreo/Nicholson PRB84 094519 Eq.(24), with spin operator
            # divided by two and the momentum sum normalized per cell.
            equal_weight = fermi(E[n, i], mu, beta) * (1 - fermi(E[m, j], mu, beta))
            s11 += equal_weight * a * a
            s22 += equal_weight * b * b
            s12 += equal_weight * a * b
        end
    end
    norm = 0.5 / nk^2
    c11 *= norm
    c22 *= norm
    c12 *= norm
    s11 *= norm
    s22 *= norm
    s12 *= norm
    even, odd = c11 + c22 + 2c12, c11 + c22 - 2c12
    largest = (c11 + c22) / 2 + hypot((c11 - c22) / 2, c12)
    return (; chi_xx=c11, chi_yy=c22, chi_xy=c12,
              chi_even=even, chi_odd=odd, chi_largest_orbital_eigenvalue=largest,
              equal_time_even=s11+s22+2s12, equal_time_odd=s11+s22-2s12)
end

function uniform_decomposition(g, mu, beta, gamma)
    intra = inter = degenerate = 0.0
    G = gamma == :odd ? [1.0 0; 0 -1] : Matrix{Float64}(I, 2, 2)
    for i in 1:g.nk^2
        W = transpose(g.vectors[:, :, i]) * G * g.vectors[:, :, i]
        for a in 1:2, b in 1:2
            value = divided_fermi(g.energies[a, i], g.energies[b, i], mu, beta) * abs2(W[a, b])
            if abs(g.energies[2, i] - g.energies[1, i]) <= 1e-9
                # At band degeneracy the intra/inter split is gauge dependent.
                # Preserve the entire block as a separate invariant contribution.
                degenerate += value
            elseif a == b
                intra += value
            else
                inter += value
            end
        end
    end
    return (; intra=intra / (2g.nk^2), inter=inter / (2g.nk^2), degenerate=degenerate / (2g.nk^2))
end

# Independent check uses a dense symmetric eigensolver at nonzero field.
# H_s=H0-s*h*Gamma, Delta_Gamma=(1/2N) sum_s s Tr[Gamma f(H_s)].
# Hence chi_Gamma=(1/2)*dDelta_Gamma/dh.
function field_order(g, mu, beta, h, gamma)
    G = gamma == :odd ? [1.0 0; 0 -1] : Matrix{Float64}(I, 2, 2)
    order = 0.0
    for iy in 0:g.nk-1, ix in 0:g.nk-1, spin in (-1, 1)
        H = bloch_hamiltonian(2pi * ix / g.nk, 2pi * iy / g.nk, g.p) - spin * h * G
        e = eigen(Symmetric(H))
        for n in 1:2
            order += spin * dot(e.vectors[:, n], G * e.vectors[:, n]) * fermi(e.values[n], mu, beta)
        end
    end
    return order / (2g.nk^2)
end

function realspace_response_check(L, mu, beta, sx, sy)
    # Independent real-space field perturbation at q=-q (0 or pi).
    # Orbital b is perturbed; both orbital responses a are measured.
    K = realspace_kinetic_matrix(L)
    patterns = zeros(2L^2, 2)
    for i in 1:2L^2
        x, y, a = single_particle_coordinates(i, L)
        patterns[i, a] = cos(2pi * (sx * (x-1) + sy * (y-1)) / L)
    end
    h = 1e-5
    chi = zeros(2, 2)
    for b in 1:2, direction in (-1, 1), spin in (-1, 1)
        e = eigen(Symmetric(K - spin * direction * h * Diagonal(patterns[:, b])))
        occup = abs2.(e.vectors) * fermi.(e.values, mu, beta)
        for a in 1:2
            # order=spin*dot(pattern,occup)/(2N); chi=dorder/dh /2.
            chi[a, b] += direction * spin * dot(patterns[:, a], occup) / (8h * L^2)
        end
    end
    return chi
end

function realspace_equal_time_check(L, mu, beta, sx, sy, gamma)
    K = realspace_kinetic_matrix(L)
    e = eigen(Symmetric(K))
    C = e.vectors * Diagonal(fermi.(e.values, mu, beta)) * transpose(e.vectors)
    eta = [begin
        x, y, a = single_particle_coordinates(i, L)
        sign = gamma == :odd && a == 2 ? -1 : 1
        sign * cos(2pi * (sx * (x-1) + sy * (y-1)) / L)
    end for i in 1:2L^2]
    # Wick covariance including the equal-mode contact term, evaluated
    # independently in real space with no band overlap formula.
    covariance = 0.0
    for i in eachindex(eta), j in eachindex(eta)
        covariance += eta[i] * eta[j] * ((i == j ? C[i, i] : 0.0) - C[i, j] * C[j, i])
    end
    return covariance / (2L^2)
end

function source_analytic_checks()
    max_inequality_violation = 0.0
    for d in range(-2, 2; length=19), b in range(-2, 2; length=17), h in range(0, 2; length=13)
        fm = sort([h + hypot(d, b), h - hypot(d, b), -h + hypot(d, b), -h - hypot(d, b)])
        alm = sort([hypot(d+h, b), -hypot(d+h, b), hypot(d-h, b), -hypot(d-h, b)])
        max_inequality_violation = max(max_inequality_violation, sum(alm[1:2]) - sum(fm[1:2]))
    end
    # A single occupied state at d=0,b=1,h=.5 reverses the comparison.
    one_electron_fm = -1.5
    one_electron_alm = -hypot(1.0, 0.5)

    # For the H0 and diagonal field printed in arXiv v1, d(k) ranges over
    # +/-2|t1-t2|. An interior crossing at h=1.0 is an explicit counterexample
    # to its printed threshold |h|<=|t1-t2|=.75. Do not attribute this to
    # the journal version without inspecting its final supplementary text.
    h = 1.0
    kx = acos(1 - h / abs(DEFAULT_PARAMETERS.t1 - DEFAULT_PARAMETERS.t2))
    H = bloch_hamiltonian(kx, 0.0) - h * [1.0 0; 0 -1]
    gap = diff(eigvals(Symmetric(H)))[1]
    return (; max_inequality_violation, one_electron_fm, one_electron_alm,
        crossing_field=h, crossing_kx=kx, crossing_ky=0.0, crossing_gap=gap,
        printed_preprint_threshold=abs(DEFAULT_PARAMETERS.t1 - DEFAULT_PARAMETERS.t2),
        threshold_from_printed_hamiltonian=2abs(DEFAULT_PARAMETERS.t1 - DEFAULT_PARAMETERS.t2))
end

function validate()
    @testset "Literature transfer: free orbital response and source algebra" begin
        g = make_grid(24)
        beta = 8.0
        mu = chemical_potential(g, TARGET_DENSITY, beta)
        @test isapprox(density(g, mu, beta), TARGET_DENSITY; atol=2e-13, rtol=0)
        # 1e-12 permits floating-point summation over the small grid.
        for i in (1, 7, 49, 167, 455)
            ix, iy = mod(i-1, g.nk), div(i-1, g.nk)
            H = bloch_hamiltonian(2pi*ix/g.nk, 2pi*iy/g.nk)
            @test isapprox(g.vectors[:, :, i] * Diagonal(g.energies[:, i]) * transpose(g.vectors[:, :, i]), H; atol=1e-12, rtol=0)
        end
        r = response(g, 0, 0, mu, beta)
        @test isapprox(r.chi_even, beta * r.equal_time_even; atol=2e-12, rtol=0)
        @test abs(r.chi_odd - beta * r.equal_time_odd) > 0.01
        for gamma in (:even, :odd)
            expected = gamma == :even ? r.chi_even : r.chi_odd
            parts = uniform_decomposition(g, mu, beta, gamma)
            @test isapprox(parts.intra + parts.inter + parts.degenerate, expected; atol=2e-12, rtol=0)
            # h^2 finite-difference truncation dominates eigensolver error.
            h = 1e-5
            fd = (field_order(g, mu, beta, h, gamma) - field_order(g, mu, beta, -h, gamma)) / (4h)
            @test isapprox(fd, expected; atol=2e-8, rtol=2e-7)
        end
        for (sx, sy) in ((0, 0), (6, 0), (12, 0), (8, 12), (12, 12))
            q = response(g, sx, sy, mu, beta)
            qm = response(g, -sx, -sy, mu, beta)
            qc = response(g, -sy, sx, mu, beta)
            @test minimum(eigvals(Symmetric([q.chi_xx q.chi_xy; q.chi_xy q.chi_yy]))) >= -1e-12
            @test isapprox(q.chi_odd, qm.chi_odd; atol=2e-12, rtol=0)
            @test isapprox(q.chi_odd, qc.chi_odd; atol=2e-12, rtol=0)
        end
        small = make_grid(4)
        musmall = chemical_potential(small, TARGET_DENSITY, beta)
        for (sx, sy) in ((0, 0), (2, 0), (2, 2))
            rr = response(small, sx, sy, musmall, beta)
            oracle = realspace_response_check(4, musmall, beta, sx, sy)
            @test isapprox(oracle, [rr.chi_xx rr.chi_xy; rr.chi_xy rr.chi_yy]; atol=2e-8, rtol=2e-7)
            for gamma in (:even, :odd)
                exact_equal = realspace_equal_time_check(4, musmall, beta, sx, sy, gamma)
                band_equal = gamma == :even ? rr.equal_time_even : rr.equal_time_odd
                @test isapprox(exact_equal, band_equal; atol=2e-12, rtol=0)
            end
        end
        # Removing hybridization restores equal even/odd response for two
        # independent C4-related orbital bands; retaining degenerate terms matters.
        decoupled = make_grid(24, ModelParameters(t4=0.0))
        mud = chemical_potential(decoupled, TARGET_DENSITY, beta)
        rd = response(decoupled, 0, 0, mud, beta)
        @test isapprox(rd.chi_even, rd.chi_odd; atol=1e-12, rtol=0)
        @test isapprox(rd.chi_odd, beta * rd.equal_time_odd; atol=1e-12, rtol=0)
        # Completely degenerate orbitals test basis invariance at zero band gap.
        degenerate = make_grid(24, ModelParameters(t1=-1.0, t2=-1.0, t4=0.0))
        mudeg = chemical_potential(degenerate, TARGET_DENSITY, beta)
        rdeg = response(degenerate, 0, 0, mudeg, beta)
        @test isapprox(rdeg.chi_even, rdeg.chi_odd; atol=1e-12, rtol=0)
        degparts = uniform_decomposition(degenerate, mudeg, beta, :odd)
        @test isapprox(degparts.degenerate, rdeg.chi_odd; atol=1e-12, rtol=0)
        @test degparts.intra == degparts.inter == 0.0
        a = source_analytic_checks()
        @test a.max_inequality_violation <= 2e-14
        @test a.one_electron_fm < a.one_electron_alm
        @test a.crossing_field > a.printed_preprint_threshold
        @test abs(a.crossing_gap) <= 2e-14
    end
end

function write_csv(path, rows)
    open(path, "w") do io
        names = propertynames(first(rows))
        println(io, join(string.(names), ","))
        for row in rows
            println(io, join((getproperty(row, name) for name in names), ","))
        end
    end
end

function run(output_dir)
    validate()
    mkpath(output_dir)
    all_rows = NamedTuple[]
    refinements = NamedTuple[]
    decompositions = NamedTuple[]
    # A deterministic 24x24 q mesh on a 96x96 k mesh screens competitors.
    # Finite momentum maxima are mesh samples, not a continuum optimization.
    for n in (1.42, TARGET_DENSITY)
        beta, nk, nq = 20.0, 96, 24
        g = make_grid(nk)
        mu = chemical_potential(g, n, beta)
        local_rows = NamedTuple[]
        for qy in 0:nq-1, qx in 0:nq-1
            r = response(g, qx * div(nk, nq), qy * div(nk, nq), mu, beta)
            row = (; density=n, beta, nk, qx_over_pi=2qx/nq, qy_over_pi=2qy/nq, mu, r...)
            push!(local_rows, row)
            push!(all_rows, row)
        end
        best_odd = local_rows[argmax([r.chi_odd for r in local_rows])]
        best_full = local_rows[argmax([r.chi_largest_orbital_eigenvalue for r in local_rows])]
        println("density=", n, " strongest sampled odd q/pi=", (best_odd.qx_over_pi, best_odd.qy_over_pi), " chi=", best_odd.chi_odd)
        qpoints = unique([(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.5, 0.0), (2/3, 1.0),
            (best_odd.qx_over_pi, best_odd.qy_over_pi), (best_full.qx_over_pi, best_full.qy_over_pi)])
        for fine_nk in (96, 192, 384)
            gf = fine_nk == nk ? g : make_grid(fine_nk)
            muf = chemical_potential(gf, n, beta)
            for (qx, qy) in qpoints
                rr = response(gf, round(Int, qx * fine_nk / 2), round(Int, qy * fine_nk / 2), muf, beta)
                push!(refinements, (; density=n, beta, nk=fine_nk, qx_over_pi=qx, qy_over_pi=qy, mu=muf, rr...))
            end
            for gamma in (:even, :odd)
                parts = uniform_decomposition(gf, muf, beta, gamma)
                push!(decompositions, (; density=n, beta, nk=fine_nk, channel=gamma, mu=muf, parts...))
            end
        end
    end
    write_csv(joinpath(output_dir, "momentum_response.csv"), all_rows)
    write_csv(joinpath(output_dir, "mesh_refinement.csv"), refinements)
    write_csv(joinpath(output_dir, "uniform_intra_inter.csv"), decompositions)
    write_csv(joinpath(output_dir, "source_algebra.csv"), [source_analytic_checks()])
    open(joinpath(output_dir, "metadata.txt"), "w") do io
        println(io, "Target journal: 10.1103/PhysRevB.111.L020401")
        println(io, "Source equations inspected: arXiv:2410.00909v1, main text and Appendices A-E; final journal full text was not accessible during this check.")
        println(io, "Transfer source: Moreo et al. PRB84 094519 (orbital composition versus band nesting); the target response calculation is a derived diagnostic, not a reproduction of its interacting phase diagram.")
        println(io, "t1=-1; t2=-1.75; t3=-0.85; t4=-0.65; orbital order=(dxz,dyz); lattice spacing=1; hbar=1")
        println(io, "U=0; beta=20; densities1.42 and1.46021875; mu separately solved on every k grid; static connected susceptibility per cell")
        println(io, "Spin operator normalization: S^z_alpha=(n_alpha_up-n_alpha_down)/2; odd operator equals target Delta_alm per cell.")
        println(io, "Equal-time structure factors reproduce the Wick/band-overlap formula of Moreo/Nicholson PRB84 094519 Eq.(24), adapted to the target hoppings/filling. They are not beta-integrated susceptibilities.")
        println(io, "No interacting phase, transition temperature, or gRISB reproduction is claimed. Fixed finite beta and a finite q mesh bound the interpretation.")
        println(io, "Julia ", VERSION)
    end
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    output = isempty(ARGS) ? joinpath(@__DIR__, "..", "..", "results", "literature_transfer", "target_response") : ARGS[1]
    LiteratureTargetResponse.run(abspath(output))
end
