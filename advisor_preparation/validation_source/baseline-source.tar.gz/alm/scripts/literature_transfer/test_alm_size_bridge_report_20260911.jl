#!/usr/bin/env julia
# Adverse-input tests use analytic tables only; no ED/DMRG optimization or packages.
using Test,LinearAlgebra,TOML,Serialization,SHA
include("alm_size_bridge_report_20260911.jl")
const Report=ALMSizeBridgeReport20260911
const SEED=314159
const REFHASH="test-reference-artifact-sha256"

function fixture()
    nu=nd=4;C=Matrix(Diagonal(fill(.5,12)));Z=C/3
    ref=(;accepted=true,Lx=3,Ly=2,cells=6,U=20.,N=8,Nup=4,Ndown=4,Sz=0.,
        ground_energy=-32.8,spin_dot=C,total_spin_squared=6.,total_spin=[2.])
    stages=Dict{String,Any}[];spins=Dict{String,Any}[];locals=Dict{String,Any}[]
    for seed in Report.DMRG_SEEDS,stage in 1:5
        cap=Report.DMRG_CAPS[stage]
        push!(stages,Dict("N"=>8,"Nup"=>4,"Ndown"=>4,"Sz"=>0.,"seed"=>seed,"stage"=>stage,"cap"=>cap,
            "energy"=>-32.8,"energy_error"=>0.,"variance"=>0.,"fock_variance"=>0.,"spin_matrix_error"=>0.,
            "spin_squared_error"=>0.,"fidelity"=>1.,"total_spin_squared"=>6.,"S_odd_scalar"=>1.,
            "particle_error"=>0.,"sz_error"=>0.,"energy_action_error"=>0.,"sector_leakage"=>0.,"passed"=>true))
        for p in 1:12,q in 1:12
            push!(spins,Dict("Nup"=>4,"Ndown"=>4,"seed"=>seed,"stage"=>stage,"cap"=>cap,
                "p"=>p,"q"=>q,"spin_dot"=>C[p,q],"SzSz"=>Z[p,q]))
        end
        for p in 1:12
            push!(locals,Dict("Nup"=>4,"Ndown"=>4,"seed"=>seed,"stage"=>stage,"cap"=>cap,
                "mode"=>p,"Nup_local"=>1/3,"Ndown_local"=>1/3,"density"=>2/3,"double_occupancy"=>0.,"Sz_local"=>0.))
        end
    end
    summary=Dict{String,Any}("status"=>"PASS","N"=>8,"Nup"=>4,"Ndown"=>4,"physical_Sz"=>0.,
        "completed_arms"=>2,"completed_stages"=>10,"initialization_agreement_pass"=>true)
    metadata=Dict{String,Any}("reference_sha256"=>REFHASH,"seeds"=>collect(Report.DMRG_SEEDS),"caps"=>collect(Report.DMRG_CAPS[1:4]),
        "energy_tolerance"=>1e-8,"variance_tolerance"=>1e-8,"spin_entry_tolerance"=>1e-6,"particle_Sz_tolerance"=>1e-10)
    (;ref,stages,spins,locals,summary,metadata)
end
finalrow(f)=only(filter(r->r["seed"]==SEED && r["stage"]==5,f.stages))
finalspins(f)=filter(r->r["seed"]==SEED && r["stage"]==5,f.spins)
finallocals(f)=filter(r->r["seed"]==SEED && r["stage"]==5,f.locals)
function evaluate(f;reference=f.ref,reference_usable=true,reference_sha256=REFHASH)
    mktempdir() do dir
        sector=joinpath(dir,"N8_up4_down4");mkpath(sector)
        for (file,rows) in (("stages.csv",f.stages),("spin_matrices.csv",f.spins),("local_observables.csv",f.locals))
            columns=sort!(collect(union((keys(r) for r in rows)...)))
            Report.write_csv(joinpath(sector,file),rows,columns)
        end
        open(io->TOML.print(io,f.summary),joinpath(sector,"summary.toml"),"w")
        open(io->TOML.print(io,f.metadata),joinpath(sector,"metadata.toml"),"w")
        warnings=String[]
        records,probes=Report.dmrg_rows(dir,4,4,reference,warnings;reference_usable,reference_sha256)
        finals=filter(r->isequal(get(r,"stage",missing),5),records)
        (;records,finals,probes,warnings)
    end
end
function assert_rejected(f;kwargs...)
    result=evaluate(f;kwargs...)
    @test !any(r->r["usable"],result.finals)
    @test !any(r->r["status"]=="VALIDATED_DMRG_FINAL",result.probes)
    result
end

@testset "Registered report acceptance from analytic raw tables" begin
    result=evaluate(fixture())
    @test length(result.records)==10
    @test length(result.finals)==2
    @test all(r->r["usable"],result.finals)
    @test all(r->r["raw_comparison_gates_pass"],result.finals)
    @test all(r->r["solver_reported_numeric_gates_pass"],result.finals)
    @test all(r->r["registered_pair_gates_pass"],result.finals)
    @test isempty(result.warnings)
    f=fixture();finalrow(f)["variance"]=-1e-12
    @test all(r->r["usable"],evaluate(f).finals) # Subtraction roundoff is explicitly allowed.
end

@testset "Stored numeric diagnostics cannot be hidden by PASS flags" begin
    for (key,value) in (("energy",-32.7),("energy",NaN),("energy",Inf),("energy",""),
            ("variance",1.01e-8),("variance",-1.01e-8),("variance",NaN),
            ("fock_variance",-1e-14),("fock_variance",Inf),("fock_variance",1.01e-8),
            ("energy_action_error",1.01e-8),("sector_leakage",1.01e-10),
            ("energy_error",-1e-12),("spin_matrix_error",-1e-12),("spin_squared_error",NaN),
            ("particle_error",1.01e-10),("sz_error",1.01e-10))
        f=fixture();finalrow(f)[key]=value;assert_rejected(f)
    end
    f=fixture();delete!(finalrow(f),"fock_variance");assert_rejected(f)
    f=fixture();finalrow(f)["passed"]=false;assert_rejected(f)
end

@testset "Recomputed scalar matrices and local number gates" begin
    # Four off-diagonal changes preserve S2, Sodd, and contact, but violate the entrywise ED gate.
    f=fixture()
    for r in finalspins(f)
        (r["p"],r["q"]) in ((1,3),(3,1)) && (r["spin_dot"]+=2e-6)
        (r["p"],r["q"]) in ((1,5),(5,1)) && (r["spin_dot"]-=2e-6)
    end
    result=assert_rejected(f)
    @test only(filter(r->r["seed"]==SEED,result.finals))["spin_matrix_error_recomputed"]>Report.SPIN_ATOL
    # Every individual entry passes, but their accumulated S2 error does not.
    f=fixture()
    for r in finalspins(f)
        r["p"]==r["q"] && (r["spin_dot"]+=2e-7)
    end
    finalrow(f)["total_spin_squared"]+=12*2e-7;finalrow(f)["S_odd_scalar"]+=2*2e-7
    result=assert_rejected(f)
    bad=only(filter(r->r["seed"]==SEED,result.finals))
    @test bad["spin_matrix_error_recomputed"]<Report.SPIN_ATOL
    @test bad["spin_squared_error_recomputed"]>Report.SPIN_ATOL
    # N is unchanged and local table identities hold; spin-resolved populations fail.
    f=fixture();r=first(finallocals(f));r["Nup_local"]+=1e-8;r["Ndown_local"]-=1e-8;r["Sz_local"]+=1e-8
    result=assert_rejected(f)
    @test only(filter(r->r["seed"]==SEED,result.finals))["particle_error_recomputed"]>Report.NUMBER_ATOL
    f=fixture();first(finallocals(f))["Sz_local"]=1e-8;assert_rejected(f)
    f=fixture();first(finallocals(f))["double_occupancy"]=1e-3;assert_rejected(f)
    f=fixture();first(finallocals(f))["double_occupancy"]=-1e-7;assert_rejected(f)
    f=fixture();first(finallocals(f))["density"]=NaN;assert_rejected(f)
    f=fixture();first(finalspins(f))["spin_dot"]=Inf;assert_rejected(f)
    f=fixture();first(finalspins(f))["p"]=13;assert_rejected(f)
    f=fixture();pop!(f.spins);assert_rejected(f)
    f=fixture();pop!(f.locals);assert_rejected(f)
end

@testset "Registered pair, schedule, and sector provenance" begin
    f=fixture();filter!(r->!(r["seed"]==SEED && r["stage"]==5),f.stages);assert_rejected(f)
    f=fixture();push!(f.stages,deepcopy(finalrow(f)));assert_rejected(f)
    f=fixture();filter!(r->!(r["seed"]==SEED && r["stage"]==1),f.stages);assert_rejected(f)
    f=fixture();finalrow(f)["cap"]=512;assert_rejected(f)
    f=fixture();finalrow(f)["Nup"]=5;assert_rejected(f)
    f=fixture();finalrow(f)["Sz"]=1.;assert_rejected(f)
    f=fixture();first(finalspins(f))["Ndown"]=3;assert_rejected(f)
    f=fixture();first(finallocals(f))["cap"]=512;assert_rejected(f)
    for (key,value) in (("Nup",5),("physical_Sz",1.),("completed_arms",1),("completed_stages",9),
            ("status","FAIL_REGISTERED_GATES"),("initialization_agreement_pass",false))
        f=fixture();f.summary[key]=value;assert_rejected(f)
    end
    for (key,value) in (("reference_sha256","different"),("seeds",[314159,999]),("caps",[128,256,512,2048]),
            ("variance_tolerance",1e-6))
        f=fixture();f.metadata[key]=value;assert_rejected(f)
    end
    f=fixture();empty!(f.metadata);assert_rejected(f)
    assert_rejected(fixture();reference_usable=false)
    f=fixture();assert_rejected(f;reference=merge(f.ref,(Nup=5,)))
    # Rewrite one arm's seed throughout its tables; its otherwise valid numerics cannot qualify it.
    f=fixture()
    for rows in (f.stages,f.spins,f.locals),r in rows
        r["seed"]==SEED && (r["seed"]=123)
    end
    assert_rejected(f)
end

@testset "Between-start agreement uses numerical values" begin
    a=Dict("energy"=>0.,"S2"=>0.);b=copy(a);C=zeros(12,12);D=copy(C)
    @test Report.pair_agreement(a,b,C,D).passed
    b["energy"]=2.01e-8;@test !Report.pair_agreement(a,b,C,D).passed
    b["energy"]=0.;b["S2"]=2.01e-6;@test !Report.pair_agreement(a,b,C,D).passed
    b["S2"]=0.;D[1,2]=2.01e-6;@test !Report.pair_agreement(a,b,C,D).passed
    D[1,2]=NaN;@test !Report.pair_agreement(a,b,C,D).passed
end

@testset "Retrieved completed sectors satisfy strengthened report gates" begin
    base=joinpath(Report.ROOT,"results/literature_transfer/alm_size_bridge_20260911")
    count=0
    for (nu,nd) in Report.SECTORS
        name="N$(nu+nd)_up$(nu)_down$(nd)";dmrg=joinpath(base,"dmrg_attempt01",name)
        isfile(joinpath(dmrg,"summary.toml")) || continue
        get(TOML.parsefile(joinpath(dmrg,"summary.toml")),"status","")=="PASS" || continue
        warnings=String[]
        ed,ref,_=Report.read_ed(joinpath(base,"ed_attempt01"),nu,nd,warnings)
        rows,_=Report.dmrg_rows(joinpath(base,"dmrg_attempt01"),nu,nd,ref,warnings;
            reference_usable=ed["usable"],reference_sha256=ed["reference_sha256"])
        finals=filter(r->isequal(r["stage"],5),rows)
        @test length(finals)==2
        @test all(r->r["usable"],finals)
        @test isempty(warnings)
        count+=1
    end
    @info "Integration fixtures available" completed_sectors=count
end
