#!/usr/bin/env julia
module TrialSymmetryProjection
using LinearAlgebra, Serialization, Random, Test, Printf, SHA
include(joinpath(@__DIR__,"ed_estimator_audit.jl"))
const A=EDEstimatorAudit
const ED=A.ED
const CP=A.CP
const OUT=joinpath(@__DIR__,"..","..","results","literature_transfer","trial_symmetry_projection")
const TOL=2e-9

# Preserve previous output bytes. Deterministic reruns may verify an existing
# table; different data requires a newly named artifact, not an overwrite.
function write_new_csv(path,rows)
    if !isfile(path)
        A.write_csv(path,rows)
    else
        temporary=tempname(OUT)
        try
            A.write_csv(temporary,rows)
            read(temporary)==read(path) || error("Refusing to overwrite differing existing data: $path")
        finally
            isfile(temporary) && rm(temporary)
        end
    end
end

function spectrum()
    mkpath(OUT)
    K=ED.open_cluster_kinetic_matrix(2,2)
    op=ED.sector_hamiltonian(K,12.0,3,3)
    path=joinpath(OUT,"u12_complete_spectrum.jls")
    if isfile(path)
        data=deserialize(path)
        @test data.K==K && data.U==12.0 && data.Nup==3 && data.Ndown==3
        @test data.up_states==op.basis.up_states && data.down_states==op.basis.down_states
        E,V=data.energies,data.vectors
    else
        dec=eigen!(Symmetric(ED.dense_sector_hamiltonian(op)))
        E,V=dec.values,dec.vectors
        serialize(path,(format_version=1,U=12.0,Nup=3,Ndown=3,K=K,
                        energies=E,vectors=V,up_states=op.basis.up_states,
                        down_states=op.basis.down_states))
    end
    @test size(V)==(3136,3136)
    @test E[2]-E[1]>1e-3
    @test norm(op*V[:,1]-E[1]*V[:,1])<TOL
    K,op,E,V
end

function trial_screen(K,op,E,V)
    g=V[:,1]
    Splus=A.spin_raise(op.basis,ED.sector_basis(8,4,2))
    Tx,Mx=A.reflection(op.basis,:mirror_x)
    Ty,My=A.reflection(op.basis,:mirror_y)
    fields=[1.0,-.7,.2,-.4,.9,-.1,-.6,.3]
    rows=[]
    restricted_bound_rows=[]
    candidates=[]
    for lambda in (0.0,.2,.5,1.0,2.0,3.0,6.0)
        dec=eigen(Symmetric(K+Diagonal(lambda.*fields)))
        phi=dec.vectors[:,1:3]
        push!(candidates,(label="restricted_charge_$(lambda)",kind="restricted_charge",parameter=lambda,
                          up=phi,down=phi))
    end
    rng=Xoshiro(18273)
    for i in 1:32
        phi=Matrix(qr(randn(rng,8,3)).Q)[:,1:3]
        push!(candidates,(label="restricted_qr_$(i)",kind="restricted_qr",parameter=Float64(i),up=phi,down=phi))
    end
    problem=CP.CPAFQMCProblem(K,12.,3,3;lattice_size=2,cell_count=4)
    for h in (3.0,6.0)
        trial=CP.one_body_trial(problem;pattern=:altermagnetic,field_strength=h)
        push!(candidates,(label="AM_$(h)",kind="AM",parameter=h,up=trial.up,down=trial.down))
    end
    for candidate in candidates
        psi=A.slater_fock(op.basis,candidate.up,candidate.down)
        @test abs(norm(psi)-1)<TOL
        spin2=sum(abs2,Splus*psi)
        startswith(candidate.kind,"restricted") && (@test spin2<TOL)
        if startswith(candidate.kind,"restricted")
            density=diag(candidate.up*candidate.up')
            doubles=sum(abs2,density)
            kinetic=2tr(candidate.up'*K*candidate.up)
            lower_bound=2sum(eigvals(Symmetric(K))[1:3])+12*(9/8-1)
            @test abs(sum(density)-3)<TOL
            @test doubles>=9/8-TOL
            @test dot(psi,op*psi)>=lower_bound-TOL
            @test abs(dot(psi,op*psi)-(kinetic+12*(doubles-1)))<TOL
            if candidate.label=="restricted_charge_0.0"
                @test maximum(abs,density.-3/8)<TOL
                @test abs(dot(psi,op*psi)-lower_bound)<TOL
            end
            push!(restricted_bound_rows,(label=candidate.label,total_double_occupancy=doubles,
                                         centered_interaction_energy=12*(doubles-1),
                                         kinetic_energy=kinetic,variational_energy=dot(psi,op*psi),
                                         restricted_energy_lower_bound=lower_bound))
        end
        mx=dot(psi,Mx*psi);my=dot(psi,My*psi)
        if startswith(candidate.kind,"restricted")
            @test abs(mx-det(candidate.up'*Tx*candidate.up)^2)<TOL
            @test abs(my-det(candidate.up'*Ty*candidate.up)^2)<TOL
        end
        minusminus=(psi-Mx*psi-My*psi+Mx*(My*psi))/4
        @test abs(sum(abs2,minusminus)-(1-mx-my+dot(psi,Mx*(My*psi)))/4)<TOL
        overlap=abs2(dot(g,psi))
        @test overlap <= sum(abs2,minusminus)+TOL
        row=(label=candidate.label,kind=candidate.kind,parameter=candidate.parameter,
             spin_squared=spin2,Mx_expectation=mx,My_expectation=my,
             odd_odd_weight=sum(abs2,minusminus),squared_ground_overlap=overlap,
             variational_energy=dot(psi,op*psi))
        push!(rows,row)
    end
    write_new_csv(joinpath(OUT,"trial_screen.csv"),rows)
    write_new_csv(joinpath(OUT,"restricted_energy_bound.csv"),restricted_bound_rows)
    sorted=sort(filter(r->startswith(r.kind,"restricted"),rows);by=r->r.squared_ground_overlap,rev=true)
    winner=only(filter(c->c.label==sorted[1].label,candidates))
    trialpath=joinpath(OUT,"selected_restricted_trial.jls")
    if !isfile(trialpath)
        serialize(trialpath,(label=winner.label,up=winner.up,down=winner.down,
                            row=sorted[1],source="Xoshiro(18273); 26th 8x3 randn matrix; thin QR"))
    end
    csvpath=joinpath(OUT,"selected_restricted_trial.csv")
    if !isfile(csvpath)
        open(csvpath,"w") do io
            for i in 1:8
                println(io,join((@sprintf("%.17g",x) for x in vcat(winner.up[i,:],winner.down[i,:])),","))
            end
        end
    end
    println("Best restricted trials: ",sorted[1:5]);flush(stdout)
    candidates,rows
end

spinflip(psi)=vec(copy(transpose(reshape(psi,56,56))))

function export_singlet_terms(op,trial,projected,projection_weight)
    W=hcat(trial.up,trial.down)
    terms=[];rows=[]
    reconstructed=zeros(length(op.basis))
    for a in 1:4, b in a+1:5, c in b+1:6
        I=[a,b,c];J=setdiff(1:6,I)
        r=count(i->i>3,I)
        inversions=sum(j<i for j in J for i in I)
        coefficient=(iseven(r+inversions) ? 1.0 : -1.0)/(4binomial(3,r))
        up,down=W[:,I],W[:,J]
        vector=A.slater_fock(op.basis,up,down)
        reconstructed .+= coefficient.*vector
        push!(terms,(coefficient=coefficient,up=up,down=down,
                     up_source_columns=I,down_source_columns=J))
        for mode in 1:8
            push!(rows,(term=length(terms),coefficient=coefficient,
                        normalized_coefficient=coefficient/sqrt(projection_weight),
                        mode=mode,up1=up[mode,1],up2=up[mode,2],up3=up[mode,3],
                        down1=down[mode,1],down2=down[mode,2],down3=down[mode,3]))
        end
    end
    @test length(terms)==20
    @test norm(reconstructed-projected)<TOL
    @test abs(sum(abs2,reconstructed)-projection_weight)<TOL
    data=(format_version=1,terms=terms,projection_weight=projection_weight,
          normalization=sqrt(projection_weight),normalized_coefficients=false,
          reconstruction_residual=norm(reconstructed-projected),
          convention="Raw nonorthogonal 8x3 up/down matrices. Sum coefficient*Fock(up,down) is P_S0|AM3>, unnormalized. Orbital-fast dxz/dyz site order; up-major/down-minor Fock basis. Divide all coefficients by normalization for unit norm.")
    path=joinpath(OUT,"full_singlet_am3_20_terms.jls")
    if !isfile(path)
        serialize(path,data)
    else
        previous=deserialize(path)
        @test previous.terms==data.terms
        @test previous.projection_weight==data.projection_weight
    end
    write_new_csv(joinpath(OUT,"full_singlet_am3_20_terms.csv"),rows)
    write_new_csv(joinpath(OUT,"full_singlet_am3_20_terms_validation.csv"),
                  [(term_count=length(terms),projection_weight=projection_weight,
                    reconstruction_residual=norm(reconstructed-projected))])
    println("Exported20 exact singlet Slater terms; residual=",norm(reconstructed-projected));flush(stdout)
end

function finite_references(K,op,E,V,candidates,screenrows;only_full_singlet=false)
    Splus=A.spin_raise(op.basis,ED.sector_basis(8,4,2))
    Z=A.fock_oracle(op.basis).z
    oalm=Z*repeat([1.0,-1.0],4)
    Mx=A.reflection(op.basis,:mirror_x)[2]
    My=A.reflection(op.basis,:mirror_y)[2]
    E0=E[1];g=V[:,1]
    test_vector=[sin(.17i)+cos(.73i) for i in eachindex(E)]
    test_vector./=norm(test_vector)
    @test norm(spinflip(spinflip(test_vector))-test_vector)<TOL
    @test norm(op*spinflip(test_vector)-spinflip(op*test_vector))<TOL
    @test norm(spinflip(g)-g)<TOL

    # Resolve total spin inside each degenerate energy block, so accidental
    # eigensolver mixing never turns a triplet into a supposed singlet.
    spinrows=[]
    lowest_singlet_gap=Inf
    first=1
    while first<=64
        last=first
        while last<length(E) && abs(E[last+1]-E[first])<1e-9;last+=1;end
        Q=V[:,first:last]
        R=Splus*Q
        ss=eigen(Symmetric(R'*R))
        for (j,spin2) in enumerate(ss.values)
            S=round(Int,(sqrt(1+4max(0,spin2))-1)/2)
            @test abs(spin2-S*(S+1))<TOL
            if first>1 && S==0
                lowest_singlet_gap=min(lowest_singlet_gap,E[first]-E0)
            end
            push!(spinrows,(energy=E[first],gap=E[first]-E0,spin=S,spin_squared=spin2,
                           degenerate_block_first=first,block_eigenvector=j))
        end
        first=last+1
    end
    @test isfinite(lowest_singlet_gap)
    write_new_csv(joinpath(OUT,"low_energy_spin.csv"),spinrows)
    println("Lowest singlet gap=",lowest_singlet_gap,"; lowest any-spin gap=",E[2]-E0)
    flush(stdout)

    states=[]
    for name in ("AM_3.0","AM_6.0","restricted_qr_26","restricted_charge_2.0")
        trial=only(filter(c->c.label==name,candidates))
        psi=A.slater_fock(op.basis,trial.up,trial.down)
        push!(states,(label=name,kind=trial.kind,psi=psi))
        if trial.kind=="AM"
            even=psi+spinflip(psi)
            even./=norm(even)
            @test norm(spinflip(even)-even)<TOL
            @test abs(dot(even,oalm.*even))<TOL
            push!(states,(label=name*"_spinflip_even",kind="two_determinant_even",psi=even))
        end
        if name=="restricted_charge_2.0"
            csvpath=joinpath(OUT,"restricted_charge_2_trial.csv")
            if !isfile(csvpath)
                open(csvpath,"w") do io
                    for i in 1:8
                        println(io,join((@sprintf("%.17g",x) for x in vcat(trial.up[i,:],trial.down[i,:])),","))
                    end
                end
            end
        end
    end
    prefix=""
    if only_full_singlet
        am3=only(filter(s->s.label=="AM_3.0",states)).psi
        amtrial=only(filter(s->s.label=="AM_3.0",candidates))
        singlet=copy(am3)
        # In N=6,Sz=0, S=0,1,2,3 exhaust the possible total spins.
        # This polynomial acts as identity on S=0 and zero on S=1,2,3.
        for spin in (1,2,3)
            singlet -= (Splus'*(Splus*singlet))/(spin*(spin+1))
        end
        projection_weight=sum(abs2,singlet)
        export_singlet_terms(op,amtrial,singlet,projection_weight)
        singlet./=sqrt(projection_weight)
        @test norm(Splus*singlet)<TOL
        @test norm(spinflip(singlet)-singlet)<TOL
        @test norm(Mx*singlet+singlet)<TOL
        @test norm(My*singlet+singlet)<TOL
        projected_again=copy(singlet)
        for spin in (1,2,3)
            projected_again-=(Splus'*(Splus*projected_again))/(spin*(spin+1))
        end
        @test norm(projected_again-singlet)<TOL
        states=[(label="AM_3.0_full_singlet",kind="full_singlet_projection",psi=singlet)]
        prefix="full_singlet_"
        write_new_csv(joinpath(OUT,"full_singlet_projector.csv"),
            [(label="AM_3.0_full_singlet",projection_weight=projection_weight,
              spin_raising_residual=norm(Splus*singlet),
              projector_idempotence_residual=norm(projected_again-singlet),
              squared_ground_overlap=abs2(dot(g,singlet)),
              variational_energy=dot(singlet,op*singlet))])
    end
    statemeta=[];gridrows=[];schedulerows=[];summaryrows=[];purerows=[]
    schedules=(("warm16_b4",16.1:0.1:32.0,4.0),
               ("warm16_b12",16.1:0.1:32.0,12.0),
               ("warm48_b4",48.1:0.1:64.0,4.0),
               ("warm48_b12",48.1:0.1:64.0,12.0))
    cases=[(beta=beta,b=b) for beta in (8.,16.,32.,48.,64.,96.,128.,256.)
           for b in (0.,2.,4.,8.,12.,16.,24.,32.,48.,64.,128.) if b<=beta]
    pure_times=(0.,2.,4.,8.,16.,24.,32.,48.,64.,96.,128.)
    for state in states
        psi=state.psi
        amplitudes=V'*psi
        @test norm(V*amplitudes-psi)<TOL
        @test abs(norm(amplitudes)-1)<TOL
        @test abs(amplitudes[1])>1e-4 # Every selected state has real GS support.
        is_restricted=startswith(state.kind,"restricted") || state.kind=="full_singlet_projection"
        spin2=sum(abs2,Splus*psi)
        mx=dot(psi,Mx*psi);my=dot(psi,My*psi)
        push!(statemeta,(label=state.label,kind=state.kind,spin_squared=spin2,
                        Mx_expectation=mx,My_expectation=my,
                        spinflip_expectation=dot(psi,spinflip(psi)),
                        squared_ground_overlap=abs2(amplitudes[1]),
                        lowest_singlet_gap=lowest_singlet_gap,lowest_any_spin_gap=E[2]-E0))
        # No overlap cutoff: these states all have independently verified
        # nonzero ground overlap, so tiny excited coefficients decay harmlessly.
        gaps=E.-E0
        times=Float64[0.0]
        append!(times,pure_times)
        for c in cases
            append!(times,(c.b,c.beta-c.b,c.beta/2))
        end
        for (_,betas,b) in schedules, beta in betas
            append!(times,(b,beta-b))
        end
        times=sort(unique(times))
        coefficients=amplitudes.*exp.(-gaps*transpose(times))
        coefficients./=sqrt.(sum(abs2,coefficients;dims=1))
        projected=V*coefficients
        timeindex=Dict(t=>i for (i,t) in enumerate(times))
        getstate(t)=view(projected,:,timeindex[t])
        function mixed_energy(beta)
            w=abs2.(amplitudes).*exp.(-beta.*gaps)
            dot(w,E)/sum(w)
        end
        function bp(beta,b)
            left,right=getstate(b),getstate(beta-b)
            den=dot(left,right)
            @test den>0
            S=dot(left,oalm.^2 .*right)/(4den)
            delta=dot(left,oalm.*right)/(4den)
            if is_restricted || state.kind=="two_determinant_even"
                @test abs(delta)<TOL
            end
            (;S,delta,den)
        end
        for tau in pure_times
            vector=getstate(tau)
            @test abs(norm(vector)-1)<TOL
            energy=dot(vector,op*vector)
            pure_energy=mixed_energy(2tau)
            @test abs(energy-pure_energy)<TOL
            so=dot(abs2.(vector),oalm.^2)/4
            delta=dot(abs2.(vector),oalm)/4
            is_restricted && (@test norm(Splus*vector)<TOL)
            push!(purerows,(label=state.label,tau=tau,energy=energy,
                            S_odd_q0=so,Delta=delta,connected_S_odd_q0=so-4delta^2))
        end
        for c in cases
            r=bp(c.beta,c.b)
            # Hermitian real observables give b <-> beta-b symmetry.
            reverse=bp(c.beta,c.beta-c.b)
            @test abs(r.S-reverse.S)<TOL
            @test abs(r.delta-reverse.delta)<TOL
            if c.b==c.beta/2
                p=getstate(c.beta/2)
                @test abs(r.S-dot(abs2.(p),oalm.^2)/4)<TOL
            end
            push!(gridrows,(label=state.label,beta=c.beta,back_propagation_lag=c.b,
                            exact_mixed_energy=mixed_energy(c.beta),exact_BP_S_odd_q0=r.S,
                            exact_BP_Delta=r.delta))
        end
        for (name,betas,b) in schedules
            energies,Ss,deltas=Float64[],Float64[],Float64[]
            for beta in betas
                r=bp(beta,b);e=mixed_energy(beta)
                push!(energies,e);push!(Ss,r.S);push!(deltas,r.delta)
                push!(schedulerows,(label=state.label,schedule=name,beta=beta,
                                     back_propagation_lag=b,exact_mixed_energy=e,
                                     exact_BP_S_odd_q0=r.S,exact_BP_Delta=r.delta))
            end
            push!(summaryrows,(label=state.label,schedule=name,count=length(betas),
                                exact_mean_mixed_energy=sum(energies)/length(energies),
                                exact_mean_BP_S_odd_q0=sum(Ss)/length(Ss),
                                exact_mean_BP_Delta=sum(deltas)/length(deltas)))
        end
        println("Computed finite projection/BP controls for ",state.label);flush(stdout)
    end
    write_new_csv(joinpath(OUT,prefix*"projection_trial_metadata.csv"),statemeta)
    write_new_csv(joinpath(OUT,prefix*"exact_projection_grid.csv"),gridrows)
    write_new_csv(joinpath(OUT,prefix*"exact_schedule_controls.csv"),schedulerows)
    write_new_csv(joinpath(OUT,prefix*"exact_schedule_summary.csv"),summaryrows)
    write_new_csv(joinpath(OUT,prefix*"exact_pure_projection.csv"),purerows)
    for r in summaryrows
        println(r)
    end
end

function main()
    old=BLAS.get_num_threads();BLAS.set_num_threads(2)
    try
        @testset "Trial symmetry screen" begin
            K,op,E,V=spectrum()
            candidates,rows=trial_screen(K,op,E,V)
            finite_references(K,op,E,V,candidates,rows)
            finite_references(K,op,E,V,candidates,rows;only_full_singlet=true)
        end
    finally
        BLAS.set_num_threads(old)
    end
end
if abspath(PROGRAM_FILE)==@__FILE__;main();end
end
