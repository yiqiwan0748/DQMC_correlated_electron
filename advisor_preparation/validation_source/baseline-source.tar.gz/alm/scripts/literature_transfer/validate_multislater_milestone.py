#!/usr/bin/env python3
"""Audit completion, source provenance and preserved research state."""
from pathlib import Path
import csv
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/literature_transfer/multislater_milestone'
RUNS=ROOT/'results/literature_transfer/multislater_cp_benchmark'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    with p.open() as f: return list(csv.DictReader(f))
def save(name,data): (OUT/name).write_text(json.dumps(data,indent=2)+'\n')

def main():
    baseline=json.loads((OUT/'initial_source_manifest.json').read_text())['files']
    changed=[p for p,h in baseline.items() if not (ROOT/p).exists() or sha(ROOT/p)!=h]
    assert not changed, changed
    save('existing_source_verification.json',dict(files_checked=len(baseline),changed=changed,
        frozen_reference_sha256=sha(ROOT/'reference/square_hubbard.jl')))
    health=[]
    for profile in ('baseline','dt_half','population','history','dt_half_matched'):
        for seed in (61423,72539):
            d=RUNS/f'{profile}_seed{seed}_initial'
            assert (d/'status.txt').read_text().startswith('COMPLETED'),d
            meta=dict(s.split('=',1) for s in (d/'metadata.txt').read_text().splitlines() if '=' in s)
            rows=read(d/'samples.csv');assert len(rows)==int(meta['measurement_count'])==160
            assert all(r['status']=='valid' for r in rows)
            for j,r in enumerate(rows,1):
                assert abs(float(r['beta'])-(16+j*.1))<1e-10
                assert all(math.isfinite(float(r[k])) for k in ('E','bp_E','S_alm','Delta','bp_V','bp_D'))
                assert int(r['ancestors'])>=int(meta['minimum_backprop_ancestors'])
            sum_rule=max(abs(float(r['bp_V'])-12*(4*float(r['bp_D'])-1)) for r in rows)
            assert sum_rule<2e-8
            checked=0
            for line in (d/'metadata.txt').read_text().splitlines():
                if not line.startswith('sha256 '): continue
                name,digest=line[7:].rsplit(' ',1);p=Path(name)
                assert sha(p)==digest,(d,p,'runtime dependency changed')
                if p.suffix!='.jls': assert sha(d/'source_snapshot'/p.name)==digest
                checked+=1
            health.append(dict(run=d.name,samples=len(rows),dependency_hashes_checked=checked,
                minimum_ancestors=min(int(r['ancestors']) for r in rows),
                max_centered_interaction_sum_rule_error=sum_rule))
    replay_health=[]
    for seed in (61423,72539):
        d=ROOT/f'results/literature_transfer/multislater_su2_diagnostic/baseline_seed{seed}'
        assert (d/'validation.txt').read_text().startswith('status=PASS')
        replay=read(d/'samples.csv');original=read(RUNS/f'baseline_seed{seed}_initial/samples.csv')
        assert len(replay)==len(original)==160
        discrepancy=max(abs(float(x[q])-float(y[q])) for x,y in zip(replay,original)
                        for q in ('E','bp_E','S_alm','Delta'))
        assert discrepancy<2e-8
        replay_health.append(dict(seed=seed,samples=160,maximum_original_observable_discrepancy=discrepancy))
    ledger=json.loads((ROOT/'docs/reading/hubbard_altermagnet_transfer_ledger.json').read_text())
    before=json.loads((OUT/'daily_delivery_before.json').read_text())
    after={r['id']:r['daily_delivery_status'] for r in ledger['papers']}
    assert before==after and len(after)==51
    tests=json.loads((OUT/'repository_test_summary.json').read_text())
    assert tests['exit_code']==0 and tests['passed']==tests['total']==42998
    pooled=read(RUNS/'pooled_comparison.csv')
    failed=[dict(profile=r['profile'],quantity=r['quantity']) for r in pooled
            if r['quantity'] in ('S_alm','Delta') and r['screen_3se']=='False']
    save('validation_summary.json',dict(status='PASS for implementation/provenance; scientific screens recorded separately',
        original_scientific_chains=8,added_matched_cadence_chains=2,scientific_measurements=1600,
        smoke_measurements_excluded=20,baseline_replays_are_not_new_independent_chains=True,
        repository_assertions=42998,repository_testsets=84,preexisting_sources_unchanged=len(baseline),
        daily_delivery_flags_preserved=len(after),magnetic_screens_failed=failed,run_health=health,
        baseline_replay_health=replay_health))
    directories=['multislater_milestone','multislater_cp_implementation','multislater_cp_oracle',
        'exact_multislater_projection','actual_multislater_history_audit','multislater_cp_benchmark',
        'cp_population_state_audit','multislater_su2_diagnostic','actual_multislater_su2_audit',
        'exact_multislater_scalar_reference']
    files=set()
    for name in directories:
        d=ROOT/'results/literature_transfer'/name
        if d.exists(): files.update(p for p in d.rglob('*') if p.is_file())
    for p in (ROOT/'scripts/literature_transfer').glob('*'):
        if p.is_file() and str(p.relative_to(ROOT)) not in baseline: files.add(p)
    for pattern in ('*multislater*.md','cp_population_state_audit.md'):
        files.update((ROOT/'docs/reading').glob(pattern))
    files.update(ROOT/'docs/reading'/name for name in ('hubbard_altermagnet_transfer_ledger.json','hubbard_altermagnet_transfer_ledger.md'))
    files.discard(OUT/'artifact_manifest.json')
    save('artifact_manifest.json',dict(files={str(p.relative_to(ROOT)):sha(p) for p in sorted(files)},
        note='Run source snapshots and checkpoint hashes retain provenance. Living ledger may change in later milestones.'))
    print(json.dumps(dict(scientific_chains=len(health),samples=sum(r['samples'] for r in health),
        unchanged_sources=len(baseline),unchanged_delivery_flags=len(after),artifacts=len(files)),indent=2))

if __name__=='__main__':main()
