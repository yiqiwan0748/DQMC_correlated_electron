module MoreoSingletFrontierLanczos20261021

using LinearAlgebra
using Random
using Serialization

export restarted_lowest, read_lanczos_checkpoint

# Twice-modified projection, using level-2 BLAS for the long vectors. All
# retained vectors are reorthogonalized, including already converged roots.
function _orthogonalize!(w, Q, count, coefficients, increment)
    fill!(coefficients, zero(eltype(coefficients)))
    count == 0 && return norm(w)
    basis = @view Q[:, 1:count]
    delta = @view increment[1:count]
    for _ in 1:2
        mul!(delta, adjoint(basis), w)
        @inbounds for i in 1:count
            coefficients[i] += delta[i]
        end
        mul!(w, basis, delta, -one(eltype(w)), one(eltype(w)))
    end
    return norm(w)
end

# Filtering acts on unnormalized directions. A guard reads a normalized
# direction and returns Bool; it must not mutate that direction. Its S²
# action, if any, is counted by the caller separately from original-H calls.
mutable struct DirectionCounters
    filter_calls::Int
    filter_rejections::Int
    normalized_guard_calls::Int
    normalized_guard_rejections::Int
    random_attempts::Int
    replaced_initial_directions::Int
    frontier_attempts::Int
    rejected_frontiers::Int
end
DirectionCounters()=DirectionCounters(0,0,0,0,0,0,0,0)
counter_record(c::DirectionCounters)=(;filter_calls=c.filter_calls,
    filter_rejections=c.filter_rejections,normalized_guard_calls=c.normalized_guard_calls,
    normalized_guard_rejections=c.normalized_guard_rejections,random_attempts=c.random_attempts,
    replaced_initial_directions=c.replaced_initial_directions,
    frontier_attempts=c.frontier_attempts,rejected_frontiers=c.rejected_frontiers)

function _filtered_direction!(w, direction_filter, counters)
    direction_filter === nothing && return all(isfinite,w)
    counters.filter_calls+=1
    accepted=direction_filter(w)
    accepted isa Bool||throw(ArgumentError("direction_filter must return Bool"))
    accepted=accepted&&all(isfinite,w)
    accepted||(counters.filter_rejections+=1)
    accepted
end
function _guard_direction(w, normalized_direction_guard, counters)
    all(isfinite,w)||return false
    normalized_direction_guard===nothing&&return true
    counters.normalized_guard_calls+=1
    accepted=normalized_direction_guard(w)
    accepted isa Bool||throw(ArgumentError("normalized_direction_guard must return Bool"))
    accepted=accepted&&all(isfinite,w)
    accepted||(counters.normalized_guard_rejections+=1)
    accepted
end

function _random_direction!(rng,w,Q,count,coefficients,increment,
        direction_filter,normalized_direction_guard,counters)
    for _ in 1:4
        counters.random_attempts+=1
        randn!(rng,w)
        _filtered_direction!(w,direction_filter,counters)||continue
        magnitude=_orthogonalize!(w,Q,count,coefficients,increment)
        if magnitude>sqrt(eps(real(float(one(eltype(w))))))
            rmul!(w,inv(magnitude))
            _guard_direction(w,normalized_direction_guard,counters)&&return true
        end
    end
    false
end

function _write_checkpoint(path, payload)
    destination = abspath(path)
    mkpath(dirname(destination))
    temporary = destination * ".tmp." * string(rand(UInt64), base=16)
    try
        open(temporary, "w") do io
            serialize(io, payload)
            flush(io)
        end
        mv(temporary, destination; force=true)
    finally
        isfile(temporary) && rm(temporary)
    end
    return nothing
end

"""
    read_lanczos_checkpoint(path)

Read a trusted format3 frontier-filtered checkpoint. The caller must first
pin the file and validate its model/source/runtime. It contains unqualified
Ritz directions, not accepted physical eigenstates or full Krylov history.
"""
function read_lanczos_checkpoint(path::AbstractString)
    payload=open(deserialize,path)
    all(hasproperty(payload,k) for k in (:format_version,:checkpoint_schema,:dimension,
        :scalar_type,:vectors,:values,:configuration,:metadata,:matvecs,:converged))||error("Incomplete frontier checkpoint")
    payload.format_version==3&&payload.checkpoint_schema=="moreo-singlet-frontier-filtered-lanczos-v1"||error("Unexpected frontier checkpoint schema")
    payload.vectors isa AbstractMatrix&&size(payload.vectors,1)==payload.dimension||error("Checkpoint vector dimensions differ")
    payload
end

"""
    restarted_lowest(H; ..., direction_filter=nothing,
                     normalized_direction_guard=nothing)

Isolated derivative of the frozen filtered thick-restart solver. Use plain
original H for the singlet consumer. Initial and random directions are
filtered before orthogonalization, normalized and guarded. Each new Krylov
frontier is orthogonalized, filtered, reorthogonalized, normalized and guarded;
this avoids amplifying spin leakage introduced after an earlier H projection.
The guard reads a normalized vector and must return Bool without mutating it.
Rejected directions are recorded. Random recovery attempts are bounded and
exhaustion never certifies restricted-space completeness.

All supplied-H calls, including direct residual checks for all requested
roots, count against max_matvecs. Filter/guard S² calls are separate caller
work. The solver-owned memory guard includes its arrays; caller vectors,
filter workspace and runtime need their own allocation plan.

Converged requires fresh supplied-H residuals <=atol+rtol*abs(value) for every
root. This remains a solver result, not physical S² acceptance or a ground-
state certificate. The consumer must freshly validate original H, full S²,
norms, Gram matrix and its branch-selection gates before accepting a result.
Checkpoints use format3 and schema moreo-singlet-frontier-filtered-lanczos-v1;
all checkpoint vectors remain unqualified starting directions.
"""
function restarted_lowest(H; nev::Integer=1, krylovdim::Integer=12,
                         keep::Integer=3, max_matvecs::Integer=600,
                         atol::Real=1e-8, rtol::Real=1e-10, seed::Integer=7,
                         max_bytes::Integer=3 * 1024^3,
                         initial_vector=nothing, checkpoint_path=nothing,
                         checkpoint_every::Integer=30,
                         checkpoint_metadata=nothing, progress=nothing, direction_filter=nothing, normalized_direction_guard=nothing)
    n, columns = size(H)
    n == columns && n > 0 || throw(ArgumentError("H must be nonempty and square"))
    1 <= nev <= n || throw(ArgumentError("nev must be between one and dimension"))
    krylovdim >= nev || throw(ArgumentError("krylovdim must be at least nev"))
    keep >= nev || throw(ArgumentError("keep must be at least nev"))
    max_matvecs >= 2nev || throw(ArgumentError("max_matvecs must be at least 2nev"))
    isfinite(atol) && atol >= 0 || throw(ArgumentError("atol must be finite and nonnegative"))
    isfinite(rtol) && rtol >= 0 || throw(ArgumentError("rtol must be finite and nonnegative"))
    atol > 0 || rtol > 0 || throw(ArgumentError("at least one tolerance must be positive"))
    max_bytes > 0 || throw(ArgumentError("max_bytes must be positive"))
    checkpoint_every > 0 || throw(ArgumentError("checkpoint_every must be positive"))
    T = float(eltype(H))
    T <: Union{Float32,Float64,ComplexF32,ComplexF64} || throw(ArgumentError(
        "solver supports Float32/Float64 and corresponding complex arithmetic"))
    R = typeof(real(zero(T)))
    m, block = min(Int(krylovdim), n), Int(nev)
    n > m && m < 2block && throw(ArgumentError(
        "a restarted solve requires krylovdim >= 2nev"))
    retained = n == m ? min(Int(keep), m) : min(Int(keep), m - block)
    capacity = m >= n - block ? n : m + block
    chunk_rows = min(n, 32768)
    # BigInt arithmetic makes the guard safe even for synthetic huge operators.
    estimate = big(sizeof(T)) * (big(n) * (capacity + block + 1) +
        big(chunk_rows) * retained + 12big(capacity)^2) + 1024^2
    estimate <= max_bytes || throw(ArgumentError(
        "estimated solver workspace $estimate bytes exceeds max_bytes=$max_bytes; " *
        "reduce krylovdim/nev or explicitly raise the budget"))
    estimate <= typemax(Int) || throw(ArgumentError("workspace exceeds Int indexing"))
    if initial_vector !== nothing
        initial_vector isa AbstractVecOrMat || throw(ArgumentError(
            "initial_vector must be a vector or matrix"))
        size(initial_vector, 1) == n || throw(ArgumentError("initial_vector has wrong dimension"))
        1 <= size(initial_vector, 2) <= block || throw(ArgumentError(
            "initial_vector must have between one and nev columns"))
        all(isfinite, initial_vector) || throw(ArgumentError("initial_vector must be finite"))
    end

    Q = Matrix{T}(undef, n, capacity)
    w = Vector{T}(undef, n)
    vectors = Matrix{T}(undef, n, block)
    rotation_buffer = Matrix{T}(undef, chunk_rows, retained)
    projected = zeros(T, capacity, capacity)
    coefficients = zeros(T, capacity)
    increment = zeros(T, capacity)
    frontier_coefficients=zeros(T,capacity)
    directions=DirectionCounters()
    rng = MersenneTwister(seed)
    initial_columns = initial_vector === nothing ? 0 : size(initial_vector, 2)
    for j in 1:block
        seeded=false
        if j<=initial_columns
            copyto!(w,@view initial_vector[:,j])
            if _filtered_direction!(w,direction_filter,directions)
                initial_norm=norm(w)
                magnitude=_orthogonalize!(w,Q,j-1,coefficients,increment)
                if isfinite(initial_norm)&&initial_norm>0&&magnitude>64eps(R)*initial_norm
                    rmul!(w,inv(magnitude))
                    seeded=_guard_direction(w,normalized_direction_guard,directions)
                end
            end
            seeded||(directions.replaced_initial_directions+=1)
        end
        if !seeded
            _random_direction!(rng,w,Q,j-1,coefficients,increment,direction_filter,normalized_direction_guard,directions)||
                error("Cannot construct the requested independent validated starting directions")
        end
        copyto!(@view(Q[:,j]),w)
    end

    processed, active, matvecs, restarts = 0, block, 0, 0
    last_checkpoint = 0
    filtered_direction_exhausted = false
    configuration = (; nev=block, krylovdim=m, keep=retained,
        max_matvecs=Int(max_matvecs), atol, rtol, seed, max_bytes=Int(max_bytes),
        direction_filter_applied=direction_filter !== nothing,
        frontier_filter_after_orthogonalization=direction_filter !== nothing,
        normalized_direction_guard_applied=normalized_direction_guard !== nothing)
    while true
        while processed < m && matvecs < max_matvecs - block
            # A happy breakdown means the explored subspace is invariant.
            # Fill unused capacity randomly to expose further eigenspaces.
            if processed == active
                active == n && break
                if !_random_direction!(rng,w,Q,active,coefficients,increment,direction_filter,normalized_direction_guard,directions)
                    # Four failed random directions do not certify a complete
                    # restricted space. They only end this bounded attempt;
                    # returned eigenpairs still require fresh physical gates.
                    filtered_direction_exhausted = true
                    break
                end
                active += 1
                copyto!(@view(Q[:, active]), w)
            end
            j = processed + 1
            mul!(w, H, @view(Q[:, j]))
            matvecs += 1
            image_norm = norm(w)
            isfinite(image_norm) || error("H produced a nonfinite vector")
            magnitude=_orthogonalize!(w,Q,active,coefficients,increment)
            frontier_ready=false
            if active<n&&magnitude>32eps(R)*max(image_norm,one(R))
                directions.frontier_attempts+=1
                if _filtered_direction!(w,direction_filter,directions)
                    # Retain the first orthogonalization coefficients while
                    # projecting the remainder, then accumulate the correction.
                    magnitude=_orthogonalize!(w,Q,active,frontier_coefficients,increment)
                    @inbounds for i in 1:active
                        coefficients[i]+=frontier_coefficients[i]
                    end
                    if magnitude>32eps(R)*max(image_norm,one(R))
                        rmul!(w,inv(magnitude))
                        frontier_ready=_guard_direction(w,normalized_direction_guard,directions)
                    end
                end
                frontier_ready||(directions.rejected_frontiers+=1)
            end
            @inbounds for i in 1:active
                projected[i,j]=coefficients[i]
                projected[j,i]=conj(coefficients[i])
            end
            projected[j,j]=real(projected[j,j])
            if frontier_ready
                active+=1
                copyto!(@view(Q[:,active]),w)
                projected[active,j]=magnitude
                projected[j,active]=magnitude
            end
            processed = j
        end

        processed >= block || error("insufficient operator applications for requested roots")
        eigensystem = eigen(Hermitian(Matrix(@view projected[1:processed, 1:processed])))
        values = eigensystem.values[1:block]
        small_vectors = eigensystem.vectors
        mul!(vectors, @view(Q[:, 1:processed]), @view(small_vectors[:, 1:block]))
        estimates = zeros(R, block)
        for root in 1:block
            # For H*Q = Q*T + Q_frontier*C, the small C matrix gives an
            # inexpensive estimate. Filtering/rejected directions can spoil
            # that recurrence relation numerically; acceptance always measures
            # all supplied original-H residuals directly, never estimates alone.
            estimates[root] = norm(@view(projected[processed + 1:active, 1:processed]) *
                                   @view(small_vectors[:, root]))
        end
        tolerances = atol .+ rtol .* abs.(values)
        exhausted = matvecs >= max_matvecs - block || processed == n || filtered_direction_exhausted
        checked = exhausted || all(estimates .<= tolerances)
        residuals = fill(R(Inf), block)
        if checked
            for root in 1:block
                candidate = @view vectors[:, root]
                candidate_norm = norm(candidate)
                rmul!(candidate, inv(candidate_norm))
                mul!(w, H, candidate)
                matvecs += 1
                axpy!(-values[root], candidate, w)
                residuals[root] = norm(w)
            end
        end
        converged = checked && all(isfinite, residuals) && all(residuals .<= tolerances)
        finished = converged || exhausted || (checked && matvecs >= max_matvecs - block)
        info = (; values=copy(values), residual_estimates=estimates,
            residuals=checked ? copy(residuals) : nothing, matvecs, restarts,
            dimension=n, subspace_dimension=processed, converged, filtered_direction_exhausted,
            direction_counters=counter_record(directions))
        progress === nothing || progress(info)
        if checkpoint_path !== nothing &&
           (finished || matvecs - last_checkpoint >= checkpoint_every)
            _write_checkpoint(checkpoint_path, (; format_version=3, checkpoint_schema="moreo-singlet-frontier-filtered-lanczos-v1", dimension=n,
                scalar_type=string(T), configuration, metadata=checkpoint_metadata,
                values, vectors, residual_estimates=estimates,
                residuals=checked ? residuals : nothing, matvecs, restarts, converged, filtered_direction_exhausted,
                direction_counters=counter_record(directions),checkpoint_vectors_physically_accepted=false,
                restricted_space_completeness_certified=false))
            last_checkpoint = matvecs
        end
        if finished
            return (; values, vectors, residuals, matvecs, converged, restarts,
                estimated_workspace_bytes=Int(estimate), residual_estimates=estimates, filtered_direction_exhausted,
                direction_counters=counter_record(directions),restricted_space_completeness_certified=false)
        end

        # Thick restart. Rotation is local to row chunks, so no N×keep
        # temporary is needed and input columns cannot be overwritten early.
        r = min(retained, processed)
        frontier = active - processed
        coupling = @view(projected[processed + 1:active, 1:processed]) *
                   @view(small_vectors[:, 1:r])
        for first_row in 1:chunk_rows:n
            last_row = min(n, first_row + chunk_rows - 1)
            rows = first_row:last_row
            temporary = @view rotation_buffer[1:length(rows), 1:r]
            mul!(temporary, @view(Q[rows, 1:processed]), @view(small_vectors[:, 1:r]))
            copyto!(@view(Q[rows, 1:r]), temporary)
        end
        for j in 1:frontier
            copyto!(@view(Q[:, r + j]), @view(Q[:, processed + j]))
        end
        fill!(projected, zero(T))
        for j in 1:r
            projected[j, j] = eigensystem.values[j]
            for k in 1:frontier
                projected[r + k, j] = coupling[k, j]
                projected[j, r + k] = conj(coupling[k, j])
            end
        end
        processed, active = r, r + frontier
        restarts += 1
    end
end

end
