module MoreoSingletRestartedLanczos20261014

using LinearAlgebra
using Random
using Serialization

export restarted_lowest, read_lanczos_checkpoint

# Twice-modified projection, using level-2 BLAS for the long vectors. All
# retained vectors are reorthogonalized, including already converged roots.
function _orthogonalize!(w, Q, count, coefficients, increment)
    fill!(coefficients, zero(eltype(coefficients)))
    count == 0 && return norm(w)
    basis = @view Q[:, 1:count]
    delta = @view increment[1:count]
    for _ in 1:2
        mul!(delta, adjoint(basis), w)
        @inbounds for i in 1:count
            coefficients[i] += delta[i]
        end
        mul!(w, basis, delta, -one(eltype(w)), one(eltype(w)))
    end
    return norm(w)
end

# The filter mutates a direction and returns false when its target-sector
# support is absent. It is applied before EVERY seeded/random injection.
function _filtered_direction!(w, direction_filter)
    direction_filter === nothing && return true
    accepted = direction_filter(w)
    accepted isa Bool || throw(ArgumentError("direction_filter must return Bool"))
    accepted && all(isfinite, w) || return false
    true
end

function _random_direction!(rng, w, Q, count, coefficients, increment, direction_filter)
    for _ in 1:4
        randn!(rng, w)
        _filtered_direction!(w, direction_filter) || continue
        magnitude = _orthogonalize!(w, Q, count, coefficients, increment)
        if magnitude > sqrt(eps(real(float(one(eltype(w))))))
            rmul!(w, inv(magnitude))
            return true
        end
    end
    return false
end

function _write_checkpoint(path, payload)
    destination = abspath(path)
    mkpath(dirname(destination))
    temporary = destination * ".tmp." * string(rand(UInt64), base=16)
    try
        open(temporary, "w") do io
            serialize(io, payload)
            flush(io)
        end
        mv(temporary, destination; force=true)
    finally
        isfile(temporary) && rm(temporary)
    end
    return nothing
end

"""
    read_lanczos_checkpoint(path)

Read a locally produced checkpoint. Julia Serialization is intended only for
trusted files. The caller must validate model metadata before reusing `vectors`
as `initial_vector`; this resumes the subspace approximately, not its full
discarded Krylov history. Checkpoints are not portable across all Julia versions.
"""
read_lanczos_checkpoint(path::AbstractString) = open(deserialize, path)

"""
    restarted_lowest(H; nev=1, krylovdim=12, keep=3, max_matvecs=600,
                     atol=1e-8, rtol=1e-10, seed=7, max_bytes=3*1024^3,
                     initial_vector=nothing, checkpoint_path=nothing,
                     checkpoint_every=30, checkpoint_metadata=nothing,
                     progress=nothing)

Memory-limited block thick-restart Lanczos for a real symmetric or complex
Hermitian, matrix-free operator supporting `size`, `eltype`, and `mul!`.
This isolated derivative adds only a direction_filter hook and filtered
happy-breakdown handling. The supplied operator must project every H output.
A projected-operator residual is not a physical eigenstate acceptance test;
the caller must freshly validate original H and full S².

Returns `values`, column `vectors`, directly measured `residuals`, `matvecs`,
`converged`, `restarts`, and `estimated_workspace_bytes`. A result is converged
only when every fresh supplied-operator residual satisfies
`norm(H*v - value*v) <= atol + rtol*abs(value)`.

`direction_filter` is optional, mutates each injected direction and returns a
Bool indicating resolvable target-sector support. This includes every supplied
initial column, random omitted column and random happy-breakdown direction.

The initial block has `nev` independent directions, allowing multiplicities to
be resolved. `initial_vector` may be one vector or a matrix with at most `nev`
columns; omitted columns are random. As with any Krylov method, an invariant
initial subspace may miss lower eigenvalues. Residual convergence certifies the
returned eigenpairs, not the absence of a lower state outside the explored
subspace. Separate seeds or independent physical bounds should establish the
ground-state assignment.

The projected Hamiltonian is kept without a second array of H-applied basis
vectors. At restart `keep` Ritz vectors and up to `nev` frontier directions are
retained; row-block rotation avoids a second full set of Ritz vectors.
`krylovdim` is capped at the operator dimension and `keep` is capped to leave
room for the frontier. For a restarted solve `krylovdim >= 2nev` is required.
The allocation guard covers solver-owned arrays, including returned vectors,
but excludes storage/workspace owned by H, BLAS, the caller, and serialization
runtime overhead. H must not allocate large hidden temporaries in `mul!`.

`max_matvecs` includes independent residual verification and must be at least
`2nev`. No Krylov growth beyond the configured dimension occurs. Nonconvergence
returns `converged=false` and the best current Ritz pairs with measured residuals.
Checkpoints are atomically replaced at restart boundaries after approximately
`checkpoint_every` matvecs, and on return. They contain the current Ritz vectors,
configuration, metadata, and count, not the much larger Krylov basis.
`progress(info)` is called at each candidate evaluation; `info.residuals` is
`nothing` unless original-operator residuals have been measured at that point.
"""
function restarted_lowest(H; nev::Integer=1, krylovdim::Integer=12,
                         keep::Integer=3, max_matvecs::Integer=600,
                         atol::Real=1e-8, rtol::Real=1e-10, seed::Integer=7,
                         max_bytes::Integer=3 * 1024^3,
                         initial_vector=nothing, checkpoint_path=nothing,
                         checkpoint_every::Integer=30,
                         checkpoint_metadata=nothing, progress=nothing, direction_filter=nothing)
    n, columns = size(H)
    n == columns && n > 0 || throw(ArgumentError("H must be nonempty and square"))
    1 <= nev <= n || throw(ArgumentError("nev must be between one and dimension"))
    krylovdim >= nev || throw(ArgumentError("krylovdim must be at least nev"))
    keep >= nev || throw(ArgumentError("keep must be at least nev"))
    max_matvecs >= 2nev || throw(ArgumentError("max_matvecs must be at least 2nev"))
    isfinite(atol) && atol >= 0 || throw(ArgumentError("atol must be finite and nonnegative"))
    isfinite(rtol) && rtol >= 0 || throw(ArgumentError("rtol must be finite and nonnegative"))
    atol > 0 || rtol > 0 || throw(ArgumentError("at least one tolerance must be positive"))
    max_bytes > 0 || throw(ArgumentError("max_bytes must be positive"))
    checkpoint_every > 0 || throw(ArgumentError("checkpoint_every must be positive"))
    T = float(eltype(H))
    T <: Union{Float32,Float64,ComplexF32,ComplexF64} || throw(ArgumentError(
        "solver supports Float32/Float64 and corresponding complex arithmetic"))
    R = typeof(real(zero(T)))
    m, block = min(Int(krylovdim), n), Int(nev)
    n > m && m < 2block && throw(ArgumentError(
        "a restarted solve requires krylovdim >= 2nev"))
    retained = n == m ? min(Int(keep), m) : min(Int(keep), m - block)
    capacity = m >= n - block ? n : m + block
    chunk_rows = min(n, 32768)
    # BigInt arithmetic makes the guard safe even for synthetic huge operators.
    estimate = big(sizeof(T)) * (big(n) * (capacity + block + 1) +
        big(chunk_rows) * retained + 12big(capacity)^2) + 1024^2
    estimate <= max_bytes || throw(ArgumentError(
        "estimated solver workspace $estimate bytes exceeds max_bytes=$max_bytes; " *
        "reduce krylovdim/nev or explicitly raise the budget"))
    estimate <= typemax(Int) || throw(ArgumentError("workspace exceeds Int indexing"))
    if initial_vector !== nothing
        initial_vector isa AbstractVecOrMat || throw(ArgumentError(
            "initial_vector must be a vector or matrix"))
        size(initial_vector, 1) == n || throw(ArgumentError("initial_vector has wrong dimension"))
        1 <= size(initial_vector, 2) <= block || throw(ArgumentError(
            "initial_vector must have between one and nev columns"))
        all(isfinite, initial_vector) || throw(ArgumentError("initial_vector must be finite"))
    end

    Q = Matrix{T}(undef, n, capacity)
    w = Vector{T}(undef, n)
    vectors = Matrix{T}(undef, n, block)
    rotation_buffer = Matrix{T}(undef, chunk_rows, retained)
    projected = zeros(T, capacity, capacity)
    coefficients = zeros(T, capacity)
    increment = zeros(T, capacity)
    rng = MersenneTwister(seed)
    initial_columns = initial_vector === nothing ? 0 : size(initial_vector, 2)
    for j in 1:block
        if j <= initial_columns
            copyto!(w, @view initial_vector[:, j])
            _filtered_direction!(w, direction_filter) || throw(ArgumentError("Initial direction has no target-sector support"))
            initial_norm = norm(w)
            magnitude = _orthogonalize!(w, Q, j - 1, coefficients, increment)
            isfinite(initial_norm) && initial_norm > 0 &&
                magnitude > 64eps(R) * initial_norm || throw(ArgumentError(
                    "initial vectors must be nonzero and numerically linearly independent"))
            rmul!(w, inv(magnitude))
        else
            _random_direction!(rng, w, Q, j - 1, coefficients, increment, direction_filter) ||
                error("could not generate independent starting directions")
        end
        copyto!(@view(Q[:, j]), w)
    end

    processed, active, matvecs, restarts = 0, block, 0, 0
    last_checkpoint = 0
    filtered_direction_exhausted = false
    configuration = (; nev=block, krylovdim=m, keep=retained,
        max_matvecs=Int(max_matvecs), atol, rtol, seed, max_bytes=Int(max_bytes),
        direction_filter_applied=direction_filter !== nothing)
    while true
        while processed < m && matvecs < max_matvecs - block
            # A happy breakdown means the explored subspace is invariant.
            # Fill unused capacity randomly to expose further eigenspaces.
            if processed == active
                active == n && break
                if !_random_direction!(rng, w, Q, active, coefficients, increment, direction_filter)
                    direction_filter === nothing && error("could not generate a direction after Lanczos breakdown")
                    # Four failed random directions do not certify a complete
                    # restricted space. They only end this bounded attempt;
                    # returned eigenpairs still require fresh physical gates.
                    filtered_direction_exhausted = true
                    break
                end
                active += 1
                copyto!(@view(Q[:, active]), w)
            end
            j = processed + 1
            mul!(w, H, @view(Q[:, j]))
            matvecs += 1
            image_norm = norm(w)
            isfinite(image_norm) || error("H produced a nonfinite vector")
            magnitude = _orthogonalize!(w, Q, active, coefficients, increment)
            @inbounds for i in 1:active
                projected[i, j] = coefficients[i]
                projected[j, i] = conj(coefficients[i])
            end
            projected[j, j] = real(projected[j, j])
            if active < n && magnitude > 32eps(R) * max(image_norm, one(R))
                active += 1
                copyto!(@view(Q[:, active]), w)
                rmul!(@view(Q[:, active]), inv(magnitude))
                projected[active, j] = magnitude
                projected[j, active] = magnitude
            end
            processed = j
        end

        processed >= block || error("insufficient operator applications for requested roots")
        eigensystem = eigen(Hermitian(Matrix(@view projected[1:processed, 1:processed])))
        values = eigensystem.values[1:block]
        small_vectors = eigensystem.vectors
        mul!(vectors, @view(Q[:, 1:processed]), @view(small_vectors[:, 1:block]))
        estimates = zeros(R, block)
        for root in 1:block
            # For H*Q = Q*T + Q_frontier*C, the small C matrix gives an
            # inexpensive estimate. The supplied projected operator measures
            # its residual; the caller separately validates original H/S².
            estimates[root] = norm(@view(projected[processed + 1:active, 1:processed]) *
                                   @view(small_vectors[:, root]))
        end
        tolerances = atol .+ rtol .* abs.(values)
        exhausted = matvecs >= max_matvecs - block || processed == n || filtered_direction_exhausted
        checked = exhausted || all(estimates .<= tolerances)
        residuals = fill(R(Inf), block)
        if checked
            for root in 1:block
                candidate = @view vectors[:, root]
                candidate_norm = norm(candidate)
                rmul!(candidate, inv(candidate_norm))
                mul!(w, H, candidate)
                matvecs += 1
                axpy!(-values[root], candidate, w)
                residuals[root] = norm(w)
            end
        end
        converged = checked && all(isfinite, residuals) && all(residuals .<= tolerances)
        finished = converged || exhausted || (checked && matvecs >= max_matvecs - block)
        info = (; values=copy(values), residual_estimates=estimates,
            residuals=checked ? copy(residuals) : nothing, matvecs, restarts,
            dimension=n, subspace_dimension=processed, converged, filtered_direction_exhausted)
        progress === nothing || progress(info)
        if checkpoint_path !== nothing &&
           (finished || matvecs - last_checkpoint >= checkpoint_every)
            _write_checkpoint(checkpoint_path, (; format_version=2, checkpoint_schema="moreo-singlet-filtered-lanczos-v1", dimension=n,
                scalar_type=string(T), configuration, metadata=checkpoint_metadata,
                values, vectors, residual_estimates=estimates,
                residuals=checked ? residuals : nothing, matvecs, restarts, converged, filtered_direction_exhausted))
            last_checkpoint = matvecs
        end
        if finished
            return (; values, vectors, residuals, matvecs, converged, restarts,
                estimated_workspace_bytes=Int(estimate), residual_estimates=estimates, filtered_direction_exhausted)
        end

        # Thick restart. Rotation is local to row chunks, so no N×keep
        # temporary is needed and input columns cannot be overwritten early.
        r = min(retained, processed)
        frontier = active - processed
        coupling = @view(projected[processed + 1:active, 1:processed]) *
                   @view(small_vectors[:, 1:r])
        for first_row in 1:chunk_rows:n
            last_row = min(n, first_row + chunk_rows - 1)
            rows = first_row:last_row
            temporary = @view rotation_buffer[1:length(rows), 1:r]
            mul!(temporary, @view(Q[rows, 1:processed]), @view(small_vectors[:, 1:r]))
            copyto!(@view(Q[rows, 1:r]), temporary)
        end
        for j in 1:frontier
            copyto!(@view(Q[:, r + j]), @view(Q[:, processed + j]))
        end
        fill!(projected, zero(T))
        for j in 1:r
            projected[j, j] = eigensystem.values[j]
            for k in 1:frontier
                projected[r + k, j] = coupling[k, j]
                projected[j, r + k] = conj(coupling[k, j])
            end
        end
        processed, active = r, r + frontier
        restarts += 1
    end
end

end
