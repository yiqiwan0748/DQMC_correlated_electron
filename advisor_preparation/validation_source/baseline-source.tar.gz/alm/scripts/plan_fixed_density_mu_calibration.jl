include(joinpath(@__DIR__, "..", "src", "fixed_density_mu_calibration_planner.jl"))
using .FixedDensityMuCalibrationPlanner

const ROOT = normpath(joinpath(@__DIR__, ".."))
const RUNNER_PATH = joinpath(ROOT, "scripts", "run_dqmc_sign_feasibility.jl")
const RESULT_ROOT = joinpath(ROOT, "results", "dqmc_sign_feasibility")
const DISPLAY_RESULT_ROOT = joinpath("results", "dqmc_sign_feasibility")
const TARGET_DENSITY = 1.46021875
const FIRST_CANDIDATE_SEED = 6117
const MAXIMUM_NEW_EVALUATIONS = 6
const BRACKET_WIDTH_TOLERANCE = 0.001
const BASELINE_ENDPOINTS = Set([
    ("calibrate_target_mu_m2p55", 6116),
    ("calibrate_target_mu_m2p497", 6111),
])

function _parse_csv_line(line::AbstractString)
    fields = String[]
    current = Char[]
    quoted = false
    characters = collect(line)
    index = 1
    while index <= length(characters)
        character = characters[index]
        if character == '"'
            if quoted && index < length(characters) &&
               characters[index + 1] == '"'
                push!(current, '"')
                index += 1
            else
                quoted = !quoted
            end
        elseif character == ',' && !quoted
            push!(fields, String(current))
            empty!(current)
        else
            push!(current, character)
        end
        index += 1
    end
    quoted && error("unterminated quoted CSV field")
    push!(fields, String(current))
    return fields
end

function _read_single_record_csv(path)
    lines = readlines(path)
    length(lines) == 2 || error("$path must contain one header and one data row")
    header = _parse_csv_line(lines[1])
    values = _parse_csv_line(lines[2])
    length(values) == length(header) ||
        error("$path has a CSV field-count mismatch")
    length(unique(header)) == length(header) ||
        error("$path has duplicate CSV column names")
    return (header=header, row=Dict(zip(header, values)))
end

function _required(row, name, source)
    haskey(row, name) || error("$source is missing required field $name")
    return row[name]
end

function _parse_bool(text, label)
    text == "true" && return true
    text == "false" && return false
    error("$label must be true or false, found '$text'")
end

function _runner_constant(source, name)
    match_value = match(
        Regex("(?m)^const\\s+$(name)\\s*=\\s*([^\\n]+)\\s*\$"),
        source,
    )
    isnothing(match_value) && error("runner constant $name was not found")
    return strip(only(match_value.captures))
end

function _assignment(body, name; required=true)
    match_value = match(
        Regex("\\b$(name)\\s*=\\s*([^,\\n\\)]+)"),
        body,
    )
    if isnothing(match_value)
        required && error("configured case is missing assignment $name")
        return nothing
    end
    return strip(only(match_value.captures))
end

function _numeric_expression(expression, constants)
    value = get(constants, expression, expression)
    return parse(Float64, value)
end

function _integer_expression(expression, constants)
    value = get(constants, expression, expression)
    return parse(Int, value)
end

function _parse_configured_cases(path)
    source = read(path, String)
    constants = Dict(
        "TARGET_MU" => _runner_constant(source, "TARGET_MU"),
        "TARGET_FILLING" => _runner_constant(source, "TARGET_FILLING"),
    )
    dtau_match = match(r"(?m)^\s+dtau\s*=\s*([^,\n]+),\s*$", source)
    stabilization_match = match(
        r"(?m)^\s+stabilization_period\s*=\s*([^,\n]+),\s*$",
        source,
    )
    isnothing(dtau_match) && error("runner dtau default was not found")
    isnothing(stabilization_match) &&
        error("runner stabilization period was not found")
    dtau = _numeric_expression(strip(only(dtau_match.captures)), constants)
    stabilization_period = _integer_expression(
        strip(only(stabilization_match.captures)),
        constants,
    )

    cases = NamedTuple[]
    for match_value in eachmatch(
        r"(?ms)^    feasibility_chain\(\n(.*?)^    \),",
        source,
    )
        body = only(match_value.captures)
        phase_text = _assignment(body, "phase")
        startswith(phase_text, ':') || error("configured phase is not a symbol")
        phase = Symbol(phase_text[2:end])
        case_text = _assignment(body, "case_name")
        startswith(case_text, '"') && endswith(case_text, '"') ||
            error("configured case name is not a string literal")
        case_name = case_text[2:(end - 1)]
        L = _integer_expression(_assignment(body, "L"), constants)
        beta = _numeric_expression(_assignment(body, "beta"), constants)
        U = _numeric_expression(_assignment(body, "U"), constants)
        mu = _numeric_expression(_assignment(body, "mu"), constants)
        seed = _integer_expression(_assignment(body, "seed"), constants)
        burnin_sweeps = _integer_expression(
            _assignment(body, "burnin_sweeps"),
            constants,
        )
        measurement_sweeps = _integer_expression(
            _assignment(body, "measurement_sweeps"),
            constants,
        )
        sweeps_between_measurements = _integer_expression(
            _assignment(body, "sweeps_between_measurements"),
            constants,
        )
        block_size = _integer_expression(
            _assignment(body, "block_size"),
            constants,
        )
        target_expression = _assignment(body, "target_filling"; required=false)
        target_filling = isnothing(target_expression) ? missing :
            _numeric_expression(target_expression, constants)
        Ltau = round(Int, beta / dtau)
        beta / dtau == Ltau ||
            error("configured beta/dtau is not an integer for $case_name")
        push!(cases, (
            phase=phase,
            case=case_name,
            L=L,
            beta=beta,
            dtau=dtau,
            Ltau=Ltau,
            U=U,
            mu=mu,
            stabilization_period=stabilization_period,
            burnin_sweeps=burnin_sweeps,
            measurement_sweeps=measurement_sweeps,
            sweeps_between_measurements=sweeps_between_measurements,
            block_size=block_size,
            seed=seed,
            target_filling=target_filling,
        ))
    end
    isempty(cases) && error("no configured feasibility cases were found")
    length(unique(case.seed for case in cases)) == length(cases) ||
        error("configured feasibility seeds are not globally unique")
    return cases
end

function _metadata_key_values(lines, path)
    values = Dict{String,String}()
    for line in lines
        line == "Selected chain table" && break
        isempty(line) && continue
        occursin('=', line) || continue
        pair = split(line, '='; limit=2)
        length(pair) == 2 || error("malformed metadata assignment in $path")
        haskey(values, pair[1]) &&
            error("duplicate metadata assignment $(pair[1]) in $path")
        values[pair[1]] = pair[2]
    end
    return values
end

function _metadata_table(lines, title, path)
    title_index = findfirst(==(title), lines)
    isnothing(title_index) && error("$path is missing '$title'")
    title_index + 3 <= length(lines) || error("$path has a truncated '$title'")
    all(==('-'), lines[title_index + 1]) ||
        error("$path has a malformed '$title' separator")
    header = split(lines[title_index + 2], '\t'; keepempty=true)
    values = split(lines[title_index + 3], '\t'; keepempty=true)
    length(header) == length(values) ||
        error("$path has a '$title' field-count mismatch")
    length(unique(header)) == length(header) ||
        error("$path has duplicate '$title' columns")
    return Dict(zip(header, values))
end

function _parse_metadata(path)
    lines = readlines(path)
    return (
        settings=_metadata_key_values(lines, path),
        selected=_metadata_table(lines, "Selected chain table", path),
        completed=_metadata_table(lines, "Completed chain diagnostics", path),
    )
end

function _assert_equal(label, left, right, path)
    isequal(left, right) || error(
        "$path has inconsistent $label: $(repr(left)) != $(repr(right))",
    )
    return nothing
end

function _parse_result_directory(directory, configured_cases)
    csv_path = joinpath(directory, "sign_feasibility.csv")
    metadata_path = joinpath(directory, "metadata.txt")
    isfile(csv_path) == isfile(metadata_path) ||
        error("partial result directory: $directory")
    isfile(csv_path) || error("result directory has no result pair: $directory")

    csv = _read_single_record_csv(csv_path)
    row = csv.row
    source = csv_path
    phase = Symbol(_required(row, "phase", source))
    case_name = _required(row, "case", source)
    seed = parse(Int, _required(row, "seed", source))
    matches = filter(
        case -> case.phase == phase && case.case == case_name && case.seed == seed,
        configured_cases,
    )
    length(matches) == 1 || error(
        "$directory does not match exactly one configured phase/case/seed",
    )
    configured = only(matches)
    expected_basename = "$(case_name)_seed$(seed)_strict_pilot"
    basename(directory) == expected_basename || error(
        "$directory does not use the unique strict-pilot output name $expected_basename",
    )

    parsed = (
        L=parse(Int, _required(row, "L", source)),
        beta=parse(Float64, _required(row, "beta", source)),
        dtau=parse(Float64, _required(row, "dtau", source)),
        Ltau=parse(Int, _required(row, "Ltau", source)),
        U=parse(Float64, _required(row, "U", source)),
        mu=parse(Float64, _required(row, "mu", source)),
        burnin_sweeps=parse(Int, _required(row, "burnin_sweeps", source)),
        measurement_sweeps=parse(
            Int,
            _required(row, "measurement_sweeps", source),
        ),
        sweeps_between_measurements=parse(
            Int,
            _required(row, "sweeps_between_measurements", source),
        ),
        requested_block_size=parse(
            Int,
            _required(row, "requested_block_size", source),
        ),
    )
    for name in fieldnames(typeof(parsed))
        configured_name = name == :requested_block_size ? :block_size : name
        _assert_equal(
            string(name),
            getfield(parsed, name),
            getfield(configured, configured_name),
            directory,
        )
    end

    target_text = _required(row, "target_filling", source)
    target_filling = isempty(target_text) ? missing : parse(Float64, target_text)
    _assert_equal("target filling", target_filling, configured.target_filling, directory)

    metadata = _parse_metadata(metadata_path)
    selected = metadata.selected
    selected_pairs = (
        "phase" => string(phase),
        "case" => case_name,
        "L" => string(parsed.L),
        "beta" => string(parsed.beta),
        "dtau" => string(parsed.dtau),
        "Ltau" => string(parsed.Ltau),
        "U" => string(parsed.U),
        "mu" => string(parsed.mu),
        "burnin" => string(parsed.burnin_sweeps),
        "measurements" => string(parsed.measurement_sweeps),
        "between" => string(parsed.sweeps_between_measurements),
        "block_size" => string(parsed.requested_block_size),
        "seed" => string(seed),
        "target_filling" => ismissing(target_filling) ? "-" : string(target_filling),
    )
    for (name, expected) in selected_pairs
        actual = _required(selected, name, metadata_path)
        _assert_equal("selected-chain $name", actual, expected, metadata_path)
    end

    completed = metadata.completed
    for name in ("phase", "case", "seed")
        _assert_equal(
            "completed-diagnostics $name",
            _required(completed, name, metadata_path),
            _required(row, name, source),
            metadata_path,
        )
    end
    for name in (
        "total_density",
        "filling_jackknife_valid",
        "filling_jackknife_standard_error",
        "attempted_updates",
        "strict_pilot_status",
    )
        _assert_equal(
            "completed-diagnostics $name",
            _required(completed, name, metadata_path),
            _required(row, name, source),
            metadata_path,
        )
    end

    density = parse(Float64, _required(row, "total_density", source))
    standard_error = parse(
        Float64,
        _required(row, "filling_jackknife_standard_error", source),
    )
    total_density_standard_error = parse(
        Float64,
        _required(row, "total_density_standard_error", source),
    )
    _assert_equal(
        "density standard errors",
        standard_error,
        total_density_standard_error,
        directory,
    )
    filling_jackknife_valid = _parse_bool(
        _required(row, "filling_jackknife_valid", source),
        "filling_jackknife_valid",
    )
    strict_pilot_passed = _parse_bool(
        _required(row, "strict_pilot_passed", source),
        "strict_pilot_passed",
    )
    strict_pilot_status = Symbol(_required(row, "strict_pilot_status", source))

    settings = metadata.settings
    configured_sign_threshold = parse(
        Float64,
        _required(row, "configured_average_sign_threshold", source),
    )
    _assert_equal(
        "average-sign threshold",
        configured_sign_threshold,
        parse(Float64, _required(settings, "average_sign_threshold", metadata_path)),
        metadata_path,
    )

    calibration = nothing
    if phase == :mu_calibration
        ismissing(target_filling) &&
            error("calibration record $directory has no target filling")
        provenance = CalibrationProvenance(
            phase=phase,
            L=parsed.L,
            beta=parsed.beta,
            dtau=parsed.dtau,
            Ltau=parsed.Ltau,
            U=parsed.U,
            matrix_dimension=parse(
                Int,
                _required(row, "matrix_dimension", source),
            ),
            stabilization_period=configured.stabilization_period,
            burnin_sweeps=parsed.burnin_sweeps,
            measurement_sweeps=parsed.measurement_sweeps,
            sweeps_between_measurements=parsed.sweeps_between_measurements,
            measurement_count=parse(
                Int,
                _required(row, "measurement_count", source),
            ),
            requested_block_size=parsed.requested_block_size,
            block_count=parse(Int, _required(row, "block_count", source)),
            minimum_block_length=parse(
                Int,
                _required(row, "minimum_block_length", source),
            ),
            maximum_block_length=parse(
                Int,
                _required(row, "maximum_block_length", source),
            ),
            attempted_updates=parse(
                Int,
                _required(row, "attempted_updates", source),
            ),
            configured_average_sign_threshold=configured_sign_threshold,
            maximum_average_sign_standard_error=parse(
                Float64,
                _required(
                    settings,
                    "maximum_average_sign_standard_error",
                    metadata_path,
                ),
            ),
            minimum_block_count=parse(
                Int,
                _required(settings, "minimum_block_count", metadata_path),
            ),
            maximum_block_drift_zscore=parse(
                Float64,
                _required(settings, "maximum_block_drift_zscore", metadata_path),
            ),
            minimum_sign_signal_to_noise=parse(
                Float64,
                _required(settings, "minimum_sign_signal_to_noise", metadata_path),
            ),
            minimum_absolute_average_sign=parse(
                Float64,
                _required(settings, "minimum_absolute_average_sign", metadata_path),
            ),
            maximum_greens_recompute_error=parse(
                Float64,
                _required(settings, "maximum_greens_recompute_error", metadata_path),
            ),
            u0_filling_tolerance=parse(
                Float64,
                _required(settings, "u0_filling_tolerance", metadata_path),
            ),
            require_single=_parse_bool(
                _required(settings, "require_single", metadata_path),
                "require_single",
            ),
            strict_pilot=_parse_bool(
                _required(settings, "strict_pilot", metadata_path),
                "strict_pilot",
            ),
            output_schema=join(csv.header, ','),
        )
        calibration = CalibrationRecord(
            case_name=case_name,
            seed=seed,
            mu=parsed.mu,
            target_density=target_filling,
            density=density,
            standard_error=standard_error,
            strict_pilot_status=strict_pilot_status,
            strict_pilot_passed=strict_pilot_passed,
            filling_jackknife_valid=filling_jackknife_valid,
            source_consistent=true,
            provenance=provenance,
            output_directory=relpath(directory, ROOT),
        )
    end
    return (seed=seed, calibration=calibration)
end

function _scan_results(result_root, configured_cases)
    isdir(result_root) || error("result root does not exist: $result_root")
    parsed_results = NamedTuple[]
    for entry in sort(readdir(result_root; join=true))
        isdir(entry) || error("unexpected non-directory in result root: $entry")
        push!(parsed_results, _parse_result_directory(entry, configured_cases))
    end
    isempty(parsed_results) && error("no sign-feasibility results were found")
    record_seeds = [result.seed for result in parsed_results]
    length(unique(record_seeds)) == length(record_seeds) ||
        error("available result seeds are not globally unique")
    calibrations = CalibrationRecord[
        result.calibration for result in parsed_results
        if !isnothing(result.calibration)
    ]
    return (record_seeds=record_seeds, calibrations=calibrations)
end

function main(;
    io::IO=stdout,
    runner_path=RUNNER_PATH,
    result_root=RESULT_ROOT,
    path_exists=path -> ispath(joinpath(ROOT, path)),
)
    configured_cases = _parse_configured_cases(runner_path)
    scan = _scan_results(result_root, configured_cases)
    available_keys = Set((record.case_name, record.seed) for record in scan.calibrations)
    issubset(BASELINE_ENDPOINTS, available_keys) ||
        error("the two baseline bracket records are not both available")
    completed_new_evaluations = count(
        record -> !((record.case_name, record.seed) in BASELINE_ENDPOINTS),
        scan.calibrations,
    )

    plan = plan_calibration(
        scan.calibrations;
        target_density=TARGET_DENSITY,
        completed_new_evaluations=completed_new_evaluations,
        maximum_new_evaluations=MAXIMUM_NEW_EVALUATIONS,
        bracket_width_tolerance=BRACKET_WIDTH_TOLERANCE,
    )
    proposal = if plan.status == :PROPOSE_CANDIDATE
        build_candidate_proposal(
            plan;
            configured_seeds=(case.seed for case in configured_cases),
            record_seeds=scan.record_seeds,
            output_root=DISPLAY_RESULT_ROOT,
            first_candidate=FIRST_CANDIDATE_SEED,
            path_exists=path_exists,
        )
    else
        nothing
    end

    println(io, "configured_case_count=", length(configured_cases))
    println(io, "available_result_count=", length(scan.record_seeds))
    println(io, "available_calibration_record_count=", length(scan.calibrations))
    print_plan(io, plan, proposal)
    return (
        plan=plan,
        proposal=proposal,
        configured_case_count=length(configured_cases),
        available_result_count=length(scan.record_seeds),
    )
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end
