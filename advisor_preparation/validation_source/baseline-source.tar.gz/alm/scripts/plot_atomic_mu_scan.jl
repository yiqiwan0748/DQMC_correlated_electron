#!/usr/bin/env julia

using DelimitedFiles
using Plots
using Printf

function usage()
    println("Usage: julia --project=. plot_atomic_mu_scan.jl SCAN_ROOT [BETA]")
end

if any(argument -> argument in ("-h", "--help"), ARGS)
    usage()
    exit()
end
length(ARGS) in (1, 2) || (usage(); error("SCAN_ROOT and optional BETA are required"))

const U = 2.0
const BETA = length(ARGS) == 2 ? parse(Float64, ARGS[2]) : 10.0
const LABELS = ["mu_m0p5", "mu_0p0", "mu_p0p5"]
const MUS = [-0.5, 0.0, 0.5]
const DQMC_HEADER = [
    "omega",
    "A_normalized",
    "A_normalized_deac_se",
    "A_physical_total",
    "A_physical_total_deac_se",
]

function read_dqmc(path)
    isfile(path) || error("Missing DQMC continuation CSV: $path")
    header = split(strip(open(readline, path)), ',')
    header == DQMC_HEADER || error("Unexpected DQMC CSV header in $path")
    data = readdlm(path, ',', Float64, '\n'; skipstart=1)
    size(data, 2) == 5 || error("Expected five DQMC CSV columns in $path")
    all(isfinite, data) || error("Non-finite DQMC spectrum in $path")
    return data
end

function read_control(path)
    isfile(path) || error("Missing exact-input continuation CSV: $path")
    data = readdlm(path, ',', Float64)
    size(data, 2) == 4 || error("Expected four exact-control CSV columns in $path")
    all(isfinite, data) || error("Non-finite exact-control spectrum in $path")
    return data
end

function trapz(x, y)
    length(x) == length(y) || throw(DimensionMismatch("x and y lengths differ"))
    length(x) >= 2 || error("At least two integration points are required")
    return sum(diff(x) .* (y[1:end-1] .+ y[2:end]) ./ 2)
end

function peak_position(omega, spectrum, positive)
    indices = findall(value -> positive ? value > 0 : value < 0, omega)
    isempty(indices) && error("Energy grid does not contain the requested half-axis")
    return omega[indices[argmax(spectrum[indices])]]
end

function exact_poles(mu)
    return (-U / 2 - mu, U / 2 - mu)
end

scan_root = abspath(ARGS[1])
isdir(scan_root) || error("Scan root does not exist: $scan_root")

rows = NamedTuple[]
spectral_panels = Plots.Plot[]
dqmc_spectra = Vector{Vector{Float64}}()
common_omega = nothing

for (index, (label, mu)) in enumerate(zip(LABELS, MUS))
    point = joinpath(scan_root, label)
    dqmc = read_dqmc(joinpath(point, "dos", "dos_spectrum.csv"))
    control = read_control(joinpath(point, "exact_deac", "atom_deac_spectrum.csv"))

    omega = dqmc[:, 1]
    spectrum = dqmc[:, 4]
    spectrum_error = dqmc[:, 5]
    control_omega = control[:, 1]
    control_spectrum = 4 .* control[:, 2]
    control_error = 4 .* control[:, 3]
    exact_broadened = 4 .* control[:, 4]

    omega == control_omega || error("Energy grids differ for mu=$mu")
    if isnothing(common_omega)
        global common_omega = copy(omega)
    else
        omega == common_omega || error("Energy grids differ between mu points")
    end
    push!(dqmc_spectra, copy(spectrum))

    negative_exact, positive_exact = exact_poles(mu)
    negative_dqmc = peak_position(omega, spectrum, false)
    positive_dqmc = peak_position(omega, spectrum, true)
    negative_control = peak_position(omega, control_spectrum, false)
    positive_control = peak_position(omega, control_spectrum, true)
    spectral_weight = trapz(omega, spectrum)

    push!(rows, (
        mu=mu,
        spectral_weight=spectral_weight,
        dqmc_negative_peak=negative_dqmc,
        exact_negative_pole=negative_exact,
        dqmc_negative_error=negative_dqmc - negative_exact,
        dqmc_positive_peak=positive_dqmc,
        exact_positive_pole=positive_exact,
        dqmc_positive_error=positive_dqmc - positive_exact,
        control_negative_peak=negative_control,
        control_positive_peak=positive_control,
    ))

    panel = plot(
        omega,
        spectrum;
        ribbon=spectrum_error,
        color=:blue,
        linewidth=2,
        label=index == 1 ? "DQMC G(τ) + DEAC" : false,
        xlabel="Energy, ω",
        ylabel="Total spectral density",
        title="μ = $(mu)",
        xlims=(-2.5, 2.5),
        grid=true,
        framestyle=:box,
    )
    plot!(
        panel,
        control_omega,
        control_spectrum;
        ribbon=control_error,
        color=:orange,
        linewidth=2,
        label=index == 1 ? "Exact-ED G(τ) + DEAC" : false,
    )
    plot!(
        panel,
        control_omega,
        exact_broadened;
        color=:red,
        linestyle=:dash,
        linewidth=2,
        label=index == 1 ? "Exact ED, Lorentzian η=0.05" : false,
    )
    vline!(
        panel,
        [negative_exact, positive_exact];
        color=:black,
        linestyle=:dot,
        linewidth=1.5,
        label=index == 1 ? "Exact ED poles" : false,
    )
    push!(spectral_panels, panel)
end

negative_exact_line = [-U / 2 - mu for mu in MUS]
positive_exact_line = [U / 2 - mu for mu in MUS]
negative_dqmc_points = [row.dqmc_negative_peak for row in rows]
positive_dqmc_points = [row.dqmc_positive_peak for row in rows]
negative_control_points = [row.control_negative_peak for row in rows]
positive_control_points = [row.control_positive_peak for row in rows]

peak_panel = plot(
    MUS,
    negative_exact_line;
    color=:black,
    linestyle=:dash,
    linewidth=2,
    label="Exact poles",
    xlabel="Chemical potential, μ",
    ylabel="Peak energy, ω",
    title="Peak shift with chemical potential",
    xticks=MUS,
    xlims=(-0.6, 0.6),
    ylims=(-1.8, 1.8),
    grid=true,
    framestyle=:box,
)
plot!(
    peak_panel,
    MUS,
    positive_exact_line;
    color=:black,
    linestyle=:dash,
    linewidth=2,
    label=false,
)
scatter!(
    peak_panel,
    MUS,
    negative_dqmc_points;
    color=:blue,
    marker=:circle,
    markersize=6,
    label="DQMC + DEAC",
)
scatter!(
    peak_panel,
    MUS,
    positive_dqmc_points;
    color=:blue,
    marker=:circle,
    markersize=6,
    label=false,
)
scatter!(
    peak_panel,
    MUS,
    negative_control_points;
    color=:orange,
    marker=:diamond,
    markersize=5,
    label="Exact-input DEAC",
)
scatter!(
    peak_panel,
    MUS,
    positive_control_points;
    color=:orange,
    marker=:diamond,
    markersize=5,
    label=false,
)

combined = plot(
    spectral_panels[1],
    spectral_panels[2],
    spectral_panels[3],
    peak_panel;
    layout=(2, 2),
    size=(1200, 900),
    plot_title="Interacting atomic DQMC-ED μ scan — U=2, β=$(BETA)",
    left_margin=5Plots.mm,
    bottom_margin=4Plots.mm,
)

figure_path = joinpath(scan_root, "atomic_mu_scan_ed_benchmark.png")
savefig(combined, figure_path)

summary_path = joinpath(scan_root, "atomic_mu_scan_summary.csv")
open(summary_path, "w") do io
    println(
        io,
        "mu,spectral_weight,dqmc_negative_peak,exact_negative_pole," *
        "dqmc_negative_error,dqmc_positive_peak,exact_positive_pole," *
        "dqmc_positive_error,control_negative_peak,control_positive_peak",
    )
    for row in rows
        println(io, join(values(row), ','))
    end
end

mirror_error = trapz(
    common_omega,
    abs.(dqmc_spectra[1] .- reverse(dqmc_spectra[3])),
) / (2 * 4)

println("mu, spectral weight, DQMC peaks, exact poles")
for row in rows
    @printf(
        "%+.1f, %.8f, (%.4f, %.4f), (%.4f, %.4f)\n",
        row.mu,
        row.spectral_weight,
        row.dqmc_negative_peak,
        row.dqmc_positive_peak,
        row.exact_negative_pole,
        row.exact_positive_pole,
    )
end
@printf("Particle-hole mirror TV distance = %.8f\n", mirror_error)
println("Saved figure: ", figure_path)
println("Saved summary: ", summary_path)

