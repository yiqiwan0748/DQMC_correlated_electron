#!/usr/bin/env julia

using DelimitedFiles
using Plots
using Printf

const SPECTRUM_HEADER = [
    "omega",
    "A_normalized",
    "A_normalized_deac_se",
    "A_physical_total",
    "A_physical_total_deac_se",
]

function usage()
    println(
        "Usage: julia --project=. plot_dos_resolution_comparison.jl " *
        "DOS_DIRECTORY_1 DOS_DIRECTORY_2 [OUTPUT.png]",
    )
end

function read_spectrum(directory)
    path = joinpath(directory, "dos_spectrum.csv")
    isfile(path) || error("Missing DOS spectrum: $path")
    header = split(strip(open(readline, path)), ',')
    header == SPECTRUM_HEADER || error(
        "Unexpected spectrum columns in $path",
    )
    data = readdlm(path, ',', Float64, '\n'; skipstart=1)
    ndims(data) == 2 && size(data, 2) == 5 || error(
        "Malformed DOS spectrum: $path",
    )
    all(isfinite, data) || error("Non-finite DOS value in $path")
    return (omega=data[:, 1], spectral_density=data[:, 4])
end

function run_label(directory)
    seed_match = match(r"seed([0-9]+)", basename(directory))
    return isnothing(seed_match) ? basename(directory) : "seed=$(seed_match.captures[1])"
end

function trapezoid_weights(x)
    length(x) >= 3 || error("At least three energy points are required.")
    all(diff(x) .> 0) || error("Energy grid must be strictly increasing.")
    weights = zeros(Float64, length(x))
    weights[1] = (x[2] - x[1]) / 2
    weights[end] = (x[end] - x[end - 1]) / 2
    for index in 2:(length(x) - 1)
        weights[index] = (x[index + 1] - x[index - 1]) / 2
    end
    return weights
end

function integrate(weights, values)
    return sum(weights .* values)
end

function gaussian_broaden(omega, spectrum, sigma, weights)
    sigma > 0 || return copy(spectrum)
    output = zeros(Float64, length(omega))
    normalization = inv(sqrt(2pi) * sigma)
    for output_index in eachindex(omega)
        center = omega[output_index]
        total = 0.0
        for input_index in eachindex(omega)
            displacement = center - omega[input_index]
            kernel = normalization * exp(-0.5 * (displacement / sigma)^2)
            total += weights[input_index] * kernel * spectrum[input_index]
        end
        output[output_index] = total
    end

    original_weight = integrate(weights, spectrum)
    broadened_weight = integrate(weights, output)
    broadened_weight > 0 || error("Gaussian broadening produced zero weight.")
    output .*= original_weight / broadened_weight
    return output
end

function total_variation_distance(weights, first_spectrum, second_spectrum)
    first_weight = integrate(weights, first_spectrum)
    second_weight = integrate(weights, second_spectrum)
    first_weight > 0 && second_weight > 0 || error(
        "Both spectra need positive integrated weight.",
    )
    first_normalized = first_spectrum ./ first_weight
    second_normalized = second_spectrum ./ second_weight
    return 0.5 * integrate(weights, abs.(first_normalized .- second_normalized))
end

function main(args)
    if any(argument -> argument in ("-h", "--help"), args)
        usage()
        return
    end
    2 <= length(args) <= 3 || error("Expected two or three arguments.")

    directory_1 = abspath(args[1])
    directory_2 = abspath(args[2])
    output_path = length(args) == 3 ? abspath(args[3]) :
        joinpath(dirname(directory_1), "dos_resolution_comparison.png")
    first_run = read_spectrum(directory_1)
    second_run = read_spectrum(directory_2)
    first_run.omega == second_run.omega || error(
        "The two spectra use different energy grids.",
    )
    omega = first_run.omega
    weights = trapezoid_weights(omega)
    label_1 = run_label(directory_1)
    label_2 = run_label(directory_2)
    resolutions = [0.0, 0.25, 0.5, 1.0]

    panels = Plots.Plot[]
    distances = Float64[]
    for (panel_index, sigma) in pairs(resolutions)
        first_spectrum = gaussian_broaden(
            omega,
            first_run.spectral_density,
            sigma,
            weights,
        )
        second_spectrum = gaussian_broaden(
            omega,
            second_run.spectral_density,
            sigma,
            weights,
        )
        distance = total_variation_distance(
            weights,
            first_spectrum,
            second_spectrum,
        )
        push!(distances, distance)
        resolution_label = sigma == 0 ? "Raw DEAC output" :
            @sprintf("Additional Gaussian resolution σ = %.2g", sigma)
        panel = plot(
            omega,
            first_spectrum;
            linewidth=2,
            color=:blue,
            label=label_1,
            xlabel="Energy, ω",
            ylabel="Spectral density",
            title=@sprintf("%s; TV distance = %.3f", resolution_label, distance),
            legend=panel_index == 1 ? :topright : false,
            gridalpha=0.2,
            left_margin=7Plots.mm,
            bottom_margin=5Plots.mm,
        )
        plot!(
            panel,
            omega,
            second_spectrum;
            linewidth=2,
            color=:orange,
            label=label_2,
        )
        vline!(
            panel,
            [0.0];
            color=:black,
            linestyle=:dash,
            linewidth=1,
            label=false,
        )
        push!(panels, panel)
    end

    combined = plot(
        panels...;
        layout=(2, 2),
        size=(1100, 850),
        plot_title="Independent-chain DOS agreement versus imposed resolution",
    )
    mkpath(dirname(output_path))
    savefig(combined, output_path)

    println("Additional Gaussian sigma, total-variation distance")
    for (sigma, distance) in zip(resolutions, distances)
        @printf("%.8g, %.8g\n", sigma, distance)
    end
    @printf(
        "Integrated physical spectral weight, %s = %.8g\n",
        label_1,
        integrate(weights, first_run.spectral_density),
    )
    @printf(
        "Integrated physical spectral weight, %s = %.8g\n",
        label_2,
        integrate(weights, second_run.spectral_density),
    )
    println("Saved resolution comparison: $output_path")
end

main(ARGS)
