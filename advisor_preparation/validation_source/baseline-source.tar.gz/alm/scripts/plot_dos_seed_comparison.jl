#!/usr/bin/env julia

using DelimitedFiles
using Plots
using Printf
using Statistics

const INPUT_HEADER = [
    "tau_index",
    "tau",
    "G_normalized",
    "G_normalized_se",
    "G_physical_total",
    "G_physical_total_se",
]

const SPECTRUM_HEADER = [
    "omega",
    "A_normalized",
    "A_normalized_deac_se",
    "A_physical_total",
    "A_physical_total_deac_se",
]

function usage()
    println(
        "Usage: julia --project=. plot_dos_seed_comparison.jl " *
        "DOS_DIRECTORY_1 DOS_DIRECTORY_2 [OUTPUT.png]",
    )
end

function read_numeric_csv(path, expected_header)
    isfile(path) || error("Missing file: $path")
    header = split(strip(open(readline, path)), ',')
    header == expected_header || error(
        "Unexpected columns in $(basename(path)): $(join(header, ", "))",
    )
    data = readdlm(path, ',', Float64, '\n'; skipstart=1)
    ndims(data) == 2 && size(data, 2) == length(expected_header) || error(
        "Malformed numeric table: $path",
    )
    all(isfinite, data) || error("Non-finite value in $path")
    return data
end

function read_run(directory)
    isdir(directory) || error("DOS directory does not exist: $directory")
    input = read_numeric_csv(joinpath(directory, "dos_input.csv"), INPUT_HEADER)
    spectrum = read_numeric_csv(
        joinpath(directory, "dos_spectrum.csv"),
        SPECTRUM_HEADER,
    )
    return (
        tau=input[:, 2],
        green=input[:, 3],
        green_se=input[:, 4],
        omega=spectrum[:, 1],
        spectral_density=spectrum[:, 4],
        spectral_se=spectrum[:, 5],
    )
end

function run_label(directory)
    seed_match = match(r"seed([0-9]+)", basename(directory))
    return isnothing(seed_match) ? basename(directory) : "seed=$(seed_match.captures[1])"
end

function trapezoid_integral(x, y)
    return sum(
        (x[index + 1] - x[index]) *
        (y[index + 1] + y[index]) / 2
        for index in 1:(length(x) - 1)
    )
end

function main(args)
    if any(argument -> argument in ("-h", "--help"), args)
        usage()
        return
    end
    2 <= length(args) <= 3 || error("Expected two or three arguments.")

    directory_1 = abspath(args[1])
    directory_2 = abspath(args[2])
    output_path = length(args) == 3 ? abspath(args[3]) :
        joinpath(dirname(directory_1), "dos_seed_comparison.png")
    run_1 = read_run(directory_1)
    run_2 = read_run(directory_2)
    run_1.tau == run_2.tau || error("The two runs use different tau grids.")
    run_1.omega == run_2.omega || error("The two runs use different energy grids.")
    label_1 = run_label(directory_1)
    label_2 = run_label(directory_2)

    combined_se = hypot.(run_1.green_se, run_2.green_se)
    pointwise_z = zeros(Float64, length(combined_se))
    for index in eachindex(pointwise_z)
        difference = run_1.green[index] - run_2.green[index]
        pointwise_z[index] = combined_se[index] > 0 ?
            difference / combined_se[index] : 0.0
    end
    maximum_z = maximum(abs, pointwise_z)
    rms_z = sqrt(mean(abs2, pointwise_z))

    green_plot = plot(
        run_1.tau,
        run_1.green;
        ribbon=run_1.green_se,
        fillalpha=0.16,
        linewidth=2,
        color=:blue,
        label=label_1,
        xlabel="Imaginary time, τ",
        ylabel="Normalized G_DOS(τ)",
        title="DQMC continuation input",
        legend=:topright,
        gridalpha=0.2,
        left_margin=8Plots.mm,
    )
    plot!(
        green_plot,
        run_2.tau,
        run_2.green;
        ribbon=run_2.green_se,
        fillalpha=0.16,
        linewidth=2,
        color=:orange,
        label=label_2,
    )

    z_limit = max(3.0, 1.1 * maximum_z)
    z_plot = plot(
        run_1.tau,
        pointwise_z;
        linewidth=2,
        color=:purple,
        label=false,
        xlabel="Imaginary time, τ",
        ylabel="Pointwise difference / combined SE",
        title=@sprintf("Input agreement: max |z| = %.3g, RMS z = %.3g", maximum_z, rms_z),
        ylims=(-z_limit, z_limit),
        gridalpha=0.2,
        left_margin=8Plots.mm,
    )
    hline!(z_plot, [0.0]; color=:black, linewidth=1, label=false)
    hline!(
        z_plot,
        [-2.0, 2.0];
        color=:red,
        linestyle=:dash,
        linewidth=1.5,
        label=false,
    )

    spectrum_plot = plot(
        run_1.omega,
        run_1.spectral_density;
        ribbon=run_1.spectral_se,
        fillalpha=0.13,
        linewidth=2,
        color=:blue,
        label=label_1,
        xlabel="Energy, ω",
        ylabel="Spectral density (states/cell/energy)",
        title="Medium-DEAC DOS comparison",
        legend=:topright,
        gridalpha=0.2,
        left_margin=8Plots.mm,
        bottom_margin=5Plots.mm,
    )
    plot!(
        spectrum_plot,
        run_2.omega,
        run_2.spectral_density;
        ribbon=run_2.spectral_se,
        fillalpha=0.13,
        linewidth=2,
        color=:orange,
        label=label_2,
    )
    vline!(
        spectrum_plot,
        [0.0];
        color=:black,
        linestyle=:dash,
        linewidth=1,
        label=false,
    )

    combined = plot(
        green_plot,
        z_plot,
        spectrum_plot;
        layout=(3, 1),
        size=(950, 1150),
        plot_title="Independent-chain DOS reproducibility",
    )
    mkpath(dirname(output_path))
    savefig(combined, output_path)

    weight_1 = trapezoid_integral(run_1.omega, run_1.spectral_density)
    weight_2 = trapezoid_integral(run_2.omega, run_2.spectral_density)
    @printf("Maximum pointwise |z| = %.8g\n", maximum_z)
    @printf("RMS pointwise z = %.8g\n", rms_z)
    @printf("Integrated physical spectral weight, %s = %.8g\n", label_1, weight_1)
    @printf("Integrated physical spectral weight, %s = %.8g\n", label_2, weight_2)
    println("Saved comparison plot: $output_path")
end

main(ARGS)
