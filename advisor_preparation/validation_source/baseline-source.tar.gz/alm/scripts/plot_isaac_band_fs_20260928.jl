#!/usr/bin/env julia
"""Matched-density HF plots and explicitly incomplete, selected-state ED views."""
ENV["GKSwstype"]="100"
using Plots, TOML, SHA, Printf, Dates
const ROOT=normpath(joinpath(@__DIR__,".."))
const DATA=joinpath(ROOT,"results/isaac_20260928/band_fs")
const OUT=isempty(ARGS) ? joinpath(ROOT,"deliverables/ed_hf_band_fs_20260928") : abspath(only(ARGS))
const UP="#c73536"
const DOWN="#2468c4"
function rows(path)
    lines=readlines(path)
    (;header=split(lines[1],','),data=[split(x,',') for x in lines[2:end] if !isempty(x)])
end
function main()
    started=time()
    ispath(joinpath(OUT,"plot_verification.toml")) && error("Refusing to overwrite completed figures")
    mkpath(OUT)
    hfdir=joinpath(DATA,"hf")
    summary=TOML.parsefile(joinpath(hfdir,"hf_summary.toml"))
    summary["status"]=="completed" || error("Incomplete HF")
    path=rows(joinpath(hfdir,"hf_path.csv")).data
    vertices=rows(joinpath(hfdir,"hf_path_vertices.csv")).data
    ticks=parse.(Float64,getindex.(vertices,4))
    labels=["Γ","X","M","Y","Γ","M"]
    grid=rows(joinpath(hfdir,"hf_fermi_grid.csv")).data
    edfile=joinpath(ROOT,"results/isaac_20260925/spectral_stage/final_u20/figures_v2/highest_weight_spectra.csv")
    ed=rows(edfile).data
    maxsymmetry=0.
    default(fontfamily="sans-serif",guidefontsize=11,tickfontsize=10,titlefontsize=12,
        legendfontsize=9,framestyle=:box,grid=false,background_color=:white,
        left_margin=6Plots.mm,right_margin=5Plots.mm,top_margin=4Plots.mm,bottom_margin=5Plots.mm,
        plot_titlevspan=.15,plot_titlefontsize=13)
    hf_names=Dict("AM"=>"HF · compensated orbital magnetism", "FM"=>"HF · saturated uniform magnetism")
    outputfiles=String[]
    function saveboth(p,name)
        for ext in ("png","pdf")
            file=joinpath(OUT,name*"."*ext);savefig(p,file);push!(outputfiles,file)
        end
    end
    for shift in (0.,20.)
        panels=Plots.Plot[]
        for branch in ("AM","FM")
            p=plot(;title=hf_names[branch],xlabel="Momentum path (distance in radians)",
                ylabel=shift==0 ? "ω / |t₁| = (E − μ) / |t₁|" : "(ω − U) / |t₁|",
                xticks=(ticks,labels),xlims=(0,last(ticks)),ylims=(-12-shift,26-shift),legend=:topright)
            for (spin,color,style) in (("up",UP,:solid),("down",DOWN,:dash)),band in ("1","2")
                r=filter(r->r[1]==branch&&r[6]==band&&r[7]==spin,path)
                plot!(p,parse.(Float64,getindex.(r,5)),parse.(Float64,getindex.(r,8)).-shift;
                    color,linestyle=style,linewidth=2.0,label=band=="1" ? "Spin $spin" : false)
            end
            hline!(p,[-shift];color=:black,linestyle=:dot,linewidth=1,label=false)
            vline!(p,ticks[2:end-1];color="#999999",alpha=.35,linewidth=.7,label=false)
            push!(panels,p)
        end
        figure=plot(panels...;layout=(1,2),size=(1400,650),dpi=160,
            plot_title="Two-orbital U-only model · U = 20 · n = 1.5 · Hartree–Fock, T = 0.0125\nSelf-consistent restricted uniform branches; these are not ED bands")
        saveboth(figure,shift==0 ? "hf_bands_actual_omega" : "hf_bands_omega_minus_U")
    end
    fs_panels=Plots.Plot[]
    fermi_ranges=Dict{String,Any}()
    for branch in ("AM","FM")
        r=filter(r->r[1]==branch,grid);L=maximum(parse.(Int,getindex.(r,2)))
        x=sort(unique(parse.(Float64,getindex.(r,4))));y=sort(unique(parse.(Float64,getindex.(r,5))))
        length(x)==length(y)==L || error("FS grid shape")
        p=plot(;title=hf_names[branch],xlabel="kₓ / π",ylabel="kᵧ / π",aspect_ratio=:equal,
            xlims=(-1,1),ylims=(-1,1),xticks=[-1,-.5,0,.5,1],yticks=[-1,-.5,0,.5,1],legend=:outerbottom)
        energies=Dict{Tuple{String,Int},Matrix{Float64}}()
        for (spin,color,style,base) in (("up",UP,:solid,6),("down",DOWN,:dash,8)),band in 1:2
            z=zeros(L,L)
            for row in r;z[parse(Int,row[3]),parse(Int,row[2])]=parse(Float64,row[base+band-1]);end
            energies[(spin,band)]=z
            fermi_ranges["$(branch)_$(spin)_band$(band)"]=[minimum(z),maximum(z)]
            if minimum(z)<0<maximum(z)
                contour!(p,x./pi,y./pi,z;levels=[0.],color=color,linewidth=2.3,linestyle=style,
                    colorbar=false,label=false)
            end
        end
        plot!(p,[NaN],[NaN];color=UP,linewidth=2.3,label="Spin up: E(k) = μ")
        plot!(p,[NaN],[NaN];color=DOWN,linestyle=:dash,linewidth=2.3,
            label=branch=="FM" ? "Spin down: no zero contour" : "Spin down: E(k) = μ")
        dots=[(a,b) for a in (-1.,0.,1.) for b in (-1.,0.,1.)]
        append!(dots,[(a,b) for a in (-.5,.5) for b in (-.5,.5)])
        scatter!(p,first.(dots),last.(dots);color=:black,markersize=2.5,markerstrokewidth=0,
            label="ED momenta (with boundary repeats)")
        branch=="AM" && (maxsymmetry=max(maxsymmetry,
            maximum(abs.(energies[("up",1)].-transpose(energies[("down",1)])))))
        push!(fs_panels,p)
    end
    maxsymmetry<2e-11 || error("HF AM spin/C4 relation failed")
    figure=plot(fs_panels...;layout=(1,2),size=(1350,780),dpi=160,
        plot_title="Hartree–Fock Fermi contours · U = 20 · n = 1.5 · T = 0.0125\n257 × 257 contour grid; eight distinct ED momenta are marked")
    saveboth(figure,"hf_fermi_contours")
    # Compare the available ED spectra with HF at exactly the same X and Y.
    # Each curve traces both orbitals for one spin and has full-frequency area 2.
    comparisons=NamedTuple[]
    for shift in (0.,20.)
        panels=Plots.Plot[]
        for label in ("X","Y"),method in ("ED","AM","FM")
            er=filter(r->r[1]==label,ed)
            omega=parse.(Float64,getindex.(er,2))
            if method=="ED"
                curves=[parse.(Float64,getindex.(er,4)),parse.(Float64,getindex.(er,5))]
            else
                vertex_index=findfirst(==(label),labels)
                pr=filter(r->r[1]==method&&abs(parse(Float64,r[5])-ticks[vertex_index])<1e-12,path)
                curves=[[sum(.15/pi/((w-parse(Float64,r[8]))^2+.15^2) for r in pr if r[7]==spin)
                         for w in omega] for spin in ("up","down")]
            end
            title=method=="ED" ? "$label · ED chosen Sᶻ = 4" : "$label · HF $method"
            p=plot(;title,xlabel=shift==0 ? "ω / |t₁|" : "(ω − U) / |t₁|",
                ylabel="Aσ(k,ω) [1 / |t₁|]",xlims=(-14-shift,38-shift),ylims=(0,2.6),legend=:topright)
            for (s,color,style) in ((1,UP,:solid),(2,DOWN,:dash))
                plot!(p,omega.-shift,curves[s];color,linestyle=style,linewidth=1.8,label=s==1 ? "Spin up" : "Spin down")
            end
            vline!(p,[-shift];color=:black,linestyle=:dot,linewidth=.8,label=false)
            push!(panels,p)
            if shift==0
                for i in eachindex(omega)
                    push!(comparisons,(momentum=label,method,omega=omega[i],omega_minus_U=omega[i]-20,
                        A_up=curves[1][i],A_down=curves[2][i]))
                end
            end
        end
        figure=plot(panels...;layout=(2,3),size=(1650,900),dpi=150,
            plot_title="Available ED and matched-density Hartree–Fock spectra · U = 20 · n = 1.5 · η = 0.15\nED: eight-cell torus, T = 0, N↑/N↓ = 10/2. HF: dense momentum grid, T = 0.0125, distinct self-consistent states.")
        saveboth(figure,shift==0 ? "xy_ed_hf_actual_omega" : "xy_ed_hf_omega_minus_U")
    end
    file=joinpath(OUT,"xy_comparison.csv")
    open(file,"w") do io
        println(io,join(string.(keys(first(comparisons))),','))
        for row in comparisons;println(io,join(values(row),','));end
    end
    push!(outputfiles,file)
    # Explicit incomplete momentum view: columns at X and Y only, no interpolation.
    # Gray markers locate requested but not yet computed k; they are not zero data.
    w=collect(-14.:.05:38.)
    sparse_panels=Plots.Plot[]
    eta=.15
    for (s,color,title) in ((4,UP,"Spin up"),(5,DOWN,"Spin down"))
        p=plot(;title,xlabel="Momentum path",ylabel="ω / |t₁|",xticks=(ticks,labels),
            xlims=(-.25,last(ticks)+.25),ylims=(-14,38),legend=false)
        for (label,where) in (("X",ticks[2]),("Y",ticks[4]))
            er=filter(r->r[1]==label&&-14<=parse(Float64,r[2])<=38,ed)
            energies=parse.(Float64,getindex.(er,2));intensities=parse.(Float64,getindex.(er,s))
            z=hcat(intensities,intensities)
            heatmap!(p,[where-.15,where+.15],energies,z;color=cgrad([:white,color]),
                clims=(0,1.2),colorbar_title="Aσ",colorbar=true,label=false)
        end
        for where in (ticks[1],ticks[3],ticks[5],ticks[6],(ticks[5]+ticks[6])/2)
            vline!(p,[where];color="#bbbbbb",linestyle=:dot,linewidth=.7,label=false)
        end
        hline!(p,[0.];color=:black,linestyle=:dash,linewidth=.7,label=false)
        push!(sparse_panels,p)
    end
    figure=plot(sparse_panels...;layout=(1,2),size=(1450,750),dpi=150,
        plot_title="ED spectral path: X and Y currently available · U = 20 · N = 12 · selected Sᶻ = 4\nWhite momentum regions are uncomputed, not zero spectral weight. No curves are interpolated between X and Y.")
    saveboth(figure,"ed_path_available_only")
    inputs=[joinpath(hfdir,f) for f in ("hf_summary.toml","hf_path.csv","hf_path_vertices.csv","hf_fermi_grid.csv")]
    append!(inputs,[edfile,@__FILE__])
    report=Dict("created_utc"=>string(now(UTC)),"elapsed_seconds"=>time()-started,
        "julia_version"=>string(VERSION),"plots_version"=>string(pkgversion(Plots)),
        "inputs_sha256"=>Dict(p=>bytes2hex(open(sha256,p)) for p in inputs),
        "outputs_sha256"=>Dict(p=>bytes2hex(open(sha256,p)) for p in outputfiles),
        "hf_spin_swapped_xy_max_error"=>maxsymmetry,"hf_fermi_band_ranges"=>fermi_ranges,
        "ED_mu_centered"=>-8.240639292760854,"eta_for_XY_comparison"=>eta,
        "normalization"=>"Orbital trace per spin; full spectral area 2. No amplitude normalization or window rescaling.",
        "sparse_ED_color_cap"=>1.2,"sparse_ED_display_width_in_path_radians"=>.3,
        "sparse_ED_warning"=>"X/Y strips have arbitrary visual width; no interpolation or continuous dispersion is calculated.",
        "HF_FS_definition"=>"Linearly contoured sampled HF eigenenergy=mu; finite-T density-matched mean field.",
        "scope"=>"HF curves and available ED X/Y only; full eight-momentum ED extension pending.")
    open(joinpath(OUT,"plot_verification.toml"),"w") do io;TOML.print(io,report);end
    println("Wrote ",OUT," in ",round(time()-started;digits=2)," seconds")
end
if abspath(PROGRAM_FILE)==@__FILE__; main(); end
