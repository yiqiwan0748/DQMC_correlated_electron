#!/usr/bin/env julia

ENV["GKSwstype"] = get(ENV, "GKSwstype", "100")

using Plots

const ZERO_FIELD = "zero_field_ground_state"
const PLOT_MM = Plots.PlotMeasures.mm
const DEFAULT_DATA_DIR = normpath(joinpath(
    @__DIR__,
    "..",
    "results",
    "periodic_l2_ground_state_N6_U0_20",
))

function usage(io::IO=stdout)
    print(io, """
Usage: julia --project=. scripts/plot_periodic_l2_ground_state_results.jl [options]

  --data-dir=PATH          Directory containing the ground-state ED CSV files
  --output-dir=PATH        Destination for the four PNGs [same as data-dir]
  --particle-number=6      Canonical particle number shown in the spectrum
  --spectral-U=2,3,4       Zero-field interactions shown in A(k,omega) and DOS
  --momentum-path=Gamma,X,M,Y,Gamma  Categorical intensity-map path
  --spectrum-ymax=1.5      Maximum many-body excitation energy
  --omega-min=-8           Minimum displayed spectral frequency
  --omega-max=17           Maximum displayed spectral frequency
  --crossing-U=9.4321242166  Refined finite-cluster level crossing

The script reads saved CSVs only. It never plots explicit-source data.
""")
end

function parse_options(arguments=ARGS)
    any(argument -> argument in ("-h", "--help"), arguments) && return nothing
    raw = Dict{String,String}()
    for argument in arguments
        startswith(argument, "--") && occursin('=', argument) ||
            throw(ArgumentError("options must use --name=value: $argument"))
        name, value = split(argument[3:end], '='; limit=2)
        raw[name] = value
    end
    allowed = Set([
        "data-dir", "output-dir", "particle-number", "spectral-U",
        "momentum-path", "spectrum-ymax", "omega-min", "omega-max",
        "crossing-U",
    ])
    unknown = setdiff(Set(keys(raw)), allowed)
    isempty(unknown) || throw(ArgumentError("unknown option(s): $(join(sort!(collect(unknown)), ", "))"))

    data_dir = abspath(get(raw, "data-dir", DEFAULT_DATA_DIR))
    spectral_U = parse.(Float64, split(get(raw, "spectral-U", "2,3,4"), ','))
    isempty(spectral_U) && throw(ArgumentError("--spectral-U must not be empty"))
    momentum_path = String.(strip.(split(
        get(raw, "momentum-path", "Gamma,X,M,Y,Gamma"),
        ',',
    )))
    length(momentum_path) >= 2 || throw(ArgumentError(
        "--momentum-path must contain at least two comma-separated momenta",
    ))
    valid_momenta = Set(["Gamma", "X", "Y", "M"])
    all(momentum -> momentum in valid_momenta, momentum_path) ||
        throw(ArgumentError("--momentum-path entries must be Gamma, X, Y, or M"))
    return (
        data_dir=data_dir,
        output_dir=abspath(get(raw, "output-dir", data_dir)),
        particle_number=parse(Int, get(raw, "particle-number", "6")),
        spectral_U=sort!(unique(spectral_U)),
        momentum_path=momentum_path,
        spectrum_ymax=parse(Float64, get(raw, "spectrum-ymax", "1.5")),
        omega_min=parse(Float64, get(raw, "omega-min", "-8")),
        omega_max=parse(Float64, get(raw, "omega-max", "17")),
        crossing_U=parse(Float64, get(raw, "crossing-U", "9.4321242166")),
    )
end

function csv_columns(io, required)
    names = split(chomp(readline(io)), ',')
    indices = Dict(name => index for (index, name) in enumerate(names))
    for name in required
        haskey(indices, name) || throw(ArgumentError("CSV is missing column $name"))
    end
    return indices
end

compact_number(value::Real) = isinteger(value) ? string(Int(round(value))) : string(value)

function low_energy_levels(path, particle_number, ymax; tolerance=1.0e-8)
    energy_sum = Dict{Tuple{Float64,String,Int},Float64}()
    multiplicity = Dict{Tuple{Float64,String,Int},Int}()
    ground_energy = Dict{Float64,Float64}()
    open(path, "r") do io
        columns = csv_columns(io, ["U", "field_role", "N", "momentum", "canonical_energy"])
        for line in eachline(io)
            fields = split(line, ',')
            fields[columns["field_role"]] == ZERO_FIELD || continue
            parse(Int, fields[columns["N"]]) == particle_number || continue
            U = parse(Float64, fields[columns["U"]])
            energy = parse(Float64, fields[columns["canonical_energy"]])
            E0 = get!(ground_energy, U, energy)
            excitation = max(0.0, energy - E0)
            excitation <= ymax + tolerance || continue
            momentum = fields[columns["momentum"]]
            key = (U, momentum, round(Int, excitation / tolerance))
            energy_sum[key] = get(energy_sum, key, 0.0) + excitation
            multiplicity[key] = get(multiplicity, key, 0) + 1
        end
    end
    levels = [
        (
            U=key[1],
            momentum=key[2],
            excitation=energy_sum[key] / multiplicity[key],
            multiplicity=multiplicity[key],
        )
        for key in keys(multiplicity)
    ]
    sort!(levels; by=level -> (level.U, level.excitation, level.momentum))
    return levels
end

function read_akw(path, selected_U, momenta)
    selected = Set(selected_U)
    selected_momenta = Set(momenta)
    sums = Dict{Tuple{Float64,String,String,Float64},Float64}()
    eta = NaN
    open(path, "r") do io
        columns = csv_columns(io, [
            "U", "field_role", "spin", "momentum", "omega", "A",
            "lorentzian_eta",
        ])
        for line in eachline(io)
            fields = split(line, ',')
            fields[columns["field_role"]] == ZERO_FIELD || continue
            U = parse(Float64, fields[columns["U"]])
            U in selected || continue
            momentum = fields[columns["momentum"]]
            momentum in selected_momenta || continue
            spin = fields[columns["spin"]]
            omega = parse(Float64, fields[columns["omega"]])
            key = (U, momentum, spin, omega)
            sums[key] = get(sums, key, 0.0) + parse(Float64, fields[columns["A"]])
            eta = parse(Float64, fields[columns["lorentzian_eta"]])
        end
    end
    curves = Dict{Tuple{Float64,String,String},Tuple{Vector{Float64},Vector{Float64}}}()
    for U in selected_U, momentum in unique(momenta), spin in ("up", "down")
        points = sort!(
            [(key[4], value) for (key, value) in sums
             if key[1] == U && key[2] == momentum && key[3] == spin];
            by=first,
        )
        isempty(points) && throw(ArgumentError("no zero-field A(k,omega) data for U=$U, $momentum, $spin"))
        curves[(U, momentum, spin)] = (first.(points), last.(points))
    end
    return curves, eta
end

function read_dos(path, selected_U)
    selected = Set(selected_U)
    curves = Dict{Float64,NamedTuple}()
    rows = Dict(U => Tuple{Float64,Float64,Float64}[] for U in selected_U)
    eta = NaN
    open(path, "r") do io
        columns = csv_columns(io, [
            "U", "field_role", "omega", "dos_up", "dos_down", "lorentzian_eta",
        ])
        for line in eachline(io)
            fields = split(line, ',')
            fields[columns["field_role"]] == ZERO_FIELD || continue
            U = parse(Float64, fields[columns["U"]])
            U in selected || continue
            push!(rows[U], (
                parse(Float64, fields[columns["omega"]]),
                parse(Float64, fields[columns["dos_up"]]),
                parse(Float64, fields[columns["dos_down"]]),
            ))
            eta = parse(Float64, fields[columns["lorentzian_eta"]])
        end
    end
    for U in selected_U
        sort!(rows[U]; by=first)
        isempty(rows[U]) && throw(ArgumentError("no zero-field DOS data for U=$U"))
        curves[U] = (
            omega=first.(rows[U]),
            up=getindex.(rows[U], 2),
            down=getindex.(rows[U], 3),
        )
    end
    return curves, eta
end

function plot_many_body_spectrum(levels, options)
    momentum_style = Dict(
        "Gamma" => (label="Gamma (0,0)", color=RGB(0.10, 0.10, 0.10), marker=:circle),
        "X" => (label="X (pi,0)", color=RGB(0.00, 0.45, 0.70), marker=:diamond),
        "Y" => (label="Y (0,pi)", color=RGB(0.84, 0.37, 0.00), marker=:utriangle),
        "M" => (label="M (pi,pi)", color=RGB(0.00, 0.62, 0.45), marker=:square),
    )
    panel = plot(
        xlabel="interaction U / |t1|",
        ylabel="many-body excitation  Delta E_n / |t1|",
        title="Periodic 2x2 canonical ED: low-lying N=$(options.particle_number) many-body spectrum (h_alm=0)",
        titlefontsize=16,
        xlims=(-0.45, 20.45),
        ylims=(-0.035, options.spectrum_ymax),
        xticks=0:2:20,
        framestyle=:box,
        gridalpha=0.18,
        legend=:topright,
        background_color=:white,
        left_margin=6 * PLOT_MM,
        bottom_margin=5 * PLOT_MM,
        top_margin=3 * PLOT_MM,
        size=(1200, 650),
        dpi=180,
    )
    for momentum in ("Gamma", "X", "Y", "M")
        subset = filter(level -> level.momentum == momentum, levels)
        style = momentum_style[momentum]
        scatter!(
            panel,
            getproperty.(subset, :U),
            getproperty.(subset, :excitation);
            label=style.label,
            color=style.color,
            marker=style.marker,
            markersize=3.0 .+ 1.05 .* sqrt.(getproperty.(subset, :multiplicity)),
            markerstrokewidth=0.35,
            markeralpha=0.82,
        )
    end
    vline!(panel, [options.crossing_U];
           label="finite-size high-spin crossing  U*=9.4321",
           color=RGB(0.55, 0.20, 0.55), linewidth=2, linestyle=:dash)
    path = joinpath(options.output_dir, "periodic_L2_N6_zero_field_many_body_spectrum.png")
    savefig(panel, path)
    return path
end

function plot_akw(curves, eta, options)
    ymax = 1.08 * maximum(last(curve)[index] for curve in values(curves) for index in eachindex(last(curve)))
    panels = Any[]
    for momentum in ("X", "Y"), (column, U) in enumerate(options.spectral_U)
        up_omega, up = curves[(U, momentum, "up")]
        down_omega, down = curves[(U, momentum, "down")]
        show_legend = momentum == "X" && column == 1
        panel = plot(
            up_omega,
            up;
            label=show_legend ? "spin up (solid)" : "",
            color=RGB(0.84, 0.15, 0.16),
            linewidth=3.0,
            xlabel=momentum == "Y" ? "omega / |t1|" : "",
            ylabel=column == 1 ? "orbital-summed A_sigma(k,omega)" : "",
            xlims=(options.omega_min, options.omega_max),
            ylims=(0, ymax),
            xticks=-8:4:16,
            framestyle=:box,
            gridalpha=0.16,
            legend=show_legend ? :topright : false,
            left_margin=column == 1 ? 5 * PLOT_MM : 1 * PLOT_MM,
            bottom_margin=momentum == "Y" ? 4 * PLOT_MM : 1 * PLOT_MM,
        )
        plot!(
            panel,
            down_omega,
            down;
            label=show_legend ? "spin down (dashed)" : "",
            color=RGB(0.00, 0.35, 0.70),
            linewidth=2.2,
            linestyle=:dash,
        )
        vline!(panel, [0.0]; label="", color=:black, alpha=0.25, linewidth=1)
        annotate!(
            panel,
            options.omega_min + 1.0,
            0.91 * ymax,
            text("U=$(compact_number(U)),  $momentum", 11, :left),
        )
        push!(panels, panel)
    end
    figure = plot(
        panels...;
        layout=(2, length(options.spectral_U)),
        size=(1500, 800),
        dpi=180,
        background_color=:white,
        plot_title="T=0 zero-field A_sigma(k,omega) at X and Y - red solid: spin up; blue dashed: spin down; overlap means equality (eta=$(compact_number(eta)))",
        plot_titlefontsize=15,
    )
    path = joinpath(options.output_dir, "periodic_L2_N6_zero_field_XY_Akw_U2_U3_U4.png")
    savefig(figure, path)
    return path
end

function spectral_intensity_matrix(curves, U, momenta, spin)
    reference_omega, _ = curves[(U, first(momenta), spin)]
    columns = Vector{Vector{Float64}}()
    for momentum in momenta
        omega, intensity = curves[(U, momentum, spin)]
        omega == reference_omega || throw(ArgumentError(
            "inconsistent omega grids in the saved A(k,omega) data",
        ))
        push!(columns, intensity)
    end
    return reference_omega, hcat(columns...)
end

function momentum_tick_labels(momentum_path)
    base = Dict(
        "Gamma" => "Gamma\n(0,0)",
        "X" => "X\n(pi,0)",
        "Y" => "Y\n(0,pi)",
        "M" => "M\n(pi,pi)",
    )
    seen = Dict{String,Int}()
    labels = String[]
    for momentum in momentum_path
        count = get(seen, momentum, 0) + 1
        seen[momentum] = count
        label = base[momentum]
        count > 1 && (label *= "\n(repeat)")
        push!(labels, label)
    end
    return labels
end

function plot_discrete_spectral_intensity(curves, eta, options)
    momentum_path = options.momentum_path
    intensity_max = 0.0
    maximum_spin_difference = 0.0
    for U in options.spectral_U, momentum in unique(momentum_path)
        omega, up = curves[(U, momentum, "up")]
        _, down = curves[(U, momentum, "down")]
        window = findall(value -> options.omega_min <= value <= options.omega_max, omega)
        isempty(window) && throw(ArgumentError("the requested omega window contains no data"))
        intensity_max = max(
            intensity_max,
            maximum(up[window]),
            maximum(down[window]),
        )
        maximum_spin_difference = max(
            maximum_spin_difference,
            maximum(abs.(up[window] .- down[window])),
        )
    end

    positions = collect(1:length(momentum_path))
    tick_labels = momentum_tick_labels(momentum_path)
    panels = Any[]
    for spin in ("up", "down"), (column, U) in enumerate(options.spectral_U)
        omega, intensity = spectral_intensity_matrix(
            curves,
            U,
            momentum_path,
            spin,
        )
        panel = heatmap(
            positions,
            omega,
            intensity;
            color=:inferno,
            clims=(0.0, intensity_max),
            colorbar=column == length(options.spectral_U),
            colorbar_title=column == length(options.spectral_U) ? "A" : "",
            xlabel=spin == "down" ? "discrete momentum bin" : "",
            ylabel=column == 1 ? "spin $spin: omega / |t1|" : "",
            xticks=(positions, tick_labels),
            xlims=(0.5, length(momentum_path) + 0.5),
            ylims=(options.omega_min, options.omega_max),
            framestyle=:box,
            grid=false,
            left_margin=column == 1 ? 6 * PLOT_MM : 1 * PLOT_MM,
            right_margin=column == length(options.spectral_U) ? 5 * PLOT_MM : 1 * PLOT_MM,
            bottom_margin=spin == "down" ? 6 * PLOT_MM : 2 * PLOT_MM,
            top_margin=spin == "up" ? 3 * PLOT_MM : 1 * PLOT_MM,
        )
        if length(momentum_path) > 1
            vline!(
                panel,
                collect(1.5:1.0:(length(momentum_path) - 0.5));
                label="",
                color=:white,
                linewidth=3,
                alpha=0.92,
            )
        end
        annotate!(
            panel,
            0.68,
            options.omega_max - 0.07 * (options.omega_max - options.omega_min),
            text("U=$(compact_number(U)), spin $spin", 10, :left, :white),
        )
        hline!(panel, [0.0]; label="", color=:cyan, linewidth=1.2, alpha=0.7)
        push!(panels, panel)
    end
    path_description = join(momentum_path, "-")
    repeated_note = first(momentum_path) == last(momentum_path) ?
                    "; final $(last(momentum_path)) only closes the loop" :
                    (length(unique(momentum_path)) < length(momentum_path) ?
                     "; repeated bins are labeled" : "")
    figure = plot(
        panels...;
        layout=(2, length(options.spectral_U)),
        size=(1500, 820),
        dpi=180,
        background_color=:white,
        plot_title="T=0 zero-field spectral intensity A_sigma(k,omega): categorical $path_description\n" *
                   "four periodic-L2 momenta only; no interpolation$repeated_note; " *
                   "max |up-down|=$(round(maximum_spin_difference; sigdigits=3)), eta=$(compact_number(eta))",
        plot_titlefontsize=12,
    )
    slug = join(momentum_path, "_")
    path = joinpath(
        options.output_dir,
        "periodic_L2_N6_zero_field_discrete_$(slug)_spectral_intensity.png",
    )
    savefig(figure, path)
    return path
end

function plot_dos(curves, eta, options)
    ymax = 1.08 * maximum(maximum(vcat(curve.up, curve.down)) for curve in values(curves))
    panels = Any[]
    for (column, U) in enumerate(options.spectral_U)
        curve = curves[U]
        show_legend = column == 1
        panel = plot(
            curve.omega,
            curve.up;
            label=show_legend ? "spin up (solid)" : "",
            color=RGB(0.84, 0.15, 0.16),
            linewidth=3.0,
            xlabel="omega / |t1|",
            ylabel=column == 1 ? "DOS per spin" : "",
            xlims=(options.omega_min, options.omega_max),
            ylims=(0, ymax),
            xticks=-8:4:16,
            framestyle=:box,
            gridalpha=0.16,
            legend=show_legend ? :topright : false,
            left_margin=column == 1 ? 5 * PLOT_MM : 1 * PLOT_MM,
            bottom_margin=4 * PLOT_MM,
        )
        plot!(
            panel,
            curve.omega,
            curve.down;
            label=show_legend ? "spin down (dashed)" : "",
            color=RGB(0.00, 0.35, 0.70),
            linewidth=2.2,
            linestyle=:dash,
        )
        vline!(panel, [0.0]; label="", color=:black, alpha=0.25, linewidth=1)
        annotate!(
            panel,
            options.omega_min + 1.0,
            0.91 * ymax,
            text("U=$(compact_number(U))", 11, :left),
        )
        push!(panels, panel)
    end
    figure = plot(
        panels...;
        layout=(1, length(options.spectral_U)),
        size=(1500, 470),
        dpi=180,
        background_color=:white,
        plot_title="T=0 canonical zero-field DOS - red solid: spin up; blue dashed: spin down; overlap means equality (eta=$(compact_number(eta)))",
        plot_titlefontsize=15,
    )
    path = joinpath(options.output_dir, "periodic_L2_N6_zero_field_spin_DOS_U2_U3_U4.png")
    savefig(figure, path)
    return path
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        usage()
        return nothing
    end
    options.spectrum_ymax > 0 || throw(ArgumentError("--spectrum-ymax must be positive"))
    options.omega_min < options.omega_max || throw(ArgumentError("--omega-min must be below --omega-max"))
    mkpath(options.output_dir)

    levels_path = joinpath(options.data_dir, "periodic_L2_ground_state_full_many_body_levels.csv")
    akw_path = joinpath(options.data_dir, "periodic_L2_ground_state_spin_orbital_Akw.csv")
    dos_path = joinpath(options.data_dir, "periodic_L2_ground_state_spin_resolved_DOS.csv")
    all(isfile, (levels_path, akw_path, dos_path)) ||
        throw(ArgumentError("one or more required CSV files are missing from $(options.data_dir)"))

    levels = low_energy_levels(
        levels_path,
        options.particle_number,
        options.spectrum_ymax,
    )
    required_momenta = unique(vcat(["X", "Y"], options.momentum_path))
    akw, akw_eta = read_akw(akw_path, options.spectral_U, required_momenta)
    dos, dos_eta = read_dos(dos_path, options.spectral_U)
    paths = (
        plot_many_body_spectrum(levels, options),
        plot_akw(akw, akw_eta, options),
        plot_discrete_spectral_intensity(akw, akw_eta, options),
        plot_dos(dos, dos_eta, options),
    )
    println.(paths)
    return paths
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end
