#!/usr/bin/env julia

module PRL101237004Fig2aPlot

using Printf, SHA, Dates

const ROOT = normpath(joinpath(@__DIR__, ".."))
const DEFAULT_INPUT = joinpath(ROOT, "results", "prl_101_237004", "milestone3")
const DEFAULT_REFERENCE = joinpath(ROOT, "results", "prl_101_237004",
                                   "milestone3_reference", "fig2a_digitized.csv")
const JOBS = ((U=0.5, name="U0p5_gamma_seed7", color="#2457c5", marker=:xcross),
              (U=1.0, name="U1p0_gamma_seed7", color="#c93636", marker=:circle))
const CLASSES = ((name="Gamma", q=(0.0,0.0), multiplicity=1),
                 (name="diagonal", q=(0.5,0.5), multiplicity=4),
                 (name="stripe", q=(0.0,1.0), multiplicity=2),
                 (name="M", q=(1.0,1.0), multiplicity=1))
const ALLOWED_Q = ((0.0,0.0), (0.0,1.0), (0.5,0.5), (0.5,1.5),
                   (1.0,0.0), (1.0,1.0), (1.5,0.5), (1.5,1.5))

# Input files are the scalar, unquoted CSV schema of the production runner.
# Keeping this reader local avoids introducing a package dependency.
function read_scalar_csv(path, required)
    isfile(path) || throw(ArgumentError("required input is missing: $path"))
    lines = filter(line -> !isempty(strip(line)), readlines(path))
    isempty(lines) && throw(ArgumentError("empty CSV: $path"))
    header = strip.(split(first(lines), ','))
    length(unique(header)) == length(header) || error("duplicate CSV header: $path")
    all(in(header), required) || error("missing required CSV columns: $path")
    rows = Dict{String,String}[]
    for line in lines[2:end]
        cells = strip.(split(line, ','))
        length(cells) == length(header) || error("malformed CSV row: $path")
        push!(rows, Dict(zip(header,cells)))
    end
    isempty(rows) && error("CSV has no data rows: $path")
    return rows
end

function number(row, field)
    value = parse(Float64, row[field])
    isfinite(value) || error("nonfinite value in CSV field $field")
    return value
end

periodic_distance(a,b) = abs(mod(a-b+1,2)-1)
same_q(row,q) = periodic_distance(number(row,"qx_over_pi"),q[1]) <= 1e-12 &&
                periodic_distance(number(row,"qy_over_pi"),q[2]) <= 1e-12

function unique_q(rows,q)
    found = filter(row -> same_q(row,q), rows)
    length(found) == 1 || error("expected exactly one row at q/pi=$q")
    return only(found)
end

function collect_comparison(input, reference)
    references = read_scalar_csv(reference, ("U","J","pdpi_over_pdsigma",
        "qx_over_pi","qy_over_pi","multiplicity","S_published","extraction_allowance_abs"))
    data = NamedTuple[]
    sources = String[abspath(reference), abspath(@__FILE__)]
    for job in JOBS
        directory = joinpath(input,job.name)
        structure_path = joinpath(directory,"structure_factors.csv")
        energies_path = joinpath(directory,"energies.csv")
        spin_path = joinpath(directory,"spin_checks.csv")
        # energies.csv is written last by the production runner. Requiring it
        # prevents a plot from consuming a job while measurements are partial.
        energies = read_scalar_csv(energies_path, ("U","J","root","energy","residual"))
        ground = filter(row -> number(row,"root") == 1, energies)
        length(ground) == 1 || error("expected one root=1 row: $energies_path")
        energyrow = only(ground)
        isapprox(number(energyrow,"U"),job.U; atol=1e-12, rtol=0) || error("wrong U in $energies_path")
        isapprox(number(energyrow,"J"),job.U/4; atol=1e-12, rtol=0) || error("wrong J in $energies_path")
        residual = number(energyrow,"residual")
        residual >= 0 || error("negative solver residual: $energies_path")
        checks = read_scalar_csv(spin_path, ("norm_squared","total_spin_squared"))
        length(checks) == 1 || error("expected one spin-check row: $spin_path")
        abs(number(only(checks),"norm_squared")-1) <= 1e-7 || error("state is not normalized: $spin_path")
        abs(number(only(checks),"total_spin_squared")) <= 1e-7 || error("state is not a verified singlet: $spin_path")
        rows = read_scalar_csv(structure_path, ("qx_over_pi","qy_over_pi",
            "Szz_per_site","Szz_raw","Sdot_per_site_singlet"))
        length(rows) == 8 || error("expected all eight momenta: $structure_path")
        for q in ALLOWED_Q
            row = unique_q(rows,q)
            zz, raw = number(row,"Szz_per_site"), number(row,"Szz_raw")
            dotvalue = number(row,"Sdot_per_site_singlet")
            # These tolerances only check CSV normalization identities and
            # rounding, not numerical agreement with the published curves.
            isapprox(raw,8zz; atol=5e-11, rtol=1e-12) || error("raw/site Szz mismatch")
            isapprox(dotvalue,3zz; atol=5e-11, rtol=1e-12) || error("singlet Sdot mismatch")
            raw >= -5e-11 || error("negative spin structure factor")
        end
        reference_rows = filter(row -> isapprox(number(row,"U"),job.U; atol=1e-12,rtol=0), references)
        length(reference_rows) == 4 || error("expected four reference points for U=$(job.U)")
        comparisons = NamedTuple[]
        for class in CLASSES
            observed, published = unique_q(rows,class.q), unique_q(reference_rows,class.q)
            isapprox(number(published,"J"),job.U/4;atol=1e-12,rtol=0) || error("wrong reference J")
            isapprox(number(published,"pdpi_over_pdsigma"),-0.2;atol=1e-12,rtol=0) || error("wrong reference hopping ratio")
            number(published,"multiplicity") == class.multiplicity || error("wrong reference multiplicity")
            actual = number(observed,"Szz_raw")
            target = number(published,"S_published")
            allowance = number(published,"extraction_allowance_abs")
            allowance > 0 || error("reference extraction allowance must be positive")
            push!(comparisons,(; class.name, qx=class.q[1], qy=class.q[2],
                class.multiplicity, Szz_raw=actual, Szz_per_site=number(observed,"Szz_per_site"),
                Sdot_per_site=number(observed,"Sdot_per_site_singlet"),
                reference=target, difference=actual-target, allowance,
                within_extraction_allowance=abs(actual-target)<=allowance))
        end
        push!(data,(;job..., comparisons, energy=number(energyrow,"energy"), residual))
        append!(sources,(structure_path,energies_path,spin_path))
    end
    return data,sources
end

function render_figures(output, data)
    ticks = (1:4,["Γ\n(0,0)","D\n(½,½)","Y\n(0,1)","M\n(1,1)"])
    common = (;xlims=(0.85,4.15),xticks=ticks,xlabel="q / π",framestyle=:box,
        background_color=:white,grid=false,fontfamily="sans-serif",guidefontsize=11,
        tickfontsize=10,titlefontsize=12,legendfontsize=9,legend_background_color=:white,
        legend_foreground_color=:white,size=(840,610),dpi=220,
        left_margin=7Plots.mm,bottom_margin=9Plots.mm,right_margin=4Plots.mm,
        top_margin=5Plots.mm)
    titletext = "PRL 101, 237004 · Fig. 2(a)\n8 Fe sites · N = 16 · J/U = 1/4 · pdπ/pdσ = −0.2"
    ymax = max(8.0,1.07maximum(max(row.Szz_raw,row.reference) for d in data for row in d.comparisons))
    panel = plot(;common...,title=titletext,ylabel="Szz_raw(q)  [inferred paper normalization]",
        ylims=(-0.12,ymax),legend=:topleft)
    for (index,d) in enumerate(data)
        rows = d.comparisons
        scatter!(panel,1:4,[row.reference for row in rows];
            marker=index==1 ? :diamond : :circle,markersize=7.0,
            markercolor=:white,markerstrokecolor="#333333",markerstrokewidth=0.9,
            label="Published U = $(d.U)")
        plot!(panel,1:4,[row.Szz_raw for row in rows];color=d.color,
            linewidth=1.8,marker=d.marker,markersize=index==1 ? 6.5 : 4.5,
            markercolor=d.color,markerstrokecolor=d.color,markerstrokewidth=1.2,
            label="ED U = $(d.U)")
    end
    savefig(panel,joinpath(output,"fig2a_spin_structure.png"))
    savefig(panel,joinpath(output,"fig2a_spin_structure.pdf"))

    extent = max(0.014,1.2maximum(abs(row.difference)+row.allowance for d in data for row in d.comparisons))
    difference = plot(;common...,title="Figure 2(a): numerical difference from the published curve",
        ylabel="Szz_raw(ED) − S(published)",ylims=(-extent,extent),legend=:outertop)
    # This interval describes digitization only; no solver error bar is
    # inferred from an eigenvalue residual or substituted for it.
    allowance = maximum(row.allowance for d in data for row in d.comparisons)
    plot!(difference,[0.85,4.15],[0.0,0.0];ribbon=allowance,fillcolor="#aab4bf",
        fillalpha=0.27,linecolor="#6e7882",linewidth=0.8,
        label=@sprintf("Reference extraction allowance ±%.3f",allowance))
    for d in data
        plot!(difference,1:4,[row.difference for row in d.comparisons];
            color=d.color,linewidth=1.5,marker=d.marker,markersize=5.5,
            markerstrokecolor=d.color,label="U = $(d.U)")
    end
    savefig(difference,joinpath(output,"fig2a_reference_difference.png"))
    savefig(difference,joinpath(output,"fig2a_reference_difference.pdf"))
end

function write_outputs(output,data,sources)
    open(joinpath(output,"fig2a_comparison.csv"),"w") do io
        println(io,"U,J,q_class,qx_over_pi,qy_over_pi,multiplicity,Szz_raw,Szz_per_site,Sdot_per_site_singlet,S_published,difference,abs_difference,reference_extraction_allowance,within_extraction_allowance,ground_energy,ground_residual")
        for d in data, row in d.comparisons
            println(io,join((d.U,d.U/4,row.name,row.qx,row.qy,row.multiplicity,
                row.Szz_raw,row.Szz_per_site,row.Sdot_per_site,row.reference,
                row.difference,abs(row.difference),row.allowance,
                row.within_extraction_allowance,d.energy,d.residual),','))
        end
    end
    open(joinpath(output,"comparison_summary.txt"),"w") do io
        println(io,"PRL 101, 237004 Figure 2(a) comparison generated: ",now())
        println(io,"Plotted convention: Szz_raw = <Sz(q) Sz(-q)> = 8 Szz_per_site = (8/3) Sdot_per_site for Nsites=8 singlet.")
        println(io,"The normalization is inferred from the authors' independent U=0 follow-up curve; it is not printed as a formula in the PRL.")
        println(io,"Reference intervals concern graphics extraction only, not the authors' or this solver's numerical uncertainty.")
        println(io,"No fitted vertical rescaling or additive offset was applied.")
        println(io,"This postprocessor checks completed-job files and spin/normalization consistency. It does not independently certify the global ground state or convergence across symmetry sectors.")
        for d in data
            @printf(io,"U=%.1f J=%.3f: maximum absolute difference=%.9g; points within extraction allowance=%d/4; ground energy=%.15g; direct residual=%.6g\n",
                d.U,d.U/4,maximum(abs(row.difference) for row in d.comparisons),
                count(row.within_extraction_allowance for row in d.comparisons),d.energy,d.residual)
        end
        println(io,"See docs/prl_101_237004_fig2_reference.md for the reference extraction and normalization derivation.")
    end
    open(joinpath(output,"provenance.txt"),"w") do io
        println(io,"Julia version: ",VERSION)
        println(io,"Input and plotting source SHA-256:")
        for file in sources
            println(io,bytes2hex(sha256(read(file))),"  ",abspath(file))
        end
        println(io,"Output SHA-256:")
        for name in sort(readdir(output))
            name == "provenance.txt" && continue
            println(io,bytes2hex(sha256(read(joinpath(output,name)))),"  ",name)
        end
    end
end

function main(arguments=ARGS)
    options = Dict("input-root"=>DEFAULT_INPUT,"output-dir"=>"","reference"=>DEFAULT_REFERENCE)
    overwrite = false
    for argument in arguments
        if argument == "--overwrite"
            overwrite = true
        elseif argument == "--help"
            println("Usage: julia --project=. scripts/plot_prl_101_237004_fig2a.jl [--input-root=DIR] [--output-dir=DIR] [--reference=CSV] [--overwrite]")
            println("Reads completed U0p5_gamma_seed7 and U1p0_gamma_seed7 jobs; writes PNG/PDF figures, comparison CSV, and provenance to INPUT_ROOT/plots by default.")
            return nothing
        else
            startswith(argument,"--") && occursin('=',argument) || throw(ArgumentError("use --key=value"))
            key,value = split(argument[3:end],'=';limit=2)
            haskey(options,key) || throw(ArgumentError("unknown option --$key"))
            options[key] = value
        end
    end
    input = abspath(options["input-root"])
    output = isempty(options["output-dir"]) ? joinpath(input,"plots") : abspath(options["output-dir"])
    isfile(output) && error("output is a file: $output")
    isdir(output) && !isempty(readdir(output)) && !overwrite &&
        error("output directory is not empty; choose another directory or pass --overwrite: $output")
    data,sources = collect_comparison(input,abspath(options["reference"]))
    # All input validation precedes writing; rendering failures leave no
    # misleading partly complete figure directory.
    mkpath(dirname(output))
    staging = mktempdir(dirname(output);prefix="fig2a_staging_")
    try
        ENV["GKSwstype"] = "100"
        @eval using Plots
        Base.invokelatest(render_figures,staging,data)
        write_outputs(staging,data,sources)
        if isdir(output)
            for name in readdir(staging)
                mv(joinpath(staging,name),joinpath(output,name);force=overwrite)
            end
        else
            mv(staging,output)
        end
    finally
        isdir(staging) && rm(staging;recursive=true)
    end
    println("Figure 2(a) comparison saved to ",output)
    for d in data
        @printf("U=%.1f: largest absolute difference %.8g; %d/4 points inside the reference extraction allowance.\n",
            d.U,maximum(abs(row.difference) for row in d.comparisons),
            count(row.within_extraction_allowance for row in d.comparisons))
    end
    return output
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    PRL101237004Fig2aPlot.main()
end
