#!/usr/bin/env julia
module PRL101237004Fig2bPlot

using Printf, SHA, Dates
include("plot_prl_101_237004_fig2a.jl")
const CSV = PRL101237004Fig2aPlot
const ROOT = normpath(joinpath(@__DIR__,".."))
const DEFAULT_INPUT = joinpath(ROOT,"results","prl_101_237004","milestone4")
const DEFAULT_REFERENCE = joinpath(ROOT,"results","prl_101_237004","milestone4_reference","fig2b_digitized.csv")
const CHANNELS = ((name="stripe_y",reference="stripe",label="Stripe (0,π)",q=(0,1),
                   color="#2457c5",marker=:circle,published_marker=:circle,count=21),
                  (name="neel",reference="neel",label="Néel (π,π)",q=(1,1),
                   color="#c93636",marker=:xcross,published_marker=:diamond,count=5))
const H_ATOL = 1e-12
const GRADIENT_ATOL = 1e-7
const DENSITY_ATOL = 1e-6
const SCAN_COLUMNS = ("channel","h","U","J","ratio","mu","mu_prime","Omega_per_Fe",
    "density","moment_signed_muB_per_Fe","mu_prime_gradient","reference_E0","reference_residual",
    "green_probe_converged","green_half_depth_error","mu_prime_lower","mu_prime_upper",
    "root_count","physical_L","quadrature_order","block_steps","functional_evaluations","seconds","reference_cache")

num(row,key) = CSV.number(row,key)
function integer(row,key)
    value=num(row,key)
    isinteger(value) || error("$key must be an integer")
    Int(value)
end
function boolean(row,key)
    row[key] in ("true","false") || error("$key must be true or false")
    row[key]=="true"
end
function equal_parameter(row,key,value)
    abs(num(row,key)-value)<=1e-12 || error("expected $key=$value; received $(row[key])")
end
function at_field(rows,key,h)
    found=filter(row->abs(num(row,key)-h)<=H_ATOL,rows)
    length(found)==1 || error("expected exactly one $key=$h row; found $(length(found))")
    only(found)
end

"""Read completed scan CSVs and compare the declared nominal field grid.
No .progress file, source-data interpolation, offset, or fitted scale is used.
"""
function collect_comparison(input,scan_label,reference;mu=.85,physical_L=48,order=24,block_steps=48)
    isfinite(mu) || error("physical μ must be finite")
    physical_L>=2 && iseven(physical_L) || error("physical lattice size must be positive and even")
    order>=1 && block_steps>=1 || error("quadrature order and block steps must be positive")
    refs=CSV.read_scalar_csv(reference,("channel","qx_over_pi","qy_over_pi","U","J","pdpi_over_pdsigma",
        "h_stagg_nominal_inferred","h_stagg_digitized","Omega_published",
        "h_extraction_allowance_abs","Omega_extraction_allowance_abs"))
    length(refs)==26 || error("expected the complete 26-point Figure 2(b) reference")
    folder=joinpath(input,"scans",scan_label)
    data=NamedTuple[]
    sources=String[abspath(reference),abspath(@__FILE__),joinpath(@__DIR__,"plot_prl_101_237004_fig2a.jl")]
    for channel in CHANNELS
        # Only the final channel.csv marks a completed scan. Its metadata is
        # also required so the chart's field and normalization labels have evidence.
        path=joinpath(folder,channel.name*".csv")
        rows=CSV.read_scalar_csv(path,SCAN_COLUMNS)
        length(rows)==channel.count || error("$(channel.name) needs $(channel.count) completed field points")
        metadata=joinpath(folder,channel.name*"_metadata.txt")
        isfile(metadata) || error("scan metadata is missing: $metadata")
        record=read(metadata,String)
        for term in ("open2x2 Fe","no1/2","Grand potential perFe","Physical μ is fixed","μ′ is independently stationary")
            occursin(term,record) || error("scan metadata does not establish the declared convention: $term")
        end
        append!(sources,(path,metadata))
        branches=joinpath(folder,channel.name*"_stationary_branches.csv")
        isfile(branches) && push!(sources,branches)
        reference_rows=filter(row->row["channel"]==channel.reference,refs)
        length(reference_rows)==channel.count || error("wrong reference point count for $(channel.reference)")
        actual0=at_field(rows,"h",0.0)
        reference0=at_field(reference_rows,"h_stagg_nominal_inferred",0.0)
        comparisons=NamedTuple[]
        for index in 0:channel.count-1
            h=index*.005
            row=at_field(rows,"h",h)
            ref=at_field(reference_rows,"h_stagg_nominal_inferred",h)
            row["channel"]==channel.name || error("wrong channel in $path")
            for (key,value) in (("U",1.0),("J",.25),("ratio",-.2),("mu",mu),
                ("physical_L",physical_L),("quadrature_order",order),("block_steps",block_steps))
                equal_parameter(row,key,value)
            end
            for (key,value) in (("U",1.0),("J",.25),("pdpi_over_pdsigma",-.2),
                ("qx_over_pi",channel.q[1]),("qy_over_pi",channel.q[2]))
                equal_parameter(ref,key,value)
            end
            gradient,density=num(row,"mu_prime_gradient"),num(row,"density")
            abs(gradient)<=GRADIENT_ATOL+1e-12 || error("μ′ stationarity fails at $(channel.name), h=$h: $gradient")
            abs(density-2)<=DENSITY_ATOL || error("half-filling check fails at $(channel.name), h=$h: $density")
            mup=num(row,"mu_prime")
            num(row,"mu_prime_lower")<mup<num(row,"mu_prime_upper") || error("stationary μ′ lies outside the reference particle interval")
            roots=integer(row,"root_count")
            roots>=0 || error("negative stationary-root count")
            # Zero roots is permitted for the stationarity solver's explicitly
            # flat interval case; it is not described as an isolated root.
            integer(row,"functional_evaluations")>0 || error("invalid functional evaluation count")
            num(row,"seconds")>=0 || error("negative scan time")
            residual=num(row,"reference_residual")
            0<=residual<=1e-9 || error("invalid/unconverged reference eigenpair residual")
            num(row,"reference_E0")
            boolean(row,"green_probe_converged") || error("Green-function probe convergence is false at $(channel.name), h=$h")
            green_error=num(row,"green_half_depth_error")
            green_error>=0 || error("negative Green-function convergence diagnostic")
            moment=num(row,"moment_signed_muB_per_Fe")
            abs(moment)<=2+1e-6 || error("magnetic moment exceeds the two-orbital per-Fe bound")
            allowance=num(ref,"Omega_extraction_allowance_abs")
            h_allowance=num(ref,"h_extraction_allowance_abs")
            allowance>0 && h_allowance>0 || error("extraction allowances must be positive")
            href=num(ref,"h_stagg_digitized")
            abs(href-h)<=h_allowance || error("nominal field differs from digitized field beyond its allowance")
            omega,published=num(row,"Omega_per_Fe"),num(ref,"Omega_published")
            difference=omega-published
            delta=omega-num(actual0,"Omega_per_Fe")
            published_delta=published-num(reference0,"Omega_published")
            delta_difference=delta-published_delta
            # Deterministic interval bounds add; they are not independent
            # Gaussian uncertainties. At h=0 the same quantity cancels exactly.
            delta_allowance=index==0 ? 0.0 : allowance+num(reference0,"Omega_extraction_allowance_abs")
            push!(comparisons,(;h,href,h_allowance,omega,published,difference,allowance,
                within_allowance=abs(difference)<=allowance,delta,published_delta,delta_difference,delta_allowance,
                delta_within_allowance=abs(delta_difference)<=delta_allowance,mup,density,gradient,
                roots,residual,green_error,moment,reference_cache=row["reference_cache"]))
        end
        push!(data,(;channel...,comparisons,mu,physical_L,order,block_steps))
    end
    return data,sources
end

function render_figures(output,data)
    settings=first(data)
    common=(;xlabel="h  [(pdσ)² / Δpd]",xlims=(-.0015,.102),xticks=0:.02:.1,
        framestyle=:box,grid=false,fontfamily="sans-serif",guidefontsize=11,tickfontsize=10,
        legendfontsize=9,titlefontsize=12,background_color=:white,
        legend_background_color=:white,legend_foreground_color=:white,
        left_margin=7Plots.mm,right_margin=4Plots.mm,bottom_margin=6Plots.mm,top_margin=4Plots.mm)
    titletext="PRL 101, 237004 · Fig. 2(b)\n2×2 open reference · $(settings.physical_L)×$(settings.physical_L) Fe lattice · μ = $(settings.mu)\nU = 1 · J = 1/4 · r = −0.2 · Weiss term h Σ η(n↑−n↓)"
    all_omega=[value for d in data for r in d.comparisons for value in (r.omega,r.published)]
    low,high=extrema(all_omega)
    margin=max(.002,.07(high-low))
    overlay=plot(;common...,title=titletext,ylabel="Ω per Fe  [(pdσ)² / Δpd]",
        ylims=(low-margin,high+margin),legend=:right,size=(920,650),dpi=220)
    for d in data
        rows=d.comparisons
        scatter!(overlay,[r.h for r in rows],[r.published for r in rows];
            marker=d.published_marker,markersize=5.2,markercolor=:white,
            markerstrokecolor="#333333",markerstrokewidth=.9,label=d.label*": published")
        plot!(overlay,[r.h for r in rows],[r.omega for r in rows];color=d.color,
            linewidth=1.7,marker=d.marker,markersize=3.2,markerstrokecolor=d.color,
            markerstrokewidth=1,markercolor=d.color,label=d.label*": VCA")
    end
    savefig(overlay,joinpath(output,"fig2b_grand_potential.png"))
    savefig(overlay,joinpath(output,"fig2b_grand_potential.pdf"))

    # Scaling by 1e5 keeps the tiny deterministic differences legible; the
    # source units and unscaled values are retained in the CSV.
    scale=1e5
    raw_extent=max(7.0,1.18maximum(scale*(abs(r.difference)+r.allowance) for d in data for r in d.comparisons))
    delta_extent=max(12.0,1.18maximum(scale*(abs(r.delta_difference)+r.delta_allowance) for d in data for r in d.comparisons))
    raw=plot(;common...,title="Absolute grand-potential comparison at fixed μ = $(settings.mu)",
        ylabel="(Ω VCA − Ω published) × 10⁵",ylims=(-raw_extent,raw_extent),legend=:outertop)
    raw_allowance=maximum(r.allowance for d in data for r in d.comparisons)
    plot!(raw,[-.0015,.102],[0.,0.];ribbon=scale*raw_allowance,fillcolor="#aab4bf",fillalpha=.27,
        linecolor="#6e7882",linewidth=.8,label=@sprintf("Vertical extraction ±%.1g",raw_allowance))
    for d in data
        plot!(raw,[r.h for r in d.comparisons],[scale*r.difference for r in d.comparisons];
            color=d.color,linewidth=1.5,marker=d.marker,markersize=3.5,markerstrokecolor=d.color,label=d.label)
    end
    relative=plot(;common...,title="Curve shape: ΔΩ(h) = Ω(h) − Ω(0), separately for each channel",
        ylabel="(ΔΩ VCA − ΔΩ published) × 10⁵",ylims=(-delta_extent,delta_extent),legend=false)
    relative_allowance=maximum(r.delta_allowance for d in data for r in d.comparisons)
    plot!(relative,[-.0015,.102],[0.,0.];ribbon=scale*relative_allowance,
        fillcolor="#aab4bf",fillalpha=.27,linecolor="#6e7882",linewidth=.8,label="")
    for d in data
        plot!(relative,[r.h for r in d.comparisons],[scale*r.delta_difference for r in d.comparisons];
            color=d.color,linewidth=1.5,marker=d.marker,markersize=3.5,markerstrokecolor=d.color,label="")
    end
    annotate!(relative,.050,delta_extent*.79,text(@sprintf("Combined vertical bound ±%.1g; h = 0 cancels exactly",relative_allowance),8,:black))
    difference=plot(raw,relative;layout=(2,1),size=(980,900),dpi=220)
    savefig(difference,joinpath(output,"fig2b_reference_difference.png"))
    savefig(difference,joinpath(output,"fig2b_reference_difference.pdf"))
end

function write_outputs(output,data,sources,input,scan_label)
    open(joinpath(output,"fig2b_comparison.csv"),"w") do io
        println(io,"channel,qx_over_pi,qy_over_pi,h_nominal,h_reference_digitized,h_extraction_allowance,U,J,ratio,physical_mu,reference_mu_prime,physical_L,quadrature_order,block_steps,Omega_VCA_per_Fe,Omega_published,Omega_difference,Omega_vertical_extraction_allowance,Omega_within_vertical_allowance,delta_Omega_VCA,delta_Omega_published,delta_Omega_difference,delta_Omega_combined_vertical_allowance,delta_Omega_within_vertical_allowance,density,density_minus_two,mu_prime_gradient,stationary_root_count,reference_eigenpair_residual,green_half_depth_error,moment_signed_muB_per_Fe,reference_cache")
        for d in data,r in d.comparisons
            println(io,join((d.name,d.q...,r.h,r.href,r.h_allowance,1.,.25,-.2,d.mu,r.mup,d.physical_L,d.order,d.block_steps,
                r.omega,r.published,r.difference,r.allowance,r.within_allowance,r.delta,r.published_delta,r.delta_difference,
                r.delta_allowance,r.delta_within_allowance,r.density,r.density-2,r.gradient,r.roots,r.residual,r.green_error,r.moment,r.reference_cache),','))
        end
    end
    open(joinpath(output,"comparison_report.md"),"w") do io
        settings=first(data)
        raw_pass=all(r.within_allowance for d in data for r in d.comparisons)
        relative_pass=all(r.delta_within_allowance for d in data for r in d.comparisons)
        println(io,"# Figure 2(b): VCA comparison\n")
        println(io,"**Absolute Ω comparison: ",raw_pass ? "all points within the vertical extraction allowance" : "one or more points outside the vertical extraction allowance",
            ". Curve-shape comparison: ",relative_pass ? "all points within the combined vertical allowance" : "one or more points outside the combined vertical allowance",".** These counts describe ordinate differences on the inferred nominal field grid; they are not an overall reproduction verdict.\n")
        println(io,"Generated ",now()," from the two completed scans in `",scan_label,"`. The reconstruction uses an open 2×2 Fe reference, original printed hoppings, U=1, J=0.25, r=−0.2, physical μ=",settings.mu," held fixed, and independently stationary μ′ at every field. Ω is per Fe; the reference Weiss term is h Σ η(n↑−n↓), with no factor one-half. The physical lattice is ",settings.physical_L,"×",settings.physical_L," Fe (",settings.physical_L÷2,"×",settings.physical_L÷2," reduced-zone nodes); quadrature order ",settings.order," and Green-function block steps ",settings.block_steps,".\n")
        println(io,"| Channel | Points | Largest absolute Ω difference | Raw points inside vertical allowance | Largest absolute ΔΩ difference | Shape points inside combined vertical allowance |\n|:---|---:|---:|---:|---:|---:|")
        for d in data
            rows=d.comparisons
            @printf(io,"| %s | %d | %.9g | %d/%d | %.9g | %d/%d |\n",d.label,length(rows),
                maximum(abs(r.difference) for r in rows),count(r.within_allowance for r in rows),length(rows),
                maximum(abs(r.delta_difference) for r in rows),count(r.delta_within_allowance for r in rows),length(rows))
        end
        println(io,"\nReference points are matched at their declared **nominal 0.005 field grid**. Raw digitized fields and horizontal ±5e−5 extraction allowances remain in [the CSV](fig2b_comparison.csv); no interpolation or field rescaling is applied. The vertical ±5e−5 allowance describes published vector-graphics extraction only. Horizontal uncertainty is reported separately, and is not propagated into an Ω tolerance: on the steep part of the curve, it can contribute additional ordinate uncertainty. Thus an outside-vertical-allowance flag alone does not establish disagreement beyond the full extraction uncertainty. These bounds also do not establish the convergence error of this solver or the authors' calculation.\n")
        println(io,"![VCA and published grand potentials](fig2b_grand_potential.png)\n\n![Absolute and relative differences](fig2b_reference_difference.png)\n")
        println(io,"For curve shape, ΔΩ(h)=Ω(h)−Ω(0) is formed separately for each computed and published channel. The conservative vertical extraction bound is the sum of the ordinate and its channel's zero-field allowance (normally ±1e−4); at h=0 both differences and their bound are exactly zero. This removes each channel's common energy baseline. At fixed density along the same stationary branch, the common −μn contribution cancels; this does not prove invariance across chemical potentials that change the density or stationary branch. No baseline subtraction is applied to the raw Ω comparison.\n")
        println(io,"| Channel | VCA Ω(0) | Published Ω(0) | Lowest sampled h (VCA / source) | VCA / source well depth Ω(0)−min Ω |\n|:---|---:|---:|:---|:---|")
        for d in data
            rows=d.comparisons
            actual=rows[argmin(r.omega for r in rows)]
            published=rows[argmin(r.published for r in rows)]
            @printf(io,"| %s | %.12f | %.12f | %.5f / %.5f | %.9g / %.9g |\n",d.label,first(rows).omega,first(rows).published,
                actual.h,published.h,first(rows).omega-actual.omega,first(rows).published-published.published)
        end
        println(io,"\nThese are extrema of the plotted samples, not refined stationary magnetic fields. The two published h=0 ordinates are retained separately; no enforced equality or fitted offset is used. The source shows the Néel branch only through h=0.02.\n")
        maxgradient=maximum(abs(r.gradient) for d in data for r in d.comparisons)
        maxdensity=maximum(abs(r.density-2) for d in data for r in d.comparisons)
        maxresidual=maximum(r.residual for d in data for r in d.comparisons)
        @printf(io,"Input checks: max |∂Ω/∂μ′|=%.6g (limit 1e−7 plus 1e−12 rounding); max |n−2|=%.6g (limit 1e−6); largest recorded reference residual %.6g (reader limit 1e−9). All Green-function probe-convergence flags are true. These reader checks do not replace independent particle-sector, quadrature, embedding-grid, or Green-function-depth audits.\n\n",maxgradient,maxdensity,maxresidual)
        println(io,"The script follows the scan's selected stationary branch; multiple roots and possible flat intervals are retained in the scan artifacts and are not reclassified by this plotter. It does not search for additional branches, certify that the reference is the absolute grand-canonical ground state, or prove that all VCA approximations have converged.\n")
        println(io,"The PRL does not specify the reference-cluster size, the precise h operator, Ω per-Fe normalization, or its μ/μ′ procedure in full. These are explicitly declared reconstruction choices supported by the cited methods and related authors' calculations; physical μ is not quoted from the PRL. See [the source audit](",joinpath(ROOT,"docs","prl_101_237004_vca_reference.md"),"). This comparison concerns Figure 2(b) only; it does not complete Figure 2(c) or subsequent milestones.\n")
        println(io,"Recreate after both completed scan CSVs and metadata exist:\n\n```bash\njulia --project=. scripts/plot_prl_101_237004_fig2b.jl\n```\n\nUse `--input-root=PATH --scan-label=NAME --output-dir=PATH` to select another completed campaign. Expected settings can be declared with `--mu=0.85 --physical-L=48 --quadrature-order=24 --block-steps=48`. Existing output is preserved unless `--overwrite` is supplied.")
    end
    open(joinpath(output,"provenance.txt"),"w") do io
        println(io,"Generated: ",now(),"; Julia: ",VERSION)
        println(io,"Input root: ",abspath(input),"; scan label: ",scan_label)
        println(io,"Input and postprocessor SHA-256:")
        for source in sort(unique(sources))
            println(io,bytes2hex(open(sha256,source)),"  ",abspath(source))
        end
        println(io,"Output SHA-256:")
        for name in sort(readdir(output))
            name=="provenance.txt" && continue
            println(io,bytes2hex(open(sha256,joinpath(output,name))),"  ",name)
        end
    end
end

function main(arguments=ARGS)
    options=Dict("input-root"=>DEFAULT_INPUT,"scan-label"=>"fig2b_L48_q24","output-dir"=>"",
        "reference"=>DEFAULT_REFERENCE,"mu"=>"0.85","physical-L"=>"48","quadrature-order"=>"24","block-steps"=>"48")
    overwrite=false
    for argument in arguments
        if argument=="--overwrite"
            overwrite=true
        elseif argument=="--help"
            println("Usage: julia --project=. scripts/plot_prl_101_237004_fig2b.jl [--input-root=DIR] [--scan-label=NAME] [--output-dir=DIR] [--reference=CSV] [--mu=0.85] [--physical-L=48] [--quadrature-order=24] [--block-steps=48] [--overwrite]")
            println("Requires complete stripe_y.csv (21 fields), neel.csv (5 fields), and scan metadata. Writes raw Ω overlay, raw/relative differences (PNG/PDF), comparison CSV/report, and provenance. No simulation is run.")
            return nothing
        else
            startswith(argument,"--") && occursin('=',argument) || error("use --key=value")
            key,value=split(argument[3:end],'=';limit=2)
            haskey(options,key) || error("unknown option --$key")
            options[key]=value
        end
    end
    input=abspath(options["input-root"])
    output=isempty(options["output-dir"]) ? joinpath(input,"plots") : abspath(options["output-dir"])
    isfile(output) && error("output is a file")
    isdir(output) && !isempty(readdir(output)) && !overwrite && error("output exists; choose a fresh directory or use --overwrite")
    data,sources=collect_comparison(input,options["scan-label"],abspath(options["reference"]);
        mu=parse(Float64,options["mu"]),physical_L=parse(Int,options["physical-L"]),
        order=parse(Int,options["quadrature-order"]),block_steps=parse(Int,options["block-steps"]))
    mkpath(dirname(output))
    staging=mktempdir(dirname(output);prefix="fig2b_staging_")
    try
        ENV["GKSwstype"]="100"
        @eval using Plots
        Base.invokelatest(render_figures,staging,data)
        write_outputs(staging,data,sources,input,options["scan-label"])
        if isdir(output)
            for name in readdir(staging)
                mv(joinpath(staging,name),joinpath(output,name);force=overwrite)
            end
        else
            mv(staging,output)
        end
    finally
        isdir(staging) && rm(staging;recursive=true)
    end
    println("Figure 2(b) comparison saved to ",output)
    for d in data
        @printf("%s: raw Ω %d/%d within vertical allowance; ΔΩ %d/%d within combined vertical allowance.\n",d.label,
            count(r.within_allowance for r in d.comparisons),length(d.comparisons),
            count(r.delta_within_allowance for r in d.comparisons),length(d.comparisons))
    end
    return output
end

end

if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Fig2bPlot.main()
end
