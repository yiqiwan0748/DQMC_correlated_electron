#!/usr/bin/env julia
module PRL101237004Fig2cPlot

using Printf, SHA, Dates
include("plot_prl_101_237004_fig2a.jl")
const CSV = PRL101237004Fig2aPlot
const ROOT = normpath(joinpath(@__DIR__,".."))
const DEFAULT_INPUT = joinpath(ROOT,"results","prl_101_237004","fig2c")
const DEFAULT_REFERENCE = joinpath(ROOT,"results","prl_101_237004","fig2c_reference","fig2c_digitized.csv")
const U_GRID = (.5,.75,1.,2.,4.)
const CURVES = ((name="r_minus_0p2",ratio=-.2,label="r = −0.2",color="#2457c5",
                 marker=:circle,source_marker=:xcross,linestyle=:solid),
                (name="r_minus_0p5",ratio=-.5,label="r = −0.5",color="#c93636",
                 marker=:rect,source_marker=:circle,linestyle=:dash))
const SCAN_COLUMNS = ("ratio","U","J","h","mu","mu_prime","Omega_per_Fe","F_per_Fe",
    "density","moment_abs_muB_per_Fe","moment_signed_muB_per_Fe","mu_prime_gradient",
    "h_derivative","stationarity_status","reference_cache","physical_L","quadrature_order",
    "block_steps","zero_field_F","energy_gain")
const PARAMETER_ATOL = 1e-12
const DENSITY_ATOL = 1e-7
const MU_GRADIENT_ATOL = 1e-7
const DEFAULT_H_DERIVATIVE_ATOL = 2.1e-6
const THERMODYNAMIC_ATOL = 1e-9

num(row,key) = CSV.number(row,key)
function integer(row,key)
    value=num(row,key)
    isinteger(value) || error("$key must be an integer")
    Int(value)
end
function boolean(row,key)
    value=lowercase(row[key])
    value in ("true","false") || error("$key must be true or false")
    value=="true"
end
function equal_parameter(row,key,value)
    abs(num(row,key)-value)<=PARAMETER_ATOL || error("expected $key=$value; received $(row[key])")
end
function at_U(rows,key,U)
    found=filter(row->abs(num(row,key)-U)<=PARAMETER_ATOL,rows)
    length(found)==1 || error("expected exactly one $key=$U row; found $(length(found))")
    only(found)
end
function positive_orders(values,label)
    isempty(values) && error("$label must not be empty")
    all(x->x isa Integer && x>0,values) || error("$label must contain positive integers")
    length(unique(values))==length(values) || error("$label contains duplicate declarations")
end

"""Identify the recorded finite-difference convention from a point's frozen
driver and field helper. A standalone CSV may lack these snapshots; report
that explicitly instead of guessing the convention from quadrature order.
"""
function field_difference_method(input,curve,U,sources)
    directory=joinpath(input,"runs",curve,"U"*string(Float64(U)))
    snapshot=joinpath(directory,"source_snapshot")
    isdir(snapshot) || return "unspecified_missing_point_snapshot"
    resolved_driver="scripts/run_prl_101_237004_fig2c_resolved.jl"
    canonical_field="scripts/prl_101_237004_fig2c_canonical_field.jl"
    original_driver="scripts/run_prl_101_237004_fig2c.jl"
    original_field="scripts/prl_101_237004_fig2c_field.jl"
    resolved=isfile(joinpath(snapshot,resolved_driver))
    resolved==isfile(joinpath(snapshot,canonical_field)) || error("incomplete canonical-field snapshot at $directory")
    method,selected=resolved ?
        ("central_F_resolved_half_filling_mu_prime",(resolved_driver,canonical_field)) :
        ("central_Omega_held_mu_mu_prime",(original_driver,original_field))
    provenance=joinpath(directory,"provenance.txt")
    isfile(provenance) || error("missing point provenance for field-difference convention")
    records=Dict{String,String}()
    for line in readlines(provenance)
        found=match(r"^([0-9a-f]{64})  ((?:scripts|src)/.+)$",line)
        found===nothing && continue
        haskey(records,found[2]) && error("duplicate point source hash")
        records[found[2]]=found[1]
    end
    for source in selected
        path=joinpath(snapshot,source)
        isfile(path) && haskey(records,source) || error("incomplete field-difference provenance: $source")
        bytes2hex(open(sha256,path))==records[source] || error("field-difference snapshot hash differs: $source")
        push!(sources,path)
    end
    push!(sources,provenance)
    method
end

"""Read only completed five-point CSVs; compare raw moments without fitting.
The nominal source U grid is inferred from the PDF and retained alongside
its digitized abscissae. No incomplete .progress file is consumed.
"""
function collect_comparison(input,reference;physical_L=48,quadrature_orders=(24,),
                            block_steps=(48,),h_derivative_atol=DEFAULT_H_DERIVATIVE_ATOL)
    physical_L>=2 && iseven(physical_L) || error("physical lattice size must be positive and even")
    positive_orders(quadrature_orders,"quadrature orders")
    positive_orders(block_steps,"block steps")
    isfinite(h_derivative_atol) && h_derivative_atol>0 || error("invalid field-derivative tolerance")
    refs=CSV.read_scalar_csv(reference,("pdpi_over_pdsigma","U_nominal_inferred","U_digitized",
        "J_over_U","J_nominal","moment_muB_per_Fe","U_extraction_allowance_abs",
        "moment_extraction_allowance_abs","moment_compatible_with_zero_within_extraction_allowance",
        "source_small_U_warning_for_ratio"))
    length(refs)==10 || error("expected exactly ten Figure 2(c) source points")
    data=NamedTuple[]
    sources=String[abspath(reference),abspath(@__FILE__),joinpath(@__DIR__,"plot_prl_101_237004_fig2a.jl")]
    for curve in CURVES
        # The final named CSV is the completion marker; partial files and
        # unresolved status rows cannot produce a final comparison.
        path=joinpath(input,"scans",curve.name*".csv")
        rows=CSV.read_scalar_csv(path,SCAN_COLUMNS)
        length(rows)==length(U_GRID) || error("$(curve.name) requires exactly five completed U points")
        push!(sources,path)
        point_sources=path*".point_sources.txt"
        isfile(point_sources) && push!(sources,point_sources)
        reference_rows=filter(row->abs(num(row,"pdpi_over_pdsigma")-curve.ratio)<=PARAMETER_ATOL,refs)
        length(reference_rows)==length(U_GRID) || error("wrong reference point count for r=$(curve.ratio)")
        comparisons=NamedTuple[]
        for U in U_GRID
            row=at_U(rows,"U",U)
            ref=at_U(reference_rows,"U_nominal_inferred",U)
            equal_parameter(row,"ratio",curve.ratio)
            equal_parameter(row,"J",U/4)
            equal_parameter(ref,"J_nominal",U/4)
            equal_parameter(ref,"J_over_U",.25)
            L=integer(row,"physical_L")
            L==physical_L || error("undeclared physical lattice L=$L")
            order=integer(row,"quadrature_order")
            order in quadrature_orders || error("undeclared quadrature order $order")
            steps=integer(row,"block_steps")
            steps in block_steps || error("undeclared Green-function block steps $steps")
            density=num(row,"density")
            abs(density-2)<=DENSITY_ATOL+1e-12 || error("half filling fails at r=$(curve.ratio), U=$U")
            mugradient=num(row,"mu_prime_gradient")
            abs(mugradient)<=MU_GRADIENT_ATOL+1e-12 || error("μ′ stationarity fails at r=$(curve.ratio), U=$U")
            hgradient=num(row,"h_derivative")
            abs(hgradient)<=h_derivative_atol || error("field derivative exceeds declared tolerance at r=$(curve.ratio), U=$U")
            h,mu,mup=num(row,"h"),num(row,"mu"),num(row,"mu_prime")
            h>=0 || error("expected the nonnegative field representative")
            omega,F=num(row,"Omega_per_Fe"),num(row,"F_per_Fe")
            abs(F-(omega+2mu))<=THERMODYNAMIC_ATOL || error("F must equal Ω+2μ per Fe at half filling")
            zero_F,gain=num(row,"zero_field_F"),num(row,"energy_gain")
            abs(gain-(zero_F-F))<=THERMODYNAMIC_ATOL || error("energy_gain must equal zero_field_F−F")
            gain>=-THERMODYNAMIC_ATOL || error("selected minimum lies above the recorded zero-field F")
            moment,signed=num(row,"moment_abs_muB_per_Fe"),num(row,"moment_signed_muB_per_Fe")
            0<=moment<=2+1e-7 || error("moment exceeds the two-orbital μB-per-Fe bounds")
            abs(moment-abs(signed))<=1e-9 || error("absolute and signed moments are inconsistent")
            status=row["stationarity_status"]
            status in ("magnetic_minimum","paramagnetic_minimum") || error("unresolved or unknown stationarity status: $status")
            if status=="paramagnetic_minimum"
                h<=1e-12 && moment<=1e-7+1e-12 || error("paramagnetic minimum must have h≈0 and m≈0")
                abs(gain)<=THERMODYNAMIC_ATOL || error("paramagnetic minimum must coincide with the zero-field baseline")
            else
                h>0 && moment>0 || error("magnetic minimum needs a nonzero field and moment")
            end
            isempty(row["reference_cache"]) && error("missing reference-cache provenance")
            source_U=num(ref,"U_digitized")
            U_allowance=num(ref,"U_extraction_allowance_abs")
            allowance=num(ref,"moment_extraction_allowance_abs")
            U_allowance>0 && allowance>0 || error("reference extraction allowances must be positive")
            abs(U-source_U)<=U_allowance || error("nominal source U lies outside its horizontal allowance")
            published=num(ref,"moment_muB_per_Fe")
            zero_compatible=boolean(ref,"moment_compatible_with_zero_within_extraction_allowance")
            zero_compatible==(abs(published)<=allowance) || error("source zero-compatibility flag is inconsistent")
            small_U_warning=boolean(ref,"source_small_U_warning_for_ratio")
            small_U_warning==(curve.ratio==-.2) || error("source small-U caveat is inconsistent")
            difference=moment-published
            difference_method=field_difference_method(input,curve.name,U,sources)
            push!(comparisons,(;U,source_U,U_allowance,published,allowance,moment,signed,difference,
                within_vertical_allowance=abs(difference)<=allowance,zero_compatible,small_U_warning,
                h,mu,mup,omega,F,zero_F,gain,density,mugradient,hgradient,status,L,order,steps,
                reference_cache=row["reference_cache"],field_difference_method=difference_method))
        end
        push!(data,(;curve...,comparisons))
    end
    return data,sources
end

function render_figures(output,data)
    L=first(first(data).comparisons).L
    common=(;xlabel="U  [(pdσ)² / Δpd]",xlims=(0.,4.08),xticks=0:.5:4,
        framestyle=:box,grid=false,fontfamily="sans-serif",guidefontsize=11,tickfontsize=10,
        legendfontsize=9,titlefontsize=12,background_color=:white,
        legend_background_color=:white,legend_foreground_color=:white,
        left_margin=7Plots.mm,right_margin=4Plots.mm,bottom_margin=7Plots.mm,top_margin=4Plots.mm)
    overlay=plot(;common...,title="PRL 101, 237004 · Fig. 2(c)\nStripe moment · J = U/4 · 2×2 reference · $(L)×$(L) Fe lattice",
        ylabel="|m staggered|  [μB per Fe; g = 2]",ylims=(-.035,2.07),
        legend=:right,size=(940,680),dpi=220)
    for d in data
        rows=d.comparisons
        scatter!(overlay,[r.U for r in rows],[r.published for r in rows];
            marker=d.source_marker,markersize=6,
            markercolor=(d.source_marker==:xcross ? "#303030" : :white),
            markerstrokecolor="#303030",markerstrokewidth=1.3,label=d.label*": published")
        plot!(overlay,[r.U for r in rows],[r.moment for r in rows];color=d.color,
            linestyle=d.linestyle,linewidth=1.9,marker=d.marker,markersize=3.5,
            markerstrokecolor=d.color,markercolor=d.color,label=d.label*": VCA")
    end
    annotate!(overlay,2.65,.23,text("Source: small-U r = −0.2 numerically unstable\n(range unspecified); no source samples below U = 0.5",9,:black))
    savefig(overlay,joinpath(output,"fig2c_staggered_moment.png"))
    savefig(overlay,joinpath(output,"fig2c_staggered_moment.pdf"))
    scale=1e3
    extent=max(3.,1.2maximum(scale*(abs(r.difference)+r.allowance) for d in data for r in d.comparisons))
    difference=plot(;common...,title="Moment difference on the inferred nominal U grid\nNo fitted scale or offset; horizontal source uncertainty reported separately",
        ylabel="(m VCA − m published) × 10³  [μB/Fe]",ylims=(-extent,extent),
        legend=:outertop,size=(940,640),dpi=220)
    allowance=maximum(r.allowance for d in data for r in d.comparisons)
    plot!(difference,[0.,4.08],[0.,0.];ribbon=scale*allowance,
        linecolor="#6e7882",linewidth=.8,fillcolor="#aab4bf",fillalpha=.27,
        label=@sprintf("Vertical extraction ±%.3g μB/Fe",allowance))
    for d in data
        plot!(difference,[r.U for r in d.comparisons],[scale*r.difference for r in d.comparisons];
            color=d.color,linestyle=d.linestyle,linewidth=1.7,marker=d.marker,
            markersize=4,markerstrokecolor=d.color,label=d.label)
    end
    savefig(difference,joinpath(output,"fig2c_reference_difference.png"))
    savefig(difference,joinpath(output,"fig2c_reference_difference.pdf"))
end

function write_outputs(output,data,sources,input;h_derivative_atol,quadrature_orders,block_steps)
    open(joinpath(output,"fig2c_comparison.csv"),"w") do io
        println(io,"ratio,U_nominal,U_reference_digitized,U_extraction_allowance,J,moment_VCA_muB_per_Fe,moment_published_muB_per_Fe,moment_difference_muB_per_Fe,moment_vertical_extraction_allowance,within_vertical_allowance,source_moment_zero_compatible,source_small_U_warning_for_ratio,h,mu,mu_prime,Omega_per_Fe,F_per_Fe,zero_field_F,energy_gain,density,mu_prime_gradient,h_derivative,stationarity_status,physical_L,quadrature_order,block_steps,reference_cache,field_difference_method")
        for d in data,r in d.comparisons
            println(io,join((d.ratio,r.U,r.source_U,r.U_allowance,r.U/4,r.moment,r.published,r.difference,
                r.allowance,r.within_vertical_allowance,r.zero_compatible,r.small_U_warning,
                r.h,r.mu,r.mup,r.omega,r.F,r.zero_F,r.gain,r.density,r.mugradient,r.hgradient,
                r.status,r.L,r.order,r.steps,r.reference_cache,r.field_difference_method),','))
        end
    end
    open(joinpath(output,"comparison_report.md"),"w") do io
        println(io,"# Figure 2(c): staggered-moment comparison\n")
        total=sum(length(d.comparisons) for d in data)
        inside=sum(count(r.within_vertical_allowance for r in d.comparisons) for d in data)
        println(io,"**",inside,"/",total," raw moment differences lie within the vertical graphics-extraction allowance.** This is a pointwise ordinate check on the inferred nominal U grid, not an overall reproduction verdict.\n")
        println(io,"Generated ",now()," from the completed five-point scans for each ratio. The plotted U values are 0.5, 0.75, 1, 2, 4, with J=U/4 and the original printed Slater–Koster hopping formulas. No moment rescaling, offset, smoothing, or extrapolation below U=0.5 is applied. Lines connect the computed samples only.\n")
        println(io,"| Ratio | Max absolute moment difference (μB/Fe) | Inside vertical allowance | Quadrature orders used | Green block steps used |\n|:---|---:|---:|:---|:---|")
        for d in data
            rows=d.comparisons
            @printf(io,"| %s | %.9g | %d/%d | %s | %s |\n",d.label,
                maximum(abs(r.difference) for r in rows),count(r.within_vertical_allowance for r in rows),length(rows),
                join(sort(unique(r.order for r in rows)),", "),join(sort(unique(r.steps for r in rows)),", "))
        end
        println(io,"\nThe source provides moments in Bohr magnetons per Fe. This reconstruction uses the magnitude of the physical-lattice staggered spin polarization, summed over both orbitals: m/μB=|Σᵢα ηᵢ〈nᵢα↑−nᵢα↓〉|/N_Fe, with spin-only g=2. The saturation bound is 2 μB/Fe. The variational Weiss field and isolated-cluster moment are different quantities. The calculation uses an open 2×2 Fe reference and a ",first(first(data).comparisons).L,"×",first(first(data).comparisons).L," physical Fe lattice; the exact cluster and optimization conventions are reconstruction choices, not fully specified by the short PRL.\n")
        println(io,"![Published and computed moments](fig2c_staggered_moment.png)\n\n![Pointwise moment differences](fig2c_reference_difference.png)\n")
        println(io,"The [comparison CSV](fig2c_comparison.csv) retains both nominal and digitized U, horizontal and vertical extraction allowances, moments, stationarity quantities, and selected phases. The source allowances are ±0.001 in U and ±0.002 μB/Fe in m. Horizontal uncertainty is not folded into the vertical count, and may contribute additional ordinate uncertainty where the curve is steep. Neither allowance estimates solver error or the authors' numerical error.\n")
        println(io,"The PRL caption explicitly warns that the small-U r=−0.2 region was numerically unstable, without giving a numerical boundary. No missing small-U values are supplied by this comparison. The dashed source curve denotes r=−0.5 throughout; it is not an instability marker. Its U=0.5 ordinate is about 0.00094 μB/Fe and is compatible with zero at extraction precision, so it does not resolve a tiny magnetic moment or an exact transition point.\n")
        println(io,"| Ratio | U | Published m | VCA m | Difference | Selected status | h | Energy gain F(0)−F |\n|:---|---:|---:|---:|---:|:---|---:|---:|")
        for d in data,r in d.comparisons
            @printf(io,"| %.1f | %.2f | %.9f | %.9f | %+.6g | %s | %.9g | %.9g |\n",d.ratio,r.U,r.published,r.moment,r.difference,r.status,r.h,r.gain)
        end
        println(io,"\nThe selected status is read from the scan; the plotter accepts only `magnetic_minimum` or `paramagnetic_minimum`. It rejects incomplete grids, duplicate U, unknown or unresolved statuses, nonfinite values, undeclared numerical settings, inconsistent moment magnitudes, and inconsistent F=Ω+2μ or energy-gain records. These checks do not independently prove a global minimum or exclude additional stationary branches.\n")
        maxdensity=maximum(abs(r.density-2) for d in data for r in d.comparisons)
        maxmu=maximum(abs(r.mugradient) for d in data for r in d.comparisons)
        maxh=maximum(abs(r.hgradient) for d in data for r in d.comparisons)
        @printf(io,"Recorded search checks: max |n−2|=%.6g; max |∂Ω/∂μ′|=%.6g (each reader limit 1e−7 plus 1e−12 rounding); max |h derivative|=%.6g (declared reader limit %.6g). The h derivative is the search's central finite difference with step 2e−4. Independent derivative-step or quadrature refinements belong in separate audits and are not silently substituted for the recorded search derivative.\n\n",maxdensity,maxmu,maxh,h_derivative_atol)
        println(io,"The comparison CSV records `field_difference_method` per point, identified from its hashed frozen driver and field-helper snapshot. `central_Omega_held_mu_mu_prime` evaluates Ω at h±2e−4 with both center chemical potentials held fixed. `central_F_resolved_half_filling_mu_prime` evaluates F=Ω+2μ at h±2e−4 after solving density=2 and μ′ stationarity independently on each side; its filling solver also permits a canonical ensemble of a partially occupied degenerate Fermi shell. The original derivative has its envelope interpretation on a smooth stationary branch; it is not substituted for the canonical derivative at a shell boundary.\n")
        println(io,"| Recorded field-difference method | Points |\n|:---|---:|")
        methods=sort(unique(r.field_difference_method for d in data for r in d.comparisons))
        for method in methods
            println(io,"| `",method,"` | ",sum(count(r.field_difference_method==method for r in d.comparisons) for d in data)," |")
        end
        if "unspecified_missing_point_snapshot" in methods
            println(io,"\nSome input points lack individual source snapshots, so their field-difference method is explicitly unverified; it is not inferred from the numerical order or phase label.")
        end
        println(io)
        println(io,"The reader's allowed quadrature orders are ",join(quadrature_orders,", ")," and allowed Green block depths are ",join(block_steps,", "),". Actual settings are retained per point. These postprocessing checks do not replace particle-sector, half-filling, field-minimum, frequency-grid, lattice-grid, or Green-function-depth validation. Physical μ may vary across U and r; the recorded canonical energy is F=Ω+2μ per Fe.\n")
        if any(endswith(source,".point_sources.txt") for source in sources)
            println(io,"The scan's available `.point_sources.txt` records are included in the plot provenance hashes. They preserve the selected points' individual driver/source records when original, adaptive, and resolved filling searches occur in one curve. The plotter does not change or rerun those searches.\n")
        end
        println(io,"See [the supplied-paper source audit](",joinpath(ROOT,"docs","prl_101_237004_fig2c_reference.md"),") for extraction and normalization details. This comparison concerns Fig. 2(c); it makes no claim about later spectral or pairing panels.\n")
        println(io,"Recreate after both final scan CSVs exist:\n\n```bash\njulia --project=. scripts/plot_prl_101_237004_fig2c.jl --quadrature-orders=",join(quadrature_orders,',')," --block-steps=",join(block_steps,','),"\n```\n\nSelect paths with `--input-root=PATH --reference=CSV --output-dir=PATH`. Declare expected settings with `--physical-L=48 --quadrature-orders=24,48 --block-steps=48`; comma-separated order/depth lists admit explicitly qualified mixed settings. The default `--h-derivative-atol=2.1e-6` can be changed explicitly. Existing output is preserved unless `--overwrite` is supplied.")
    end
    open(joinpath(output,"provenance.txt"),"w") do io
        println(io,"Generated: ",now(),"; Julia: ",VERSION)
        println(io,"Input root: ",abspath(input))
        println(io,"Input and postprocessor SHA-256:")
        for source in sort(unique(sources))
            println(io,bytes2hex(open(sha256,source)),"  ",abspath(source))
        end
        println(io,"Output SHA-256:")
        for name in sort(readdir(output))
            name=="provenance.txt" && continue
            println(io,bytes2hex(open(sha256,joinpath(output,name))),"  ",name)
        end
    end
end

function main(arguments=ARGS)
    options=Dict("input-root"=>DEFAULT_INPUT,"reference"=>DEFAULT_REFERENCE,"output-dir"=>"",
        "physical-L"=>"48","quadrature-orders"=>"24","block-steps"=>"48","h-derivative-atol"=>"2.1e-6")
    overwrite=false
    for argument in arguments
        if argument=="--overwrite"
            overwrite=true
        elseif argument=="--help"
            println("Usage: julia --project=. scripts/plot_prl_101_237004_fig2c.jl [--input-root=DIR] [--reference=CSV] [--output-dir=DIR] [--physical-L=48] [--quadrature-orders=24] [--block-steps=48] [--h-derivative-atol=2.1e-6] [--overwrite]")
            println("Requires both final five-point scans. Writes raw moment overlay and difference PNG/PDF, comparison CSV/report, and provenance. Order/depth lists may be comma-separated. No simulation is run.")
            return nothing
        else
            startswith(argument,"--") && occursin('=',argument) || error("use --key=value")
            key,value=split(argument[3:end],'=';limit=2)
            haskey(options,key) || error("unknown option --$key")
            options[key]=value
        end
    end
    input=abspath(options["input-root"])
    output=isempty(options["output-dir"]) ? joinpath(input,"plots") : abspath(options["output-dir"])
    isfile(output) && error("output is a file")
    isdir(output) && !isempty(readdir(output)) && !overwrite && error("output exists; choose a fresh directory or use --overwrite")
    orders=parse.(Int,split(options["quadrature-orders"],','))
    depths=parse.(Int,split(options["block-steps"],','))
    h_atol=parse(Float64,options["h-derivative-atol"])
    data,sources=collect_comparison(input,abspath(options["reference"]);
        physical_L=parse(Int,options["physical-L"]),quadrature_orders=orders,block_steps=depths,h_derivative_atol=h_atol)
    mkpath(dirname(output))
    staging=mktempdir(dirname(output);prefix="fig2c_staging_")
    try
        ENV["GKSwstype"]="100"
        @eval using Plots
        Base.invokelatest(render_figures,staging,data)
        write_outputs(staging,data,sources,input;h_derivative_atol=h_atol,quadrature_orders=orders,block_steps=depths)
        if isdir(output)
            for name in readdir(staging)
                mv(joinpath(staging,name),joinpath(output,name);force=overwrite)
            end
        else
            mv(staging,output)
        end
    finally
        isdir(staging) && rm(staging;recursive=true)
    end
    println("Figure 2(c) comparison saved to ",output)
    for d in data
        @printf("%s: %d/%d inside vertical allowance; max absolute moment difference %.9g μB/Fe.\n",
            d.label,count(r.within_vertical_allowance for r in d.comparisons),length(d.comparisons),
            maximum(abs(r.difference) for r in d.comparisons))
    end
    return output
end

end

if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Fig2cPlot.main()
end
