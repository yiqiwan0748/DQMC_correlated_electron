#!/usr/bin/env julia
module PRL101237004Fig3Plot

using Plots, SHA, TOML, Dates, Printf
const ROOT=normpath(joinpath(@__DIR__,".."))
const DEFAULT_INPUT=joinpath(ROOT,"results","prl_101_237004","fig3")
const CASES=("blue_U0","blue_U0p5","blue_U1","blue_U2","red_U1")
filehash(path)=bytes2hex(open(sha256,path))

function numeric_csv(path)
    lines=readlines(path)
    names=split(first(lines),',')
    data=Matrix{Float64}(undef,length(lines)-1,length(names))
    for i in 2:length(lines)
        values=split(lines[i],',')
        length(values)==length(names) || error("malformed numeric CSV: $path")
        data[i-1,:].=parse.(Float64,values)
    end
    names,data
end

function load_data(input)
    completed=TOML.parsefile(joinpath(input,"completed.toml"))
    completed["status"]=="spectral_grids_computed" || error("incomplete spectral production")
    paths=String[joinpath(input,"completed.toml"),joinpath(input,"configuration.toml")]
    records=Dict{String,Any}()
    for name in CASES
        folder=joinpath(input,"cases",name)
        marker=joinpath(folder,"completed.toml")
        filehash(marker)==completed["case_completion_sha256"][name] || error("case completion hash differs")
        record=TOML.parsefile(marker)
        for (file,hash) in record["output_sha256"]
            target=joinpath(folder,file)
            filehash(target)==hash || error("production input hash differs: $target")
            push!(paths,target)
        end
        push!(paths,marker)
        _,dos=numeric_csv(joinpath(folder,"dos.csv"))
        records[name]=Dict{String,Any}("dos"=>dos,"parameters"=>TOML.parsefile(joinpath(folder,"parameters.toml")))
        if isfile(joinpath(folder,"path.csv"))
            _,matrix=numeric_csv(joinpath(folder,"path.csv"))
            omega=sort(unique(matrix[:,5])); coord=sort(unique(matrix[:,2]))
            length(omega)*length(coord)==size(matrix,1) || error("incomplete path grid")
            records[name]["omega"]=omega
            records[name]["coordinate"]=coord
            records[name]["A"]=reshape(matrix[:,6],length(omega),length(coord))
        end
        if isfile(joinpath(folder,"fermi_intensity.csv"))
            _,matrix=numeric_csv(joinpath(folder,"fermi_intensity.csv"))
            axis=sort(unique(matrix[:,3]))
            n=length(axis)
            n*n==size(matrix,1) || error("incomplete Fermi-intensity grid")
            records[name]["fs_axis"]=axis
            records[name]["fs_raw"]=reshape(matrix[:,5],n,n)
            records[name]["fs_C4"]=reshape(matrix[:,6],n,n)
        end
    end
    records,paths
end

const PATH_TICKS=([0.,1.,2.,3.,4.],["(0, π)","(π, π)","(0, 0)","(0, π)","(π, 0)"])
function ridges(data,title)
    omega,coordinate,A=data["omega"],data["coordinate"],data["A"]
    p=plot(;title,xlabel="ω − μ  [(pdσ)² / Δpd]",ylabel="Momentum path",
        xlims=extrema(omega),ylims=(-.07,4.36),yticks=PATH_TICKS,
        legend=false,grid=false,framestyle=:box)
    vline!(p,[0.];color="#b83f38",linewidth=.8,linestyle=:dash)
    # Uniform display gain for both panels, unrelated to fitting the paper.
    # 49 traces (12 intervals per segment) are a declared rendering choice;
    # the paper's 48 trace momenta are not specified numerically.
    indices=round.(Int,range(1,length(coordinate);length=49))
    for j in indices
        plot!(p,omega,coordinate[j].+.013A[:,j];fillrange=coordinate[j],
            fillcolor=:white,fillalpha=1,color="#202630",linewidth=.7)
    end
    p
end

function heatmap_path(data,title,maximum_intensity)
    heatmap(data["omega"],data["coordinate"],permutedims(data["A"]);
        title,xlabel="ω − μ  [(pdσ)² / Δpd]",ylabel="Momentum path",yticks=PATH_TICKS,
        color=:inferno,clims=(0.,maximum_intensity),colorbar_title="A  [states / Fe / energy]",
        xlims=extrema(data["omega"]),ylims=(0.,4.),grid=false,framestyle=:box)
end

function fs_panel(data,symmetric,title;maximum_intensity=nothing)
    axis=data["fs_axis"]./pi
    raw=data[symmetric ? "fs_C4" : "fs_raw"]
    # Close periodic endpoints for display only; raw CSV omits duplicate edges.
    closed=[raw raw[:,1];transpose(raw[1,:]) raw[1,1]]
    x=vcat(axis,1.)
    maximum_intensity===nothing && (maximum_intensity=maximum(raw))
    heatmap(x,x,permutedims(closed);title,xlabel="kₓ / π",ylabel="kᵧ / π",
        xlims=(-1.,1.),ylims=(-1.,1.),xticks=[-1.,0.,1.],yticks=[-1.,0.,1.],
        color=:inferno,clims=(0.,maximum_intensity),aspect_ratio=:equal,
        colorbar_title="A(k, 0)  [states / Fe / energy]",grid=false,framestyle=:box)
end

function render(;input=DEFAULT_INPUT,output=joinpath(input,"plots"))
    records,sources=load_data(input)
    any(isfile(joinpath(output,file)) for file in ("fig3_reconstruction.png","provenance.toml")) &&
        error("plot output exists; choose a fresh output directory")
    mkpath(output)
    default(fontfamily="sans-serif",guidefontsize=10,tickfontsize=9,titlefontsize=11,
        legendfontsize=9,background_color=:white,left_margin=7Plots.mm,
        right_margin=5Plots.mm,top_margin=5Plots.mm,bottom_margin=6Plots.mm)
    a=ridges(records["blue_U0p5"],"(a) r = −0.2 · U = 0.5 · J = 0.125")
    b=ridges(records["red_U1"],"(b) r = −0.5 · U = 1 · J = 0.25")
    c=plot(;title="(c) Density of states · r = −0.2 · J = U/4",
        xlabel="ω − μ  [(pdσ)² / Δpd]",ylabel="DOS  [states / Fe / energy]",
        xlims=(-3.,3.),ylims=(0.,4.),legend=:topright,grid=false,framestyle=:box)
    for (name,label,color,style) in (("blue_U0","U = 0","#303030",:solid),
        ("blue_U0p5","U = 0.5","#2457c5",:dash),
        ("blue_U1","U = 1","#c93636",:dot),
        ("blue_U2","U = 2","#27833b",:dashdot))
        dos=records[name]["dos"]
        plot!(c,dos[:,1],dos[:,2];label,color,linestyle=style,linewidth=1.8)
    end
    vline!(c,[0.];label=false,color="#777777",linestyle=:dash,linewidth=.7)
    d=fs_panel(records["blue_U0p5"],true,"(d) Fermi-level intensity · equal C₄ average")
    main=plot(a,b,c,d;layout=(2,2),size=(1400,1060),dpi=200,
        plot_title="PRL 101, 237004 · Fig. 3 reconstruction · η = 0.05",
        plot_titlefontsize=14)
    savefig(main,joinpath(output,"fig3_reconstruction.png"))
    savefig(main,joinpath(output,"fig3_reconstruction.pdf"))
    limit=maximum(maximum(records[name]["A"]) for name in ("blue_U0p5","red_U1"))
    heat=plot(heatmap_path(records["blue_U0p5"],"(a) r = −0.2 · U = 0.5",limit),
        heatmap_path(records["red_U1"],"(b) r = −0.5 · U = 1",limit);
        layout=(1,2),size=(1300,670),dpi=200,plot_title="The same spectral data, without vertical offsets")
    savefig(heat,joinpath(output,"fig3_spectral_heatmaps.png"))
    savefig(heat,joinpath(output,"fig3_spectral_heatmaps.pdf"))
    fs=records["blue_U0p5"]
    lim=maximum(fs["fs_raw"])
    symmetry=plot(fs_panel(fs,false,"Raw (0, π) stripe solution";maximum_intensity=lim),
        fs_panel(fs,true,"Equal arithmetic average of four rotations";maximum_intensity=lim);
        layout=(1,2),size=(1250,590),dpi=200,plot_title="Fermi-level intensity · identical color scale · η = 0.05")
    savefig(symmetry,joinpath(output,"fig3_fermi_symmetrization.png"))
    savefig(symmetry,joinpath(output,"fig3_fermi_symmetrization.pdf"))
    push!(sources,@__FILE__)
    source_hashes=Dict(relpath(p,ROOT)=>filehash(p) for p in unique(sources))
    files=filter(p->endswith(p,".png") || endswith(p,".pdf"),readdir(output;join=true))
    open(joinpath(output,"provenance.toml"),"w") do io
        TOML.print(io,Dict("created_utc"=>string(now(UTC)),"input_sha256"=>source_hashes,
            "output_sha256"=>Dict(basename(p)=>filehash(p) for p in files),
            "ridge_display_gain"=>.013,"ridge_count"=>49,
            "notes"=>"Fixed normalization4 states/Fe; ridge offsets/gain are display choices. Fig3d paper colorbar normalization is unspecified, so this colorbar labels raw A(k,0) explicitly. No fitted spectral scale or energy shift.");sorted=true)
    end
    println("Saved Figure3, spectral heatmaps, and unsymmetrized/C4 Fermi intensity to ",output)
end

function main(args=ARGS)
    options=Dict{Symbol,String}()
    for arg in args
        key,value=split(arg,'=';limit=2)
        key=="--input-root" ? (options[:input]=abspath(value)) :
        key=="--output-dir" ? (options[:output]=abspath(value)) : error("unknown option: $key")
    end
    render(;options...)
end

end
if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Fig3Plot.main()
end
