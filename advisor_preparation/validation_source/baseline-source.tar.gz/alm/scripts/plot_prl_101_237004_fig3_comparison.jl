#!/usr/bin/env julia
module PRL101237004Fig3ComparisonPlot
using Plots, SHA, TOML, Dates
const ROOT=normpath(joinpath(@__DIR__,".."))
const BASE=joinpath(ROOT,"results","prl_101_237004","fig3")
filehash(path)=bytes2hex(open(sha256,path))
function rows(path)
    lines=readlines(path);names=split(first(lines),',')
    [Dict(names.=>split(line,',')) for line in lines[2:end] if !isempty(line)]
end
number(row,key)=parse(Float64,row[key])
function run()
    source=joinpath(ROOT,"results","prl_101_237004","fig3_reference","fig3c_dos_polylines.csv")
    paired=joinpath(BASE,"comparison","fermi_paired_cells.csv")
    references=rows(source)
    output=joinpath(BASE,"comparison","plots")
    isfile(joinpath(output,"provenance.toml")) && error("completed comparison plots exist")
    mkpath(output)
    default(fontfamily="sans-serif",guidefontsize=10,tickfontsize=9,titlefontsize=11,
        legendfontsize=9,background_color=:white,left_margin=7Plots.mm,right_margin=5Plots.mm,
        top_margin=5Plots.mm,bottom_margin=6Plots.mm)
    panels=Plots.Plot[];inputs=[source,paired,@__FILE__]
    for (U,name,color) in ((0.,"blue_U0","#2457c5"),(.5,"blue_U0p5","#2457c5"),
                           (1.,"blue_U1","#2457c5"),(2.,"blue_U2","#2457c5"))
        file=joinpath(BASE,"refined","cases",name,"dos.csv");push!(inputs,file)
        calculated=rows(file)
        p=plot(;title="r = −0.2 · U = $U · J = U/4",xlabel="ω − μ",ylabel="DOS",
            xlims=(-3.,3.),ylims=(0.,4.15),legend=:outertop,legend_columns=2,grid=false,framestyle=:box)
        selected=filter(row->number(row,"U")==U,references)
        firstpath=true
        for group in unique([row["subpath_index"] for row in selected])
            segment=filter(row->row["subpath_index"]==group,selected)
            plot!(p,[number(row,"omega_minus_mu") for row in segment],
                [number(row,"dos_published") for row in segment];color="#222222",
                linewidth=1.5,label=firstpath ? "Published vector curve" : false)
            firstpath=false
        end
        plot!(p,[number(row,"omega_minus_mu") for row in calculated],
            [number(row,"DOS_states_per_Fe_per_energy") for row in calculated];
            color,linewidth=1.5,linestyle=:dash,label="Calculated · η = 0.05")
        vline!(p,[0.];color="#777777",linewidth=.6,linestyle=:dot,label=false)
        push!(panels,p)
    end
    combined=plot(panels...;layout=(2,2),size=(1240,850),dpi=200,
        plot_title="Figure 3(c) · direct DOS comparison · no fitted energy shift or intensity scale")
    savefig(combined,joinpath(output,"fig3c_dos_comparison.png"))
    savefig(combined,joinpath(output,"fig3c_dos_comparison.pdf"))
    cells=filter(row->row["registration"]=="native_cell_centers",rows(paired))
    length(cells)==3600 || error("source-grid cell count differs")
    original=zeros(60,60);calculated=zeros(60,60);classification=zeros(Int,60,60)
    for row in cells
        ix,iy=parse(Int,row["ix"])+1,parse(Int,row["iy"])+1
        original[ix,iy]=number(row,"source_palette_index")
        calculated[ix,iy]=number(row,"A_calculated")
        paper=lowercase(row["source_in_top_decile"])=="true"
        ours=lowercase(row["calculated_in_top_decile"])=="true"
        classification[ix,iy]=paper ? (ours ? 3 : 1) : (ours ? 2 : 0)
    end
    axis=collect(range(-1+1/60,1-1/60;length=60))
    common=(;xlabel="kₓ / π",ylabel="kᵧ / π",xlims=(-1.,1.),ylims=(-1.,1.),
        xticks=[-1.,0.,1.],yticks=[-1.,0.,1.],aspect_ratio=:equal,grid=false,framestyle=:box)
    a=heatmap(axis,axis,permutedims(original);common...,title="Published color ranks",
        color=:inferno,colorbar_title="Palette index (not physical units)",clims=(0.,63.))
    b=heatmap(axis,axis,permutedims(calculated);common...,title="Calculated · η = 0.05 · C₄ mean",
        color=:inferno,colorbar_title="A(k, 0) [states / Fe / energy]")
    c=heatmap(axis,axis,permutedims(classification);common...,title="Brightest decile · overlap = 0.328",
        color=cgrad(["#ffffff","#cd3636","#2457c5","#8a3faa"],4;categorical=true),
        clims=(-.5,3.5),colorbar=false,legend=:outerbottom)
    for (label,color) in (("Paper only","#cd3636"),("Calculation only","#2457c5"),("Both","#8a3faa"))
        scatter!(c,[NaN],[NaN];label,marker=:rect,markercolor=color,markerstrokecolor=color,markersize=5)
    end
    map=plot(a,b,c;layout=(1,3),size=(1650,580),dpi=200,
        plot_title="Figure 3(d) · shape comparison · intensity scales are not equated")
    savefig(map,joinpath(output,"fig3d_shape_comparison.png"))
    savefig(map,joinpath(output,"fig3d_shape_comparison.pdf"))
    files=filter(p->endswith(p,".png") || endswith(p,".pdf"),readdir(output;join=true))
    open(joinpath(output,"provenance.toml"),"w") do io
        TOML.print(io,Dict("created_utc"=>string(now(UTC)),
            "input_sha256"=>Dict(relpath(p,ROOT)=>filehash(p) for p in inputs),
            "output_sha256"=>Dict(basename(p)=>filehash(p) for p in files),
            "limits"=>"DOS subpath clipping gaps retained. Source color indices and calculated spectral intensities have different units. Brightest-decile comparison uses the predeclared threshold including all ties, not fitted contours.");sorted=true)
    end
    println("Saved direct DOS and Fermi-intensity shape comparison plots.")
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Fig3ComparisonPlot.run()
end
