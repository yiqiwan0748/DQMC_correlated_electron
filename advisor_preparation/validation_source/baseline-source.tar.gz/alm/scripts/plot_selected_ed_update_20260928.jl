#!/usr/bin/env julia
"""The user's three selected ED plots, on the actual chemical-potential-referenced axis."""
ENV["GKSwstype"]="100"
using Plots, TOML, SHA, Dates, Printf
const ROOT=normpath(joinpath(@__DIR__,".."))
function main(args=ARGS)
    out=isempty(args) ? joinpath(ROOT,"deliverables/moreo_selected_ed_update_20260928") : abspath(only(args))
    figures=joinpath(out,"figures");data=joinpath(out,"data")
    mkpath(figures);mkpath(data)
    input=joinpath(ROOT,"results/isaac_20260925/spectral_stage/final_u20/figures_v2/highest_weight_spectra.csv")
    reference=joinpath(ROOT,"results/isaac_20260925/spectral_stage/final_u20/cross_spin/comparison.toml")
    expected=TOML.parsefile(reference)["checks"]["chosen_Sz4"]
    lines=readlines(input)
    first(lines)=="momentum,omega,omega_minus_U,A_up,A_down,A_spin_sum" || error("Unexpected source format")
    rows=[split(r,',') for r in lines[2:end] if !isempty(r)]
    channels=Dict(label=>begin
        r=filter(r->r[1]==label,rows)
        (;omega=parse.(Float64,getindex.(r,2)),up=parse.(Float64,getindex.(r,4)),down=parse.(Float64,getindex.(r,5)))
    end for label in ("X","Y"))
    x,y=channels["X"],channels["Y"]
    x.omega==y.omega || error("Frequency grids differ")
    all(diff(x.omega).>0) || error("Frequency ordering")
    all(isfinite,vcat(x.up,x.down,y.up,y.down)) || error("Nonfinite spectral values")
    minimum(vcat(x.up,x.down,y.up,y.down))>=0 || error("Negative spectral values")
    delta=x.down.-y.up;index=argmax(abs.(delta));difference=abs(delta[index])
    checks=Dict("maximum_abs_Xdown_minus_Yup"=>difference,"omega_at_largest_cross_difference"=>x.omega[index],
        "Xdown_at_largest_difference"=>x.down[index],"Yup_at_largest_difference"=>y.up[index],
        "maximum_abs_Xup_minus_Yup"=>maximum(abs.(x.up.-y.up)),
        "maximum_abs_Xdown_minus_Ydown"=>maximum(abs.(x.down.-y.down)))
    for (key,value) in checks
        abs(value-expected[key])<=1e-12 || error("Mismatch to accepted cross-spin checkpoint: $key")
    end
    open(joinpath(data,"selected_state_spectra.csv"),"w") do io
        println(io,"momentum,omega,A_up,A_down,A_spin_sum")
        for label in ("X","Y"),i in eachindex(channels[label].omega)
            c=channels[label];println(io,join((label,c.omega[i],c.up[i],c.down[i],c.up[i]+c.down[i]),','))
        end
    end
    open(joinpath(data,"selected_cross_spin.csv"),"w") do io
        println(io,"omega,A_X_down,A_Y_up,X_down_minus_Y_up")
        for i in eachindex(x.omega);println(io,join((x.omega[i],x.down[i],y.up[i],delta[i]),','));end
    end
    default(fontfamily="sans-serif",guidefontsize=13,tickfontsize=11,titlefontsize=14,
        legendfontsize=11,background_color=:white,gridalpha=.12,framestyle=:box,
        left_margin=8Plots.mm,right_margin=5Plots.mm,bottom_margin=6Plots.mm,top_margin=5Plots.mm,
        plot_titlevspan=.11,plot_titlefontsize=16)
    function panel(label)
        c=channels[label]
        coord=label=="X" ? "(π, 0)" : "(0, π)"
        p=plot(;title="$label = $coord · same selected Sᶻ = 4 state",xlabel="ω / |t₁|",
            ylabel="Aσ(k,ω) [1 / |t₁|]",xlims=(-14,38),ylims=(0,1.32),legend=:topright)
        plot!(p,c.omega,c.up;color="#155e95",linewidth=2,label="Spin up")
        plot!(p,c.omega,c.down;color="#dc6b26",linewidth=2,linestyle=:dash,label="Spin down")
        vline!(p,[0.];color="#777777",linestyle=:dot,linewidth=1,label=false)
        p
    end
    output=String[]
    function saveboth(p,name)
        for ext in ("png","pdf")
            f=joinpath(figures,"$name.$ext");savefig(p,f);push!(output,f)
        end
    end
    for label in ("X","Y")
        saveboth(plot(panel(label);size=(1080,620),dpi=160),"ed_$(label)_spin")
    end
    saveboth(plot(panel("X"),panel("Y");layout=(2,1),size=(1100,1060),dpi=160,
        plot_title="U = 20 · eight-cell ED · N↑ = 10, N↓ = 2 · T = 0 · η = 0.15"),"ed_XY_spins")
    cross=plot(;title="Selected Sᶻ = 4 state · X ↓ and Y ↑",
        xlabel="ω / |t₁|",ylabel="Aσ(k,ω) [1 / |t₁|]",xlims=(-14,38),ylims=(0,1.12),legend=:topright)
    plot!(cross,x.omega,x.down;color="#155e95",linewidth=2,label="X ↓")
    plot!(cross,y.omega,y.up;color="#dc6b26",linewidth=2,linestyle=:dash,label="Y ↑")
    vline!(cross,[0.];color="#777777",linestyle=:dot,linewidth=1,label=false)
    saveboth(plot(cross;size=(1080,680),dpi=160),"ed_Xdown_Yup")
    provenance=Dict("created_utc"=>string(now(UTC)),"status"=>"PASS",
        "input_spectrum_sha256"=>bytes2hex(open(sha256,input)),
        "input_checkpoint_sha256"=>bytes2hex(open(sha256,reference)),
        "plot_source_sha256"=>bytes2hex(open(sha256,@__FILE__)),"checks"=>checks,
        "checkpoint_comparison_tolerance"=>1e-12,"eta"=>.15,"display_window"=>[-14.,38.],
        "frequency_definition"=>"Canonical pole minus midpoint chemical potential; actual omega only",
        "mu_centered"=>-8.240639292760854,"source_frequency_spacing"=>.05,
        "source_frequency_range"=>[first(x.omega),last(x.omega)],
        "state"=>"Selected S=4,Sz=4,K=M,Nup=10,Ndown=2; no spin or ensemble averaging",
        "rendering"=>"Original sampled values joined by plot lines. No resampling, smoothing, refitting, extra broadening, or amplitude normalization. Gray vertical guide is omega=0.",
        "output_sha256"=>Dict(relpath(f,out)=>bytes2hex(open(sha256,f)) for f in output))
    open(joinpath(out,"plot_verification.toml"),"w") do io;TOML.print(io,provenance);end
    println("Saved selected ED plots: ",out)
end
if abspath(PROGRAM_FILE)==@__FILE__; main(); end
