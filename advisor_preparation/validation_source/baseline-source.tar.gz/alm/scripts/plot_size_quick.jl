#!/usr/bin/env julia

using Plots
using Printf

const SIGN_RE = r"Average sign\s*=\s*([-+0-9.eE]+)\s*\+/-\s*([-+0-9.eE]+)"
const RUNTIME_RE = r"Runtime \(seconds\)\s*=\s*([-+0-9.eE]+)"
const RSS_RE = r"Maximum resident set size \(kbytes\):\s*([0-9]+)"
const LOG_NAME_RE = r"^L([0-9]+)_quick\.log$"
const TARGET_RE = r"Fixed-mu target check .*?=\s*(TARGET_COMPATIBLE|NOT_AT_TARGET)"

function usage()
    println("Usage: julia --project=. plot_size_quick.jl [SIZE_RESULTS_DIRECTORY]")
    println()
    println("If the directory is omitted, latest_size_dir.txt is read from the current directory.")
end

function results_directory(args)
    if !isempty(args)
        return abspath(args[1])
    end

    pointer = joinpath(pwd(), "latest_size_dir.txt")
    isfile(pointer) || error("Missing $pointer; pass the size-results directory explicitly.")
    value = strip(read(pointer, String))
    isempty(value) && error("$pointer is empty.")
    return isabspath(value) ? value : abspath(value)
end

function parse_last_float(text, regex, label, path)
    matches = collect(eachmatch(regex, text))
    isempty(matches) && error("Missing $label in $(basename(path)).")
    return parse(Float64, matches[end].captures[1])
end

function parse_completed_log(path)
    name_match = match(LOG_NAME_RE, basename(path))
    name_match === nothing && return nothing

    text = read(path, String)
    occursin("Simulation complete", text) || return nothing

    sign_matches = collect(eachmatch(SIGN_RE, text))
    isempty(sign_matches) && error("Missing average sign in $(basename(path)).")
    sign_match = sign_matches[end]

    target_matches = collect(eachmatch(TARGET_RE, text))
    isempty(target_matches) && error("Missing fixed-density status in $(basename(path)).")
    target_status = target_matches[end].captures[1]

    L = parse(Int, name_match.captures[1])
    average_sign = parse(Float64, sign_match.captures[1])
    sign_se = parse(Float64, sign_match.captures[2])
    runtime_seconds = parse_last_float(text, RUNTIME_RE, "runtime", path)
    max_rss_kbytes = round(Int, parse_last_float(text, RSS_RE, "maximum RSS", path))

    values = (average_sign, sign_se, runtime_seconds, Float64(max_rss_kbytes))
    all(isfinite, values) || error("Non-finite value in $(basename(path)).")
    sign_se >= 0 || error("Negative sign error in $(basename(path)).")
    runtime_seconds > 0 || error("Non-positive runtime in $(basename(path)).")
    max_rss_kbytes > 0 || error("Non-positive maximum RSS in $(basename(path)).")

    return (
        L = L,
        average_sign = average_sign,
        sign_se = sign_se,
        runtime_seconds = runtime_seconds,
        max_rss_kbytes = max_rss_kbytes,
        max_rss_gib = max_rss_kbytes / 1024.0^2,
        target_status = target_status,
        log = basename(path),
    )
end

function write_csv(path, rows)
    open(path, "w") do io
        println(io, "L,average_sign,sign_se,runtime_seconds,max_rss_kbytes,max_rss_gib,log")
        for row in rows
            @printf(
                io,
                "%d,%.17g,%.17g,%.17g,%d,%.17g,%s\n",
                row.L,
                row.average_sign,
                row.sign_se,
                row.runtime_seconds,
                row.max_rss_kbytes,
                row.max_rss_gib,
                row.log,
            )
        end
    end
end

function main(args)
    if any(arg -> arg in ("-h", "--help"), args)
        usage()
        return
    end
    length(args) <= 1 || error("Expected at most one results-directory argument.")

    directory = results_directory(args)
    isdir(directory) || error("Size-results directory does not exist: $directory")

    rows = NamedTuple[]
    for path in sort(readdir(directory; join = true))
        match(LOG_NAME_RE, basename(path)) === nothing && continue
        try
            row = parse_completed_log(path)
            row === nothing || push!(rows, row)
        catch err
            @warn "Skipping malformed completed log" log = basename(path) exception = err
        end
    end

    isempty(rows) && error("No completed L*_quick.log files were found in $directory")
    sort!(rows; by = row -> row.L)

    Ls = getproperty.(rows, :L)
    signs = getproperty.(rows, :average_sign)
    sign_2se = 2 .* getproperty.(rows, :sign_se)
    runtimes = getproperty.(rows, :runtime_seconds)
    memories = getproperty.(rows, :max_rss_gib)
    target_bad = getproperty.(rows, :target_status) .== "NOT_AT_TARGET"

    sign_low = min(-0.05, minimum(signs .- sign_2se) - 0.03)
    sign_high = max(1.05, maximum(signs .+ sign_2se) + 0.03)

    common = (
        marker = :circle,
        markersize = 6,
        linewidth = 2,
        legend = false,
        gridalpha = 0.2,
        xticks = Ls,
        xlabel = "Linear lattice size, L",
    )

    sign_plot = plot(
        Ls,
        signs;
        common...,
        yerror = sign_2se,
        ylabel = "Average sign (±2 SE)",
        title = "Average sign",
        label = "Average sign",
        ylims = (sign_low, sign_high),
    )
    any(target_bad) && scatter!(
        sign_plot,
        Ls[target_bad],
        signs[target_bad];
        marker = :xcross,
        markersize = 10,
        markerstrokewidth = 3,
        color = :red,
        label = "NOT_AT_TARGET",
        legend = :bottomleft,
    )
    hline!(sign_plot, [0.1]; linestyle = :dash, color = :black, label = false)
    annotate!(sign_plot, Ls[end] - 0.25, 0.13, text("threshold = 0.1", 9, :right))

    runtime_plot = plot(
        Ls,
        runtimes;
        common...,
        ylabel = "Runtime (seconds, log scale)",
        title = "Runtime",
        yscale = :log10,
    )

    memory_plot = plot(
        Ls,
        memories;
        common...,
        ylabel = "Peak resident memory (GiB)",
        title = "Peak memory",
        ylims = (0, 1.12 * maximum(memories)),
    )

    title = "Quick size diagnostics — U=2, β=10, n_target=1.42"
    combined = plot(
        sign_plot,
        runtime_plot,
        memory_plot;
        layout = (3, 1),
        size = (900, 1150),
        plot_title = title,
        left_margin = 8Plots.mm,
        bottom_margin = 5Plots.mm,
    )

    sign_path = joinpath(directory, "average_sign_vs_L_quick.png")
    runtime_path = joinpath(directory, "runtime_vs_L_quick.png")
    memory_path = joinpath(directory, "memory_vs_L_quick.png")
    combined_path = joinpath(directory, "size_scaling_quick.png")
    csv_path = joinpath(directory, "size_scaling_quick.csv")

    savefig(sign_plot, sign_path)
    savefig(runtime_plot, runtime_path)
    savefig(memory_plot, memory_path)
    savefig(combined, combined_path)
    write_csv(csv_path, rows)

    println("Included completed lattice sizes: ", join(Ls, ", "))
    println("Saved combined plot: $combined_path")
    println("Saved sign plot: $sign_path")
    println("Saved runtime plot: $runtime_path")
    println("Saved memory plot: $memory_path")
    println("Saved data: $csv_path")
end

main(ARGS)
