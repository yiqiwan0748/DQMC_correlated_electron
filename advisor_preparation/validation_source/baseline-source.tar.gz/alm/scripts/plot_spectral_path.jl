#!/usr/bin/env julia

using DelimitedFiles
using Plots
using Statistics

const SPECTRUM_HEADER = [
    "omega",
    "A_normalized",
    "A_normalized_deac_se",
    "A_physical_total",
    "A_physical_total_deac_se",
]

function usage()
    println(
        "Usage: julia --project=. plot_spectral_path.jl " *
        "ALL_K_DIRECTORY [OUTPUT.png]",
    )
end

function lattice_size(directory)
    manifest = joinpath(directory, "all_k_manifest.csv")
    isfile(manifest) || error("Missing all-k manifest: $manifest")
    lines = readlines(manifest)
    length(lines) > 1 || error("The all-k manifest contains no momentum rows.")
    maximum_index = 0
    for line in lines[2:end]
        fields = split(strip(line), ',')
        length(fields) >= 5 || error("Malformed all-k manifest row: $line")
        fields[5] in ("complete", "skipped") || error(
            "All-k channel is not complete: $line",
        )
        maximum_index = max(
            maximum_index,
            parse(Int, fields[1]),
            parse(Int, fields[2]),
        )
    end
    iseven(maximum_index) || error(
        "The Γ-X-M-Γ helper currently requires an even lattice size.",
    )
    return maximum_index
end

function high_symmetry_path(L)
    half = L ÷ 2
    gamma_to_x = [(index, 1) for index in 1:(half + 1)]
    x_to_m = [(half + 1, index) for index in 2:(half + 1)]
    m_to_gamma = [(index, index) for index in half:-1:1]
    points = vcat(gamma_to_x, x_to_m, m_to_gamma)

    momenta = [
        (2pi * (kx_index - 1) / L, 2pi * (ky_index - 1) / L)
        for (kx_index, ky_index) in points
    ]
    coordinate = zeros(Float64, length(points))
    for index in 2:length(points)
        previous = momenta[index - 1]
        current = momenta[index]
        coordinate[index] = coordinate[index - 1] +
            hypot(current[1] - previous[1], current[2] - previous[2])
    end

    x_position = half + 1
    m_position = length(gamma_to_x) + length(x_to_m)
    tick_indices = [1, x_position, m_position, length(points)]
    return (
        points=points,
        coordinate=coordinate,
        tick_positions=coordinate[tick_indices],
        tick_labels=["Γ", "X", "M", "Γ"],
    )
end

function read_numeric_csv(path, expected_header)
    isfile(path) || error("Missing continuation output: $path")
    header = split(strip(open(readline, path)), ',')
    header == expected_header || error(
        "Unexpected columns in $(basename(path)): $(join(header, ", "))",
    )
    return readdlm(path, ',', Float64, '\n'; skipstart=1)
end

function read_channel(directory, kx_index, ky_index)
    stem = "ktrace_kx$(kx_index)_ky$(ky_index)"
    spectrum_path = joinpath(directory, stem * "_spectrum.csv")
    input_path = joinpath(directory, stem * "_input.csv")
    spectrum_data = read_numeric_csv(spectrum_path, SPECTRUM_HEADER)
    input_data = read_numeric_csv(
        input_path,
        [
            "tau_index",
            "tau",
            "G_normalized",
            "G_normalized_se",
            "G_physical_total",
            "G_physical_total_se",
        ],
    )
    return (
        omega=spectrum_data[:, 1],
        spectrum=spectrum_data[:, 4],
        noisy=any(input_data[:, 3] .<= 0),
    )
end

function color_cap(values)
    finite_nonnegative = filter(
        value -> isfinite(value) && value >= 0,
        vec(values),
    )
    isempty(finite_nonnegative) && error("No finite spectral weight to plot.")
    cap = quantile(finite_nonnegative, 0.995)
    cap > 0 || (cap = maximum(finite_nonnegative))
    cap > 0 || error("The continued spectrum is identically zero.")
    return cap
end

function spectral_panel(
    coordinate,
    omega,
    spectrum,
    selected,
    ticks,
    noisy_columns,
    title;
    show_flag_legend,
)
    selected_omega = omega[selected]
    selected_spectrum = max.(spectrum[selected, :], 0.0)
    cap = color_cap(selected_spectrum)
    panel = heatmap(
        coordinate,
        selected_omega,
        selected_spectrum;
        color = :inferno,
        clims = (0.0, cap),
        colorbar_title = "A(k,ω)",
        xlabel = "Momentum path",
        ylabel = "Energy, ω",
        title = title,
        xticks = ticks,
        xlims = (first(coordinate), last(coordinate)),
        grid = false,
        framestyle = :box,
        right_margin = 8Plots.mm,
        left_margin = 7Plots.mm,
        bottom_margin = 5Plots.mm,
    )
    hline!(
        panel,
        [0.0];
        color = :white,
        linestyle = :dash,
        linewidth = 1.5,
        label = false,
    )
    vline!(
        panel,
        ticks[1][2:3];
        color = :white,
        alpha = 0.45,
        linewidth = 1,
        label = false,
    )
    if any(noisy_columns)
        energy_range = last(selected_omega) - first(selected_omega)
        marker_energy = last(selected_omega) - 0.04 * energy_range
        scatter!(
            panel,
            coordinate[noisy_columns],
            fill(marker_energy, count(noisy_columns));
            marker = :xcross,
            markersize = 8,
            markerstrokewidth = 3,
            color = :cyan,
            markerstrokecolor = :black,
            label = show_flag_legend ? "nonpositive noisy G(k,τ)" : false,
            legend = show_flag_legend ? :topright : false,
        )
    end
    return panel
end

function main(args)
    if any(argument -> argument in ("-h", "--help"), args)
        usage()
        return
    end
    1 <= length(args) <= 2 || error("Expected one or two arguments.")

    directory = abspath(args[1])
    isdir(directory) || error("All-k directory does not exist: $directory")
    output_path = length(args) == 2 ? abspath(args[2]) :
        joinpath(directory, "spectral_path_smoke.png")

    L = lattice_size(directory)
    path = high_symmetry_path(L)
    channels = [read_channel(directory, point...) for point in path.points]
    omega = channels[1].omega
    all(channel -> channel.omega == omega, channels) || error(
        "All path channels must use the same energy grid.",
    )
    spectrum = hcat(getproperty.(channels, :spectrum)...)
    all(isfinite, spectrum) || error("A path spectrum contains non-finite values.")
    noisy_columns = getproperty.(channels, :noisy)
    ticks = (path.tick_positions, path.tick_labels)

    full_selection = trues(length(omega))
    low_selection = abs.(omega) .<= 3.0
    count(low_selection) >= 3 || error("Energy grid has too few points in [-3,3].")
    full_panel = spectral_panel(
        path.coordinate,
        omega,
        spectrum,
        full_selection,
        ticks,
        noisy_columns,
        "Full energy range (color capped at 99.5th percentile)";
        show_flag_legend=true,
    )
    low_panel = spectral_panel(
        path.coordinate,
        omega,
        spectrum,
        low_selection,
        ticks,
        noisy_columns,
        "Low-energy zoom: -3 ≤ ω ≤ 3";
        show_flag_legend=false,
    )
    combined = plot(
        full_panel,
        low_panel;
        layout = (2, 1),
        size = (950, 900),
        plot_title = "Two-orbital DQMC A(k,ω): Γ-X-M-Γ — smoke continuation",
    )

    mkpath(dirname(output_path))
    savefig(combined, output_path)
    flagged = [
        "($(point[1]),$(point[2]))"
        for (point, noisy) in zip(path.points, noisy_columns) if noisy
    ]
    println("Lattice size inferred from manifest: L=$L")
    println(
        "Flagged path columns: ",
        isempty(flagged) ? "none" : join(flagged, ", "),
    )
    println("Saved spectral-path plot: $output_path")
end

main(ARGS)
