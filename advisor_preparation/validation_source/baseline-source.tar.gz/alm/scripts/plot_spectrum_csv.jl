#!/usr/bin/env julia

using DelimitedFiles
using Printf

const RUN_AS_SCRIPT = abspath(PROGRAM_FILE) == @__FILE__
if RUN_AS_SCRIPT && !any(argument -> argument in ("-h", "--help"), ARGS)
    using Plots
end

function usage()
    println(
        "Usage: julia --project=. plot_spectrum_csv.jl " *
        "SPECTRUM.csv [OUTPUT.png] [TITLE] [--compare=OTHER_SPIN.csv]",
    )
    println("Compare up/down spectra on the same energy grid; ribbons show DEAC spread only.")
end

function trapezoid_integral(x, y)
    return sum(
        (x[index + 1] - x[index]) *
        (y[index + 1] + y[index]) / 2
        for index in 1:(length(x) - 1)
    )
end

function parse_options(args)
    if any(argument -> argument in ("-h", "--help"), args)
        return nothing
    end
    positional = String[]
    comparison_path = nothing
    for argument in args
        if startswith(argument, "--compare=")
            isnothing(comparison_path) || error("--compare may be supplied only once")
            value = split(argument, '='; limit=2)[2]
            isempty(value) && error("--compare requires a spectrum CSV path")
            comparison_path = abspath(value)
        elseif startswith(argument, "--")
            error("Unknown option: $argument")
        else
            push!(positional, argument)
        end
    end
    1 <= length(positional) <= 3 || error("Expected one to three positional arguments.")
    input_path = abspath(positional[1])
    output_path = length(positional) >= 2 ? abspath(positional[2]) :
        joinpath(dirname(input_path), "spectrum.png")
    title = length(positional) == 3 ? positional[3] : "Continued spectral density"
    return (; input_path, output_path, title, comparison_path)
end

function read_spectrum_csv(input_path)
    isfile(input_path) || error("Spectrum CSV does not exist: $input_path")
    header = split(strip(first(eachline(input_path))), ',')
    length(header) == 5 || error("Spectrum CSV must contain five columns")
    channels = Dict("total" => :both, "up" => :up, "down" => :down)
    suffix = replace(header[4], "A_physical_" => ""; count=1)
    haskey(channels, suffix) || error("Unsupported physical spectrum column: $(header[4])")
    expected = [
        "omega",
        "A_normalized",
        "A_normalized_deac_se",
        "A_physical_$suffix",
        "A_physical_$(suffix)_deac_se",
    ]
    header == expected || error(
        "Unexpected spectrum columns. Expected: $(join(expected, ", "))",
    )

    data = readdlm(input_path, ',', Float64, '\n'; skipstart=1)
    ndims(data) == 2 && size(data, 2) == 5 || error(
        "Spectrum CSV must contain five numeric columns.",
    )
    omega = data[:, 1]
    spectrum = data[:, 4]
    uncertainty = data[:, 5]
    length(omega) >= 3 || error("Spectrum needs at least three energy points.")
    all(isfinite, omega) || error("Energy grid contains non-finite values.")
    all(diff(omega) .> 0) || error("Energy grid must be strictly increasing.")
    all(isfinite, spectrum) || error("Spectrum contains non-finite values.")
    spin = channels[suffix]
    expected_weight = spin == :both ? 4.0 : 2.0
    # CSV text roundoff is far smaller than this tolerance. This check catches
    # a mislabeled /2 versus /4 physical conversion without testing the fit.
    isapprox(spectrum, expected_weight .* data[:, 2]; atol=1.0e-10, rtol=1.0e-10) ||
        error("Physical spectrum disagrees with the selected-spin normalization")
    label = spin == :both ? "Both spins" : spin == :up ? "Spin up" : "Spin down"
    return (; omega, spectrum, uncertainty, spin, expected_weight, label)
end

function validate_comparison(first_spectrum, second_spectrum)
    Set((first_spectrum.spin, second_spectrum.spin)) == Set((:up, :down)) ||
        error("--compare requires one spin-up and one spin-down spectrum")
    first_spectrum.omega == second_spectrum.omega ||
        error("Compared spin spectra must use identical energy grids")
    return nothing
end

function main(args)
    options = parse_options(args)
    if isnothing(options)
        usage()
        return nothing
    end
    primary = read_spectrum_csv(options.input_path)
    spectra = [primary]
    if !isnothing(options.comparison_path)
        comparison = read_spectrum_csv(options.comparison_path)
        validate_comparison(primary, comparison)
        push!(spectra, comparison)
    end
    plot_options = (
        xlabel = "Energy, ω",
        ylabel = "Spectral density (states/cell/energy)",
        title = options.title,
        linewidth = 2,
        gridalpha = 0.2,
        legend = :topright,
        size = (850, 520),
        bottom_margin = 5Plots.mm,
        left_margin = 8Plots.mm,
    )
    spectrum_plot = plot(; plot_options...)
    for channel in spectra
        valid_uncertainty = all(isfinite, channel.uncertainty) &&
            all(channel.uncertainty .>= 0)
        color = channel.spin == :down ? :orangered : :blue
        if valid_uncertainty
            plot!(
                spectrum_plot, channel.omega, channel.spectrum;
                label="$(channel.label) (DEAC spread)", color=color,
                ribbon=channel.uncertainty, fillalpha=0.18,
            )
        else
            @warn "DEAC spread is unavailable; plotting the central curve only" spin=channel.spin
            plot!(
                spectrum_plot, channel.omega, channel.spectrum;
                label=channel.label, color=color,
            )
        end
    end
    vline!(
        spectrum_plot,
        [0.0];
        color = :black,
        linestyle = :dash,
        linewidth = 1,
        label = false,
    )

    mkpath(dirname(options.output_path))
    savefig(spectrum_plot, options.output_path)
    for channel in spectra
        spectral_weight = trapezoid_integral(channel.omega, channel.spectrum)
        @printf("%s: integrated physical weight = %.8g (expected near %.0f)\n",
                channel.label, spectral_weight, channel.expected_weight)
    end
    println("Ribbons show the CSV DEAC standard-error spread, not full DQMC uncertainty.")
    println("Saved spectrum plot: $(options.output_path)")
    return nothing
end

if RUN_AS_SCRIPT
    main(ARGS)
end
