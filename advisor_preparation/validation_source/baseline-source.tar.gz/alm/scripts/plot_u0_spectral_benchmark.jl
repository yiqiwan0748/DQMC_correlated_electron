#!/usr/bin/env julia

# Reconstruct the two free-particle spectral poles directly from the measured
# unequal-time DQMC Green function and compare them with the exact Bloch bands.
# At U=0 the Monte Carlo bins are deterministic, so this is a cleaner exact
# benchmark than assigning an artificial covariance solely to run DEAC.

ENV["GKSwstype"] = "100"

using DelimitedFiles
using LinearAlgebra
using Plots
using Printf
using Serialization
using Statistics

function usage()
    println(
        "Usage: julia --project=. plot_u0_spectral_benchmark.jl " *
        "PAYLOAD.jls [OUTPUT.png]",
    )
end

function required(dictionary::AbstractDict, key::AbstractString)
    haskey(dictionary, key) || error("payload is missing key: $key")
    return dictionary[key]
end

function bloch_hamiltonian(kx, ky, t1, t2, t3, t4)
    epsilon_x =
        -2t1 * cos(kx) - 2t2 * cos(ky) - 4t3 * cos(kx) * cos(ky)
    epsilon_y =
        -2t2 * cos(kx) - 2t1 * cos(ky) - 4t3 * cos(kx) * cos(ky)
    epsilon_xy = -4t4 * sin(kx) * sin(ky)
    return Symmetric([epsilon_x epsilon_xy; epsilon_xy epsilon_y])
end

function averaged_green_matrix(
    greens,
    full_sign_sum,
    kx_index,
    ky_index,
    tau_index,
)
    matrix = zeros(ComplexF64, 2, 2)
    for bin in axes(greens, 1), spin in 1:2
        @views matrix .+= greens[
            bin,
            spin,
            :,
            :,
            kx_index,
            ky_index,
            tau_index,
        ]
    end
    # Average over the two equivalent spin channels.  full_sign_sum performs
    # the sign reweighting and sample normalization for each spin separately.
    matrix ./= 2full_sign_sum
    return matrix
end

function fit_single_exponential(tau, values)
    real_values = real.(values)
    maximum_imaginary = maximum(abs, imag.(values))
    # A free band is a single exponential.  Use the end with the larger
    # resolved signal: tau≈0 for an empty state and tau≈beta for an occupied
    # state.  This avoids fitting exponentially tiny tails.
    candidates = ((1, 2), (length(tau) - 1, length(tau)))
    scores = [
        min(real_values[first], real_values[second])
        for (first, second) in candidates
    ]
    first, second = candidates[argmax(scores)]
    g_first = real_values[first]
    g_second = real_values[second]
    g_first > 0 && g_second > 0 || error(
        "projected U=0 Green function is nonpositive at both stable endpoints",
    )
    delta_tau = tau[second] - tau[first]
    delta_tau > 0 || error("imaginary-time grid is not strictly increasing")
    pole = -log(g_second / g_first) / delta_tau
    return (pole, maximum_imaginary)
end

function high_symmetry_path(L)
    iseven(L) || error("the Γ-X-M-Γ helper requires an even L")
    half = L ÷ 2
    gamma_to_x = [(index, 1) for index in 1:(half + 1)]
    x_to_m = [(half + 1, index) for index in 2:(half + 1)]
    m_to_gamma = [(index, index) for index in half:-1:1]
    points = vcat(gamma_to_x, x_to_m, m_to_gamma)
    momenta = [
        (2pi * (kx_index - 1) / L, 2pi * (ky_index - 1) / L)
        for (kx_index, ky_index) in points
    ]
    coordinate = zeros(Float64, length(points))
    for index in 2:length(points)
        coordinate[index] = coordinate[index - 1] + hypot(
            momenta[index][1] - momenta[index - 1][1],
            momenta[index][2] - momenta[index - 1][2],
        )
    end
    x_position = half + 1
    m_position = length(gamma_to_x) + length(x_to_m)
    tick_indices = [1, x_position, m_position, length(points)]
    return (
        points=points,
        coordinate=coordinate,
        tick_positions=coordinate[tick_indices],
        tick_labels=["Γ", "X", "M", "Γ"],
    )
end

function continuous_exact_path(mu, t1, t2, t3, t4; points_per_segment=240)
    vertices = [(0.0, 0.0), (pi, 0.0), (pi, pi), (0.0, 0.0)]
    coordinate = Float64[]
    lower = Float64[]
    upper = Float64[]
    distance_offset = 0.0

    for segment in 1:3
        start = vertices[segment]
        stop = vertices[segment + 1]
        segment_length = hypot(stop[1] - start[1], stop[2] - start[2])
        first_sample = segment == 1 ? 0 : 1
        for sample in first_sample:points_per_segment
            fraction = sample / points_per_segment
            kx = start[1] + fraction * (stop[1] - start[1])
            ky = start[2] + fraction * (stop[2] - start[2])
            energies = eigvals(bloch_hamiltonian(kx, ky, t1, t2, t3, t4))
            push!(coordinate, distance_offset + fraction * segment_length)
            push!(lower, energies[1] - mu)
            push!(upper, energies[2] - mu)
        end
        distance_offset += segment_length
    end
    return (coordinate=coordinate, lower=lower, upper=upper)
end

lorentzian(omega, pole, eta) = eta / (pi * ((omega - pole)^2 + eta^2))

function main(arguments)
    if any(argument -> argument in ("-h", "--help"), arguments)
        usage()
        return
    end
    1 <= length(arguments) <= 2 || error("expected one or two arguments")

    payload_path = abspath(arguments[1])
    isfile(payload_path) || error("payload does not exist: $payload_path")
    output_path = length(arguments) == 2 ? abspath(arguments[2]) :
        joinpath(dirname(payload_path), "u0_spectral_benchmark.png")

    payload = open(deserialize, payload_path)
    payload isa AbstractDict || error("payload must be a dictionary")
    metadata = required(payload, "metadata")
    U = Float64(required(metadata, "U"))
    iszero(U) || error("this exact benchmark requires U=0, but payload has U=$U")

    beta = Float64(required(metadata, "beta"))
    L = Int(required(metadata, "L"))
    mu = Float64(required(metadata, "mu_measured"))
    target_density = Float64(required(metadata, "target_density"))
    t1 = Float64(required(metadata, "t1"))
    t2 = Float64(required(metadata, "t2"))
    t3 = Float64(required(metadata, "t3"))
    t4 = Float64(required(metadata, "t4"))

    tau = Float64.(required(payload, "tau"))
    momenta = Float64.(required(payload, "momenta"))
    greens = required(payload, "green_signed_momentum_bins")
    greens === nothing && error("payload has no unequal-time Green data")
    sign_sums = Float64.(required(payload, "green_sign_sums"))
    full_sign_sum = sum(sign_sums)
    full_sign_sum > 0 || error("U=0 Green sign sum must be positive")
    size(greens) == (length(sign_sums), 2, 2, 2, L, L, length(tau)) ||
        error("unexpected Green tensor shape")

    exact_poles = zeros(Float64, 2, L, L)
    dqmc_poles = similar(exact_poles)
    physical_weights = similar(exact_poles)
    maximum_projected_imaginary = 0.0

    for ky_index in 1:L, kx_index in 1:L
        kx = momenta[kx_index]
        ky = momenta[ky_index]
        decomposition = eigen(bloch_hamiltonian(kx, ky, t1, t2, t3, t4))
        exact_poles[:, kx_index, ky_index] .= decomposition.values .- mu

        projected = zeros(ComplexF64, 2, length(tau))
        for tau_index in eachindex(tau)
            green_matrix = averaged_green_matrix(
                greens,
                full_sign_sum,
                kx_index,
                ky_index,
                tau_index,
            )
            band_green = decomposition.vectors' * green_matrix *
                decomposition.vectors
            projected[:, tau_index] .= diag(band_green)
        end

        for band in 1:2
            pole, imaginary_error = fit_single_exponential(
                tau,
                @view(projected[band, :]),
            )
            dqmc_poles[band, kx_index, ky_index] = pole
            # One spectral state per spin and band.  The endpoint identity
            # extracts its measured residue; multiply by two for both spins.
            physical_weights[band, kx_index, ky_index] = 2real(
                projected[band, 1] + projected[band, end],
            )
            maximum_projected_imaginary = max(
                maximum_projected_imaginary,
                imaginary_error,
            )
        end
    end

    pole_errors = abs.(dqmc_poles .- exact_poles)
    weight_errors = abs.(physical_weights .- 2.0)
    maximum_pole_error = maximum(pole_errors)
    rms_pole_error = sqrt(mean(abs2, pole_errors))
    maximum_weight_error = maximum(weight_errors)

    path = high_symmetry_path(L)
    path_exact = zeros(Float64, 2, length(path.points))
    path_dqmc = similar(path_exact)
    path_weights = similar(path_exact)
    for (index, (kx_index, ky_index)) in pairs(path.points)
        path_exact[:, index] .= exact_poles[:, kx_index, ky_index]
        path_dqmc[:, index] .= dqmc_poles[:, kx_index, ky_index]
        path_weights[:, index] .= physical_weights[:, kx_index, ky_index]
    end

    minimum_energy = minimum(exact_poles) - 0.7
    maximum_energy = maximum(exact_poles) + 0.7
    omega = collect(range(minimum_energy, maximum_energy; length=900))
    eta = 0.12
    spectrum = zeros(Float64, length(omega), length(path.points))
    for point in axes(spectrum, 2), band in 1:2, index in eachindex(omega)
        spectrum[index, point] += path_weights[band, point] * lorentzian(
            omega[index],
            path_dqmc[band, point],
            eta,
        )
    end

    exact_path = continuous_exact_path(mu, t1, t2, t3, t4)
    cap = quantile(vec(spectrum), 0.995)
    ticks = (path.tick_positions, path.tick_labels)
    benchmark_plot = heatmap(
        path.coordinate,
        omega,
        spectrum;
        color=:inferno,
        clims=(0.0, cap),
        colorbar_title="A(k,ω)",
        xlabel="Momentum path",
        ylabel="Energy relative to μ, ω",
        title=@sprintf(
            "U=0 full-hopping spectral benchmark — L=%d, β=%g, n_target=%g",
            L,
            beta,
            target_density,
        ),
        xticks=ticks,
        xlims=(first(path.coordinate), last(path.coordinate)),
        ylims=(minimum_energy, maximum_energy),
        grid=false,
        framestyle=:box,
        size=(950, 650),
        right_margin=10Plots.mm,
        left_margin=8Plots.mm,
        bottom_margin=6Plots.mm,
    )
    plot!(
        benchmark_plot,
        exact_path.coordinate,
        exact_path.lower;
        color=:cyan,
        linestyle=:dash,
        linewidth=2,
        label="exact Bloch bands",
    )
    plot!(
        benchmark_plot,
        exact_path.coordinate,
        exact_path.upper;
        color=:cyan,
        linestyle=:dash,
        linewidth=2,
        label=false,
    )
    scatter!(
        benchmark_plot,
        repeat(path.coordinate, inner=2),
        vec(path_dqmc);
        color=:white,
        markerstrokecolor=:black,
        markersize=4,
        label="poles from DQMC G(k,τ)",
    )
    hline!(
        benchmark_plot,
        [0.0];
        color=:white,
        alpha=0.7,
        linestyle=:dot,
        linewidth=1.5,
        label=false,
    )
    vline!(
        benchmark_plot,
        path.tick_positions[2:3];
        color=:white,
        alpha=0.35,
        linewidth=1,
        label=false,
    )
    annotate!(
        benchmark_plot,
        path.coordinate[2],
        minimum_energy + 0.08 * (maximum_energy - minimum_energy),
        text(
            @sprintf(
                "max all-k |Δω| = %.2e\nmax |Δweight| = %.2e\nη = %.2f (display only)",
                maximum_pole_error,
                maximum_weight_error,
                eta,
            ),
            9,
            :white,
            :left,
        ),
    )

    mkpath(dirname(output_path))
    savefig(benchmark_plot, output_path)

    csv_path = splitext(output_path)[1] * ".csv"
    rows = Matrix{Float64}(undef, 2L^2, 9)
    row = 1
    for ky_index in 1:L, kx_index in 1:L, band in 1:2
        rows[row, :] .= (
            kx_index,
            ky_index,
            momenta[kx_index],
            momenta[ky_index],
            band,
            exact_poles[band, kx_index, ky_index],
            dqmc_poles[band, kx_index, ky_index],
            pole_errors[band, kx_index, ky_index],
            physical_weights[band, kx_index, ky_index],
        )
        row += 1
    end
    open(csv_path, "w") do io
        println(
            io,
            "kx_index,ky_index,kx,ky,band,exact_pole,dqmc_pole," *
            "absolute_error,physical_weight",
        )
        writedlm(io, rows, ',')
    end

    summary_path = splitext(output_path)[1] * "_summary.txt"
    open(summary_path, "w") do io
        println(io, "source_payload = ", payload_path)
        println(io, "U = ", U)
        println(io, "beta = ", beta)
        println(io, "L = ", L)
        println(io, "mu = ", mu)
        println(io, "target_density = ", target_density)
        println(io, "maximum_all_grid_pole_error = ", maximum_pole_error)
        println(io, "rms_all_grid_pole_error = ", rms_pole_error)
        println(io, "maximum_physical_weight_error = ", maximum_weight_error)
        println(io, "maximum_projected_imaginary_part = ", maximum_projected_imaginary)
        println(io, "display_lorentzian_eta = ", eta)
        println(io, "plot = ", output_path)
        println(io, "csv = ", csv_path)
    end

    println("U=0 spectral poles reconstructed from DQMC G(k,tau)")
    println("Maximum all-grid pole error = ", maximum_pole_error)
    println("RMS all-grid pole error = ", rms_pole_error)
    println("Maximum physical spectral-weight error = ", maximum_weight_error)
    println("Maximum projected imaginary part = ", maximum_projected_imaginary)
    println("Saved benchmark plot = ", output_path)
    println("Saved benchmark data = ", csv_path)
    println("Saved benchmark summary = ", summary_path)
end

main(ARGS)
