#!/usr/bin/env julia
"""Coordinate diagram for the exact X/Y convention, with no new many-body solve."""
ENV["GKSwstype"]="100"
using Plots, TOML, SHA, Dates, Printf, LinearAlgebra
const ROOT=normpath(joinpath(@__DIR__,".."))
include(joinpath(ROOT,"src/noninteracting.jl"))
const LABELS_ONLY="--labels-only" in ARGS
const OUTPUT_ARGS=filter(!=("--labels-only"),ARGS)
const OUT=isempty(OUTPUT_ARGS) ? joinpath(ROOT,"deliverables/xy_convention_20260928") : abspath(only(OUTPUT_ARGS))
mkpath(OUT)
started=time()
meta_path=joinpath(ROOT,"results/isaac_20260925/spectral_stage/retry_v4_results/tasks/X-o1-up-add/result/metadata.toml")
meta=TOML.parsefile(meta_path)
model=meta["ground"]["model"]
cells=model["cells"]
points=[("Γ",0.,0.),("X",pi,0.),("Y",0.,pi),("M",pi,pi)]
X=bloch_hamiltonian(pi,0.);Y=bloch_hamiltonian(0.,pi)
norm(X-Diagonal([-1.9,-4.9]))<1e-12 || error("X convention mismatch")
norm(Y-Diagonal([-4.9,-1.9]))<1e-12 || error("Y convention mismatch")
length(cells)==8 || error("Unexpected geometry")
colors=Dict("Γ"=>"#434955","X"=>"#bf3b32","Y"=>"#1f65ac","M"=>"#62429a")
default(fontfamily="sans-serif",guidefontsize=15,tickfontsize=12,titlefontsize=16,
    legendfontsize=11,background_color=:white,grid=false,framestyle=:box,
    left_margin=9Plots.mm,right_margin=6Plots.mm,bottom_margin=8Plots.mm,top_margin=6Plots.mm,
    plot_titlevspan=.11,plot_titlefontsize=18)

p=plot(;xlims=(-1.23,1.30),ylims=(-1.23,1.30),aspect_ratio=:equal,
    xticks=([-1.,-.5,0,.5,1.],["−1","−½","0","½","1"]),
    yticks=([-1.,-.5,0,.5,1.],["−1","−½","0","½","1"]),
    xlabel="kₓ / π",ylabel="kᵧ / π",title="Original square-lattice axes",legend=false)
plot!(p,[-1,1,1,-1,-1],[-1,-1,1,1,-1];color="#8d949c",linewidth=1.3,label=false)
plot!(p,[-1.15,1.20],[0,0];color="#a8afb6",linewidth=1,label=false,arrow=:closed)
plot!(p,[0,0],[-1.15,1.20];color="#a8afb6",linewidth=1,label=false,arrow=:closed)
for (x,y) in ((.5,.5),(.5,-.5),(-.5,.5),(-.5,-.5))
    scatter!(p,[x],[y];markersize=5,markercolor="#8d949c",markerstrokewidth=0,label=false)
end
for (name,x,y) in (("X",-1.,0.),("Y",0.,-1.),("M",-1.,-1.),("M",-1.,1.),("M",1.,-1.))
    scatter!(p,[x],[y];markersize=7,markercolor=:white,markerstrokecolor=colors[name],markerstrokewidth=2,label=false)
end
for (name,x,y) in points
    scatter!(p,[x/pi],[y/pi];markersize=8,markercolor=colors[name],markerstrokewidth=0,label=false)
end
annotate!(p,.10,.12,text("Γ",17,colors["Γ"]))
annotate!(p,.97,.14,text("X = (π, 0)",16,colors["X"],:right))
annotate!(p,.10,1.10,text("Y = (0, π)",16,colors["Y"],:left))
annotate!(p,.93,.83,text("M = (π, π)",15,colors["M"],:right))
annotate!(p,-.97,.13,text("same X",11,colors["X"],:left))
annotate!(p,.08,-1.10,text("same Y",11,colors["Y"],:left))

table=plot(;xlims=(0,1),ylims=(0,1),axis=false,grid=false,framestyle=:none,legend=false,
    title="Numerical coordinates (radians)")
annotate!(table,.04,.91,text("Point",14,:black,:left))
annotate!(table,.42,.91,text("kₓ",15,:black,:center))
annotate!(table,.78,.91,text("kᵧ",15,:black,:center))
plot!(table,[.02,.96],[.85,.85];color="#bfc4c9",linewidth=.8,label=false)
for (i,(name,x,y)) in enumerate(points)
    yloc=.76-.15*(i-1)
    annotate!(table,.07,yloc,text(name,20,colors[name],:left))
    annotate!(table,.42,yloc,text(@sprintf("%.6f",x),16,:black,:center))
    annotate!(table,.78,yloc,text(@sprintf("%.6f",y),16,:black,:center))
end
annotate!(table,.04,.17,text("Lattice spacing a = 1",13,:black,:left))
annotate!(table,.04,.08,text("Same definitions in ED and HF",13,:black,:left))
fig=plot(p,table;layout=grid(1,2,widths=[.55,.45]),size=(1400,760),dpi=150,
    plot_title="X is along kₓ.  Y is along kᵧ.\nEight ED momenta; open edge markers are periodic copies.")
for ext in ("png","pdf");savefig(fig,joinpath(OUT,"xy_momentum_convention.$ext"));end

# A second diagram makes the same convention visible in real-space Fourier phases.
# Sites are the saved integer representatives, not a schematic replacement lattice.
phase_panels=Plots.Plot[]
phase_rows=NamedTuple[]
for (name,coordinate_index) in (("X",1),("Y",2))
    panel_title=LABELS_ONLY ? "$name Fourier signs" : "$name: phase = (−1)^$(coordinate_index==1 ? "x" : "y")"
    q=plot(;xlims=(-1.55,1.55),ylims=(-2.45,1.45),aspect_ratio=:equal,
        xticks=-1:1,yticks=-2:1,xlabel="x / a",ylabel="y / a",title=panel_title,legend=false)
    for y in -2:1;hline!(q,[y];color="#d9dce0",linewidth=.6,label=false);end
    for x in -1:1;vline!(q,[x];color="#d9dce0",linewidth=.6,label=false);end
    for (j,r) in enumerate(cells)
        sign=iseven(r[coordinate_index]) ? 1 : -1
        color=sign==1 ? "#246896" : "#b84931"
        scatter!(q,[r[1]],[r[2]];markersize=17,color,markerstrokewidth=0,label=false)
        annotate!(q,r[1],r[2],text(sign==1 ? "+" : "−",19,:white))
        annotate!(q,r[1],r[2]+.26,text("j = $j",13,:black))
        annotate!(q,r[1],r[2]-.28,text("($(r[1]), $(r[2]))",11,:black))
        push!(phase_rows,(point=name,cell_index=j,x=r[1],y=r[2],phase=sign,coefficient=sign/sqrt(8.)))
    end
    push!(phase_panels,q)
end
phase_title=LABELS_ONLY ? "Numbered ED sites and their Fourier signs" : "Numbered ED sites and their Fourier signs\nEach coefficient is ±1/√8 = ±0.353553.  These signs are not spin arrows."
phase_fig=plot(phase_panels...;layout=(1,2),size=(1100,870),dpi=150,plot_title=phase_title)
for ext in ("png","pdf")
    savefig(phase_fig,joinpath(OUT,"xy_fourier_phases.$ext"))
    savefig(phase_fig,joinpath(OUT,"xy_fourier_phases_numbered.$ext"))
end
open(joinpath(OUT,"coordinates.csv"),"w") do io
    println(io,"point,kx,ky,kx_over_pi,ky_over_pi")
    for (name,x,y) in points;println(io,join((name,x,y,x/pi,y/pi),','));end
end
open(joinpath(OUT,"fourier_coefficients.csv"),"w") do io
    println(io,join(string.(keys(first(phase_rows))),','))
    for row in phase_rows;println(io,join(values(row),','));end
end
for name in ("X","Y")
    selected=filter(r->r.point==name,phase_rows)
    abs(sum(r.coefficient^2 for r in selected)-1)<1e-14 || error("Fourier normalization")
end
evidence=Dict("created_utc"=>string(now(UTC)),"elapsed_seconds"=>time()-started,
    "source_sha256"=>bytes2hex(open(sha256,@__FILE__)),"model_sha256"=>bytes2hex(open(sha256,joinpath(ROOT,"src/noninteracting.jl"))),
    "saved_ED_metadata_sha256"=>bytes2hex(open(sha256,meta_path)),
    "H0_X"=>[collect(X[i,:]) for i in 1:2],"H0_Y"=>[collect(Y[i,:]) for i in 1:2],
    "matrix_check_tolerance"=>1e-12,"phase_norm_check_tolerance"=>1e-14,
    "scope"=>"Coordinate/Fourier diagram only; no many-body solve, no new spectral result",
    "labels_only"=>LABELS_ONLY,
    "coordinates"=>"Original square axes, a=1, radians; periodic tilted torus a1=(2,2),a2=(-2,2)",
    "figure_hashes"=>Dict(basename(f)=>bytes2hex(open(sha256,f)) for f in readdir(OUT;join=true) if endswith(f,".png")||endswith(f,".pdf")))
open(joinpath(OUT,"verification.toml"),"w") do io;TOML.print(io,evidence);end
println("Saved coordinate diagrams to ",OUT,"; elapsed ",round(time()-started;digits=2)," s")
