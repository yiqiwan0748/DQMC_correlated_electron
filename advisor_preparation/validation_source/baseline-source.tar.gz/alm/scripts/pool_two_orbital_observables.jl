#!/usr/bin/env julia

module TwoOrbitalObservablePooling

using SHA

import JDQMCMeasurements as jdqmcm

include(joinpath(@__DIR__, "two_orbital_observable_tools.jl"))
using .TwoOrbitalObservableTools

export validate_source_payload, merge_observable_payloads, pooled_summary, main

const TOP_LEVEL_IDENTITY_KEYS = (
    "schema_version",
    "kind",
    "model",
    "orbital_names",
    "momentum_convention",
    "basic_bin_normalization",
    "green_bin_normalization",
    "trace_channel_normalization",
    "altermagnetic_fields",
    "green_axes",
    "green_convention",
)

const METADATA_IDENTITY_KEYS = (
    "U",
    "beta",
    "dtau",
    "L",
    "Ltau",
    "mu_start",
    "mu_measured",
    "target_density",
    "t1",
    "t2",
    "t3",
    "t4",
    "stabilization_period",
    "tuning_sweeps",
    "burnin_sweeps",
    "measurements_per_bin",
    "greens_every",
    "atomic_check",
)

function usage(io::IO=stdout)
    println(
        io,
        "Usage: julia --project=. pool_two_orbital_observables.jl ",
        "OUTPUT.jls INPUT1.jls INPUT2.jls [INPUT3.jls ...]",
    )
end

function required(dictionary::AbstractDict, key, context)
    haskey(dictionary, key) || error("$context is missing key: $key")
    return dictionary[key]
end

finite_number(value::Number) = isfinite(real(value)) && isfinite(imag(value))

function require_equal(reference, candidate, description)
    isequal(reference, candidate) || error(
        "$description differs between source payloads",
    )
end

function file_sha256(path)
    return open(path, "r") do io
        bytes2hex(sha256(io))
    end
end

function validate_source_payload(path::AbstractString)
    absolute_path = abspath(path)
    isfile(absolute_path) || error("source payload does not exist: $absolute_path")
    payload = load_observable_payload(absolute_path)
    payload isa AbstractDict || error("payload must be a dictionary: $absolute_path")

    for key in TOP_LEVEL_IDENTITY_KEYS
        required(payload, key, "payload $(basename(absolute_path))")
    end
    required(payload, "kind", "payload") == "two_orbital_dqmc_observables" ||
        error("unexpected payload kind: $absolute_path")

    metadata = required(payload, "metadata", "payload")
    metadata isa AbstractDict || error("metadata must be a dictionary: $absolute_path")
    for key in METADATA_IDENTITY_KEYS
        required(metadata, key, "metadata $(basename(absolute_path))")
    end

    bin_count = required(metadata, "bin_count", "metadata")
    bin_count isa Integer && bin_count >= 2 || error(
        "metadata bin_count must be an integer of at least two: $absolute_path",
    )
    measurements_per_bin = required(metadata, "measurements_per_bin", "metadata")
    measurements_per_bin isa Integer && measurements_per_bin > 0 || error(
        "measurements_per_bin must be positive: $absolute_path",
    )
    measurement_count = required(metadata, "measurement_count", "metadata")
    measurement_count == bin_count * measurements_per_bin || error(
        "measurement_count does not equal bin_count*measurements_per_bin: $absolute_path",
    )
    greens_every = required(metadata, "greens_every", "metadata")
    greens_every isa Integer && greens_every > 0 || error(
        "greens_every must be a positive integer: $absolute_path",
    )
    seed = required(metadata, "seed", "metadata")
    seed isa Integer && seed >= 0 || error(
        "source seed must be a nonnegative integer: $absolute_path",
    )

    tau = required(payload, "tau", "payload")
    momenta = required(payload, "momenta", "payload")
    tau isa AbstractVector{<:Real} && all(isfinite, tau) || error(
        "tau must be a finite real vector: $absolute_path",
    )
    momenta isa AbstractVector{<:Real} && all(isfinite, momenta) || error(
        "momenta must be a finite real vector: $absolute_path",
    )
    L = required(metadata, "L", "metadata")
    Ltau = required(metadata, "Ltau", "metadata")
    length(momenta) == L || error("momentum grid length differs from L: $absolute_path")
    length(tau) == Ltau + 1 || error("tau grid length differs from Ltau+1: $absolute_path")

    basic_bins = required(payload, "basic_bins", "payload")
    basic_bins isa AbstractDict || error("basic_bins must be a dictionary: $absolute_path")
    haskey(basic_bins, "average_sign") || error(
        "basic_bins is missing average_sign: $absolute_path",
    )
    for (name, values) in basic_bins
        values isa AbstractVector{<:Number} || error(
            "basic bin $name must be a numeric vector: $absolute_path",
        )
        length(values) == bin_count || error(
            "basic bin $name has the wrong length: $absolute_path",
        )
        all(finite_number, values) || error(
            "basic bin $name contains a non-finite value: $absolute_path",
        )
    end
    all(abs.(basic_bins["average_sign"]) .<= 1 + 256eps(Float64)) || error(
        "a scalar-bin average sign lies outside [-1,1]: $absolute_path",
    )

    fields = required(payload, "altermagnetic_fields", "payload")
    altermagnetic = required(payload, "altermagnetic_signed_bins", "payload")
    altermagnetic isa AbstractMatrix{<:Number} || error(
        "altermagnetic_signed_bins must be a numeric matrix: $absolute_path",
    )
    size(altermagnetic) == (bin_count, length(fields)) || error(
        "altermagnetic_signed_bins has the wrong shape: $absolute_path",
    )
    all(finite_number, altermagnetic) || error(
        "altermagnetic_signed_bins contains a non-finite value: $absolute_path",
    )

    greens = required(payload, "green_signed_momentum_bins", "payload")
    greens isa AbstractArray{<:Number,7} || error(
        "green_signed_momentum_bins must be a numeric seven-axis array: $absolute_path",
    )
    size(greens) == (bin_count, 2, 2, 2, L, L, length(tau)) || error(
        "green_signed_momentum_bins has the wrong shape: $absolute_path",
    )
    all(finite_number, greens) || error(
        "green_signed_momentum_bins contains a non-finite value: $absolute_path",
    )

    sign_sums = required(payload, "green_sign_sums", "payload")
    counts = required(payload, "green_counts", "payload")
    sign_sums isa AbstractVector{<:Real} && length(sign_sums) == bin_count || error(
        "green_sign_sums has the wrong shape: $absolute_path",
    )
    counts isa AbstractVector{<:Integer} && length(counts) == bin_count || error(
        "green_counts has the wrong shape: $absolute_path",
    )
    all(isfinite, sign_sums) || error("green_sign_sums is non-finite: $absolute_path")
    all(counts .> 0) || error("every Green bin must have a positive count: $absolute_path")
    expected_green_count = cld(measurements_per_bin, greens_every)
    all(counts .== expected_green_count) || error(
        "Green counts disagree with the per-bin measurement protocol: $absolute_path",
    )
    all(abs.(sign_sums) .<= counts .+ 256eps(Float64) .* counts) || error(
        "a Green sign sum exceeds its sample count: $absolute_path",
    )

    stabilization = required(
        payload,
        "green_maximum_stabilization_errors",
        "payload",
    )
    stabilization isa AbstractMatrix{<:Real} || error(
        "stabilization errors must be a real matrix: $absolute_path",
    )
    size(stabilization) == (bin_count, 2) || error(
        "stabilization errors have the wrong shape: $absolute_path",
    )
    all(isfinite, stabilization) && all(stabilization .>= 0) || error(
        "stabilization errors must be finite and nonnegative: $absolute_path",
    )

    return (
        path=absolute_path,
        payload=payload,
        metadata=metadata,
        seed=Int(seed),
        bin_count=Int(bin_count),
        measurement_count=Int(measurement_count),
        measurements_per_bin=Int(measurements_per_bin),
        green_count=Int(sum(counts)),
        sha256=file_sha256(absolute_path),
    )
end

function validate_compatibility(sources)
    length(sources) >= 2 || error("at least two source payloads are required")
    seeds = [source.seed for source in sources]
    allunique(seeds) || error("source payload seeds must be unique")
    reference = first(sources).payload
    reference_metadata = first(sources).metadata
    reference_basic_keys = Set(keys(reference["basic_bins"]))
    reference_green_count = first(reference["green_counts"])

    for source in Iterators.drop(sources, 1)
        payload = source.payload
        metadata = source.metadata
        for key in TOP_LEVEL_IDENTITY_KEYS
            require_equal(reference[key], payload[key], "top-level key $key")
        end
        for key in METADATA_IDENTITY_KEYS
            require_equal(reference_metadata[key], metadata[key], "metadata key $key")
        end
        require_equal(reference["tau"], payload["tau"], "tau grid")
        require_equal(reference["momenta"], payload["momenta"], "momentum grid")
        require_equal(reference_basic_keys, Set(keys(payload["basic_bins"])), "basic-bin keys")
        size(reference["green_signed_momentum_bins"])[2:end] ==
            size(payload["green_signed_momentum_bins"])[2:end] || error(
                "non-bin Green dimensions differ between sources",
            )
        all(payload["green_counts"] .== reference_green_count) || error(
            "Green bins must have equal sample counts across all sources",
        )
    end
    return nothing
end

function merge_observable_payloads(sources)
    validate_compatibility(sources)
    payloads = [source.payload for source in sources]
    merged = deepcopy(first(payloads))
    merged["basic_bins"] = Dict{String,Any}(
        key => vcat((payload["basic_bins"][key] for payload in payloads)...)
        for key in keys(first(payloads)["basic_bins"])
    )
    merged["altermagnetic_signed_bins"] = cat(
        (payload["altermagnetic_signed_bins"] for payload in payloads)...;
        dims=1,
    )
    merged["green_sign_sums"] = vcat(
        (payload["green_sign_sums"] for payload in payloads)...,
    )
    merged["green_counts"] = vcat(
        (payload["green_counts"] for payload in payloads)...,
    )
    merged["green_signed_momentum_bins"] = cat(
        (payload["green_signed_momentum_bins"] for payload in payloads)...;
        dims=1,
    )
    merged["green_maximum_stabilization_errors"] = cat(
        (payload["green_maximum_stabilization_errors"] for payload in payloads)...;
        dims=1,
    )

    metadata = deepcopy(first(sources).metadata)
    metadata["seed"] = [source.seed for source in sources]
    metadata["source_seeds"] = [source.seed for source in sources]
    metadata["source_paths"] = [source.path for source in sources]
    metadata["source_sha256"] = [source.sha256 for source in sources]
    metadata["source_metadata"] = [deepcopy(source.metadata) for source in sources]
    metadata["chain_count"] = length(sources)
    metadata["aggregation"] = "raw_bin_concatenation"
    metadata["bin_count"] = sum(source.bin_count for source in sources)
    metadata["measurement_count"] = sum(
        source.measurement_count for source in sources
    )
    metadata["runtime_seconds"] = sum(
        Float64(source.metadata["runtime_seconds"]) for source in sources
    )
    metadata["largest_equal_time_greens_error"] = maximum(
        Float64(source.metadata["largest_equal_time_greens_error"])
        for source in sources
    )
    merged["metadata"] = metadata
    return merged
end

function pooled_summary(payload)
    metadata = payload["metadata"]
    basic = payload["basic_bins"]
    sign_bins = basic["average_sign"]
    sign, sign_se = jdqmcm.jackknife(identity, sign_bins)
    density, density_se = jdqmcm.jackknife(/, basic["density"], sign_bins)

    fields = payload["altermagnetic_fields"]
    altermagnetic = payload["altermagnetic_signed_bins"]
    field_estimates = Dict{Symbol,Tuple{Float64,Float64}}()
    for (column, field) in pairs(fields)
        estimate, standard_error = jdqmcm.jackknife(
            /,
            view(altermagnetic, :, column),
            sign_bins,
        )
        field_estimates[Symbol(field)] = (real(estimate), standard_error)
    end

    trace_numerators = trace_green_channel(payload) ./ 4
    green = sign_reweighted_channel_statistics(
        trace_numerators,
        payload["green_sign_sums"],
        payload["green_counts"];
        minimum_average_sign=0.05,
    )
    green.full_denominator_usable || error("pooled Green sign denominator is unusable")
    green.leave_one_out_denominators_usable || error(
        "a pooled leave-one-bin Green sign denominator is unusable",
    )
    green.values === missing && error("pooled Green estimate is unavailable")
    values = real.(green.values)
    endpoint_moment = first(values) + last(values)
    endpoint_se = if green.covariance === missing
        NaN
    else
        covariance = green.covariance
        sqrt(max(0.0, covariance[1, 1] + covariance[end, end] +
                      2covariance[1, end]))
    end
    target = Float64(metadata["target_density"])
    residual = real(density) - target
    target_compatible = abs(residual) <= max(2density_se, 1e-10)
    maximum_stabilization = maximum(
        payload["green_maximum_stabilization_errors"],
    )
    continuation_ready =
        green.full_denominator_usable &&
        green.leave_one_out_denominators_usable &&
        maximum_stabilization <= 1e-8
    return (
        sign=real(sign),
        sign_se=sign_se,
        density=real(density),
        density_se=density_se,
        density_residual=residual,
        target_compatible=target_compatible,
        fields=field_estimates,
        green_samples=sum(payload["green_counts"]),
        green_average_sign=green.full_average_sign,
        endpoint_moment=endpoint_moment,
        endpoint_se=endpoint_se,
        maximum_stabilization=maximum_stabilization,
        continuation_ready=continuation_ready,
    )
end

function print_summary(io, payload, summary)
    metadata = payload["metadata"]
    println(io, "Pooled chains = ", metadata["chain_count"])
    println(io, "Source seeds = ", join(metadata["source_seeds"], ", "))
    println(io, "Chemical potential = ", metadata["mu_measured"])
    println(io, "Pooled scalar bins = ", metadata["bin_count"])
    println(io, "Pooled scalar measurements = ", metadata["measurement_count"])
    println(io, "Pooled unequal-time Green samples = ", summary.green_samples)
    println(io, "Average sign = ", summary.sign, " +/- ", summary.sign_se)
    println(io, "Density = ", summary.density, " +/- ", summary.density_se)
    println(
        io,
        "Density residual = ", summary.density_residual,
        " (target ", metadata["target_density"], ")",
    )
    println(
        io,
        "Pooled target check = ",
        summary.target_compatible ? "TARGET_COMPATIBLE" : "NOT_AT_TARGET",
    )
    for field in (:delta_alm, :S_alm_q0, :m_alm_squared)
        estimate, standard_error = summary.fields[field]
        println(io, field, " = ", estimate, " +/- ", standard_error)
    end
    println(io, "Green average sign = ", summary.green_average_sign)
    println(
        io,
        "Endpoint moment G(0)+G(beta) = ",
        summary.endpoint_moment,
        " +/- ",
        summary.endpoint_se,
    )
    println(
        io,
        "Maximum unequal-time stabilization error = ",
        summary.maximum_stabilization,
    )
    println(
        io,
        "Continuation numerical eligibility = ",
        summary.continuation_ready ? "ELIGIBLE" : "NOT_ELIGIBLE",
    )
end

function main(args)
    if any(argument -> argument in ("-h", "--help"), args)
        usage()
        return
    end
    length(args) >= 3 || begin
        usage(stderr)
        error("expected one output and at least two source payloads")
    end
    output_path = abspath(first(args))
    input_paths = args[2:end]
    length(unique(abspath.(input_paths))) == length(input_paths) || error(
        "source payload paths must be unique",
    )
    output_path in abspath.(input_paths) && error(
        "output path must differ from every source path",
    )

    println("Validating ", length(input_paths), " source payloads")
    sources = [validate_source_payload(path) for path in input_paths]
    merged = merge_observable_payloads(sources)
    summary = pooled_summary(merged)
    merged["metadata"]["target_compatible"] = summary.target_compatible
    merged["metadata"]["pooling_summary"] = Dict{String,Any}(
        "average_sign" => summary.sign,
        "average_sign_se" => summary.sign_se,
        "density" => summary.density,
        "density_se" => summary.density_se,
        "density_residual" => summary.density_residual,
        "green_average_sign" => summary.green_average_sign,
        "green_samples" => summary.green_samples,
        "endpoint_moment" => summary.endpoint_moment,
        "endpoint_se" => summary.endpoint_se,
        "maximum_stabilization" => summary.maximum_stabilization,
        "continuation_ready" => summary.continuation_ready,
    )
    print_summary(stdout, merged, summary)
    summary.continuation_ready || error(
        "pooled payload failed numerical continuation eligibility",
    )
    saved = save_observable_payload(output_path, merged)
    println("Saved pooled payload = ", saved)
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    TwoOrbitalObservablePooling.main(ARGS)
end
