module PRL101237004ClusterGreen

using LinearAlgebra
include("prl_101_237004_ed.jl")
include("prl_101_237004_restarted_lanczos.jl")
const ED = PRL101237004ED
const Lanczos = PRL101237004RestartedLanczos

export SpinHamiltonian, spin_hamiltonian, SpectralChannel, PoleExpansion,
       ClusterGreenResult, build_cluster_green, cluster_green,
       green_mu_derivative, spectral_moments, spectral_data, omega_prime,
       particle_stability_interval

"""Canonical full-PRL Hamiltonian with possibly different real one-body
matrices for the two spins. The historical compressed ED operator supplies
the common kinetic matrix and complete interaction. This wrapper adds only
the one-body spin difference; onsite Weiss fields therefore need only a
diagonal vector. No chemical potential is included.
"""
struct SpinHamiltonian{B} <: AbstractMatrix{Float64}
    base::B
    basis::ED.SectorBasis
    diagonal_shift::Vector{Float64}
    colptr::Vector{Int}
    rowindices::Vector{Int}
    values::Vector{Float64}
end

Base.size(H::SpinHamiltonian) = size(H.base)
Base.size(H::SpinHamiltonian, axis::Integer) = size(H.base,axis)
LinearAlgebra.ishermitian(::SpinHamiltonian) = true
LinearAlgebra.issymmetric(::SpinHamiltonian) = true

function spin_hamiltonian(Kup::AbstractMatrix{<:Real}, Kdown::AbstractMatrix{<:Real},
                          U::Real,Nup::Integer,Ndown::Integer;J::Real=U/4,
                          max_dimension::Integer=100_000,max_bytes::Integer=512*1024^2)
    size(Kup)==size(Kdown) || throw(DimensionMismatch("spin kinetic matrices differ in size"))
    size(Kup,1)==size(Kup,2) && size(Kup,1)>=2 && iseven(size(Kup,1)) ||
        throw(ArgumentError("kinetic matrices must be square with two orbitals per site"))
    all(isfinite,Kup) && all(isfinite,Kdown) || throw(ArgumentError("kinetic matrices must be finite"))
    issymmetric(Kup) && issymmetric(Kdown) || throw(ArgumentError("kinetic matrices must be real symmetric"))
    ku,kd = Matrix{Float64}(Kup),Matrix{Float64}(Kdown)
    all(isfinite,ku) && all(isfinite,kd) || throw(ArgumentError("kinetic matrices overflow Float64"))
    common,difference = (ku+kd)/2,(ku-kd)/2
    all(isfinite,common) && all(isfinite,difference) || throw(ArgumentError("kinetic combinations overflow Float64"))
    base = ED.sector_hamiltonian(common,Float64(U),Nup,Ndown;J=Float64(J),max_dimension,max_bytes)
    basis = base.basis
    n,nmodes = length(basis.states),basis.nmodes
    offdiagonal = [(a,b,difference[a,b]) for a in 1:nmodes for b in 1:nmodes
                   if a!=b && !iszero(difference[a,b])]
    extra_bound = 16big(n)*length(offdiagonal)*2+24big(n)+8192
    base.estimated_bytes+extra_bound<=max_bytes || throw(ArgumentError("spin-shift storage exceeds max_bytes"))
    diagonal = zeros(Float64,n)
    colptr = Vector{Int}(undef,n+1)
    rows,values = Int[],Float64[]
    for (column,state) in enumerate(basis.states)
        colptr[column] = length(rows)+1
        for mode in 1:nmodes
            up = Int((state>>(mode-1))&1)
            down = Int((state>>(nmodes+mode-1))&1)
            diagonal[column] += difference[mode,mode]*(up-down)
        end
        for (a,b,value) in offdiagonal, (offset,spin_sign) in ((0,1),(nmodes,-1))
            transition = ED.apply_fermion_ops(state,((offset+b,false),(offset+a,true)))
            transition===nothing && continue
            destination,sign = transition
            push!(rows,basis.indices[destination])
            push!(values,spin_sign*sign*value)
        end
    end
    colptr[end] = length(rows)+1
    return SpinHamiltonian(base,basis,diagonal,colptr,rows,values)
end

function LinearAlgebra.mul!(output::AbstractVector,H::SpinHamiltonian,
                            input::AbstractVector,alpha::Number,beta::Number)
    length(input)==length(output)==size(H,1) || throw(DimensionMismatch("Hamiltonian vector length differs"))
    source = Base.mightalias(output,input) ? copy(input) : input
    mul!(output,H.base,source,alpha,beta)
    iszero(alpha) && return output
    @inbounds for column in eachindex(source)
        scale = alpha*source[column]
        output[column] += H.diagonal_shift[column]*scale
        for entry in H.colptr[column]:(H.colptr[column+1]-1)
            output[H.rowindices[entry]] += H.values[entry]*scale
        end
    end
    return output
end
LinearAlgebra.mul!(output::AbstractVector,H::SpinHamiltonian,input::AbstractVector) =
    mul!(output,H,input,true,false)
function Base.:*(H::SpinHamiltonian,input::AbstractVector)
    output = zeros(promote_type(eltype(H),eltype(input)),size(H,1))
    return mul!(output,H,input)
end
function Base.getindex(H::SpinHamiltonian,row::Int,column::Int)
    checkbounds(H,row,column)
    value = H.base[row,column]+(row==column ? H.diagonal_shift[row] : 0.0)
    for entry in H.colptr[column]:(H.colptr[column+1]-1)
        H.rowindices[entry]==row && (value+=H.values[entry])
    end
    return value
end

"""Real Lehmann weights: G(z;μ′)=Σ_l w_l*w_lᵀ/(z+μ′−p_l).
The poles are canonical energies, with no chemical-potential shift.
"""
struct PoleExpansion
    poles::Vector{Float64}
    weights::Matrix{Float64}
end

struct SpectralChannel
    spin::Symbol
    kind::Symbol
    particle_sector::Tuple{Int,Int}
    sector_dimension::Int
    source_rank::Int
    krylov_dimension::Int
    block_steps::Int
    spectrum::PoleExpansion
    exact_moments::NTuple{3,Matrix{Float64}}
    moment_errors::NTuple{3,Float64}
    probe_points::Vector{ComplexF64}
    convergence_error::Float64
    convergence_scale::Float64
    converged::Bool
    closed_subspace::Bool
    closure_residual::Float64
    neighbor_energy::Float64
    neighbor_residual::Float64
end

struct ClusterGreenResult
    K_up::Matrix{Float64}
    K_down::Matrix{Float64}
    U::Float64
    J::Float64
    Nup::Int
    Ndown::Int
    E0::Float64
    ground_residual::Float64
    ground_dimension::Int
    ground_vector::Vector{Float64}
    channels::NamedTuple{(:up_addition,:up_removal,:down_addition,:down_removal),NTuple{4,SpectralChannel}}
    up::PoleExpansion
    down::PoleExpansion
    moments_up::NTuple{3,Matrix{Float64}}
    moments_down::NTuple{3,Matrix{Float64}}
    converged::Bool
    mu_interval::Tuple{Float64,Float64}
end

function _evaluate(spectrum::PoleExpansion,z::Number,mu_prime::Real,derivative::Bool=false)
    isfinite(z) && isfinite(mu_prime) || throw(ArgumentError("frequency and chemical potential must be finite"))
    nmodes = size(spectrum.weights,1)
    result = zeros(ComplexF64,nmodes,nmodes)
    @inbounds for pole in eachindex(spectrum.poles)
        denominator = z+mu_prime-spectrum.poles[pole]
        iszero(denominator) && throw(DomainError(z,"Green function evaluated on a pole"))
        inverse = inv(ComplexF64(denominator))
        scale = derivative ? -inverse^2 : inverse
        for column in 1:nmodes, row in 1:column
            result[row,column] += scale*spectrum.weights[row,pole]*spectrum.weights[column,pole]
        end
    end
    for column in 1:nmodes, row in (column+1):nmodes
        result[row,column] = result[column,row] # symmetric, not Hermitian, at complex z
    end
    return result
end

function spectral_data(result::ClusterGreenResult;spin::Symbol=:up)
    spin==:up && return result.up
    spin==:down && return result.down
    throw(ArgumentError("spin must be :up or :down"))
end

"""Reference Green matrix with poles measured relative to μ′; E0 excludes μ′."""
cluster_green(result::ClusterGreenResult,z::Number;mu_prime::Real=0.0,spin::Symbol=:up) =
    _evaluate(spectral_data(result;spin),z,mu_prime)

"""Analytic derivative at fixed canonical cluster eigenstates: ∂G′/∂μ′."""
green_mu_derivative(result::ClusterGreenResult,z::Number;mu_prime::Real=0.0,spin::Symbol=:up) =
    _evaluate(spectral_data(result;spin),z,mu_prime,true)

function spectral_moments(result::ClusterGreenResult;spin::Symbol=:up,mu_prime::Real=0.0)
    isfinite(mu_prime) || throw(ArgumentError("chemical potential must be finite"))
    canonical = spin==:up ? result.moments_up : spin==:down ? result.moments_down :
        throw(ArgumentError("spin must be :up or :down"))
    m0,m1,m2 = canonical
    return (zeroth=copy(m0),first=m1-mu_prime*m0,
            second=m2-2mu_prime*m1+mu_prime^2*m0)
end

"""Canonical-sector grand potential, valid while this reference state is selected."""
function omega_prime(result::ClusterGreenResult,mu_prime::Real)
    isfinite(mu_prime) || throw(ArgumentError("chemical potential must be finite"))
    return result.E0-mu_prime*(result.Nup+result.Ndown)
end

"""Bounds against the four neighboring (Nup±1,Ndown)/(Nup,Ndown±1)
sectors. These are necessary stability bounds, not a global grand-canonical
certificate against other spin populations or multiple-particle changes.
"""
particle_stability_interval(result::ClusterGreenResult) =
    (lower=result.mu_interval[1],upper=result.mu_interval[2],
     scope=:four_neighboring_spin_particle_sectors)

function _source_vectors(ground_basis,target_basis,ground_vector,spin,addition)
    nmodes = ground_basis.nmodes
    source = zeros(Float64,length(target_basis.states),nmodes)
    offset = spin==:up ? 0 : nmodes
    for (column,state) in enumerate(ground_basis.states), orbital in 1:nmodes
        transition = ED.apply_fermion_ops(state,((offset+orbital,addition),))
        transition===nothing && continue
        destination,sign = transition
        source[target_basis.indices[destination],orbital] += sign*ground_vector[column]
    end
    return source
end

function _moments(spectrum::PoleExpansion)
    weights,poles = spectrum.weights,spectrum.poles
    return (weights*transpose(weights),
        (weights.*reshape(poles,1,:))*transpose(weights),
        (weights.*reshape(poles.^2,1,:))*transpose(weights))
end

function _project_spectrum(projected,Q,source,E0,addition,dimension)
    eigensystem = eigen(Symmetric(Matrix(@view projected[1:dimension,1:dimension])))
    coefficients = transpose(@view Q[:,1:dimension])*source
    weights = Matrix(transpose(transpose(eigensystem.vectors)*coefficients))
    poles = addition ? eigensystem.values.-E0 : E0.-eigensystem.values
    # Removal's resolvent indices are transposed. All source amplitudes are
    # real here, so each weight outer product is already symmetric.
    return PoleExpansion(poles,weights)
end

function _block_resolvent(H,source,E0,addition;block_steps,probe_z,
                          convergence_atol,convergence_rtol,rank_atol,max_bytes)
    n,nmodes = size(source)
    initial = svd(source;full=false)
    source_rank = count(>(rank_atol),initial.S)
    if source_rank==0
        empty = PoleExpansion(Float64[],zeros(Float64,nmodes,0))
        zero_moments = ntuple(_->zeros(Float64,nmodes,nmodes),3)
        return (;spectrum=empty,source_rank,krylov_dimension=0,block_steps=0,
            exact_moments=zero_moments,moment_errors=(0.0,0.0,0.0),
            convergence_error=0.0,convergence_scale=0.0,converged=true,
            closed_subspace=true,closure_residual=0.0)
    end
    capacity = Int(min(big(n),big(block_steps)*nmodes))
    estimate = 8big(n)*(capacity+5nmodes)+48big(capacity)^2+2^20
    estimate<=max_bytes || throw(ArgumentError("block Krylov workspace estimate $estimate exceeds max_bytes=$max_bytes"))
    Q = zeros(Float64,n,capacity)
    Q[:,1:source_rank] .= initial.U[:,1:source_rank]
    projected = zeros(Float64,capacity,capacity)
    images = similar(source)
    for orbital in 1:nmodes
        mul!(@view(images[:,orbital]),H,@view(source[:,orbital]))
    end
    images .-= E0.*source
    m0 = transpose(source)*source
    m1 = transpose(source)*images
    m2 = transpose(images)*images
    exact_moments = (m0,addition ? m1 : Matrix(-transpose(m1)),m2)
    active,first = source_rank,1
    dimensions = Int[]
    closed = false
    closure = Inf
    steps = 0
    for step in 1:block_steps
        steps = step
        last_index = active
        frontier = first:last_index
        work = Matrix{Float64}(undef,n,length(frontier))
        for (column,index) in enumerate(frontier)
            mul!(@view(work[:,column]),H,@view(Q[:,index]))
        end
        scale = max(1.0,norm(work))
        accumulated = zeros(Float64,active,length(frontier))
        basis = @view Q[:,1:active]
        for _ in 1:2
            coefficients = transpose(basis)*work
            accumulated .+= coefficients
            mul!(work,basis,coefficients,-1.0,1.0)
        end
        projected[1:active,frontier] .= accumulated
        projected[frontier,1:active] .= transpose(accumulated)
        diagonal_block = @view projected[frontier,frontier]
        diagonal_block .= (diagonal_block+transpose(diagonal_block))/2
        push!(dimensions,active)
        remainder = svd(work;full=false)
        closure = norm(remainder.S)
        next_rank = count(>(rank_atol*scale),remainder.S)
        closed = next_rank==0 || active==n
        (closed || step==block_steps || active==capacity) && break
        next_rank = min(next_rank,capacity-active)
        next_rank==0 && break
        Q[:,(active+1):(active+next_rank)] .= remainder.U[:,1:next_rank]
        first = active+1
        active += next_rank
    end
    dimension = last(dimensions)
    spectrum = _project_spectrum(projected,Q,source,E0,addition,dimension)
    projected_moments = _moments(spectrum)
    moment_errors = ntuple(i->maximum(abs.(projected_moments[i]-exact_moments[i])),3)
    previous_dimension = dimensions[max(1,length(dimensions)÷2)]
    previous = _project_spectrum(projected,Q,source,E0,addition,previous_dimension)
    error,scale = 0.0,0.0
    for z in probe_z
        final_green = _evaluate(spectrum,z,0.0)
        earlier_green = _evaluate(previous,z,0.0)
        error = max(error,maximum(abs.(final_green-earlier_green)))
        scale = max(scale,maximum(abs.(final_green)))
    end
    # Exact closure is stronger than a two-depth comparison. Otherwise this
    # flag certifies agreement only at the explicitly recorded probe points.
    converged = closed || (length(dimensions)>=2 && error<=convergence_atol+convergence_rtol*scale)
    return (;spectrum,source_rank,krylov_dimension=dimension,block_steps=steps,
        exact_moments,moment_errors,convergence_error=error,convergence_scale=scale,
        converged,closed_subspace=closed,closure_residual=closure)
end

function _ground(H;seed,ground_atol,ground_krylovdim,ground_keep,ground_max_matvecs,max_bytes)
    result = Lanczos.restarted_lowest(H;nev=1,krylovdim=min(size(H,1),ground_krylovdim),
        keep=ground_keep,max_matvecs=ground_max_matvecs,atol=ground_atol,rtol=0.0,
        seed,max_bytes)
    result.converged || error("canonical cluster eigensolver did not converge")
    return (energy=result.values[1],vector=Vector(result.vectors[:,1]),residual=result.residuals[1])
end

function _empty_channel(spin,kind,sector,nmodes,probe_z)
    spectrum = PoleExpansion(Float64[],zeros(Float64,nmodes,0))
    moments = ntuple(_->zeros(Float64,nmodes,nmodes),3)
    return SpectralChannel(spin,kind,sector,0,0,0,0,spectrum,moments,(0.0,0.0,0.0),
        copy(probe_z),0.0,0.0,true,true,0.0,Inf,0.0)
end

"""
    build_cluster_green(K_up,K_down,U,Nup,Ndown;J=U/4,...)

Compute a canonical reference ground state and the four zero-temperature
addition/removal resolvents. `block_steps` controls each block Krylov depth;
all spatial-orbital c† or c source vectors enter together. A comparison to
half the realized depth is recorded at `probe_z` (canonical frequency z+μ′).
The `converged` flag is a probe-grid convergence diagnostic, not a uniform
bound over all frequencies. Defaults return unconverged channels visibly;
set `require_convergence=true` to reject them. Pole-by-pole full-space Ritz
residuals are not used as a resolvent-convergence criterion.

The original full PRL interaction is retained. `K_up` and `K_down` include
Weiss fields but exclude μ′. Neighboring sector ground states supply necessary
μ′ stability bounds; they do not compare all other particle/spin sectors.
"""
function build_cluster_green(Kup::AbstractMatrix{<:Real},Kdown::AbstractMatrix{<:Real},
    U::Real,Nup::Integer,Ndown::Integer;J::Real=U/4,block_steps::Integer=24,
    probe_z=ComplexF64[0.05im,0.1im,0.2im,0.5im,1im,2im,4im,8im,
        -4+0.2im,-2+0.2im,-1+0.2im,1+0.2im,2+0.2im,4+0.2im],
    convergence_atol::Real=1e-8,convergence_rtol::Real=1e-7,rank_atol::Real=1e-12,
    require_convergence::Bool=false,ground_atol::Real=1e-11,
    ground_krylovdim::Integer=64,ground_keep::Integer=8,ground_max_matvecs::Integer=1000,
    seed::Integer=7,max_dimension::Integer=100_000,max_bytes::Integer=512*1024^2)
    block_steps>=1 || throw(ArgumentError("block_steps must be positive"))
    all(x->isfinite(x)&&x>=0,(convergence_atol,convergence_rtol)) || throw(ArgumentError("convergence tolerances must be nonnegative and finite"))
    isfinite(rank_atol)&&rank_atol>0 || throw(ArgumentError("rank_atol must be positive and finite"))
    probes = ComplexF64.(collect(probe_z))
    !isempty(probes) && all(z->isfinite(z)&&!iszero(imag(z)),probes) ||
        throw(ArgumentError("probe_z must contain finite frequencies away from the real axis"))
    ground_H = spin_hamiltonian(Kup,Kdown,U,Nup,Ndown;J,max_dimension,max_bytes)
    ground = _ground(ground_H;seed,ground_atol,ground_krylovdim,ground_keep,ground_max_matvecs,max_bytes)
    nmodes = ground_H.basis.nmodes
    channels = SpectralChannel[]
    for (channel_index,(spin,addition)) in enumerate(((:up,true),(:up,false),(:down,true),(:down,false)))
        delta = addition ? 1 : -1
        sector = spin==:up ? (Int(Nup)+delta,Int(Ndown)) : (Int(Nup),Int(Ndown)+delta)
        kind = addition ? :addition : :removal
        if !all(n->0<=n<=nmodes,sector)
            push!(channels,_empty_channel(spin,kind,sector,nmodes,probes))
            continue
        end
        target = spin_hamiltonian(Kup,Kdown,U,sector...;J,max_dimension,max_bytes)
        neighbor = _ground(target;seed=seed+channel_index,ground_atol,ground_krylovdim,
            ground_keep,ground_max_matvecs,max_bytes)
        source = _source_vectors(ground_H.basis,target.basis,ground.vector,spin,addition)
        resolution = _block_resolvent(target,source,ground.energy,addition;
            block_steps=Int(min(big(block_steps),big(size(target,1)))),probe_z=probes,convergence_atol,
            convergence_rtol,rank_atol,max_bytes)
        push!(channels,SpectralChannel(spin,kind,sector,size(target,1),resolution.source_rank,
            resolution.krylov_dimension,resolution.block_steps,resolution.spectrum,
            resolution.exact_moments,resolution.moment_errors,copy(probes),
            resolution.convergence_error,resolution.convergence_scale,resolution.converged,
            resolution.closed_subspace,resolution.closure_residual,neighbor.energy,neighbor.residual))
    end
    named = (up_addition=channels[1],up_removal=channels[2],down_addition=channels[3],down_removal=channels[4])
    combine(a,b) = PoleExpansion(vcat(a.spectrum.poles,b.spectrum.poles),hcat(a.spectrum.weights,b.spectrum.weights))
    up,down = combine(channels[1],channels[2]),combine(channels[3],channels[4])
    moments_up = ntuple(i->channels[1].exact_moments[i]+channels[2].exact_moments[i],3)
    moments_down = ntuple(i->channels[3].exact_moments[i]+channels[4].exact_moments[i],3)
    for moments in (moments_up,moments_down)
        maximum(abs.(moments[1]-Matrix{Float64}(I,nmodes,nmodes)))<=2e-10 || error("cluster anticommutator sum rule failed")
    end
    lower = maximum(ground.energy-channels[i].neighbor_energy for i in (2,4))
    upper = minimum(channels[i].neighbor_energy-ground.energy for i in (1,3))
    converged = all(channel.converged for channel in channels)
    require_convergence && !converged && error("cluster Green function did not converge at the configured frequency probes; increase block_steps")
    return ClusterGreenResult(Matrix{Float64}(Kup),Matrix{Float64}(Kdown),Float64(U),Float64(J),
        Int(Nup),Int(Ndown),ground.energy,ground.residual,size(ground_H,1),ground.vector,
        named,up,down,moments_up,moments_down,converged,(lower,upper))
end

end # module
