module PRL101237004ED

using LinearAlgebra

export SectorBasis, SectorHamiltonian, sector_basis, sector_hamiltonian,
       apply_fermion_ops, dense_hamiltonian

const DEFAULT_MAX_DIMENSION = 100_000
const DEFAULT_MAX_BYTES = 512 * 1024^2

"""
A fixed `(Nup,Ndown)` Fock basis. `nmodes` counts spatial orbitals, with
`(d_xz,d_yz)` consecutive at each Fe. Bits `1:nmodes` encode up electrons,
and bits `nmodes+1:2nmodes` encode down electrons. States are sorted by their
unsigned bit pattern, with canonical creation operators in increasing mode
order. `indices` maps these patterns to one-based basis indices.
"""
struct SectorBasis
    nmodes::Int
    Nup::Int
    Ndown::Int
    states::Vector{UInt64}
    indices::Dict{UInt64,Int}
end

function _sector_counts(nmodes::Integer, Nup::Integer, Ndown::Integer,
                        max_dimension::Integer, max_bytes::Integer)
    0 <= nmodes <= 32 || throw(ArgumentError("nmodes must be between 0 and 32"))
    0 <= Nup <= nmodes || throw(ArgumentError("Nup must be between 0 and nmodes"))
    0 <= Ndown <= nmodes || throw(ArgumentError("Ndown must be between 0 and nmodes"))
    max_dimension > 0 || throw(ArgumentError("max_dimension must be positive"))
    max_bytes > 0 || throw(ArgumentError("max_bytes must be positive"))
    nu = binomial(big(nmodes), Nup)
    nd = binomial(big(nmodes), Ndown)
    dimension = nu * nd
    dimension <= max_dimension || throw(ArgumentError(
        "sector dimension $dimension exceeds max_dimension=$max_dimension"))
    dimension <= typemax(Int) || throw(ArgumentError("sector dimension exceeds Int indexing"))
    # Include a generous allowance for Dict capacity, hash slots, and allocation
    # headers, plus both temporary lists of fixed-population spin masks.
    basis_bytes = 8192 + 160dimension + 8(nu + nd)
    basis_bytes <= max_bytes || throw(ArgumentError(
        "estimated basis memory $basis_bytes bytes exceeds max_bytes=$max_bytes"))
    return (Int(nmodes), Int(Nup), Int(Ndown), Int(nu), Int(nd), Int(dimension), basis_bytes)
end

function _spin_masks(nmodes::Int, population::Int, dimension::Int)
    result = Vector{UInt64}(undef, dimension)
    if population == 0
        result[1] = 0
        return result
    end
    mask = (UInt64(1) << population) - UInt64(1)
    for index in eachindex(result)
        result[index] = mask
        if index < dimension
            # Gosper's next-combination rule; nmodes <= 32 leaves ample headroom.
            low = mask & (~mask + UInt64(1))
            next = mask + low
            mask = next | (((next ⊻ mask) >> 2) ÷ low)
        end
    end
    return result
end

function _make_basis(counts)
    nmodes, Nup, Ndown, nu, nd, dimension, _ = counts
    ups = _spin_masks(nmodes, Nup, nu)
    downs = _spin_masks(nmodes, Ndown, nd)
    states = Vector{UInt64}(undef, dimension)
    indices = Dict{UInt64,Int}()
    sizehint!(indices, dimension)
    index = 0
    for down in downs, up in ups
        index += 1
        state = up | (down << nmodes)
        states[index] = state
        indices[state] = index
    end
    return SectorBasis(nmodes, Nup, Ndown, states, indices)
end

"""
    sector_basis(nmodes, Nup, Ndown; max_dimension=100_000, max_bytes=512*1024^2)

Construct a fixed spin-population basis. Exact integer binomial dimension and
conservative memory checks run before allocating state arrays or the index map.
The UInt64 representation permits at most 32 spatial modes (64 spin orbitals).
"""
function sector_basis(nmodes::Integer, Nup::Integer, Ndown::Integer;
                      max_dimension::Integer=DEFAULT_MAX_DIMENSION,
                      max_bytes::Integer=DEFAULT_MAX_BYTES)
    return _make_basis(_sector_counts(nmodes, Nup, Ndown, max_dimension, max_bytes))
end

"""
    apply_fermion_ops(state::UInt64, ops)

Apply `(mode, creation::Bool)` operations in **right-to-left application order**:
the first tuple acts first on the ket. Modes are one-based in `1:64`. Return
`nothing` for a forbidden annihilation/creation, otherwise `(new_state, sign)`.
The sign counts all occupied preceding spin orbitals, including the other spin.
For example `((2,false),(1,true))` represents `c†_1 c_2`.
"""
function apply_fermion_ops(state::UInt64, ops)
    sign = 1
    for (mode, creation) in ops
        mode isa Integer && 1 <= mode <= 64 ||
            throw(ArgumentError("fermion modes must be integers in 1:64"))
        creation isa Bool || throw(ArgumentError("creation flags must be Bool"))
        bit = UInt64(1) << (mode - 1)
        occupied = !iszero(state & bit)
        occupied == creation && return nothing
        isodd(count_ones(state & (bit - UInt64(1)))) && (sign = -sign)
        state ⊻= bit
    end
    return state, sign
end

"""
Full Eq. (2) plus a spin-independent one-body matrix, stored by compressed
columns without an additional sparse-array dependency. `Uprime=U-2J`; no
chemical-potential shift, linear-density subtraction, or energy constant is
added. `estimated_bytes` is the conservative preallocation estimate used by
the construction guard, including basis and construction workspace.
"""
struct SectorHamiltonian{T<:AbstractFloat} <: AbstractMatrix{T}
    basis::SectorBasis
    U::T
    J::T
    Uprime::T
    colptr::Vector{Int}
    rowindices::Vector{Int}
    values::Vector{T}
    estimated_bytes::BigInt
end

Base.size(h::SectorHamiltonian) = (length(h.basis.states), length(h.basis.states))
Base.size(h::SectorHamiltonian, axis::Integer) = axis < 1 ?
    throw(ArgumentError("dimension must be positive")) : axis <= 2 ? size(h)[axis] : 1

function Base.getindex(h::SectorHamiltonian, row::Int, column::Int)
    checkbounds(h, row, column)
    value = zero(eltype(h))
    for entry in h.colptr[column]:(h.colptr[column + 1] - 1)
        h.rowindices[entry] == row && (value += h.values[entry])
    end
    return value
end

# BigFloat values own a GMP allocation in addition to the stored object.
_value_bytes(::Type{T}) where {T<:AbstractFloat} = sizeof(T)
_value_bytes(::Type{BigFloat}) = 64 + cld(precision(BigFloat), 8)

function _onsite_diagonal(state::UInt64, nmodes::Int, U, J, Uprime)
    energy = zero(U)
    for x in 1:2:nmodes
        y = x + 1
        xu = Int((state >> (x - 1)) & UInt64(1))
        yu = Int((state >> (y - 1)) & UInt64(1))
        xd = Int((state >> (nmodes + x - 1)) & UInt64(1))
        yd = Int((state >> (nmodes + y - 1)) & UInt64(1))
        # (U'-J/2) nx*ny - 2J Szx*Szy, expanded without fractions.
        energy += U * (xu * xd + yu * yd) +
                  (Uprime - J) * (xu * yu + xd * yd) +
                  Uprime * (xu * yd + xd * yu)
    end
    return energy
end

"""
    sector_hamiltonian(K, U, Nup, Ndown; J=U/4,
                       max_dimension=100_000, max_bytes=512*1024^2)

Construct `sum(K[a,b] c†[a,σ] c[b,σ]) + H_int` with the full PRL
**101**, 237004 Eq. (2), `Uprime=U-2J`, and pair hopping `J'=J`. `K`
must be finite, real, symmetric, even-dimensional, and ordered orbital-fast
within Fe sites. Spin exchange has coefficient `-J` multiplying
`Sx⁺Sy⁻+Sx⁻Sy⁺`; pair transfer has coefficient `+J`. Literal fermion
monomials supply their signs in the global Fock ordering.

Dimension and a conservative upper bound on the complete compressed operator,
basis, and construction workspace are checked before allocating these objects.
This is a small-cluster validation implementation; the large eight-Fe sectors
require a separate production solver and resource assessment.
"""
function sector_hamiltonian(K::AbstractMatrix{<:Real}, U::Real,
                            Nup::Integer, Ndown::Integer; J::Real=U/4,
                            max_dimension::Integer=DEFAULT_MAX_DIMENSION,
                            max_bytes::Integer=DEFAULT_MAX_BYTES)
    size(K, 1) == size(K, 2) || throw(ArgumentError("K must be square"))
    nmodes = size(K, 1)
    iseven(nmodes) || throw(ArgumentError("K must have two spatial orbitals per Fe"))
    counts = _sector_counts(nmodes, Nup, Ndown, max_dimension, max_bytes)
    all(isfinite, K) || throw(ArgumentError("K must contain finite values"))
    issymmetric(K) || throw(ArgumentError("K must be real symmetric"))
    isfinite(U) && isfinite(J) || throw(ArgumentError("U and J must be finite"))
    T = typeof(float(zero(promote_type(eltype(K), typeof(U), typeof(J)))))
    T <: AbstractFloat && isconcretetype(T) ||
        throw(ArgumentError("K, U, and J must promote to a concrete floating-point type"))
    u, j = T(U), T(J)
    uprime = u - 2j
    isfinite(u) && isfinite(j) && isfinite(uprime) ||
        throw(ArgumentError("interaction parameters overflow the arithmetic type"))
    dimension = counts[6]
    offdiagonal_terms = count(!iszero, K) - count(!iszero, diag(K))
    # At most one transition per directed occupied-to-empty orbital pair for
    # each spin, plus four local monomials per Fe and one diagonal value.
    transitions_per_state = 1 +
        min(offdiagonal_terms, Int(Nup) * (nmodes - Int(Nup))) +
        min(offdiagonal_terms, Int(Ndown) * (nmodes - Int(Ndown))) +
        (iszero(j) ? 0 : 4 * (nmodes ÷ 2))
    entries = big(dimension) * transitions_per_state
    value_bytes = _value_bytes(T)
    estimated_bytes = counts[7] + 8big(dimension + 1) +
                      entries * (8 + value_bytes) +
                      8192 + 2nmodes^2 * (32 + value_bytes)
    estimated_bytes <= max_bytes || throw(ArgumentError(
        "estimated Hamiltonian memory $estimated_bytes bytes exceeds max_bytes=$max_bytes"))
    entries <= typemax(Int) || throw(ArgumentError("operator storage exceeds Int indexing"))
    basis = _make_basis(counts)
    colptr = Vector{Int}(undef, dimension + 1)
    rows = Vector{Int}(undef, Int(entries))
    values = Vector{T}(undef, Int(entries))
    hopping = Tuple{Int,Int,T}[]
    for source in 1:nmodes, target in 1:nmodes
        source == target && continue
        iszero(K[target, source]) && continue
        push!(hopping, (target, source, T(K[target, source])))
    end
    all(term -> isfinite(term[3]), hopping) ||
        throw(ArgumentError("kinetic entries overflow the arithmetic type"))
    diagonal_K = T[K[mode, mode] for mode in 1:nmodes]
    all(isfinite, diagonal_K) ||
        throw(ArgumentError("kinetic entries overflow the arithmetic type"))
    written = 0
    for (column, state) in enumerate(basis.states)
        colptr[column] = written + 1
        diagonal = _onsite_diagonal(state, nmodes, u, j, uprime)
        for mode in 1:nmodes
            occupancy = Int((state >> (mode - 1)) & UInt64(1)) +
                        Int((state >> (nmodes + mode - 1)) & UInt64(1))
            diagonal += diagonal_K[mode] * occupancy
        end
        written += 1
        rows[written], values[written] = column, diagonal
        for (target, source, amplitude) in hopping, shift in (0, nmodes)
            transition = apply_fermion_ops(state, ((source + shift, false),
                                                   (target + shift, true)))
            transition === nothing && continue
            final, sign = transition
            written += 1
            rows[written], values[written] = basis.indices[final], sign * amplitude
        end
        if !iszero(j)
            for x in 1:2:nmodes
                y, xd, yd = x + 1, x + nmodes, x + 1 + nmodes
                # Each tuple lists the rightmost operator first.
                local_terms = (
                    (-j, ((y, false), (yd, true), (xd, false), (x, true))),
                    (-j, ((yd, false), (y, true), (x, false), (xd, true))),
                    (j, ((y, false), (yd, false), (xd, true), (x, true))),
                    (j, ((x, false), (xd, false), (yd, true), (y, true))),
                )
                for (amplitude, ops) in local_terms
                    transition = apply_fermion_ops(state, ops)
                    transition === nothing && continue
                    final, sign = transition
                    written += 1
                    rows[written], values[written] = basis.indices[final], sign * amplitude
                end
            end
        end
    end
    colptr[end] = written + 1
    resize!(rows, written)
    resize!(values, written)
    return SectorHamiltonian(basis, u, j, uprime, colptr, rows, values, estimated_bytes)
end

function LinearAlgebra.mul!(output::AbstractVector, h::SectorHamiltonian,
                            input::AbstractVector, alpha::Number, beta::Number)
    length(input) == size(h, 2) && length(output) == size(h, 1) ||
        throw(DimensionMismatch("vector lengths must match the Hamiltonian dimension"))
    Base.require_one_based_indexing(output, input)
    source = Base.mightalias(output, input) ? copy(input) : input
    if iszero(beta)
        fill!(output, zero(eltype(output)))
    else
        output .*= beta
    end
    iszero(alpha) && return output
    for column in eachindex(source)
        scale = alpha * source[column]
        for entry in h.colptr[column]:(h.colptr[column + 1] - 1)
            output[h.rowindices[entry]] += h.values[entry] * scale
        end
    end
    return output
end

LinearAlgebra.mul!(output::AbstractVector, h::SectorHamiltonian,
                   input::AbstractVector) = mul!(output, h, input, true, false)

function Base.:*(h::SectorHamiltonian, input::AbstractVector)
    result = Vector{promote_type(eltype(h), eltype(input))}(undef, size(h, 1))
    return mul!(result, h, input)
end

"""
    dense_hamiltonian(h; max_bytes=512*1024^2)

Materialize a dense matrix after checking its additional storage. The limit
applies to this matrix only; the compressed Hamiltonian remains in memory.
`Matrix(h)` uses the default limit. An eigensolver needs further workspace.
"""
function dense_hamiltonian(h::SectorHamiltonian;
                           max_bytes::Integer=DEFAULT_MAX_BYTES)
    max_bytes > 0 || throw(ArgumentError("max_bytes must be positive"))
    n = size(h, 1)
    bytes = big(n)^2 * _value_bytes(eltype(h)) + 128
    bytes <= max_bytes || throw(ArgumentError(
        "dense matrix requires an estimated $bytes bytes, exceeding max_bytes=$max_bytes"))
    result = zeros(eltype(h), n, n)
    for column in 1:n
        for entry in h.colptr[column]:(h.colptr[column + 1] - 1)
            result[h.rowindices[entry], column] += h.values[entry]
        end
    end
    return result
end

Base.Matrix(h::SectorHamiltonian) = dense_hamiltonian(h)

end
