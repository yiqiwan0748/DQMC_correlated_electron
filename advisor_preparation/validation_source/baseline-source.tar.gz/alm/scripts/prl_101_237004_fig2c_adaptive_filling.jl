module PRL101237004Fig2CAdaptiveFilling

include("prl_101_237004_fig2c_filling.jl")
const BaseFilling=PRL101237004Fig2CFilling
const R=BaseFilling.R
const F=R.F

export solve_filling, refine_validity_boundary

function _check_sample(sample,relative)
    sample isa NamedTuple && hasproperty(sample,:valid) &&
        hasproperty(sample,:relative_mu) || throw(ArgumentError("sample requires valid and relative_mu"))
    sample.valid isa Bool && sample.relative_mu==relative && isfinite(relative) ||
        throw(ArgumentError("invalid sample position or validity flag"))
    if sample.valid
        hasproperty(sample,:gradient) && sample.gradient isa Real && isfinite(sample.gradient) ||
            throw(ArgumentError("valid samples require a finite gradient"))
    end
    sample
end

"""Bisect a valid/invalid parameter interval without accepting invalid roots.

A finite mesh can exclude one sampled parameter because its degenerate pole
count skips the target occupation, while nearby parameters remain valid.
Exponential bracketing can consequently jump over a valid gradient root.
This helper returns a bracket only when two valid samples have opposite
gradient signs, or a residual candidate only when a valid sample meets the
gradient threshold. Shrinking onto a domain boundary is not convergence.
It does not certify the separate density residual; solve_filling does that.
"""
function refine_validity_boundary(evaluate,valid_sample,invalid_sample;
                                  gradient_atol=1e-7,x_atol=1e-10,max_iterations=32)
    _check_sample(valid_sample,valid_sample.relative_mu)
    _check_sample(invalid_sample,invalid_sample.relative_mu)
    valid_sample.valid && !invalid_sample.valid || throw(ArgumentError("one valid and one invalid endpoint required"))
    valid_sample.relative_mu!=invalid_sample.relative_mu || throw(ArgumentError("distinct endpoints required"))
    all(isfinite,(gradient_atol,x_atol)) && gradient_atol>0 && x_atol>0 &&
        max_iterations>=0 || throw(ArgumentError("invalid boundary-search controls"))
    good,bad=valid_sample,invalid_sample
    log=NamedTuple[]
    if abs(good.gradient)<=gradient_atol
        return (;status=:residual_candidate,bracket=nothing,candidate=good,valid_endpoint=good,
            invalid_endpoint=bad,iterations=0,evaluations=0,log)
    end
    status=:iteration_limit
    completed=0
    for iteration in 1:max_iterations
        if abs(good.relative_mu-bad.relative_mu)<=x_atol
            status=:domain_boundary_without_root
            break
        end
        relative=(good.relative_mu+bad.relative_mu)/2
        item=_check_sample(evaluate(relative),relative)
        push!(log,item)
        completed=iteration
        if item.valid
            if abs(item.gradient)<=gradient_atol
                return (;status=:residual_candidate,bracket=nothing,candidate=item,
                    valid_endpoint=good,invalid_endpoint=bad,iterations=completed,evaluations=length(log),log)
            elseif signbit(item.gradient)!=signbit(good.gradient)
                bracket=good.relative_mu<item.relative_mu ? (good,item) : (item,good)
                return (;status=:sign_bracket,bracket,candidate=nothing,valid_endpoint=item,
                    invalid_endpoint=bad,iterations=completed,evaluations=length(log),log)
            end
            good=item
        else
            bad=item
        end
    end
    (;status,bracket=nothing,candidate=nothing,valid_endpoint=good,invalid_endpoint=bad,
      iterations=completed,evaluations=length(log),log)
end

function _boundary_pairs(history)
    samples=sort(collect(values(Dict(x.relative_mu=>x for x in history)));by=x->x.relative_mu)
    pairs=Tuple[]
    for j in 1:length(samples)-1
        a,b=samples[j],samples[j+1]
        a.valid==b.valid && continue
        good,bad=a.valid ? (a,b) : (b,a)
        push!(pairs,(good,bad))
    end
    sort!(pairs;by=pair->(abs(pair[1].gradient),abs(pair[1].relative_mu-pair[2].relative_mu)))
end

"""Wrap the frozen Fig2c filling solver with bounded domain-aware retries.

All original keywords pass through unchanged. If the original relative-mu
bracketing fails, inspect adjacent valid/invalid samples and bisect at most
adaptive_max_boundaries such intervals. Only a valid sign bracket or valid
small-gradient sample seeds a retry. The original solver independently
certifies both filling and stationarity on every accepted retry.

Returned fields preserve choice.data, converged and status; attempts and
adaptive_boundaries retain every small scalar diagnostic. There are no
canonical vectors, reference-system objects or lattice matrices in the result.
"""
function solve_filling(state,lat;adaptive_max_iterations=32,adaptive_max_boundaries=4,kwargs...)
    adaptive_max_iterations>=0 && adaptive_max_boundaries>=0 ||
        throw(ArgumentError("adaptive budgets must be nonnegative"))
    arguments=(;kwargs...)
    original=BaseFilling.solve_filling(state,lat;arguments...)
    attempts=Any[original]
    boundaries=Any[]
    function finished(result)
        boundary_functionals=sum(count(x->x.valid,b.log) for b in boundaries;init=0)
        boundary_occupations=sum(sum(x.occupation_region.evaluations for x in b.log;init=0) for b in boundaries;init=0)
        merge(result,(;attempts,adaptive_boundaries=boundaries,retry_count=length(attempts)-1,
            functional_evaluations=sum(x.functional_evaluations for x in attempts)+boundary_functionals,
            occupation_evaluations=sum(x.occupation_evaluations for x in attempts)+boundary_occupations,
            adaptive_max_iterations,adaptive_max_boundaries))
    end
    original.converged && return finished(original)
    original.status in (:no_relative_bracket,:occupation_region_lost) || return finished(original)
    pairs=_boundary_pairs(original.history)
    isempty(pairs) && return finished(original)
    ref=hasproperty(state,:reference) ? state.reference : state
    gradient_atol=get(arguments,:gradient_atol,1e-7)
    order=get(arguments,:order,24)
    quadrature=F.imaginary_quadrature(order)
    edge_fraction=get(arguments,:edge_fraction,.03)
    occupation_x_atol=get(arguments,:occupation_x_atol,1e-9)
    occupation_max_iterations=get(arguments,:occupation_max_iterations,36)
    for (good,bad) in Iterators.take(pairs,adaptive_max_boundaries)
        function evaluate(relative)
            region=BaseFilling.occupation_region(ref,lat,relative;mu_prime_initial=good.mu_prime,
                edge_fraction,x_atol=occupation_x_atol,max_iterations=occupation_max_iterations)
            if !region.converged
                return (;valid=false,relative_mu=relative,status=region.status,occupation_region=region)
            end
            point=region.choice
            raw=F.evaluate_functional(ref,lat,point.mu,point.mu_prime;quadrature)
            data=merge(raw,(;canonical_energy=raw.omega+2raw.mu))
            (;valid=true,relative_mu=relative,mu=data.mu,mu_prime=data.mu_prime,data,
                gradient=data.mu_prime_gradient,density_residual=data.density-2,inertia=point,
                occupation_region=region,status=:evaluated)
        end
        boundary=refine_validity_boundary(evaluate,good,bad;gradient_atol,
            x_atol=get(arguments,:relative_x_atol,1e-10),max_iterations=adaptive_max_iterations)
        push!(boundaries,boundary)
        if boundary.bracket!==nothing
            a,b=boundary.bracket
            relative=(a.relative_mu+b.relative_mu)/2
            mup=(a.mu_prime+b.mu_prime)/2
            step=(b.relative_mu-a.relative_mu)/2
            retry_arguments=merge(arguments,(;mu_initial=mup-relative,mu_prime_initial=mup,
                relative_step=step,max_bracket_expansions=0))
        elseif boundary.candidate!==nothing
            point=boundary.candidate
            retry_arguments=merge(arguments,(;mu_initial=point.mu,mu_prime_initial=point.mu_prime,
                relative_step=max(1e-4,.1abs(good.relative_mu-bad.relative_mu)),max_bracket_expansions=0))
        else
            continue
        end
        retry=BaseFilling.solve_filling(state,lat;retry_arguments...)
        push!(attempts,retry)
        retry.converged && return finished(retry)
    end
    candidates=filter(x->x.choice!==nothing,attempts)
    best=isempty(candidates) ? original : candidates[argmin(abs(x.choice.gradient)+abs(x.choice.density_residual) for x in candidates)]
    finished(merge(best,(;converged=false,status=:adaptive_bracket_not_resolved)))
end

end
