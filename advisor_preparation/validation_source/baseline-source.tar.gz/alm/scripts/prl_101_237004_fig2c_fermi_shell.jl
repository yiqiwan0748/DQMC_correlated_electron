module PRL101237004Fig2CFermiShell

export resolve_fermi_shell, resolve_relative_cusp

"""Resolve an integer count jump by its canonical zero-temperature ensemble.

The callbacks are `inertia(mu_prime)` and `evaluate(mu_prime)`, with the
relative shift d=mu_prime-mu held fixed. Inertia records have integer mismatch,
its per-site offset, mu_prime, mu, and reference_count. Functional records have
omega, density, mu_prime_gradient, moment, mu and mu_prime. On a common-shift
occupation interval, g_muprime-(n-target)=offset and d(Omega+target*mu)/dmuprime
=offset. The crossing fraction is fixed by the count jump; no broadening or
fit determines it. A direct integral evaluated exactly on the pole would
instead select half occupation, which is not generally the canonical limit.

Both side values are evaluated away from the pole. Their canonical energies
are linearly continued to the crossing and must agree. Mixed derivatives are
subgradients at the finite-system cusp. Fields should be differentiated by
re-solving the canonical functional on each side, not by holding both chemical
potentials at this cusp. Shell degeneracy is resolved only to shell_x_atol.
"""
function resolve_fermi_shell(inertia,evaluate,interval,relative;
        initial_region,target=2.,shell_x_atol=1e-12,max_iterations=48,
        side_max_iterations=24,identity_atol=1e-8,continuity_atol=1e-8,integration_scale=1.)
    lo,hi=interval
    all(isfinite,(lo,hi,relative,target,shell_x_atol,identity_atol,continuity_atol)) &&
        lo<hi && shell_x_atol>0 && identity_atol>0 && continuity_atol>0 &&
        max_iterations>=0 && side_max_iterations>=1 && isfinite(integration_scale) && integration_scale>0 || throw(ArgumentError("invalid shell controls"))
    cache=Dict{Float64,Any}(x.mu_prime=>x for x in initial_region.log)
    function at(mup)
        get!(cache,Float64(mup)) do
            local x=inertia(Float64(mup))
            x.mu_prime==mup && isfinite(x.offset) && x.mismatch isa Integer ||
                throw(ArgumentError("inertia callback requires a finite integer count record at the requested mu_prime"))
            x
        end
    end
    calls=Ref(0)
    function values_at(mup)
        calls[]+=1
        local x=evaluate(mup)
        x.mu_prime==mup && all(isfinite,(x.omega,x.density,x.mu_prime_gradient,x.moment,x.mu,x.mu_prime)) ||
            throw(ArgumentError("functional callback returned invalid values or mu_prime"))
        x
    end
    function finish(status;data=nothing,point=nothing,metadata=nothing,lower=NaN,upper=NaN)
        good=status in (:resolved_shell,:resolved_interval)
        region=merge(initial_region,(;status,converged=good,choice=point,lower,upper,width=upper-lower,
            kind=status==:resolved_shell ? :canonical_fermi_shell : :refined_occupation_interval,
            common_shift=point===nothing || !hasproperty(initial_region,:anchor) ? NaN : point.mu_prime-initial_region.anchor,
            evaluations=length(cache),log=[cache[x] for x in sort(collect(keys(cache)))],
            shell=metadata))
        (;converged=good,status,data,inertia=point,occupation_region=region,
          functional_evaluations=calls[])
    end
    positive=filter(x->x.mismatch>0,collect(values(cache)))
    negative=filter(x->x.mismatch<0,collect(values(cache)))
    isempty(positive) && return finish(:shell_no_positive_bracket)
    isempty(negative) && return finish(:shell_no_negative_bracket)
    a=positive[argmax(x.mu_prime for x in positive)]
    b=negative[argmin(x.mu_prime for x in negative)]
    a.mu_prime<b.mu_prime || return finish(:shell_nonmonotone_count)
    iterations=0
    for i in 1:max_iterations
        b.mu_prime-a.mu_prime<=shell_x_atol && break
        mid=at((a.mu_prime+b.mu_prime)/2)
        iterations=i
        if mid.mismatch==0
            x=values_at(mid.mu_prime)
            identity=x.mu_prime_gradient-(x.density-target)
            abs(identity)<=identity_atol || return finish(:interval_quadrature_identity_unresolved;
                metadata=(;identity_error=identity),lower=a.mu_prime,upper=b.mu_prime)
            data=merge(x,(;canonical_energy=x.omega+target*x.mu,occupation_policy=:integer_interval))
            return finish(:resolved_interval;data,point=mid,lower=a.mu_prime,upper=b.mu_prime)
        elseif mid.mismatch>0
            a=mid
        else
            b=mid
        end
    end
    width=b.mu_prime-a.mu_prime
    width<=shell_x_atol || return finish(:shell_iteration_limit;lower=a.mu_prime,upper=b.mu_prime)
    shell=(a.mu_prime+b.mu_prime)/2
    fraction=a.mismatch/(a.mismatch-b.mismatch)
    0<fraction<1 || return finish(:shell_invalid_fraction;lower=a.mu_prime,upper=b.mu_prime)
    function safe_side(direction,mismatch)
        delta=max(16shell_x_atol,(hi-lo)*1e-8)
        previous=nothing
        for _ in 1:side_max_iterations
            trial=shell+direction*delta
            lo<trial<hi || break
            local point=at(trial)
            point.mismatch==mismatch || break
            previous=point
            delta*=2
        end
        previous===nothing && return nothing
        # Interior to the largest verified constant-count step. This avoids
        # evaluating next to either the target shell or its adjacent shell.
        interior=at((shell+previous.mu_prime)/2)
        interior.mismatch==mismatch ? interior : nothing
    end
    left=safe_side(-1,a.mismatch);right=safe_side(1,b.mismatch)
    (left===nothing || right===nothing) && return finish(:shell_side_interval_unresolved;
        lower=a.mu_prime,upper=b.mu_prime)
    left.reference_count==right.reference_count || return finish(:shell_reference_zero_ambiguous;
        lower=a.mu_prime,upper=b.mu_prime)
    x=values_at(left.mu_prime); y=values_at(right.mu_prime)
    error_left=x.mu_prime_gradient-(x.density-target)-left.offset
    error_right=y.mu_prime_gradient-(y.density-target)-right.offset
    fa=x.omega+target*x.mu+left.offset*(shell-left.mu_prime)
    fb=y.omega+target*y.mu+right.offset*(shell-right.mu_prime)
    metadata=(;fraction,mismatch_left=a.mismatch,mismatch_right=b.mismatch,
        offset_left=left.offset,offset_right=right.offset,mu_prime_shell=shell,
        shell_bracket=(a.mu_prime,b.mu_prime),shell_width=width,
        mu_prime_left=left.mu_prime,mu_prime_right=right.mu_prime,
        density_left=x.density,density_right=y.density,
        gradient_left=x.mu_prime_gradient,gradient_right=y.mu_prime_gradient,
        moment_left=x.moment,moment_right=y.moment,
        identity_error_left=error_left,identity_error_right=error_right,
        canonical_left_at_shell=fa,canonical_right_at_shell=fb,
        canonical_continuity_error=fb-fa,iterations,
        interpretation=:canonical_zero_temperature_shell_ensemble)
    max(abs(error_left),abs(error_right))<=identity_atol ||
        return finish(:shell_quadrature_identity_unresolved;metadata,lower=a.mu_prime,upper=b.mu_prime)
    abs(fb-fa)<=continuity_atol || return finish(:shell_energy_continuity_unresolved;
        metadata,lower=a.mu_prime,upper=b.mu_prime)
    mix(a,b)=(1-fraction)*a+fraction*b
    canonical=mix(fa,fb)
    mu=shell-relative
    moment=mix(x.moment,y.moment)
    data=merge(x,(;omega=canonical-target*mu,density=mix(x.density,y.density),
        mu_prime_gradient=mix(x.mu_prime_gradient,y.mu_prime_gradient),moment,
        moment_abs=abs(moment),mu,mu_prime=shell,canonical_energy=canonical,
        occupation_policy=:canonical_shell_ensemble,shell_fraction=fraction))
    # Retain the ordinary evaluator's additive decomposition at the crossing.
    if hasproperty(data,:omega_reference)
        omega_reference=x.omega_reference-target*(shell-left.mu_prime)
        data=merge(data,(;omega_reference))
        if hasproperty(data,:trace_correction) && hasproperty(data,:trace_log_integral)
            data=merge(data,(;trace_log_integral=(omega_reference+data.trace_correction-data.omega)/integration_scale))
        end
    end
    point=merge(left,(;mu_prime=shell,mu,relative_mu=relative,mismatch=0.0,offset=0.0,
        lattice_count=mix(left.lattice_count,right.lattice_count),
        minimum_reduced_eigenvalue=0.,occupation_policy=:canonical_shell_ensemble,
        shell_fraction=fraction))
    finish(:resolved_shell;data,point,metadata,lower=a.mu_prime,upper=b.mu_prime)
end

"""Mix two coalescing occupation configurations at a relative-potential cusp.

This fallback requires a resolved sign bracket narrower than relative_x_atol,
closed occupation windows, coalescing physical/reference chemical potentials,
and continuous canonical energy. Both limiting configurations must already
have zero common-shift count. The ensemble weight is set by the remaining
reference-potential stationarity equation, and density is checked separately.
It is a subgradient limit at common model parameters, not a mixture of
self-energies at distinct finite-separated reference potentials. Convergence
checks must re-solve filling because evaluating one d at the crossing can
choose either limiting occupation configuration.
"""
function resolve_relative_cusp(left,right;relative_x_atol=1e-10,
        potential_atol=1e-8,occupation_width_atol=1e-7,gradient_atol=1e-7,
        density_atol=1e-7,continuity_atol=1e-8,integration_scale=1.,target=2.)
    all(isfinite,(relative_x_atol,potential_atol,occupation_width_atol,gradient_atol,
        density_atol,continuity_atol,integration_scale,target)) &&
        min(relative_x_atol,potential_atol,occupation_width_atol,gradient_atol,
        density_atol,continuity_atol,integration_scale)>0 || throw(ArgumentError("invalid relative-cusp controls"))
    fail(status)=(;converged=false,status,choice=nothing)
    left.valid && right.valid || return fail(:cusp_invalid_endpoint)
    dl,dr=left.relative_mu,right.relative_mu
    0<dr-dl<=relative_x_atol || return fail(:cusp_bracket_not_closed)
    signbit(left.gradient)!=signbit(right.gradient) || return fail(:cusp_no_sign_bracket)
    min(abs(left.gradient),abs(right.gradient))>10gradient_atol || return fail(:cusp_jump_not_resolved)
    x,y=left.data,right.data
    max(abs(x.mu-y.mu),abs(x.mu_prime-y.mu_prime))<=potential_atol ||
        return fail(:cusp_potentials_do_not_coalesce)
    max(left.occupation_region.width,right.occupation_region.width)<=occupation_width_atol ||
        return fail(:cusp_occupation_windows_open)
    left.inertia.offset==right.inertia.offset==0 || return fail(:cusp_count_not_zero)
    left.inertia.reference_count==right.inertia.reference_count || return fail(:cusp_reference_zero_ambiguous)
    d=(dl+dr)/2
    mup=(x.mu_prime+y.mu_prime)/2
    mu=mup-d
    fraction=left.gradient/(left.gradient-right.gradient)
    mix(a,b)=(1-fraction)*a+fraction*b
    fl=x.canonical_energy+left.gradient*(d-dl)
    fr=y.canonical_energy+right.gradient*(d-dr)
    abs(fr-fl)<=continuity_atol || return fail(:cusp_energy_discontinuous)
    density=mix(x.density,y.density)
    gradient=mix(left.gradient,right.gradient)
    abs(density-target)<=density_atol && abs(gradient)<=gradient_atol ||
        return fail(:cusp_mixed_residual_unresolved)
    canonical=mix(fl,fr)
    moment=mix(x.moment,y.moment)
    data=merge(x,(;mu,mu_prime=mup,omega=canonical-target*mu,canonical_energy=canonical,
        density,mu_prime_gradient=gradient,moment,moment_abs=abs(moment),
        occupation_policy=:canonical_relative_cusp_ensemble,shell_fraction=fraction,
        relative_cusp_fraction=fraction))
    if hasproperty(data,:omega_reference)
        omega_reference=mix(x.omega_reference-target*(mup-x.mu_prime),
            y.omega_reference-target*(mup-y.mu_prime))
        # Trace correction is affine in d; interpolate it to the midpoint.
        trace_correction=(x.trace_correction+y.trace_correction)/2
        data=merge(data,(;omega_reference,trace_correction,
            trace_log_integral=(omega_reference+trace_correction-data.omega)/integration_scale))
    end
    metadata=(;fraction,left_relative_mu=dl,right_relative_mu=dr,
        left_mu=x.mu,right_mu=y.mu,left_mu_prime=x.mu_prime,right_mu_prime=y.mu_prime,
        left_gradient=left.gradient,right_gradient=right.gradient,
        left_density=x.density,right_density=y.density,left_moment=x.moment,right_moment=y.moment,
        left_canonical_at_cusp=fl,right_canonical_at_cusp=fr,canonical_continuity_error=fr-fl,
        relative_bracket_width=dr-dl,
        interpretation=:canonical_zero_temperature_relative_cusp_ensemble,
        quadrature_validation=:resolve_filling_again)
    point=merge(left.inertia,(;mu,mu_prime=mup,relative_mu=d,mismatch=0.,offset=0.,
        minimum_reduced_eigenvalue=0.,occupation_policy=:canonical_relative_cusp_ensemble,
        shell_fraction=fraction))
    anchor=hasproperty(left.occupation_region,:anchor) ? left.occupation_region.anchor : mup
    region=merge(left.occupation_region,(;status=:resolved_relative_cusp,converged=true,
        choice=point,lower=mup,upper=mup,width=0.,anchor,common_shift=mup-anchor,
        kind=:canonical_relative_cusp,log=NamedTuple[],evaluations=0,shell=metadata))
    choice=(;valid=true,relative_mu=d,mu,mu_prime=mup,data,gradient,density_residual=density-target,
        inertia=point,occupation_region=region,functional_evaluations=0,
        status=:evaluated_relative_cusp_ensemble)
    (;converged=true,status=:resolved_relative_cusp,choice)
end

end
