module PRL101237004Fig2cField

export stationary_field

"""Search nonnegative stripe fields using a half-filled canonical potential.

`center(h)` returns a named tuple with `canonical`, `mu`, `mu_prime`, and
`density`, plus arbitrary audit data. It must make mu_prime stationary and
enforce density two. `side(h, center_data)` returns the grand potential with
both chemical potentials held at the center values. Thus its central finite
difference measures the partial field derivative; the density and reference
stationarity conditions give the canonical envelope derivative.

Every sampled local energy minimum is considered. A finite coarse grid is
not a proof that no additional narrow well exists. Derivative convergence is
only for the stated finite-difference step; a final step refinement is needed.
"""
function stationary_field(center,side;fields=[0.,.002,.005,.015,.04,.08,.14],
    derivative_step=2e-4,gradient_atol=2e-6,max_iterations=14,
    energy_atol=2e-9,density_atol=1e-7,progress=(args...)->nothing)
    grid=Float64.(collect(fields))
    length(grid)>=3 && first(grid)==0 && all(diff(grid).>0) && all(isfinite,grid) ||
        throw(ArgumentError("fields must be finite, increasing and start at zero"))
    derivative_step>0 && gradient_atol>0 && max_iterations>0 || throw(ArgumentError("invalid field search settings"))
    cache=Dict{Float64,Any}(); derivatives=Dict{Float64,Any}(); history=NamedTuple[]
    function at(h)
        get!(cache,Float64(h)) do
            x=center(Float64(h))
            all(isfinite,(x.canonical,x.mu,x.mu_prime,x.density)) || error("nonfinite center")
            abs(x.density-2)<=density_atol || error("center is not half filled")
            progress(:center,h,x)
            x
        end
    end
    function derivative(h)
        get!(derivatives,Float64(h)) do
            x=at(h)
            d=Float64(derivative_step)
            lo=side(h-d,x);hi=side(h+d,x)
            all(isfinite,(lo,hi)) || error("nonfinite side potential")
            g=(hi-lo)/(2d)
            # Ω(center)=F(center)−2μ on the enforced half-filled branch.
            curvature=(hi-2(x.canonical-2x.mu)+lo)/d^2
            data=(;h=Float64(h),gradient=g,curvature,step=d,left=lo,right=hi)
            push!(history,data)
            progress(:derivative,h,data)
            data
        end
    end
    samples=[at(h) for h in grid]
    values=[x.canonical for x in samples]
    brackets=Tuple{Float64,Float64}[]
    for i in 2:length(grid)-1
        values[i]<values[i-1] && values[i]<=values[i+1] &&
            max(values[i-1]-values[i],values[i+1]-values[i])>energy_atol &&
            push!(brackets,(grid[i-1],grid[i+1]))
    end
    values[end]<values[end-1]-energy_atol && error("field grid ends on a descending branch; extend upper field")
    roots=NamedTuple[]; failures=NamedTuple[]
    for (left,right) in brackets
        # At h=0 symmetry makes the derivative vanish even when it is a
        # maximum. Use a small strictly positive field to bracket an ordered
        # solution. Coarse h=0 remains a separate comparison candidate.
        a=left==0 ? min(grid[2]/2,derivative_step) : left
        b=right
        ga=derivative(a).gradient;gb=derivative(b).gradient
        if !(ga<0 && gb>0)
            push!(failures,(;bracket=(left,right),reason=:not_sign_bracket,ga,gb))
            continue
        end
        last_a,last_b=a,b; last_ga,last_gb=ga,gb
        best=abs(ga)<abs(gb) ? a : b
        converged=false
        iterations=0
        for iteration in 1:max_iterations
            iterations=iteration
            proposal=last_b-last_gb*(last_b-last_a)/(last_gb-last_ga)
            if !isfinite(proposal) || !(a<proposal<b) || iteration%5==0
                proposal=(a+b)/2
            end
            g=derivative(proposal).gradient
            abs(g)<abs(derivative(best).gradient) && (best=proposal)
            last_a,last_ga=last_b,last_gb
            last_b,last_gb=proposal,g
            if g<0
                a,ga=proposal,g
            else
                b,gb=proposal,g
            end
            if abs(g)<=gradient_atol
                best=proposal;converged=true
                break
            end
        end
        # The sign bracket belongs to the constrained canonical envelope.
        # Partial Ω_hh at fixed μ,μ′ can be negative at an envelope minimum:
        # the second derivative also contains the response of those variables.
        if converged
            push!(roots,(;h=best,center=at(best),derivative=derivative(best),bracket=(a,b),iterations))
        else
            push!(failures,(;bracket=(a,b),reason=:derivative_not_converged,ga,gb))
        end
    end
    isempty(failures) || return (;status=:unresolved,selected=nothing,roots,failures,cache,history,grid,values)
    zero=at(0.)
    if !isempty(roots)
        selected=roots[argmin(x.center.canonical for x in roots)]
        if selected.center.canonical<zero.canonical-energy_atol
            return (;status=:magnetic_minimum,selected,roots,failures,cache,history,grid,values)
        end
    end
    zero_derivative=derivative(0.)
    # For this physical spin-symmetric model all mixed h/chemical-potential
    # derivatives vanish at h=0, so partial and envelope curvatures coincide
    # there. A final second-step check is needed near zero curvature.
    zero_derivative.curvature>0 && minimum(values)>=zero.canonical-energy_atol ||
        return (;status=:unresolved,selected=nothing,roots,failures,cache,history,grid,values)
    selected=(;h=0.,center=zero,derivative=zero_derivative,bracket=(0.,grid[2]),iterations=0)
    (;status=:paramagnetic_minimum,selected,roots,failures,cache,history,grid,values)
end

end
