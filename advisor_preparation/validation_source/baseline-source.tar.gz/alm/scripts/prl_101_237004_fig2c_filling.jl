module PRL101237004Fig2CFilling

using LinearAlgebra
include("prl_101_237004_fig2c_reference.jl")
const R=PRL101237004Fig2cReference
const F=R.F

export solve_filling, occupation_inertia, occupation_region

"""Integer zero-frequency occupation mismatch, summed over both spins.

For d=mu_prime-mu, diagonalize G′(0)=L*S*L†, with S a diagonal sign
matrix. Sylvester inertia gives the positive count of G(0) from
S-L†*V*L, avoiding inversion near a zero of G′. A zero eigenvalue of G′
has L=0 and contributes the same sign to both counts. `offset` is the
integer mismatch divided by sites*momentum_points. On a fixed canonical
reference branch, g_mu_prime-(n-Nref/sites)=offset, away from Fermi poles.
This is a pole-count identity, not an assertion of an insulating gap.
"""
function occupation_inertia(ref::F.ReferenceSystem,lat::F.LatticeEmbedding,
                            relative_mu::Real,mu_prime::Real;zero_atol=1e-13)
    all(isfinite,(relative_mu,mu_prime)) || throw(ArgumentError("finite potentials required"))
    ref.nsites==lat.nsites || throw(DimensionMismatch("reference and lattice differ"))
    ref.mu_interval[1]<mu_prime<ref.mu_interval[2] || throw(ArgumentError("mu_prime is outside reference charge branch"))
    nk=length(lat.hoppings)
    reference_count=0; lattice_count=0
    minimum_reduced_eigenvalue=Inf
    zero_reference_modes=0
    for spin in 1:2
        green,_=ref.green(complex(mu_prime,0.0),spin)
        all(isfinite,green) || error("nonfinite zero-frequency reference Green function")
        eig=eigen(Hermitian((green+green')/2))
        scale=max(1.0,maximum(abs,eig.values))
        values=map(x->abs(x)<=zero_atol*scale ? 0.0 : x,eig.values)
        zero_reference_modes+=count(iszero,values)
        signs=map(x->x<0 ? -1.0 : 1.0,values)
        root=eig.vectors*Diagonal(sqrt.(abs.(values)))
        reference_count+=count(>(0),signs)
        for hopping in lat.hoppings
            potential=hopping-ref.kinetics[spin]+relative_mu*I
            reduced=Diagonal(signs)-root'*potential*root
            ev=eigvals(Hermitian((reduced+reduced')/2))
            lattice_count+=count(>(0),ev)
            minimum_reduced_eigenvalue=min(minimum_reduced_eigenvalue,minimum(abs,ev))
        end
    end
    mismatch=nk*reference_count-lattice_count
    (;mu_prime=Float64(mu_prime),mu=Float64(mu_prime-relative_mu),relative_mu=Float64(relative_mu),
      mismatch,offset=mismatch/(ref.nsites*nk),reference_count,lattice_count,
      minimum_reduced_eigenvalue,zero_reference_modes)
end

"""Choose a common chemical-potential shift with zero occupation mismatch.

The reference charge interval is open and trimmed by edge_fraction. A local
interval around the supplied anchor is retained when three inertia checks
already have zero mismatch. Otherwise bounded bisections locate the lower
and upper count transitions and choose the middle of their zero-count region.
The returned interval is a finite-mesh occupation interval, not a certified
thermodynamic charge gap. No endpoint with nonzero mismatch is accepted.
"""
function occupation_region(ref::F.ReferenceSystem,lat::F.LatticeEmbedding,relative_mu;
                           mu_prime_initial=nothing,edge_fraction=.03,x_atol=1e-9,
                           max_iterations=36,local_guard_fraction=.001)
    lo,hi=ref.mu_interval
    all(isfinite,(lo,hi)) && lo<hi || throw(ArgumentError("finite reference charge interval required"))
    0<=edge_fraction<.5 || throw(ArgumentError("invalid charge-edge fraction"))
    x_atol>0 && max_iterations>=0 && local_guard_fraction>0 || throw(ArgumentError("invalid occupation-search tolerances"))
    a=max(nextfloat(lo),lo+edge_fraction*(hi-lo))
    b=min(prevfloat(hi),hi-edge_fraction*(hi-lo))
    a<b || throw(ArgumentError("empty charge-search interior"))
    anchor=mu_prime_initial===nothing ? (a+b)/2 : clamp(Float64(mu_prime_initial),a,b)
    isfinite(anchor) || throw(ArgumentError("finite mu_prime anchor required"))
    cache=Dict{Float64,Any}()
    function at(x)
        get!(cache,Float64(x)) do
            occupation_inertia(ref,lat,relative_mu,x)
        end
    end
    function result(status,choice,lower,upper,kind)
        (;status,converged=status==:resolved,choice,lower,upper,width=upper-lower,
          anchor,common_shift=choice===nothing ? NaN : choice.mu_prime-anchor,
          kind,charge_interval=(lo,hi),search_interval=(a,b),evaluations=length(cache),
          log=[cache[x] for x in sort(collect(keys(cache)))])
    end
    initial=at(anchor)
    guard=max(8x_atol,local_guard_fraction*(b-a))
    if initial.mismatch==0 && a<anchor-guard<anchor+guard<b
        lower,upper=at(anchor-guard),at(anchor+guard)
        if lower.mismatch==upper.mismatch==0
            return result(:resolved,initial,lower.mu_prime,upper.mu_prime,:verified_local_interval)
        end
    end
    left,right=at(a),at(b)
    if left.mismatch<0 || right.mismatch>0
        return result(:no_occupation_bracket,nothing,a,b,:unresolved)
    end
    # First nonpositive mismatch: the lower edge of a possible zero region.
    lower=a
    if left.mismatch>0
        lower_left,lower_right=a,b
        for _ in 1:max_iterations
            lower_right-lower_left<=x_atol && break
            midpoint=(lower_left+lower_right)/2
            if at(midpoint).mismatch>0
                lower_left=midpoint
            else
                lower_right=midpoint
            end
        end
        lower=lower_right
    end
    # Last nonnegative mismatch: the upper edge of that region.
    upper=b
    if right.mismatch<0
        upper_left,upper_right=a,b
        for _ in 1:max_iterations
            upper_right-upper_left<=x_atol && break
            midpoint=(upper_left+upper_right)/2
            if at(midpoint).mismatch>=0
                upper_left=midpoint
            else
                upper_right=midpoint
            end
        end
        upper=upper_left
    end
    upper-lower>4x_atol || return result(:unresolved_occupation_interval,nothing,lower,upper,:unresolved)
    selected=at((lower+upper)/2)
    selected.mismatch==0 || return result(:target_count_skipped,nothing,lower,upper,:unresolved)
    result(:resolved,selected,lower,upper,:located_occupation_interval)
end

"""
    solve_filling(state,lat;mu_initial,mu_prime_initial=nothing,order=24,...)

Solve half-filled reference stationarity at fixed h, varying d=mu_prime-mu.
For each d, occupation_region chooses a common shift with zero mismatch.
Consequently g_mu_prime=n-2 and F=Omega+2mu is independent of that common
shift within the finite-mesh occupation region. A safeguarded scalar root
in d then enforces both residuals explicitly. This avoids a singular 2D
Newton Jacobian on zero-temperature occupation plateaus.

`choice.data` contains the original functional values plus canonical_energy.
Only small scalar logs are returned; no canonical states or Hamiltonians are
retained in the result. `converged` certifies the callback residuals only;
quadrature, Green-function depth and reference-sector checks remain separate.
The canonical reference occupation must equal two electrons per Fe.
"""
function solve_filling(state,lat;mu_initial,mu_prime_initial=nothing,order=24,
                       gradient_atol=1e-7,density_atol=1e-7,relative_step=nothing,
                       relative_x_atol=1e-10,max_iterations=32,max_bracket_expansions=8,
                       edge_fraction=.03,occupation_x_atol=1e-9,
                       occupation_max_iterations=36)
    ref=hasproperty(state,:reference) ? state.reference : state
    target=ref.particles/ref.nsites
    target==2 || throw(ArgumentError("half-filled reference must contain two electrons per Fe"))
    all(isfinite,(mu_initial,gradient_atol,density_atol,relative_x_atol)) &&
        gradient_atol>0 && density_atol>0 && relative_x_atol>0 || throw(ArgumentError("invalid filling tolerances"))
    max_iterations>=0 && max_bracket_expansions>=0 || throw(ArgumentError("iteration limits must be nonnegative"))
    lo,hi=ref.mu_interval
    all(isfinite,(lo,hi)) && lo<hi || throw(ArgumentError("finite reference charge interval required"))
    anchor=mu_prime_initial===nothing ? clamp(Float64(mu_initial),lo+.1(hi-lo),hi-.1(hi-lo)) : Float64(mu_prime_initial)
    isfinite(anchor) || throw(ArgumentError("finite reference-mu initial value required"))
    relative_initial=anchor-mu_initial
    step=relative_step===nothing ? max(.005,.05(hi-lo)) : Float64(relative_step)
    isfinite(step) && step>0 || throw(ArgumentError("relative step must be positive"))
    quadrature=F.imaginary_quadrature(order)
    cache=Dict{Float64,Any}()
    history=NamedTuple[]
    function probe(relative)
        haskey(cache,relative) && return cache[relative]
        valid_previous=filter(x->x.valid,history)
        local_anchor=isempty(valid_previous) ? anchor :
            valid_previous[argmin(abs(x.relative_mu-relative) for x in valid_previous)].mu_prime
        region=occupation_region(ref,lat,relative;mu_prime_initial=local_anchor,
            edge_fraction,x_atol=occupation_x_atol,max_iterations=occupation_max_iterations)
        if !region.converged
            item=(;valid=false,relative_mu=relative,status=region.status,occupation_region=region)
        else
            point=region.choice
            x=F.evaluate_functional(ref,lat,point.mu,point.mu_prime;quadrature)
            data=merge(x,(;canonical_energy=x.omega+target*x.mu))
            item=(;valid=true,relative_mu=relative,mu=data.mu,mu_prime=data.mu_prime,
                data,gradient=data.mu_prime_gradient,density_residual=data.density-target,
                inertia=point,occupation_region=region,status=:evaluated)
        end
        cache[relative]=item
        push!(history,item)
        item
    end
    good(item)=item.valid && abs(item.gradient)<=gradient_atol && abs(item.density_residual)<=density_atol
    function finish(status,choice,bracket,iterations)
        reference_probe_converged=hasproperty(state,:result) ? state.result.converged : nothing
        (;converged=status==:converged,status,choice,relative_bracket=bracket,iterations,
          functional_evaluations=count(x->x.valid,history),
          occupation_evaluations=sum(x.occupation_region.evaluations for x in history),
          mu_initial=Float64(mu_initial),mu_prime_initial=anchor,relative_initial,
          gradient_atol,density_atol,order,reference_probe_converged,history)
    end
    function bracket()
        valid=sort(filter(x->x.valid,history);by=x->x.relative_mu)
        pairs=[(valid[j],valid[j+1]) for j in 1:length(valid)-1
            if signbit(valid[j].gradient)!=signbit(valid[j+1].gradient)]
        isempty(pairs) && return nothing
        pairs[argmin(abs((a.relative_mu+b.relative_mu)/2-relative_initial) for (a,b) in pairs)]
    end
    initial=probe(Float64(relative_initial))
    good(initial) && return finish(:converged,initial,(relative_initial,relative_initial),0)
    bounds=nothing
    for expansion in 0:max_bracket_expansions
        for relative in (relative_initial-step*2.0^expansion,relative_initial+step*2.0^expansion)
            item=probe(relative)
            good(item) && return finish(:converged,item,(relative,relative),0)
        end
        bounds=bracket()
        bounds===nothing || break
    end
    valid=filter(x->x.valid,history)
    best=isempty(valid) ? nothing : valid[argmin(abs(x.gradient)+abs(x.density_residual) for x in valid)]
    bounds===nothing && return finish(:no_relative_bracket,best,(NaN,NaN),0)
    left,right=bounds
    previous,current=left,right
    for iteration in 1:max_iterations
        width=right.relative_mu-left.relative_mu
        width>relative_x_atol || return finish(:relative_tolerance_only,best,(left.relative_mu,right.relative_mu),iteration-1)
        denominator=current.gradient-previous.gradient
        proposed=current.relative_mu-current.gradient*(current.relative_mu-previous.relative_mu)/denominator
        if !isfinite(proposed) || !(left.relative_mu+.01width<proposed<right.relative_mu-.01width)
            proposed=(left.relative_mu+right.relative_mu)/2
        end
        item=probe(proposed)
        item.valid || return finish(:occupation_region_lost,best,(left.relative_mu,right.relative_mu),iteration)
        if best===nothing || abs(item.gradient)+abs(item.density_residual)<abs(best.gradient)+abs(best.density_residual)
            best=item
        end
        good(item) && return finish(:converged,item,(left.relative_mu,right.relative_mu),iteration)
        if abs(item.gradient)<=gradient_atol && abs(item.density_residual)>density_atol
            return finish(:density_identity_not_resolved,item,(left.relative_mu,right.relative_mu),iteration)
        end
        if signbit(item.gradient)==signbit(left.gradient)
            left=item
        else
            right=item
        end
        previous,current=current,item
    end
    finish(:max_iterations,best,(left.relative_mu,right.relative_mu),max_iterations)
end

end
