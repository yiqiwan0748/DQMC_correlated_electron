module PRL101237004Fig2cReference

using LinearAlgebra, SHA, Serialization, Dates
include("prl_101_237004_vca_campaign.jl")
const V=PRL101237004VCACampaign
const C=V.C
const F=V.F
const G=V.G
const ROOT=V.ROOT
const OUTPUT=joinpath(ROOT,"results","prl_101_237004","fig2c")
const SOURCES=vcat(V.SCAN_SOURCES,["scripts/prl_101_237004_fig2c_reference.jl"])

# Cache only standard arrays/scalars/tuples. Custom Julia module paths differ
# when this module is included by a campaign, an audit, or an isolated test.
# Reconstruct the public immutable Green-function records in the local module.
_plain(x)=x
_plain(x::NamedTuple)=map(_plain,x)
_plain(x::Union{C.PoleExpansion,C.SpectralChannel,C.ClusterGreenResult})=
    NamedTuple{fieldnames(typeof(x))}(Tuple(_plain(getfield(x,n)) for n in fieldnames(typeof(x))))
_pole(x)=C.PoleExpansion(x.poles,x.weights)
_channel(x)=C.SpectralChannel((n==:spectrum ? _pole(x.spectrum) : getproperty(x,n)
    for n in fieldnames(C.SpectralChannel))...)
_restore(x)=C.ClusterGreenResult((n==:channels ? map(_channel,x.channels) :
    n in (:up,:down) ? _pole(getproperty(x,n)) : getproperty(x,n)
    for n in fieldnames(C.ClusterGreenResult))...)

"""Bare half-filled chemical potential on a stated physical momentum mesh.
It is an initial interacting-mu estimate only, not an imposed filling result.
"""
function bare_mu(ratio;physical_L=48)
    p=G.Model.slater_koster_parameters(ratio)
    bands=Float64[]
    for ix in 0:physical_L-1,iy in 0:physical_L-1
        append!(bands,G.Model.paper_band_energies(-pi+2pi*ix/physical_L,-pi+2pi*iy/physical_L,p))
    end
    sort!(bands)
    n=physical_L^2
    (bands[n]+bands[n+1])/2
end

function initial_mu(U,ratio)
    # The unpolarized half-filled Hartree shift is 3U/2−5J/2=7U/8.
    # Use the Fig.2(b) representative at r=−.2 for an exact anchor, without
    # retuning it to the published moment curve.
    .875U+(ratio==-.2 ? -.025 : bare_mu(ratio))
end

"""Canonical reference with probe energies that follow U and the band scale.
The diagnostic still covers a finite probe grid, not all chemical potentials.
Every final stationary result needs actual-mu and deeper-space checks.
"""
function reference_state(U::Real,ratio::Real,h::Real;channel=:stripe_y,
                         block_steps=48,seed=7,output=OUTPUT)
    isfinite(U) && U>0 || throw(ArgumentError("interacting Fig.2(c) reference requires U>0"))
    isfinite(h) && isfinite(ratio) || throw(ArgumentError("finite field and ratio required"))
    c=G.rectangular_cluster()
    p=G.Model.slater_koster_parameters(ratio)
    K=G.weiss_kinetics(c,h;channel,p)
    anchor=initial_mu(U,ratio)
    width=.1max(U,.5)
    probes=ComplexF64[complex(anchor+shift,w) for shift in (-width,0.,width)
        for w in (1e-5,.001,.01,.1,1.,10.)]
    hashes=Dict(source=>V.filehash(joinpath(ROOT,source)) for source in SOURCES)
    metadata=(;cache_format=2,U=Float64(U),J=Float64(U/4),ratio=Float64(ratio),h=Float64(h),channel,
        Nup=4,Ndown=4,Kup=K.up,Kdown=K.down,block_steps,seed,probe_z=probes,
        source_hashes=Tuple(s=>hashes[s] for s in sort(SOURCES)))
    identity=bytes2hex(sha256(repr(metadata)))
    directory=joinpath(output,"reference_cache")
    cache=joinpath(directory,identity*".jls")
    if isfile(cache)
        saved=open(deserialize,cache)
        saved.metadata==metadata || error("reference cache identity mismatch")
        result=_restore(saved.result); seconds=saved.seconds
    else
        mkpath(directory)
        signature=bytes2hex(sha256(join([s*hashes[s] for s in sort(SOURCES)],"\n")))[1:16]
        snapshot=joinpath(output,"reference_sources",signature)
        for source in SOURCES
            target=joinpath(snapshot,source)
            mkpath(dirname(target))
            if isfile(target)
                V.filehash(target)==hashes[source] || error("reference source changed; use a fresh output root")
            else
                cp(joinpath(ROOT,source),target)
            end
        end
        seconds=@elapsed result=C.build_cluster_green(K.up,K.down,U,4,4;J=U/4,
            block_steps,probe_z=probes,seed,require_convergence=false)
        open(cache*".partial","w") do io
            serialize(io,(;metadata,result=_plain(result),seconds,julia=string(VERSION)))
        end
        mv(cache*".partial",cache)
        open(replace(cache,".jls"=>".txt"),"w") do io
            println(io,"Created: ",now(),"; Julia ",VERSION)
            println(io,"Metadata: ",metadata)
            println(io,"E0: ",result.E0,"; residual: ",result.ground_residual,"; mu interval: ",result.mu_interval)
            println(io,"Probe convergence: ",result.converged,"; half-depth max error: ",maximum(ch.convergence_error for ch in result.channels))
            println(io,"Elapsed seconds: ",seconds,"; checkpoint SHA256: ",V.filehash(cache))
        end
    end
    function green(z,spin)
        label=spin==1 ? :up : :down
        C.cluster_green(result,z;spin=label),C.green_mu_derivative(result,z;spin=label)
    end
    reference=F.ReferenceSystem(result.E0,8,K.up,K.down,green;mu_interval=result.mu_interval)
    (;result,reference,cluster=c,parameters=p,cache,metadata,seconds)
end

end
