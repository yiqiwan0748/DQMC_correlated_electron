module PRL101237004Fig2CResolvedFilling

# The frozen solvers remain untouched. This extension carries their bounded
# search logic with an explicitly selectable low-frequency integration grid.
# It resolves near-Fermi poles that the original first interval can miss.
const FREQUENCY_BREAKS=(0.,1e-11,1e-9,1e-7,1e-5,.001,.01,.1,1.,10.,100.)
module BaseSolver
include("prl_101_237004_fig2c_filling.jl")
const Original=PRL101237004Fig2CFilling
const R=Original.R
const F=R.F
const occupation_region=Original.occupation_region
const occupation_inertia=Original.occupation_inertia
include("prl_101_237004_fig2c_fermi_shell.jl")
const Shell=PRL101237004Fig2CFermiShell

"""Evaluate one fixed relative chemical potential, including a canonical shell
ensemble when the finite-mesh integer count jumps past the target. This is
also the correct entry point for order/depth convergence checks of shell data;
calling the ordinary functional at the shell would impose half occupation.
"""
function evaluate_relative(state,lat,relative;mu_prime_initial=nothing,order=48,
        quadrature_breaks=(0.,1e-11,1e-9,1e-7,1e-5,.001,.01,.1,1.,10.,100.),
        quadrature=nothing,edge_fraction=.03,occupation_x_atol=1e-9,
        occupation_max_iterations=36,shell_x_atol=1e-12,shell_max_iterations=48,
        shell_identity_atol=1e-8,shell_continuity_atol=1e-8)
    ref=hasproperty(state,:reference) ? state.reference : state
    target=ref.particles/ref.nsites
    target==2 || throw(ArgumentError("half-filled reference required"))
    q=quadrature===nothing ? F.imaginary_quadrature(order;breaks=quadrature_breaks) : quadrature
    region=occupation_region(ref,lat,relative;mu_prime_initial,edge_fraction,
        x_atol=occupation_x_atol,max_iterations=occupation_max_iterations)
    calls=0
    if region.converged
        point=region.choice
        x=F.evaluate_functional(ref,lat,point.mu,point.mu_prime;quadrature=q)
        calls=1
        identity=x.mu_prime_gradient-(x.density-target)-point.offset
        if abs(identity)>shell_identity_atol
            return (;valid=false,relative_mu=relative,status=:interval_quadrature_identity_unresolved,
                occupation_region=region,functional_evaluations=calls,identity_error=identity)
        end
        data=merge(x,(;canonical_energy=x.omega+target*x.mu,occupation_policy=:integer_interval))
    else
        region.status in (:unresolved_occupation_interval,:target_count_skipped) ||
            return (;valid=false,relative_mu=relative,status=region.status,
                occupation_region=region,functional_evaluations=0)
        resolved=Shell.resolve_fermi_shell(
            mup->occupation_inertia(ref,lat,relative,mup),
            mup->F.evaluate_functional(ref,lat,mup-relative,mup;quadrature=q),
            ref.mu_interval,relative;initial_region=region,target,
            shell_x_atol,max_iterations=shell_max_iterations,
            identity_atol=shell_identity_atol,continuity_atol=shell_continuity_atol,
            integration_scale=1/(pi*ref.nsites))
        region=resolved.occupation_region
        calls=resolved.functional_evaluations
        resolved.converged || return (;valid=false,relative_mu=relative,status=resolved.status,
            occupation_region=region,functional_evaluations=calls)
        data=resolved.data;point=resolved.inertia
    end
    (;valid=true,relative_mu=relative,mu=data.mu,mu_prime=data.mu_prime,data,
        gradient=data.mu_prime_gradient,density_residual=data.density-target,
        inertia=point,occupation_region=region,functional_evaluations=calls,
        status=data.occupation_policy==:canonical_shell_ensemble ? :evaluated_shell_ensemble : :evaluated)
end
function solve_filling(state,lat;mu_initial,mu_prime_initial=nothing,order=24,
                       gradient_atol=1e-7,density_atol=1e-7,relative_step=nothing,
                       relative_x_atol=1e-10,max_iterations=32,max_bracket_expansions=8,
                       edge_fraction=.03,occupation_x_atol=1e-9,
                       occupation_max_iterations=36,
                       shell_x_atol=1e-12,shell_max_iterations=48,
                       shell_identity_atol=1e-8,shell_continuity_atol=1e-8,
                       quadrature_breaks=(0.,1e-11,1e-9,1e-7,1e-5,.001,.01,.1,1.,10.,100.))
    ref=hasproperty(state,:reference) ? state.reference : state
    target=ref.particles/ref.nsites
    target==2 || throw(ArgumentError("half-filled reference must contain two electrons per Fe"))
    all(isfinite,(mu_initial,gradient_atol,density_atol,relative_x_atol)) &&
        gradient_atol>0 && density_atol>0 && relative_x_atol>0 || throw(ArgumentError("invalid filling tolerances"))
    max_iterations>=0 && max_bracket_expansions>=0 || throw(ArgumentError("iteration limits must be nonnegative"))
    lo,hi=ref.mu_interval
    all(isfinite,(lo,hi)) && lo<hi || throw(ArgumentError("finite reference charge interval required"))
    anchor=mu_prime_initial===nothing ? clamp(Float64(mu_initial),lo+.1(hi-lo),hi-.1(hi-lo)) : Float64(mu_prime_initial)
    isfinite(anchor) || throw(ArgumentError("finite reference-mu initial value required"))
    relative_initial=anchor-mu_initial
    step=relative_step===nothing ? max(.005,.05(hi-lo)) : Float64(relative_step)
    isfinite(step) && step>0 || throw(ArgumentError("relative step must be positive"))
    quadrature=F.imaginary_quadrature(order;breaks=quadrature_breaks)
    cache=Dict{Float64,Any}()
    history=NamedTuple[]
    function probe(relative)
        haskey(cache,relative) && return cache[relative]
        valid_previous=filter(x->x.valid,history)
        local_anchor=isempty(valid_previous) ? anchor :
            valid_previous[argmin(abs(x.relative_mu-relative) for x in valid_previous)].mu_prime
        item=evaluate_relative(ref,lat,relative;mu_prime_initial=local_anchor,order,
            quadrature_breaks,quadrature,edge_fraction,occupation_x_atol,
            occupation_max_iterations,shell_x_atol,shell_max_iterations,
            shell_identity_atol,shell_continuity_atol)
        cache[relative]=item
        push!(history,item)
        item
    end
    good(item)=item.valid && abs(item.gradient)<=gradient_atol && abs(item.density_residual)<=density_atol
    function finish(status,choice,bracket,iterations)
        reference_probe_converged=hasproperty(state,:result) ? state.result.converged : nothing
        (;converged=status==:converged,status,choice,relative_bracket=bracket,iterations,
          functional_evaluations=sum(x.functional_evaluations for x in history),
          occupation_evaluations=sum(x.occupation_region.evaluations for x in history),
          mu_initial=Float64(mu_initial),mu_prime_initial=anchor,relative_initial,
          gradient_atol,density_atol,order,quadrature_breaks,reference_probe_converged,history)
    end
    function bracket()
        valid=sort(filter(x->x.valid,history);by=x->x.relative_mu)
        pairs=[(valid[j],valid[j+1]) for j in 1:length(valid)-1
            if signbit(valid[j].gradient)!=signbit(valid[j+1].gradient)]
        isempty(pairs) && return nothing
        pairs[argmin(abs((a.relative_mu+b.relative_mu)/2-relative_initial) for (a,b) in pairs)]
    end
    initial=probe(Float64(relative_initial))
    good(initial) && return finish(:converged,initial,(relative_initial,relative_initial),0)
    bounds=nothing
    for expansion in 0:max_bracket_expansions
        for relative in (relative_initial-step*2.0^expansion,relative_initial+step*2.0^expansion)
            item=probe(relative)
            good(item) && return finish(:converged,item,(relative,relative),0)
        end
        bounds=bracket()
        bounds===nothing || break
    end
    valid=filter(x->x.valid,history)
    best=isempty(valid) ? nothing : valid[argmin(abs(x.gradient)+abs(x.density_residual) for x in valid)]
    bounds===nothing && return finish(:no_relative_bracket,best,(NaN,NaN),0)
    left,right=bounds
    previous,current=left,right
    for iteration in 1:max_iterations
        width=right.relative_mu-left.relative_mu
        if width<=relative_x_atol
            cusp=Shell.resolve_relative_cusp(left,right;relative_x_atol,gradient_atol,
                density_atol,continuity_atol=shell_continuity_atol,integration_scale=1/(pi*ref.nsites),target)
            if cusp.converged
                push!(history,cusp.choice)
                return finish(:converged,cusp.choice,(left.relative_mu,right.relative_mu),iteration-1)
            end
            return finish(:relative_tolerance_only,best,(left.relative_mu,right.relative_mu),iteration-1)
        end
        denominator=current.gradient-previous.gradient
        proposed=current.relative_mu-current.gradient*(current.relative_mu-previous.relative_mu)/denominator
        if !isfinite(proposed) || !(left.relative_mu+.01width<proposed<right.relative_mu-.01width)
            proposed=(left.relative_mu+right.relative_mu)/2
        end
        item=probe(proposed)
        item.valid || return finish(:occupation_region_lost,best,(left.relative_mu,right.relative_mu),iteration)
        if best===nothing || abs(item.gradient)+abs(item.density_residual)<abs(best.gradient)+abs(best.density_residual)
            best=item
        end
        good(item) && return finish(:converged,item,(left.relative_mu,right.relative_mu),iteration)
        if abs(item.gradient)<=gradient_atol && abs(item.density_residual)>density_atol
            return finish(:density_identity_not_resolved,item,(left.relative_mu,right.relative_mu),iteration)
        end
        if signbit(item.gradient)==signbit(left.gradient)
            left=item
        else
            right=item
        end
        previous,current=current,item
    end
    finish(:max_iterations,best,(left.relative_mu,right.relative_mu),max_iterations)
end

end
const BaseFilling=BaseSolver
const R=BaseFilling.R
const F=R.F
const evaluate_relative=BaseSolver.evaluate_relative
export solve_filling, refine_validity_boundary, evaluate_relative

function _check_sample(sample,relative)
    sample isa NamedTuple && hasproperty(sample,:valid) &&
        hasproperty(sample,:relative_mu) || throw(ArgumentError("sample requires valid and relative_mu"))
    sample.valid isa Bool && sample.relative_mu==relative && isfinite(relative) ||
        throw(ArgumentError("invalid sample position or validity flag"))
    if sample.valid
        hasproperty(sample,:gradient) && sample.gradient isa Real && isfinite(sample.gradient) ||
            throw(ArgumentError("valid samples require a finite gradient"))
    end
    sample
end

"""Bisect a valid/invalid parameter interval without accepting invalid roots.

A finite mesh can exclude one sampled parameter because its degenerate pole
count skips the target occupation, while nearby parameters remain valid.
Exponential bracketing can consequently jump over a valid gradient root.
This helper returns a bracket only when two valid samples have opposite
gradient signs, or a residual candidate only when a valid sample meets the
gradient threshold. Shrinking onto a domain boundary is not convergence.
It does not certify the separate density residual; solve_filling does that.
"""
function refine_validity_boundary(evaluate,valid_sample,invalid_sample;
                                  gradient_atol=1e-7,x_atol=1e-10,max_iterations=32)
    _check_sample(valid_sample,valid_sample.relative_mu)
    _check_sample(invalid_sample,invalid_sample.relative_mu)
    valid_sample.valid && !invalid_sample.valid || throw(ArgumentError("one valid and one invalid endpoint required"))
    valid_sample.relative_mu!=invalid_sample.relative_mu || throw(ArgumentError("distinct endpoints required"))
    all(isfinite,(gradient_atol,x_atol)) && gradient_atol>0 && x_atol>0 &&
        max_iterations>=0 || throw(ArgumentError("invalid boundary-search controls"))
    good,bad=valid_sample,invalid_sample
    log=NamedTuple[]
    if abs(good.gradient)<=gradient_atol
        return (;status=:residual_candidate,bracket=nothing,candidate=good,valid_endpoint=good,
            invalid_endpoint=bad,iterations=0,evaluations=0,log)
    end
    status=:iteration_limit
    completed=0
    for iteration in 1:max_iterations
        if abs(good.relative_mu-bad.relative_mu)<=x_atol
            status=:domain_boundary_without_root
            break
        end
        relative=(good.relative_mu+bad.relative_mu)/2
        item=_check_sample(evaluate(relative),relative)
        push!(log,item)
        completed=iteration
        if item.valid
            if abs(item.gradient)<=gradient_atol
                return (;status=:residual_candidate,bracket=nothing,candidate=item,
                    valid_endpoint=good,invalid_endpoint=bad,iterations=completed,evaluations=length(log),log)
            elseif signbit(item.gradient)!=signbit(good.gradient)
                bracket=good.relative_mu<item.relative_mu ? (good,item) : (item,good)
                return (;status=:sign_bracket,bracket,candidate=nothing,valid_endpoint=item,
                    invalid_endpoint=bad,iterations=completed,evaluations=length(log),log)
            end
            good=item
        else
            bad=item
        end
    end
    (;status,bracket=nothing,candidate=nothing,valid_endpoint=good,invalid_endpoint=bad,
      iterations=completed,evaluations=length(log),log)
end

function _boundary_pairs(history)
    samples=sort(collect(values(Dict(x.relative_mu=>x for x in history)));by=x->x.relative_mu)
    pairs=Tuple[]
    for j in 1:length(samples)-1
        a,b=samples[j],samples[j+1]
        a.valid==b.valid && continue
        good,bad=a.valid ? (a,b) : (b,a)
        push!(pairs,(good,bad))
    end
    sort!(pairs;by=pair->(abs(pair[1].gradient),abs(pair[1].relative_mu-pair[2].relative_mu)))
end

"""Wrap the frozen Fig2c filling solver with bounded domain-aware retries.

All original keywords pass through unchanged. If the original relative-mu
bracketing fails, inspect adjacent valid/invalid samples and bisect at most
adaptive_max_boundaries such intervals. Only a valid sign bracket or valid
small-gradient sample seeds a retry. The original solver independently
certifies both filling and stationarity on every accepted retry.

Returned fields preserve choice.data, converged and status; attempts and
adaptive_boundaries retain every small scalar diagnostic. There are no
canonical vectors, reference-system objects or lattice matrices in the result.
"""
function solve_filling(state,lat;adaptive_max_iterations=32,adaptive_max_boundaries=4,kwargs...)
    adaptive_max_iterations>=0 && adaptive_max_boundaries>=0 ||
        throw(ArgumentError("adaptive budgets must be nonnegative"))
    arguments=merge((;order=48,quadrature_breaks=FREQUENCY_BREAKS),(;kwargs...))
    original=BaseFilling.solve_filling(state,lat;arguments...)
    attempts=Any[original]
    boundaries=Any[]
    function finished(result)
        boundary_functionals=sum(sum(x.functional_evaluations for x in b.log;init=0) for b in boundaries;init=0)
        boundary_occupations=sum(sum(x.occupation_region.evaluations for x in b.log;init=0) for b in boundaries;init=0)
        merge(result,(;attempts,adaptive_boundaries=boundaries,retry_count=length(attempts)-1,
            functional_evaluations=sum(x.functional_evaluations for x in attempts)+boundary_functionals,
            occupation_evaluations=sum(x.occupation_evaluations for x in attempts)+boundary_occupations,
            adaptive_max_iterations,adaptive_max_boundaries))
    end
    original.converged && return finished(original)
    original.status in (:no_relative_bracket,:occupation_region_lost) || return finished(original)
    pairs=_boundary_pairs(original.history)
    isempty(pairs) && return finished(original)
    ref=hasproperty(state,:reference) ? state.reference : state
    gradient_atol=get(arguments,:gradient_atol,1e-7)
    order=get(arguments,:order,24)
    quadrature=F.imaginary_quadrature(order;breaks=get(arguments,:quadrature_breaks,FREQUENCY_BREAKS))
    edge_fraction=get(arguments,:edge_fraction,.03)
    occupation_x_atol=get(arguments,:occupation_x_atol,1e-9)
    occupation_max_iterations=get(arguments,:occupation_max_iterations,36)
    for (good,bad) in Iterators.take(pairs,adaptive_max_boundaries)
        function evaluate(relative)
            evaluate_relative(ref,lat,relative;mu_prime_initial=good.mu_prime,
                order,quadrature,quadrature_breaks=get(arguments,:quadrature_breaks,FREQUENCY_BREAKS),
                edge_fraction,occupation_x_atol,occupation_max_iterations,
                shell_x_atol=get(arguments,:shell_x_atol,1e-12),
                shell_max_iterations=get(arguments,:shell_max_iterations,48),
                shell_identity_atol=get(arguments,:shell_identity_atol,1e-8),
                shell_continuity_atol=get(arguments,:shell_continuity_atol,1e-8))
        end
        boundary=refine_validity_boundary(evaluate,good,bad;gradient_atol,
            x_atol=get(arguments,:relative_x_atol,1e-10),max_iterations=adaptive_max_iterations)
        push!(boundaries,boundary)
        if boundary.bracket!==nothing
            a,b=boundary.bracket
            relative=(a.relative_mu+b.relative_mu)/2
            mup=(a.mu_prime+b.mu_prime)/2
            step=(b.relative_mu-a.relative_mu)/2
            retry_arguments=merge(arguments,(;mu_initial=mup-relative,mu_prime_initial=mup,
                relative_step=step,max_bracket_expansions=0))
        elseif boundary.candidate!==nothing
            point=boundary.candidate
            retry_arguments=merge(arguments,(;mu_initial=point.mu,mu_prime_initial=point.mu_prime,
                relative_step=max(1e-4,.1abs(good.relative_mu-bad.relative_mu)),max_bracket_expansions=0))
        else
            continue
        end
        retry=BaseFilling.solve_filling(state,lat;retry_arguments...)
        push!(attempts,retry)
        retry.converged && return finished(retry)
    end
    candidates=filter(x->x.choice!==nothing,attempts)
    best=isempty(candidates) ? original : candidates[argmin(abs(x.choice.gradient)+abs(x.choice.density_residual) for x in candidates)]
    finished(merge(best,(;converged=false,status=:adaptive_bracket_not_resolved)))
end

end
