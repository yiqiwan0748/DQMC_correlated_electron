module PRL101237004Fig3Campaign

using LinearAlgebra, SHA, Serialization, Dates, TOML
include("prl_101_237004_fig2c_reference.jl")
include("prl_101_237004_spectra.jl")
const R=PRL101237004Fig2cReference
const S=PRL101237004Spectra
const ROOT=normpath(joinpath(@__DIR__,".."))
const INPUT=joinpath(ROOT,"results","prl_101_237004","fig2c")
const OUTPUT=joinpath(ROOT,"results","prl_101_237004","fig3")
const CASES=((name="blue_U0",ratio=-.2,U=0.),(name="blue_U0p5",ratio=-.2,U=.5),
    (name="blue_U1",ratio=-.2,U=1.),(name="blue_U2",ratio=-.2,U=2.),
    (name="red_U1",ratio=-.5,U=1.))
const SOURCES=unique(vcat(R.SOURCES,["scripts/prl_101_237004_spectra.jl",
    "scripts/prl_101_237004_fig3_campaign.jl"]))

filehash(path)=bytes2hex(open(sha256,path))
function scalar_csv(path)
    lines=readlines(path)
    length(lines)>=2 || error("empty scalar CSV: $path")
    names=split(first(lines),',')
    length(unique(names))==length(names) || error("duplicate CSV columns: $path")
    rows=Dict{String,String}[]
    for line in lines[2:end]
        isempty(strip(line)) && continue
        values=split(line,',')
        length(values)==length(names) || error("non-scalar or malformed CSV: $path")
        push!(rows,Dict(String.(names).=>String.(values)))
    end
    rows
end
number(row,name)=parse(Float64,row[name])
function verify_recorded_file(path,manifest;root=dirname(manifest))
    key=relpath(path,root)
    found=filter(line->length(line)>66 && line[67:end]==key,readlines(manifest))
    length(found)==1 || error("expected one checksum for $key")
    filehash(path)==only(found)[1:64] || error("input checksum changed: $path")
    nothing
end
function copy_identical(source,target)
    mkpath(dirname(target))
    if isfile(target)
        filehash(source)==filehash(target) || error("existing copied input differs: $target")
    else
        cp(source,target)
    end
    target
end
function snapshot(output,sources=SOURCES)
    hashes=Dict(s=>filehash(joinpath(ROOT,s)) for s in sources)
    for s in sources
        copy_identical(joinpath(ROOT,s),joinpath(output,"source_snapshot",s))
    end
    hashes
end
function guard(hashes)
    for (source,hash) in hashes
        filehash(joinpath(ROOT,source))==hash || error("source changed during calculation: $source")
    end
end
function write_toml(path,data)
    mkpath(dirname(path))
    open(path*".partial","w") do io
        TOML.print(io,data;sorted=true)
    end
    mv(path*".partial",path;force=true)
end

"""Load exactly a saved Fig2c center into a new output root. The prior
milestone is read-only. Its checksummed local cache is copied before loading;
metadata, numerical source versions, and every selected parameter are checked.
The U=0 curve instead uses the analytic Bloch limit at half filling on L48.
"""
function load_case(case;input=INPUT,output=OUTPUT)
    c=R.G.rectangular_cluster()
    p=R.G.Model.slater_koster_parameters(case.ratio)
    if iszero(case.U)
        mu=R.bare_mu(case.ratio;physical_L=48)
        K=R.G.open_kinetic(c,p)
        # The open free cluster has a degenerate half-filled shell. Its
        # retarded one-body resolvent is occupation independent, so imposing
        # a nondegenerate canonical charge interval would be inappropriate.
        # No interacting-reference acceptance rule is relaxed here.
        function green(z,spin)
            matrix=inv(z*I-K)
            matrix,-matrix*matrix
        end
        ref=(;nsites=length(c.sites),kinetics=(K,K),green)
        mup=mu # arbitrary free reference shift; embedding cancels it exactly
        problem=S.SpectralProblem(ref,c,p;mu,mu_prime=mup)
        meta=Dict("case"=>case.name,"U"=>0.,"J"=>0.,"ratio"=>case.ratio,
            "h"=>0.,"mu"=>mu,"mu_prime"=>mup,"physical_L"=>48,
            "reference_kind"=>"analytic_noninteracting",
            "chemical_potential_policy"=>"midpoint of half-filled L48 bare levels; not a fitted value")
        return (;problem,state=nothing,row=nothing,meta,case)
    end
    curve=case.ratio==-.2 ? "r_minus_0p2" : case.ratio==-.5 ? "r_minus_0p5" : error("unknown ratio")
    scan=joinpath(input,"scans",curve*".csv")
    verify_recorded_file(scan,joinpath(input,"checksums.sha256"))
    rows=scalar_csv(scan)
    length(rows)==5 || error("requires a complete five-point scan")
    chosen=filter(row->number(row,"U")==case.U && number(row,"ratio")==case.ratio,rows)
    length(chosen)==1 || error("missing or repeated production point")
    row=only(chosen)
    number(row,"J")==case.U/4 || error("wrong Hund coupling")
    abs(number(row,"density")-2)<=1e-7 || error("production filling fails")
    abs(number(row,"mu_prime_gradient"))<=1e-7 || error("reference stationarity fails")
    abs(number(row,"h_derivative"))<=2.1e-6 || error("production field threshold fails")
    row["stationarity_status"]=="magnetic_minimum" || error("expected selected stripe minimum")
    number(row,"physical_L")==48 && number(row,"block_steps")==48 || error("undeclared production discretization")
    h,mu,mup=number(row,"h"),number(row,"mu"),number(row,"mu_prime")
    point=joinpath(input,"runs",curve,"U"*string(case.U))
    records=(scan,joinpath(point,"result.csv"),joinpath(point,"completed.txt"),joinpath(point,"provenance.txt"))
    input_hashes=Dict{String,String}()
    for source in records
        verify_recorded_file(source,joinpath(input,"checksums.sha256"))
        target=joinpath(output,"inputs","fig2c",relpath(source,input))
        copy_identical(source,target)
        input_hashes[relpath(source,input)]=filehash(source)
    end
    selected=only(scalar_csv(joinpath(point,"result.csv")))
    all(selected[key]==row[key] for key in keys(row)) || error("selected point and final scan differ")
    cache=joinpath(input,row["reference_cache"])
    startswith(abspath(cache),abspath(input)*"/") || error("reference path escapes saved milestone")
    verify_recorded_file(cache,joinpath(input,"checkpoints.sha256"))
    target=copy_identical(cache,joinpath(output,row["reference_cache"]))
    saved=open(deserialize,target)
    saved.metadata.cache_format==2 || error("unsupported portable reference format")
    for (source,expected) in saved.metadata.source_hashes
        filehash(joinpath(ROOT,source))==expected || error("reference numerical source version changed: $source")
    end
    state=R.reference_state(case.U,case.ratio,h;block_steps=48,output)
    state.cache==target || error("saved reference identity does not match requested center")
    state.metadata.channel==:stripe_y || error("wrong stripe orientation")
    state.result.mu_interval[1]<mup<state.result.mu_interval[2] || error("reference potential outside charge interval")
    problem=S.SpectralProblem(state.reference,state.cluster,state.parameters;mu,mu_prime=mup)
    input_hashes[row["reference_cache"]]=filehash(cache)
    meta=Dict("case"=>case.name,"U"=>case.U,"J"=>case.U/4,"ratio"=>case.ratio,
        "h"=>h,"mu"=>mu,"mu_prime"=>mup,"physical_L"=>48,"block_steps"=>48,
        "density"=>number(row,"density"),"moment_abs"=>number(row,"moment_abs_muB_per_Fe"),
        "reference_kind"=>"saved_stationary_Fig2c_canonical_reference",
        "reference_cache"=>row["reference_cache"],"input_sha256"=>input_hashes,
        "limits"=>"Retains Fig2c production field and its documented field-step/mesh sensitivity; no spectral fit or new variational optimization.")
    (;problem,state,row,meta,case)
end

"""Paper path from bottom to top; equal parameter length for each segment.
Repeated end points are stored once. This is a plotting coordinate, not arc length.
"""
function paper_path(intervals=16)
    intervals>0 || throw(ArgumentError("positive path subdivision required"))
    vertices=((0.,pi),(pi,pi),(0.,0.),(0.,pi),(pi,0.))
    points=Tuple{Float64,Float64}[]; coordinate=Float64[]
    for segment in 1:4, j in 0:intervals-1
        a,b=vertices[segment],vertices[segment+1]
        t=j/intervals
        push!(points,((1-t)*a[1]+t*b[1],(1-t)*a[2]+t*b[2]))
        push!(coordinate,segment-1+t)
    end
    push!(points,last(vertices));push!(coordinate,4.)
    (;points,coordinate,vertices)
end

end
