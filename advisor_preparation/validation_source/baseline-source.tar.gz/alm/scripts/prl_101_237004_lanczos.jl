module PRL101237004Lanczos

using LinearAlgebra
using Random

export lowest_lanczos

"""
    lowest_lanczos(H; seed=7, maxiter=min(size(H,1),300), atol=1e-11,
                   rtol=1e-12, max_bytes=512*1024^2, require_convergence=true)

Small-sector real symmetric Lanczos with two-pass full reorthogonalization.
`H` must implement symmetric multiplication. The final residual is computed
by applying the original operator, not inferred solely from Ritz values.

The storage check covers solver arrays, in addition to the already allocated
operator. This proof backend stores all Krylov vectors; it is not a production
eight-site solver. A single starting vector does not resolve a degenerate
ground manifold or certify that it overlaps the global ground state. Validate
energies against independent starts and dense spectra in small sectors.
"""
function lowest_lanczos(H; seed::Integer=7,
    maxiter::Integer=min(size(H, 1), 300), atol::Real=1e-11, rtol::Real=1e-12,
    max_bytes::Integer=512 * 1024^2, require_convergence::Bool=true)
    n = size(H, 1)
    size(H) == (n, n) && n > 0 || throw(ArgumentError("H must be nonempty and square"))
    T = eltype(H)
    T in (Float32, Float64) || throw(ArgumentError("the Lanczos eigensolver supports Float32 and Float64"))
    maxiter > 0 || throw(ArgumentError("maxiter must be positive"))
    isfinite(atol) && atol >= 0 || throw(ArgumentError("atol must be finite and nonnegative"))
    isfinite(rtol) && rtol >= 0 || throw(ArgumentError("rtol must be finite and nonnegative"))
    max_bytes > 0 || throw(ArgumentError("max_bytes must be positive"))
    limit = Int(min(big(n), big(maxiter)))
    # Krylov matrix, seven vector workspaces, and conservative small Ritz work.
    bytes = sizeof(T) * (big(n) * (limit + 7) + 4big(limit)^2)
    bytes <= max_bytes || throw(ArgumentError("Lanczos workspace estimate $bytes bytes exceeds max_bytes=$max_bytes"))
    q = randn(MersenneTwister(seed), T, n)
    q ./= norm(q)
    Q = Matrix{T}(undef, n, limit)
    previous, work = zeros(T, n), zeros(T, n)
    alpha, beta = zeros(T, limit), zeros(T, max(0, limit - 1))
    result = nothing
    for iteration in 1:limit
        Q[:, iteration] .= q
        mul!(work, H, q)
        alpha[iteration] = dot(q, work)
        work .-= alpha[iteration] .* q
        iteration > 1 && (work .-= beta[iteration - 1] .* previous)
        active = view(Q, :, 1:iteration)
        for _ in 1:2
            coefficients = transpose(active) * work
            work .-= active * coefficients
        end
        next_norm = norm(work)
        ritz = eigen(SymTridiagonal(alpha[1:iteration], beta[1:iteration-1]), 1:1)
        threshold = T(atol) + T(rtol) * abs(ritz.values[1])
        estimated_residual = next_norm * abs(ritz.vectors[end, 1])
        breakdown = next_norm <= eps(T) * max(one(T), abs(alpha[iteration]))
        if estimated_residual <= threshold || breakdown || iteration == limit
            vector = active * view(ritz.vectors, :, 1)
            vector ./= norm(vector)
            applied = H * vector
            energy = dot(vector, applied)
            residual = norm(applied - energy * vector)
            final_threshold = T(atol) + T(rtol) * abs(energy)
            converged = residual <= final_threshold
            result = (energy=energy, vector=vector, residual=residual,
                iterations=iteration, converged=converged, seed=seed,
                threshold=final_threshold, workspace_bytes=bytes,
                ground_manifold_resolved=false)
            (converged || breakdown || iteration == limit) && break
        end
        beta[iteration] = next_norm
        previous .= q
        q .= work ./ next_norm
    end
    if require_convergence && !result.converged
        error("Lanczos did not converge: residual=$(result.residual), threshold=$(result.threshold), iterations=$(result.iterations)")
    end
    return result
end

end
