module PRL101237004Model

# Reuse the validated band algebra without changing this repository's model
# defaults. The paper's orbital gauge is handled by repository_parameters.
module ValidatedBloch
include(joinpath(@__DIR__, "..", "src", "noninteracting.jl"))
end

export PaperHoppingParameters,
       slater_koster_parameters,
       raghu_parameters,
       repository_parameters,
       paper_bloch_hamiltonian,
       paper_band_energies

"""
    PaperHoppingParameters(t1, t2, t3, t4)

Hoppings in the literal convention of Eq. (1), PRL **101**, 237004 (2008).
The basis is `(d_xz, d_yz)`. A positive `(1,1)` interorbital bond carries
`-t4`, and a positive `(1,-1)` bond carries `+t4`; consequently the Bloch
off-diagonal entry is `+4t4*sin(kx)*sin(ky)`.

These fields are paper-convention values, not the repository's `ModelParameters`.
Use `repository_parameters` when calling the reused repository routines.
"""
struct PaperHoppingParameters{T<:Real}
    t1::T
    t2::T
    t3::T
    t4::T

    function PaperHoppingParameters(t1::T, t2::T, t3::T, t4::T) where {T<:Real}
        all(isfinite, (t1, t2, t3, t4)) ||
            throw(ArgumentError("paper hopping parameters must be finite"))
        return new{T}(t1, t2, t3, t4)
    end
end

function PaperHoppingParameters(t1::Real, t2::Real, t3::Real, t4::Real)
    return PaperHoppingParameters(promote(t1, t2, t3, t4)...)
end

function _checked_energy_scale(energy_scale::Real)
    isfinite(energy_scale) && energy_scale > 0 ||
        throw(ArgumentError("energy_scale must be finite and positive"))
    return energy_scale
end

"""
    slater_koster_parameters(ratio=-0.2; energy_scale=1)

Return the paper's Slater-Koster hoppings, with `ratio = (pdπ)/(pdσ)` and
`energy_scale = (pdσ)^2/Δpd` in the chosen energy unit. Eq. (1)'s coefficients
are obtained from

```
a = 0.324 - 0.374ratio
b = 0.324 + 0.123ratio
g = 0.263 + 0.310ratio
t1 = -2(b² - a² + g²) * energy_scale
t2 = -2(b² - a² - g²) * energy_scale
t3 = -(a² + b² - g²) * energy_scale
t4 = -(ab - g²) * energy_scale.
```

The decimal coefficients are represented as exact rational constants before
conversion to the input arithmetic type. In particular, Float32 and BigFloat
inputs do not first round these constants through Float64.
"""
function slater_koster_parameters(ratio::Real=-0.2; energy_scale::Real=1)
    isfinite(ratio) || throw(ArgumentError("ratio must be finite"))
    _checked_energy_scale(energy_scale)
    r, scale = float.(promote(ratio, energy_scale))
    T = typeof(r)
    a = T(324 // 1000) - T(374 // 1000) * r
    b = T(324 // 1000) + T(123 // 1000) * r
    g = T(263 // 1000) + T(310 // 1000) * r
    return PaperHoppingParameters(
        -2 * (b^2 - a^2 + g^2) * scale,
        -2 * (b^2 - a^2 - g^2) * scale,
        -(a^2 + b^2 - g^2) * scale,
        -(a * b - g^2) * scale,
    )
end

"""
    raghu_parameters(; energy_scale=1)

The Ref. [11] (Raghu et al.) band fit, expressed in the literal PRL Eq. (1)
convention: `(-1, 1.3, -0.85, +0.85) * energy_scale`.

The original Raghu convention uses `t4=-0.85` and the Bloch entry
`-4t4*sin(kx)*sin(ky)`. Thus the paper-convention `t4` returned here has the
opposite sign, preserving the original matrix, not merely its band energies.
The energy unit is the original fit's `|t1|`. This function does not impose
the commonly used chemical potential `μ=1.54*energy_scale`.
"""
function raghu_parameters(; energy_scale::Real=1)
    scale = float(_checked_energy_scale(energy_scale))
    T = typeof(scale)
    return PaperHoppingParameters(
        -scale,
        T(13 // 10) * scale,
        -T(85 // 100) * scale,
        T(85 // 100) * scale,
    )
end

"""
    repository_parameters(parameters::PaperHoppingParameters)

Map paper hoppings into the reused implementation by negating only `t4`.
The repository uses `-4t4*sin(kx)*sin(ky)`. This mapping preserves all entries
of the paper's Bloch matrix in the stated orbital basis.
"""
function repository_parameters(parameters::PaperHoppingParameters)
    return ValidatedBloch.ModelParameters(
        parameters.t1, parameters.t2, parameters.t3, -parameters.t4,
    )
end

function _checked_momenta(kx::Real, ky::Real)
    isfinite(kx) && isfinite(ky) ||
        throw(ArgumentError("momenta must be finite real numbers in radians"))
    return nothing
end

"""
    paper_bloch_hamiltonian(kx, ky, parameters=slater_koster_parameters())

Real symmetric, unshifted Bloch Hamiltonian for literal PRL Eq. (1). Momenta
are radians at unit lattice spacing. No interaction or chemical potential is
included.
"""
function paper_bloch_hamiltonian(
    kx::Real, ky::Real,
    parameters::PaperHoppingParameters=slater_koster_parameters(),
)
    _checked_momenta(kx, ky)
    return ValidatedBloch.bloch_hamiltonian(kx, ky, repository_parameters(parameters))
end

"""
    paper_band_energies(kx, ky, parameters=slater_koster_parameters())

Return the two unshifted bands in ascending order, in the same energy unit as
the paper hopping parameters.
"""
function paper_band_energies(
    kx::Real, ky::Real,
    parameters::PaperHoppingParameters=slater_koster_parameters(),
)
    _checked_momenta(kx, ky)
    return ValidatedBloch.band_energies(kx, ky, repository_parameters(parameters))
end

end
