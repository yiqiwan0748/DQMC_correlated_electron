module PRL101237004MomentumBasis

using LinearAlgebra

export MomentumBasis, build_momentum_basis, locate, locate_code,
       representative, expand_momentum_vector, phase_value

"""
Factorized fixed-spin momentum basis with projector
`P(k)=sum_g exp(+im*k⋅g)T(g)/Nsites`. Its normalized columns are
`sqrt(orbit_length)*P(k)|representative⟩`; translation eigenvalues are
`exp(-im*k⋅g)`. Each representative first minimizes the up-spin mask,
then minimizes the down-spin mask under the up representative's stabilizer.

`lookup[down_rank, up_orbit]` packs `(row << 2) | phase_code`, with zero
meaning an inadmissible orbit. The phase is the signed translation taking
that mask pair to its representative, including `exp(+im*k⋅g)`, encoded
as a power of `im`. Arrays indexed by a raw mask use `Int(mask)+1`.
`row_offsets` are one-based block starts, with a final `dimension+1` sentinel.
No full fixed-spin basis, dictionary, or Hamiltonian is constructed.
"""
struct MomentumBasis{Torus}
    nmodes::Int
    Nup::Int
    Ndown::Int
    torus::Torus
    kx::Float64
    ky::Float64
    up_masks::Vector{UInt16}
    down_masks::Vector{UInt16}
    up_reps::Vector{UInt16}
    row_offsets::Vector{Int}
    row_down_ranks::Vector{UInt16}
    orbit_lengths::Vector{UInt8}
    lookup::Matrix{UInt32}
    rank_up::Vector{Int32}
    rank_down::Vector{Int32}
    canonical_up_orbit::Vector{UInt16}
    canonical_up_translation::Vector{UInt8}
    translation_masks::Matrix{UInt16}
    translation_signs::Matrix{Int8}
    translation_phases::Vector{UInt8}
    estimated_bytes::Int
end

Base.length(basis::MomentumBasis) = length(basis.orbit_lengths)
phase_value(code::Integer) = (1.0 + 0.0im, 0.0 + 1.0im,
                              -1.0 + 0.0im, 0.0 - 1.0im)[Int(code & 3) + 1]

function _memory_guard(bytes::Integer, max_bytes::Integer)
    bytes <= max_bytes || throw(ArgumentError(
        "momentum-basis allocation estimate $bytes bytes exceeds max_bytes=$max_bytes"))
    return nothing
end

function _translation_phases(torus, kx, ky)
    all(isfinite, (kx, ky)) || throw(ArgumentError("momentum must be finite"))
    # This tolerance only recognizes exact finite-group characters represented
    # by Float64 trigonometric values. All subsequent phases use exact integers.
    for (x, y) in (torus.a1, torus.a2)
        isapprox(cis(kx * x + ky * y), 1; atol=2e-12, rtol=0) ||
            throw(ArgumentError("momentum is not allowed by this torus"))
    end
    result = UInt8[]
    for (x, y) in torus.cells
        phase = cis(kx * x + ky * y)
        code = mod(round(Int, 2angle(phase) / pi), 4)
        isapprox(phase, phase_value(code); atol=2e-12, rtol=0) ||
            throw(ArgumentError("packed momentum basis requires fourth-root translation phases"))
        push!(result, UInt8(code))
    end
    return result
end

function _translation_tables(torus, nmodes)
    group_size = torus.ncells
    masks = zeros(UInt16, 65536, group_size)
    signs = ones(Int8, 65536, group_size)
    for (g, (dx, dy)) in enumerate(torus.cells)
        destination_bits = zeros(UInt16, nmodes)
        for (site, (x0, y0)) in enumerate(torus.cells)
            x, y = x0 + dx, y0 + dy
            # Exact coset indexing, using the public torus data rather than a
            # module-specific TiltedTorus method (several old scripts nest it).
            signature = (mod(torus.a2[2] * x - torus.a2[1] * y, group_size),
                         mod(-torus.a1[2] * x + torus.a1[1] * y, group_size))
            target_site = torus.index_by_signature[signature]
            for orbital in 1:2
                destination_bits[2(site - 1) + orbital] =
                    UInt16(1) << (2(target_site - 1) + orbital - 1)
            end
        end
        for raw in 1:((1 << nmodes) - 1)
            mask = UInt16(raw)
            previous = mask & (mask - UInt16(1))
            bit = destination_bits[trailing_zeros(mask) + 1]
            mapped = masks[Int(previous) + 1, g]
            masks[raw + 1, g] = mapped | bit
            parity = isodd(count_ones(mapped & (bit - UInt16(1)))) ? Int8(-1) : Int8(1)
            signs[raw + 1, g] = parity * signs[Int(previous) + 1, g]
        end
    end
    return masks, signs
end

"""
    build_momentum_basis(torus, Nup, Ndown, kx, ky; max_bytes=768*1024^2)

Build a compact translation block for up to eight two-orbital sites. Momentum
characters must be fourth roots of unity, as for the PRL four/eight-site tori.
The byte guard covers basis arrays and construction workspace, before each
large allocation; it excludes later eigensolver/operator arrays.
"""
function build_momentum_basis(torus, Nup::Integer, Ndown::Integer,
                              kx::Real, ky::Real;
                              max_bytes::Integer=768 * 1024^2)
    1 <= torus.ncells <= 8 || throw(ArgumentError("basis supports one through eight sites"))
    nmodes = 2torus.ncells
    0 <= Nup <= nmodes || throw(ArgumentError("Nup is outside 0:nmodes"))
    0 <= Ndown <= nmodes || throw(ArgumentError("Ndown is outside 0:nmodes"))
    max_bytes > 0 || throw(ArgumentError("max_bytes must be positive"))
    group_size = torus.ncells
    phases = _translation_phases(torus, Float64(kx), Float64(ky))
    # Translation tables, two rank arrays, canonicalization arrays, temporary
    # canonical masks, and a generous allowance for small vectors and headers.
    base_bytes = 65536 * (3group_size + 8 + 3 + 2) + 2^20
    _memory_guard(base_bytes, max_bytes)
    masks, signs = _translation_tables(torus, nmodes)
    up_masks = UInt16[raw for raw in 0:((1 << nmodes) - 1) if count_ones(raw) == Nup]
    down_masks = UInt16[raw for raw in 0:((1 << nmodes) - 1) if count_ones(raw) == Ndown]
    rank_up, rank_down = zeros(Int32, 65536), zeros(Int32, 65536)
    for (rank, mask) in enumerate(up_masks)
        rank_up[Int(mask) + 1] = rank
    end
    for (rank, mask) in enumerate(down_masks)
        rank_down[Int(mask) + 1] = rank
    end
    canonical_masks = zeros(UInt16, 65536)
    canonical_up_translation = zeros(UInt8, 65536)
    up_reps = UInt16[]
    for up in up_masks
        slot = Int(up) + 1
        best, best_g = typemax(UInt16), 0
        for g in 1:group_size
            candidate = masks[slot, g]
            if best_g == 0 || candidate < best
                best, best_g = candidate, g
            end
        end
        canonical_masks[slot] = best
        canonical_up_translation[slot] = best_g
        up == best && push!(up_reps, up)
    end
    canonical_up_orbit = zeros(UInt16, 65536)
    for (orbit, rep) in enumerate(up_reps)
        canonical_up_orbit[Int(rep) + 1] = orbit
    end
    for up in up_masks
        canonical_up_orbit[Int(up) + 1] = canonical_up_orbit[Int(canonical_masks[Int(up) + 1]) + 1]
    end
    lookup_entries = length(down_masks) * length(up_reps)
    # Each table entry can produce at most one row: UInt32 lookup plus UInt16
    # down rank and UInt8 orbit length. Extra row arrays are allocated once.
    estimated_bytes = base_bytes + 7lookup_entries + 64(length(up_masks) +
        length(down_masks) + length(up_reps) + 1)
    _memory_guard(estimated_bytes, max_bytes)
    lookup_entries < (1 << 30) || throw(ArgumentError("packed lookup index exceeds 30 bits"))
    lookup = zeros(UInt32, length(down_masks), length(up_reps))
    row_down_ranks = Vector{UInt16}(undef, lookup_entries)
    orbit_lengths = Vector{UInt8}(undef, lookup_entries)
    row_offsets = Vector{Int}(undef, length(up_reps) + 1)
    visited = falses(length(down_masks))
    row = 0
    for (up_orbit, up) in enumerate(up_reps)
        row_offsets[up_orbit] = row + 1
        stabilizer = Int[g for g in 1:group_size if masks[Int(up) + 1, g] == up]
        fill!(visited, false)
        for (down_rank, down) in enumerate(down_masks)
            visited[down_rank] && continue
            admissible = true
            common_stabilizer_size = 0
            for g in stabilizer
                mapped_down = masks[Int(down) + 1, g]
                visited[Int(rank_down[Int(mapped_down) + 1])] = true
                if mapped_down == down
                    common_stabilizer_size += 1
                    code = Int(phases[g]) + (signs[Int(up) + 1, g] * signs[Int(down) + 1, g] == -1 ? 2 : 0)
                    admissible &= iszero(code & 3)
                end
            end
            admissible || continue
            row += 1
            row_down_ranks[row] = down_rank
            orbit_lengths[row] = group_size ÷ common_stabilizer_size
            # We have g: representative -> mapped_down; the lookup needs
            # its inverse. Fermion parity is unchanged by inversion, whereas
            # the fourth-root character must be conjugated.
            for g in stabilizer
                mapped_down = masks[Int(down) + 1, g]
                mapped_rank = Int(rank_down[Int(mapped_down) + 1])
                code = (-Int(phases[g]) + (signs[Int(up) + 1, g] * signs[Int(down) + 1, g] == -1 ? 2 : 0)) & 3
                packed = (UInt32(row) << 2) | UInt32(code)
                previous = lookup[mapped_rank, up_orbit]
                (iszero(previous) || previous == packed) || error("inconsistent stabilizer phase")
                lookup[mapped_rank, up_orbit] = packed
            end
        end
    end
    row_offsets[end] = row + 1
    resize!(row_down_ranks, row)
    resize!(orbit_lengths, row)
    return MomentumBasis(nmodes, Int(Nup), Int(Ndown), torus, Float64(kx), Float64(ky),
        up_masks, down_masks, up_reps, row_offsets, row_down_ranks, orbit_lengths,
        lookup, rank_up, rank_down, canonical_up_orbit, canonical_up_translation,
        masks, signs, phases, estimated_bytes)
end

"""Return `(row, code)` with `P|up,down⟩ = im^code P|representative(row)⟩`.
An excluded momentum orbit returns `(0,0)`; invalid particle masks throw.
"""
@inline function locate_code(basis::MomentumBasis, up::UInt16, down::UInt16)
    uslot, dslot = Int(up) + 1, Int(down) + 1
    (basis.rank_up[uslot] != 0 && basis.rank_down[dslot] != 0) ||
        throw(ArgumentError("masks are outside the fixed-spin sector"))
    up_orbit = Int(basis.canonical_up_orbit[uslot])
    g = Int(basis.canonical_up_translation[uslot])
    mapped_down = basis.translation_masks[dslot, g]
    down_rank = Int(basis.rank_down[Int(mapped_down) + 1])
    packed = basis.lookup[down_rank, up_orbit]
    iszero(packed) && return (0, UInt8(0))
    sign_code = basis.translation_signs[uslot, g] * basis.translation_signs[dslot, g] == -1 ? 2 : 0
    code = (Int(packed & 3) + Int(basis.translation_phases[g]) + sign_code) & 3
    return (Int(packed >> 2), UInt8(code))
end

function locate(basis::MomentumBasis, up::UInt16, down::UInt16)
    row, code = locate_code(basis, up, down)
    return row, phase_value(code)
end

"""Return the `(up,down)` masks of one normalized momentum-basis column."""
function representative(basis::MomentumBasis, row::Integer)
    1 <= row <= length(basis) || throw(BoundsError(basis, row))
    block = searchsortedlast(basis.row_offsets, row)
    return basis.up_reps[block], basis.down_masks[Int(basis.row_down_ranks[row])]
end

"""
Expand a small momentum vector into sorted fixed-spin Fock order (up masks
vary fastest). Intended for independent projector/operator validation only.
"""
function expand_momentum_vector(basis::MomentumBasis, vector::AbstractVector;
                                max_dimension::Integer=100_000)
    length(vector) == length(basis) || throw(DimensionMismatch("momentum vector length differs"))
    max_dimension > 0 || throw(ArgumentError("max_dimension must be positive"))
    dimension = length(basis.up_masks) * length(basis.down_masks)
    dimension <= max_dimension || throw(ArgumentError("full-space expansion exceeds max_dimension=$max_dimension"))
    result = zeros(promote_type(eltype(vector), ComplexF64), dimension)
    group_size = basis.torus.ncells
    for row in eachindex(vector)
        up, down = representative(basis, row)
        amplitude = sqrt(Float64(basis.orbit_lengths[row])) * vector[row] / group_size
        for g in 1:group_size
            mapped_up = basis.translation_masks[Int(up) + 1, g]
            mapped_down = basis.translation_masks[Int(down) + 1, g]
            full_row = Int(basis.rank_up[Int(mapped_up) + 1]) +
                (Int(basis.rank_down[Int(mapped_down) + 1]) - 1) * length(basis.up_masks)
            sign = basis.translation_signs[Int(up) + 1, g] * basis.translation_signs[Int(down) + 1, g]
            result[full_row] += amplitude * sign * phase_value(basis.translation_phases[g])
        end
    end
    return result
end

end # module
