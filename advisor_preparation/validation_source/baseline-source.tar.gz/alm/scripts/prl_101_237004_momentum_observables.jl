module PRL101237004MomentumObservables

using LinearAlgebra

export spin_structure_factors, total_spin_squared, free_slater_start

@inline _phase(code::Integer) = (1.0 + 0.0im, 0.0 + 1.0im,
                                 -1.0 + 0.0im, 0.0 - 1.0im)[Int(code & 3) + 1]

function _vector_norm_squared(basis, vector)
    length(vector) == length(basis.orbit_lengths) ||
        throw(DimensionMismatch("vector and momentum basis lengths differ"))
    Base.require_one_based_indexing(vector)
    value = sum(abs2, vector)
    isfinite(value) && value > 0 || throw(ArgumentError("vector must have a finite positive norm"))
    return Float64(value)
end

function _spin_fourier_sums(basis, masks, momenta)
    phases = ComplexF64[cis(qx*x + qy*y) / 2
                       for (x, y) in basis.torus.cells, (qx, qy) in momenta]
    result = zeros(ComplexF64, length(masks), length(momenta))
    for (rank, mask) in enumerate(masks), site in 1:basis.torus.ncells
        occupancy = count_ones((mask >> (2(site - 1))) & UInt16(3))
        for q in eachindex(momenta)
            result[rank, q] += occupancy * phases[site, q]
        end
    end
    return result
end

"""
    spin_structure_factors(basis, vector)

Return `(momenta, szsz_per_site, szsz_raw, norm_squared)`, with
`szsz_raw[q] = ⟨|sum_r exp(im*q⋅r) (n_up(r)-n_down(r))/2|²⟩` and
`szsz_per_site = szsz_raw/Nsites`. Both orbitals contribute at each site.
Expectations are divided by the input vector norm. The observable is invariant
under translations, so representative probabilities require no orbit weights.
This is the longitudinal correlation; converting it to a spin-dot correlation
by a factor of three requires an independently established spin singlet.
"""
function spin_structure_factors(basis, vector::AbstractVector)
    norm_squared = _vector_norm_squared(basis, vector)
    momenta = copy(basis.torus.momenta)
    up_sums = _spin_fourier_sums(basis, basis.up_masks, momenta)
    down_sums = basis.Nup == basis.Ndown ? up_sums :
        _spin_fourier_sums(basis, basis.down_masks, momenta)
    partial = zeros(Float64, length(momenta), Threads.maxthreadid())
    Threads.@threads :static for block in eachindex(basis.up_reps)
        thread = Threads.threadid()
        up_rank = Int(basis.rank_up[Int(basis.up_reps[block]) + 1])
        @inbounds for row in basis.row_offsets[block]:(basis.row_offsets[block + 1] - 1)
            probability = Float64(abs2(vector[row]))
            down_rank = Int(basis.row_down_ranks[row])
            for q in eachindex(momenta)
                partial[q, thread] += probability * abs2(up_sums[up_rank, q] - down_sums[down_rank, q])
            end
        end
    end
    raw = vec(sum(partial; dims=2)) ./ norm_squared
    return (momenta=momenta, szsz_per_site=raw ./ basis.torus.ncells,
            szsz_raw=raw, norm_squared=norm_squared)
end

# Generic field-based lookup avoids coupling to one nested copy of the basis
# module. It is the same packed representation, independently checked against
# unreduced Fock-space spin operators in the observable tests.
@inline function _locate_code(basis, up::UInt16, down::UInt16)
    uslot, dslot = Int(up) + 1, Int(down) + 1
    @inbounds begin
        block = Int(basis.canonical_up_orbit[uslot])
        g = Int(basis.canonical_up_translation[uslot])
        mapped_down = basis.translation_masks[dslot, g]
        rank = Int(basis.rank_down[Int(mapped_down) + 1])
        packed = basis.lookup[rank, block]
        iszero(packed) && return (0, UInt8(0))
        sign_code = basis.translation_signs[uslot, g] * basis.translation_signs[dslot, g] == -1 ? 2 : 0
        code = (Int(packed & 3) + Int(basis.translation_phases[g]) + sign_code) & 3
        return (Int(packed >> 2), UInt8(code))
    end
end

"""
    total_spin_squared(basis, vector)

Compute normalized `⟨S_total²⟩` within the existing fixed-spin momentum block,
without constructing a full Fock vector or an adjacent-spin-sector vector.
For `M=(Nup-Ndown)/2`, the diagonal is `M²+N/2-Ndouble`, and the off-diagonal
terms are `sum_{a≠b} S_a⁺S_b⁻` over spatial orbitals. Fermion reorder signs and
the momentum-orbit normalization are retained explicitly.
"""
function total_spin_squared(basis, vector::AbstractVector)
    norm_squared = _vector_norm_squared(basis, vector)
    partial = zeros(ComplexF64, Threads.maxthreadid())
    diagonal_constant = ((basis.Nup - basis.Ndown) / 2)^2 + (basis.Nup + basis.Ndown) / 2
    Threads.@threads :static for block in eachindex(basis.up_reps)
        thread = Threads.threadid()
        up = basis.up_reps[block]
        subtotal = 0.0 + 0.0im
        @inbounds for row in basis.row_offsets[block]:(basis.row_offsets[block + 1] - 1)
            down = basis.down_masks[Int(basis.row_down_ranks[row])]
            amplitude = vector[row]
            subtotal += (diagonal_constant - count_ones(up & down)) * abs2(amplitude)
            up_only, down_only = up & ~down, down & ~up
            sources = up_only
            while !iszero(sources)
                source = sources & (~sources + UInt16(1))
                targets = down_only
                while !iszero(targets)
                    target = targets & (~targets + UInt16(1))
                    flip = source | target
                    # S_a⁺S_b⁻ equals minus the product of separate-spin hops.
                    # Their parity is the occupation strictly between a and b.
                    lo, hi = minmax(source, target)
                    between = (hi - UInt16(1)) & ~(lo | (lo - UInt16(1)))
                    sign = isodd(count_ones((up ⊻ down) & between)) ? 1.0 : -1.0
                    destination, code = _locate_code(basis, up ⊻ flip, down ⊻ flip)
                    if destination != 0
                        factor = sqrt(Float64(basis.orbit_lengths[row]) / basis.orbit_lengths[destination])
                        subtotal += conj(vector[destination]) * amplitude * sign * _phase(code) * factor
                    end
                    targets &= targets - UInt16(1)
                end
                sources &= sources - UInt16(1)
            end
        end
        partial[thread] += subtotal
    end
    return real(sum(partial)) / norm_squared
end

function _slater_determinants(masks, orbitals)
    population = size(orbitals, 2)
    population == 0 && return ones(Float64, length(masks))
    workspace = Matrix{Float64}(undef, population, population)
    result = Vector{Float64}(undef, length(masks))
    for (rank, mask) in enumerate(masks)
        occupied = mask
        row = 0
        while !iszero(occupied)
            mode = trailing_zeros(occupied) + 1
            row += 1
            for column in 1:population
                workspace[row, column] = orbitals[mode, column]
            end
            occupied &= occupied - UInt16(1)
        end
        result[rank] = det(lu!(workspace; check=false))
    end
    return result
end

function _slater_characters(basis, masks, coefficients)
    characters = zeros(Int8, basis.torus.ncells)
    rank_map = length(masks) == length(basis.up_masks) && masks == basis.up_masks ? basis.rank_up : basis.rank_down
    for g in 1:basis.torus.ncells
        overlap = 0.0
        for (rank, mask) in enumerate(masks)
            transformed_rank = Int(rank_map[Int(basis.translation_masks[Int(mask) + 1, g]) + 1])
            overlap += coefficients[rank] * basis.translation_signs[Int(mask) + 1, g] * coefficients[transformed_rank]
        end
        character = overlap >= 0 ? Int8(1) : Int8(-1)
        defect = 0.0
        for (rank, mask) in enumerate(masks)
            transformed_rank = Int(rank_map[Int(basis.translation_masks[Int(mask) + 1, g]) + 1])
            defect += abs2(basis.translation_signs[Int(mask) + 1, g] * coefficients[transformed_rank] - character * coefficients[rank])
        end
        # Determinants of at most 16x16 orthonormal-orbital matrices carry
        # roundoff; this verifies covariance, not an approximate projection.
        defect <= (2e-11)^2 || return nothing
        characters[g] = character
    end
    return characters
end

"""
    free_slater_start(basis, K)

Fill the lowest `Nup` and `Ndown` eigenvectors of the real symmetric one-spin
matrix `K`, and return their normalized momentum projection as `vector`.
Other fields are `projection_weight`, `unprojected_energy`,
`orbital_gap_up`, `orbital_gap_down`, and `translation_covariance_verified`.
The determinant amplitudes are cached only for the single-spin mask lists.
Closed-shell translation covariance is checked before using the fast
`sqrt(orbit_length)*det(up)*det(down)` expression. Otherwise an explicit
finite-group projection handles arbitrary momentum and degenerate orbitals.
An exactly orthogonal momentum sector raises an error rather than returning
a numerically amplified zero vector.
"""
function free_slater_start(basis, K::AbstractMatrix{<:Real})
    size(K) == (basis.nmodes, basis.nmodes) || throw(DimensionMismatch("K and basis spatial modes differ"))
    issymmetric(K) || throw(ArgumentError("K must be real symmetric"))
    all(isfinite, K) || throw(ArgumentError("K must be finite"))
    spectrum = eigen(Symmetric(Matrix{Float64}(K)))
    up = _slater_determinants(basis.up_masks, view(spectrum.vectors, :, 1:basis.Nup))
    down = basis.Nup == basis.Ndown ? up :
        _slater_determinants(basis.down_masks, view(spectrum.vectors, :, 1:basis.Ndown))
    up_characters = _slater_characters(basis, basis.up_masks, up)
    down_characters = basis.Nup == basis.Ndown ? up_characters :
        _slater_characters(basis, basis.down_masks, down)
    covariant = up_characters !== nothing && down_characters !== nothing
    if covariant
        all(g -> abs(_phase(basis.translation_phases[g]) - up_characters[g] * down_characters[g]) < 2e-12,
            1:basis.torus.ncells) || throw(ArgumentError("free Slater determinant has zero weight in this momentum sector"))
    end
    is_real = all(code -> iseven(code), basis.translation_phases)
    T = is_real ? Float64 : ComplexF64
    vector = zeros(T, length(basis.orbit_lengths))
    Threads.@threads :static for block in eachindex(basis.up_reps)
        up_mask = basis.up_reps[block]
        up_rank = Int(basis.rank_up[Int(up_mask) + 1])
        @inbounds for row in basis.row_offsets[block]:(basis.row_offsets[block + 1] - 1)
            down_rank = Int(basis.row_down_ranks[row])
            factor = sqrt(Float64(basis.orbit_lengths[row]))
            if covariant
                vector[row] = factor * up[up_rank] * down[down_rank]
            else
                down_mask = basis.down_masks[down_rank]
                coefficient = 0.0 + 0.0im
                for g in 1:basis.torus.ncells
                    mapped_up = basis.translation_masks[Int(up_mask) + 1, g]
                    mapped_down = basis.translation_masks[Int(down_mask) + 1, g]
                    up_target = Int(basis.rank_up[Int(mapped_up) + 1])
                    down_target = Int(basis.rank_down[Int(mapped_down) + 1])
                    sign = basis.translation_signs[Int(up_mask) + 1, g] * basis.translation_signs[Int(down_mask) + 1, g]
                    coefficient += conj(_phase(basis.translation_phases[g])) * sign * up[up_target] * down[down_target]
                end
                projected = factor * coefficient / basis.torus.ncells
                vector[row] = is_real ? real(projected) : projected
            end
        end
    end
    projection_weight = sum(abs2, vector)
    projection_weight > 1e-24 || throw(ArgumentError("free Slater determinant has zero weight in this momentum sector"))
    vector ./= sqrt(projection_weight)
    gap(population) = population == 0 || population == basis.nmodes ? Inf :
        spectrum.values[population + 1] - spectrum.values[population]
    energy = sum(view(spectrum.values, 1:basis.Nup)) + sum(view(spectrum.values, 1:basis.Ndown))
    return (vector=vector, projection_weight=projection_weight, unprojected_energy=energy,
            orbital_gap_up=gap(basis.Nup), orbital_gap_down=gap(basis.Ndown),
            translation_covariance_verified=covariant)
end

end # module
