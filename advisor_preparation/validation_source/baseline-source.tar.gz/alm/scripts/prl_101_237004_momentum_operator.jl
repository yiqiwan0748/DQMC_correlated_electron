module PRL101237004MomentumOperator

using LinearAlgebra
using Base.Threads

export MomentumHamiltonian, momentum_hamiltonian

struct UpMove
    orbit::UInt16
    translation::UInt8
    phase::UInt8
    amplitude::Float64
end

struct DownMove
    rank::UInt16
    amplitude::Float64
end

"""Matrix-free Eq. (2), in normalized translation orbits. No sparse many-body
matrix is stored. Hopping is precomputed in the small one-spin spaces, and
independent output rows are gathered in parallel (no atomic additions).
The basis uses all up-spin modes followed by all down-spin modes.
"""
struct MomentumHamiltonian{T,B} <: AbstractMatrix{T}
    basis::B
    K::Matrix{Float64}
    U::Float64
    J::Float64
    diagonal::Vector{Float64}
    up_offsets::Vector{Int}
    up_moves::Vector{UpMove}
    down_offsets::Vector{Int}
    down_moves::Vector{DownMove}
    local_moves::Matrix{UpMove}
    orbit_ratios::Matrix{Float64}
    estimated_bytes::Int
end

Base.size(H::MomentumHamiltonian) = (length(H.diagonal), length(H.diagonal))
LinearAlgebra.ishermitian(::MomentumHamiltonian) = true
LinearAlgebra.issymmetric(::MomentumHamiltonian{Float64}) = true

@inline _paired(mask::UInt16) = count_ones(mask & (mask >> 1) & 0x5555)
@inline _swap_orbitals(mask::UInt16) = ((mask & 0x5555) << 1) | ((mask & 0xaaaa) >> 1)
@inline _single(pattern::UInt16) = pattern == 1 || pattern == 2
@inline _phase(::Type{Float64}, code) = iszero(code & 2) ? 1.0 : -1.0
@inline _phase(::Type{ComplexF64}, code) =
    (1.0 + 0im, 0.0 - 1im, -1.0 + 0im, 0.0 + 1im)[Int(code & 3) + 1]

function _up_move(b, up::UInt16, amplitude)
    slot = Int(up) + 1
    g = Int(b.canonical_up_translation[slot])
    phase = (Int(b.translation_phases[g]) +
             (b.translation_signs[slot, g] == -1 ? 2 : 0)) & 3
    return UpMove(b.canonical_up_orbit[slot], UInt8(g), UInt8(phase), amplitude)
end

function _hops(mask::UInt16, K, nmodes)
    result = Tuple{UInt16,Float64}[]
    for source in 1:nmodes
        source_bit = UInt16(1) << (source - 1)
        iszero(mask & source_bit) && continue
        removed = mask ⊻ source_bit
        annihilation_sign = isodd(count_ones(mask & (source_bit - UInt16(1)))) ? -1 : 1
        for target in 1:nmodes
            (source == target || iszero(K[target, source])) && continue
            target_bit = UInt16(1) << (target - 1)
            iszero(removed & target_bit) || continue
            creation_sign = isodd(count_ones(removed & (target_bit - UInt16(1)))) ? -1 : 1
            push!(result, (removed | target_bit,
                          annihilation_sign * creation_sign * K[target, source]))
        end
    end
    return result
end

"""
    momentum_hamiltonian(basis, K, U; J=U/4, max_bytes=1024^3)

Full spin-rotation-invariant PRL interaction, with U'=U-2J. The budget includes
the existing basis and all operator-owned arrays, but excludes solver vectors.
K must be a real symmetric translation-invariant one-spin matrix. On-site
off-diagonal orbital hybridization is supported as ordinary hopping.
"""
function momentum_hamiltonian(b, K::AbstractMatrix{<:Real}, U::Real;
                              J::Real=U/4, max_bytes::Integer=1024^3)
    size(K) == (b.nmodes, b.nmodes) || throw(DimensionMismatch("one-spin K size differs"))
    all(isfinite, K) && isfinite(U) && isfinite(J) || throw(ArgumentError("parameters must be finite"))
    K = Matrix{Float64}(K)
    U, J = Float64(U), Float64(J)
    all(isfinite,K) && all(isfinite,(U,J,U-2J,U-3J)) ||
        throw(ArgumentError("parameters overflow Float64 interaction arithmetic"))
    isapprox(K, transpose(K); atol=2e-13, rtol=0) || throw(ArgumentError("K must be symmetric"))
    # Absolute tolerance covers only Float64 bond summation; a non-invariant
    # operator cannot act within one momentum block.
    for g in 1:b.torus.ncells
        permutation = [trailing_zeros(b.translation_masks[(1 << (a-1))+1, g])+1 for a in 1:b.nmodes]
        isapprox(K[permutation, permutation], K; atol=2e-13, rtol=0) ||
            throw(ArgumentError("K does not preserve translations"))
    end
    estimate = b.estimated_bytes + 8big(length(b)) +
        16big(b.nmodes)^2 * (length(b.up_reps) + length(b.down_masks)) + 2^20
    estimate <= max_bytes || throw(ArgumentError("operator and basis estimate $estimate exceeds max_bytes=$max_bytes"))
    up_offsets, down_offsets = Int[1], Int[1]
    up_moves, down_moves = UpMove[], DownMove[]
    for up in b.up_reps
        for (next, amplitude) in _hops(up, K, b.nmodes)
            push!(up_moves, _up_move(b, next, amplitude))
        end
        push!(up_offsets, length(up_moves)+1)
    end
    for down in b.down_masks
        for (next, amplitude) in _hops(down, K, b.nmodes)
            push!(down_moves, DownMove(UInt16(b.rank_down[Int(next)+1]), amplitude))
        end
        push!(down_offsets, length(down_moves)+1)
    end
    local_moves = Matrix{UpMove}(undef, b.torus.ncells, length(b.up_reps))
    for (block, up) in enumerate(b.up_reps), site in 1:b.torus.ncells
        shift = 2(site-1)
        local_moves[site, block] = _single((up >> shift) & 0x0003) ?
            _up_move(b, up ⊻ (UInt16(3) << shift), Float64(J)) :
            UpMove(0, 0, 0, 0.0)
    end
    diagonal = Vector{Float64}(undef, length(b))
    one_spin_diagonal = zeros(Float64, 65536)
    for mask in union(b.up_masks, b.down_masks)
        one_spin_diagonal[Int(mask)+1] = sum(K[a,a] for a in 1:b.nmodes if !iszero(mask & (UInt16(1) << (a-1))); init=0.0)
    end
    @threads :dynamic for block in eachindex(b.up_reps)
        up = b.up_reps[block]
        for row in b.row_offsets[block]:(b.row_offsets[block+1]-1)
            @inbounds down = b.down_masks[Int(b.row_down_ranks[row])]
            @inbounds diagonal[row] = U*count_ones(up & down) +
                (U-3J)*(_paired(up)+_paired(down)) +
                (U-2J)*count_ones(up & _swap_orbitals(down)) +
                one_spin_diagonal[Int(up)+1] + one_spin_diagonal[Int(down)+1]
        end
    end
    all(isfinite,diagonal) || throw(ArgumentError("diagonal interaction energy overflowed Float64"))
    ratios = [sqrt(i/j) for i in 1:8, j in 1:8]
    T = all(iseven, b.translation_phases) ? Float64 : ComplexF64
    return MomentumHamiltonian{T,typeof(b)}(b, Matrix{Float64}(K), Float64(U), Float64(J),
        diagonal, up_offsets, up_moves, down_offsets, down_moves, local_moves, ratios, Int(estimate))
end

@inline function _translated_contribution(H::MomentumHamiltonian{T}, move, down::UInt16,
                                           Li::Int, input) where T
    b = H.basis
    g, orbit = Int(move.translation), Int(move.orbit)
    @inbounds mapped_down = b.translation_masks[Int(down)+1, g]
    @inbounds rank = Int(b.rank_down[Int(mapped_down)+1])
    @inbounds packed = b.lookup[rank, orbit]
    iszero(packed) && return zero(eltype(input))
    j = Int(packed >> 2)
    @inbounds phase = Int(move.phase) + Int(packed & 3) +
        (b.translation_signs[Int(down)+1, g] == -1 ? 2 : 0)
    @inbounds return move.amplitude * _phase(T, phase) *
        H.orbit_ratios[Li, Int(b.orbit_lengths[j])] * input[j]
end

function LinearAlgebra.mul!(output::AbstractVector, H::MomentumHamiltonian{T},
                            input::AbstractVector, alpha::Number, beta::Number) where T
    length(input) == length(output) == size(H,1) || throw(DimensionMismatch("vector size differs"))
    Base.mightalias(input, output) && throw(ArgumentError("mul! input/output must not alias"))
    T <: Complex && !(eltype(output) <: Complex) && throw(ArgumentError("complex momentum requires complex output"))
    b = H.basis
    @threads :dynamic for block in eachindex(b.up_reps)
        up = b.up_reps[block]
        @inbounds for row in b.row_offsets[block]:(b.row_offsets[block+1]-1)
            dr = Int(b.row_down_ranks[row])
            down = b.down_masks[dr]
            Li = Int(b.orbit_lengths[row])
            value = H.diagonal[row] * input[row]
            # Gather conjugated column transitions. The orbit factor is
            # sqrt(L_source/L_target), derived from sqrt(L)*P(k)|rep>.
            for entry in H.down_offsets[dr]:(H.down_offsets[dr+1]-1)
                move = H.down_moves[entry]
                packed = b.lookup[Int(move.rank), block]
                iszero(packed) && continue
                j = Int(packed >> 2)
                value += move.amplitude * _phase(T, Int(packed & 3)) *
                    H.orbit_ratios[Li, Int(b.orbit_lengths[j])] * input[j]
            end
            for entry in H.up_offsets[block]:(H.up_offsets[block+1]-1)
                value += _translated_contribution(H, H.up_moves[entry], down, Li, input)
            end
            if !iszero(H.J)
                for site in 1:b.torus.ncells
                    move = H.local_moves[site,block]
                    iszero(move.orbit) && continue
                    shift = 2(site-1)
                    _single((down >> shift) & 0x0003) || continue
                    # In this Fock ordering, both a pair transfer and a Hund
                    # spin flip have +J matrix element for this simultaneous
                    # two-orbital toggle. Their operator coefficients remain
                    # +J and -J, respectively, before fermionic signs.
                    next_down = down ⊻ (UInt16(3) << shift)
                    value += _translated_contribution(H, move, next_down, Li, input)
                end
            end
            output[row] = iszero(beta) ? alpha*value : alpha*value + beta*output[row]
        end
    end
    return output
end

LinearAlgebra.mul!(output::AbstractVector, H::MomentumHamiltonian, input::AbstractVector) =
    mul!(output, H, input, one(eltype(H)), zero(eltype(H)))
function Base.:*(H::MomentumHamiltonian, input::AbstractVector)
    output = Vector{promote_type(eltype(H), eltype(input))}(undef, size(H,1))
    return mul!(output, H, input)
end

end # module
