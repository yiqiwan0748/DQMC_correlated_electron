module PRL101237004Spectra

using LinearAlgebra
include("prl_101_237004_vca_geometry.jl")
const G = PRL101237004VCAGeometry

export SpectralProblem, SpectralPlan, spectral_plan, reduced_momentum,
       periodization_matrix, embedded_green, periodized_green, spectral_matrix,
       spectral_grid, dos_spectrum

"""Fixed canonical reference and stationary physical/reference potentials.

The reference is duck typed: `nsites`, `kinetics[spin]`, and
`green(z_canonical,spin)` are required; the latter may return G or (G,Gdot).
This accepts saved Fig2c states even when their Julia module paths differ.
The rectangle and paper-convention hopping parameters are copied into this
module's geometry types. Frequencies supplied to this module are ω−μ.
"""
struct SpectralProblem{R}
    reference::R
    cluster::G.ReferenceCluster
    parameters::G.Model.PaperHoppingParameters{Float64}
    mu::Float64
    mu_prime::Float64
end

function SpectralProblem(reference,cluster,parameters;mu::Real,mu_prime::Real)
    all(isfinite,(mu,mu_prime)) || throw(ArgumentError("finite chemical potentials required"))
    c=G.rectangular_cluster(cluster.Lx,cluster.Ly)
    collect(cluster.sites)==c.sites || throw(ArgumentError("reference site order must be x-fast in the open rectangle"))
    reference.nsites==length(c.sites) || throw(DimensionMismatch("reference and geometry site counts differ"))
    n=2length(c.sites)
    length(reference.kinetics)==2 || throw(DimensionMismatch("two spin kinetic matrices required"))
    all(size(K)==(n,n) && all(isfinite,K) && isapprox(K,K';atol=3e-12,rtol=3e-12)
        for K in reference.kinetics) || throw(ArgumentError("finite Hermitian reference kinetics required"))
    if hasproperty(reference,:mu_interval)
        reference.mu_interval[1]<mu_prime<reference.mu_interval[2] ||
            throw(ArgumentError("reference potential lies outside its declared charge branch"))
    end
    p=G.Model.PaperHoppingParameters(Float64(parameters.t1),Float64(parameters.t2),
                                    Float64(parameters.t3),Float64(parameters.t4))
    SpectralProblem(reference,c,p,Float64(mu),Float64(mu_prime))
end

"""Physical momentum mapped to [-π/Lx,π/Lx)×[-π/Ly,π/Ly).
Only the supercell resolvent uses the folded momentum; the periodizer keeps
the full physical k, so folded bands retain their unfolding weights.
"""
function reduced_momentum(cluster,kx::Real,ky::Real)
    all(isfinite,(kx,ky)) || throw(ArgumentError("finite momenta required"))
    (mod(Float64(kx)+pi/cluster.Lx,2pi/cluster.Lx)-pi/cluster.Lx,
     mod(Float64(ky)+pi/cluster.Ly,2pi/cluster.Ly)-pi/cluster.Ly)
end

"""W[iα,β]=δαβ exp(+ik⋅rᵢ)/√Nc in the existing cell-translation gauge.
G(k,z)=W† Gsuper(k̃,z) W. The positive phase is fixed by Kij(k̃) carrying
exp(+ik̃⋅R): at U=0, Ksuper W = W Hpaper(k). W†W=I₂.
"""
function periodization_matrix(sites::AbstractVector,kx::Real,ky::Real)
    !isempty(sites) && all(isfinite,(kx,ky)) || throw(ArgumentError("nonempty sites and finite k required"))
    W=zeros(ComplexF64,2length(sites),2)
    scale=inv(sqrt(length(sites)))
    for (i,(x,y)) in enumerate(sites)
        all(isfinite,(x,y)) || throw(ArgumentError("finite site positions required"))
        phase=scale*cis(kx*x+ky*y)
        W[2i-1,1]=phase
        W[2i,2]=phase
    end
    W
end
periodization_matrix(cluster,kx::Real,ky::Real)=periodization_matrix(cluster.sites,kx,ky)

struct SpectralPlan{P}
    problem::P
    kpoints::Vector{NTuple{2,Float64}}
    reduced_kpoints::Vector{NTuple{2,Float64}}
    potentials::NTuple{2,Vector{Matrix{ComplexF64}}}
    projectors::Vector{Matrix{ComplexF64}}
    phase_weights::Vector{Matrix{ComplexF64}}
end

"""Cache frequency-independent matrices for a path or a uniform momentum mesh.
Physical momenta may cover the full BZ or lie in the reduced BZ. For DOS,
pass a uniform reduced-BZ mesh; the trace average needs no periodization.
"""
function spectral_plan(problem::SpectralProblem,kpoints)
    points=NTuple{2,Float64}[]
    for k in kpoints
        length(k)==2 && all(isfinite,k) || throw(ArgumentError("each momentum must contain two finite coordinates"))
        push!(points,(Float64(k[1]),Float64(k[2])))
    end
    !isempty(points) || throw(ArgumentError("empty momentum grid"))
    reduced=[reduced_momentum(problem.cluster,k...) for k in points]
    hopping=[G.lattice_kinetic(problem.cluster,k...,problem.parameters) for k in reduced]
    potentials=ntuple(s->[K-problem.reference.kinetics[s]+(problem.mu_prime-problem.mu)*I for K in hopping],2)
    projectors=[periodization_matrix(problem.cluster,k...) for k in points]
    weights=[conj.(W[1:2:end,1])*transpose(W[1:2:end,1]) for W in projectors]
    SpectralPlan(problem,points,reduced,potentials,projectors,weights)
end

function _spin(spin)
    spin===:up && return 1
    spin===:down && return 2
    spin isa Integer && spin in (1,2) && return Int(spin)
    throw(ArgumentError("spin must be 1/:up or 2/:down"))
end

function _retarded(z)
    z isa Number && isfinite(z) && imag(z)>0 || throw(ArgumentError("retarded z requires finite real part and strictly positive imaginary part"))
    ComplexF64(z)
end

function _reference_green(problem,z,spin)
    value=problem.reference.green(z+problem.mu_prime,spin)
    raw=value isa Tuple ? first(value) : value
    n=2problem.reference.nsites
    raw isa AbstractMatrix && size(raw)==(n,n) && all(isfinite,raw) ||
        throw(ArgumentError("reference Green callback returned invalid dimensions or entries"))
    Matrix{ComplexF64}(raw)
end

# No inverse of G′ is taken. LU solves against an identity buffer avoid the
# large work allocation used by inv! for millions of small embedding solves.
function _embed!(output,Gref,V,M,B)
    mul!(M,V,Gref)
    M .*= -1
    for i in axes(M,1)
        M[i,i]+=1
    end
    factor=lu!(M;check=false)
    issuccess(factor) || error("singular retarded embedding matrix")
    fill!(B,0)
    for i in axes(B,1)
        B[i,i]=1
    end
    ldiv!(factor,B)
    mul!(output,Gref,B)
    output
end

"""Spin-block lattice Green matrix at z=ω+iη, measured from physical μ.
G=[G′(z+μ′)⁻¹−K(k̃)+K′−(μ′−μ)I]⁻¹, evaluated without inverting G′.
"""
function embedded_green(problem::SpectralProblem,kx::Real,ky::Real,z;spin=1)
    s=_spin(spin);zz=_retarded(z)
    q=reduced_momentum(problem.cluster,kx,ky)
    V=G.lattice_kinetic(problem.cluster,q...,problem.parameters)-problem.reference.kinetics[s]+(problem.mu_prime-problem.mu)*I
    ref=_reference_green(problem,zz,s)
    _embed!(similar(ref),ref,V,similar(ref),similar(ref))
end

"""Project any cell-gauge Green matrix to the physical two-orbital momentum."""
function periodized_green(matrix::AbstractMatrix,sites,kx::Real,ky::Real)
    W=periodization_matrix(sites,kx,ky)
    size(matrix)==(size(W,1),size(W,1)) || throw(DimensionMismatch("Green matrix and periodizer differ"))
    W'*matrix*W
end
function periodized_green(problem::SpectralProblem,kx::Real,ky::Real,z;spin=1)
    periodized_green(embedded_green(problem,kx,ky,z;spin),problem.cluster,kx,ky)
end

"""Hermitian spectral matrix −(G−G†)/(2πi), not entrywise imaginary parts."""
spectral_matrix(matrix::AbstractMatrix)=Matrix(Hermitian((matrix'-matrix)/(2im*pi)))
spectral_matrix(problem::SpectralProblem,kx::Real,ky::Real,z;spin=1)=
    spectral_matrix(periodized_green(problem,kx,ky,z;spin))

function _frequency_grid(frequencies,eta)
    eta isa Real && isfinite(eta) && eta>0 || throw(ArgumentError("eta must be finite and positive"))
    omega=Float64.(collect(frequencies))
    !isempty(omega) && all(isfinite,omega) || throw(ArgumentError("nonempty finite frequency grid required"))
    omega,Float64(eta)
end

function _foreach_frequency(work,n,threaded)
    if threaded && Threads.nthreads()>1
        Threads.@threads :static for index in 1:n
            work(index)
        end
    else
        for index in 1:n
            work(index)
        end
    end
end

"""Physical spectral intensity, summed over both spins and both orbitals.

Returns `(omega,kpoints,eta,total,spin_orbital)`. `total` has axes (ω,k),
and optional `spin_orbital` has axes (ω,k,orbital,spin), orbital=(xz,yz).
Each physical k has zeroth-moment weight4, not 4Nc. No clipping, smoothing,
spin averaging, intensity rescaling, or artificial band fitting is applied.
"""
function spectral_grid(plan::SpectralPlan,frequencies;eta=.05,resolved::Bool=false,threaded::Bool=true)
    omega,broadening=_frequency_grid(frequencies,eta)
    nk,nw=length(plan.kpoints),length(omega)
    nc=plan.problem.reference.nsites;n=2nc
    total=zeros(nw,nk)
    components=resolved ? zeros(nw,nk,2,2) : nothing
    function frequency(index)
        M=Matrix{ComplexF64}(undef,n,n);B=similar(M);embedded=similar(M)
        for spin in 1:2
            ref=_reference_green(plan.problem,complex(omega[index],broadening),spin)
            for k in 1:nk
                _embed!(embedded,ref,plan.potentials[spin][k],M,B)
                weights=plan.phase_weights[k]
                for orbital in 1:2
                    value=0.0+0.0im
                    @inbounds for j in 1:nc,i in 1:nc
                        value+=weights[i,j]*embedded[2i-2+orbital,2j-2+orbital]
                    end
                    intensity=-imag(value)/pi
                    total[index,k]+=intensity
                    resolved && (components[index,k,orbital,spin]=intensity)
                end
            end
        end
    end
    _foreach_frequency(frequency,nw,threaded)
    all(isfinite,total) || error("nonfinite spectral intensity")
    (;omega,kpoints=plan.kpoints,eta=broadening,total,spin_orbital=components)
end

"""DOS per Fe from the uniform reduced-BZ supercell trace average.

Returns `(omega,eta,total,spin_orbital,k_points,nsites)`. Total has axis ω;
optional components have axes (ω,orbital,spin). Its integrated weight is4
states/Fe. Caller supplies a uniform grid with equal weights. Full-BZ trace
averaging also works when it repeats each reduced momentum equally often.
A finite-η occupied integral contains Lorentzian tails and is not a zero-T
particle-count check.
"""
function dos_spectrum(plan::SpectralPlan,frequencies;eta=.05,resolved::Bool=false,threaded::Bool=true)
    omega,broadening=_frequency_grid(frequencies,eta)
    nk,nw=length(plan.kpoints),length(omega)
    nc=plan.problem.reference.nsites;n=2nc
    total=zeros(nw)
    components=resolved ? zeros(nw,2,2) : nothing
    function frequency(index)
        M=Matrix{ComplexF64}(undef,n,n);B=similar(M);embedded=similar(M)
        for spin in 1:2
            ref=_reference_green(plan.problem,complex(omega[index],broadening),spin)
            for k in 1:nk
                _embed!(embedded,ref,plan.potentials[spin][k],M,B)
                for orbital in 1:2
                    intensity=-sum(imag(embedded[2i-2+orbital,2i-2+orbital]) for i in 1:nc)/(pi*nc*nk)
                    total[index]+=intensity
                    resolved && (components[index,orbital,spin]+=intensity)
                end
            end
        end
    end
    _foreach_frequency(frequency,nw,threaded)
    all(isfinite,total) || error("nonfinite density of states")
    (;omega,eta=broadening,total,spin_orbital=components,k_points=nk,nsites=nc)
end

end
