module PRL101237004VCACampaign

using LinearAlgebra, SHA, Serialization, Printf, Dates
include("prl_101_237004_cluster_green.jl")
include("prl_101_237004_vca_functional.jl")
include("prl_101_237004_vca_stationarity.jl")
const C=PRL101237004ClusterGreen
const F=PRL101237004VCAFunctional
const G=F.Geometry
const S=PRL101237004VCAStationarity
const ROOT=normpath(joinpath(@__DIR__,".."))
const DEFAULT_OUTPUT=joinpath(ROOT,"results","prl_101_237004","milestone4")
const REFERENCE_SOURCES=("prl_101_237004_cluster_green.jl","prl_101_237004_ed.jl","prl_101_237004_restarted_lanczos.jl")

function write_csv(path,header,rows)
    mkpath(dirname(path))
    open(path*".partial","w") do io
        println(io,header)
        for row in rows
            println(io,join(row,','))
        end
    end
    mv(path*".partial",path;force=true)
end

filehash(path)=bytes2hex(open(sha256,path))
reference_hashes()=Dict(name=>filehash(joinpath(@__DIR__,name)) for name in REFERENCE_SOURCES)

"""Cached canonical reference solve. Cache identity includes exact one-body
matrices, physical couplings, Krylov configuration and numerical source hashes.
Only locally produced Julia checkpoints are read. Cache files contain no
fitted or digitized figure values.
"""
function reference_state(h::Real,channel::Symbol;U=1.0,ratio=-0.2,block_steps=48,
                         output=DEFAULT_OUTPUT,seed=7)
    c=G.rectangular_cluster()
    p=G.Model.slater_koster_parameters(ratio)
    K=G.weiss_kinetics(c,h;channel,p)
    hashes=reference_hashes()
    signature=bytes2hex(sha256(join([name*hashes[name] for name in sort(collect(keys(hashes)))],"\n")))[1:16]
    key=string(channel,"_h",string(reinterpret(UInt64,Float64(h));base=16),"_U",U,"_r",ratio,"_b",block_steps,"_s",seed)
    directory=joinpath(output,"reference_cache",signature)
    cache=joinpath(directory,key*".jls")
    probes=ComplexF64[complex(mup,w) for mup in (.65,.85,1.05) for w in (.00001,.001,.01,.1,1.0,10.0)]
    metadata=(;U=Float64(U),J=Float64(U/4),ratio=Float64(ratio),h=Float64(h),channel,
        Nup=4,Ndown=4,Kup=K.up,Kdown=K.down,block_steps,seed,probe_z=probes,source_hashes=hashes)
    if isfile(cache)
        saved=open(deserialize,cache)
        saved.metadata==metadata || error("reference cache metadata mismatch")
        result=saved.result
        seconds=saved.seconds
    else
        mkpath(directory)
        snapshot=joinpath(directory,"source_snapshot")
        mkpath(snapshot)
        for source in REFERENCE_SOURCES
            target=joinpath(snapshot,source)
            if isfile(target)
                filehash(target)==hashes[source] || error("source snapshot mismatch")
            else
                cp(joinpath(@__DIR__,source),target)
            end
        end
        seconds=@elapsed result=C.build_cluster_green(K.up,K.down,U,4,4;J=U/4,
            block_steps,probe_z=probes,seed,require_convergence=false)
        open(cache*".partial","w") do io
            serialize(io,(;metadata,result,seconds,julia=string(VERSION)))
        end
        mv(cache*".partial",cache)
        open(replace(cache,".jls"=>".txt"),"w") do io
            println(io,"Created: ",now(),"; Julia ",VERSION)
            println(io,"Metadata: ",metadata)
            println(io,"Canonical E0: ",result.E0,"; direct residual: ",result.ground_residual)
            println(io,"Neighbor-sector chemical-potential interval: ",result.mu_interval)
            println(io,"Probe-grid convergence: ",result.converged,"; elapsed seconds: ",seconds)
            println(io,"Checkpoint SHA256: ",filehash(cache))
            for ch in result.channels
                println(io,ch.spin," ",ch.kind,"; dimension=",ch.krylov_dimension,
                    "; half-depth difference=",ch.convergence_error,"; moment errors=",ch.moment_errors)
            end
        end
    end
    function greens(z,spin)
        label=spin==1 ? :up : :down
        C.cluster_green(result,z;spin=label),C.green_mu_derivative(result,z;spin=label)
    end
    reference=F.ReferenceSystem(result.E0,8,K.up,K.down,greens;mu_interval=result.mu_interval)
    (;result,reference,cluster=c,parameters=p,cache,metadata,seconds)
end

function embedding(state;physical_L=48)
    F.LatticeEmbedding(state.cluster;physical_L,p=state.parameters,channel=state.metadata.channel)
end

function stationary_point(state,lat;mu=.85,order=24,initial=nothing,gradient_atol=1e-7,scan_points=9)
    q=F.imaginary_quadrature(order)
    evaluate(mup)=F.evaluate_functional(state.reference,lat,mu,mup;quadrature=q)
    search=S.stationary_reference_mu(evaluate,state.result.mu_interval;
        initial,gradient_atol,scan_points,x_atol=1e-8,max_iterations=40,edge_fraction=.03)
    search.status in (:converged,:flat) || error("incomplete μ′ stationarity search at h=$(state.metadata.h): $(search.status)")
    if isempty(search.roots)
        search.status==:flat || error("no certified μ′ stationary root at h=$(state.metadata.h): $(search.status)")
        choice=search.representative
    else
        anchor=initial===nothing ? mu : initial
        choice=search.roots[argmin(abs(root.mu_prime-anchor) for root in search.roots)]
    end
    (;choice,search)
end

const SCAN_SOURCES=vcat("scripts/".*["prl_101_237004_vca_campaign.jl","prl_101_237004_vca_stationarity.jl",
    "prl_101_237004_vca_functional.jl","prl_101_237004_vca_geometry.jl","prl_101_237004_model.jl",
    "prl_101_237004_cluster_green.jl","prl_101_237004_ed.jl","prl_101_237004_restarted_lanczos.jl"],
    ["src/noninteracting.jl"])

function scan_curve(fields,channel;mu=.85,physical_L=48,order=24,block_steps=48,
                    U=1.0,ratio=-.2,output=DEFAULT_OUTPUT,label="fig2b_initial",initial=nothing)
    folder=joinpath(output,"scans",label)
    path=joinpath(folder,string(channel)*".csv")
    isfile(path) && error("completed scan exists: $path")
    mkpath(folder)
    snapshot=joinpath(folder,"source_snapshot")
    for source in SCAN_SOURCES
        target=joinpath(snapshot,source)
        mkpath(dirname(target))
        if isfile(target)
            filehash(target)==filehash(joinpath(ROOT,source)) || error("scan source snapshot differs; use a fresh label")
        else
            cp(joinpath(ROOT,source),target)
        end
    end
    rows=Tuple[]; branches=Tuple[]
    header="channel,h,U,J,ratio,mu,mu_prime,Omega_per_Fe,density,moment_signed_muB_per_Fe,mu_prime_gradient,reference_E0,reference_residual,green_probe_converged,green_half_depth_error,mu_prime_lower,mu_prime_upper,root_count,physical_L,quadrature_order,block_steps,functional_evaluations,seconds,reference_cache"
    previous=initial
    for h in fields
        elapsed=@elapsed begin
            state=reference_state(h,channel;U,ratio,block_steps,output)
            lat=embedding(state;physical_L)
            solved=stationary_point(state,lat;mu,order,initial=previous)
        end
        selected=solved.choice
        x=selected.data
        previous=selected.mu_prime
        for root in solved.search.roots
            push!(branches,(channel,h,root.mu_prime,root.data.omega,root.data.density,root.gradient,root.iterations,root.status))
        end
        push!(rows,(channel,h,U,U/4,ratio,mu,x.mu_prime,x.omega,x.density,x.moment,x.mu_prime_gradient,
            state.result.E0,state.result.ground_residual,state.result.converged,
            maximum(ch.convergence_error for ch in state.result.channels),state.result.mu_interval...,
            length(solved.search.roots),physical_L,order,block_steps,solved.search.evaluations,elapsed,relpath(state.cache,output)))
        write_csv(path*".progress",header,rows)
        write_csv(joinpath(folder,string(channel)*"_stationary_branches.csv"),
            "channel,h,mu_prime,Omega_per_Fe,density,gradient,iterations,status",branches)
        @printf("%s %s h=%.5f μ′=%.9f Ω=%.10f n=%.9f gradient=%.3g roots=%d %.2fs\n",
            string(now()),string(channel),h,x.mu_prime,x.omega,x.density,x.mu_prime_gradient,length(solved.search.roots),elapsed)
        flush(stdout)
    end
    write_csv(path,header,rows)
    rm(path*".progress")
    open(joinpath(folder,string(channel)*"_metadata.txt"),"w") do io
        println(io,"Generated: ",now(),"; Julia: ",VERSION,"; Julia threads: ",Threads.nthreads(),"; BLAS threads: ",BLAS.get_num_threads())
        println(io,"Physical μ is fixed across the field scan. μ′ is independently stationary at every point.")
        println(io,"Selection follows the stationary root closest to the prior field's μ′; the first anchor is physical μ. All detected roots are retained.")
        println(io,"Reference cluster: open2x2 Fe; original printed hoppings; +h Σp(nup−ndown), no1/2. Grand potential perFe.")
        println(io,"μ′ bounds from immediate neighboring spin/charge sectors are necessary; separate all-sector audits check sufficiency at selected points.")
        for source in SCAN_SOURCES
            println(io,filehash(joinpath(ROOT,source)),"  ",source)
        end
    end
    path
end

end
