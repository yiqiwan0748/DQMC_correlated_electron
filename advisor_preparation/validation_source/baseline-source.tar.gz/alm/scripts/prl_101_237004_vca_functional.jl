module PRL101237004VCAFunctional

using LinearAlgebra
include("prl_101_237004_vca_geometry.jl")
const Geometry=PRL101237004VCAGeometry

export ReferenceSystem, LatticeEmbedding, imaginary_quadrature, evaluate_functional,
       noninteracting_reference, free_lattice_observables

"""Canonical reference energy and its zero-temperature Green function.
`green(z,spin)` returns (G,dG/dz), with canonical energy argument z and
spin=1,2. The evaluator supplies z=μ′+iω. The callback must be read-only
and safe for concurrent calls. μ′ must stay on the declared charge branch.
"""
struct ReferenceSystem{F}
    energy::Float64
    particles::Int
    nsites::Int
    kinetics::NTuple{2,Matrix{Float64}}
    green::F
    mu_interval::Tuple{Float64,Float64}
end

function ReferenceSystem(energy,particles,Kup,Kdown,green;mu_interval=(-Inf,Inf))
    n=size(Kup,1)
    n>0 && iseven(n) && size(Kup)==size(Kdown)==(n,n) || throw(ArgumentError("require two equal square matrices, two orbitals per Fe"))
    all(isfinite,Kup) && all(isfinite,Kdown) && issymmetric(Kup) && issymmetric(Kdown) || throw(ArgumentError("reference one-body matrices must be finite, real symmetric"))
    0<=particles<=2n && isinteger(particles) && isfinite(energy) || throw(ArgumentError("invalid canonical energy or particle count"))
    lo,hi=Float64.(mu_interval)
    lo<hi || throw(ArgumentError("empty reference chemical-potential interval"))
    isfinite(lo) && isfinite(hi) && hi-lo<=128eps(Float64)*max(1,abs(lo),abs(hi)) &&
        throw(ArgumentError("reference charge interval is indistinguishable from a degeneracy at Float64 precision"))
    ReferenceSystem(Float64(energy),Int(particles),n÷2,(Matrix{Float64}(Kup),Matrix{Float64}(Kdown)),green,(lo,hi))
end

struct LatticeEmbedding
    hoppings::Vector{Matrix{ComplexF64}}
    nsites::Int
    moment_pattern::Vector{Float64}
end

function LatticeEmbedding(hoppings::AbstractVector,nsites::Integer;moment_pattern=zeros(2nsites))
    !isempty(hoppings) && nsites>0 || throw(ArgumentError("empty lattice embedding"))
    n=2nsites
    all(size(K)==(n,n) && all(isfinite,K) && isapprox(K,K';atol=3e-12,rtol=3e-12) for K in hoppings) || throw(ArgumentError("embedding matrices must be Hermitian and match the cluster"))
    length(moment_pattern)==n && all(isfinite,moment_pattern) || throw(ArgumentError("invalid moment pattern"))
    LatticeEmbedding(Matrix{ComplexF64}.(hoppings),Int(nsites),Float64.(moment_pattern))
end

function LatticeEmbedding(c::Geometry.ReferenceCluster;physical_L=48,p=Geometry.Model.slater_koster_parameters(-0.2),channel=:stripe_y)
    points=Geometry.reduced_momentum_grid(c,physical_L)
    pattern=Geometry.weiss_kinetics(c,0.0;channel,p).pattern
    LatticeEmbedding([Geometry.lattice_kinetic(c,q...,p) for q in points],length(c.sites);moment_pattern=pattern)
end

function _gauss_legendre(order)
    order>=2 || throw(ArgumentError("quadrature order must be at least two"))
    beta=[j/sqrt(4j*j-1) for j in 1:order-1]
    eig=eigen(SymTridiagonal(zeros(order),beta))
    (;nodes=(eig.values.+1)./2,weights=abs2.(eig.vectors[1,:]))
end

"""Piecewise Gauss-Legendre integration on the positive imaginary axis.
The last interval uses ω=b+b*x/(1−x) to reach infinity. Refinement doubles
the order in every interval; no finite temperature or real-frequency
broadening is introduced. Low-frequency intervals resolve metallic poles.
"""
function imaginary_quadrature(order::Integer=24;breaks=(0.0,0.00001,0.001,0.01,0.1,1.0,10.0,100.0))
    all(isfinite,breaks) && first(breaks)==0 && all(diff(collect(breaks)).>0) || throw(ArgumentError("breaks must increase from zero"))
    q=_gauss_legendre(order)
    nodes,weights=Float64[],Float64[]
    for (a,b) in zip(breaks[1:end-1],breaks[2:end])
        append!(nodes,a.+(b-a).*q.nodes)
        append!(weights,(b-a).*q.weights)
    end
    b=last(breaks)
    append!(nodes,b.+b.*q.nodes./(1 .-q.nodes))
    append!(weights,b.*q.weights./(1 .-q.nodes).^2)
    (;nodes,weights,order=Int(order),breaks=Float64.(collect(breaks)))
end

"""Zero-T self-energy functional, per Fe, at independent physical μ and
reference μ′. V=t(k)−t′+(μ′−μ)I, M=I−V G′, G=G′M⁻¹.

Ω=Ω′/Nc + <Tr V>/(2Nc) − ∫₀∞ <log|det M|>dω/(πNc).
Both spin blocks are included. The trace correction is necessary, especially
when μ′ differs from μ. Returned density is −∂Ω/∂μ at fixed variational
parameters; `mu_prime_gradient` is the independent partial derivative.
The signed moment uses g=2 and the declared site pattern, in μB per Fe.
"""
function evaluate_functional(ref::ReferenceSystem,lattice::LatticeEmbedding,mu::Real,mu_prime::Real;
                             quadrature=imaginary_quadrature(),threaded::Bool=true)
    all(isfinite,(mu,mu_prime)) || throw(ArgumentError("chemical potentials must be finite"))
    ref.nsites==lattice.nsites || throw(DimensionMismatch("reference and embedding differ"))
    ref.mu_interval[1]<mu_prime<ref.mu_interval[2] || throw(ArgumentError("μ′ lies outside the reference charge branch"))
    n=2ref.nsites
    nk=length(lattice.hoppings)
    nw=length(quadrature.nodes)
    nw==length(quadrature.weights) && all(>(0),quadrature.nodes) && all(>(0),quadrature.weights) || throw(ArgumentError("invalid positive-axis quadrature"))
    potentials=([K-ref.kinetics[s]+(mu_prime-mu)*I for K in lattice.hoppings] for s in 1:2) |> Tuple
    traceV=sum(real(tr(V)) for block in potentials for V in block)/nk
    logs=zeros(nw); densities=zeros(nw); gradients=zeros(nw); moments=zeros(nw)
    function frequency(index)
        logsum,densitysum,gradsum,momentsum=0.0,0.0,0.0,0.0
        M=Matrix{ComplexF64}(undef,n,n)
        B=similar(M)
        for spin in 1:2
            G,Gdot=ref.green(complex(mu_prime,quadrature.nodes[index]),spin)
            size(G)==size(Gdot)==(n,n) || error("wrong reference Green-function dimensions")
            all(isfinite,G) && all(isfinite,Gdot) || error("nonfinite reference Green function")
            for V in potentials[spin]
                mul!(M,V,G)
                M .*= -1
                for i in 1:n
                    M[i,i]+=1
                end
                factor=lu!(M;check=false)
                issuccess(factor) || error("singular embedding resolvent at positive imaginary frequency")
                logsum+=first(logabsdet(factor))
                # Solve into an identity buffer. LAPACK inv! allocates a much
                # larger work array at every small k/frequency point.
                fill!(B,0)
                for i in 1:n
                    B[i,i]=1
                end
                ldiv!(factor,B) # B=M⁻¹. The LU buffer can now be reused.
                mul!(M,V,Gdot)
                M .+= G
                for i in 1:n
                    occupied=0.0+0.0im
                    for j in 1:n
                        occupied+=G[i,j]*B[j,i]
                        gradsum-=real(B[i,j]*M[j,i])
                    end
                    densitysum+=real(occupied)
                    momentsum+=(spin==1 ? 1 : -1)*lattice.moment_pattern[i]*real(occupied)
                end
            end
        end
        logs[index]=logsum/nk
        densities[index]=densitysum/nk
        gradients[index]=gradsum/nk
        moments[index]=momentsum/nk
        nothing
    end
    if threaded && Threads.nthreads()>1
        Threads.@threads :static for index in 1:nw
            frequency(index)
        end
    else
        for index in 1:nw
            frequency(index)
        end
    end
    integral=dot(quadrature.weights,logs)
    scale=inv(pi*ref.nsites)
    omega_reference=(ref.energy-mu_prime*ref.particles)/ref.nsites
    trace_correction=traceV/(2ref.nsites)
    omega=omega_reference+trace_correction-scale*integral
    density=n/ref.nsites+scale*dot(quadrature.weights,densities)
    mu_prime_gradient=(-ref.particles+n)/ref.nsites-scale*dot(quadrature.weights,gradients)
    moment=scale*dot(quadrature.weights,moments)
    all(isfinite,(omega,density,mu_prime_gradient,moment)) || error("nonfinite functional result")
    (;omega,density,mu_prime_gradient,moment,moment_abs=abs(moment),omega_reference,
      trace_correction,trace_log_integral=integral,mu=Float64(mu),mu_prime=Float64(mu_prime),
      quadrature_order=quadrature.order,frequency_points=nw,k_points=nk)
end

"""Exact one-body reference for functional cancellation tests."""
function noninteracting_reference(Kup,Kdown,Nup,Ndown)
    eigenvalues=(eigvals(Symmetric(Kup)),eigvals(Symmetric(Kdown)))
    n=size(Kup,1)
    0<=Nup<=n && 0<=Ndown<=n || throw(ArgumentError("invalid occupations"))
    populations=(Nup,Ndown)
    E=sum(sum(eigenvalues[s][1:populations[s]]) for s in 1:2)
    lo=maximum(populations[s]==0 ? -Inf : eigenvalues[s][populations[s]] for s in 1:2)
    hi=minimum(populations[s]==n ? Inf : eigenvalues[s][populations[s]+1] for s in 1:2)
    kinetics=(Matrix(Kup),Matrix(Kdown))
    function green(z,spin)
        G=inv(z*I-kinetics[spin])
        G,-G*G
    end
    ReferenceSystem(E,Nup+Ndown,Kup,Kdown,green;mu_interval=(lo,hi))
end

function free_lattice_observables(lattice::LatticeEmbedding,mu)
    energies=[eigvals(Hermitian(K)) for K in lattice.hoppings]
    omega=2sum(sum(min(e-mu,0.0) for e in band) for band in energies)/(lattice.nsites*length(energies))
    density=2sum(count(<(mu),band) for band in energies)/(lattice.nsites*length(energies))
    (;omega,density)
end

end
