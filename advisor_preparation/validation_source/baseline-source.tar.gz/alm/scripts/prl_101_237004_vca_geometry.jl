module PRL101237004VCAGeometry

using LinearAlgebra
include("prl_101_237004_model.jl")
const Model = PRL101237004Model

export ReferenceCluster, rectangular_cluster, open_kinetic, lattice_kinetic,
       weiss_kinetics, reduced_momentum_grid, folded_band_energies

"""Rectangular open reference cluster; x varies fastest, then y, with
orbital order (xz,yz) at each site. Supercell Bloch phases refer to cell
translations only. This gauge is shared by the cluster Green function and
lattice embedding; no momentum periodization enters the trace functional.
"""
struct ReferenceCluster
    Lx::Int
    Ly::Int
    sites::Vector{NTuple{2,Int}}
end

function rectangular_cluster(Lx::Integer=2,Ly::Integer=2)
    Lx>0 && Ly>0 && big(Lx)*Ly<=8 || throw(ArgumentError("require 1 to 8 Fe sites"))
    ReferenceCluster(Int(Lx),Int(Ly),[(x,y) for y in 0:Ly-1 for x in 0:Lx-1])
end

function bonds(p)
    ((1,0,[-p.t1 0.0;0.0 -p.t2]),
     (0,1,[-p.t2 0.0;0.0 -p.t1]),
     (1,1,[-p.t3 -p.t4;-p.t4 -p.t3]),
     (1,-1,[-p.t3 p.t4;p.t4 -p.t3]))
end

function open_kinetic(c::ReferenceCluster,p=Model.slater_koster_parameters(-0.2))
    K=zeros(Float64,2length(c.sites),2length(c.sites))
    for (i,(x,y)) in enumerate(c.sites), (dx,dy,T) in bonds(p)
        tx,ty=x+dx,y+dy
        0<=tx<c.Lx && 0<=ty<c.Ly || continue
        j=1+tx+c.Lx*ty
        for a in 1:2,b in 1:2
            K[2i-2+a,2j-2+b]+=T[a,b]
            K[2j-2+b,2i-2+a]+=T[a,b]
        end
    end
    K
end

"""Infinite-lattice hopping in the reference-supercell Bloch gauge.
Directed periodic images are added, including coincident small-cell bonds.
"""
function lattice_kinetic(c::ReferenceCluster,kx::Real,ky::Real,
                         p=Model.slater_koster_parameters(-0.2))
    all(isfinite,(kx,ky)) || throw(ArgumentError("momenta must be finite"))
    K=zeros(ComplexF64,2length(c.sites),2length(c.sites))
    for (i,(x,y)) in enumerate(c.sites), (dx,dy,T) in bonds(p)
        tx,ty=x+dx,y+dy
        cx,cy=mod(tx,c.Lx),mod(ty,c.Ly)
        j=1+cx+c.Lx*cy
        phase=cis(kx*(tx-cx)+ky*(ty-cy))
        for a in 1:2,b in 1:2
            value=T[a,b]*phase
            K[2i-2+a,2j-2+b]+=value
            K[2j-2+b,2i-2+a]+=conj(value)
        end
    end
    K
end

"""Dahnken convention: H′_h=+h Σ_i p_i(n_i↑−n_i↓), summed
over both orbitals, without a factor 1/2. The physical lattice has no
Weiss field. :stripe_y means q=(0,π), :stripe_x means q=(π,0).
"""
function weiss_kinetics(c::ReferenceCluster,h::Real;
                        channel::Symbol=:stripe_y,p=Model.slater_koster_parameters(-0.2))
    isfinite(h) || throw(ArgumentError("field must be finite"))
    channel in (:stripe_y,:stripe_x,:neel,:ferro) || throw(ArgumentError("unknown magnetic channel"))
    channel in (:stripe_x,:neel) && isodd(c.Lx) && throw(ArgumentError("x-staggered field needs an even Lx"))
    channel in (:stripe_y,:neel) && isodd(c.Ly) && throw(ArgumentError("y-staggered field needs an even Ly"))
    pattern=Float64[channel==:ferro ? 1 :
        iseven(channel==:stripe_y ? y : channel==:stripe_x ? x : x+y) ? 1 : -1
        for (x,y) in c.sites]
    orbital_pattern=repeat(pattern;inner=2)
    K=open_kinetic(c,p)
    (;up=K+Diagonal(h.*orbital_pattern),down=K-Diagonal(h.*orbital_pattern),pattern=orbital_pattern)
end

"""A physical L×L momentum mesh becomes (L/Lx)×(L/Ly) reduced-BZ
points. The PRL's L=48 is an embedding mesh, not the ED cluster size.
"""
function reduced_momentum_grid(c::ReferenceCluster,L::Integer=48)
    L>0 && L%c.Lx==0 && L%c.Ly==0 || throw(ArgumentError("L must be a positive multiple of both cell lengths"))
    nx,ny=L÷c.Lx,L÷c.Ly
    [(2pi*(ix-fld(nx,2))/L,2pi*(iy-fld(ny,2))/L) for iy in 0:ny-1 for ix in 0:nx-1]
end

function folded_band_energies(c::ReferenceCluster,kx,ky,p=Model.slater_koster_parameters(-0.2))
    energies=Float64[]
    for ix in 0:c.Lx-1,iy in 0:c.Ly-1
        # Literal Eq. (1), including +4t4 sin(kx)sin(ky).
        x,y=kx+2pi*ix/c.Lx,ky+2pi*iy/c.Ly
        a=-2p.t1*cos(x)-2p.t2*cos(y)-4p.t3*cos(x)*cos(y)
        d=-2p.t2*cos(x)-2p.t1*cos(y)-4p.t3*cos(x)*cos(y)
        b=4p.t4*sin(x)*sin(y)
        append!(energies,eigvals(Symmetric([a b;b d])))
    end
    sort!(energies)
end

end
