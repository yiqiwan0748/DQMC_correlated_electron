module PRL101237004VCAReferenceAudit

using LinearAlgebra
using SHA
using TOML
using Dates
include("prl_101_237004_cluster_green.jl")
const C = PRL101237004ClusterGreen

export audit_reference_ground, reference_stability, write_reference_audit

"""Compare the canonical reference state with every spin/particle sector.

All `(Nup,Ndown)` sectors are enumerated, for at most four Fe sites. Energies
exclude chemical potential. The all-N interval is sufficient for grand-ground
stability **conditional on the computed lowest sector eigenvalues** and absence
of a lower state at the target total N. Direct residuals test eigenpairs; a
small residual alone is not a rigorous certificate that a Ritz value is the
lowest eigenvalue. A different spin sector at the same N cannot be excluded
by a check of particle addition/removal energies alone.
"""
function audit_reference_ground(Kup::AbstractMatrix{<:Real},Kdown::AbstractMatrix{<:Real},
                                U::Real,Nup::Integer,Ndown::Integer;J::Real=U/4,
                                ground_atol::Real=1e-11,ground_krylovdim::Integer=64,
                                ground_keep::Integer=8,ground_max_matvecs::Integer=1000,
                                seed::Integer=7,max_bytes::Integer=512*1024^2,
                                comparison_atol::Real=1e-9,progress=nothing)
    nmodes=size(Kup,1)
    2<=nmodes<=8 && iseven(nmodes) || throw(ArgumentError("audit supports one to four Fe sites"))
    size(Kup)==size(Kdown)==(nmodes,nmodes) || throw(DimensionMismatch("spin kinetic matrix sizes differ"))
    0<=Nup<=nmodes && 0<=Ndown<=nmodes || throw(ArgumentError("target particle counts out of range"))
    isfinite(comparison_atol) && comparison_atol>=0 || throw(ArgumentError("comparison_atol must be finite and nonnegative"))
    rows=NamedTuple{(:Nup,:Ndown,:N,:dimension,:energy,:residual,:matvecs,:restarts,:seed),
                   Tuple{Int,Int,Int,Int,Float64,Float64,Int,Int,Int}}[]
    for nu in 0:nmodes,nd in 0:nmodes
        H=C.spin_hamiltonian(Kup,Kdown,U,nu,nd;J,max_dimension=100_000,max_bytes)
        sector_seed=Int(seed+nu*(nmodes+1)+nd)
        result=C.Lanczos.restarted_lowest(H;nev=1,krylovdim=ground_krylovdim,
            keep=ground_keep,max_matvecs=ground_max_matvecs,atol=ground_atol,
            rtol=0.0,seed=sector_seed,max_bytes)
        result.converged || error("sector ($nu,$nd) did not converge; residual=$(result.residuals[1])")
        row=(Nup=nu,Ndown=nd,N=nu+nd,dimension=size(H,1),energy=result.values[1],
            residual=result.residuals[1],matvecs=result.matvecs,restarts=result.restarts,seed=sector_seed)
        push!(rows,row)
        progress===nothing || progress(row)
    end
    target=only(filter(r->r.Nup==Nup && r.Ndown==Ndown,rows))
    minima=[reduce((a,b)->a.energy<=b.energy ? a : b,filter(r->r.N==n,rows)) for n in 0:2nmodes]
    lower_same_N=filter(r->r.N==target.N && r.energy<target.energy-comparison_atol,rows)
    lower_candidates=[(mu=(target.energy-r.energy)/(target.N-r.N),sector=r)
                      for r in minima if r.N<target.N]
    upper_candidates=[(mu=(r.energy-target.energy)/(r.N-target.N),sector=r)
                      for r in minima if r.N>target.N]
    lower=isempty(lower_candidates) ? nothing : reduce((a,b)->a.mu>=b.mu ? a : b,lower_candidates)
    upper=isempty(upper_candidates) ? nothing : reduce((a,b)->a.mu<=b.mu ? a : b,upper_candidates)
    interval=(lower===nothing ? -Inf : lower.mu,upper===nothing ? Inf : upper.mu)
    settings=(ground_atol=Float64(ground_atol),ground_krylovdim=Int(ground_krylovdim),
        ground_keep=Int(ground_keep),ground_max_matvecs=Int(ground_max_matvecs),
        seed=Int(seed),max_bytes=Int(max_bytes),comparison_atol=Float64(comparison_atol))
    return (;K_up=Matrix{Float64}(Kup),K_down=Matrix{Float64}(Kdown),U=Float64(U),J=Float64(J),
        nmodes,rows,minima,target,lower_same_N,mu_interval=interval,lower_constraint=lower,
        upper_constraint=upper,target_lowest_at_same_N=isempty(lower_same_N),
        has_stable_mu_interval=isempty(lower_same_N) && interval[1]<=interval[2]+comparison_atol,
        settings,scope=:all_spin_particle_sectors,
        qualification="Conditional on computed sector minima; direct residuals do not rigorously certify the lowest eigenvalue.")
end

"""Directly compare Ω′=E−μ′N against every computed sector at one μ′."""
function reference_stability(audit,mu_prime::Real;atol::Real=audit.settings.comparison_atol)
    isfinite(mu_prime) || throw(ArgumentError("chemical potential must be finite"))
    isfinite(atol) && atol>=0 || throw(ArgumentError("atol must be finite and nonnegative"))
    omega_target=audit.target.energy-mu_prime*audit.target.N
    differences=[(Nup=r.Nup,Ndown=r.Ndown,N=r.N,
        omega_difference=r.energy-mu_prime*r.N-omega_target) for r in audit.rows]
    lower_sectors=filter(r->r.omega_difference < -atol,differences)
    return (;mu_prime=Float64(mu_prime),omega_target,differences,lower_sectors,
        stable=isempty(lower_sectors),minimum_difference=minimum(r.omega_difference for r in differences))
end

"""Write compact CSVs and physical/source provenance; no eigenvectors are saved."""
function write_reference_audit(audit,directory::AbstractString;physical_metadata=Dict{String,Any}())
    mkpath(directory)
    open(joinpath(directory,"sectors.csv"),"w") do io
        println(io,"Nup,Ndown,N,dimension,energy_canonical,direct_residual,matvecs,restarts,seed")
        for r in audit.rows
            println(io,join((r.Nup,r.Ndown,r.N,r.dimension,r.energy,r.residual,r.matvecs,r.restarts,r.seed),','))
        end
    end
    open(joinpath(directory,"particle_minima.csv"),"w") do io
        println(io,"N,Nup,Ndown,energy_canonical,direct_residual,target_mu_constraint,bound_type")
        for r in audit.minima
            constraint=r.N==audit.target.N ? NaN : (r.energy-audit.target.energy)/(r.N-audit.target.N)
            bound_type=r.N<audit.target.N ? "lower" : r.N>audit.target.N ? "upper" : "same_N"
            println(io,join((r.N,r.Nup,r.Ndown,r.energy,r.residual,constraint,bound_type),','))
        end
    end
    for (name,K) in (("K_up.csv",audit.K_up),("K_down.csv",audit.K_down))
        open(joinpath(directory,name),"w") do io
            for row in eachrow(K)
                println(io,join(row,','))
            end
        end
    end
    root=normpath(joinpath(@__DIR__,".."))
    paths=["scripts/prl_101_237004_vca_reference_audit.jl","scripts/prl_101_237004_cluster_green.jl",
           "scripts/prl_101_237004_ed.jl","scripts/prl_101_237004_restarted_lanczos.jl",
           "scripts/prl_101_237004_vca_geometry.jl","scripts/prl_101_237004_model.jl","src/noninteracting.jl"]
    hashes=Dict(path=>bytes2hex(sha256(read(joinpath(root,path)))) for path in paths)
    constraint_dict(c)=c===nothing ? Dict("bounded"=>false) :
        Dict("bounded"=>true,"mu"=>c.mu,"N"=>c.sector.N,"Nup"=>c.sector.Nup,"Ndown"=>c.sector.Ndown)
    metadata=Dict{String,Any}(
        "created_utc"=>string(now(UTC)),"julia_version"=>string(VERSION),
        "scope"=>String(audit.scope),"qualification"=>audit.qualification,
        "U"=>audit.U,"J"=>audit.J,"nmodes_per_spin"=>audit.nmodes,
        "sector_count"=>length(audit.rows),"summed_dimensions"=>sum(r.dimension for r in audit.rows),
        "target_Nup"=>audit.target.Nup,"target_Ndown"=>audit.target.Ndown,
        "target_energy_canonical"=>audit.target.energy,"target_residual"=>audit.target.residual,
        "target_lowest_at_same_N"=>audit.target_lowest_at_same_N,
        "same_N_lower_sector_count"=>length(audit.lower_same_N),
        "mu_lower"=>audit.mu_interval[1],"mu_upper"=>audit.mu_interval[2],
        "has_stable_mu_interval"=>audit.has_stable_mu_interval,
        "lower_constraint"=>constraint_dict(audit.lower_constraint),
        "upper_constraint"=>constraint_dict(audit.upper_constraint),
        "maximum_direct_residual"=>maximum(r.residual for r in audit.rows),
        "total_matvecs"=>sum(r.matvecs for r in audit.rows),
        "settings"=>Dict(string(k)=>v for (k,v) in pairs(audit.settings)),
        "physical_metadata"=>physical_metadata,"source_sha256"=>hashes)
    open(joinpath(directory,"metadata.toml"),"w") do io
        TOML.print(io,metadata;sorted=true)
    end
    return metadata
end

end # module

if abspath(PROGRAM_FILE)==@__FILE__
    using .PRL101237004VCAReferenceAudit
    include("prl_101_237004_vca_geometry.jl")
    const ReferenceAuditGeometry=PRL101237004VCAGeometry
    length(ARGS)<=1 || error("usage: julia --project=. scripts/prl_101_237004_vca_reference_audit.jl [output_directory]")
    output=isempty(ARGS) ? joinpath(@__DIR__,"..","results","prl_101_237004","milestone4","pilot_reference_audit") : ARGS[1]
    cluster=ReferenceAuditGeometry.rectangular_cluster(2,2)
    hopping=ReferenceAuditGeometry.Model.slater_koster_parameters(-0.2)
    kinetics=ReferenceAuditGeometry.weiss_kinetics(cluster,0.045;channel=:stripe_y,p=hopping)
    elapsed=@elapsed result=audit_reference_ground(kinetics.up,kinetics.down,1.0,4,4;J=0.25)
    metadata=Dict{String,Any}("cluster"=>"open 2x2 Fe", "sites"=>[collect(r) for r in cluster.sites],
        "weiss_h"=>0.045,"weiss_channel"=>"stripe_y, q=(0,pi)",
        "weiss_convention"=>"+h sum_i p_i (n_up-n_down), both orbitals, no factor 1/2",
        "hopping_ratio_pdpi_pdsigma"=>-0.2,"original_PRL_t4"=>true,
        "hoppings"=>Dict(string(k)=>getproperty(hopping,k) for k in (:t1,:t2,:t3,:t4)),
        "wall_seconds_including_compilation"=>elapsed)
    write_reference_audit(result,output;physical_metadata=metadata)
    println("target E0 = ",result.target.energy,"; residual = ",result.target.residual)
    println("same-N stable = ",result.target_lowest_at_same_N,"; all-N mu interval = ",result.mu_interval)
    println("sectors = ",length(result.rows),"; summed dimensions = ",sum(r.dimension for r in result.rows))
    println("maximum residual = ",maximum(r.residual for r in result.rows),"; elapsed seconds = ",elapsed)
    println("saved ",abspath(output))
end
