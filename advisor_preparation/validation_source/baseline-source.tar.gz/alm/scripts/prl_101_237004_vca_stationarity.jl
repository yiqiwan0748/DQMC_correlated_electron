module PRL101237004VCAStationarity

export stationary_reference_mu

function _checked_evaluation(evaluate, x, cache)
    haskey(cache, x) && return cache[x]
    data = evaluate(x)
    data isa NamedTuple || throw(ArgumentError("evaluate must return a NamedTuple"))
    for name in (:mu_prime_gradient, :omega, :density, :mu_prime)
        hasproperty(data, name) || throw(ArgumentError("evaluation is missing $name"))
        value = getproperty(data, name)
        value isa Real && isfinite(value) || throw(ArgumentError(
            "evaluation field $name must be finite and real"))
    end
    data.mu_prime == x || throw(ArgumentError("evaluation mu_prime differs from its input"))
    cache[x] = data
    return data
end

function _candidate(x, data, bracket, iterations, status, converged)
    (; mu_prime=x, data, gradient=Float64(data.mu_prime_gradient),
       bracket, iterations, status, converged)
end

function _refine_bracket(evaluate, cache, left, right, gradient_atol,
                         x_atol, max_iterations)
    a, b = left, right
    fa = Float64(cache[a].mu_prime_gradient)
    fb = Float64(cache[b].mu_prime_gradient)
    status = :max_iterations
    completed = 0
    for iteration in 1:max_iterations
        if b - a <= x_atol
            status = :bracket_tolerance_only
            break
        end
        width = b - a
        # Scaled opposite-sign interpolation avoids fa*fb and fa+fb overflow.
        magnitude = max(abs(fa), abs(fb))
        weight_a, weight_b = abs(fa) / magnitude, abs(fb) / magnitude
        fraction = weight_a / (weight_a + weight_b)
        x = a + width * fraction
        # A regular bisection step prevents false-position stagnation. Other
        # steps are kept away from endpoints to guarantee interval contraction.
        if iteration % 3 == 0 || !(a + 0.1width < x < b - 0.1width)
            x = a + width / 2
        end
        if !(a < x < b)
            status = :resolution_limit
            break
        end
        data = _checked_evaluation(evaluate, x, cache)
        fx = Float64(data.mu_prime_gradient)
        completed = iteration
        if abs(fx) <= gradient_atol
            return _candidate(x, data, (a, b), completed, :converged, true)
        end
        if signbit(fx) == signbit(fa)
            a, fa = x, fx
        else
            b, fb = x, fx
        end
    end
    x = abs(fa) <= abs(fb) ? a : b
    return _candidate(x, cache[x], (a, b), completed, status, false)
end

"""
    stationary_reference_mu(evaluate, interval; initial=nothing,
        scan_points=9, gradient_atol=1e-6, x_atol=1e-6,
        max_iterations=32, edge_fraction=0.03)

Find all *detected* stationary reference chemical potentials on a finite open
charge interval. The callback returns a NamedTuple containing finite real
`mu_prime_gradient`, `omega`, `density`, and `mu_prime` (equal to its input).
The canonical reference/Green function should be constructed once outside the
callback: changing mu_prime within this charge branch does not require new ED.

A full uniform scan is always performed. A finite `initial` adds a continuation
sample, clamped inside the search interval. Every sign-change bracket is refined
by safeguarded secant/bisection, using at most `max_iterations` extra callback
evaluations per bracket. Cached points are never reevaluated. The total bound is
`scan_points + (initial !== nothing) + bracket_count*max_iterations`.

Returns `roots` (gradient-certified candidates only), `attempts` (including
failed brackets), `status`, `evaluations`, `evaluation_cache`, `sample_points`,
`sample_gradients`, `interval`, `search_interval`, `initial_used`, and
`representative` (only for an entirely flat sampled branch). Root records have
`mu_prime`, callback `data`, `gradient`, `bracket`, `iterations`, `status`, and
`converged`. Top-level statuses are `:converged`, `:partial`, `:nonconverged`,
`:flat`, and `:no_root`. Multiple adjacent near-zero samples produce one
`:flat_interval` candidate, rather than claiming several distinct isolated roots.

An x-small bracket without a gradient-small evaluation is NOT a converged root.
Endpoints with nonzero gradients are never promoted by minimizing omega. A flat
branch has no uniquely selected root; `representative` records a usable sampled
point while `roots` is empty. `:no_root` means no root was detected by this scan,
not a proof that one does not exist: narrow or even-multiplicity roots can be
missed unless a sample has a sufficiently small gradient. Refine the scan near
suspected tangent roots. The caller must independently repeat final evaluations
with tighter frequency quadrature; this routine certifies callback values only.
"""
function stationary_reference_mu(evaluate, interval; initial=nothing,
        scan_points::Integer=9, gradient_atol::Real=1e-6, x_atol::Real=1e-6,
        max_iterations::Integer=32, edge_fraction::Real=0.03)
    length(interval) == 2 || throw(ArgumentError("interval needs two bounds"))
    lo, hi = Float64.(interval)
    all(isfinite, (lo, hi)) && lo < hi && isfinite(hi - lo) || throw(ArgumentError(
        "charge interval must have finite, ordered bounds and finite width"))
    scan_points >= 2 || throw(ArgumentError("scan_points must be at least two"))
    isfinite(gradient_atol) && gradient_atol > 0 || throw(ArgumentError(
        "gradient_atol must be finite and positive"))
    isfinite(x_atol) && x_atol > 0 || throw(ArgumentError("x_atol must be finite and positive"))
    max_iterations >= 0 || throw(ArgumentError("max_iterations must be nonnegative"))
    isfinite(edge_fraction) && 0 <= edge_fraction < 0.5 || throw(ArgumentError(
        "edge_fraction must lie in [0, 0.5)"))
    initial === nothing || (initial isa Real && isfinite(initial)) || throw(ArgumentError(
        "initial must be nothing or a finite real value"))
    a = max(nextfloat(lo), lo + edge_fraction * (hi - lo))
    b = min(prevfloat(hi), hi - edge_fraction * (hi - lo))
    a < b || throw(ArgumentError("charge interval has no resolvable search interior"))
    points = collect(range(a, b; length=Int(scan_points)))
    initial_used = initial === nothing ? nothing : clamp(Float64(initial), a, b)
    initial_used === nothing || push!(points, initial_used)
    sort!(unique!(points))
    cache = Dict{Float64,Any}()
    gradients = Float64[]
    for x in points
        data = _checked_evaluation(evaluate, x, cache)
        push!(gradients, Float64(data.mu_prime_gradient))
    end
    near_zero = abs.(gradients) .<= gradient_atol
    attempts = NamedTuple[]
    representative = nothing
    if all(near_zero)
        x = initial_used === nothing ? points[cld(length(points), 2)] : initial_used
        representative = _candidate(x, cache[x], (a, b), 0, :flat, true)
        return (; roots=NamedTuple[], attempts, status=:flat,
            evaluations=length(cache), evaluation_cache=cache, sample_points=points,
            sample_gradients=gradients, interval=(lo, hi), search_interval=(a, b),
            initial_used, representative)
    end

    # Samples already satisfy the derivative criterion. Adjacent such samples
    # cannot establish distinct roots, so describe the whole detected interval.
    j = 1
    while j <= length(points)
        if !near_zero[j]
            j += 1
            continue
        end
        first = j
        while j < length(points) && near_zero[j + 1]
            j += 1
        end
        last = j
        chosen = if initial_used === nothing
            first - 1 + argmin(abs.(@view gradients[first:last]))
        else
            first - 1 + argmin(abs.(@view(points[first:last]) .- initial_used))
        end
        x = points[chosen]
        status = first == last ? :sampled_zero : :flat_interval
        push!(attempts, _candidate(x, cache[x], (points[first], points[last]),
                                  0, status, true))
        j += 1
    end
    for j in 1:length(points)-1
        (near_zero[j] || near_zero[j + 1]) && continue
        signbit(gradients[j]) == signbit(gradients[j + 1]) && continue
        push!(attempts, _refine_bracket(evaluate, cache, points[j], points[j + 1],
            gradient_atol, x_atol, Int(max_iterations)))
    end
    sort!(attempts; by=x -> x.mu_prime)
    roots = filter(x -> x.converged, attempts)
    failed = any(x -> !x.converged, attempts)
    status = isempty(attempts) ? :no_root : isempty(roots) ? :nonconverged :
             failed ? :partial : :converged
    return (; roots, attempts, status, evaluations=length(cache), evaluation_cache=cache,
        sample_points=points, sample_gradients=gradients, interval=(lo, hi),
        search_interval=(a, b), initial_used, representative)
end

end
