#!/usr/bin/env julia

module Arxiv09013544Milestone1

using LinearAlgebra
using Printf
using SHA
using Dates
using Sockets
include("arxiv_0901_3544_noninteracting.jl")
using .Arxiv09013544Noninteracting
const N = Arxiv09013544Noninteracting
const ROOT = normpath(joinpath(@__DIR__, ".."))
const PDF_REL = "results/arxiv_0901_3544/source/0901.3544v1.pdf"
const PDF_SHA = "7489fea3180cc63ebff703ef96c05a0b1c417eba336de9a13ff173b20d1e8441"
const DEFAULT_OUTPUT = joinpath(ROOT, "results", "arxiv_0901_3544", "milestone1")

function options(arguments)
    output, plots = DEFAULT_OUTPUT, true
    for argument in arguments
        if startswith(argument, "--output-dir=")
            output = abspath(split(argument, '='; limit=2)[2])
        elseif argument == "--no-plots"
            plots = false
        else
            throw(ArgumentError("supported options: --output-dir=PATH, --no-plots"))
        end
    end
    ispath(output) && (!isdir(output) || !isempty(readdir(output))) &&
        error("output must be a new or empty directory: $output")
    return (; output, plots)
end

function write_csv(path, header, rows)
    open(path, "w") do io
        println(io, join(header, ','))
        for row in rows
            println(io, join(row, ','))
        end
    end
end

function numerical_data()
    grids = (200, 400, 800, 1600)
    datasets, sensitivities, fillings, areas, gates = NamedTuple[], NamedTuple[], Tuple[], Tuple[], NamedTuple[]
    gate(name, figure, observed, tolerance) = push!(gates,
        (; name, figure, observed, tolerance, passed=isfinite(observed) && observed <= tolerance))
    for spec in figure_specs()
        println("$(Dates.now(Dates.UTC)) computing Figure $(spec.figure): $(spec.name)")
        flush(stdout)
        p = spec.hoppings
        reference_mu = isnothing(spec.printed_mu) ? 1.54 : spec.printed_mu
        audits = [filling_audit(p, grid, reference_mu) for grid in grids]
        half_mu = audits[end].mu_half
        mu = isnothing(spec.printed_mu) ? half_mu : spec.printed_mu
        for audit in audits
            push!(fillings, (spec.figure, audit.Nk, reference_mu, audit.mu_half, audit.mu_lower,
                audit.mu_upper, audit.density_at_reference, audit.lower_density_at_reference,
                audit.upper_density_at_reference, audit.density_below_half_mu,
                audit.density_through_half_mu))
        end
        # Quantile degeneracy is an occupancy interval, not a claim that all
        # exactly degenerate finite-grid levels can be filled to n=2 uniquely.
        gate("half_filling_quantile_brackets_n2", spec.figure,
            all(a.density_below_half_mu <= 2 <= a.density_through_half_mu for a in audits) ? 0.0 : 1.0, 0.0)
        # A discretization tolerance, much looser than the eigensolver tolerance.
        gate("mu_grid_change_800_to_1600_eV", spec.figure,
            abs(audits[end].mu_half - audits[end - 1].mu_half), 1e-3)
        convention = convention_audit(p)
        gate("independent_Fourier_matrix_error_eV", spec.figure, convention.matrix_error, 1e-12)
        gate("independent_band_eigensolver_error_eV", spec.figure, convention.eigenvalue_error, 1e-11)
        contours = fermi_contours(p, mu)
        coarse = fermi_contours(p, mu; angles=720)
        fine_density, coarse_density = contour_band_densities(contours), contour_band_densities(coarse)
        counted = filling_audit(p, 1600, mu)
        density_error = maximum(abs.((fine_density.lower - counted.lower_density_at_reference,
            fine_density.upper - counted.upper_density_at_reference)))
        angular_error = maximum(abs.(Tuple(fine_density) .- Tuple(coarse_density)))
        # Bandwise checking prevents errors in electron and hole areas cancelling.
        gate("max_band_area_vs_grid_density", spec.figure, density_error, 3e-4)
        gate("max_band_area_change_720_to_1440", spec.figure, angular_error, 4e-5)
        root_error = maximum(maximum(c.residual) for c in contours)
        eigensolver_root_error = maximum(abs(eigvals(Symmetric(
            fourier_bond_hamiltonian(c.kx[i], c.ky[i], p)))[c.pocket.band] - mu)
            for c in contours for i in eachindex(c.theta))
        gate("fermi_root_residual_eV", spec.figure, root_error, 1e-11)
        gate("independent_Fourier_fermi_root_residual_eV", spec.figure, eigensolver_root_error, 1e-11)
        gate("four_pockets_present", spec.figure, abs(length(contours) - 4), 0)
        push!(areas, (spec.figure, mu, half_mu, sum(fine_density), counted.density_at_reference,
            fine_density.lower, counted.lower_density_at_reference,
            fine_density.upper, counted.upper_density_at_reference, density_error, angular_error))
        path = band_path(p, mu)
        push!(datasets, merge(spec, (; mu, half_mu, contours, path,
            density=counted.density_at_reference)))
        if isnothing(spec.printed_mu)
            # The v1 caption has no mu. The alternative shifts are a declared
            # sensitivity envelope, not attributed to the authors or to Ref. 73.
            for delta in (-0.05, 0.05)
                alternative_mu = half_mu + delta
                push!(sensitivities, (figure=spec.figure, name="inferred_mu_$(delta < 0 ? "minus" : "plus")_0.05eV",
                    mu=alternative_mu, contours=fermi_contours(p, alternative_mu)))
            end
        else
            push!(sensitivities, (figure=spec.figure, name="n2_from_printed_hoppings",
                mu=half_mu, contours=fermi_contours(p, half_mu)))
        end
    end
    return (; datasets, sensitivities, fillings, areas, gates)
end

function save_data(output, data)
    write_csv(joinpath(output, "parameters.csv"),
        ("figure", "case", "t1_eV", "t2_eV", "t3_eV", "t4_eV", "mu_used_eV", "mu_source", "mu_half_calculated_eV", "density_per_Fe_at_mu_used"),
        ((d.figure, d.name, d.hoppings.t1, d.hoppings.t2, d.hoppings.t3, d.hoppings.t4,
            d.mu, isnothing(d.printed_mu) ? "inferred_n2" : "printed_caption", d.half_mu, d.density) for d in data.datasets))
    write_csv(joinpath(output, "filling_convergence.csv"),
        ("figure", "Nk", "reference_mu_eV", "mu_half_eV", "mu_quantile_lower_eV", "mu_quantile_upper_eV", "density_at_reference", "lower_band_density_at_reference", "upper_band_density_at_reference", "density_below_mu_half", "density_through_mu_half"), data.fillings)
    write_csv(joinpath(output, "pocket_area_validation.csv"),
        ("figure", "mu_used_eV", "mu_half_eV", "contour_density", "grid_density", "lower_contour_density", "lower_grid_density", "upper_contour_density", "upper_grid_density", "max_band_density_error", "angular_change_720_to_1440"), data.areas)
    write_csv(joinpath(output, "numerical_gates.csv"),
        ("gate", "figure", "observed", "tolerance", "passed"), (Tuple(g) for g in data.gates))
    write_csv(joinpath(output, "band_paths.csv"),
        ("figure", "sample", "path_equal_segment_coordinate", "path_arc_length_radians", "kx_radians", "ky_radians", "lower_E_eV", "upper_E_eV", "mu_eV", "lower_E_minus_mu_eV", "upper_E_minus_mu_eV"),
        ((d.figure, i, d.path.path_segment[i], d.path.coordinate[i], d.path.kx[i], d.path.ky[i],
            d.path.lower_energy[i], d.path.upper_energy[i], d.mu,
            d.path.lower_relative[i], d.path.upper_relative[i]) for d in data.datasets for i in eachindex(d.path.kx)))
    contour_rows = ((d.figure, d.name, d.mu, c.pocket.name, c.pocket.character, c.pocket.band,
        c.theta[i], c.kx[i], c.ky[i], mod(c.kx[i] + pi, 2pi) - pi,
        mod(c.ky[i] + pi, 2pi) - pi, c.residual[i])
        for d in Iterators.flatten((data.datasets, data.sensitivities)) for c in d.contours for i in eachindex(c.theta))
    write_csv(joinpath(output, "fermi_contours.csv"),
        ("figure", "case", "mu_eV", "pocket", "character", "band", "angle_radians", "kx_unwrapped", "ky_unwrapped", "kx_wrapped", "ky_wrapped", "abs_energy_residual_eV"), contour_rows)
    write_csv(joinpath(output, "high_symmetry.csv"),
        ("figure", "point", "kx", "ky", "h_xz_xz", "h_yz_yz", "h_xz_yz", "lower_E", "upper_E"),
        ((d.figure, name, kx, ky, bloch_hamiltonian(kx, ky, d.hoppings)[1, 1],
            bloch_hamiltonian(kx, ky, d.hoppings)[2, 2], bloch_hamiltonian(kx, ky, d.hoppings)[1, 2],
            band_energies(kx, ky, d.hoppings)...) for d in data.datasets
            for (name, kx, ky) in (("Gamma", 0.0, 0.0), ("X", pi, 0.0), ("Y", 0.0, pi), ("M", pi, pi))))
end

function draw_contours!(panel, contours; linestyle=:solid, color_override=nothing)
    for c in contours
        color = isnothing(color_override) ? (c.pocket.band == 1 ? "#bd2632" : "#242d3b") : color_override
        for dx in (-2pi, 0, 2pi), dy in (-2pi, 0, 2pi)
            x, y = (c.kx .+ dx) ./ pi, (c.ky .+ dy) ./ pi
            (maximum(x) < -1 || minimum(x) > 1 || maximum(y) < -1 || minimum(y) > 1) && continue
            plot!(panel, x, y; color, linestyle, linewidth=1.6, label=false)
        end
    end
    return panel
end

function contour_panel(title)
    plot(; title, xlims=(-1, 1), ylims=(-1, 1), aspect_ratio=:equal, framestyle=:box,
        xlabel="kₓ / π", ylabel="kᵧ / π", xticks=-1:0.5:1, yticks=-1:0.5:1,
        legend=false, grid=false, titlefontsize=10, guidefontsize=10, tickfontsize=8)
end

function render(output, data)
    panels, sensitive_panels = Any[], Any[]
    ylimits = ((-2., 2.), (-2., 1.), (-1.2, 0.8), (-8.5, 4.5))
    for (i, d) in enumerate(data.datasets)
        p = d.path
        bp = plot(p.path_segment, p.lower_energy; color="#bd2632", linewidth=1.7, label="lower band",
            xticks=([0, 1, 2, 3], ["Γ", "X", "M", "Γ"]), xlabel="momentum path", ylabel="E (eV)",
            title="Fig. $(d.figure)(a) · $(d.description)", titlefontsize=10,
            ylims=ylimits[i], xlims=(0, 3), framestyle=:box, legend=false, grid=false,
            guidefontsize=10, tickfontsize=8)
        plot!(bp, p.path_segment, p.upper_energy; color="#242d3b", linewidth=1.7, label="upper band")
        hline!(bp, [d.mu]; color="#777777", linestyle=:dash, linewidth=1, label="μ")
        mu_label = isnothing(d.printed_mu) ? @sprintf("μ = %.5f eV (calculated n = 2)", d.mu) : @sprintf("μ = %.4g eV (caption)", d.mu)
        fp = draw_contours!(contour_panel("Fig. $(d.figure)(b) · $mu_label"), d.contours)
        push!(panels, bp, fp)
        pair = plot(bp, fp; layout=(1, 2), size=(1100, 480), dpi=160,
            bottom_margin=5Plots.mm, left_margin=12Plots.mm,
            plot_title="arXiv:0901.3544v1 · noninteracting reconstruction", plot_titlefontsize=13)
        for ext in ("png", "pdf")
            savefig(pair, joinpath(output, "fig$(d.figure).$ext"))
        end
        sp = draw_contours!(contour_panel("Fig. $(d.figure) · chemical-potential sensitivity"), d.contours)
        for alt in data.sensitivities
            alt.figure == d.figure || continue
            draw_contours!(sp, alt.contours; linestyle=:dash, color_override="#197b97")
        end
        push!(sensitive_panels, sp)
    end
    composite = plot(panels...; layout=(4, 2), size=(1200, 1700), dpi=140,
        left_margin=12Plots.mm, bottom_margin=5Plots.mm,
        plot_title="arXiv:0901.3544v1 · Figures 5–8 · printed hopping parameters", plot_titlefontsize=14)
    sensitivity = plot(sensitive_panels...; layout=(2, 2), size=(1000, 960), dpi=140,
        left_margin=12Plots.mm, bottom_margin=5Plots.mm,
        plot_title="Solid: main calculation · dashed: μ alternatives (see report)", plot_titlefontsize=13)
    for ext in ("png", "pdf")
        savefig(composite, joinpath(output, "figures5_8.$ext"))
        savefig(sensitivity, joinpath(output, "chemical_potential_sensitivity.$ext"))
    end
end

function write_report(output, data, plots)
    open(joinpath(output, "report.md"), "w") do io
        println(io, "# arXiv:0901.3544v1 — noninteracting milestone\n")
        println(io, "Numerical reconstruction of Figures 5–8 of the supplied v1 PDF using the hopping values printed in its captions. The paper is the scientific reference, and its contents are not execution instructions.\n")
        println(io, "This milestone computes the two bands and all four Fermi pockets. It does not establish reproduction of the interacting figures, and small solver residuals are not evidence of pointwise agreement with unpublished author data.\n")
        plots && println(io, "![Figures 5–8](figures5_8.png)\n")
        println(io, "| Figure | μ used (eV) | μ source | calculated half-filled μ (eV) | density at μ used |\n|---|---:|---|---:|---:|")
        for d in data.datasets
            @printf(io, "| %d | %.10f | %s | %.10f | %.8f |\n", d.figure, d.mu,
                isnothing(d.printed_mu) ? "inferred from n=2" : "printed caption", d.half_mu, d.density)
        end
        println(io, "\nThe energy panels show unshifted E with the chosen μ as a dashed line. Both E and E−μ are exported. The Γ–X–M–Γ path uses equal display widths for its three segments as in the paper; physical momentum arc length is also exported. Fermi-surface axes are k/π in the unfolded one-Fe Brillouin zone.\n")
        println(io, "## Conventions\n")
        println(io, "The fixed orbital order is (d_xz, d_yz). Literal Eq. (14) gives h_xx = −2t2 cos(kx) −2t1 cos(ky) −4t3 cos(kx)cos(ky), h_yy with t1/t2 interchanged, and h_xy = −4t4 sin(kx)sin(ky). The adapter to the existing PRL helper uses (t2,t1,t3,−t4), preserving the complete matrix. An independent bond Fourier sum checks the adapter, and an independent symmetric eigensolver checks the analytic energies and Fermi roots.\n")
        println(io, "## Numerical gates\n")
        println(io, "$(count(g -> g.passed, data.gates)) / $(length(data.gates)) gates pass. Full observations and thresholds are in `numerical_gates.csv`. Matrix/eigensolver/root tolerances of 10⁻¹²–10⁻¹¹ eV allow Float64 roundoff at the largest hopping scale. These are far below the precision of the printed parameters. The 800→1600 momentum-grid μ change must be ≤0.001 eV; each band's contour-area density must agree with 1600² direct counting within 0.0003 electrons/Fe; its 720→1440 angular change must be ≤0.00004. These latter thresholds measure discretization.\n")
        println(io, "Spin degeneracy is two and half filling is n=2 electrons/Fe. The finite-grid quantile interval explicitly records degenerate levels around half filling. Neither a thermal broadening nor an exact integer occupancy of a split degenerate shell is assumed.\n")
        println(io, "## Comparison limits and sensitivity\n")
        println(io, "Figures 5–7 retain the caption's μ even when rounded hoppings produce a density offset. Their dashed sensitivity contours use the calculated half-filled μ. Figure 8 does not print μ; the main value is inferred from n=2 with the literal caption hoppings. Its dashed sensitivity contours use this inferred value ±0.05 eV, a declared sensitivity range rather than author-supplied values. The 1.54 eV reference in the Fig. 8 filling-convergence table is only a diagnostic reference, not a value attributed to this paper.\n")
        plots && println(io, "![Chemical-potential sensitivity](chemical_potential_sensitivity.png)\n")
        println(io, "The computed topology contains hole pockets at Γ/M and electron pockets at X/Y. The supplied PDF supports a visual comparison, but no digitized curve error is claimed by this runner. Quantitative reproduction against external reference coordinates remains unassessed; numerical validation and visual reconstruction are recorded separately. Figures 6 and 7 use printed hoppings directly; no undocumented direct-hopping overlaps or higher-precision parameters were inferred.\n")
        println(io, "## Re-run\n\n```bash\nOPENBLAS_NUM_THREADS=1 julia --threads=1 --project=. scripts/run_arxiv_0901_3544_milestone1.jl --output-dir=results/arxiv_0901_3544/milestone1_rerun\n```\n")
        println(io, "The destination must be new or empty. Add `--no-plots` for numerical output only. Numerical work is serial, with a largest individual filling spectrum of 2×1600² Float64 values (about 41 MB). Existing Plots is loaded only after numerical calculations. `metadata.txt` records host/process/source hashes, and `checksums.sha256` covers the outputs.\n")
    end
end

function main(arguments=ARGS)
    config = options(arguments)
    BLAS.set_num_threads(1)
    pdf = joinpath(ROOT, PDF_REL)
    isfile(pdf) || error("the archived reference PDF is required: $pdf")
    actual_pdf_sha = bytes2hex(sha256(read(pdf)))
    actual_pdf_sha == PDF_SHA || error("reference PDF checksum does not match supplied v1")
    mkpath(config.output)
    data = numerical_data()
    save_data(config.output, data)
    plots_rendered = false
    if config.plots
        println("Numerical calculations finished; rendering figures.")
        flush(stdout)
        ENV["GKSwstype"] = "100"
        @eval using Plots
        Base.invokelatest(render, config.output, data)
        plots_rendered = true
    end
    write_report(config.output, data, plots_rendered)
    open(joinpath(config.output, "metadata.txt"), "w") do io
        println(io, "paper=https://arxiv.org/abs/0901.3544v1\nreference_pdf_sha256=$PDF_SHA\nexecution_pdf_sha256=$actual_pdf_sha")
        println(io, "completed_utc=$(Dates.now(Dates.UTC))\nhostname=$(gethostname())\npid=$(getpid())\njulia_version=$(VERSION)\njulia_threads=$(Threads.nthreads())\nblas_threads=$(BLAS.get_num_threads())")
        println(io, "orbital_order=d_xz,d_yz\nenergy_unit=eV\nmomentum_unit=radians\nlattice_spacing=1\nU=0\nJ=0\nspin_degeneracy=2\nn_half_per_Fe=2")
        println(io, "plots_rendered=$plots_rendered\nnum_numerical_gates=$(length(data.gates))\nall_numerical_gates_pass=$(all(g -> g.passed, data.gates))")
        println(io, "numerical_validation=$(all(g -> g.passed, data.gates) ? "pass" : "fail")\nquantitative_reference_comparison=not_assessed\ninteracting_reproduction=not_started_by_this_milestone\nfig8_mu=inferred_n2")
        println(io, "main_parameters=literal_figure_captions\nprl_adapter=t1_to_t2_t2_to_t1_t4_to_minus_t4\nfermi_angular_intervals=1440\nmu_grids=200,400,800,1600")
        for relative in ("scripts/arxiv_0901_3544_noninteracting.jl", "scripts/run_arxiv_0901_3544_milestone1.jl",
            "scripts/run_prl_101_237004_fig1.jl", "scripts/prl_101_237004_model.jl", "src/noninteracting.jl")
            println(io, "source_sha256 $(bytes2hex(sha256(read(joinpath(ROOT, relative))))) $relative")
        end
    end
    open(joinpath(config.output, "checksums.sha256"), "w") do io
        for name in sort(readdir(config.output))
            name == "checksums.sha256" && continue
            println(io, "$(bytes2hex(sha256(read(joinpath(config.output, name)))))  $name")
        end
    end
    failed = filter(g -> !g.passed, data.gates)
    isempty(failed) || error("numerical gates failed; inspect $(config.output)/numerical_gates.csv: $(getproperty.(failed, :name))")
    println("Figures 5–8 milestone complete: $(config.output)")
    println("$(length(data.gates)) numerical gates passed. Quantitative external curve matching remains unassessed.")
    flush(stdout)
    return config.output
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    Arxiv09013544Milestone1.main()
end
