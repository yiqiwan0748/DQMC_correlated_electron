#!/usr/bin/env bash

# Detached, restartable interacting-atom benchmark at mu=-0.5, 0, +0.5.
# Run this script from the standalone DQMC directory on the Windows PC.

set -Eeuo pipefail

WORKDIR=/mnt/c/Users/YQW/DQMCStandalone
SCAN_ROOT=benchmark_data/atom_mu_scan_beta10
EXISTING_MU_ZERO=benchmark_data/atom_spectral_ed_beta10/atom_U2_beta10_10chains.jls

cd "$WORKDIR"
mkdir -p "$SCAN_ROOT"

exec >> "$SCAN_ROOT/task.log" 2>&1

finish() {
    local status=$?
    trap - EXIT
    echo "WINDOWS_TASK_FINISHED=$(date -Iseconds)"
    echo "WINDOWS_TASK_EXIT_STATUS=$status"
    exit "$status"
}
trap finish EXIT

echo "WINDOWS_TASK_STARTED=$(date -Iseconds)"
echo "Atomic chemical-potential scan: U=2, beta=10, L=2"
echo "Chemical potentials: -0.5, 0.0, +0.5"

run_chains_and_pool() {
    local label=$1
    local mu=$2
    local first_seed=$3
    local reuse_payload=${4:-}
    local point="$SCAN_ROOT/$label"
    local pooled="$point/pooled.jls"

    mkdir -p "$point/chains"

    if [[ -f "$pooled" ]]; then
        echo "[$label] Reusing pooled payload: $pooled"
        return
    fi

    if [[ -n "$reuse_payload" && -f "$reuse_payload" ]]; then
        echo "[$label] Reusing existing mu=0 pooled payload"
        cp "$reuse_payload" "$pooled.tmp"
        mv "$pooled.tmp" "$pooled"
        return
    fi

    local sources=()
    local offset seed output
    for offset in {0..9}; do
        seed=$((first_seed + offset))
        output="$point/chains/seed${seed}.jls"
        sources+=("$output")

        if [[ -f "$output" ]]; then
            echo "[$label] Reusing DQMC seed $seed"
            continue
        fi

        echo "[$label] Running DQMC seed $seed"
        julia --project=. square_hubbard_two_orbital_observables.jl \
            2 10 "$mu" 2 2 \
            --atomic-check \
            --production \
            --measure-greens \
            --greens-every=10 \
            --seed="$seed" \
            --output="$output"
    done

    echo "[$label] Pooling 10 raw-bin payloads"
    julia --project=. pool_two_orbital_observables.jl \
        "$pooled" \
        "${sources[@]}"
}

validate_trace_channel() {
    local label=$1
    local point="$SCAN_ROOT/$label"
    local pooled="$point/pooled.jls"
    local validation_log="$point/exact_validation.log"
    local validator_status

    echo "[$label] Comparing pooled DQMC observables with exact ED"
    set +e
    julia --project=. validate_two_orbital_exact_benchmarks.jl \
        "$pooled" > "$validation_log" 2>&1
    validator_status=$?
    set -e
    cat "$validation_log"

    local required_labels=(
        "Density per cell"
        "Double occupancy (2 orbitals)"
        "S_alm(q=0)"
        "m_alm^2"
        "G_loc(tau), max error"
        "G(0)+G(beta)=1"
        "Off-diagonal orbital G"
    )
    local required_label
    for required_label in "${required_labels[@]}"; do
        if ! grep -F "$required_label" "$validation_log" | grep -q "PASS"; then
            echo "[$label] REQUIRED_ED_CHECK_FAILED: $required_label"
            return 1
        fi
    done

    if [[ $validator_status -eq 0 ]]; then
        echo "[$label] FULL_ED_VALIDATION=PASS"
    else
        echo "[$label] TRACE_ED_VALIDATION=PASS"
        echo "[$label] STRICT_CHANNEL_VALIDATION=UNRESOLVED"
    fi
}

continue_point() {
    local label=$1
    local mu=$2
    local point="$SCAN_ROOT/$label"
    local pooled="$point/pooled.jls"

    if [[ ! -f "$point/exact_deac/atom_deac_spectrum.csv" ]]; then
        echo "[$label] Continuing exact-ED G(tau)"
        julia --threads=auto --project=deac_env \
            benchmark_two_orbital_atom_deac.jl \
            2 10 "$mu" \
            --error=0.001 \
            --tau-points=201 \
            --omega-min=-4 \
            --omega-max=4 \
            --omega-points=401 \
            --deac-bins=10 \
            --runs-per-bin=100 \
            --generations=100000 \
            --base-seed=16180339 \
            --output-dir="$point/exact_deac"
    else
        echo "[$label] Reusing exact-input DEAC result"
    fi

    if [[ ! -f "$point/dos/dos_spectrum.csv" ]]; then
        echo "[$label] Continuing pooled DQMC DOS"
        julia --threads=auto --project=deac_env \
            continue_two_orbital_spectrum.jl \
            "$pooled" \
            --mode=dos \
            --tau-stride=5 \
            --omega-min=-4 \
            --omega-max=4 \
            --omega-points=401 \
            --deac-bins=10 \
            --runs-per-bin=100 \
            --generations=100000 \
            --base-seed=31415927 \
            --output-dir="$point/dos"
    else
        echo "[$label] Reusing pooled DQMC DOS continuation"
    fi
}

run_chains_and_pool mu_m0p5 -0.5 525001
run_chains_and_pool mu_0p0 0.0 550001 "$EXISTING_MU_ZERO"
run_chains_and_pool mu_p0p5 0.5 575001

for label in mu_m0p5 mu_0p0 mu_p0p5; do
    validate_trace_channel "$label"
done

continue_point mu_m0p5 -0.5
continue_point mu_0p0 0.0
continue_point mu_p0p5 0.5

echo "Creating combined ED comparison figure and summary"
julia --project=. plot_atomic_mu_scan.jl "$SCAN_ROOT"

echo "MU_SCAN_COMPLETE"

