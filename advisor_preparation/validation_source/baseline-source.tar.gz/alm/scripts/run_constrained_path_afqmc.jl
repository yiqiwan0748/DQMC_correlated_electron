#!/usr/bin/env julia

module RunConstrainedPathAFQMC

using AltermagnetDQMCTrial
using LinearAlgebra: BLAS
using Serialization: deserialize, serialize

export parse_options, run_calculation, main

const HELP = """
Run fixed-particle constrained-path AFQMC for the periodic two-orbital model.

Usage:
  julia --project=. scripts/run_constrained_path_afqmc.jl [options]

Options use --name=value:
  --L=2
  --U=2.0
  --Nup=2
  --Ndown=2
  --dtau=0.02
  --walkers=200
  --warmup=200
  --measurements=40
  --steps-between=5
  --orthogonalize-every=5
  --population-control-every=5
  --overlap-refresh-every=16
  --back-propagation-steps=20
  --minimum-backprop-ancestors=2
  --block-size=5
  --seed=1234
  --trial=free
  --field-strength=0.001
  --checkpoint-every-steps=25
  --checkpoint-path=PATH
  --resume-from=PATH
  --output-dir=results/cp_afqmc

Trial choices: free, altermagnetic, stripe-x, stripe-y, neel.
The output directory must not already exist.
"""

function _integer(raw, name; minimum=nothing)
    value = try
        parse(Int, raw)
    catch
        throw(ArgumentError("--$name must be an integer"))
    end
    isnothing(minimum) || value >= minimum || throw(ArgumentError(
        "--$name must be at least $minimum",
    ))
    return value
end

function _real(raw, name; minimum=nothing)
    value = try
        parse(Float64, raw)
    catch
        throw(ArgumentError("--$name must be a real number"))
    end
    isfinite(value) || throw(ArgumentError("--$name must be finite"))
    isnothing(minimum) || value >= minimum || throw(ArgumentError(
        "--$name must be at least $minimum",
    ))
    return value
end

function _trial_pattern(raw)
    normalized = replace(lowercase(raw), "_" => "-")
    patterns = Dict(
        "free" => :free,
        "altermagnetic" => :altermagnetic,
        "stripe-x" => :stripe_x,
        "stripe-y" => :stripe_y,
        "neel" => :neel,
    )
    haskey(patterns, normalized) || throw(ArgumentError(
        "--trial must be free, altermagnetic, stripe-x, stripe-y, or neel",
    ))
    return patterns[normalized]
end

function parse_options(arguments=ARGS)
    any(argument -> argument in ("--help", "-h"), arguments) && return nothing
    allowed = Set((
        "L", "U", "Nup", "Ndown", "dtau", "walkers", "warmup",
        "measurements", "steps-between", "orthogonalize-every",
        "population-control-every", "overlap-refresh-every",
        "back-propagation-steps", "minimum-backprop-ancestors", "block-size",
        "seed", "trial", "field-strength", "checkpoint-every-steps",
        "checkpoint-path", "resume-from", "output-dir",
    ))
    raw = Dict{String,String}()
    for argument in arguments
        startswith(argument, "--") || throw(ArgumentError(
            "arguments must use --name=value",
        ))
        parts = split(argument[3:end], '='; limit=2)
        length(parts) == 2 || throw(ArgumentError(
            "argument $argument must use --name=value",
        ))
        name, value = parts
        name in allowed || throw(ArgumentError("unknown option --$name"))
        haskey(raw, name) && throw(ArgumentError("duplicate option --$name"))
        raw[name] = value
    end

    output_dir = abspath(get(raw, "output-dir", "results/cp_afqmc"))
    checkpoint_path = haskey(raw, "checkpoint-path") ?
        abspath(raw["checkpoint-path"]) : output_dir * ".checkpoint.jls"
    resume_from = haskey(raw, "resume-from") ?
        abspath(raw["resume-from"]) : nothing
    return (
        L=_integer(get(raw, "L", "2"), "L"; minimum=1),
        U=_real(get(raw, "U", "2.0"), "U"; minimum=0.0),
        Nup=_integer(get(raw, "Nup", "2"), "Nup"; minimum=0),
        Ndown=_integer(get(raw, "Ndown", "2"), "Ndown"; minimum=0),
        dtau=_real(get(raw, "dtau", "0.02"), "dtau"; minimum=nextfloat(0.0)),
        walkers=_integer(get(raw, "walkers", "200"), "walkers"; minimum=2),
        warmup=_integer(get(raw, "warmup", "200"), "warmup"; minimum=0),
        measurements=_integer(
            get(raw, "measurements", "40"),
            "measurements";
            minimum=1,
        ),
        steps_between=_integer(
            get(raw, "steps-between", "5"),
            "steps-between";
            minimum=1,
        ),
        orthogonalize_every=_integer(
            get(raw, "orthogonalize-every", "5"),
            "orthogonalize-every";
            minimum=1,
        ),
        population_control_every=_integer(
            get(raw, "population-control-every", "5"),
            "population-control-every";
            minimum=1,
        ),
        overlap_refresh_every=_integer(
            get(raw, "overlap-refresh-every", "16"),
            "overlap-refresh-every";
            minimum=1,
        ),
        back_propagation_steps=_integer(
            get(raw, "back-propagation-steps", "20"),
            "back-propagation-steps";
            minimum=0,
        ),
        minimum_backprop_ancestors=_integer(
            get(raw, "minimum-backprop-ancestors", "2"),
            "minimum-backprop-ancestors";
            minimum=1,
        ),
        block_size=_integer(
            get(raw, "block-size", "5"),
            "block-size";
            minimum=1,
        ),
        seed=_integer(get(raw, "seed", "1234"), "seed"),
        trial=_trial_pattern(get(raw, "trial", "free")),
        field_strength=_real(
            get(raw, "field-strength", "0.001"),
            "field-strength",
        ),
        checkpoint_every_steps=_integer(
            get(raw, "checkpoint-every-steps", "25"),
            "checkpoint-every-steps";
            minimum=1,
        ),
        checkpoint_path=checkpoint_path,
        resume_from=resume_from,
        output_dir=output_dir,
        provided_names=Set(keys(raw)),
    )
end

_csv(value::Missing) = ""
_csv(value::Nothing) = ""
_csv(value) = string(value)

const CHECKPOINT_FORMAT_VERSION = 1
const _PHYSICS_OPTION_NAMES = (
    "L" => :L,
    "U" => :U,
    "Nup" => :Nup,
    "Ndown" => :Ndown,
    "dtau" => :dtau,
    "walkers" => :walkers,
    "warmup" => :warmup,
    "measurements" => :measurements,
    "steps-between" => :steps_between,
    "orthogonalize-every" => :orthogonalize_every,
    "population-control-every" => :population_control_every,
    "overlap-refresh-every" => :overlap_refresh_every,
    "back-propagation-steps" => :back_propagation_steps,
    "minimum-backprop-ancestors" => :minimum_backprop_ancestors,
    "block-size" => :block_size,
    "seed" => :seed,
    "trial" => :trial,
    "field-strength" => :field_strength,
)

function _read_checkpoint(path)
    isfile(path) || throw(ArgumentError("checkpoint does not exist: $path"))
    payload = open(deserialize, path)
    hasproperty(payload, :format_version) &&
        payload.format_version == CHECKPOINT_FORMAT_VERSION || throw(
            ArgumentError("unsupported checkpoint format in $path"),
        )
    return payload
end

function _resume_options(requested, payload)
    saved = payload.options
    for (cli_name, field_name) in _PHYSICS_OPTION_NAMES
        if cli_name in requested.provided_names &&
           getproperty(requested, field_name) != getproperty(saved, field_name)
            throw(ArgumentError(
                "--$cli_name does not match the saved checkpoint",
            ))
        end
    end
    output_dir = "output-dir" in requested.provided_names ?
        requested.output_dir : saved.output_dir
    checkpoint_path = "checkpoint-path" in requested.provided_names ?
        requested.checkpoint_path : requested.resume_from
    return merge(
        saved,
        (
            output_dir=output_dir,
            checkpoint_path=checkpoint_path,
            resume_from=requested.resume_from,
            checkpoint_every_steps=requested.checkpoint_every_steps,
            provided_names=requested.provided_names,
        ),
    )
end

function _write_checkpoint(
    path,
    options,
    state,
    measurements,
    warmup_completed,
    separation_completed;
    order_measurements=nothing,
)
    orders = AltermagnetDQMCTrial._cp_checked_order_measurements(
        measurements, order_measurements,
    )
    mkpath(dirname(path))
    temporary, io = mktemp(dirname(path))
    try
        serialize(io, (
            format_version=CHECKPOINT_FORMAT_VERSION,
            options=options,
            state=state,
            measurements=measurements,
            order_measurements=orders,
            warmup_completed=warmup_completed,
            separation_completed=separation_completed,
        ))
        close(io)
        mv(temporary, path; force=true)
    catch
        isopen(io) && close(io)
        ispath(temporary) && rm(temporary; force=true)
        rethrow()
    end
    return path
end

function _write_summary(path, result)
    summary = result.summary
    open(path, "w") do io
        println(io, "quantity,value,standard_error")
        rows = (
            ("mixed_energy", summary.energy, summary.energy_standard_error),
            (
                "mixed_energy_per_cell",
                summary.energy_per_cell,
                summary.energy_standard_error_per_cell,
            ),
            (
                "mixed_kinetic_energy",
                summary.mixed_kinetic_energy,
                summary.mixed_kinetic_energy_standard_error,
            ),
            (
                "mixed_interaction_energy",
                summary.mixed_interaction_energy,
                summary.mixed_interaction_energy_standard_error,
            ),
            (
                "mixed_double_occupancy_per_cell",
                summary.mixed_double_occupancy_per_cell,
                summary.mixed_double_occupancy_standard_error,
            ),
            (
                "backpropagated_energy",
                summary.backpropagated_energy,
                summary.backpropagated_energy_standard_error,
            ),
            (
                "backpropagated_kinetic_energy",
                summary.backpropagated_kinetic_energy,
                summary.backpropagated_kinetic_energy_standard_error,
            ),
            (
                "backpropagated_interaction_energy",
                summary.backpropagated_interaction_energy,
                summary.backpropagated_interaction_energy_standard_error,
            ),
            (
                "backpropagated_double_occupancy_per_cell",
                summary.backpropagated_double_occupancy_per_cell,
                summary.backpropagated_double_occupancy_standard_error,
            ),
            ("S_alm_q0", summary.S_alm_q0, summary.S_alm_q0_standard_error),
            ("S_fm_q0", summary.S_fm_q0, summary.S_fm_q0_standard_error),
            ("mx", summary.mx, summary.mx_standard_error),
            ("my", summary.my, summary.my_standard_error),
            ("m_fm", summary.m_fm, summary.m_fm_standard_error),
            ("delta_alm", summary.delta_alm, summary.delta_alm_standard_error),
            ("m_alm_squared", summary.m_alm_squared,
                summary.m_alm_squared_standard_error),
            ("density", summary.density, missing),
        )
        for row in rows
            println(io, join(_csv.(row), ','))
        end
    end
end

function _write_measurements(path, result)
    open(path, "w") do io
        println(
            io,
            "step,mixed_energy,mixed_kinetic,mixed_interaction," *
            "mixed_double_per_cell,backpropagated_energy," *
            "backpropagated_kinetic,backpropagated_interaction," *
            "backpropagated_double_per_cell,S_alm_q0,S_fm_q0," *
            "distinct_backprop_ancestors,mx,my,m_fm,delta_alm,m_alm_squared",
        )
        for (measurement, order) in zip(result.measurements, result.order_measurements)
            values = (
                measurement.step,
                measurement.mixed_total_energy,
                measurement.mixed_kinetic_energy,
                measurement.mixed_interaction_energy,
                measurement.mixed_double_occupancy_per_cell,
                measurement.backpropagated_total_energy,
                measurement.backpropagated_kinetic_energy,
                measurement.backpropagated_interaction_energy,
                measurement.backpropagated_double_occupancy_per_cell,
                measurement.S_alm_q0,
                measurement.S_fm_q0,
                measurement.distinct_backprop_ancestors,
                order.mx,
                order.my,
                order.m_fm,
                order.delta_alm,
                measurement.S_alm_q0 / result.problem.cell_count,
            )
            println(io, join(_csv.(values), ','))
        end
    end
end

function _write_spin_structure(path, result)
    summary = result.summary
    odd = summary.orbital_odd_spin_structure_factor
    isnothing(odd) && return false
    even = summary.orbital_even_spin_structure_factor
    odd_error = summary.orbital_odd_spin_structure_factor_standard_error
    even_error = summary.orbital_even_spin_structure_factor_standard_error
    open(path, "w") do io
        println(io, "qx_index,qy_index,qx,qy,S_orbital_odd,se_odd,S_orbital_even,se_even")
        for qy in axes(odd, 2), qx in axes(odd, 1)
            values = (
                qx - 1,
                qy - 1,
                summary.spin_structure_momenta_x[qx],
                summary.spin_structure_momenta_y[qy],
                odd[qx, qy],
                odd_error[qx, qy],
                even[qx, qy],
                even_error[qx, qy],
            )
            println(io, join(_csv.(values), ','))
        end
    end
    return true
end

function _write_full_orbital_spin_structure(path, result)
    any(
        measurement -> !isnothing(measurement.structure_factor),
        result.measurements,
    ) || return false
    momenta_x = result.summary.spin_structure_momenta_x
    momenta_y = result.summary.spin_structure_momenta_y
    open(path, "w") do io
        println(
            io,
            "measurement,step,orbital_a,orbital_b,qx_index,qy_index," *
            "qx,qy,real_value,imag_value",
        )
        for (measurement_index, measurement) in enumerate(result.measurements)
            structure = measurement.structure_factor
            isnothing(structure) && continue
            for qy in axes(structure, 4), qx in axes(structure, 3),
                orbital_b in 1:2, orbital_a in 1:2
                value = structure[orbital_a, orbital_b, qx, qy]
                row = (
                    measurement_index,
                    measurement.step,
                    orbital_a,
                    orbital_b,
                    qx - 1,
                    qy - 1,
                    momenta_x[qx],
                    momenta_y[qy],
                    real(value),
                    imag(value),
                )
                println(io, join(_csv.(row), ','))
            end
        end
    end
    return true
end

function _write_metadata(path, options, result, spin_written, full_spin_written)
    open(path, "w") do io
        println(io, "method=constrained-path AFQMC")
        println(io, "Hamiltonian=centered repulsive two-orbital Hubbard")
        println(io, "boundary=periodic")
        println(io, "julia_version=", VERSION)
        println(io, "hostname=", get(ENV, "HOSTNAME", "unknown"))
        println(io, "system=", Sys.KERNEL)
        println(io, "machine=", Sys.MACHINE)
        println(io, "cpu_name=", Sys.CPU_NAME)
        println(io, "julia_threads=", Threads.nthreads())
        println(io, "blas_threads=", BLAS.get_num_threads())
        println(
            io,
            "blas_config=",
            replace(string(BLAS.get_config()), '\n' => ' '),
        )
        for name in propertynames(options)
            name in (:provided_names, :resume_from) && continue
            println(io, name, '=', getproperty(options, name))
        end
        println(io, "realized_density=", result.summary.density)
        println(io, "trial_label=", result.trial_label)
        for name in propertynames(result.diagnostics)
            println(io, name, '=', _csv(getproperty(result.diagnostics, name)))
        end
        println(io, "spin_structure_written=", spin_written)
        println(io, "full_orbital_spin_structure_written=", full_spin_written)
        println(io, "energy_estimator=constrained mixed estimate; not variational")
        println(io, "K_V_D_estimators=use backpropagated columns for ED comparison")
        println(io, "orbital_magnetization_estimator=backpropagated signed first moment")
        println(io, "delta_alm_definition=(mx-my)/2; orbital magnetizations per cell")
        println(io, "m_alm_squared_definition=S_alm_q0/L^2; second moment of Delta")
        println(io, "physical_altermagnetic_field=0; field_strength selects trial only")
        println(io, "delta_summary_requires=complete first-moment measurement history")
        println(io, "constraint_bias=not removed by more walkers or longer projection")
        println(io, "required_checks=dtau,projection time,walkers,seeds,trials,BP length,size")
    end
end

function run_calculation(options)
    payload = isnothing(options.resume_from) ? nothing :
        _read_checkpoint(options.resume_from)
    if !isnothing(payload)
        options = _resume_options(options, payload)
    end
    ispath(options.output_dir) && throw(ArgumentError(
        "refusing to overwrite output directory: $(options.output_dir)",
    ))
    if isnothing(payload) && ispath(options.checkpoint_path)
        throw(ArgumentError(
            "refusing to overwrite checkpoint: $(options.checkpoint_path); " *
            "use --resume-from=$(options.checkpoint_path)",
        ))
    end

    state, measurements, warmup_completed, separation_completed = if isnothing(payload)
        problem = two_orbital_cp_afqmc_problem(
            options.L,
            options.U,
            options.Nup,
            options.Ndown,
        )
        controls = CPAFQMCParameters(
            dtau=options.dtau,
            walker_count=options.walkers,
            warmup_steps=options.warmup,
            measurement_count=options.measurements,
            steps_between_measurements=options.steps_between,
            orthogonalize_every=options.orthogonalize_every,
            population_control_every=options.population_control_every,
            overlap_refresh_every=options.overlap_refresh_every,
            back_propagation_steps=options.back_propagation_steps,
            minimum_backprop_ancestors=options.minimum_backprop_ancestors,
            error_block_size=options.block_size,
            seed=options.seed,
        )
        controls.back_propagation_steps <=
            controls.warmup_steps + controls.steps_between_measurements || throw(
                ArgumentError(
                    "back-propagation history is longer than the first " *
                    "measurement projection",
                ),
            )
        trial = one_body_trial(
            problem;
            pattern=options.trial,
            field_strength=options.field_strength,
        )
        initialized = initialize_cp_afqmc(problem, controls; trial=trial)
        (
            initialized,
            CPAFQMCMeasurement{eltype(problem.kinetic)}[],
            0,
            0,
        )
    else
        (
            payload.state,
            payload.measurements,
            payload.warmup_completed,
            payload.separation_completed,
        )
    end

    0 <= warmup_completed <= state.parameters.warmup_steps || throw(
        ArgumentError("checkpoint has an invalid warmup counter"),
    )
    0 <= separation_completed < state.parameters.steps_between_measurements || throw(
        ArgumentError("checkpoint has an invalid measurement-step counter"),
    )
    length(measurements) <= state.parameters.measurement_count || throw(
        ArgumentError("checkpoint has too many measurements"),
    )
    saved_orders = !isnothing(payload) && hasproperty(payload, :order_measurements) ?
        payload.order_measurements : nothing
    order_measurements = AltermagnetDQMCTrial._cp_checked_order_measurements(
        measurements, saved_orders,
    )

    last_checkpoint_step = state.step
    function checkpoint!()
        _write_checkpoint(
            options.checkpoint_path,
            options,
            state,
            measurements,
            warmup_completed,
            separation_completed;
            order_measurements=order_measurements,
        )
        last_checkpoint_step = state.step
        return nothing
    end
    isnothing(payload) && checkpoint!()
    while warmup_completed < state.parameters.warmup_steps
        step_cp_afqmc!(state)
        warmup_completed += 1
        state.step - last_checkpoint_step >= options.checkpoint_every_steps &&
            checkpoint!()
    end
    checkpoint!()
    while length(measurements) < state.parameters.measurement_count
        while separation_completed < state.parameters.steps_between_measurements
            step_cp_afqmc!(state)
            separation_completed += 1
            state.step - last_checkpoint_step >= options.checkpoint_every_steps &&
                checkpoint!()
        end
        sample = measure_cp_afqmc(state; include_order=true)
        push!(measurements, sample.measurement)
        push!(order_measurements, sample.order_measurement)
        separation_completed = 0
        checkpoint!()
    end
    result = finish_cp_afqmc(
        state, measurements; order_measurements=order_measurements,
    )

    parent = dirname(options.output_dir)
    mkpath(parent)
    staging = mktempdir(parent; prefix=".$(basename(options.output_dir)).tmp-")
    try
        _write_summary(joinpath(staging, "summary.csv"), result)
        _write_measurements(joinpath(staging, "measurements.csv"), result)
        spin_written = _write_spin_structure(
            joinpath(staging, "spin_structure.csv"),
            result,
        )
        full_spin_written = _write_full_orbital_spin_structure(
            joinpath(staging, "orbital_spin_structure_measurements.csv"),
            result,
        )
        _write_metadata(
            joinpath(staging, "metadata.txt"),
            options,
            result,
            spin_written,
            full_spin_written,
        )
        ispath(options.output_dir) && throw(ArgumentError(
            "output directory appeared while calculation was running: " *
            options.output_dir,
        ))
        mv(staging, options.output_dir)
    catch
        ispath(staging) && rm(staging; recursive=true)
        rethrow()
    end
    return (
        result=result,
        output_dir=options.output_dir,
        checkpoint_path=options.checkpoint_path,
    )
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        print(HELP)
        return nothing
    end
    run = run_calculation(options)
    println("Saved CP-AFQMC output to ", run.output_dir)
    println("Constrained mixed energy estimate = ", run.result.summary.energy)
    return run
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    RunConstrainedPathAFQMC.main()
end
