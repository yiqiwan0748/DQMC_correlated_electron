#!/usr/bin/env julia

module RunConstrainedPathAFQMCCampaign

include(joinpath(@__DIR__, "run_constrained_path_afqmc.jl"))
import .RunConstrainedPathAFQMC

export CampaignJob,
       parse_options,
       read_jobs,
       resource_smoke_jobs,
       pilot_jobs,
       l6_target_pilot_jobs,
       l8_target_pilot_jobs,
       run_campaign,
       main

const HELP = """
Run a restartable sequence of constrained-path AFQMC jobs.

Usage:
  julia --project=. scripts/run_constrained_path_afqmc_campaign.jl \\
    --jobs=jobs.csv --campaign-dir=results/cp_afqmc_campaign

  julia --project=. scripts/run_constrained_path_afqmc_campaign.jl \\
    --profile=resource-smoke \\
    --campaign-dir=results/cp_afqmc_resource_smoke

  julia --project=. scripts/run_constrained_path_afqmc_campaign.jl \\
    --profile=pilot --campaign-dir=results/cp_afqmc_pilot

  julia --project=. scripts/run_constrained_path_afqmc_campaign.jl \\
    --profile=l6-target-pilot \\
    --campaign-dir=results/cp_afqmc_l6_target_pilot

  julia --project=. scripts/run_constrained_path_afqmc_campaign.jl \\
    --profile=l8-target-pilot \\
    --campaign-dir=results/cp_afqmc_l8_target_pilot

Options use --name=value:
  --jobs=PATH                 CSV job table
  --profile=NAME              Built-in resource-smoke, pilot,
                              l6-target-pilot, or l8-target-pilot profile
  --campaign-dir=PATH         Persistent campaign directory
  --keep-going=false          Continue after an ordinary job failure
  --max-jobs=N                Run at most N unfinished jobs this invocation

Give exactly one of --jobs or --profile. The resource-smoke profile checks
execution and restart behavior only. The pilot is a prepared L=4, U=12 trial
and seed grid. The l6-target-pilot and l8-target-pilot are six-job,
near-target-filling size follow-ups. No one profile alone is a finite-size
physics result.

The CSV header must contain job_id. Other columns use the same names as
run_constrained_path_afqmc.jl, except output and checkpoint paths, which are
managed by this driver. For example:

  job_id,L,U,Nup,Ndown,seed,trial
  U4_seed1,2,4,2,2,101,free
  U4_seed2,2,4,2,2,102,altermagnetic

Job ids may contain letters, numbers, period, underscore, and hyphen. This
simple input format does not support quoted CSV fields.
"""

const JOB_OPTION_NAMES = (
    "L",
    "U",
    "Nup",
    "Ndown",
    "dtau",
    "walkers",
    "warmup",
    "measurements",
    "steps-between",
    "orthogonalize-every",
    "population-control-every",
    "overlap-refresh-every",
    "back-propagation-steps",
    "minimum-backprop-ancestors",
    "block-size",
    "seed",
    "trial",
    "field-strength",
    "checkpoint-every-steps",
)

const SPEC_FIELDS = (
    "L" => :L,
    "U" => :U,
    "Nup" => :Nup,
    "Ndown" => :Ndown,
    "dtau" => :dtau,
    "walkers" => :walkers,
    "warmup" => :warmup,
    "measurements" => :measurements,
    "steps-between" => :steps_between,
    "orthogonalize-every" => :orthogonalize_every,
    "population-control-every" => :population_control_every,
    "overlap-refresh-every" => :overlap_refresh_every,
    "back-propagation-steps" => :back_propagation_steps,
    "minimum-backprop-ancestors" => :minimum_backprop_ancestors,
    "block-size" => :block_size,
    "seed" => :seed,
    "trial" => :trial,
    "field-strength" => :field_strength,
    "checkpoint-every-steps" => :checkpoint_every_steps,
)

const REQUIRED_OUTPUT_FILES = (
    "summary.csv",
    "measurements.csv",
    "metadata.txt",
)

struct CampaignJob
    id::String
    runner_arguments::Vector{String}
end

function resource_smoke_jobs()
    common = [
        "--L=4",
        "--U=12",
        "--Nup=12",
        "--Ndown=12",
        "--dtau=0.01",
        "--walkers=64",
        "--warmup=60",
        "--measurements=10",
        "--steps-between=4",
        "--orthogonalize-every=5",
        "--population-control-every=5",
        "--overlap-refresh-every=8",
        "--back-propagation-steps=20",
        "--minimum-backprop-ancestors=4",
        "--block-size=2",
        "--checkpoint-every-steps=10",
    ]
    trials = (
        ("free", "free", 0.0, 6101),
        ("alm_plus", "altermagnetic", 0.01, 6102),
        ("alm_minus", "altermagnetic", -0.01, 6103),
        ("stripe_x", "stripe-x", 0.01, 6104),
        ("stripe_y", "stripe-y", 0.01, 6105),
        ("neel", "neel", 0.01, 6106),
    )
    return [
        CampaignJob(
            id,
            vcat(
                common,
                [
                    "--trial=$trial",
                    "--field-strength=$field",
                    "--seed=$seed",
                ],
            ),
        ) for (id, trial, field, seed) in trials
    ]
end

function pilot_jobs()
    common = [
        "--L=4",
        "--U=12",
        "--Nup=12",
        "--Ndown=12",
        "--dtau=0.025",
        "--walkers=512",
        "--warmup=320",
        "--measurements=400",
        "--steps-between=4",
        "--back-propagation-steps=80",
        "--block-size=20",
    ]
    trials = (
        ("free", "free", 0.0),
        ("alm_plus", "altermagnetic", 0.01),
        ("alm_minus", "altermagnetic", -0.01),
        ("stripe_x", "stripe-x", 0.01),
        ("stripe_y", "stripe-y", 0.01),
        ("neel", "neel", 0.01),
    )
    seeds = (12041, 12042, 12043)
    return [
        CampaignJob(
            "$(id)_seed$(seed)",
            vcat(
                common,
                [
                    "--trial=$trial",
                    "--field-strength=$field",
                    "--seed=$seed",
                ],
            ),
        ) for seed in seeds for (id, trial, field) in trials
    ]
end

function l6_target_pilot_jobs()
    common = [
        "--L=6",
        "--U=12",
        "--Nup=26",
        "--Ndown=26",
        "--dtau=0.025",
        "--walkers=512",
        "--warmup=320",
        "--measurements=400",
        "--steps-between=4",
        "--orthogonalize-every=5",
        "--population-control-every=5",
        "--overlap-refresh-every=16",
        "--back-propagation-steps=80",
        "--minimum-backprop-ancestors=16",
        "--block-size=20",
        "--checkpoint-every-steps=25",
    ]
    trials = (
        ("alm_plus", 0.01),
        ("alm_minus", -0.01),
    )
    seeds = (12041, 12042, 12043)
    return [
        CampaignJob(
            "$(id)_seed$(seed)",
            vcat(
                common,
                [
                    "--trial=altermagnetic",
                    "--field-strength=$field",
                    "--seed=$seed",
                ],
            ),
        ) for seed in seeds for (id, field) in trials
    ]
end

function l8_target_pilot_jobs()
    common = [
        "--L=8",
        "--U=12",
        "--Nup=46",
        "--Ndown=46",
        "--dtau=0.025",
        "--walkers=512",
        "--warmup=320",
        "--measurements=400",
        "--steps-between=4",
        "--orthogonalize-every=5",
        "--population-control-every=5",
        "--overlap-refresh-every=16",
        "--back-propagation-steps=80",
        "--minimum-backprop-ancestors=16",
        "--block-size=20",
        "--checkpoint-every-steps=25",
    ]
    trials = (
        ("alm_plus", 0.01),
        ("alm_minus", -0.01),
    )
    seeds = (12041, 12042, 12043)
    return [
        CampaignJob(
            "$(id)_seed$(seed)",
            vcat(
                common,
                [
                    "--trial=altermagnetic",
                    "--field-strength=$field",
                    "--seed=$seed",
                ],
            ),
        ) for seed in seeds for (id, field) in trials
    ]
end

mutable struct CampaignStatus
    job_id::String
    state::String
    action::String
    output_dir::String
    checkpoint_path::String
    message::String
end

function _boolean(raw::AbstractString, name::AbstractString)
    normalized = lowercase(strip(raw))
    normalized == "true" && return true
    normalized == "false" && return false
    throw(ArgumentError("--$name must be true or false"))
end

function _positive_integer(raw::AbstractString, name::AbstractString)
    value = try
        parse(Int, raw)
    catch
        throw(ArgumentError("--$name must be an integer"))
    end
    value >= 1 || throw(ArgumentError("--$name must be at least 1"))
    return value
end

function parse_options(arguments=ARGS)
    any(argument -> argument in ("--help", "-h"), arguments) && return nothing
    allowed = Set((
        "jobs",
        "profile",
        "campaign-dir",
        "keep-going",
        "max-jobs",
    ))
    raw = Dict{String,String}()
    for argument in arguments
        startswith(argument, "--") || throw(ArgumentError(
            "arguments must use --name=value",
        ))
        pieces = split(argument[3:end], '='; limit=2)
        length(pieces) == 2 || throw(ArgumentError(
            "argument $argument must use --name=value",
        ))
        name, value = pieces
        name in allowed || throw(ArgumentError("unknown option --$name"))
        haskey(raw, name) && throw(ArgumentError("duplicate option --$name"))
        raw[name] = value
    end
    has_jobs = haskey(raw, "jobs")
    has_profile = haskey(raw, "profile")
    has_jobs == has_profile && throw(ArgumentError(
        "give exactly one of --jobs or --profile",
    ))
    has_jobs && isempty(raw["jobs"]) && throw(ArgumentError(
        "--jobs must not be empty",
    ))
    profile = if has_profile
        normalized = lowercase(raw["profile"])
        normalized in (
            "resource-smoke",
            "pilot",
            "l6-target-pilot",
            "l8-target-pilot",
        ) || throw(ArgumentError(
            "--profile must be resource-smoke, pilot, l6-target-pilot, or " *
            "l8-target-pilot",
        ))
        Symbol(replace(normalized, '-' => '_'))
    else
        nothing
    end
    default_campaign = if profile == :resource_smoke
        "results/cp_afqmc_resource_smoke"
    elseif profile == :pilot
        "results/cp_afqmc_pilot"
    elseif profile == :l6_target_pilot
        "results/cp_afqmc_l6_target_pilot"
    elseif profile == :l8_target_pilot
        "results/cp_afqmc_l8_target_pilot"
    else
        "results/cp_afqmc_campaign"
    end
    campaign_raw = get(raw, "campaign-dir", default_campaign)
    isempty(campaign_raw) && throw(ArgumentError(
        "--campaign-dir must not be empty",
    ))
    return (
        jobs_path=has_jobs ? abspath(raw["jobs"]) : nothing,
        profile=profile,
        campaign_dir=abspath(campaign_raw),
        keep_going=_boolean(get(raw, "keep-going", "false"), "keep-going"),
        max_jobs=haskey(raw, "max-jobs") ?
            _positive_integer(raw["max-jobs"], "max-jobs") : nothing,
    )
end

function _fields(line::AbstractString, line_number::Integer)
    occursin('"', line) && throw(ArgumentError(
        "quoted CSV fields are not supported (line $line_number)",
    ))
    return strip.(split(line, ','; keepempty=true))
end

function read_jobs(path::AbstractString)
    isfile(path) || throw(ArgumentError("jobs file does not exist: $path"))
    source_lines = readlines(path)
    lines = Tuple{Int,String}[]
    for (line_number, source_line) in enumerate(source_lines)
        line = strip(source_line)
        (isempty(line) || startswith(line, '#')) && continue
        push!(lines, (line_number, line))
    end
    isempty(lines) && throw(ArgumentError("jobs file is empty: $path"))

    header_line, header_text = first(lines)
    header = _fields(header_text, header_line)
    any(isempty, header) && throw(ArgumentError(
        "jobs header contains an empty column",
    ))
    length(unique(header)) == length(header) || throw(ArgumentError(
        "jobs header contains duplicate columns",
    ))
    "job_id" in header || throw(ArgumentError(
        "jobs header must contain job_id",
    ))
    allowed = Set(("job_id", JOB_OPTION_NAMES...))
    unknown = filter(name -> !(name in allowed), header)
    isempty(unknown) || throw(ArgumentError(
        "unsupported jobs column: $(first(unknown))",
    ))

    id_column = findfirst(==("job_id"), header)
    jobs = CampaignJob[]
    seen = Set{String}()
    for (line_number, line) in Iterators.drop(lines, 1)
        values = _fields(line, line_number)
        length(values) == length(header) || throw(ArgumentError(
            "line $line_number has $(length(values)) fields; expected $(length(header))",
        ))
        id = values[id_column]
        occursin(r"^[A-Za-z0-9][A-Za-z0-9._-]*$", id) || throw(ArgumentError(
            "invalid job_id on line $line_number: $id",
        ))
        id in seen && throw(ArgumentError("duplicate job_id: $id"))
        push!(seen, id)
        runner_arguments = String[]
        for (name, value) in zip(header, values)
            (name == "job_id" || isempty(value)) && continue
            push!(runner_arguments, "--$name=$value")
        end
        push!(jobs, CampaignJob(id, runner_arguments))
    end
    isempty(jobs) && throw(ArgumentError("jobs file contains no jobs: $path"))
    return jobs
end

function _atomic_write(path::AbstractString, content::AbstractString)
    mkpath(dirname(path))
    temporary, io = mktemp(dirname(path))
    try
        write(io, content)
        close(io)
        mv(temporary, path; force=true)
    catch
        isopen(io) && close(io)
        ispath(temporary) && rm(temporary; force=true)
        rethrow()
    end
    return path
end

function _csv_field(value)
    text = string(value)
    if any(character -> character in (',', '"', '\n', '\r'), text)
        return "\"" * replace(text, "\"" => "\"\"") * "\""
    end
    return text
end

function _write_status(path::AbstractString, statuses)
    io = IOBuffer()
    println(io, "job_id,state,action,output_dir,checkpoint_path,message")
    for status in statuses
        row = (
            status.job_id,
            status.state,
            status.action,
            status.output_dir,
            status.checkpoint_path,
            status.message,
        )
        println(io, join(_csv_field.(row), ','))
    end
    return _atomic_write(path, String(take!(io)))
end

function _resolved_options(job::CampaignJob, output_dir, checkpoint_path)
    arguments = vcat(
        job.runner_arguments,
        [
            "--output-dir=$output_dir",
            "--checkpoint-path=$checkpoint_path",
        ],
    )
    return RunConstrainedPathAFQMC.parse_options(arguments)
end

function _canonical_spec(job::CampaignJob, options)
    io = IOBuffer()
    println(io, "format_version=1")
    println(io, "job_id=", job.id)
    for (name, field) in SPEC_FIELDS
        println(io, name, '=', getproperty(options, field))
    end
    return String(take!(io))
end

function _ensure_spec(path::AbstractString, expected::AbstractString)
    if ispath(path)
        isfile(path) || throw(ArgumentError("job spec is not a file: $path"))
        read(path, String) == expected || throw(ArgumentError(
            "job settings changed for $(basename(path)); use a new job_id",
        ))
    else
        _atomic_write(path, expected)
    end
    return path
end

function _runner_arguments(options, output_dir, checkpoint_path; resume=false)
    arguments = String[]
    for (name, field) in SPEC_FIELDS
        push!(arguments, "--$name=$(getproperty(options, field))")
    end
    push!(arguments, "--output-dir=$output_dir")
    push!(arguments, "--checkpoint-path=$checkpoint_path")
    resume && push!(arguments, "--resume-from=$checkpoint_path")
    return arguments
end

function _complete_output(path::AbstractString)
    !ispath(path) && return false
    isdir(path) || throw(ArgumentError("job output is not a directory: $path"))
    missing = filter(name -> !isfile(joinpath(path, name)), REQUIRED_OUTPUT_FILES)
    isempty(missing) || throw(ArgumentError(
        "job output is incomplete at $path; missing $(join(missing, ", "))",
    ))
    metadata = read(joinpath(path, "metadata.txt"), String)
    occursin("method=constrained-path AFQMC", metadata) || throw(ArgumentError(
        "job output has unexpected metadata: $path",
    ))
    return true
end

function _error_message(exception)
    message = sprint(showerror, exception)
    return replace(message, '\n' => ' ', '\r' => ' ')
end

function run_campaign(
    options;
    executor=RunConstrainedPathAFQMC.run_calculation,
)
    jobs = if isnothing(options.profile)
        read_jobs(options.jobs_path)
    elseif options.profile == :resource_smoke
        resource_smoke_jobs()
    elseif options.profile == :pilot
        pilot_jobs()
    elseif options.profile == :l6_target_pilot
        l6_target_pilot_jobs()
    elseif options.profile == :l8_target_pilot
        l8_target_pilot_jobs()
    else
        error("unsupported campaign profile: $(options.profile)")
    end
    output_root = joinpath(options.campaign_dir, "outputs")
    checkpoint_root = joinpath(options.campaign_dir, "checkpoints")
    spec_root = joinpath(options.campaign_dir, "specs")
    mkpath(output_root)
    mkpath(checkpoint_root)
    mkpath(spec_root)
    status_path = joinpath(options.campaign_dir, "campaign_status.csv")
    profile_label = if isnothing(options.profile)
        "custom"
    elseif options.profile == :resource_smoke
        "resource-smoke"
    elseif options.profile == :pilot
        "pilot"
    elseif options.profile == :l6_target_pilot
        "l6-target-pilot"
    else
        "l8-target-pilot"
    end
    interpretation = if isnothing(options.profile)
        "user-defined"
    elseif options.profile == :resource_smoke
        "resource_and_restart_smoke_only"
    elseif options.profile == :pilot
        "trial_and_seed_pilot_only"
    elseif options.profile == :l6_target_pilot
        "near_target_filling_size_followup_only"
    else
        "near_target_filling_l8_size_followup_only"
    end
    metadata = "format_version=1\n" *
        "profile=$profile_label\n" *
        "interpretation=$interpretation\n" *
        "job_count=$(length(jobs))\n"
    _atomic_write(joinpath(options.campaign_dir, "campaign_metadata.txt"), metadata)

    entries = NamedTuple[]
    statuses = CampaignStatus[]
    for job in jobs
        output_dir = joinpath(output_root, job.id)
        checkpoint_path = joinpath(checkpoint_root, job.id * ".jls")
        ispath(checkpoint_path) && !isfile(checkpoint_path) && throw(
            ArgumentError("job checkpoint is not a file: $checkpoint_path"),
        )
        resolved = _resolved_options(job, output_dir, checkpoint_path)
        spec = _canonical_spec(job, resolved)
        _ensure_spec(joinpath(spec_root, job.id * ".txt"), spec)
        complete = _complete_output(output_dir)
        resume = !complete && isfile(checkpoint_path)
        push!(entries, (
            job=job,
            output_dir=output_dir,
            checkpoint_path=checkpoint_path,
            resolved=resolved,
            complete=complete,
            resume=resume,
        ))
        push!(statuses, CampaignStatus(
            job.id,
            complete ? "complete" : "pending",
            complete ? "skip" : (resume ? "resume" : "start"),
            output_dir,
            checkpoint_path,
            complete ? "valid completed output already exists" : "",
        ))
    end
    _write_status(status_path, statuses)

    started = 0
    resumed = 0
    skipped = 0
    failed = 0
    attempted = 0
    for (index, entry) in enumerate(entries)
        status = statuses[index]
        if entry.complete
            skipped += 1
            continue
        end
        if !isnothing(options.max_jobs) && attempted >= options.max_jobs
            continue
        end
        attempted += 1
        status.state = "running"
        status.action = entry.resume ? "resume" : "start"
        status.message = ""
        _write_status(status_path, statuses)
        arguments = _runner_arguments(
            entry.resolved,
            entry.output_dir,
            entry.checkpoint_path;
            resume=entry.resume,
        )
        run_options = RunConstrainedPathAFQMC.parse_options(arguments)
        try
            executor(run_options)
            _complete_output(entry.output_dir) || error(
                "job returned without publishing its output",
            )
            status.state = "complete"
            status.action = entry.resume ? "resumed" : "completed"
            status.message = ""
            entry.resume ? (resumed += 1) : (started += 1)
        catch exception
            failed += 1
            status.state = "failed"
            status.action = entry.resume ? "resume" : "start"
            status.message = _error_message(exception)
            _write_status(status_path, statuses)
            (exception isa InterruptException || !options.keep_going) && rethrow()
            continue
        end
        _write_status(status_path, statuses)
    end

    return (
        job_count=length(jobs),
        completed=started + resumed,
        started=started,
        resumed=resumed,
        skipped=skipped,
        failed=failed,
        remaining=count(status -> status.state == "pending", statuses),
        status_path=status_path,
    )
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        print(HELP)
        return nothing
    end
    result = run_campaign(options)
    println(
        "Campaign jobs: completed=", result.completed,
        ", resumed=", result.resumed,
        ", skipped=", result.skipped,
        ", failed=", result.failed,
        ", remaining=", result.remaining,
    )
    println("Campaign status: ", result.status_path)
    result.failed == 0 || error("$(result.failed) campaign job(s) failed")
    return result
end

end


if abspath(PROGRAM_FILE) == @__FILE__
    RunConstrainedPathAFQMCCampaign.main()
end
