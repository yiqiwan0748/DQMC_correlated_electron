#!/usr/bin/env julia

module EDStudy

ENV["GKSwstype"] = get(ENV, "GKSwstype", "100")

using AltermagnetDQMCTrial
using Plots

include(joinpath(@__DIR__, "hubbard_ed_benchmarks.jl"))
include(joinpath(@__DIR__, "two_orbital_atom_ed.jl"))
include(joinpath(@__DIR__, "two_orbital_cluster_ed.jl"))
include(joinpath(@__DIR__, "two_orbital_open_cluster_ed.jl"))

const Benchmarks = HubbardEDBenchmarks
const AtomED = TwoOrbitalAtomED
const PeriodicED = TwoOrbitalClusterED
const OpenED = TwoOrbitalOpenClusterED

export parse_options, run_study, main

const STUDY_LIMITATION =
    "Finite zero-field ED preserves spin symmetry and cannot select a " *
    "spontaneously ordered domain. Periodic 2x2 also cancels t4; the open " *
    "2x2 calculation is a t4-active finite-cluster response proxy, not a bulk Uc."

function usage(io=stdout)
    print(io, """
Usage: julia --project=. scripts/run_ed_study.jl [options]

  --mode=all|benchmarks|scan       Work to run [all]
  --output-dir=PATH                New output directory [results/ed_study]
  --U-min=0 --U-max=20 --U-step=1 Interaction scan
  --mu=-2.5157 --beta=10           Periodic thermal ensemble
  --particles=6                    Open 2x2 canonical particle count
  --probe-field=0.001              Explicit -h*O_alm response field
  --probe-field-ratio=0.1          Second field is this fraction of h
  --eta=0.15                       Lorentzian display width
  --omega-min=-30 --omega-max=30 --omega-points=1201
  --band-points=100 --dos-Nk=200 --dos-bins=400
  --t1=-1 --t2=-1.75 --t3=-0.85 --t4=-0.65
  --open-proxy=true --plots=true   Optional proxy scan and PNG summaries

Outputs are CSV plus metadata. Existing output directories are never replaced.
The fixed-mu scan is not fixed density. The open-cluster scan is fixed N.
""")
end

function _parse_bool(value::AbstractString, name::AbstractString)
    lowercase(value) == "true" && return true
    lowercase(value) == "false" && return false
    throw(ArgumentError("$name must be true or false"))
end

function _finite_float(value::AbstractString, name::AbstractString)
    parsed = parse(Float64, value)
    isfinite(parsed) || throw(ArgumentError("$name must be finite"))
    return parsed
end

function _positive_int(value::AbstractString, name::AbstractString; minimum=1)
    parsed = parse(Int, value)
    parsed >= minimum || throw(ArgumentError("$name must be at least $minimum"))
    return parsed
end

function _interaction_grid(first_value, last_value, step)
    first_value >= 0 || throw(ArgumentError("U-min must be nonnegative"))
    last_value >= first_value || throw(ArgumentError("U-max must be at least U-min"))
    step > 0 || throw(ArgumentError("U-step must be positive"))
    intervals = round(Int, (last_value - first_value) / step)
    isapprox(first_value + intervals * step, last_value; atol=1.0e-12, rtol=1.0e-12) ||
        throw(ArgumentError("U-step must land on U-max"))
    return collect(range(first_value, last_value; length=intervals + 1))
end

function parse_options(arguments=ARGS)
    any(argument -> argument in ("-h", "--help"), arguments) && return nothing
    raw = Dict{String,String}()
    allowed = Set([
        "mode", "output-dir", "U-min", "U-max", "U-step", "mu", "beta",
        "particles", "probe-field", "probe-field-ratio", "eta", "omega-min", "omega-max",
        "omega-points", "band-points", "dos-Nk", "dos-bins", "t1", "t2",
        "t3", "t4", "open-proxy", "plots",
    ])
    for argument in arguments
        startswith(argument, "--") && occursin('=', argument) ||
            throw(ArgumentError("options must use --name=value: $argument"))
        name, value = split(argument[3:end], '='; limit=2)
        name in allowed || throw(ArgumentError("unknown option --$name"))
        haskey(raw, name) && throw(ArgumentError("duplicate option --$name"))
        isempty(value) && throw(ArgumentError("--$name requires a value"))
        raw[name] = value
    end

    mode = Symbol(lowercase(get(raw, "mode", "all")))
    mode in (:all, :benchmarks, :scan) ||
        throw(ArgumentError("mode must be all, benchmarks, or scan"))
    U_min = _finite_float(get(raw, "U-min", "0"), "U-min")
    U_max = _finite_float(get(raw, "U-max", "20"), "U-max")
    U_step = _finite_float(get(raw, "U-step", "1"), "U-step")
    U_values = _interaction_grid(U_min, U_max, U_step)
    mu = _finite_float(get(raw, "mu", "-2.5157"), "mu")
    beta = _finite_float(get(raw, "beta", "10"), "beta")
    beta > 0 || throw(ArgumentError("beta must be positive"))
    particles = _positive_int(get(raw, "particles", "6"), "particles"; minimum=0)
    particles <= 16 || throw(ArgumentError("particles must lie in 0:16 for open 2x2"))
    iseven(particles) || throw(ArgumentError(
        "particles must be even for the compensated open-cluster response scan",
    ))
    probe_field = _finite_float(get(raw, "probe-field", "0.001"), "probe-field")
    probe_field > 0 || throw(ArgumentError("probe-field must be positive"))
    probe_field_ratio = _finite_float(
        get(raw, "probe-field-ratio", "0.1"),
        "probe-field-ratio",
    )
    0 < probe_field_ratio < 1 ||
        throw(ArgumentError("probe-field-ratio must lie strictly between zero and one"))
    eta = _finite_float(get(raw, "eta", "0.15"), "eta")
    eta > 0 || throw(ArgumentError("eta must be positive"))
    omega_min = _finite_float(get(raw, "omega-min", "-30"), "omega-min")
    omega_max = _finite_float(get(raw, "omega-max", "30"), "omega-max")
    omega_min < omega_max || throw(ArgumentError("omega-min must be below omega-max"))
    omega_points = _positive_int(get(raw, "omega-points", "1201"), "omega-points"; minimum=3)
    band_points = _positive_int(get(raw, "band-points", "100"), "band-points")
    dos_Nk = _positive_int(get(raw, "dos-Nk", "200"), "dos-Nk"; minimum=2)
    dos_bins = _positive_int(get(raw, "dos-bins", "400"), "dos-bins"; minimum=2)
    hopping = (
        t1=_finite_float(get(raw, "t1", "-1"), "t1"),
        t2=_finite_float(get(raw, "t2", "-1.75"), "t2"),
        t3=_finite_float(get(raw, "t3", "-0.85"), "t3"),
        t4=_finite_float(get(raw, "t4", "-0.65"), "t4"),
    )
    return (
        mode=mode,
        output_dir=abspath(get(raw, "output-dir", "results/ed_study")),
        U_values=U_values,
        mu=mu,
        beta=beta,
        particles=particles,
        probe_field=probe_field,
        probe_field_ratio=probe_field_ratio,
        eta=eta,
        omega=collect(range(omega_min, omega_max; length=omega_points)),
        band_points=band_points,
        dos_Nk=dos_Nk,
        dos_bins=dos_bins,
        hopping=hopping,
        open_proxy=_parse_bool(get(raw, "open-proxy", "true"), "open-proxy"),
        plots=_parse_bool(get(raw, "plots", "true"), "plots"),
    )
end

function _csv_value(value)
    if value isa AbstractString || value isa Symbol
        string_value = string(value)
        return occursin(',', string_value) || occursin('"', string_value) ?
            "\"" * replace(string_value, "\"" => "\"\"") * "\"" : string_value
    elseif value === missing || value === nothing
        return ""
    end
    return string(value)
end

function write_rows(path::AbstractString, rows)
    isempty(rows) && throw(ArgumentError("cannot write an empty CSV"))
    columns = collect(keys(first(rows)))
    all(row -> collect(keys(row)) == columns, rows) ||
        throw(ArgumentError("CSV rows must have identical columns"))
    open(path, "w") do io
        println(io, join(string.(columns), ','))
        for row in rows
            println(io, join((_csv_value(getproperty(row, column)) for column in columns), ','))
        end
    end
    return path
end

function _model_parameters(options, constructor)
    return constructor(; options.hopping...)
end

function _benchmark_outputs(destination, options)
    model = AltermagnetDQMCTrial.ModelParameters(; options.hopping...)
    band = band_path(points_per_segment=options.band_points, parameters=model)
    band_rows = [(
        coordinate=band.coordinate[index], kx=band.kx[index], ky=band.ky[index],
        lower_energy=band.lower_energy[index], upper_energy=band.upper_energy[index],
    ) for index in eachindex(band.coordinate)]
    write_rows(joinpath(destination, "two_orbital_band_structure.csv"), band_rows)

    samples = sample_band_energies(options.dos_Nk; parameters=model)
    dos = density_of_states(samples; bins=options.dos_bins, smoothing_width=0.05)
    dos_rows = [(
        energy=dos.energy[index], density_per_spin=dos.density[index],
        raw_count=dos.counts[index],
    ) for index in eachindex(dos.energy)]
    write_rows(joinpath(destination, "two_orbital_noninteracting_dos.csv"), dos_rows)

    dimer_rows = NamedTuple[]
    for U in unique([first(options.U_values), options.U_values[cld(length(options.U_values), 2)],
                     last(options.U_values)])
        result = Benchmarks.benchmark_hubbard_dimer(U)
        push!(dimer_rows, (
            U=U, passed=result.passed,
            spectrum_max_error=result.errors.spectrum,
            ground_energy_error=result.errors.ground_singlet_energy,
            spin_gap_error=result.errors.singlet_triplet_gap,
            double_occupancy_error=result.errors.ground_double_occupancy_total,
            exact_ground_energy=result.analytic.ground_singlet_energy,
            exact_spin_gap=result.analytic.singlet_triplet_gap,
        ))
    end
    write_rows(joinpath(destination, "hubbard_dimer_benchmark.csv"), dimer_rows)

    square = Benchmarks.square_l4_dos_oracle()
    square_rows = [(
        omega=square.poles[index], multiplicity_per_spin=square.multiplicities[index],
        weight_per_spin=square.weights[index],
    ) for index in eachindex(square.poles)]
    write_rows(joinpath(destination, "square_hubbard_L4_dos_oracle.csv"), square_rows)
    square_broadened = Benchmarks.lorentzian_broaden(
        square, options.omega; eta=options.eta, spin_summed=true,
    )
    write_rows(joinpath(destination, "square_hubbard_L4_dos_broadened.csv"), [(
        omega=options.omega[index], density_both_spins=square_broadened.density[index],
    ) for index in eachindex(options.omega)])

    atom_U = isempty(options.U_values) ? 4.0 : last(options.U_values)
    atom = AtomED.solve_two_orbital_atom(
        atom_U, 0.0, options.beta, [0.0, options.beta / 2, options.beta],
    )
    atom_broadened = AtomED.broaden_spectral_peaks(atom, options.omega; eta=options.eta)
    write_rows(joinpath(destination, "two_orbital_atom_spectrum.csv"), [(
        omega=options.omega[index], exact_lorentzian=atom_broadened.spectrum[index],
    ) for index in eachindex(options.omega)])
    write_rows(joinpath(destination, "two_orbital_atom_poles.csv"), [(
        omega=atom.peak_frequencies[index], weight=atom.peak_weights[index],
    ) for index in eachindex(atom.peak_frequencies)])

    periodic_model = _model_parameters(options, PeriodicED.ValidatedKinetic.ModelParameters)
    free_cluster = PeriodicED.solve_two_orbital_cluster(
        0.0, options.mu, options.beta, [0.0, options.beta]; parameters=periodic_model,
    )
    pairing = PeriodicED.spin_pairing_error(free_cluster)
    free_pole_error = 0.0
    for orbital in 1:2, ky in 1:2, kx in 1:2
        block = PeriodicED.ValidatedKinetic.bloch_hamiltonian(
            free_cluster.momenta[kx], free_cluster.momenta[ky], periodic_model,
        )
        expected = block[orbital, orbital] - options.mu
        channel = free_cluster.spectral_peaks[1, orbital, kx, ky]
        free_pole_error = max(free_pole_error, abs(only(channel.frequencies) - expected))
    end

    checkpoints = (
        ("Gamma lower", band_energies(0.0, 0.0, model)[1], 8.9),
        ("Gamma upper", band_energies(0.0, 0.0, model)[2], 8.9),
        ("X lower", band_energies(pi, 0.0, model)[1], -4.9),
        ("X upper", band_energies(pi, 0.0, model)[2], -1.9),
        ("M lower", band_energies(pi, pi, model)[1], -2.1),
        ("M upper", band_energies(pi, pi, model)[2], -2.1),
        ("pi/2 lower", band_energies(pi / 2, pi / 2, model)[1], -2.6),
        ("pi/2 upper", band_energies(pi / 2, pi / 2, model)[2], 2.6),
    )
    # Published checkpoint values apply to the repository's default hopping
    # parameters. For an overridden model, keep the numerical outputs but do
    # not pretend those default values are an oracle.
    default_hopping = options.hopping == (t1=-1.0, t2=-1.75, t3=-0.85, t4=-0.65)
    checkpoint_error = default_hopping ? maximum(abs(actual - expected)
        for (_, actual, expected) in checkpoints) : NaN
    enumerated_square_levels = sort([
        -2 * (cos(kx) + cos(ky))
        for kx in square.momenta for ky in square.momenta
    ])
    expanded_square_oracle = sort([
        pole
        for (pole, multiplicity) in zip(square.poles, square.multiplicities)
        for _ in 1:multiplicity
    ])
    square_level_error = maximum(abs, enumerated_square_levels - expanded_square_oracle)
    summary = [
        (benchmark="Hubbard dimer analytic spectrum", passed=all(row.passed for row in dimer_rows),
         max_abs_error=maximum(row.spectrum_max_error for row in dimer_rows),
         tolerance=1.0e-12, note="one orbital, one bond, centered interaction"),
        (benchmark="square Hubbard L4 DOS multiplicities",
         passed=sum(square.multiplicities) == 16 && square_level_error < 2.0e-15,
         max_abs_error=square_level_error, tolerance=2.0e-15,
         note="independent enumeration of all 16 momenta"),
        (benchmark="two-orbital Bloch checkpoints",
         passed=default_hopping ? checkpoint_error < 1.0e-12 : missing,
         max_abs_error=default_hopping ? checkpoint_error : missing, tolerance=1.0e-12,
         note=default_hopping ? "includes t4-sensitive pi/2 point" : "skipped for custom hopping"),
        (benchmark="periodic L2 U0 ED poles versus Bloch", passed=free_pole_error < 2.0e-10,
         max_abs_error=free_pole_error, tolerance=2.0e-10,
         note="L2 t4 cancels exactly"),
        (benchmark="periodic L2 spin pairing", passed=pairing.maximum < 2.0e-10,
         max_abs_error=pairing.maximum, tolerance=2.0e-10,
         note="zero-field symmetry check"),
        (benchmark="two-orbital atom spectral moment", passed=abs(atom.spectral_zeroth_moment - 1) < 2.0e-10,
         max_abs_error=abs(atom.spectral_zeroth_moment - 1), tolerance=2.0e-10,
         note="16-state interacting atomic ED"),
    ]
    write_rows(joinpath(destination, "benchmark_summary.csv"), summary)
    all(row -> ismissing(row.passed) || row.passed, summary) ||
        error("an ED benchmark failed; inspect benchmark_summary.csv")
    return (; band, dos, summary)
end

function _periodic_scan_outputs(destination, options)
    model = _model_parameters(options, PeriodicED.ValidatedKinetic.ModelParameters)
    scan = PeriodicED.scan_spin_degeneracy(
        options.U_values, options.mu, options.beta;
        parameters=model,
        omega=options.omega,
        eta=options.eta,
    )
    write_rows(joinpath(destination, "periodic_L2_spin_scan.csv"), scan.rows)

    endpoint_spectra = Dict{Float64,Any}()
    for U in unique((first(options.U_values), last(options.U_values)))
        exact = PeriodicED.solve_two_orbital_cluster(
            U, options.mu, options.beta, [0.0, options.beta / 2, options.beta];
            parameters=model,
        )
        broadened = PeriodicED.broaden_cluster_spectra(exact, options.omega; eta=options.eta)
        endpoint_spectra[U] = broadened
        token = replace(string(U), '.' => 'p')
        write_rows(joinpath(destination, "periodic_L2_dos_U$(token).csv"), [(
            omega=options.omega[index],
            dos_up=broadened.dos[1, index],
            dos_down=broadened.dos[2, index],
            dos_total=broadened.total_dos[index],
        ) for index in eachindex(options.omega)])
        labels = ((1, 1, "Gamma"), (2, 1, "X"), (1, 2, "Y"), (2, 2, "M"))
        spectral_rows = NamedTuple[]
        for (kx, ky, label) in labels, spin in 1:2, index in eachindex(options.omega)
            push!(spectral_rows, (
                momentum=label, spin=spin == 1 ? "up" : "down",
                omega=options.omega[index],
                orbital_trace_spectrum=broadened.spin_trace[spin, kx, ky, index],
            ))
        end
        write_rows(joinpath(destination, "periodic_L2_spectral_U$(token).csv"), spectral_rows)
    end
    return merge(scan, (; endpoint_spectra))
end

function _next_distinct_gap(sectors, ground_energy, tolerance)
    excitations = [row.energy - ground_energy for row in sectors
                   if row.energy - ground_energy > tolerance]
    return isempty(excitations) ? missing : minimum(excitations)
end

function _field_probe(kinetic, U, Nup, Ndown, h, zero_field_energy, number_of_cells)
    plus = OpenED.ground_state_observables(kinetic, U, Nup, Ndown; h=h)
    minus = OpenED.ground_state_observables(kinetic, U, Nup, Ndown; h=-h)
    secant_response = (plus.oalm - minus.oalm) / (2h * number_of_cells)
    energy_curvature_response = -(
        plus.energy + minus.energy - 2zero_field_energy
    ) / (h^2 * number_of_cells)
    return (;
        h,
        plus,
        minus,
        secant_response,
        energy_curvature_response,
        odd_oalm_per_cell=(plus.oalm - minus.oalm) / (2number_of_cells),
        even_oalm2_per_cell=(plus.oalm2 + minus.oalm2) / (2number_of_cells),
        even_m_alm_squared=(plus.oalm2 + minus.oalm2) / (2number_of_cells^2),
        even_double_occupancy_per_cell=(
            plus.double_occupancy + minus.double_occupancy
        ) / (2number_of_cells),
        reversal_energy_error=abs(plus.energy - minus.energy),
        reversal_oalm_odd_error=abs(plus.oalm + minus.oalm),
    )
end

function _open_proxy_outputs(destination, options)
    model = _model_parameters(options, OpenED.ModelParameters)
    kinetic = OpenED.open_cluster_kinetic_matrix(2, 2, model)
    Nup = options.particles ÷ 2
    Ndown = options.particles ÷ 2
    number_of_cells = 4
    rows = NamedTuple[]
    sector_rows = NamedTuple[]
    for U in options.U_values
        sectors = OpenED.canonical_spin_sector_energies(kinetic, U, options.particles)
        ground_energy = minimum(row.energy for row in sectors)
        maximum_sector_residual = maximum(row.residual for row in sectors)
        tolerance = max(
            1.0e-10 * max(1.0, abs(ground_energy)),
            2maximum_sector_residual,
        )
        ground_sectors = [row for row in sectors if abs(row.energy - ground_energy) <= tolerance]
        maximum_ground_abs_Sz = maximum(abs(row.Sz) for row in ground_sectors)
        balanced = only(row for row in sectors if row.Nup == Nup && row.Ndown == Ndown)
        primary = _field_probe(
            kinetic, U, Nup, Ndown, options.probe_field,
            balanced.energy, number_of_cells,
        )
        reduced = _field_probe(
            kinetic, U, Nup, Ndown,
            options.probe_field * options.probe_field_ratio,
            balanced.energy, number_of_cells,
        )
        pairing_error = OpenED.spin_flip_error(sectors)
        push!(rows, (
            U=U,
            particles=options.particles,
            density=options.particles / number_of_cells,
            ground_energy_per_cell=ground_energy / number_of_cells,
            maximum_abs_Sz_in_ground_manifold=maximum_ground_abs_Sz,
            ground_manifold_membership_tolerance=tolerance,
            next_spin_sector_gap=_next_distinct_gap(sectors, ground_energy, tolerance),
            spin_flip_energy_max_error=pairing_error,
            probe_field=options.probe_field,
            finite_field_odd_oalm_per_cell=primary.odd_oalm_per_cell,
            finite_field_even_S_alm_q0=primary.even_oalm2_per_cell,
            finite_field_even_m_alm_squared=primary.even_m_alm_squared,
            finite_field_even_double_occupancy_per_cell=
                primary.even_double_occupancy_per_cell,
            finite_field_secant_response_per_cell=primary.secant_response,
            finite_field_energy_curvature_response_per_cell=
                primary.energy_curvature_response,
            reduced_probe_field=reduced.h,
            reduced_field_secant_response_per_cell=reduced.secant_response,
            reduced_field_energy_curvature_response_per_cell=
                reduced.energy_curvature_response,
            response_relative_change=abs(
                reduced.secant_response - primary.secant_response,
            ) / max(abs(reduced.secant_response), eps(Float64)),
            field_reversal_energy_error=max(
                primary.reversal_energy_error,
                reduced.reversal_energy_error,
            ),
            field_reversal_oalm_odd_error=max(
                primary.reversal_oalm_odd_error,
                reduced.reversal_oalm_odd_error,
            ),
            maximum_solver_residual=max(
                maximum_sector_residual,
                primary.plus.residual,
                primary.minus.residual,
                reduced.plus.residual,
                reduced.minus.residual,
            ),
            spontaneous_breaking_assessable=false,
        ))
        for sector in sectors
            push!(sector_rows, (
                U=U, Nup=sector.Nup, Ndown=sector.Ndown, Sz=sector.Sz,
                energy=sector.energy, dimension=sector.dimension,
                residual=sector.residual, iterations=sector.iterations,
                method=sector.method,
            ))
        end
    end
    write_rows(joinpath(destination, "open_L2_canonical_scan.csv"), rows)
    write_rows(joinpath(destination, "open_L2_spin_sectors.csv"), sector_rows)
    return (rows=rows, kinetic=kinetic)
end

function _write_metadata(destination, options; periodic_scan=nothing, open_scan=nothing)
    open(joinpath(destination, "metadata.txt"), "w") do io
        println(io, "Exact-diagonalization benchmark and finite-cluster study")
        println(io, "mode=$(options.mode)")
        println(io, "U_values=$(options.U_values)")
        println(io, "periodic thermal parameters: mu_code=$(options.mu), beta=$(options.beta)")
        println(io, "fixed mu_code is not fixed density; mu_standard=mu_code+U/2")
        println(io, "open 2x2 canonical particles=$(options.particles), density=$(options.particles/4)")
        println(io, "open probe field=$(options.probe_field), coupled as -h*O_alm")
        println(io, "open reduced probe field=$(options.probe_field * options.probe_field_ratio)")
        println(io, "finite-field secants are h-dependent response diagnostics, not h->0 susceptibilities")
        println(io, "zero-field single-eigenvector observables are omitted because degenerate subspaces make them basis-dependent")
        println(io, "hopping=$(options.hopping)")
        println(io, "Lorentzian eta=$(options.eta); retained ED poles have weight > 100*eps(Float64)")
        println(io, "periodic 2x2 t4 cancellation=true")
        println(io, "open 2x2 t4 active=$(open_scan === nothing ? "not run" : maximum(abs, open_scan.kinetic[1:2:end,2:2:end]) > 0)")
        if periodic_scan !== nothing
            println(io, "periodic first numerical spin-audit failure U=$(periodic_scan.first_audit_failure_U)")
            println(io, "periodic maximum spin-pairing error=$(maximum(row.maximum_spin_pairing_error for row in periodic_scan.rows))")
        end
        if open_scan !== nothing
            println(io, "open maximum spin-flip sector error=$(maximum(row.spin_flip_energy_max_error for row in open_scan.rows))")
            println(io, "open result is a boundary- and size-dependent response proxy")
        end
        println(io, STUDY_LIMITATION)
        println(io, "A thermodynamic Uc requires size scaling and h->0 after the thermodynamic limit.")
    end
end

function _plot_outputs(destination, options; benchmarks=nothing, periodic_scan=nothing, open_scan=nothing)
    if benchmarks !== nothing
        band = benchmarks.band
        dos = benchmarks.dos
        band_plot = Plots.plot(
            band.coordinate, band.lower_energy;
            label="lower", color=:navy, linewidth=2,
            xlabel="momentum path", ylabel="energy (input units)",
            xticks=(band.tick_positions, band.tick_labels),
            title="Two-orbital band structure", legend=:topright,
        )
        Plots.plot!(band_plot, band.coordinate, band.upper_energy;
                    label="upper", color=:orangered, linewidth=2)
        dos_plot = Plots.plot(
            dos.energy, dos.density;
            label="per spin", color=:black, linewidth=2,
            xlabel="energy (input units)", ylabel="DOS",
            title="Noninteracting DOS", legend=:topright,
        )
        Plots.savefig(
            Plots.plot(band_plot, dos_plot; layout=(1, 2), size=(1100, 430)),
            joinpath(destination, "band_and_dos_benchmarks.png"),
        )
    end

    if periodic_scan !== nothing
        interactions = [row.U for row in periodic_scan.rows]
        errors = [max(row.maximum_spin_pairing_error, eps(Float64))
                  for row in periodic_scan.rows]
        error_plot = Plots.plot(
            interactions, errors;
            marker=:circle, linewidth=2, yscale=:log10,
            label="max spin-pairing error", xlabel="U (input units)",
            ylabel="absolute difference", title="Zero-field spin audit",
        )
        Plots.hline!(error_plot, [periodic_scan.tolerance];
                     label="audit tolerance", linestyle=:dash, color=:red)
        density_plot = Plots.plot(
            interactions, [row.density for row in periodic_scan.rows];
            marker=:circle, linewidth=2, label="density", xlabel="U (input units)",
            ylabel="electrons/cell", title="Fixed-mu periodic L=2 scan",
        )
        Plots.savefig(
            Plots.plot(error_plot, density_plot; layout=(1, 2), size=(1100, 430)),
            joinpath(destination, "periodic_L2_spin_scan.png"),
        )

        spectral_plots = Any[]
        for U in sort!(collect(keys(periodic_scan.endpoint_spectra)))
            broadened = periodic_scan.endpoint_spectra[U]
            panel = Plots.plot(
                broadened.omega, broadened.dos[1, :];
                label="up", color=:red, linewidth=2, xlabel="omega (input units)",
                ylabel="DOS per spin", title="Periodic L=2, U=$(U)",
            )
            Plots.plot!(panel, broadened.omega, broadened.dos[2, :];
                        label="down", color=:blue, linewidth=2, linestyle=:dash)
            push!(spectral_plots, panel)
        end
        Plots.savefig(
            Plots.plot(spectral_plots...; layout=(1, length(spectral_plots)), size=(1100, 430)),
            joinpath(destination, "periodic_L2_endpoint_dos.png"),
        )
    end

    if open_scan !== nothing
        interactions = [row.U for row in open_scan.rows]
        correlation_plot = Plots.plot(
            interactions, [row.finite_field_even_m_alm_squared for row in open_scan.rows];
            marker=:circle, linewidth=2, label="finite-h <Oalm^2>/Nc^2",
            xlabel="U (input units)", ylabel="finite-cluster diagnostic",
            title="Open L=2, fixed N=$(options.particles)",
        )
        response_plot = Plots.plot(
            interactions,
            [row.finite_field_secant_response_per_cell for row in open_scan.rows];
            marker=:diamond, linewidth=2, label="h=$(options.probe_field)",
            xlabel="U (input units)", ylabel="secant response (1/energy/cell)",
            title="Explicit-field response",
        )
        Plots.plot!(response_plot, interactions,
            [row.reduced_field_secant_response_per_cell for row in open_scan.rows];
            marker=:circle, linewidth=2,
            label="h=$(options.probe_field * options.probe_field_ratio)")
        gap_plot = Plots.plot(
            interactions,
            [ismissing(row.next_spin_sector_gap) ? NaN : row.next_spin_sector_gap
             for row in open_scan.rows];
            marker=:circle, linewidth=2, label="spin-sector gap",
            xlabel="U (input units)", ylabel="energy (input units)",
            title="Open-cluster level diagnostic",
        )
        Plots.savefig(
            Plots.plot(correlation_plot, response_plot, gap_plot;
                       layout=(1, 3), size=(1500, 430)),
            joinpath(destination, "open_L2_altermagnetic_proxy.png"),
        )
    end
    return nothing
end

function run_study(options)
    if options.mode in (:all, :benchmarks) && all(iszero, values(options.hopping))
        throw(ArgumentError(
            "the band/DOS benchmark needs at least one nonzero hopping; " *
            "use two_orbital_atom_ed.jl for the zero-hopping atomic limit",
        ))
    end
    ispath(options.output_dir) && throw(ArgumentError(
        "refusing to overwrite output directory: $(options.output_dir)",
    ))
    parent = dirname(options.output_dir)
    mkpath(parent)
    staging = mktempdir(parent; prefix=".$(basename(options.output_dir)).tmp-")
    try
        benchmarks = nothing
        periodic_scan = nothing
        open_scan = nothing
        if options.mode in (:all, :benchmarks)
            benchmarks = _benchmark_outputs(staging, options)
        end
        if options.mode in (:all, :scan)
            periodic_scan = _periodic_scan_outputs(staging, options)
            if options.open_proxy
                open_scan = _open_proxy_outputs(staging, options)
            end
        end
        _write_metadata(staging, options; periodic_scan=periodic_scan, open_scan=open_scan)
        options.plots && _plot_outputs(
            staging,
            options;
            benchmarks=benchmarks,
            periodic_scan=periodic_scan,
            open_scan=open_scan,
        )
        mv(staging, options.output_dir)
        return (
            output_dir=options.output_dir,
            benchmarks=benchmarks,
            periodic_scan=periodic_scan,
            open_scan=open_scan,
            limitation=STUDY_LIMITATION,
        )
    catch
        ispath(staging) && rm(staging; recursive=true)
        rethrow()
    end
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        usage()
        return nothing
    end
    result = run_study(options)
    println(STUDY_LIMITATION)
    if result.periodic_scan !== nothing
        println("Periodic L2 first numerical spin-audit failure U = ",
                result.periodic_scan.first_audit_failure_U)
    end
    println("Saved ED study to ", result.output_dir)
    return result
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    try
        EDStudy.main()
    catch exception
        println(stderr, "ERROR: ", sprint(showerror, exception))
        println(stderr, "Run with --help for usage.")
        exit(1)
    end
end
