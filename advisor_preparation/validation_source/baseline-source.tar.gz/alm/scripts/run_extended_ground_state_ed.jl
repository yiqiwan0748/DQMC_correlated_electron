#!/usr/bin/env julia

module ExtendedGroundStateED

ENV["GKSwstype"] = get(ENV, "GKSwstype", "100")

using Dates
using LinearAlgebra
using Printf
import Plots

include(joinpath(@__DIR__, "two_orbital_cluster_ed.jl"))
include(joinpath(@__DIR__, "two_orbital_ground_observables.jl"))
include(joinpath(@__DIR__, "two_orbital_twisted_cluster_ed.jl"))
include(joinpath(@__DIR__, "two_orbital_tilted_cluster_ed.jl"))

const PeriodicED = TwoOrbitalClusterED
const GroundObservables = TwoOrbitalGroundObservables
const TwistedED = TwoOrbitalTwistedClusterED
const TiltedED = TwoOrbitalTiltedClusterED

export main, parse_options, run_extended_study, usage

const DEFAULT_DETAIL_U = [0.0, 2.0, 3.0, 4.0, 8.0, 10.0, 12.0, 20.0]
const DEFAULT_TWIST_U = [0.0, 2.0, 4.0, 8.0, 10.0, 12.0, 20.0]
const AUDIT_TOLERANCE = 2.0e-10

function usage(io::IO=stdout)
    print(io, """
Usage: julia --project=. scripts/run_extended_ground_state_ed.jl [options]

  --output-dir=PATH                   New output directory
                                        [results/extended_ground_state_ed]
  --particle-numbers=5,6              Periodic fixed-N scans
  --U-min=0 --U-max=20 --U-step=1    Periodic interaction grid
  --detail-particle-number=6          N for S2/C4/dynamics/self-energy
  --detail-U=0,2,3,4,8,10,12,20      Detailed periodic checkpoints
  --twist-particle-numbers=5,6        Fixed-N generic-twist scans
  --twist-U=0,2,4,8,10,12,20         Generic-twist checkpoints
  --theta-x=0.37 --theta-y=-0.61     Boundary twists in radians
  --twist-maxiter=350                 Lanczos iteration ceiling
  --matsubara=0.25,0.5,1,2,4         Positive imaginary frequencies
  --manifolds=4                       Low-energy manifolds to classify
  --t1=-1 --t2=-1.75 --t3=-0.85 --t4=-0.65
  --plots=true|false                  Write compact PNG summaries [true]

This is a zero-temperature canonical study.  N=5 and N=6 correspond to
n=1.25 and n=1.5 on four cells; n=1.42 is not an integer-N pure ground state.
The generic twist activates t4 but does not create spontaneous symmetry
breaking in a finite Hamiltonian.  The eight-site target N=12 sector is
resource-audited and deliberately refused locally; only small-sector Lanczos
proofs are run on this machine.
""")
end

function _finite_float(text::AbstractString, name::AbstractString)
    value = try
        parse(Float64, text)
    catch
        throw(ArgumentError("--$name must be a real number"))
    end
    isfinite(value) || throw(ArgumentError("--$name must be finite"))
    return value
end

function _positive_integer(text::AbstractString, name::AbstractString)
    value = try
        parse(Int, text)
    catch
        throw(ArgumentError("--$name must be an integer"))
    end
    value > 0 || throw(ArgumentError("--$name must be positive"))
    return value
end

function _float_list(text::AbstractString, name::AbstractString)
    entries = split(text, ',')
    all(entry -> !isempty(strip(entry)), entries) ||
        throw(ArgumentError("--$name must be a comma-separated number list"))
    values = [_finite_float(strip(entry), name) for entry in entries]
    isempty(values) && throw(ArgumentError("--$name must not be empty"))
    length(unique(values)) == length(values) ||
        throw(ArgumentError("--$name contains a duplicate"))
    return values
end

function _integer_list(text::AbstractString, name::AbstractString)
    values = Int[]
    for entry in split(text, ',')
        stripped = strip(entry)
        isempty(stripped) && throw(ArgumentError(
            "--$name must be a comma-separated integer list",
        ))
        value = try
            parse(Int, stripped)
        catch
            throw(ArgumentError("--$name must contain only integers"))
        end
        push!(values, value)
    end
    length(unique(values)) == length(values) ||
        throw(ArgumentError("--$name contains a duplicate"))
    return values
end

function _boolean(text::AbstractString, name::AbstractString)
    lowercase(text) == "true" && return true
    lowercase(text) == "false" && return false
    throw(ArgumentError("--$name must be true or false"))
end

function _interaction_grid(first_value, last_value, step)
    first_value >= 0 || throw(ArgumentError("--U-min must be nonnegative"))
    last_value >= first_value || throw(ArgumentError(
        "--U-max must be at least --U-min",
    ))
    step > 0 || throw(ArgumentError("--U-step must be positive"))
    intervals = round(Int, (last_value - first_value) / step)
    isapprox(first_value + intervals * step, last_value;
             atol=1.0e-12, rtol=1.0e-12) || throw(ArgumentError(
        "--U-step must land on --U-max",
    ))
    return collect(range(first_value, last_value; length=intervals + 1))
end

function parse_options(arguments=ARGS)
    any(argument -> argument in ("-h", "--help"), arguments) && return nothing
    allowed = Set([
        "output-dir", "particle-numbers", "U-min", "U-max", "U-step",
        "detail-particle-number", "detail-U", "twist-particle-numbers",
        "twist-U", "theta-x", "theta-y", "twist-maxiter", "matsubara",
        "manifolds", "t1", "t2", "t3", "t4", "plots",
    ])
    raw = Dict{String,String}()
    for argument in arguments
        startswith(argument, "--") && occursin('=', argument) ||
            throw(ArgumentError("options must use --name=value: $argument"))
        name, value = split(argument[3:end], '='; limit=2)
        name in allowed || throw(ArgumentError("unknown option --$name"))
        haskey(raw, name) && throw(ArgumentError("duplicate option --$name"))
        raw[name] = value
    end

    particle_numbers = _integer_list(
        get(raw, "particle-numbers", "5,6"), "particle-numbers",
    )
    all(N -> 1 <= N <= 15, particle_numbers) || throw(ArgumentError(
        "--particle-numbers entries must lie in 1:15",
    ))
    detail_N = _positive_integer(
        get(raw, "detail-particle-number", "6"), "detail-particle-number",
    )
    1 <= detail_N <= 15 || throw(ArgumentError(
        "--detail-particle-number must lie in 1:15",
    ))
    twist_particle_numbers = _integer_list(
        get(raw, "twist-particle-numbers", "5,6"),
        "twist-particle-numbers",
    )
    all(N -> 0 <= N <= 16, twist_particle_numbers) || throw(ArgumentError(
        "--twist-particle-numbers entries must lie in 0:16",
    ))
    U_values = _interaction_grid(
        _finite_float(get(raw, "U-min", "0"), "U-min"),
        _finite_float(get(raw, "U-max", "20"), "U-max"),
        _finite_float(get(raw, "U-step", "1"), "U-step"),
    )
    detail_U = _float_list(
        get(raw, "detail-U", join(DEFAULT_DETAIL_U, ',')), "detail-U",
    )
    twist_U = _float_list(
        get(raw, "twist-U", join(DEFAULT_TWIST_U, ',')), "twist-U",
    )
    all(>=(0), detail_U) || throw(ArgumentError("--detail-U must be nonnegative"))
    all(>=(0), twist_U) || throw(ArgumentError("--twist-U must be nonnegative"))
    matsubara = _float_list(
        get(raw, "matsubara", "0.25,0.5,1,2,4"), "matsubara",
    )
    all(>(0), matsubara) || throw(ArgumentError(
        "--matsubara values must be positive",
    ))
    hopping = (
        t1=_finite_float(get(raw, "t1", "-1"), "t1"),
        t2=_finite_float(get(raw, "t2", "-1.75"), "t2"),
        t3=_finite_float(get(raw, "t3", "-0.85"), "t3"),
        t4=_finite_float(get(raw, "t4", "-0.65"), "t4"),
    )
    return (
        output_dir=abspath(get(
            raw, "output-dir", "results/extended_ground_state_ed",
        )),
        particle_numbers=particle_numbers,
        U_values=U_values,
        detail_particle_number=detail_N,
        detail_U=detail_U,
        twist_particle_numbers=twist_particle_numbers,
        twist_U=twist_U,
        theta_x=_finite_float(get(raw, "theta-x", "0.37"), "theta-x"),
        theta_y=_finite_float(get(raw, "theta-y", "-0.61"), "theta-y"),
        twist_maxiter=_positive_integer(
            get(raw, "twist-maxiter", "350"), "twist-maxiter",
        ),
        matsubara=matsubara,
        manifolds=_positive_integer(get(raw, "manifolds", "4"), "manifolds"),
        hopping=hopping,
        plots=_boolean(get(raw, "plots", "true"), "plots"),
    )
end

function _csv_value(value)
    value === missing && return ""
    value === nothing && return ""
    text = string(value)
    if occursin(',', text) || occursin('"', text) || occursin('\n', text)
        return "\"" * replace(text, "\"" => "\"\"") * "\""
    end
    return text
end

function _write_rows(path::AbstractString, rows)
    isempty(rows) && throw(ArgumentError("cannot write an empty CSV table: $path"))
    columns = collect(keys(first(rows)))
    all(row -> collect(keys(row)) == columns, rows) || throw(ArgumentError(
        "CSV rows must have identical columns: $path",
    ))
    open(path, "w") do io
        println(io, join(string.(columns), ','))
        for row in rows
            println(io, join(
                (_csv_value(getproperty(row, column)) for column in columns), ',',
            ))
        end
    end
    return path
end

function _fmt_float(value)
    converted = Float64(value)
    return @sprintf("%.12g", iszero(converted) ? 0.0 : converted)
end
_fmt_sector(pair) = "$(pair[1]):$(pair[2])"
_fmt_spin_content(content) = join((
    "S=$(_fmt_float(row.S)):states=$(row.state_count):irreps=$(_fmt_float(row.irrep_count))"
    for row in content
), ';')
_fmt_c4_content(content) = join((
    "$(row.eigenvalue):$(row.count)" for row in content
), ';')
_fmt_joint_content(content) = join((
    "S=$(_fmt_float(row.S)):C4=$(row.c4):states=$(row.state_count)"
    for row in content
), ';')

function _periodic_scan(options, parameters)
    results = Dict{Tuple{Int,Float64},Any}()
    rows = NamedTuple[]
    for N in options.particle_numbers, U in options.U_values
        result = PeriodicED.solve_two_orbital_ground_state(
            U, N; parameters=parameters, h_alm=0.0,
            degeneracy_tolerance=AUDIT_TOLERANCE,
        )
        audit = PeriodicED.ground_state_spin_pairing_error(result)
        results[(N, Float64(U))] = result
        push!(rows, (
            U=Float64(U), N=N, density=result.density,
            ground_energy=result.ground_energy,
            ground_energy_per_cell=result.ground_energy_per_cell,
            ground_degeneracy=result.ground_degeneracy,
            ground_max_abs_Sz=maximum(abs(level.Sz) for level in result.ground_levels),
            ground_spin_sectors=join(unique(
                _fmt_sector((level.Nup, level.Ndown)) for level in result.ground_levels
            ), ';'),
            ground_momenta=join(unique(
                "$(level.kx_index-1):$(level.ky_index-1)"
                for level in result.ground_levels
            ), ';'),
            same_N_gap=result.same_N_gap,
            charge_gap=result.charge_gap,
            mu_minus=result.mu_minus, mu_plus=result.mu_plus,
            mu_reference=result.mu_reference,
            double_occupancy_per_cell=result.double_occupancy,
            oalm=result.o_alm, oalm2_per_cell2=result.o_alm2_per_cell2,
            delta_alm_per_cell=result.delta_alm_per_cell,
            spin_sector_energy_error=audit.sector_energy,
            spectral_frequency_spin_error=audit.frequency,
            spectral_weight_spin_error=audit.weight,
            maximum_spin_audit_error=audit.maximum,
            spectral_sum_rule_error=result.spectral_moment_max_error,
            spin_audit_passed=audit.maximum <= AUDIT_TOLERANCE,
        ))
    end
    return results, rows
end

function _interpolation_rows(options, results)
    5 in options.particle_numbers && 6 in options.particle_numbers || return NamedTuple[]
    rows = NamedTuple[]
    # n=1.42 on four cells means <N>=5.68.  These are convex-mixture weights,
    # not a pure canonical state and not a substitute for finite-size scaling.
    weight_N6 = 4 * 1.42 - 5
    weight_N5 = 1 - weight_N6
    for U in options.U_values
        five = results[(5, Float64(U))]
        six = results[(6, Float64(U))]
        push!(rows, (
            U=Float64(U), target_density=1.42,
            weight_N5=weight_N5, weight_N6=weight_N6,
            formal_mixed_energy_per_cell=
                weight_N5 * five.ground_energy_per_cell +
                weight_N6 * six.ground_energy_per_cell,
            formal_mixed_double_occupancy_per_cell=
                weight_N5 * five.double_occupancy +
                weight_N6 * six.double_occupancy,
            formal_mixed_oalm2_per_cell2=
                weight_N5 * five.o_alm2_per_cell2 +
                weight_N6 * six.o_alm2_per_cell2,
            interpretation="formal N=5/N=6 convex ensemble; not a pure finite-cluster ground state",
        ))
    end
    return rows
end

function _symmetry_tables(options, parameters)
    manifold_rows = NamedTuple[]
    level_rows = NamedTuple[]
    spin_gap_rows = NamedTuple[]
    N = options.detail_particle_number
    for U in options.detail_U
        result = GroundObservables.classify_ground_symmetries(
            U, N; parameters=parameters, manifolds=options.manifolds,
            tolerance=AUDIT_TOLERANCE,
        )
        for manifold in result.manifolds
            push!(manifold_rows, (
                U=Float64(U), N=N, manifold=manifold.index,
                energy=manifold.energy,
                excitation_energy=manifold.excitation_energy,
                degeneracy=manifold.degeneracy,
                spin_content=_fmt_spin_content(manifold.spin_content),
                c4_content=_fmt_c4_content(manifold.c4_content),
                joint_spin_c4_content=_fmt_joint_content(
                    manifold.joint_spin_c4_content,
                ),
                gram_residual=manifold.gram_residual,
                s2_quantization_residual=manifold.s2_quantization_residual,
                c4_unitarity_residual=manifold.c4_unitarity_residual,
                c4_leakage=manifold.c4_leakage,
                c4_spin_commutator=manifold.c4_spin_commutator,
            ))
        end
        for level in result.sector_levels
            push!(level_rows, (
                U=Float64(U), N=N,
                manifold=level.manifold,
                energy=level.energy,
                excitation_energy=level.excitation_energy,
                Nup=level.Nup, Ndown=level.Ndown, Sz=level.Sz,
                kx=level.kx, ky=level.ky,
                kx_index=level.kx_index - 1,
                ky_index=level.ky_index - 1,
                orbital1_Nup=level.orbital1_Nup,
                orbital1_Ndown=level.orbital1_Ndown,
                orbital1_eigen_index=level.orbital1_eigen_index,
                orbital2_Nup=level.orbital2_Nup,
                orbital2_Ndown=level.orbital2_Ndown,
                orbital2_eigen_index=level.orbital2_eigen_index,
            ))
        end
        lower_spin = iseven(N) ? 0.0 : 0.5
        upper_spin = lower_spin + 1.0
        lower_energies = [
            manifold.energy for manifold in result.manifolds
            if any(row.S == lower_spin for row in manifold.spin_content)
        ]
        upper_energies = [
            manifold.energy for manifold in result.manifolds
            if any(row.S == upper_spin for row in manifold.spin_content)
        ]
        resolved = !isempty(lower_energies) && !isempty(upper_energies)
        push!(spin_gap_rows, (
            U=Float64(U), N=N,
            lower_spin=lower_spin, upper_spin=upper_spin,
            lower_spin_energy=resolved ? minimum(lower_energies) : missing,
            upper_spin_energy=resolved ? minimum(upper_energies) : missing,
            spin_multiplet_gap=resolved ?
                minimum(upper_energies) - minimum(lower_energies) : missing,
            resolved_within_requested_manifolds=resolved,
            manifolds_searched=options.manifolds,
            convention="E0(N,S=$(upper_spin))-E0(N,S=$(lower_spin))",
        ))
    end
    return manifold_rows, level_rows, spin_gap_rows
end

function _correlation_tables(options, parameters)
    summaries = NamedTuple[]
    peaks = NamedTuple[]
    N = options.detail_particle_number
    for U in options.detail_U
        suite = GroundObservables.ground_state_correlation_suite(
            U, N; parameters=parameters, tolerance=AUDIT_TOLERANCE,
            normalization=:sqrt_cells,
        )
        selected = sort!(collect(suite.channels); by=entry -> string(first(entry)))
        channels = [last(entry) for entry in selected]
        push!(channels, suite.o_alm)
        for channel in channels
            nx, ny = channel.momentum_indices
            push!(summaries, (
                U=Float64(U), N=N,
                operator=string(channel.requested_operator),
                canonical_operator=string(channel.operator),
                qx_index=nx, qy_index=ny,
                normalization=string(channel.normalization),
                mean=channel.mean, equal_time=channel.equal_time,
                connected_equal_time=channel.connected_equal_time,
                elastic_weight=channel.elastic_weight,
                inelastic_weight=channel.inelastic_weight,
                regular_inelastic_static_susceptibility=
                    channel.regular_inelastic_static_susceptibility,
                susceptibility_status=string(channel.susceptibility_status),
                lehmann_sum_rule_residual=channel.lehmann_sum_rule_residual,
                retarded_commutator_vanishes=
                    channel.retarded_commutator_vanishes,
                ground_degeneracy=channel.ground_degeneracy,
            ))
            for (frequency, weight) in
                zip(channel.peaks.frequencies, channel.peaks.weights)
                push!(peaks, (
                    U=Float64(U), N=N,
                    operator=string(channel.requested_operator),
                    qx_index=nx, qy_index=ny,
                    normalization=string(channel.normalization),
                    frequency=frequency, weight=weight,
                ))
            end
        end
    end
    return summaries, peaks
end

function _self_energy_rows(options, parameters, periodic_results)
    rows = NamedTuple[]
    N = options.detail_particle_number
    for U in options.detail_U
        result = get(periodic_results, (N, Float64(U)), nothing)
        isnothing(result) && (result = PeriodicED.solve_two_orbital_ground_state(
            U, N; parameters=parameters, h_alm=0.0,
            degeneracy_tolerance=AUDIT_TOLERANCE,
        ))
        evaluated = GroundObservables.noninteracting_cluster_self_energy(
            result, im .* options.matsubara,
        )
        for point in eachindex(evaluated.z), spin in 1:2, orbital in 1:2,
            ky in 1:2, kx in 1:2
            value = evaluated.values[spin, orbital, kx, ky, point]
            green = evaluated.green[spin, orbital, kx, ky, point]
            push!(rows, (
                U=Float64(U), N=N, spin=spin == 1 ? "up" : "down",
                orbital=orbital == 1 ? "dxz" : "dyz",
                kx_index=kx - 1, ky_index=ky - 1,
                omega_n=options.matsubara[point],
                green_real=real(green), green_imag=imag(green),
                self_energy_real=real(value), self_energy_imag=imag(value),
                valid=evaluated.valid[spin, orbital, kx, ky, point],
                at_green_pole=evaluated.at_green_pole[spin, orbital, kx, ky, point],
                near_green_zero=evaluated.near_green_zero[spin, orbital, kx, ky, point],
                mu_reference=evaluated.mu_reference,
            ))
        end
    end
    return rows
end

function _twist_tables(options, parameters)
    summary_rows = NamedTuple[]
    point_rows = NamedTuple[]
    twisted_parameters = TwistedED.ModelParameters(
        parameters.t1, parameters.t2, parameters.t3, parameters.t4,
    )
    zero_kinetic = TwistedED.twisted_cluster_kinetic_matrix(
        2, 0.0, 0.0, twisted_parameters,
    )
    generic_kinetic = TwistedED.twisted_cluster_kinetic_matrix(
        2, options.theta_x, options.theta_y, twisted_parameters,
    )
    c4 = TwistedED.c4_single_particle_unitary(
        2, options.theta_x, options.theta_y,
    )
    c4_target = TwistedED.twisted_cluster_kinetic_matrix(
        2, -options.theta_y, options.theta_x, twisted_parameters,
    )
    check = (
        theta_x=options.theta_x, theta_y=options.theta_y,
        zero_twist_interorbital_max=
            maximum(abs, zero_kinetic[1:2:end, 2:2:end]),
        generic_twist_interorbital_max=
            maximum(abs, generic_kinetic[1:2:end, 2:2:end]),
        hermiticity_residual=norm(generic_kinetic - adjoint(generic_kinetic)),
        time_reversal_residual=norm(
            TwistedED.twisted_cluster_kinetic_matrix(
                2, -options.theta_x, -options.theta_y, twisted_parameters,
            ) - conj(generic_kinetic),
        ),
        c4_covariance_residual=norm(
            c4 * generic_kinetic * adjoint(c4) - c4_target,
        ),
    )
    for N in options.twist_particle_numbers, U in options.twist_U
        scan = TwistedED.canonical_twist_orbit_scan(
            U, N, options.theta_x, options.theta_y;
            parameters=twisted_parameters,
            dense_cutoff=128,
            maxiter=options.twist_maxiter,
            atol=1.0e-12,
            rtol=1.0e-11,
            max_basis_dimension=100_000,
            max_krylov_bytes=512 * 1024^2,
            require_convergence=true,
        )
        push!(summary_rows, (
            U=Float64(U), N=N, density=N / 4,
            theta_x=options.theta_x, theta_y=options.theta_y,
            symmetry_energy_spread=scan.symmetry_energy_spread,
            time_reversal_energy_error=scan.time_reversal_energy_error,
            c4_energy_error=scan.c4_energy_error,
            ground_observables_exact=scan.ground_observables_exact,
            symmetry_orbit_averaged_oalm=scan.twist_averaged_oalm,
            symmetry_orbit_averaged_oalm2=scan.twist_averaged_oalm2,
            symmetry_orbit_averaged_oalm2_per_cell2=
                ismissing(scan.twist_averaged_oalm2) ? missing :
                scan.twist_averaged_oalm2 / 16,
            symmetry_orbit_averaged_double_occupancy_per_cell=
                scan.twist_averaged_double_occupancy_per_cell,
            symmetry_orbit_diagnostic_unresolved_estimate_oalm=
                scan.twist_averaged_unresolved_estimate_oalm,
            symmetry_orbit_diagnostic_unresolved_estimate_oalm2_per_cell2=
                scan.twist_averaged_unresolved_estimate_oalm2 / 16,
            symmetry_orbit_diagnostic_unresolved_estimate_double_occupancy_per_cell=
                scan.twist_averaged_unresolved_estimate_double_occupancy_per_cell,
            max_sector_residual=maximum(row.max_residual for row in scan.rows),
            all_sector_solves_converged=all(
                sector.converged for row in scan.rows
                for sector in row.sector_results
            ),
            symmetry_audit_valid=scan.symmetry_audit_valid,
            full_interacting_Akw_computed=scan.spectral_function_computed,
        ))
        for row in scan.rows
            push!(point_rows, (
                U=Float64(U), N=N, density=N / 4,
                orbit_label=string(row.label),
                theta_x=row.theta_x, theta_y=row.theta_y,
                ground_energy=row.ground_energy,
                ground_energy_per_cell=row.ground_energy / 4,
                ground_degeneracy_lower_bound=row.ground_degeneracy_lower_bound,
                ground_subspace_resolved=row.ground_subspace_resolved,
                ground_observables_exact=row.ground_observables_exact,
                ground_spin_sectors=join(_fmt_sector.(row.ground_sectors), ';'),
                oalm=row.oalm, oalm2=row.oalm2,
                double_occupancy_total=row.double_occupancy_total,
                double_occupancy_per_cell=row.double_occupancy_per_cell,
                diagnostic_unresolved_estimate_oalm=
                    row.unresolved_estimate_oalm,
                diagnostic_unresolved_estimate_oalm2=
                    row.unresolved_estimate_oalm2,
                diagnostic_unresolved_estimate_double_occupancy_per_cell=
                    row.unresolved_estimate_double_occupancy_per_cell,
                max_residual=row.max_residual,
                spin_flip_error=row.spin_flip_error,
                all_sector_solves_converged=all(
                    sector.converged for sector in row.sector_results
                ),
            ))
        end
    end
    return check, summary_rows, point_rows
end

function _tilted_tables(parameters)
    torus = TiltedED.standard_eight_site_torus()
    tilted_parameters = TiltedED.ModelParameters(
        parameters.t1, parameters.t2, parameters.t3, parameters.t4,
    )
    kinetic = TiltedED.tilted_kinetic_matrix(torus, tilted_parameters)
    momentum_rows = NamedTuple[]
    for (index, (kx, ky)) in enumerate(TiltedED.allowed_torus_momenta(torus))
        block = TiltedED.torus_fourier_block(kinetic, torus, kx, ky)
        push!(momentum_rows, (
            momentum_index=index - 1, kx=kx, ky=ky,
            quantum_numbers=string(torus.momentum_quantum_numbers[index]),
            t4_kinematically_allowed=abs(sin(kx) * sin(ky)) > 0.5,
            interorbital_hopping_active=abs(block[1, 2]) > 1.0e-12,
            h11_real=real(block[1, 1]), h22_real=real(block[2, 2]),
            h12_real=real(block[1, 2]), h12_imag=imag(block[1, 2]),
        ))
    end
    feasibility = TiltedED.target_filling_feasibility(torus; filling=1.5)
    resource_summary = [(
        ncells=feasibility.ncells,
        target_density=feasibility.requested_filling,
        N=feasibility.N, Nup=feasibility.Nup, Ndown=feasibility.Ndown,
        full_hilbert_dimension=feasibility.full_hilbert_dimension,
        fixed_N_dimension=feasibility.fixed_N_dimension,
        fixed_Nup_Ndown_dimension=feasibility.fixed_Nup_Ndown_dimension,
        largest_momentum_block=
            feasibility.largest_fixed_Nup_Ndown_momentum_dimension,
        one_vector_bytes=feasibility.one_sector_vector_bytes,
        three_ground_vector_bytes=feasibility.minimum_krylov_vector_bytes,
        removal_sector_dimension=
            feasibility.removal_sector_estimate.fixed_Nup_Ndown_dimension,
        addition_sector_dimension=
            feasibility.addition_sector_estimate.fixed_Nup_Ndown_dimension,
        three_vector_peak_spectral_bytes=
            feasibility.three_vector_peak_spectral_bytes,
        local_target_sector_feasible=feasibility.local_target_sector_feasible,
        full_spectrum_available=feasibility.full_spectrum_available,
        target_Akw_available=feasibility.target_Akw_available,
        reason=feasibility.reason,
        recommended_method=feasibility.recommended_method,
        hpc_resource_note=feasibility.hpc_resource_note,
    )]
    momentum_resource_rows = [(
        momentum_index=index - 1,
        kx=block.kx, ky=block.ky,
        quantum_numbers=string(block.quantum_numbers),
        fixed_N_dimension=block.fixed_N_dimension,
        fixed_Nup_Ndown_dimension=block.fixed_Nup_Ndown_dimension,
        vector_bytes=block.vector_bytes,
        dense_matrix_bytes=block.dense_matrix_bytes,
    ) for (index, block) in enumerate(feasibility.momentum_blocks)]

    low_filling_rows = NamedTuple[]
    for (U, Nup, Ndown) in ((0.0, 1, 0), (2.0, 1, 1), (4.0, 2, 0))
        dense = TiltedED.dense_sector_hamiltonian(
            torus, U, Nup, Ndown; parameters=tilted_parameters,
        )
        dense_energy = eigmin(Symmetric(dense))
        lanczos = TiltedED.lanczos_lowest_sector(
            torus, U, Nup, Ndown; parameters=tilted_parameters,
            maxiter=size(dense, 1),
        )
        push!(low_filling_rows, (
            U=U, Nup=Nup, Ndown=Ndown, N=Nup + Ndown,
            sector_dimension=lanczos.sector_dimension,
            dense_energy=dense_energy, lanczos_energy=lanczos.energy,
            absolute_energy_error=abs(lanczos.energy - dense_energy),
            residual_estimate=lanczos.residual_estimate,
            iterations=lanczos.iterations, converged=lanczos.converged,
        ))
    end
    gate_message = try
        TiltedED.require_feasible_sector(torus; Nup=6, Ndown=6)
        "ERROR: target gate unexpectedly accepted the allocation"
    catch error
        error isa TiltedED.EDResourceLimitError || rethrow()
        sprint(showerror, error)
    end
    return momentum_rows, resource_summary, momentum_resource_rows,
           low_filling_rows, gate_message
end

function _write_plots(stage, periodic_rows, correlation_rows, twist_rows)
    colors = Dict(5 => :royalblue, 6 => :darkorange)
    particle_numbers = sort!(unique(row.N for row in periodic_rows))
    p1 = Plots.plot(layout=(3, 1), size=(850, 900), legend=:best)
    for N in particle_numbers
        rows = sort!(filter(row -> row.N == N, periodic_rows); by=row -> row.U)
        Plots.plot!(p1[1], [row.U for row in rows],
                    [row.charge_gap for row in rows]; marker=:circle,
                    label="N=$N", color=get(colors, N, :black))
        Plots.plot!(p1[2], [row.U for row in rows],
                    [row.same_N_gap for row in rows]; marker=:circle,
                    label="N=$N", color=get(colors, N, :black))
        Plots.plot!(p1[3], [row.U for row in rows],
                    [row.oalm2_per_cell2 for row in rows]; marker=:circle,
                    label="N=$N", color=get(colors, N, :black))
    end
    Plots.ylabel!(p1[1], "charge gap")
    Plots.ylabel!(p1[2], "next same-N gap")
    Plots.ylabel!(p1[3], "<O_alm^2>/16")
    Plots.xlabel!(p1[3], "U")
    Plots.savefig(p1, joinpath(stage, "periodic_filling_comparison.png"))

    selected = filter(row -> row.normalization == "sqrt_cells" &&
                      row.operator in ("spin_total", "spin_altermagnetic"),
                      correlation_rows)
    p2 = Plots.plot(layout=(1, 2), size=(1000, 430), legend=:outertopright)
    for (panel, operator) in enumerate(("spin_total", "spin_altermagnetic"))
        for (nx, ny, label) in ((0, 0, "Gamma"), (1, 0, "X"),
                                (0, 1, "Y"), (1, 1, "M"))
            rows = sort!(filter(row -> row.operator == operator &&
                               row.qx_index == nx && row.qy_index == ny,
                               selected); by=row -> row.U)
            Plots.plot!(p2[panel], [row.U for row in rows],
                        [row.equal_time for row in rows]; marker=:circle,
                        label=label)
        end
        Plots.xlabel!(p2[panel], "U")
        Plots.ylabel!(p2[panel], "equal-time weight")
        Plots.title!(p2[panel], replace(operator, '_' => ' '))
    end
    Plots.savefig(p2, joinpath(stage, "dynamical_channel_equal_time.png"))

    p3 = Plots.plot(layout=(2, 1), size=(850, 650), legend=:best)
    for N in sort!(unique(row.N for row in twist_rows))
        rows = sort!(filter(row -> row.N == N, twist_rows); by=row -> row.U)
        exact = all(row.ground_observables_exact for row in rows)
        oalm2_values = exact ?
            [row.symmetry_orbit_averaged_oalm2_per_cell2 for row in rows] :
            [row.symmetry_orbit_diagnostic_unresolved_estimate_oalm2_per_cell2
             for row in rows]
        double_values = exact ?
            [row.symmetry_orbit_averaged_double_occupancy_per_cell for row in rows] :
            [row.symmetry_orbit_diagnostic_unresolved_estimate_double_occupancy_per_cell
             for row in rows]
        series_label = exact ? "N=$N exact" : "N=$N unresolved estimate"
        Plots.plot!(p3[1], [row.U for row in rows],
                    oalm2_values; marker=:circle, label=series_label)
        Plots.plot!(p3[2], [row.U for row in rows],
                    double_values; marker=:circle, label=series_label)
    end
    Plots.ylabel!(p3[1], "symmetry-orbit <O_alm^2>/16")
    Plots.ylabel!(p3[2], "symmetry-orbit D/cell")
    Plots.xlabel!(p3[2], "U")
    Plots.savefig(p3, joinpath(stage, "twisted_ground_diagnostics.png"))
    return nothing
end

function _metadata(options, periodic_rows, twist_check, tilted_resources,
                   gate_message)
    maximum_periodic_error = maximum(
        row.maximum_spin_audit_error for row in periodic_rows
    )
    resource = only(tilted_resources)
    return """
format_version=1
generated_utc=$(Dates.format(now(UTC), dateformat"yyyy-mm-ddTHH:MM:SS.sssZ"))
ensemble=zero-temperature canonical complete-ground-manifold average where exactly resolved
periodic_particle_numbers=$(join(options.particle_numbers, ';'))
periodic_U=$(join(options.U_values, ';'))
detail_particle_number=$(options.detail_particle_number)
detail_U=$(join(options.detail_U, ';'))
twist_particle_numbers=$(join(options.twist_particle_numbers, ';'))
twist_U=$(join(options.twist_U, ';'))
twist_theta=$(options.theta_x);$(options.theta_y)
hopping=$(options.hopping.t1);$(options.hopping.t2);$(options.hopping.t3);$(options.hopping.t4)
maximum_periodic_spin_audit_error=$maximum_periodic_error
periodic_spin_audit_tolerance=$AUDIT_TOLERANCE
periodic_t4_limitation=all L=2 periodic momenta have sin(kx)sin(ky)=0, so t4 cancels exactly
generic_twist_t4_activation=$(twist_check.generic_twist_interorbital_max)
generic_twist_scope=ground-state diagnostics only; full interacting twisted A(k,omega) was not computed
twist_average_scope=one four-point C4/time-reversal symmetry orbit; not a conventional many-twist boundary-condition average
momentum_index_convention=all CSV momentum-index columns are zero based
finite_system_interpretation=no zero-field finite-cluster spin pairing failure is a spontaneous altermagnetic transition
oalm_periodic_L2=conserved; its exact q=0 Lehmann weight is elastic and a degenerate T=0 source susceptibility is ill-defined
target_density_note=n=1.42 requires <N>=5.68 on four cells; N=5 and N=6 bracket it but neither is exactly n=1.42
tilted_cluster_vectors=(2,2);(-2,2)
tilted_target_N=$(resource.N)
tilted_target_fixed_spin_dimension=$(resource.fixed_Nup_Ndown_dimension)
tilted_target_local_feasible=$(resource.local_target_sector_feasible)
tilted_target_gate=$(replace(gate_message, '\n' => ' '))
tilted_target_claim=resource accounting and low-filling Lanczos proof only; no N=12 ground state or A(k,omega) is claimed
cross_method_validation=use scripts/validate_constrained_path_afqmc.jl; quick profile is smoke-only and standard profile must pass before precision claims
"""
end

function run_extended_study(options)
    ispath(options.output_dir) && throw(ArgumentError(
        "output path already exists: $(options.output_dir)",
    ))
    parent = dirname(options.output_dir)
    mkpath(parent)
    # Preserve a failed stage for inspection instead of deleting potentially
    # expensive completed tables at Julia exit.
    stage = mktempdir(
        parent; prefix=basename(options.output_dir) * ".partial.", cleanup=false,
    )
    println("Writing staged ED study to $stage")
    parameters = PeriodicED.ValidatedKinetic.ModelParameters(;
        options.hopping...,
    )
    try
        periodic_results, periodic_rows = _periodic_scan(options, parameters)
        _write_rows(joinpath(stage, "periodic_ground_scan.csv"), periodic_rows)
        interpolation_rows = _interpolation_rows(options, periodic_results)
        isempty(interpolation_rows) || _write_rows(
            joinpath(stage, "formal_n1p42_convex_interpolation.csv"),
            interpolation_rows,
        )

        manifold_rows, level_rows, spin_gap_rows = _symmetry_tables(
            options, parameters,
        )
        _write_rows(joinpath(stage, "ground_symmetry_manifolds.csv"), manifold_rows)
        _write_rows(joinpath(stage, "low_energy_sector_levels.csv"), level_rows)
        _write_rows(joinpath(stage, "spin_multiplet_gaps.csv"), spin_gap_rows)

        correlation_rows, correlation_peaks = _correlation_tables(
            options, parameters,
        )
        _write_rows(joinpath(stage, "ground_correlation_summary.csv"),
                    correlation_rows)
        _write_rows(joinpath(stage, "ground_correlation_lehmann_peaks.csv"),
                    correlation_peaks)
        self_energy_rows = _self_energy_rows(
            options, parameters, periodic_results,
        )
        _write_rows(joinpath(stage, "matsubara_green_self_energy.csv"),
                    self_energy_rows)

        twist_check, twist_rows, twist_point_rows = _twist_tables(
            options, parameters,
        )
        _write_rows(joinpath(stage, "twist_single_particle_checks.csv"), [twist_check])
        _write_rows(joinpath(stage, "twist_orbit_ground_summary.csv"), twist_rows)
        _write_rows(joinpath(stage, "twist_orbit_ground_points.csv"),
                    twist_point_rows)

        tilted_momenta, tilted_resources, tilted_blocks, low_filling, gate_message =
            _tilted_tables(parameters)
        _write_rows(joinpath(stage, "tilted_eight_site_momenta.csv"),
                    tilted_momenta)
        _write_rows(joinpath(stage, "tilted_eight_site_resources.csv"),
                    tilted_resources)
        _write_rows(joinpath(stage, "tilted_eight_site_momentum_blocks.csv"),
                    tilted_blocks)
        _write_rows(joinpath(stage, "tilted_low_filling_lanczos_checks.csv"),
                    low_filling)
        open(joinpath(stage, "tilted_target_gate.txt"), "w") do io
            println(io, gate_message)
        end

        options.plots && _write_plots(
            stage, periodic_rows, correlation_rows, twist_rows,
        )
        open(joinpath(stage, "metadata.txt"), "w") do io
            print(io, _metadata(
                options, periodic_rows, twist_check, tilted_resources,
                gate_message,
            ))
        end
        all_periodic_audits = all(row.spin_audit_passed for row in periodic_rows)
        all_twist_solves = all(row.all_sector_solves_converged for row in twist_rows)
        all_twist_observables_exact = all(
            row.ground_observables_exact for row in twist_rows
        )
        symmetry_projection_passed = all(row -> maximum((
            row.gram_residual,
            row.s2_quantization_residual,
            row.c4_unitarity_residual,
            row.c4_leakage,
            row.c4_spin_commutator,
        )) <= AUDIT_TOLERANCE, manifold_rows)
        correlation_sum_rules_passed = all(
            abs(row.lehmann_sum_rule_residual) <= AUDIT_TOLERANCE
            for row in correlation_rows
        )
        twist_single_particle_passed = maximum((
            twist_check.hermiticity_residual,
            twist_check.time_reversal_residual,
            twist_check.c4_covariance_residual,
        )) <= AUDIT_TOLERANCE
        twist_symmetry_passed = all(row -> maximum((
            row.symmetry_energy_spread,
            row.time_reversal_energy_error,
            row.c4_energy_error,
        )) <= AUDIT_TOLERANCE, twist_rows)
        tilted_low_filling_passed = all(row ->
            row.converged &&
            row.absolute_energy_error <= AUDIT_TOLERANCE &&
            row.residual_estimate <= AUDIT_TOLERANCE,
            low_filling,
        )
        free_self_energy_rows = filter(row -> row.U == 0.0, self_energy_rows)
        free_self_energy_tested = !isempty(free_self_energy_rows)
        free_self_energy_passed = free_self_energy_tested &&
            all(row -> row.valid && hypot(
                row.self_energy_real, row.self_energy_imag,
            ) <= AUDIT_TOLERANCE, free_self_energy_rows)
        all_validation_gates = all_periodic_audits && all_twist_solves &&
            symmetry_projection_passed && correlation_sum_rules_passed &&
            twist_single_particle_passed && twist_symmetry_passed &&
            tilted_low_filling_passed &&
            (!free_self_energy_tested || free_self_energy_passed)
        open(joinpath(stage, "status.txt"), "w") do io
            println(io, all_validation_gates ?
                    "WORKFLOW_COMPLETE_VALIDATED" :
                    "WORKFLOW_COMPLETE_VALIDATION_FAILED")
            println(io, "audit_tolerance=", AUDIT_TOLERANCE)
            println(io, "periodic_spin_audits=",
                    all_periodic_audits ? "PASS" : "FAIL")
            println(io, "symmetry_projection_audits=",
                    symmetry_projection_passed ? "PASS" : "FAIL")
            println(io, "correlation_lehmann_sum_rules=",
                    correlation_sum_rules_passed ? "PASS" : "FAIL")
            println(io, "U0_self_energy=",
                    !free_self_energy_tested ? "NOT_RUN" :
                    free_self_energy_passed ? "PASS" : "FAIL")
            println(io, "twist_sector_solves=",
                    all_twist_solves ? "CONVERGED" : "NOT_CONVERGED")
            println(io, "twist_single_particle_audits=",
                    twist_single_particle_passed ? "PASS" : "FAIL")
            println(io, "twist_symmetry_energy_audits=",
                    twist_symmetry_passed ? "PASS" : "FAIL")
            println(io, "twist_ensemble_observables=",
                    all_twist_observables_exact ? "EXACT" :
                    "UNRESOLVED_LANCZOS_ESTIMATES_WITHHELD")
            println(io, "tilted_low_filling_lanczos_checks=",
                    tilted_low_filling_passed ? "PASS" : "FAIL")
            println(io, "tilted_target_N12=NOT_RUN_RESOURCE_GATE")
        end
        mv(stage, options.output_dir)
        println("Completed extended ground-state ED study: $(options.output_dir)")
        return (
            output_dir=options.output_dir,
            periodic_rows=periodic_rows,
            symmetry_rows=manifold_rows,
            correlation_rows=correlation_rows,
            twist_rows=twist_rows,
            tilted_resources=tilted_resources,
        )
    catch
        println(stderr, "Study failed; staged files remain at $stage")
        rethrow()
    end
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        usage()
        return nothing
    end
    return run_extended_study(options)
end

end # module ExtendedGroundStateED

if abspath(PROGRAM_FILE) == @__FILE__
    ExtendedGroundStateED.main()
end
