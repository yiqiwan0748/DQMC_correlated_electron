#!/usr/bin/env julia

module PeriodicL2EDRequest

ENV["GKSwstype"] = get(ENV, "GKSwstype", "100")

using Plots

include(joinpath(@__DIR__, "two_orbital_cluster_ed.jl"))
const ClusterED = TwoOrbitalClusterED

export main,
       momentum_label,
       parse_options,
       run_request,
       usage

const ZERO_FIELD_ROLE = "zero_field_symmetry_audit"
const POSITIVE_FIELD_ROLE = "explicit_field_plus"
const NEGATIVE_FIELD_ROLE = "explicit_field_minus"
const LIMITATION =
    "Periodic L=2 exactly cancels t4. Zero-field spin equality is a numerical " *
    "symmetry audit; finite h_alm is an explicit response and neither determines a bulk Uc."

function usage(io::IO=stdout)
    print(io, """
Usage: julia --project=. scripts/run_periodic_l2_ed_request.jl [options]

  --output-dir=PATH                 New directory [results/periodic_l2_ed_request]
  --ensemble=fixed-mu|fixed-density Thermodynamic path [fixed-mu]
  --mu=-2.5157                      Centered-convention chemical potential
  --target-density=1.5              Electrons per cell for fixed-density mode
  --mu-min=-40 --mu-max=40          Fixed-density tuning bracket
  --density-tolerance=1e-10         Density tuning tolerance
  --mu-tolerance=1e-12              Chemical-potential bracket tolerance
  --mu-max-iterations=200           Tuner iteration limit
  --beta=10                         Inverse temperature
  --U-min=0 --U-max=20 --U-step=1  Interaction grid
  --spectral-U=2,3,4                U values with poles, DOS, and A(k,omega)
  --full-spectrum-U=2,3,4           U values with all 65,536 many-body levels
                                      (use 'none' to disable)
  --probe-h=0.001                   Also solve explicit sources +/-h (0 disables)
  --eta=0.15                        Lorentzian half-width for presentation
  --omega-min=-30 --omega-max=30 --omega-points=1201
  --audit-tolerance=2e-10           Zero-field numerical spin-audit tolerance
  --t1=-1 --t2=-1.75 --t3=-0.85 --t4=-0.65
  --plots=true|false                 Write three PNG summaries [true]

Fixed-density mode requires `TwoOrbitalClusterED.tune_cluster_mu`. Exact pole
weights and many-body levels are written separately from broadened spectra.
$(LIMITATION)
""")
end

function _finite_float(value::AbstractString, name::AbstractString)
    parsed = try
        parse(Float64, value)
    catch
        throw(ArgumentError("--$name must be a real number"))
    end
    isfinite(parsed) || throw(ArgumentError("--$name must be finite"))
    return parsed
end

function _integer(value::AbstractString, name::AbstractString; minimum::Int=1)
    parsed = try
        parse(Int, value)
    catch
        throw(ArgumentError("--$name must be an integer"))
    end
    parsed >= minimum || throw(ArgumentError("--$name must be at least $minimum"))
    return parsed
end

function _boolean(value::AbstractString, name::AbstractString)
    lowercase(value) == "true" && return true
    lowercase(value) == "false" && return false
    throw(ArgumentError("--$name must be true or false"))
end

function _interaction_grid(first_value::Float64, last_value::Float64, step::Float64)
    first_value >= 0 || throw(ArgumentError("--U-min must be nonnegative"))
    last_value >= first_value ||
        throw(ArgumentError("--U-max must be at least --U-min"))
    step > 0 || throw(ArgumentError("--U-step must be positive"))
    ratio = (last_value - first_value) / step
    isfinite(ratio) && ratio <= typemax(Int) ||
        throw(ArgumentError("interaction grid is too large"))
    intervals = round(Int, ratio)
    isapprox(
        first_value + intervals * step,
        last_value;
        atol=1.0e-12,
        rtol=1.0e-12,
    ) || throw(ArgumentError("--U-step must land on --U-max"))
    return collect(range(first_value, last_value; length=intervals + 1))
end

function _float_list(value::AbstractString, name::AbstractString; allow_none::Bool=false)
    stripped = strip(value)
    if allow_none && lowercase(stripped) in ("", "none")
        return Float64[]
    end
    isempty(stripped) && throw(ArgumentError("--$name must not be empty"))
    entries = split(stripped, ',')
    any(entry -> isempty(strip(entry)), entries) &&
        throw(ArgumentError("--$name must be a comma-separated number list"))
    values = [_finite_float(strip(entry), name) for entry in entries]
    all(>=(0), values) || throw(ArgumentError("--$name values must be nonnegative"))
    length(unique(values)) == length(values) ||
        throw(ArgumentError("--$name contains a duplicate"))
    return values
end

function _canonical_selected_U(requested, grid, name)
    canonical = Float64[]
    for value in requested
        index = findfirst(candidate -> isapprox(
            candidate,
            value;
            atol=1.0e-12,
            rtol=1.0e-12,
        ), grid)
        isnothing(index) && throw(ArgumentError(
            "--$name value $value is not on the requested interaction grid",
        ))
        push!(canonical, grid[index])
    end
    return canonical
end

"""
    parse_options(arguments=ARGS)

Parse and validate the standalone periodic-L2 study options. By default the
interaction scan is exactly `0:1:20`, spectra are exported at `U=2,3,4`, and
the same three interactions receive full many-body level tables.
"""
function parse_options(arguments=ARGS)
    any(argument -> argument in ("-h", "--help"), arguments) && return nothing
    allowed = Set([
        "output-dir", "ensemble", "mu", "target-density", "mu-min", "mu-max",
        "density-tolerance", "mu-tolerance", "mu-max-iterations", "beta",
        "U-min", "U-max", "U-step", "spectral-U", "full-spectrum-U",
        "probe-h", "eta", "omega-min", "omega-max", "omega-points",
        "audit-tolerance", "t1", "t2", "t3", "t4", "plots",
    ])
    raw = Dict{String,String}()
    for argument in arguments
        startswith(argument, "--") && occursin('=', argument) ||
            throw(ArgumentError("options must use --name=value: $argument"))
        name, value = split(argument[3:end], '='; limit=2)
        name in allowed || throw(ArgumentError("unknown option --$name"))
        haskey(raw, name) && throw(ArgumentError("duplicate option --$name"))
        raw[name] = value
    end

    ensemble_string = lowercase(get(raw, "ensemble", "fixed-mu"))
    ensemble_string in ("fixed-mu", "fixed-density") || throw(ArgumentError(
        "--ensemble must be fixed-mu or fixed-density",
    ))
    ensemble = ensemble_string == "fixed-mu" ? :fixed_mu : :fixed_density
    U_min = _finite_float(get(raw, "U-min", "0"), "U-min")
    U_max = _finite_float(get(raw, "U-max", "20"), "U-max")
    U_step = _finite_float(get(raw, "U-step", "1"), "U-step")
    U_values = _interaction_grid(U_min, U_max, U_step)
    spectral_U = _canonical_selected_U(
        _float_list(get(raw, "spectral-U", "2,3,4"), "spectral-U"),
        U_values,
        "spectral-U",
    )
    full_spectrum_U = _canonical_selected_U(
        _float_list(
            get(raw, "full-spectrum-U", "2,3,4"),
            "full-spectrum-U";
            allow_none=true,
        ),
        U_values,
        "full-spectrum-U",
    )

    beta = _finite_float(get(raw, "beta", "10"), "beta")
    beta > 0 || throw(ArgumentError("--beta must be positive"))
    mu = _finite_float(get(raw, "mu", "-2.5157"), "mu")
    target_density = _finite_float(
        get(raw, "target-density", "1.5"),
        "target-density",
    )
    0 < target_density < 4 || throw(ArgumentError(
        "--target-density must lie strictly between zero and four",
    ))
    mu_min = _finite_float(get(raw, "mu-min", "-40"), "mu-min")
    mu_max = _finite_float(get(raw, "mu-max", "40"), "mu-max")
    mu_min < mu_max || throw(ArgumentError("--mu-min must be below --mu-max"))
    density_tolerance = _finite_float(
        get(raw, "density-tolerance", "1e-10"),
        "density-tolerance",
    )
    density_tolerance > 0 ||
        throw(ArgumentError("--density-tolerance must be positive"))
    mu_tolerance = _finite_float(
        get(raw, "mu-tolerance", "1e-12"),
        "mu-tolerance",
    )
    mu_tolerance > 0 || throw(ArgumentError("--mu-tolerance must be positive"))
    mu_max_iterations = _integer(
        get(raw, "mu-max-iterations", "200"),
        "mu-max-iterations",
    )

    probe_h = _finite_float(get(raw, "probe-h", "0.001"), "probe-h")
    probe_h >= 0 || throw(ArgumentError("--probe-h must be nonnegative"))
    eta = _finite_float(get(raw, "eta", "0.15"), "eta")
    eta > 0 || throw(ArgumentError("--eta must be positive"))
    omega_min = _finite_float(get(raw, "omega-min", "-30"), "omega-min")
    omega_max = _finite_float(get(raw, "omega-max", "30"), "omega-max")
    omega_min < omega_max ||
        throw(ArgumentError("--omega-min must be below --omega-max"))
    omega_points = _integer(
        get(raw, "omega-points", "1201"),
        "omega-points";
        minimum=3,
    )
    audit_tolerance = _finite_float(
        get(raw, "audit-tolerance", "2e-10"),
        "audit-tolerance",
    )
    audit_tolerance >= 0 ||
        throw(ArgumentError("--audit-tolerance must be nonnegative"))
    hopping = (
        t1=_finite_float(get(raw, "t1", "-1"), "t1"),
        t2=_finite_float(get(raw, "t2", "-1.75"), "t2"),
        t3=_finite_float(get(raw, "t3", "-0.85"), "t3"),
        t4=_finite_float(get(raw, "t4", "-0.65"), "t4"),
    )
    all(iszero, values(hopping)) && throw(ArgumentError(
        "at least one hopping must be nonzero for the requested spectral study",
    ))
    return (
        output_dir=abspath(get(raw, "output-dir", "results/periodic_l2_ed_request")),
        ensemble=ensemble,
        mu=mu,
        target_density=target_density,
        mu_bounds=(mu_min, mu_max),
        density_tolerance=density_tolerance,
        mu_tolerance=mu_tolerance,
        mu_max_iterations=mu_max_iterations,
        beta=beta,
        U_values=U_values,
        spectral_U=spectral_U,
        full_spectrum_U=full_spectrum_U,
        probe_h=probe_h,
        eta=eta,
        omega=collect(range(omega_min, omega_max; length=omega_points)),
        audit_tolerance=audit_tolerance,
        hopping=hopping,
        plots=_boolean(get(raw, "plots", "true"), "plots"),
    )
end

"""Return the conventional label for one of the four periodic-L2 momenta."""
function momentum_label(kx_index::Integer, ky_index::Integer)
    labels = Dict((1, 1) => "Gamma", (2, 1) => "X", (1, 2) => "Y", (2, 2) => "M")
    return get(labels, (Int(kx_index), Int(ky_index))) do
        throw(ArgumentError("periodic L2 momentum indices must each be 1 or 2"))
    end
end

_contains_U(values, U) = any(value -> value == U, values)

function _csv_value(value)
    value === missing && return ""
    value === nothing && return ""
    text = string(value)
    return occursin(',', text) || occursin('"', text) || occursin('\n', text) ?
        "\"" * replace(text, "\"" => "\"\"") * "\"" : text
end

function _write_rows(path::AbstractString, rows)
    isempty(rows) && return nothing
    columns = collect(keys(first(rows)))
    all(row -> collect(keys(row)) == columns, rows) ||
        throw(ArgumentError("CSV rows must have identical columns"))
    open(path, "w") do io
        println(io, join(string.(columns), ','))
        for row in rows
            println(io, join((_csv_value(getproperty(row, column)) for column in columns), ','))
        end
    end
    return path
end

function _require_tuner(ed_module)
    isdefined(ed_module, :tune_cluster_mu) || throw(ErrorException(
        "fixed-density mode requires the public API " *
        "TwoOrbitalClusterED.tune_cluster_mu",
    ))
    return getproperty(ed_module, :tune_cluster_mu)
end

function _chemical_potential(options, ed_module, parameters, U, h)
    if options.ensemble == :fixed_mu
        return (
            mu=options.mu,
            density=missing,
            target_density=missing,
            residual=missing,
            converged=true,
            iterations=0,
            bracket=missing,
        )
    end
    tuner = _require_tuner(ed_module)
    tuned = tuner(
        U,
        options.target_density,
        options.beta;
        parameters=parameters,
        h_alm=h,
        mu_bounds=options.mu_bounds,
        density_tolerance=options.density_tolerance,
        mu_tolerance=options.mu_tolerance,
        max_iterations=options.mu_max_iterations,
    )
    required = (
        :mu, :density, :target_density, :residual, :converged, :iterations, :bracket,
    )
    all(name -> hasproperty(tuned, name), required) || throw(ErrorException(
        "tune_cluster_mu returned an unsupported result; required fields are $(required)",
    ))
    tuned.converged || throw(ErrorException(
        "chemical-potential tuning did not converge at U=$U, h_alm=$h; " *
        "residual=$(tuned.residual), bracket=$(tuned.bracket)",
    ))
    return tuned
end

function _solve_point(options, ed_module, parameters, U, h; full_spectrum=false)
    tuning = _chemical_potential(options, ed_module, parameters, U, h)
    tau = [0.0, options.beta / 2, options.beta]
    result = ed_module.solve_two_orbital_cluster(
        U,
        tuning.mu,
        options.beta,
        tau;
        parameters=parameters,
        include_full_spectrum=full_spectrum,
        h_alm=h,
    )
    if options.ensemble == :fixed_density
        abs(result.density - options.target_density) <= options.density_tolerance ||
            throw(ErrorException(
                "separate ED solve missed target density at U=$U, h_alm=$h: " *
                "density=$(result.density), target=$(options.target_density)",
            ))
    end
    return result, tuning
end

function _field_point_row(result, tuning, options, role)
    return (
        U=result.U,
        field_role=role,
        interpretation=role == ZERO_FIELD_ROLE ?
            "symmetry_audit_not_order_detection" :
            "explicit_source_response_not_spontaneous_order",
        h_alm=result.h_alm,
        ensemble=options.ensemble,
        mu_code=result.mu,
        mu_standard=result.mu + result.U / 2,
        beta=result.beta,
        target_density=options.ensemble == :fixed_density ? options.target_density : missing,
        density_per_cell=result.density,
        density_residual=options.ensemble == :fixed_density ?
            result.density - options.target_density : missing,
        tuning_iterations=tuning.iterations,
        double_occupancy_per_cell=result.double_occupancy,
        grand_energy_per_cell=result.grand_energy_per_cell,
        log_partition=result.log_partition,
        orbital_1_magnetization_per_cell=result.orbital_magnetizations[1],
        orbital_2_magnetization_per_cell=result.orbital_magnetizations[2],
        delta_alm_per_cell=result.delta_alm,
        total_spin_z_per_cell=result.total_spin_z_per_cell,
        spectral_moment_max_error=result.spectral_moment_max_error,
    )
end

function _zero_field_row(
    result, tuning, options, full_exported, spectral_exported, ed_module,
    broadened,
)
    pairing = ed_module.spin_pairing_error(result)
    many_body_pairing = ed_module.many_body_spin_pairing_error(result)
    broadened_error = maximum(abs, broadened.dos[1, :] .- broadened.dos[2, :])
    maximum_error = max(pairing.maximum, broadened_error, many_body_pairing.maximum)
    return (
        U=result.U,
        mu_code=result.mu,
        mu_standard=result.mu + result.U / 2,
        beta=result.beta,
        ensemble=options.ensemble,
        target_density=options.ensemble == :fixed_density ? options.target_density : missing,
        density_per_cell=result.density,
        density_residual=options.ensemble == :fixed_density ?
            result.density - options.target_density : missing,
        tuning_iterations=tuning.iterations,
        double_occupancy_per_cell=result.double_occupancy,
        grand_energy_per_cell=result.grand_energy_per_cell,
        log_partition=result.log_partition,
        delta_alm_per_cell=result.delta_alm,
        total_spin_z_per_cell=result.total_spin_z_per_cell,
        spin_green_max_difference=pairing.green,
        spin_pole_frequency_max_difference=pairing.frequency,
        spin_pole_weight_max_difference=pairing.weight,
        spin_pole_length_mismatch=pairing.length_mismatch,
        broadened_spin_dos_max_difference=broadened_error,
        maximum_spectral_spin_pairing_error=max(pairing.maximum, broadened_error),
        many_body_K_Sz_pair_energy_max_difference=many_body_pairing.energy,
        many_body_K_Sz_pair_length_mismatch=many_body_pairing.length_mismatch,
        many_body_K_Sz_sectors_checked=many_body_pairing.sectors_checked,
        maximum_spin_symmetry_audit_error=maximum_error,
        audit_tolerance=options.audit_tolerance,
        numerical_spin_symmetry_audit_failed=
            many_body_pairing.length_mismatch != 0 ||
            maximum_error > options.audit_tolerance,
        spontaneous_breaking_assessable=false,
        spectral_moment_max_error=result.spectral_moment_max_error,
        t4_cancellation_max_abs=maximum(abs, result.kinetic[1:2:end, 2:2:end]),
        spectral_outputs_exported=spectral_exported,
        full_spectrum_exported=full_exported,
    )
end

function _response_row(
    positive,
    positive_tuning,
    negative,
    negative_tuning,
    options,
    positive_diagnostics,
    negative_diagnostics,
)
    h = options.probe_h
    reversal_green_error = max(
        maximum(abs, positive.green[1, :, :, :, :] .- negative.green[2, :, :, :, :]),
        maximum(abs, positive.green[2, :, :, :, :] .- negative.green[1, :, :, :, :]),
    )
    return (
        U=positive.U,
        interpretation="explicit_source_response_not_spontaneous_order",
        ensemble=options.ensemble,
        probe_h=h,
        mu_plus=positive.mu,
        mu_minus=negative.mu,
        tuning_iterations_plus=positive_tuning.iterations,
        tuning_iterations_minus=negative_tuning.iterations,
        density_plus=positive.density,
        density_minus=negative.density,
        delta_alm_plus=positive.delta_alm,
        delta_alm_minus=negative.delta_alm,
        central_susceptibility_per_cell=(positive.delta_alm - negative.delta_alm) / (2h),
        field_reversal_delta_odd_error=abs(positive.delta_alm + negative.delta_alm),
        field_reversal_density_even_error=abs(positive.density - negative.density),
        field_reversal_grand_energy_even_error=abs(
            positive.grand_energy_per_cell - negative.grand_energy_per_cell,
        ),
        field_reversal_green_spin_swap_max_error=reversal_green_error,
        compensated_total_spin_max_abs=max(
            abs(positive.total_spin_z_per_cell),
            abs(negative.total_spin_z_per_cell),
        ),
        positive_x_same_momentum_spin_contrast_max=
            positive_diagnostics.x_same_momentum_spin_contrast_max,
        positive_y_same_momentum_spin_contrast_max=
            positive_diagnostics.y_same_momentum_spin_contrast_max,
        positive_xy_rotated_partner_max_error=
            positive_diagnostics.xy_rotated_partner_max_error,
        positive_xy_contrast_antisymmetry_max_error=
            positive_diagnostics.xy_contrast_antisymmetry_max_error,
        positive_field_spin_dos_max_difference=positive_diagnostics.dos_spin_max_error,
        negative_x_same_momentum_spin_contrast_max=
            negative_diagnostics.x_same_momentum_spin_contrast_max,
        negative_y_same_momentum_spin_contrast_max=
            negative_diagnostics.y_same_momentum_spin_contrast_max,
        negative_xy_rotated_partner_max_error=
            negative_diagnostics.xy_rotated_partner_max_error,
        negative_xy_contrast_antisymmetry_max_error=
            negative_diagnostics.xy_contrast_antisymmetry_max_error,
        negative_field_spin_dos_max_difference=negative_diagnostics.dos_spin_max_error,
        spontaneous_breaking_assessable=false,
    )
end

function _write_spectral_point!(
    pole_io, sum_rule_io, akw_io, dos_io, result, role, options, broadened,
)
    for spin in 1:2, orbital in 1:2, ky_index in 1:2, kx_index in 1:2
        channel = result.spectral_peaks[spin, orbital, kx_index, ky_index]
        label = momentum_label(kx_index, ky_index)
        for (frequency, weight) in zip(channel.frequencies, channel.weights)
            println(pole_io, join((
                result.U, role, result.h_alm, result.mu,
                spin == 1 ? "up" : "down", orbital,
                kx_index, ky_index, label,
                result.momenta[kx_index], result.momenta[ky_index],
                frequency, weight,
            ), ','))
        end
        weight_sum = sum(channel.weights)
        println(sum_rule_io, join((
            result.U, role, result.h_alm, result.mu,
            spin == 1 ? "up" : "down", orbital,
            kx_index, ky_index, label, length(channel.frequencies),
            weight_sum, abs(weight_sum - 1),
        ), ','))
        for omega_index in eachindex(options.omega)
            println(akw_io, join((
                result.U, role, result.h_alm, result.mu,
                spin == 1 ? "up" : "down", orbital,
                kx_index, ky_index, label,
                result.momenta[kx_index], result.momenta[ky_index],
                options.omega[omega_index],
                broadened.spectral[spin, orbital, kx_index, ky_index, omega_index],
                options.eta,
            ), ','))
        end
    end
    for omega_index in eachindex(options.omega)
        println(dos_io, join((
            result.U, role, result.h_alm, result.mu, options.omega[omega_index],
            broadened.dos[1, omega_index], broadened.dos[2, omega_index],
            broadened.total_dos[omega_index], options.eta,
        ), ','))
    end
    return nothing
end

function _write_full_levels!(io, result)
    levels = result.full_many_body_levels
    isnothing(levels) && error("full many-body levels were not requested from the solver")
    for (index, level) in enumerate(levels)
        println(io, join((
            result.U, ZERO_FIELD_ROLE, result.h_alm, result.mu, index,
            level.Nup, level.Ndown, level.N, level.Sz,
            level.kx_index, level.ky_index,
            momentum_label(level.kx_index, level.ky_index),
            level.kx, level.ky, level.energy,
        ), ','))
    end
    return (
        U=result.U,
        h_alm=result.h_alm,
        mu_code=result.mu,
        number_of_levels=length(levels),
        minimum_grand_energy=first(levels).energy,
        maximum_grand_energy=maximum(level.energy for level in levels),
        interpretation="many_body_levels_not_spectral_peaks",
    )
end

function _plot_outputs(
    destination, options, zero_rows, response_rows, zero_spectra, positive_spectra,
)
    plots = Plots
    output_paths = String[]

    dos_panels = Any[]
    for U in sort!(collect(keys(zero_spectra)))
        spectrum = zero_spectra[U]
        panel = plots.plot(
            spectrum.omega,
            spectrum.dos[1, :];
            label="spin up",
            color=:red,
            linewidth=2,
            xlabel="omega",
            ylabel="DOS per spin",
            title="zero field, U=$U",
        )
        plots.plot!(
            panel,
            spectrum.omega,
            spectrum.dos[2, :];
            label="spin down",
            color=:blue,
            linewidth=2,
            linestyle=:dash,
        )
        push!(dos_panels, panel)
    end
    if !isempty(dos_panels)
        path = joinpath(destination, "periodic_L2_zero_field_spin_DOS.png")
        plots.savefig(
            plots.plot(
                dos_panels...;
                layout=(1, length(dos_panels)),
                size=(max(600, 480 * length(dos_panels)), 420),
                plot_title="Periodic L=2 zero-field spin-resolved DOS",
            ),
            path,
        )
        push!(output_paths, path)
    end

    xy_panels = Any[]
    xy_contrast_panels = Any[]
    for U in sort!(collect(keys(positive_spectra)))
        spectrum = positive_spectra[U]
        panel = plots.plot(
            spectrum.omega,
            spectrum.spin_trace[1, 2, 1, :];
            label="X up",
            color=:red,
            linewidth=2,
            xlabel="omega",
            ylabel="orbital-summed A(k,omega)",
            title="+h=$(options.probe_h), U=$U",
        )
        plots.plot!(panel, spectrum.omega, spectrum.spin_trace[2, 2, 1, :];
                    label="X down", color=:blue, linewidth=2, linestyle=:dash)
        plots.plot!(panel, spectrum.omega, spectrum.spin_trace[1, 1, 2, :];
                    label="Y up", color=:orange, linewidth=2, linestyle=:dot)
        plots.plot!(panel, spectrum.omega, spectrum.spin_trace[2, 1, 2, :];
                    label="Y down", color=:purple, linewidth=2, linestyle=:dashdot)
        push!(xy_panels, panel)

        delta_x = spectrum.spin_trace[1, 2, 1, :] -
                  spectrum.spin_trace[2, 2, 1, :]
        delta_y = spectrum.spin_trace[1, 1, 2, :] -
                  spectrum.spin_trace[2, 1, 2, :]
        contrast_panel = plots.plot(
            spectrum.omega,
            delta_x;
            label="Delta A at X",
            color=:darkred,
            linewidth=2,
            xlabel="omega",
            ylabel="A_up-A_down",
            title="source-induced contrast, U=$U",
        )
        plots.plot!(
            contrast_panel,
            spectrum.omega,
            delta_y;
            label="Delta A at Y",
            color=:navy,
            linewidth=2,
            linestyle=:dash,
        )
        plots.hline!(contrast_panel, [0.0]; label="", color=:black, alpha=0.35)
        push!(xy_contrast_panels, contrast_panel)
    end
    if !isempty(xy_panels)
        path = joinpath(destination, "periodic_L2_positive_field_XY_Akw.png")
        panels = vcat(xy_panels, xy_contrast_panels)
        plots.savefig(
            plots.plot(
                panels...;
                layout=(2, length(xy_panels)),
                size=(max(700, 500 * length(xy_panels)), 760),
                plot_title="Explicit +h response at X and Y (not spontaneous order)",
            ),
            path,
        )
        push!(output_paths, path)
    end

    interactions = getproperty.(zero_rows, :U)
    audit_errors = max.(
        getproperty.(zero_rows, :maximum_spin_symmetry_audit_error),
        eps(Float64),
    )
    audit_panel = plots.plot(
        interactions,
        audit_errors;
        marker=:circle,
        linewidth=2,
        yscale=:log10,
        label="max zero-field audit error",
        xlabel="U",
        ylabel="absolute error",
        title="E(K,+Sz) vs E(K,-Sz) and spectra",
    )
    plots.hline!(
        audit_panel,
        [max(options.audit_tolerance, eps(Float64))];
        label="audit tolerance",
        color=:black,
        linestyle=:dash,
    )
    density_panel = plots.plot(
        interactions,
        getproperty.(zero_rows, :density_per_cell);
        marker=:circle,
        linewidth=2,
        label="ED density",
        xlabel="U",
        ylabel="electrons per cell",
        title=options.ensemble == :fixed_density ?
            "fixed-density path" : "fixed-mu path",
    )
    if options.ensemble == :fixed_density
        plots.hline!(
            density_panel,
            [options.target_density];
            label="target",
            color=:black,
            linestyle=:dash,
        )
        density_margin = max(0.01, 0.01 * abs(options.target_density))
        plots.ylims!(
            density_panel,
            options.target_density - density_margin,
            options.target_density + density_margin,
        )
    end
    scan_panels = Any[audit_panel, density_panel]
    if !isempty(response_rows)
        response_panel = plots.plot(
            getproperty.(response_rows, :U),
            getproperty.(response_rows, :central_susceptibility_per_cell);
            marker=:diamond,
            linewidth=2,
            label="[Delta(+h)-Delta(-h)]/(2h)",
            xlabel="U",
            ylabel="response per cell",
            title="explicit +/-h response (not order)",
        )
        push!(scan_panels, response_panel)
    end
    scan_path = joinpath(destination, "periodic_L2_U_scan_audit_density.png")
    plots.savefig(
        plots.plot(
            scan_panels...;
            layout=(1, length(scan_panels)),
            size=(max(1100, 500 * length(scan_panels)), 430),
            plot_title="Periodic L=2 exact-diagonalization scan",
        ),
        scan_path,
    )
    push!(output_paths, scan_path)
    return output_paths
end

function _write_metadata(path, options, zero_rows, response_rows, plot_paths)
    open(path, "w") do io
        println(io, "Periodic 2x2 two-orbital exact-diagonalization request")
        println(io, LIMITATION)
        println(io, "output publication=temporary sibling plus atomic rename; existing destinations are never overwritten")
        println(io, "L=2; four physical cells; orbital basis=(d_xz,d_yz)")
        println(io, "8 spatial orbitals; 16 spin orbitals; Hilbert dimension=65536")
        println(io, "N=0..16; Sz=-4..4; fixed-(Nup,Ndown) maximum dimension=4900")
        println(io, "Factorized implementation: two 256-state orbital spaces; largest momentum block=12")
        println(io, "momenta: Gamma=(0,0), X=(pi,0), Y=(0,pi), M=(pi,pi)")
        println(io, "H=K+U sum[(n_up-1/2)(n_down-1/2)]-mu_code*N-h_alm*O_alm")
        println(io, "mu_standard=mu_code+U/2")
        println(io, "ensemble=$(options.ensemble); beta=$(options.beta)")
        println(io, "fixed mu_code=$(options.mu); fixed-density target=$(options.target_density)")
        println(io, "U_values=$(options.U_values)")
        println(io, "spectral_U=$(options.spectral_U); full_spectrum_U=$(options.full_spectrum_U)")
        println(io, "source fields: h_alm=0 and $(options.probe_h == 0 ? "no probe" : "+/-$(options.probe_h)")")
        println(io, "hopping=$(options.hopping); periodic L2 t4 cancellation is exact")
        println(io, "G=<c(tau)c^dagger(0)> with no leading minus; omega is relative to mu_code")
        println(io, "raw Lehmann poles/weights are exact; Lorentzian eta=$(options.eta) is presentation only")
        println(io, "spectral normalization: one per spin-orbital-k channel, two per-spin DOS, four total DOS")
        println(io, "zero-field audit tolerance=$(options.audit_tolerance)")
        println(io, "zero-field audit failures=$(count(row -> row.numerical_spin_symmetry_audit_failed, zero_rows))")
        println(io, "explicit-field response rows=$(length(response_rows)); these are not spontaneous order")
        println(io, "plots enabled=$(options.plots); plot files=$(basename.(plot_paths))")
        println(io, "full levels carry Nup,Ndown,N,Sz and translation momentum; total S is not assigned")
        println(io, "many-body energy degeneracy is not A(k,omega); A uses transition energies and weights")
        println(io, "Assumed solver API: solve_two_orbital_cluster(U,mu,beta,tau; parameters,include_full_spectrum,h_alm)")
        println(io, "Assumed spectral APIs: spin_pairing_error(result), broaden_cluster_spectra(result,omega;eta), altermagnetic_xy_diagnostics(result,omega;eta)")
        println(io, "Assumed fixed-density API: tune_cluster_mu(U,target_density,beta; parameters,h_alm,mu_bounds,density_tolerance,mu_tolerance,max_iterations)")
        println(io, "Required tuner fields: mu,density,target_density,residual,converged,iterations,bracket")
    end
    return path
end

function _write_request(staging, options, ed_module, parameters)
    field_rows = NamedTuple[]
    zero_rows = NamedTuple[]
    response_rows = NamedTuple[]
    full_spectrum_rows = NamedTuple[]
    zero_spectra = Dict{Float64,Any}()
    positive_spectra = Dict{Float64,Any}()
    pole_path = joinpath(staging, "periodic_L2_raw_spectral_poles.csv")
    sum_rule_path = joinpath(staging, "periodic_L2_spectral_sum_rules.csv")
    akw_path = joinpath(staging, "periodic_L2_spin_orbital_Akw.csv")
    dos_path = joinpath(staging, "periodic_L2_spin_resolved_DOS.csv")
    levels_path = joinpath(staging, "periodic_L2_full_many_body_levels.csv")

    open(pole_path, "w") do pole_io
        open(sum_rule_path, "w") do sum_rule_io
            open(akw_path, "w") do akw_io
                open(dos_path, "w") do dos_io
                    open(levels_path, "w") do levels_io
                        println(pole_io, "U,field_role,h_alm,mu_code,spin,orbital,kx_index,ky_index,momentum,kx,ky,omega,weight")
                        println(sum_rule_io, "U,field_role,h_alm,mu_code,spin,orbital,kx_index,ky_index,momentum,pole_count,weight_sum,zeroth_moment_error")
                        println(akw_io, "U,field_role,h_alm,mu_code,spin,orbital,kx_index,ky_index,momentum,kx,ky,omega,A,lorentzian_eta")
                        println(dos_io, "U,field_role,h_alm,mu_code,omega,dos_up,dos_down,dos_total,lorentzian_eta")
                        println(levels_io, "U,field_role,h_alm,mu_code,index,N_up,N_down,N,Sz,kx_index,ky_index,momentum,kx,ky,grand_energy")

                        for U in options.U_values
                            full_exported = _contains_U(options.full_spectrum_U, U)
                            spectral_exported = _contains_U(options.spectral_U, U)
                            zero, zero_tuning = _solve_point(
                                options,
                                ed_module,
                                parameters,
                                U,
                                0.0;
                                # The complete spectrum is transiently needed at
                                # every U for the E(K,+Sz)=E(K,-Sz) audit. Only
                                # explicitly selected U values are written below.
                                full_spectrum=true,
                            )
                            zero_broadened = ed_module.broaden_cluster_spectra(
                                zero,
                                options.omega;
                                eta=options.eta,
                            )
                            push!(field_rows, _field_point_row(
                                zero, zero_tuning, options, ZERO_FIELD_ROLE,
                            ))
                            push!(zero_rows, _zero_field_row(
                                zero,
                                zero_tuning,
                                options,
                                full_exported,
                                spectral_exported,
                                ed_module,
                                zero_broadened,
                            ))
                            if spectral_exported
                                _write_spectral_point!(
                                    pole_io, sum_rule_io, akw_io, dos_io,
                                    zero, ZERO_FIELD_ROLE, options, zero_broadened,
                                )
                                zero_spectra[U] = zero_broadened
                            end
                            if full_exported
                                push!(full_spectrum_rows, _write_full_levels!(levels_io, zero))
                            end

                            if options.probe_h > 0
                                positive, positive_tuning = _solve_point(
                                    options,
                                    ed_module,
                                    parameters,
                                    U,
                                    options.probe_h,
                                )
                                negative, negative_tuning = _solve_point(
                                    options,
                                    ed_module,
                                    parameters,
                                    U,
                                    -options.probe_h,
                                )
                                push!(field_rows, _field_point_row(
                                    positive,
                                    positive_tuning,
                                    options,
                                    POSITIVE_FIELD_ROLE,
                                ))
                                push!(field_rows, _field_point_row(
                                    negative,
                                    negative_tuning,
                                    options,
                                    NEGATIVE_FIELD_ROLE,
                                ))
                                positive_diagnostics =
                                    ed_module.altermagnetic_xy_diagnostics(
                                        positive,
                                        options.omega;
                                        eta=options.eta,
                                    )
                                negative_diagnostics =
                                    ed_module.altermagnetic_xy_diagnostics(
                                        negative,
                                        options.omega;
                                        eta=options.eta,
                                    )
                                push!(response_rows, _response_row(
                                    positive,
                                    positive_tuning,
                                    negative,
                                    negative_tuning,
                                    options,
                                    positive_diagnostics,
                                    negative_diagnostics,
                                ))
                                if spectral_exported
                                    _write_spectral_point!(
                                        pole_io, sum_rule_io, akw_io, dos_io,
                                        positive,
                                        POSITIVE_FIELD_ROLE,
                                        options,
                                        positive_diagnostics.broadened,
                                    )
                                    _write_spectral_point!(
                                        pole_io, sum_rule_io, akw_io, dos_io,
                                        negative,
                                        NEGATIVE_FIELD_ROLE,
                                        options,
                                        negative_diagnostics.broadened,
                                    )
                                    positive_spectra[U] = positive_diagnostics.broadened
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    _write_rows(
        joinpath(staging, "periodic_L2_field_points.csv"),
        field_rows,
    )
    _write_rows(
        joinpath(staging, "periodic_L2_zero_field_symmetry_audit.csv"),
        zero_rows,
    )
    _write_rows(
        joinpath(staging, "periodic_L2_explicit_field_response.csv"),
        response_rows,
    )
    _write_rows(
        joinpath(staging, "periodic_L2_full_spectrum_summary.csv"),
        full_spectrum_rows,
    )
    plot_paths = options.plots ? _plot_outputs(
        staging,
        options,
        zero_rows,
        response_rows,
        zero_spectra,
        positive_spectra,
    ) : String[]
    _write_metadata(
        joinpath(staging, "metadata.txt"),
        options,
        zero_rows,
        response_rows,
        plot_paths,
    )
    return (
        field_points=field_rows,
        zero_field_audit=zero_rows,
        explicit_field_response=response_rows,
        full_spectrum_summary=full_spectrum_rows,
        plot_filenames=basename.(plot_paths),
        limitation=LIMITATION,
    )
end

_destination_exists(path) = ispath(path) || islink(path)

"""
    run_request(options; ed_module=ClusterED)

Run the periodic `2 x 2` study and write immutable CSV outputs. Every `U` is
solved at zero field, where spin equality is treated only as a numerical audit.
If `probe_h>0`, the same point is also solved at `+probe_h` and `-probe_h`; the
central response is explicitly source-selected and is never labeled as
spontaneous symmetry breaking.

All files are first written to a temporary sibling of the requested output
directory. A completed study is published with one same-filesystem rename, and
an existing destination is never overwritten.
"""
function run_request(options; ed_module=ClusterED)
    destination = options.output_dir
    _destination_exists(destination) && throw(ArgumentError(
        "refusing to overwrite output directory: $destination",
    ))
    options.ensemble == :fixed_density && _require_tuner(ed_module)
    parameters = ed_module.ValidatedKinetic.ModelParameters(; options.hopping...)
    parent = dirname(destination)
    mkpath(parent)
    staging = mktempdir(parent; prefix=".$(basename(destination)).tmp-")
    try
        payload = _write_request(staging, options, ed_module, parameters)
        _destination_exists(destination) && throw(ArgumentError(
            "refusing to overwrite output directory created while the run was active: " *
            destination,
        ))
        # staging is a sibling, so rename is an atomic publication on this filesystem.
        Base.Filesystem.rename(staging, destination)
        return merge((output_dir=destination,), payload)
    catch
        _destination_exists(staging) && rm(staging; recursive=true, force=true)
        rethrow()
    end
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        usage()
        return nothing
    end
    result = run_request(options)
    println(LIMITATION)
    failures = count(
        row -> row.numerical_spin_symmetry_audit_failed,
        result.zero_field_audit,
    )
    println("Zero-field numerical spin-audit failures: $failures")
    println("Saved periodic L2 ED request to $(result.output_dir)")
    return result
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    try
        PeriodicL2EDRequest.main()
    catch exception
        println(stderr, "ERROR: ", sprint(showerror, exception))
        println(stderr, "Run with --help for usage.")
        exit(1)
    end
end
