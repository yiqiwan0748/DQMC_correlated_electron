#!/usr/bin/env julia

module PeriodicL2GroundStateED

ENV["GKSwstype"] = get(ENV, "GKSwstype", "100")

using Plots

include(joinpath(@__DIR__, "two_orbital_cluster_ed.jl"))
const ClusterED = TwoOrbitalClusterED

export main,
       momentum_label,
       parse_options,
       run_ground_state_request,
       usage

const ZERO_FIELD_ROLE = "zero_field_ground_state"
const POSITIVE_FIELD_ROLE = "explicit_source_plus_h"
const NEGATIVE_FIELD_ROLE = "explicit_source_minus_h"
const REDUCED_POSITIVE_FIELD_ROLE = "explicit_source_plus_reduced_h"
const REDUCED_NEGATIVE_FIELD_ROLE = "explicit_source_minus_reduced_h"
const LIMITATION =
    "Periodic L=2 exactly cancels t4. A finite canonical cluster cannot " *
    "spontaneously select an altermagnetic domain; nonzero h_alm results are " *
    "explicit-source responses, not a bulk critical interaction."

function usage(io::IO=stdout)
    print(io, """
Usage: julia --project=. scripts/run_periodic_l2_ground_state_ed.jl [options]

  --output-dir=PATH                 New output directory
                                      [results/periodic_l2_ground_state_ed]
  --particle-number=6               Fixed canonical particle number, 1..15
  --U-min=0 --U-max=20 --U-step=1  Interaction grid
  --spectral-U=2,3,4                Required low-U spectral comparison points
  --high-U=8,10,12,20               Additional spectral points ('none' disables)
  --full-spectrum-U=none            U values at which labeled levels are written
  --probe-h=0.001                   Explicit source magnitude (0 disables fields)
  --reduced-field-ratio=0.1         Reduced source is this fraction of probe-h
  --degeneracy-tolerance=1e-10      Ground-manifold energy tolerance
  --audit-tolerance=2e-10           Zero-field numerical symmetry tolerance
  --eta=0.15                        Lorentzian half-width for plotted spectra
  --omega-min=-30 --omega-max=30 --omega-points=1201
  --t1=-1 --t2=-1.75 --t3=-0.85 --t4=-0.65
  --plots=true|false                Write ground-state summary plots [true]

The calculation is canonical and at T=0. For N=6 on four cells the density is
exactly n=1.5; n=1.42 is not an allowed pure canonical ground-state filling.
All spectral frequencies use the solver's N<->N+/-1 midgap reference.
$(LIMITATION)
""")
end

function _finite_float(value::AbstractString, name::AbstractString)
    parsed = try
        parse(Float64, value)
    catch
        throw(ArgumentError("--$name must be a real number"))
    end
    isfinite(parsed) || throw(ArgumentError("--$name must be finite"))
    return parsed
end

function _integer(
    value::AbstractString,
    name::AbstractString;
    minimum::Int=1,
    maximum::Int=typemax(Int),
)
    parsed = try
        parse(Int, value)
    catch
        throw(ArgumentError("--$name must be an integer"))
    end
    minimum <= parsed <= maximum || throw(ArgumentError(
        "--$name must lie between $minimum and $maximum",
    ))
    return parsed
end

function _boolean(value::AbstractString, name::AbstractString)
    lowercase(value) == "true" && return true
    lowercase(value) == "false" && return false
    throw(ArgumentError("--$name must be true or false"))
end

function _interaction_grid(first_value::Float64, last_value::Float64, step::Float64)
    first_value >= 0 || throw(ArgumentError("--U-min must be nonnegative"))
    last_value >= first_value ||
        throw(ArgumentError("--U-max must be at least --U-min"))
    step > 0 || throw(ArgumentError("--U-step must be positive"))
    ratio = (last_value - first_value) / step
    isfinite(ratio) && ratio <= typemax(Int) ||
        throw(ArgumentError("interaction grid is too large"))
    intervals = round(Int, ratio)
    isapprox(
        first_value + intervals * step,
        last_value;
        atol=1.0e-12,
        rtol=1.0e-12,
    ) || throw(ArgumentError("--U-step must land on --U-max"))
    return collect(range(first_value, last_value; length=intervals + 1))
end

function _float_list(value::AbstractString, name::AbstractString; allow_none=false)
    stripped = strip(value)
    if allow_none && lowercase(stripped) in ("", "none")
        return Float64[]
    end
    isempty(stripped) && throw(ArgumentError("--$name must not be empty"))
    entries = split(stripped, ',')
    any(entry -> isempty(strip(entry)), entries) && throw(ArgumentError(
        "--$name must be a comma-separated number list",
    ))
    values = [_finite_float(strip(entry), name) for entry in entries]
    all(>=(0), values) ||
        throw(ArgumentError("--$name values must be nonnegative"))
    length(unique(values)) == length(values) ||
        throw(ArgumentError("--$name contains a duplicate"))
    return values
end

function _canonical_selected_U(requested, grid, name)
    canonical = Float64[]
    for value in requested
        index = findfirst(candidate -> isapprox(
            candidate,
            value;
            atol=1.0e-12,
            rtol=1.0e-12,
        ), grid)
        isnothing(index) && throw(ArgumentError(
            "--$name value $value is not on the requested interaction grid",
        ))
        push!(canonical, grid[index])
    end
    return canonical
end

"""Parse the standalone canonical ground-state ED options."""
function parse_options(arguments=ARGS)
    any(argument -> argument in ("-h", "--help"), arguments) && return nothing
    allowed = Set([
        "output-dir", "particle-number", "U-min", "U-max", "U-step",
        "spectral-U", "high-U", "full-spectrum-U", "probe-h",
        "reduced-field-ratio", "degeneracy-tolerance", "audit-tolerance",
        "eta", "omega-min", "omega-max", "omega-points",
        "t1", "t2", "t3", "t4", "plots",
    ])
    raw = Dict{String,String}()
    for argument in arguments
        startswith(argument, "--") && occursin('=', argument) ||
            throw(ArgumentError("options must use --name=value: $argument"))
        name, value = split(argument[3:end], '='; limit=2)
        name in allowed || throw(ArgumentError("unknown option --$name"))
        haskey(raw, name) && throw(ArgumentError("duplicate option --$name"))
        raw[name] = value
    end

    U_values = _interaction_grid(
        _finite_float(get(raw, "U-min", "0"), "U-min"),
        _finite_float(get(raw, "U-max", "20"), "U-max"),
        _finite_float(get(raw, "U-step", "1"), "U-step"),
    )
    spectral_U = _canonical_selected_U(
        _float_list(get(raw, "spectral-U", "2,3,4"), "spectral-U"),
        U_values,
        "spectral-U",
    )
    high_U = _canonical_selected_U(
        _float_list(get(raw, "high-U", "8,10,12,20"), "high-U"; allow_none=true),
        U_values,
        "high-U",
    )
    full_spectrum_U = _canonical_selected_U(
        _float_list(
            get(raw, "full-spectrum-U", "none"),
            "full-spectrum-U";
            allow_none=true,
        ),
        U_values,
        "full-spectrum-U",
    )
    spectral_output_U = sort!(unique(vcat(spectral_U, high_U)))

    probe_h = _finite_float(get(raw, "probe-h", "0.001"), "probe-h")
    probe_h >= 0 || throw(ArgumentError("--probe-h must be nonnegative"))
    reduced_field_ratio = _finite_float(
        get(raw, "reduced-field-ratio", "0.1"),
        "reduced-field-ratio",
    )
    0 < reduced_field_ratio < 1 || throw(ArgumentError(
        "--reduced-field-ratio must lie strictly between zero and one",
    ))
    degeneracy_tolerance = _finite_float(
        get(raw, "degeneracy-tolerance", "1e-10"),
        "degeneracy-tolerance",
    )
    degeneracy_tolerance > 0 || throw(ArgumentError(
        "--degeneracy-tolerance must be positive",
    ))
    audit_tolerance = _finite_float(
        get(raw, "audit-tolerance", "2e-10"),
        "audit-tolerance",
    )
    audit_tolerance >= 0 ||
        throw(ArgumentError("--audit-tolerance must be nonnegative"))
    eta = _finite_float(get(raw, "eta", "0.15"), "eta")
    eta > 0 || throw(ArgumentError("--eta must be positive"))
    omega_min = _finite_float(get(raw, "omega-min", "-30"), "omega-min")
    omega_max = _finite_float(get(raw, "omega-max", "30"), "omega-max")
    omega_min < omega_max ||
        throw(ArgumentError("--omega-min must be below --omega-max"))
    omega_points = _integer(
        get(raw, "omega-points", "1201"),
        "omega-points";
        minimum=3,
    )
    hopping = (
        t1=_finite_float(get(raw, "t1", "-1"), "t1"),
        t2=_finite_float(get(raw, "t2", "-1.75"), "t2"),
        t3=_finite_float(get(raw, "t3", "-0.85"), "t3"),
        t4=_finite_float(get(raw, "t4", "-0.65"), "t4"),
    )
    all(iszero, values(hopping)) && throw(ArgumentError(
        "at least one hopping must be nonzero for the requested spectral study",
    ))
    return (
        output_dir=abspath(get(
            raw,
            "output-dir",
            "results/periodic_l2_ground_state_ed",
        )),
        particle_number=_integer(
            get(raw, "particle-number", "6"),
            "particle-number";
            minimum=1,
            maximum=15,
        ),
        U_values=U_values,
        spectral_U=spectral_U,
        high_U=high_U,
        spectral_output_U=spectral_output_U,
        full_spectrum_U=full_spectrum_U,
        probe_h=probe_h,
        reduced_field_ratio=reduced_field_ratio,
        degeneracy_tolerance=degeneracy_tolerance,
        audit_tolerance=audit_tolerance,
        eta=eta,
        omega=collect(range(omega_min, omega_max; length=omega_points)),
        hopping=hopping,
        plots=_boolean(get(raw, "plots", "true"), "plots"),
    )
end

"""Return the conventional label for one of the four periodic-L2 momenta."""
function momentum_label(kx_index::Integer, ky_index::Integer)
    labels = Dict((1, 1) => "Gamma", (2, 1) => "X", (1, 2) => "Y", (2, 2) => "M")
    return get(labels, (Int(kx_index), Int(ky_index))) do
        throw(ArgumentError("periodic L2 momentum indices must each be 1 or 2"))
    end
end

_contains_U(values, U) = any(==(U), values)

function _property(value, names::Tuple; default=nothing, required=false)
    for name in names
        hasproperty(value, name) && return getproperty(value, name)
    end
    required && throw(ErrorException(
        "ground-state solver result is missing one of the fields $(names)",
    ))
    return default
end

_energy(level) = Float64(_property(
    level,
    (:canonical_energy, :energy, :grand_energy);
    required=true,
))

function _result_reference(result)
    return _property(result, (:mu_reference, :mu); default=missing)
end

function _csv_value(value)
    value === missing && return ""
    value === nothing && return ""
    text = string(value)
    return occursin(',', text) || occursin('"', text) || occursin('\n', text) ?
        "\"" * replace(text, "\"" => "\"\"") * "\"" : text
end

function _write_rows(path::AbstractString, rows)
    isempty(rows) && return nothing
    columns = collect(keys(first(rows)))
    all(row -> collect(keys(row)) == columns, rows) ||
        throw(ArgumentError("CSV rows must have identical columns"))
    open(path, "w") do io
        println(io, join(string.(columns), ','))
        for row in rows
            println(io, join(
                (_csv_value(getproperty(row, column)) for column in columns),
                ',',
            ))
        end
    end
    return path
end

function _require_ground_api(ed_module)
    isdefined(ed_module, :solve_two_orbital_ground_state) || throw(ErrorException(
        "ground-state mode requires TwoOrbitalClusterED." *
        "solve_two_orbital_ground_state",
    ))
    return getproperty(ed_module, :solve_two_orbital_ground_state)
end

function _solve_point(options, ed_module, parameters, U, h; full_spectrum=false)
    solver = _require_ground_api(ed_module)
    result = solver(
        U,
        options.particle_number;
        parameters=parameters,
        h_alm=h,
        degeneracy_tolerance=options.degeneracy_tolerance,
        mu_reference=:midgap,
        include_full_spectrum=full_spectrum,
    )
    _property(result, (:spectral_peaks,); required=true)
    result_N = _property(result, (:N, :particle_number); required=true)
    result_N == options.particle_number || throw(ErrorException(
        "ground-state solver returned N=$result_N for requested " *
        "N=$(options.particle_number)",
    ))
    return result
end

function _full_levels(result)
    levels = _property(
        result,
        (:full_many_body_levels, :labeled_levels, :many_body_levels);
        required=true,
    )
    isnothing(levels) && throw(ErrorException(
        "ground-state spin audit requires include_full_spectrum=true",
    ))
    return levels
end

function _fixed_N_levels(result, particle_number)
    return [level for level in _full_levels(result)
            if Int(_property(level, (:N,); required=true)) == particle_number]
end

function _spectral_spin_pairing(result)
    peaks = result.spectral_peaks
    frequency_error = 0.0
    weight_error = 0.0
    length_mismatch = 0
    for orbital in 1:2, ky in 1:2, kx in 1:2
        up = peaks[1, orbital, kx, ky]
        down = peaks[2, orbital, kx, ky]
        length_mismatch = max(
            length_mismatch,
            abs(length(up.frequencies) - length(down.frequencies)),
            abs(length(up.weights) - length(down.weights)),
        )
        if length(up.frequencies) == length(down.frequencies)
            frequency_error = max(
                frequency_error,
                maximum(abs, up.frequencies .- down.frequencies; init=0.0),
            )
        else
            frequency_error = Inf
        end
        if length(up.weights) == length(down.weights)
            weight_error = max(
                weight_error,
                maximum(abs, up.weights .- down.weights; init=0.0),
            )
        else
            weight_error = Inf
        end
    end
    return (
        frequency=frequency_error,
        weight=weight_error,
        length_mismatch=length_mismatch,
        maximum=max(frequency_error, weight_error),
    )
end

function _ground_sector_spin_audit(result, options)
    sector_rows = _property(result, (:sector_ground_energies,); default=nothing)
    groups = Dict{NTuple{4,Int},NamedTuple}()
    levels = nothing
    if isnothing(sector_rows)
        levels = _fixed_N_levels(result, options.particle_number)
        isempty(levels) && throw(ErrorException(
            "full labeled spectrum contains no N=$(options.particle_number) states",
        ))
        energy_groups = Dict{NTuple{4,Int},Vector{Float64}}()
        for level in levels
            key = (
                Int(_property(level, (:Nup, :N_up); required=true)),
                Int(_property(level, (:Ndown, :N_down); required=true)),
                Int(_property(level, (:kx_index,); required=true)),
                Int(_property(level, (:ky_index,); required=true)),
            )
            push!(get!(energy_groups, key, Float64[]), _energy(level))
        end
        for (key, energies) in energy_groups
            groups[key] = (energy=minimum(energies), dimension=length(energies))
        end
    else
        for row in sector_rows
            key = (
                Int(_property(row, (:Nup, :N_up); required=true)),
                Int(_property(row, (:Ndown, :N_down); required=true)),
                Int(_property(row, (:kx_index,); required=true)),
                Int(_property(row, (:ky_index,); required=true)),
            )
            groups[key] = (
                energy=_energy(row),
                dimension=Int(_property(row, (:dimension,); required=true)),
            )
        end
    end
    sector_ground_error = 0.0
    sector_length_mismatch = 0
    for ((nup, ndown, kx, ky), sector) in groups
        partner = get(groups, (ndown, nup, kx, ky), nothing)
        isnothing(partner) && begin
            sector_ground_error = Inf
            sector_length_mismatch = max(sector_length_mismatch, sector.dimension)
            continue
        end
        sector_length_mismatch = max(
            sector_length_mismatch,
            abs(sector.dimension - partner.dimension),
        )
        sector_ground_error = max(
            sector_ground_error,
            abs(sector.energy - partner.energy),
        )
    end

    ground_energy = Float64(_property(
        result,
        (:ground_energy, :canonical_ground_energy);
        required=true,
    ))
    ground_levels = _property(result, (:ground_levels, :ground_states); default=nothing)
    if isnothing(ground_levels)
        isnothing(levels) && throw(ErrorException(
            "ground-state solver result must provide ground_levels",
        ))
        ground_levels = [level for level in levels if
                         abs(_energy(level) - ground_energy) <=
                         options.degeneracy_tolerance]
    end
    ground_groups = Dict{NTuple{3,Int},Int}()
    for level in ground_levels
        twice_sz = Int(round(2Float64(_property(level, (:Sz,); required=true))))
        key = (
            twice_sz,
            Int(_property(level, (:kx_index,); required=true)),
            Int(_property(level, (:ky_index,); required=true)),
        )
        ground_groups[key] = get(ground_groups, key, 0) + 1
    end
    ground_partner_count_mismatch = maximum((
        abs(count - get(ground_groups, (-twice_sz, kx, ky), 0))
        for ((twice_sz, kx, ky), count) in ground_groups
    ); init=0)
    momenta = sort!(unique(
        momentum_label(
            Int(_property(level, (:kx_index,); required=true)),
            Int(_property(level, (:ky_index,); required=true)),
        ) for level in ground_levels
    ))
    spins = sort!(unique(Float64(
        _property(level, (:Sz,); required=true),
    ) for level in ground_levels))
    expected_fixed_N_dimension = binomial(16, options.particle_number)
    fixed_N_level_count = sum(sector.dimension for sector in values(groups))
    return (
        ground_energy=ground_energy,
        ground_degeneracy=length(ground_levels),
        ground_momenta=join(momenta, ';'),
        ground_Sz=join(spins, ';'),
        fixed_N_level_count=fixed_N_level_count,
        expected_fixed_N_dimension=expected_fixed_N_dimension,
        complete_fixed_N_spectrum=fixed_N_level_count == expected_fixed_N_dimension,
        sector_ground_energy_max_difference=sector_ground_error,
        sector_dimension_max_mismatch=sector_length_mismatch,
        ground_partner_count_max_mismatch=ground_partner_count_mismatch,
        sectors_checked=length(groups),
    )
end

function _ground_pairing(ed_module, result)
    if isdefined(ed_module, :ground_state_spin_pairing_error)
        pairing = ed_module.ground_state_spin_pairing_error(result)
        return (
            frequency=pairing.frequency,
            weight=pairing.weight,
            length_mismatch=pairing.length_mismatch,
            maximum=pairing.maximum,
        )
    end
    return _spectral_spin_pairing(result)
end

function _broadener(ed_module, result, options)
    isdefined(ed_module, :broaden_cluster_spectra) || throw(ErrorException(
        "ground-state output requires broaden_cluster_spectra",
    ))
    return ed_module.broaden_cluster_spectra(
        result,
        options.omega;
        eta=options.eta,
    )
end

function _xy_diagnostics(ed_module, result, options)
    isdefined(ed_module, :altermagnetic_xy_diagnostics) || throw(ErrorException(
        "ground-state output requires altermagnetic_xy_diagnostics",
    ))
    return ed_module.altermagnetic_xy_diagnostics(
        result,
        options.omega;
        eta=options.eta,
    )
end

function _observable(result, names; default=missing)
    return _property(result, names; default=default)
end

function _field_point_row(result, options, U, h, role)
    return (
        U=U,
        particle_number=options.particle_number,
        density_per_cell=options.particle_number / 4,
        field_role=role,
        interpretation=role == ZERO_FIELD_ROLE ?
            "zero_field_finite_cluster_ground_state" :
            "explicit_source_selected_ground_state_not_spontaneous_order",
        h_alm=h,
        mu_reference=_result_reference(result),
        ground_energy=_observable(
            result,
            (:ground_energy, :canonical_ground_energy);
            default=missing,
        ),
        ground_degeneracy=_observable(result, (:ground_degeneracy,); default=missing),
        excitation_gap=_observable(
            result,
            (:excitation_gap, :ground_gap, :same_N_gap, :gap);
            default=missing,
        ),
        double_occupancy_per_cell=_observable(
            result,
            (:double_occupancy_per_cell, :double_occupancy);
            default=missing,
        ),
        delta_alm_per_cell=_observable(
            result,
            (:delta_alm_per_cell, :delta_alm, :o_alm_per_cell);
            default=missing,
        ),
        o_alm_squared_per_cell_squared=_observable(
            result,
            (:o_alm_squared_per_cell_squared, :o_alm2_per_cell2, :o_alm_squared);
            default=missing,
        ),
        total_spin_z_per_cell=_observable(
            result,
            (:total_spin_z_per_cell,);
            default=missing,
        ),
        spectral_moment_max_error=_observable(
            result,
            (:spectral_moment_max_error,);
            default=missing,
        ),
    )
end

function _zero_field_row(result, audit, pairing, broadened, options, U)
    broadened_error = maximum(
        abs,
        broadened.dos[1, :] .- broadened.dos[2, :];
        init=0.0,
    )
    maximum_error = max(
        audit.sector_ground_energy_max_difference,
        pairing.maximum,
        broadened_error,
    )
    failed = audit.sector_dimension_max_mismatch != 0 ||
             audit.ground_partner_count_max_mismatch != 0 ||
             pairing.length_mismatch != 0 ||
             maximum_error > options.audit_tolerance
    return (
        U=U,
        particle_number=options.particle_number,
        density_per_cell=options.particle_number / 4,
        ground_energy=audit.ground_energy,
        ground_degeneracy=audit.ground_degeneracy,
        ground_momenta=audit.ground_momenta,
        ground_Sz=audit.ground_Sz,
        fixed_N_level_count=audit.fixed_N_level_count,
        expected_fixed_N_dimension=audit.expected_fixed_N_dimension,
        complete_fixed_N_spectrum=audit.complete_fixed_N_spectrum,
        spin_flipped_sector_ground_energy_max_difference=
            audit.sector_ground_energy_max_difference,
        spin_flipped_sector_dimension_max_mismatch=
            audit.sector_dimension_max_mismatch,
        ground_manifold_spin_partner_count_max_mismatch=
            audit.ground_partner_count_max_mismatch,
        spin_sectors_checked=audit.sectors_checked,
        spectral_pole_frequency_max_difference=pairing.frequency,
        spectral_pole_weight_max_difference=pairing.weight,
        spectral_pole_length_mismatch=pairing.length_mismatch,
        broadened_spin_dos_max_difference=broadened_error,
        maximum_zero_field_spin_audit_error=maximum_error,
        audit_tolerance=options.audit_tolerance,
        numerical_spin_symmetry_audit_failed=failed,
        spontaneous_breaking_assessable=false,
        t4_cancellation_max_abs=maximum(
            abs,
            _property(result, (:kinetic,); required=true)[1:2:end, 2:2:end];
            init=0.0,
        ),
    )
end

function _field_reversal_error(positive, negative)
    positive_peaks = positive.spectral_peaks
    negative_peaks = negative.spectral_peaks
    frequency_error = 0.0
    weight_error = 0.0
    length_mismatch = 0
    for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
        partner_spin = 3 - spin
        left = positive_peaks[spin, orbital, kx, ky]
        right = negative_peaks[partner_spin, orbital, kx, ky]
        length_mismatch = max(
            length_mismatch,
            abs(length(left.frequencies) - length(right.frequencies)),
            abs(length(left.weights) - length(right.weights)),
        )
        if length(left.frequencies) == length(right.frequencies)
            frequency_error = max(
                frequency_error,
                maximum(abs, left.frequencies .- right.frequencies; init=0.0),
            )
        else
            frequency_error = Inf
        end
        if length(left.weights) == length(right.weights)
            weight_error = max(
                weight_error,
                maximum(abs, left.weights .- right.weights; init=0.0),
            )
        else
            weight_error = Inf
        end
    end
    return (
        frequency=frequency_error,
        weight=weight_error,
        length_mismatch=length_mismatch,
        maximum=max(frequency_error, weight_error),
    )
end

function _float_observable(result, names)
    value = _property(result, names; required=true)
    value === missing && throw(ErrorException("required ground observable $(names) is missing"))
    return Float64(value)
end

function _response_row(
    U,
    positive,
    negative,
    reduced_positive,
    reduced_negative,
    positive_diagnostics,
    negative_diagnostics,
    reduced_positive_diagnostics,
    reduced_negative_diagnostics,
    options,
)
    h = options.probe_h
    reduced_h = h * options.reduced_field_ratio
    delta_names = (:delta_alm_per_cell, :delta_alm, :o_alm_per_cell)
    delta_plus = _float_observable(positive, delta_names)
    delta_minus = _float_observable(negative, delta_names)
    reduced_delta_plus = _float_observable(reduced_positive, delta_names)
    reduced_delta_minus = _float_observable(reduced_negative, delta_names)
    reversal = _field_reversal_error(positive, negative)
    reduced_reversal = _field_reversal_error(reduced_positive, reduced_negative)
    full_secant = (delta_plus - delta_minus) / (2h)
    reduced_secant = (reduced_delta_plus - reduced_delta_minus) / (2reduced_h)
    energy_names = (:ground_energy, :canonical_ground_energy)
    energy_plus = _float_observable(positive, energy_names)
    energy_minus = _float_observable(negative, energy_names)
    reduced_energy_plus = _float_observable(reduced_positive, energy_names)
    reduced_energy_minus = _float_observable(reduced_negative, energy_names)
    return (
        U=U,
        particle_number=options.particle_number,
        density_per_cell=options.particle_number / 4,
        interpretation="finite_source_secants_not_spontaneous_order_or_linear_susceptibility",
        probe_h=h,
        reduced_h=reduced_h,
        reduced_field_ratio=options.reduced_field_ratio,
        delta_alm_plus=delta_plus,
        delta_alm_minus=delta_minus,
        reduced_delta_alm_plus=reduced_delta_plus,
        reduced_delta_alm_minus=reduced_delta_minus,
        symmetric_source_secant_at_h=full_secant,
        symmetric_source_secant_at_reduced_h=reduced_secant,
        source_secant_difference=abs(full_secant - reduced_secant),
        field_reversal_delta_odd_error=abs(delta_plus + delta_minus),
        reduced_field_reversal_delta_odd_error=abs(
            reduced_delta_plus + reduced_delta_minus,
        ),
        field_reversal_ground_energy_even_error=abs(energy_plus - energy_minus),
        reduced_field_reversal_ground_energy_even_error=abs(
            reduced_energy_plus - reduced_energy_minus,
        ),
        field_reversal_spectral_frequency_max_error=reversal.frequency,
        field_reversal_spectral_weight_max_error=reversal.weight,
        field_reversal_spectral_length_mismatch=reversal.length_mismatch,
        reduced_field_reversal_spectral_frequency_max_error=
            reduced_reversal.frequency,
        reduced_field_reversal_spectral_weight_max_error=reduced_reversal.weight,
        reduced_field_reversal_spectral_length_mismatch=
            reduced_reversal.length_mismatch,
        positive_h_X_spin_contrast_max=
            positive_diagnostics.x_same_momentum_spin_contrast_max,
        positive_h_Y_spin_contrast_max=
            positive_diagnostics.y_same_momentum_spin_contrast_max,
        positive_h_XY_rotated_partner_max_error=
            positive_diagnostics.xy_rotated_partner_max_error,
        positive_h_XY_contrast_antisymmetry_max_error=
            positive_diagnostics.xy_contrast_antisymmetry_max_error,
        positive_h_spin_DOS_max_difference=
            positive_diagnostics.dos_spin_max_error,
        negative_h_XY_rotated_partner_max_error=
            negative_diagnostics.xy_rotated_partner_max_error,
        reduced_positive_h_X_spin_contrast_max=
            reduced_positive_diagnostics.x_same_momentum_spin_contrast_max,
        reduced_positive_h_Y_spin_contrast_max=
            reduced_positive_diagnostics.y_same_momentum_spin_contrast_max,
        reduced_positive_h_XY_rotated_partner_max_error=
            reduced_positive_diagnostics.xy_rotated_partner_max_error,
        reduced_positive_h_XY_contrast_antisymmetry_max_error=
            reduced_positive_diagnostics.xy_contrast_antisymmetry_max_error,
        reduced_positive_h_spin_DOS_max_difference=
            reduced_positive_diagnostics.dos_spin_max_error,
        reduced_negative_h_XY_rotated_partner_max_error=
            reduced_negative_diagnostics.xy_rotated_partner_max_error,
        spontaneous_breaking_assessable=false,
    )
end

function _write_spectral_point!(
    pole_io,
    sum_rule_io,
    akw_io,
    dos_io,
    result,
    U,
    h,
    role,
    options,
    broadened,
)
    reference = _result_reference(result)
    momenta = _property(result, (:momenta,); required=true)
    for spin in 1:2, orbital in 1:2, ky_index in 1:2, kx_index in 1:2
        channel = result.spectral_peaks[spin, orbital, kx_index, ky_index]
        label = momentum_label(kx_index, ky_index)
        for (frequency, weight) in zip(channel.frequencies, channel.weights)
            println(pole_io, join((
                U, options.particle_number, role, h, reference,
                spin == 1 ? "up" : "down", orbital,
                kx_index, ky_index, label,
                momenta[kx_index], momenta[ky_index], frequency, weight,
            ), ','))
        end
        weight_sum = sum(channel.weights)
        println(sum_rule_io, join((
            U, options.particle_number, role, h, reference,
            spin == 1 ? "up" : "down", orbital,
            kx_index, ky_index, label, length(channel.frequencies),
            weight_sum, abs(weight_sum - 1),
        ), ','))
        for omega_index in eachindex(options.omega)
            println(akw_io, join((
                U, options.particle_number, role, h, reference,
                spin == 1 ? "up" : "down", orbital,
                kx_index, ky_index, label,
                momenta[kx_index], momenta[ky_index],
                options.omega[omega_index],
                broadened.spectral[
                    spin,
                    orbital,
                    kx_index,
                    ky_index,
                    omega_index,
                ],
                options.eta,
            ), ','))
        end
    end
    for omega_index in eachindex(options.omega)
        println(dos_io, join((
            U, options.particle_number, role, h, reference,
            options.omega[omega_index],
            broadened.dos[1, omega_index],
            broadened.dos[2, omega_index],
            broadened.total_dos[omega_index],
            options.eta,
        ), ','))
    end
    return nothing
end

function _write_full_levels!(io, result, U, options)
    levels = _full_levels(result)
    fixed_count = 0
    for (index, level) in enumerate(levels)
        N = Int(_property(level, (:N,); required=true))
        N == options.particle_number && (fixed_count += 1)
        nup = Int(_property(level, (:Nup, :N_up); required=true))
        ndown = Int(_property(level, (:Ndown, :N_down); required=true))
        kx = Int(_property(level, (:kx_index,); required=true))
        ky = Int(_property(level, (:ky_index,); required=true))
        println(io, join((
            U, ZERO_FIELD_ROLE, 0.0, _result_reference(result), index,
            nup, ndown, N,
            _property(level, (:Sz,); required=true),
            kx, ky, momentum_label(kx, ky),
            (kx - 1) * pi, (ky - 1) * pi, _energy(level),
        ), ','))
    end
    return (
        U=U,
        particle_number=options.particle_number,
        mu_reference=_result_reference(result),
        labeled_level_count=length(levels),
        fixed_N_level_count=fixed_count,
        expected_fixed_N_dimension=binomial(16, options.particle_number),
        interpretation="many_body_levels_not_single_particle_bands",
    )
end

function _plot_outputs(
    staging,
    options,
    zero_rows,
    response_rows,
    spectra,
)
    output_paths = String[]
    selected_U = sort!(collect(Set(U for (U, role) in keys(spectra)
                                   if role == ZERO_FIELD_ROLE)))
    zero_panels = Any[]
    for U in selected_U
        spectrum = spectra[(U, ZERO_FIELD_ROLE)]
        panel = plot(
            spectrum.omega,
            spectrum.dos[1, :];
            label="spin up",
            color=:red,
            linewidth=2,
            xlabel="omega",
            ylabel="DOS per spin",
            title="h_alm=0, U=$U",
        )
        plot!(
            panel,
            spectrum.omega,
            spectrum.dos[2, :];
            label="spin down",
            color=:blue,
            linewidth=2,
            linestyle=:dash,
        )
        push!(zero_panels, panel)
    end
    if !isempty(zero_panels)
        path = joinpath(staging, "periodic_L2_ground_state_zero_field_spin_DOS.png")
        savefig(
            plot(
                zero_panels...;
                layout=(1, length(zero_panels)),
                size=(max(650, 470 * length(zero_panels)), 430),
                plot_title="T=0 canonical zero-field DOS: spin equality audit",
            ),
            path,
        )
        push!(output_paths, path)
    end

    if options.probe_h > 0 && !isempty(selected_U)
        xy_panels = Any[]
        contrast_panels = Any[]
        for U in selected_U
            role = POSITIVE_FIELD_ROLE
            haskey(spectra, (U, role)) || continue
            spectrum = spectra[(U, role)]
            panel = plot(
                spectrum.omega,
                spectrum.spin_trace[1, 2, 1, :];
                label="X up",
                color=:red,
                linewidth=2,
                xlabel="omega",
                ylabel="orbital-summed A(k,omega)",
                title="explicit +h=$(options.probe_h), U=$U",
            )
            plot!(panel, spectrum.omega, spectrum.spin_trace[2, 2, 1, :];
                  label="X down", color=:blue, linewidth=2, linestyle=:dash)
            plot!(panel, spectrum.omega, spectrum.spin_trace[1, 1, 2, :];
                  label="Y up", color=:orange, linewidth=2, linestyle=:dot)
            plot!(panel, spectrum.omega, spectrum.spin_trace[2, 1, 2, :];
                  label="Y down", color=:purple, linewidth=2, linestyle=:dashdot)
            push!(xy_panels, panel)

            reduced = spectra[(U, REDUCED_POSITIVE_FIELD_ROLE)]
            delta_x = reduced.spin_trace[1, 2, 1, :] .-
                      reduced.spin_trace[2, 2, 1, :]
            delta_y = reduced.spin_trace[1, 1, 2, :] .-
                      reduced.spin_trace[2, 1, 2, :]
            reduced_h = options.probe_h * options.reduced_field_ratio
            contrast = plot(
                reduced.omega,
                delta_x;
                label="Delta A at X",
                color=:darkred,
                linewidth=2,
                xlabel="omega",
                ylabel="A_up-A_down",
                title="explicit +h=$reduced_h, U=$U",
            )
            plot!(contrast, reduced.omega, delta_y;
                  label="Delta A at Y", color=:navy, linewidth=2, linestyle=:dash)
            hline!(contrast, [0.0]; label="", color=:black, alpha=0.35)
            push!(contrast_panels, contrast)
        end
        if !isempty(xy_panels)
            path = joinpath(
                staging,
                "periodic_L2_ground_state_explicit_field_XY_Akw.png",
            )
            savefig(
                plot(
                    vcat(xy_panels, contrast_panels)...;
                    layout=(2, length(xy_panels)),
                    size=(max(750, 490 * length(xy_panels)), 790),
                    plot_title="T=0 explicit-source X/Y response (not spontaneous order)",
                ),
                path,
            )
            push!(output_paths, path)
        end
    end

    interactions = getproperty.(zero_rows, :U)
    errors = max.(
        getproperty.(zero_rows, :maximum_zero_field_spin_audit_error),
        eps(Float64),
    )
    audit_panel = plot(
        interactions,
        errors;
        marker=:circle,
        linewidth=2,
        yscale=:log10,
        label="zero-field spin audit",
        xlabel="U",
        ylabel="maximum absolute error",
        title="ground-sector and spectral spin pairing",
    )
    hline!(audit_panel, [max(options.audit_tolerance, eps(Float64))];
           label="audit tolerance", color=:black, linestyle=:dash)
    energy_panel = plot(
        interactions,
        getproperty.(zero_rows, :ground_energy);
        marker=:circle,
        linewidth=2,
        label="E0(N=$(options.particle_number))",
        xlabel="U",
        ylabel="canonical ground energy",
        title="T=0 fixed-N ground state",
    )
    path = joinpath(staging, "periodic_L2_ground_state_zero_field_U_scan.png")
    savefig(
        plot(
            audit_panel,
            energy_panel;
            layout=(1, 2),
            size=(1100, 430),
            plot_title="Periodic L=2 canonical zero-field ED",
        ),
        path,
    )
    push!(output_paths, path)

    if !isempty(response_rows)
        response_panel = plot(
            getproperty.(response_rows, :U),
            getproperty.(response_rows, :symmetric_source_secant_at_h);
            marker=:diamond,
            linewidth=2,
            label="symmetric secant at h",
            xlabel="U",
            ylabel="[Delta(+h)-Delta(-h)]/(2h)",
            title="finite-source response; level jumps allowed",
        )
        plot!(
            response_panel,
            getproperty.(response_rows, :U),
            getproperty.(response_rows, :symmetric_source_secant_at_reduced_h);
            marker=:circle,
            linewidth=2,
            linestyle=:dash,
            label="symmetric secant at reduced h",
        )
        path = joinpath(
            staging,
            "periodic_L2_ground_state_explicit_source_U_scan.png",
        )
        savefig(
            plot(
                response_panel;
                size=(700, 450),
                plot_title="Explicit-source diagnostic (not Uc or spontaneous order)",
            ),
            path,
        )
        push!(output_paths, path)
    end
    return output_paths
end

function _write_metadata(path, options, zero_rows, response_rows, plot_paths)
    open(path, "w") do io
        println(io, "Periodic 2x2 two-orbital canonical ground-state ED")
        println(io, LIMITATION)
        println(io, "temperature=T=0; ensemble=canonical; particle number=$(options.particle_number)")
        println(io, "density=$(options.particle_number / 4) electrons per physical cell")
        println(io, "n=1.42 is unavailable as a pure canonical state on four cells")
        println(io, "output publication=temporary sibling plus atomic rename; existing destinations are never overwritten")
        println(io, "8 spatial orbitals; 16 spin orbitals; full Hilbert dimension=65536")
        println(io, "N=0..16; physical Sz=-4..4; fixed-N dimension=binomial(16,N)")
        println(io, "momenta: Gamma=(0,0), X=(pi,0), Y=(0,pi), M=(pi,pi)")
        println(io, "U_values=$(options.U_values)")
        println(io, "required low-U spectra=$(options.spectral_U); additional high-U spectra=$(options.high_U)")
        println(io, "all spectral output U=$(options.spectral_output_U)")
        println(io, "full level exports=$(options.full_spectrum_U)")
        println(io, "source fields: h=0, +/-$(options.probe_h), +/-$(options.probe_h * options.reduced_field_ratio)")
        println(io, "field quotients are labeled symmetric finite-source secants, not linear susceptibilities")
        println(io, "finite-field level selection or level crossings can make the secants non-smooth")
        println(io, "hopping=$(options.hopping); periodic L2 t4 cancellation is exact")
        println(io, "raw T=0 Lehmann poles/weights are exact; Lorentzian eta=$(options.eta) is presentation only")
        println(io, "A(k,omega) connects the N-particle ground manifold to N+/-1 eigenstates")
        println(io, "spectral frequencies use mu_reference=:midgap")
        println(io, "zero-field spin equality is a numerical symmetry audit, not an order detector")
        println(io, "zero-field audit tolerance=$(options.audit_tolerance)")
        println(io, "zero-field audit failures=$(count(row -> row.numerical_spin_symmetry_audit_failed, zero_rows))")
        println(io, "explicit-source response rows=$(length(response_rows)); these are not spontaneous order")
        println(io, "plots enabled=$(options.plots); plot files=$(basename.(plot_paths))")
        println(io, "many-body energies are not single-particle bands; A(k,omega) contains transition poles")
        println(io, "ground solver API=solve_two_orbital_ground_state(U,N; parameters,h_alm,degeneracy_tolerance,mu_reference=:midgap,include_full_spectrum)")
    end
    return path
end

function _write_request(staging, options, ed_module, parameters)
    field_rows = NamedTuple[]
    zero_rows = NamedTuple[]
    response_rows = NamedTuple[]
    full_spectrum_rows = NamedTuple[]
    spectra = Dict{Tuple{Float64,String},Any}()
    pole_path = joinpath(staging, "periodic_L2_ground_state_raw_spectral_poles.csv")
    sum_rule_path = joinpath(staging, "periodic_L2_ground_state_spectral_sum_rules.csv")
    akw_path = joinpath(staging, "periodic_L2_ground_state_spin_orbital_Akw.csv")
    dos_path = joinpath(staging, "periodic_L2_ground_state_spin_resolved_DOS.csv")
    levels_path = joinpath(staging, "periodic_L2_ground_state_full_many_body_levels.csv")

    open(pole_path, "w") do pole_io
        open(sum_rule_path, "w") do sum_rule_io
            open(akw_path, "w") do akw_io
                open(dos_path, "w") do dos_io
                    open(levels_path, "w") do levels_io
                        println(pole_io, "U,N,field_role,h_alm,mu_reference,spin,orbital,kx_index,ky_index,momentum,kx,ky,omega,weight")
                        println(sum_rule_io, "U,N,field_role,h_alm,mu_reference,spin,orbital,kx_index,ky_index,momentum,pole_count,weight_sum,zeroth_moment_error")
                        println(akw_io, "U,N,field_role,h_alm,mu_reference,spin,orbital,kx_index,ky_index,momentum,kx,ky,omega,A,lorentzian_eta")
                        println(dos_io, "U,N,field_role,h_alm,mu_reference,omega,dos_up,dos_down,dos_total,lorentzian_eta")
                        println(levels_io, "U,field_role,h_alm,mu_reference,index,N_up,N_down,N,Sz,kx_index,ky_index,momentum,kx,ky,canonical_energy")

                        for U in options.U_values
                            spectral_exported = _contains_U(options.spectral_output_U, U)
                            full_exported = _contains_U(options.full_spectrum_U, U)
                            zero = _solve_point(
                                options,
                                ed_module,
                                parameters,
                                U,
                                0.0;
                                # Sector-ground tables suffice for the audit;
                                # reconstruct all 65,536 levels only when the
                                # user explicitly requests an export at this U.
                                full_spectrum=full_exported,
                            )
                            zero_broadened = _broadener(ed_module, zero, options)
                            audit = _ground_sector_spin_audit(zero, options)
                            pairing = _ground_pairing(ed_module, zero)
                            push!(field_rows, _field_point_row(
                                zero,
                                options,
                                U,
                                0.0,
                                ZERO_FIELD_ROLE,
                            ))
                            push!(zero_rows, _zero_field_row(
                                zero,
                                audit,
                                pairing,
                                zero_broadened,
                                options,
                                U,
                            ))
                            if spectral_exported
                                _write_spectral_point!(
                                    pole_io,
                                    sum_rule_io,
                                    akw_io,
                                    dos_io,
                                    zero,
                                    U,
                                    0.0,
                                    ZERO_FIELD_ROLE,
                                    options,
                                    zero_broadened,
                                )
                                spectra[(U, ZERO_FIELD_ROLE)] = zero_broadened
                            end
                            if full_exported
                                push!(
                                    full_spectrum_rows,
                                    _write_full_levels!(levels_io, zero, U, options),
                                )
                            end

                            options.probe_h == 0 && continue
                            h = options.probe_h
                            reduced_h = h * options.reduced_field_ratio
                            positive = _solve_point(options, ed_module, parameters, U, h)
                            negative = _solve_point(options, ed_module, parameters, U, -h)
                            reduced_positive = _solve_point(
                                options,
                                ed_module,
                                parameters,
                                U,
                                reduced_h,
                            )
                            reduced_negative = _solve_point(
                                options,
                                ed_module,
                                parameters,
                                U,
                                -reduced_h,
                            )
                            field_results = (
                                (positive, h, POSITIVE_FIELD_ROLE),
                                (negative, -h, NEGATIVE_FIELD_ROLE),
                                (
                                    reduced_positive,
                                    reduced_h,
                                    REDUCED_POSITIVE_FIELD_ROLE,
                                ),
                                (
                                    reduced_negative,
                                    -reduced_h,
                                    REDUCED_NEGATIVE_FIELD_ROLE,
                                ),
                            )
                            for (result, field, role) in field_results
                                push!(field_rows, _field_point_row(
                                    result,
                                    options,
                                    U,
                                    field,
                                    role,
                                ))
                            end
                            positive_diagnostics = _xy_diagnostics(
                                ed_module,
                                positive,
                                options,
                            )
                            negative_diagnostics = _xy_diagnostics(
                                ed_module,
                                negative,
                                options,
                            )
                            reduced_positive_diagnostics = _xy_diagnostics(
                                ed_module,
                                reduced_positive,
                                options,
                            )
                            reduced_negative_diagnostics = _xy_diagnostics(
                                ed_module,
                                reduced_negative,
                                options,
                            )
                            push!(response_rows, _response_row(
                                U,
                                positive,
                                negative,
                                reduced_positive,
                                reduced_negative,
                                positive_diagnostics,
                                negative_diagnostics,
                                reduced_positive_diagnostics,
                                reduced_negative_diagnostics,
                                options,
                            ))
                            if spectral_exported
                                broadened_by_role = (
                                    (
                                        positive,
                                        h,
                                        POSITIVE_FIELD_ROLE,
                                        positive_diagnostics.broadened,
                                    ),
                                    (
                                        negative,
                                        -h,
                                        NEGATIVE_FIELD_ROLE,
                                        negative_diagnostics.broadened,
                                    ),
                                    (
                                        reduced_positive,
                                        reduced_h,
                                        REDUCED_POSITIVE_FIELD_ROLE,
                                        reduced_positive_diagnostics.broadened,
                                    ),
                                    (
                                        reduced_negative,
                                        -reduced_h,
                                        REDUCED_NEGATIVE_FIELD_ROLE,
                                        reduced_negative_diagnostics.broadened,
                                    ),
                                )
                                for (result, field, role, broadened) in broadened_by_role
                                    _write_spectral_point!(
                                        pole_io,
                                        sum_rule_io,
                                        akw_io,
                                        dos_io,
                                        result,
                                        U,
                                        field,
                                        role,
                                        options,
                                        broadened,
                                    )
                                    spectra[(U, role)] = broadened
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    _write_rows(
        joinpath(staging, "periodic_L2_ground_state_field_points.csv"),
        field_rows,
    )
    _write_rows(
        joinpath(staging, "periodic_L2_ground_state_zero_field_spin_audit.csv"),
        zero_rows,
    )
    _write_rows(
        joinpath(staging, "periodic_L2_ground_state_explicit_field_response.csv"),
        response_rows,
    )
    _write_rows(
        joinpath(staging, "periodic_L2_ground_state_full_spectrum_summary.csv"),
        full_spectrum_rows,
    )
    plot_paths = options.plots ? _plot_outputs(
        staging,
        options,
        zero_rows,
        response_rows,
        spectra,
    ) : String[]
    _write_metadata(
        joinpath(staging, "metadata.txt"),
        options,
        zero_rows,
        response_rows,
        plot_paths,
    )
    return (
        field_points=field_rows,
        zero_field_audit=zero_rows,
        explicit_field_response=response_rows,
        full_spectrum_summary=full_spectrum_rows,
        plot_filenames=basename.(plot_paths),
        limitation=LIMITATION,
    )
end

_destination_exists(path) = ispath(path) || islink(path)

"""
    run_ground_state_request(options; ed_module=ClusterED)

Run the canonical periodic-2x2 T=0 request. Results are staged in a temporary
sibling and published with one atomic rename. Existing output is never
overwritten. Zero-field spin equality is audited at every U. Nonzero fields
are evaluated in +/- pairs at two magnitudes and are always labeled as
explicit-source finite-cluster responses.
"""
function run_ground_state_request(options; ed_module=ClusterED)
    destination = options.output_dir
    _destination_exists(destination) && throw(ArgumentError(
        "refusing to overwrite output directory: $destination",
    ))
    _require_ground_api(ed_module)
    parameters = ed_module.ValidatedKinetic.ModelParameters(; options.hopping...)
    parent = dirname(destination)
    mkpath(parent)
    staging = mktempdir(parent; prefix=".$(basename(destination)).tmp-")
    try
        payload = _write_request(staging, options, ed_module, parameters)
        _destination_exists(destination) && throw(ArgumentError(
            "refusing to overwrite output directory created while the run was active: " *
            destination,
        ))
        Base.Filesystem.rename(staging, destination)
        return merge((output_dir=destination,), payload)
    catch
        _destination_exists(staging) && rm(staging; recursive=true, force=true)
        rethrow()
    end
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        usage()
        return nothing
    end
    result = run_ground_state_request(options)
    failures = count(
        row -> row.numerical_spin_symmetry_audit_failed,
        result.zero_field_audit,
    )
    println(LIMITATION)
    println("Zero-field ground-state numerical spin-audit failures: $failures")
    println("Saved periodic L2 ground-state ED request to $(result.output_dir)")
    return result
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    try
        PeriodicL2GroundStateED.main()
    catch exception
        println(stderr, "ERROR: ", sprint(showerror, exception))
        println(stderr, "Run with --help for usage.")
        exit(1)
    end
end
