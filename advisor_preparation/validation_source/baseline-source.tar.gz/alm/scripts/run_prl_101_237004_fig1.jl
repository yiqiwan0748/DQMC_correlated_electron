#!/usr/bin/env julia

module PRL101237004Fig1

using LinearAlgebra
using Printf
using SHA

include("prl_101_237004_model.jl")
using .PRL101237004Model

const ROOT = normpath(joinpath(@__DIR__, ".."))
const DEFAULT_OUTPUT = joinpath(ROOT, "results", "prl_101_237004", "milestone1")
const PAPER_DOI = "https://doi.org/10.1103/PhysRevLett.101.237004"
const RAGHU_SOURCE = "https://arxiv.org/pdf/0804.1113"
const PAPER_SHA256 = "3b4eaec2eb6aa397b44a2662387ef6d43a9f677e4fdcec3c14839f671b6493ae"
const POCKETS = (
    (name="Gamma", center=(0.0, 0.0), band=1, character="hole"),
    (name="M", center=(Float64(pi), Float64(pi)), band=1, character="hole"),
    (name="X", center=(Float64(pi), 0.0), band=2, character="electron"),
    (name="Y", center=(0.0, Float64(pi)), band=2, character="electron"),
)

"""T=0 density per Fe, including both spins, on a periodic Nk×Nk grid.

The quantile interval contains the N=2 half-filling chemical potential.
`density_at_reference` uses occupied levels with E≤mu; any finite-grid
boundary degeneracy is recorded by `density_below_half_mu` and
`density_through_half_mu`, not silently converted to an exact filling.
"""
function filling_audit(parameters, Nk::Integer, reference_mu::Real)
    Nk >= 4 || throw(ArgumentError("Nk must be at least 4"))
    isfinite(reference_mu) || throw(ArgumentError("reference_mu must be finite"))
    spectrum = Vector{Float64}(undef, 2Nk^2)
    i = 0
    lower_occupied, upper_occupied = 0, 0
    for iy in 0:Nk-1, ix in 0:Nk-1
        energies = paper_band_energies(-pi + 2pi * ix / Nk, -pi + 2pi * iy / Nk, parameters)
        spectrum[i + 1], spectrum[i + 2] = energies
        lower_occupied += energies[1] <= reference_mu
        upper_occupied += energies[2] <= reference_mu
        i += 2
    end
    sort!(spectrum)
    lo, hi = spectrum[Nk^2], spectrum[Nk^2 + 1]
    mu = lo / 2 + hi / 2
    # Resolve roundoff-split symmetry degeneracies (not a thermal broadening).
    boundary_atol = 64eps(Float64) * max(1.0, maximum(abs, spectrum))
    nbelow = 2 * (searchsortedfirst(spectrum, mu - boundary_atol) - 1) / Nk^2
    nthrough = 2 * searchsortedlast(spectrum, mu + boundary_atol) / Nk^2
    return (Nk=Int(Nk), mu_half=mu, mu_lower=lo, mu_upper=hi,
        density_at_reference=2searchsortedlast(spectrum, reference_mu) / Nk^2,
        lower_density_at_reference=2lower_occupied / Nk^2,
        upper_density_at_reference=2upper_occupied / Nk^2,
        density_below_half_mu=nbelow, density_through_half_mu=nthrough)
end

"""Find the first Fermi crossing on a ray from a known pocket center.

Bracketing is independent of the plotting grid. All returned roots are
checked against the band energy, with energy tolerance 1e-11 in the model's
units (far below the accuracy of the coefficients printed in the paper).
"""
function pocket_radius(parameters, mu, pocket, angle)
    direction = (cos(angle), sin(angle))
    energy(radius) = paper_band_energies(
        pocket.center[1] + radius * direction[1],
        pocket.center[2] + radius * direction[2], parameters)[pocket.band] - mu
    center_value = energy(0.0)
    expected_sign = pocket.character == "hole" ? 1 : -1
    expected_sign * center_value > 0 || error("wrong pocket-center occupation: $(pocket.name)")
    lo, hi = 0.0, NaN
    for radius in range(pi / 256, pi; length=256)
        if expected_sign * energy(radius) <= 0
            hi = radius
            break
        end
        lo = radius
    end
    isfinite(hi) || error("unbracketed Fermi crossing: $(pocket.name), angle=$angle")
    for _ in 1:48
        midpoint = lo / 2 + hi / 2
        if expected_sign * energy(midpoint) > 0
            lo = midpoint
        else
            hi = midpoint
        end
    end
    radius = lo / 2 + hi / 2
    residual = abs(energy(radius))
    residual <= 1e-11 || error("Fermi-root residual too large: $residual")
    return radius, residual
end

function fermi_contours(parameters, mu; angles::Integer=720)
    angles >= 16 || throw(ArgumentError("at least 16 angular intervals required"))
    return map(POCKETS) do pocket
        theta = collect(range(0.0, 2pi; length=angles + 1))
        roots = [pocket_radius(parameters, mu, pocket, angle) for angle in theta]
        radii = first.(roots)
        (pocket=pocket, theta=theta, radius=radii,
            kx=pocket.center[1] .+ radii .* cos.(theta),
            ky=pocket.center[2] .+ radii .* sin.(theta),
            residual=last.(roots))
    end
end

"""Density from closed pocket polygon areas, including the two spin states."""
function contour_band_densities(contours)
    hole_area, electron_area = 0.0, 0.0
    for c in contours
        # Translate to each pocket's center before the shoelace sum to avoid
        # cancellation for pockets crossing the Brillouin-zone boundary.
        x, y = c.kx .- c.pocket.center[1], c.ky .- c.pocket.center[2]
        area = abs(sum(x[i] * y[i + 1] - x[i + 1] * y[i] for i in 1:length(x)-1)) / 2
        if c.pocket.character == "electron"
            electron_area += area
        else
            hole_area += area
        end
    end
    return (lower=2 - 2hole_area / (2pi)^2, upper=2electron_area / (2pi)^2)
end

contour_density(contours) = sum(contour_band_densities(contours))

function write_contours(path, datasets)
    open(path, "w") do io
        println(io, "case,pocket,character,band,mu,angle,kx_unwrapped,ky_unwrapped,kx_wrapped,ky_wrapped,abs_energy_residual")
        for data in datasets, contour in data.contours, i in eachindex(contour.theta)
            x, y = contour.kx[i], contour.ky[i]
            println(io, join((data.name, contour.pocket.name, contour.pocket.character,
                contour.pocket.band, data.mu, contour.theta[i], x, y,
                mod(x + pi, 2pi) - pi, mod(y + pi, 2pi) - pi, contour.residual[i]), ','))
        end
    end
end

function write_report(output, datasets, audits, area_checks)
    open(joinpath(output, "report.md"), "w") do io
        println(io, "# PRL 101, 237004 — milestone 1\n")
        println(io, "Reconstruction of the noninteracting Fermi surfaces in [Daghofer et al., Fig. 1(d,e)]($PAPER_DOI), using the printed hopping formulas. The four pocket topology is reproduced: hole pockets at Gamma/M and electron pockets at X/Y. No interacting result is claimed.\n")
        println(io, "![Fermi surfaces](fig1_fermi_surfaces.png)\n")
        println(io, "## Numerical checks\n")
        println(io, "| Case | chemical potential used | largest Fermi-root residual |\n|---|---:|---:|")
        for data in datasets
            residual = maximum(maximum(c.residual) for c in data.contours)
            @printf(io, "| %s | %.10f | %.3g |\n", data.name, data.mu, residual)
        end
        println(io, "\n| Hoppings | grid | half-filled chemical potential | density at reference chemical potential |\n|---|---:|---:|---:|")
        for (name, rows) in audits, row in rows
            @printf(io, "| %s | %d × %d | %.10f | %.8f |\n", name, row.Nk, row.Nk, row.mu_half, row.density_at_reference)
        end
        println(io, "\n| Case | pocket-area density | direct grid density | absolute difference | 360→720 angular-grid change |\n|---|---:|---:|---:|---:|")
        for row in area_checks
            @printf(io, "| %s | %.8f | %.8f | %.3g | %.3g |\n", row.name,
                row.contour_density, row.grid_density, row.density_error, row.angular_change)
        end
        println(io, "\nDirect counting uses a 1600×1600 periodic momentum grid. The two band fillings are also checked separately (see `pocket_area_validation.csv`), so electron/hole area errors cannot cancel in the total. Doubling the contour resolution from 360 to 720 angular intervals checks polygon-area convergence.\n")
        println(io, "\nDensity includes both spins and both orbitals; half filling is n=2 electrons per Fe. The Brillouin zone is unfolded (one Fe), with momenta in radians and lattice spacing one.\n")
        println(io, "## Comparison limits\n")
        println(io, "Fig. 1(d) uses the printed mu=-0.03. The half-filled value calculated from the rounded Slater–Koster coefficients rounds to this value, but using exactly -0.03 gives a small density offset. Both quantities are reported rather than adjusting the paper's value.\n")
        println(io, "Fig. 1(e) does not state mu. The main reconstruction uses n=2 and the hoppings of Ref. 11. The [Raghu preprint]($RAGHU_SOURCE) explicitly uses mu=1.45 for its own figures. The alternative below shows the contour sensitivity to this unresolved choice; the half-filled mu is our calculation, not a number quoted from the PRL.\n")
        println(io, "![Chemical-potential sensitivity](chemical_potential_sensitivity.png)\n")
        println(io, "Agreement is assessed against the published pocket topology and visually against the supplied PDF. The paper supplies no raw contour coordinates; the tiny root residual validates the numerical solver, not a pointwise match to unpublished author data.\n")
        println(io, "## Reproduce\n\n```bash\nOPENBLAS_NUM_THREADS=1 julia --project=. scripts/run_prl_101_237004_fig1.jl --output-dir=results/prl_101_237004/milestone1_rerun\n```\n")
        println(io, "The output directory must be new or empty. CSV files contain the contour coordinates, grid convergence, and high-symmetry energies. PDFs are provided for export. See `docs/prl_101_237004_reproduction.md` for the subsequent milestones.\n")
    end
end

function main(arguments=ARGS)
    output = DEFAULT_OUTPUT
    for argument in arguments
        startswith(argument, "--output-dir=") || throw(ArgumentError("only --output-dir=PATH is supported"))
        output = abspath(split(argument, '='; limit=2)[2])
    end
    ispath(output) && (!isdir(output) || !isempty(readdir(output))) &&
        error("output path must be a new or empty directory: $output")

    sk, raghu = slater_koster_parameters(), raghu_parameters()
    grids = (200, 400, 800, 1600)
    sk_audit = [filling_audit(sk, grid, -0.03) for grid in grids]
    raghu_audit = [filling_audit(raghu, grid, 1.45) for grid in grids]
    audits = (("Slater_Koster", sk_audit), ("Raghu", raghu_audit))
    for (name, rows) in audits
        all(row.density_below_half_mu <= 2 <= row.density_through_half_mu for row in rows) ||
            error("half-filling quantile failed for $name")
        # Finite-grid convergence is a discretization check, not machine precision.
        abs(rows[end].mu_half - rows[end - 1].mu_half) < 1e-3 ||
            error("half-filled chemical potential has not converged within 1e-3 for $name")
    end
    abs(sk_audit[end].mu_half + 0.03) < 0.005 || error("SK mu does not round to the printed -0.03")
    specs = (
        (name="SK_paper_mu", parameters=sk, mu=-0.03),
        (name="Raghu_half_filled", parameters=raghu, mu=raghu_audit[end].mu_half),
        (name="SK_half_filled", parameters=sk, mu=sk_audit[end].mu_half),
        (name="Raghu_ref11_mu", parameters=raghu, mu=1.45),
    )
    datasets = map(specs) do spec
        merge(spec, (contours=fermi_contours(spec.parameters, spec.mu),))
    end
    area_checks = map(datasets) do data
        fine_density = contour_density(data.contours)
        fine_bands = contour_band_densities(data.contours)
        coarse_contours = fermi_contours(data.parameters, data.mu; angles=360)
        coarse_bands = contour_band_densities(coarse_contours)
        coarse_density = sum(coarse_bands)
        grid = filling_audit(data.parameters, grids[end], data.mu)
        grid_density = grid.density_at_reference
        density_error = abs(fine_density - grid_density)
        angular_change = abs(fine_density - coarse_density)
        band_density_error = max(abs(fine_bands.lower - grid.lower_density_at_reference),
            abs(fine_bands.upper - grid.upper_density_at_reference))
        band_angular_change = maximum(abs.(Tuple(fine_bands) .- Tuple(coarse_bands)))
        # Finite momentum counting is less accurate than the root solver.
        # These tolerances allow discretization at Nk=1600 and 720 angles,
        # but would expose incorrect spin factors or a missing pocket.
        max(density_error, band_density_error) < 2e-4 || error("pocket-area and grid densities disagree for $(data.name)")
        max(angular_change, band_angular_change) < 4e-5 || error("pocket areas are not angularly converged for $(data.name)")
        (name=data.name, contour_density=fine_density, grid_density=grid_density,
            density_error=density_error, angular_change=angular_change,
            lower_contour_density=fine_bands.lower, lower_grid_density=grid.lower_density_at_reference,
            upper_contour_density=fine_bands.upper, upper_grid_density=grid.upper_density_at_reference,
            max_band_density_error=band_density_error, max_band_angular_change=band_angular_change)
    end
    # Independent 2x2 eigensolver check on every exported Fermi contour.
    max_eigensolver_error = 0.0
    for data in datasets, c in data.contours, i in eachindex(c.theta)
        eig = eigvals(Symmetric(paper_bloch_hamiltonian(c.kx[i], c.ky[i], data.parameters)))
        max_eigensolver_error = max(max_eigensolver_error, abs(eig[c.pocket.band] - data.mu))
    end
    max_eigensolver_error <= 1e-11 || error("independent eigensolver Fermi-surface check failed")

    mkpath(output)
    write_contours(joinpath(output, "fermi_contours.csv"), datasets)
    open(joinpath(output, "pocket_area_validation.csv"), "w") do io
        println(io, "case,contour_density,grid_density,abs_density_error,angular_density_change_360_to_720,lower_contour_density,lower_grid_density,upper_contour_density,upper_grid_density,max_band_density_error,max_band_angular_change")
        for row in area_checks
            println(io, join(Tuple(row), ','))
        end
    end
    open(joinpath(output, "filling_convergence.csv"), "w") do io
        println(io, "model,Nk,reference_mu,mu_half,mu_lower,mu_upper,density_at_reference,density_below_half_mu,density_through_half_mu")
        for (name, rows) in audits, row in rows
            println(io, join((name, row.Nk, name == "Slater_Koster" ? -0.03 : 1.45,
                row.mu_half, row.mu_lower, row.mu_upper, row.density_at_reference,
                row.density_below_half_mu, row.density_through_half_mu), ','))
        end
    end
    open(joinpath(output, "high_symmetry.csv"), "w") do io
        println(io, "model,point,kx,ky,lower_energy,upper_energy")
        for (name, parameters) in (("Slater_Koster", sk), ("Raghu", raghu))
            for (point, kx, ky) in (("Gamma", 0.0, 0.0), ("X", pi, 0.0), ("Y", 0.0, pi), ("M", pi, pi), ("diagonal", pi/2, pi/2))
                println(io, join((name, point, kx, ky, paper_band_energies(kx, ky, parameters)...), ','))
            end
        end
    end
    ENV["GKSwstype"] = "100"
    # Existing project dependency; loading is delayed so numerical tests need no renderer.
    @eval using Plots
    Base.invokelatest(render_figures, output, datasets)
    write_report(output, datasets, audits, area_checks)
    open(joinpath(output, "metadata.txt"), "w") do io
        println(io, "paper=$PAPER_DOI\nsource_pdf_sha256=$PAPER_SHA256\nreference11=$RAGHU_SOURCE")
        println(io, "julia_version=$(VERSION)\nU=0\nJ=0\nspin_degeneracy=2\ntarget_density_per_Fe=2\nratio_pdpi_pdsigma=-0.2")
        println(io, "SK_energy_unit=(pd_sigma)^2/Delta_pd\nRaghu_energy_unit=abs(t1)\nSK_paper_hoppings=$(Tuple(getfield(sk,f) for f in (:t1,:t2,:t3,:t4)))")
        println(io, "Raghu_original_hoppings=(-1,1.3,-0.85,-0.85)\nRaghu_hoppings_in_PRL_equation1_convention=$(Tuple(getfield(raghu,f) for f in (:t1,:t2,:t3,:t4)))")
        println(io, "paper_hxy=+4*t4*sin(kx)*sin(ky)\nrepository_t4=-paper_t4\nangular_intervals_per_pocket=720\nroot_energy_atol=1e-11\nmu_grid_convergence_atol=1e-3")
        println(io, "independent_eigensolver_max_error=$max_eigensolver_error\nstatus=noninteracting_milestone_only\nfigure1e_mu_is_inferred=true")
        println(io, "pocket_area_density_atol=2e-4\nangular_area_density_atol=4e-5\nmax_pocket_area_density_error=$(maximum(max(row.density_error,row.max_band_density_error) for row in area_checks))")
        for file in (joinpath(@__DIR__, "prl_101_237004_model.jl"), @__FILE__, joinpath(ROOT, "src", "noninteracting.jl"))
            println(io, "source_sha256 $(bytes2hex(sha256(read(file)))) $(relpath(file, ROOT))")
        end
    end
    open(joinpath(output, "checksums.sha256"), "w") do io
        for name in sort(readdir(output))
            name == "checksums.sha256" && continue
            digest = bytes2hex(sha256(read(joinpath(output, name))))
            println(io, "$digest  $name")
        end
    end
    println("Figure 1 milestone written to $output")
    println("SK mu_half=$(sk_audit[end].mu_half); Raghu mu_half=$(raghu_audit[end].mu_half)")
    println("Independent eigensolver maximum contour residual=$max_eigensolver_error")
    return output
end

function draw_contours!(panel, contours; style=:solid, width=1.8, fixed_color=nothing)
    for c in contours
        color = isnothing(fixed_color) ? (c.pocket.character == "hole" ? "#cf3e4f" : "#263747") : fixed_color
        for dx in (-2pi, 0, 2pi), dy in (-2pi, 0, 2pi)
            x, y = (c.kx .+ dx) ./ pi, (c.ky .+ dy) ./ pi
            (maximum(x) < -1 || minimum(x) > 1 || maximum(y) < -1 || minimum(y) > 1) && continue
            plot!(panel, x, y; color=color, linestyle=style, linewidth=width, label=false)
        end
    end
    return panel
end

function empty_panel(title)
    panel = plot(; xlims=(-1, 1), ylims=(-1, 1), aspect_ratio=:equal,
        xticks=([-1, 0, 1], ["−1", "0", "1"]), yticks=([-1, 0, 1], ["−1", "0", "1"]),
        xlabel="kₓ / π", ylabel="kᵧ / π", title=title, framestyle=:box,
        grid=false, legend=false, titlefontsize=12, guidefontsize=11,
        tickfontsize=10, background_color=:white)
    annotate!(panel, [(0.0, 0.0, text("Γ", 12)), (0.94, 0.0, text("X", 11)),
        (0.0, 0.93, text("Y", 11)), (0.92, 0.93, text("M", 11))])
    return panel
end

function render_figures(output, datasets)
    sk, raghu, sk_half, raghu_ref = datasets
    left = draw_contours!(empty_panel("(d) Slater–Koster: r = −0.2, μ = −0.03"), sk.contours)
    right = draw_contours!(empty_panel(@sprintf("(e) Raghu: calculated μ = %.5f, n = 2", raghu.mu)), raghu.contours)
    combined = plot(left, right; layout=(1, 2), size=(1100, 560), dpi=160,
        plot_title="PRL 101, 237004 · Fig. 1 reconstruction · U = J = 0",
        plot_titlefontsize=15, bottom_margin=6Plots.mm, left_margin=5Plots.mm,
        right_margin=5Plots.mm)
    # Band colors follow the paper: red hole pockets, dark electron pockets.
    savefig(combined, joinpath(output, "fig1_fermi_surfaces.png"))
    savefig(combined, joinpath(output, "fig1_fermi_surfaces.pdf"))
    sensitive_sk = draw_contours!(empty_panel("SK: solid μ = −0.03; dashed n = 2"), sk.contours)
    draw_contours!(sensitive_sk, sk_half.contours; style=:dash, width=1.3, fixed_color="#248f9c")
    sensitive_raghu = draw_contours!(empty_panel("Raghu: solid n = 2; dashed μ = 1.45"), raghu.contours)
    draw_contours!(sensitive_raghu, raghu_ref.contours; style=:dash, width=1.3, fixed_color="#248f9c")
    sensitivity = plot(sensitive_sk, sensitive_raghu; layout=(1, 2), size=(1100, 560), dpi=160,
        plot_title="Chemical-potential sensitivity · dashed contours are alternatives",
        plot_titlefontsize=14, bottom_margin=6Plots.mm, left_margin=5Plots.mm,
        right_margin=5Plots.mm)
    savefig(sensitivity, joinpath(output, "chemical_potential_sensitivity.png"))
    savefig(sensitivity, joinpath(output, "chemical_potential_sensitivity.pdf"))
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    PRL101237004Fig1.main()
end
