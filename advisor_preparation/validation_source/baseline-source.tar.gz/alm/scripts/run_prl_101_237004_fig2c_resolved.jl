#!/usr/bin/env julia

module PRL101237004Fig2CResolvedCampaign
using LinearAlgebra, SHA, Dates, Printf
include("prl_101_237004_fig2c_resolved_filling.jl")
include("prl_101_237004_fig2c_canonical_field.jl")
const Filling=PRL101237004Fig2CResolvedFilling
const Field=PRL101237004Fig2CCanonicalField
const R=Filling.R
const V=R.V
const F=R.F
const SOURCES=vcat(R.SOURCES,["scripts/prl_101_237004_fig2c_filling.jl",
    "scripts/prl_101_237004_fig2c_field.jl","scripts/run_prl_101_237004_fig2c.jl",
    "scripts/prl_101_237004_fig2c_adaptive_filling.jl","scripts/run_prl_101_237004_fig2c_adaptive.jl",
    "scripts/prl_101_237004_fig2c_resolved_filling.jl","scripts/run_prl_101_237004_fig2c_resolved.jl",
    "scripts/prl_101_237004_fig2c_canonical_field.jl","scripts/prl_101_237004_fig2c_fermi_shell.jl"])
const HEADER="ratio,U,J,h,mu,mu_prime,Omega_per_Fe,F_per_Fe,density,moment_abs_muB_per_Fe,moment_signed_muB_per_Fe,mu_prime_gradient,h_derivative,stationarity_status,reference_cache,physical_L,quadrature_order,block_steps,zero_field_F,energy_gain"
ratio_label(r)=r==-.2 ? "r_minus_0p2" : r==-.5 ? "r_minus_0p5" : error("only the two published ratios are supported")

function validated_point(directory,U,ratio;physical_L=48,order=nothing,block_steps=48)
    isfile(joinpath(directory,"completed.txt")) || error("point lacks completion marker")
    lines=readlines(joinpath(directory,"result.csv"))
    length(lines)==2 && lines[1]==HEADER || error("invalid completed point")
    names=split(HEADER,',');cells=split(lines[2],',')
    length(names)==length(cells) || error("completed point has wrong column count")
    row=Dict(zip(names,cells))
    all(isfinite(parse(Float64,row[name])) for name in names
        if name ∉ ("stationarity_status","reference_cache")) || error("nonfinite completed point")
    parse(Float64,row["ratio"])==ratio && parse(Float64,row["U"])==U &&
        parse(Float64,row["J"])==U/4 && parse(Int,row["physical_L"])==physical_L &&
        (order===nothing ? parse(Int,row["quadrature_order"]) in (24,48) : parse(Int,row["quadrature_order"])==order) && parse(Int,row["block_steps"])==block_steps ||
        error("completed point parameters differ")
    row["stationarity_status"] in ("magnetic_minimum","paramagnetic_minimum") || error("unresolved point")
    abs(parse(Float64,row["density"])-2)<=1e-7 &&
        abs(parse(Float64,row["mu_prime_gradient"]))<=1e-7 &&
        abs(parse(Float64,row["h_derivative"]))<=2e-6 || error("completed point residuals fail")
    recorded=Dict{String,String}()
    for line in readlines(joinpath(directory,"provenance.txt"))
        matchrow=match(r"^([0-9a-f]{64})  ((?:scripts|src)/.+)$",line)
        matchrow===nothing && continue
        source=matchrow[2]
        haskey(recorded,source) && error("duplicate provenance source")
        recorded[source]=matchrow[1]
    end
    shared=vcat(R.SOURCES,["scripts/prl_101_237004_fig2c_filling.jl",
        "scripts/prl_101_237004_fig2c_field.jl","scripts/run_prl_101_237004_fig2c.jl"])
    all(haskey(recorded,s) for s in shared) || error("point lacks shared numerical source hashes")
    adapter="scripts/prl_101_237004_fig2c_adaptive_filling.jl"
    runner="scripts/run_prl_101_237004_fig2c_adaptive.jl"
    haskey(recorded,adapter)==haskey(recorded,runner) || error("incomplete adaptive source provenance")
    resolved="scripts/prl_101_237004_fig2c_resolved_filling.jl"
    resolved_runner="scripts/run_prl_101_237004_fig2c_resolved.jl"
    haskey(recorded,resolved)==haskey(recorded,resolved_runner) || error("incomplete resolved source provenance")
    if haskey(recorded,resolved)
        all(haskey(recorded,s) for s in ("scripts/prl_101_237004_fig2c_canonical_field.jl",
            "scripts/prl_101_237004_fig2c_fermi_shell.jl")) || error("missing resolved numerical helpers")
    end
    for (source,expected) in recorded
        snapshot=joinpath(directory,"source_snapshot",source)
        isfile(snapshot) && V.filehash(snapshot)==expected || error("point source snapshot differs: $source")
        V.filehash(joinpath(R.ROOT,source))==expected || error("current numerical source differs from completed point: $source")
    end
    lines[2]
end

function run_point(U,ratio;output=R.OUTPUT,physical_L=48,order=48,block_steps=48,
                   fields=[0.,.002,.005,.015,.04,.08,.14])
    directory=joinpath(output,"runs",ratio_label(ratio),"U"*string(Float64(U)))
    hashes=Dict(s=>V.filehash(joinpath(R.ROOT,s)) for s in SOURCES)
    if isfile(joinpath(directory,"result.csv"))
        validated_point(directory,U,ratio;physical_L,block_steps)
        return joinpath(directory,"result.csv")
    end
    mkpath(directory)
    for source in SOURCES
        target=joinpath(directory,"source_snapshot",source)
        mkpath(dirname(target))
        if isfile(target)
            V.filehash(target)==hashes[source] || error("run source changed: $source; preserve old run and use fresh output")
        else
            cp(joinpath(R.ROOT,source),target)
        end
    end
    open(joinpath(directory,"provenance.txt"),"w") do io
        println(io,"Started ",now(),"; Julia ",VERSION,"; threads ",Threads.nthreads(),"; BLAS ",BLAS.get_num_threads())
        println(io,"U=",U,"; J=",U/4,"; ratio=",ratio,"; physical_L=",physical_L,"; order=",order,"; block_steps=",block_steps)
        println(io,"Open2x2 reference; full original PRL interaction/hoppings; +h sum p(nup−ndown); both orbital/spin traces; per Fe.")
        println(io,"Every center solves density=2 and reference-mu stationarity. Magnetic channels compare canonical F=Omega+2mu because the chosen physical mu may vary with h.")
        println(io,"Field derivative uses fully re-solved canonical F sides; step2e−4, target2e−6, coarse grid=",fields)
        println(io,"Initial physical mu is Hartree plus the stated bare estimate, not a fit to any figure.")
        println(io,"Adaptive filling recovery refines valid/invalid occupation-domain boundaries when exponential bracketing skips a sign change; all attempts are recorded.")
        println(io,"Frequency profile: near-Fermi refinement; breaks=",Filling.FREQUENCY_BREAKS,"; order=",order)
        println(io,"Completed original points retain their validated original order and frequency profile; missing points use the refined profile.")
        for s in sort(SOURCES)
            println(io,hashes[s],"  ",s)
        end
    end
    states=Dict{Float64,Any}();centers=Dict{Float64,Any}()
    center_rows=Tuple[];side_rows=Tuple[]
    state(h)=get!(states,Float64(h)) do
        R.reference_state(U,ratio,h;output,block_steps)
    end
    lat=V.embedding(state(0.);physical_L)
    function center(h)
        haskey(centers,h) && return centers[h]
        s=state(h)
        known=collect(keys(centers))
        previous=isempty(known) ? nothing : centers[known[argmin(abs.(known.-h))]]
        mu_initial=previous===nothing ? R.initial_mu(U,ratio) : previous.mu
        mup_initial=previous===nothing ? nothing : previous.mu_prime
        seconds=@elapsed solved=Filling.solve_filling(s,lat;mu_initial,
            mu_prime_initial=mup_initial,order,gradient_atol=2e-8,density_atol=2e-8)
        # Retain bounded failed searches as well as accepted solves.
        open(joinpath(directory,"filling_h"*string(reinterpret(UInt64,Float64(h));base=16)*".txt"),"w") do io
            show(io,"text/plain",solved)
        end
        solved.converged || error("half-filling/stationarity unresolved at U=$U r=$ratio h=$h: $(solved.status)")
        x=solved.choice.data
        abs(x.mu_prime_gradient)<=1e-7 && abs(x.density-2)<=1e-7 || error("center residuals exceed acceptance")
        data=merge(x,(;canonical=x.omega+2x.mu,reference_cache=s.cache))
        centers[h]=data
        push!(center_rows,(h,x.mu,x.mu_prime,x.omega,data.canonical,x.density,x.moment,x.mu_prime_gradient,
            s.result.E0,s.result.ground_residual,s.result.converged,
            maximum(ch.convergence_error for ch in s.result.channels),seconds,relpath(s.cache,output)))
        V.write_csv(joinpath(directory,"centers.csv"),
            "h,mu,mu_prime,Omega_per_Fe,F_per_Fe,density,moment_signed,mu_prime_gradient,reference_E0,reference_residual,reference_probe_converged,reference_probe_error,seconds,reference_cache",center_rows)
        V.write_csv(joinpath(directory,"occupation_policies.csv"),
            "h,occupation_policy,mixture_fraction,frequency_points",
            [(hh,get(v,:occupation_policy,:integer_interval),get(v,:shell_fraction,""),v.frequency_points)
                for (hh,v) in sort(collect(centers);by=first)])
        @printf("%s U=%.2f r=%.1f h=%.7f mu=%.7f mup=%.7f F=%.11f m=%.8f n=%.10f (%.1fs)\n",
            string(now()),U,ratio,h,x.mu,x.mu_prime,data.canonical,abs(x.moment),x.density,seconds)
        flush(stdout)
        data
    end
    function side(h,x)
        y=center(h)
        push!(side_rows,(h,y.mu,y.mu_prime,y.omega,y.canonical,y.density,y.mu_prime_gradient,y.moment,relpath(y.reference_cache,output)))
        V.write_csv(joinpath(directory,"field_sides.csv"),"h,mu,mu_prime,Omega_per_Fe,F_per_Fe,density,mu_prime_gradient,moment_signed,reference_cache",side_rows)
        y.canonical
    end
    progress(kind,h,x)=kind==:derivative ? (println("field derivative U=",U," r=",ratio," h=",h," g=",x.gradient);flush(stdout)) : nothing
    result=Field.stationary_field(center,side;fields,progress)
    V.write_csv(joinpath(directory,"field_derivatives.csv"),"h,gradient,curvature,step,left_F,right_F",
        [(x.h,x.gradient,x.curvature,x.step,x.left,x.right) for x in result.history])
    open(joinpath(directory,"search.txt"),"w") do io
        println(io,"Status: ",result.status,"; coarse fields: ",result.grid,"; canonical values: ",result.values)
        println(io,"Detected ordered minima: ",[(x.h,x.center.canonical,x.derivative.gradient,x.bracket) for x in result.roots])
        println(io,"Failed brackets: ",result.failures)
        println(io,"A finite field grid can miss other narrow minima. Final derivative step/grid/Green-depth checks are separate.")
    end
    result.status in (:magnetic_minimum,:paramagnetic_minimum) || error("field stationarity unresolved at U=$U ratio=$ratio")
    selected=result.selected; x=selected.center;h=selected.h
    zero=result.cache[0.].canonical
    row=(ratio,U,U/4,h,x.mu,x.mu_prime,x.omega,x.canonical,x.density,abs(x.moment),x.moment,
        x.mu_prime_gradient,selected.derivative.gradient,result.status,relpath(x.reference_cache,output),
        physical_L,order,block_steps,zero,zero-x.canonical)
    all(V.filehash(joinpath(R.ROOT,s))==hashes[s] for s in SOURCES) || error("source changed during run")
    V.write_csv(joinpath(directory,"result.csv"),HEADER,[row])
    V.write_csv(joinpath(directory,"selected_occupation.csv"),
        "ratio,U,h,occupation_policy,mixture_fraction,frequency_points",
        [(ratio,U,h,get(x,:occupation_policy,:integer_interval),get(x,:shell_fraction,""),x.frequency_points)])
    open(joinpath(directory,"completed.txt"),"w") do io
        println(io,"Completed ",now(),"; all numerical source hashes unchanged.")
        println(io,"Selected h=",h,"; F=",x.canonical,"; |moment|=",abs(x.moment),"; status=",result.status)
    end
    joinpath(directory,"result.csv")
end

function scan(ratio;output=R.OUTPUT,Us=[4.,2.,1.,.75,.5])
    BLAS.set_num_threads(1)
    path=joinpath(output,"scans",ratio_label(ratio)*".csv")
    isfile(path) && error("completed ratio scan exists")
    for U in Us
        run_point(U,ratio;output)
    end
    data=String[]
    for U in (.5,.75,1.,2.,4.)
        result=joinpath(output,"runs",ratio_label(ratio),"U"*string(U),"result.csv")
        isfile(result) || return nothing
        push!(data,validated_point(dirname(result),U,ratio))
    end
    mkpath(dirname(path))
    # A resumed campaign may combine points from the original driver and this
    # adaptive extension. Each point keeps its own immutable source snapshot.
    open(path*".point_sources.txt","w") do io
        for U in (.5,.75,1.,2.,4.)
            folder=joinpath(output,"runs",ratio_label(ratio),"U"*string(U))
            isfile(joinpath(folder,"completed.txt")) || error("missing point completion")
            println(io,"U=",U," result SHA256=",V.filehash(joinpath(folder,"result.csv")))
            println(io,read(joinpath(folder,"provenance.txt"),String))
        end
    end
    open(path*".partial","w") do io
        println(io,HEADER)
        foreach(line->println(io,line),data)
    end
    mv(path*".partial",path)
    path
end

function main(args=ARGS)
    ratio=-.2;output=R.OUTPUT;Us=[4.,2.,1.,.75,.5]
    for arg in args
        if startswith(arg,"--ratio=")
            ratio=parse(Float64,split(arg,'=';limit=2)[2]);ratio_label(ratio)
        elseif startswith(arg,"--output-dir=")
            output=abspath(split(arg,'=';limit=2)[2])
        elseif startswith(arg,"--U=")
            Us=[parse(Float64,split(arg,'=';limit=2)[2])]
        elseif startswith(arg,"--Us=")
            Us=parse.(Float64,split(split(arg,'=';limit=2)[2],','))
        elseif arg=="--help"
            println("Usage: julia --project=. scripts/run_prl_101_237004_fig2c_resolved.jl --ratio=-0.2|-0.5 [--output-dir=PATH] [--U=VALUE]")
            println("Computes the five published Fig2(c) U values by default; --U computes one point and assembles a final curve only if all five exist.")
            return
        else
            error("unknown option $arg")
        end
    end
    println(scan(ratio;output,Us))
end
end

if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Fig2CResolvedCampaign.main()
end
