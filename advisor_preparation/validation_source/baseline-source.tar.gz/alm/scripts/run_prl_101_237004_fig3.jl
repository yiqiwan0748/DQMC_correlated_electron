#!/usr/bin/env julia
module PRL101237004Fig3Run

using LinearAlgebra, Printf, Dates, TOML, SHA
include("prl_101_237004_fig3_campaign.jl")
const D=PRL101237004Fig3Campaign
const S=D.S
const SOURCES=vcat(D.SOURCES,["scripts/run_prl_101_237004_fig3.jl"])

function matrix_csv(path,omegas,points,coordinate,values)
    D.R.V.write_csv(path,"path_index,path_coordinate,kx,ky,omega_minus_mu,A_states_per_Fe_per_energy",
        ((j,coordinate[j],points[j]...,omegas[i],values[i,j]) for j in eachindex(points) for i in eachindex(omegas)))
end

function load_spectral_case(case;input,output,block_steps)
    saved=D.load_case(case;input,output)
    (iszero(case.U) || block_steps==48) && return saved
    block_steps in (96,192) || error("supported spectral block depths are48,96,192")
    # Reuse the independently hashed deeper reference when available. The
    # inherited variational center and its original input cache stay intact.
    audit=joinpath(dirname(output),"numerical_audit")
    marker=joinpath(audit,case.name,"depth96_reference.toml")
    if block_steps==96 && isfile(marker)
        record=TOML.parsefile(marker)
        source=joinpath(audit,record["cache"])
        D.filehash(source)==record["sha256"] || error("deeper audit cache changed")
        D.copy_identical(source,joinpath(output,"reference_cache",basename(source)))
    end
    state=D.R.reference_state(case.U,case.ratio,saved.meta["h"];block_steps,output)
    problem=S.SpectralProblem(state.reference,state.cluster,state.parameters;
        mu=saved.problem.mu,mu_prime=saved.problem.mu_prime)
    meta=copy(saved.meta)
    meta["inherited_variational_reference_block_steps"]=48
    meta["block_steps"]=block_steps
    meta["spectral_reference_cache"]=relpath(state.cache,output)
    meta["spectral_reference_sha256"]=D.filehash(state.cache)
    meta["reference_kind"]="real_axis_depth_refined_at_saved_Fig2c_variational_center"
    (;problem,state,row=saved.row,meta,case)
end

function run(;output=D.OUTPUT,input=D.INPUT,eta=.05,physical_L=48,path_intervals=48,fs_L=192,block_steps=48)
    eta==.05 || error("production Figure3 uses the printed broadening eta=0.05")
    physical_L==48 || error("production DOS uses saved L48 mesh; mesh audits have a separate driver")
    fs_L>=48 && fs_L%4==0 || error("FS plotting grid must be a multiple of four and at least48")
    path_intervals>=12 && path_intervals%12==0 || error("path subdivisions must be a positive multiple of12")
    block_steps in (48,96,192) || error("supported spectral block depths are48,96,192")
    isfile(joinpath(output,"completed.toml")) && error("completed production exists; use a fresh output directory")
    hashes=D.snapshot(output,SOURCES)
    path=D.paper_path(path_intervals)
    configuration=Dict("started_utc"=>string(now(UTC)),"julia"=>string(VERSION),
        "eta"=>eta,"eta_convention"=>"retarded z=omega_minus_mu+i*eta; Lorentzian half width at half maximum",
        "physical_DOS_L"=>physical_L,"FS_display_L"=>fs_L,"path_intervals_per_segment"=>path_intervals,
        "spectral_block_steps"=>block_steps,"inherited_variational_block_steps"=>48,
        "path"=>"(0,pi) -> (pi,pi) -> (0,0) -> (0,pi) -> (pi,0)",
        "normalization"=>"sum over two spins and two orbitals;4 integrated states per Fe",
        "symmetrization"=>"equal arithmetic mean of A(k),A(R90*k),A(R180*k),A(R270*k); raw stripe intensity retained",
        "source_sha256"=>hashes,"BLAS_threads"=>BLAS.get_num_threads(),"Julia_threads"=>Threads.nthreads())
    D.write_toml(joinpath(output,"configuration.toml"),configuration)
    manifest=Dict{String,Any}()
    for case in D.CASES
        folder=joinpath(output,"cases",case.name)
        isfile(joinpath(folder,"completed.toml")) && error("case output already exists; use a fresh output directory")
        saved=load_spectral_case(case;input,output,block_steps)
        D.write_toml(joinpath(folder,"parameters.toml"),saved.meta)
        start=time()
        dos_omega=collect(range(-3.,3.;length=601))
        qpoints=D.R.G.reduced_momentum_grid(D.R.G.rectangular_cluster(),physical_L)
        dos_plan=S.spectral_plan(saved.problem,qpoints)
        dos=S.dos_spectrum(dos_plan,dos_omega;eta)
        D.R.V.write_csv(joinpath(folder,"dos.csv"),"omega_minus_mu,DOS_states_per_Fe_per_energy",
            zip(dos_omega,dos.total))
        @printf("%s %s DOS complete: %d frequencies, %d reduced momenta; %.2fs\n",string(now()),case.name,length(dos_omega),length(qpoints),time()-start)
        flush(stdout)
        files=["parameters.toml","dos.csv"]
        if case.name in ("blue_U0p5","red_U1")
            lo,hi=case.name=="blue_U0p5" ? (-2.5,2.5) : (-1.8,3.2)
            omega=collect(range(lo,hi;length=501))
            plan=S.spectral_plan(saved.problem,path.points)
            spectrum=S.spectral_grid(plan,omega;eta)
            matrix_csv(joinpath(folder,"path.csv"),omega,path.points,path.coordinate,spectrum.total)
            push!(files,"path.csv")
            @printf("%s %s path complete: %d frequencies, %d momenta; %.2fs\n",string(now()),case.name,length(omega),length(path.points),time()-start)
            flush(stdout)
        end
        if case.name=="blue_U0p5"
            axis=collect(range(-pi,pi;length=fs_L+1))[1:end-1]
            points=[(kx,ky) for ky in axis for kx in axis]
            fsplan=S.spectral_plan(saved.problem,points)
            fs=S.spectral_grid(fsplan,[0.];eta)
            raw=reshape(vec(fs.total),fs_L,fs_L)
            # Integer modular rotations on the endpoint-excluded periodic grid.
            # This averages intensities; it is not a self-energy average.
            rotated=zeros(fs_L,fs_L)
            for iy in 1:fs_L,ix in 1:fs_L
                negx=mod(-(ix-1),fs_L)+1; negy=mod(-(iy-1),fs_L)+1
                rotated[ix,iy]=(raw[ix,iy]+raw[negy,ix]+raw[negx,negy]+raw[iy,negx])/4
            end
            D.R.V.write_csv(joinpath(folder,"fermi_intensity.csv"),
                "ix,iy,kx,ky,A_raw_stripe,A_C4_mean",
                ((ix,iy,axis[ix],axis[iy],raw[ix,iy],rotated[ix,iy]) for iy in 1:fs_L for ix in 1:fs_L))
            push!(files,"fermi_intensity.csv")
            @printf("%s %s Fermi intensity complete: %d momenta; %.2fs\n",string(now()),case.name,length(points),time()-start)
            flush(stdout)
        end
        D.guard(hashes)
        outputs=Dict(f=>D.filehash(joinpath(folder,f)) for f in files)
        D.write_toml(joinpath(folder,"completed.toml"),Dict("case"=>case.name,
            "completed_utc"=>string(now(UTC)),"elapsed_seconds"=>time()-start,"output_sha256"=>outputs))
        manifest[case.name]=D.filehash(joinpath(folder,"completed.toml"))
    end
    D.guard(hashes)
    D.write_toml(joinpath(output,"completed.toml"),Dict("completed_utc"=>string(now(UTC)),
        "status"=>"spectral_grids_computed","source_hashes_unchanged"=>true,
        "case_completion_sha256"=>manifest,
        "limits"=>"Production data complete; independent spectral audits and paper comparison are recorded separately."))
end

function main(args=ARGS)
    options=Dict{Symbol,Any}()
    for arg in args
        startswith(arg,"--") && occursin('=',arg) || error("use --option=value")
        key,value=split(arg[3:end],'=';limit=2)
        key=="output-dir" ? (options[:output]=abspath(value)) :
        key=="input-root" ? (options[:input]=abspath(value)) :
        key=="fs-L" ? (options[:fs_L]=parse(Int,value)) :
        key=="path-intervals" ? (options[:path_intervals]=parse(Int,value)) :
        key=="block-steps" ? (options[:block_steps]=parse(Int,value)) : error("unknown option: $key")
    end
    BLAS.set_num_threads(1)
    run(;options...)
end

end
if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Fig3Run.main()
end
