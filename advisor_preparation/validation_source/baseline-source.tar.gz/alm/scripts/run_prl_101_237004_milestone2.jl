#!/usr/bin/env julia

module PRL101237004Milestone2

using LinearAlgebra
using Printf
using Random
using SHA

include("prl_101_237004_ed.jl")
include("prl_101_237004_geometry.jl")
include("prl_101_237004_lanczos.jl")
const ED = PRL101237004ED
const Geometry = PRL101237004Geometry
const Lanczos = PRL101237004Lanczos
const ROOT = normpath(joinpath(@__DIR__, ".."))
const DEFAULT_OUTPUT = joinpath(ROOT, "results", "prl_101_237004", "milestone2")

"""Resolve a small dense ground manifold and a separating excitation gap.

The budget covers three dense matrix-sized arrays plus linear work. It is a
conservative workspace allowance, not a measurement of process RSS. The
default 1 GiB permits the 4900-state four-site block. No eight-site target
block is materialized. Degeneracy is resolved only within the stated energy
tolerance and is explicitly rejected if the requested low window is too small.
"""
function dense_low_spectrum(H; low_states=8, degeneracy_atol=1e-10,
    degeneracy_rtol=1e-10, max_bytes=1024^3)
    n = size(H, 1)
    n > 0 && size(H) == (n, n) || throw(ArgumentError("H must be square and nonempty"))
    low_states >= 1 || throw(ArgumentError("low_states must be positive"))
    all(x -> isfinite(x) && x >= 0, (degeneracy_atol, degeneracy_rtol)) ||
        throw(ArgumentError("degeneracy tolerances must be finite and nonnegative"))
    estimated_bytes = sizeof(eltype(H)) * (3big(n)^2 + 64big(n))
    estimated_bytes <= max_bytes || throw(ArgumentError("dense workspace estimate exceeds max_bytes"))
    matrix = Matrix(H)
    issymmetric(matrix) || error("Hamiltonian failed the real-symmetry check")
    window = min(n, low_states)
    spectrum = eigen(Symmetric(matrix), 1:window)
    E0 = spectrum.values[1]
    tolerance = degeneracy_atol + degeneracy_rtol * abs(E0)
    multiplicity = count(value -> value - E0 <= tolerance, spectrum.values)
    multiplicity == window && window < n && error("low-state window does not bound the ground manifold")
    gap = multiplicity < window ? spectrum.values[multiplicity + 1] - E0 : Inf
    residuals = [norm(H * spectrum.vectors[:, i] - spectrum.values[i] * spectrum.vectors[:, i]) for i in 1:window]
    maximum(residuals) <= 1e-10 || error("dense eigenpair residual exceeds 1e-10")
    return (energies=spectrum.values, vectors=spectrum.vectors,
        ground_vectors=spectrum.vectors[:, 1:multiplicity], multiplicity=multiplicity,
        gap=gap, residuals=residuals, degeneracy_tolerance=tolerance,
        workspace_estimate_bytes=estimated_bytes)
end

"""Apply the physical total S+ to columns in a fixed-spin-number basis."""
function raised_spin_vectors(basis, vectors)
    nup, ndown = basis.Nup, basis.Ndown
    if ndown == 0 || nup == basis.nmodes
        return zeros(eltype(vectors), 0, size(vectors, 2))
    end
    target = ED.sector_basis(basis.nmodes, nup + 1, ndown - 1)
    output = zeros(eltype(vectors), length(target.states), size(vectors, 2))
    for (column, state) in enumerate(basis.states), orbital in 1:basis.nmodes
        action = ED.apply_fermion_ops(state,
            ((basis.nmodes + orbital, false), (orbital, true)))
        action === nothing && continue
        final_state, sign = action
        row = target.indices[final_state]
        for j in axes(vectors, 2)
            output[row, j] += sign * vectors[column, j]
        end
    end
    return output
end

function ground_symmetry_summary(H, torus, dense)
    V = dense.ground_vectors
    raised = raised_spin_vectors(H.basis, V)
    sz = (H.basis.Nup - H.basis.Ndown) / 2
    # S² = S-S+ + Sz(Sz+1); diagonalize within the entire ground manifold.
    spin2 = eigvals(Symmetric(raised' * raised + sz * (sz + 1) * I))
    spins = (sqrt.(1 .+ 4 .* max.(spin2, 0)) .- 1) ./ 2
    maximum(abs.(2 .* spins .- round.(2 .* spins))) <= 1e-8 ||
        error("ground-manifold spin is not integer/half-integer")
    v = randn(MersenneTwister(2026), size(H, 1)); v ./= norm(v)
    Hv = H * v
    rows = map(((:Tx, :translation, (1, 0)), (:Ty, :translation, (0, 1)), (:C4, :c4, (0, 0)))) do (label, kind, displacement)
        action = Geometry.symmetry_action(H.basis, torus; kind=kind, displacement=displacement)
        transformed = hcat([Geometry.apply_symmetry(action, V[:, j]) for j in axes(V, 2)]...)
        restricted = V' * transformed
        leakage = norm(transformed - V * restricted)
        unitary_error = norm(restricted' * restricted - I)
        commutator = norm(H * Geometry.apply_symmetry(action, v) - Geometry.apply_symmetry(action, Hv))
        max(leakage, unitary_error, commutator) <= 1e-8 || error("symmetry validation failed for $label")
        (label=label, eigenvalues=eigvals(restricted), leakage=leakage,
            unitarity_error=unitary_error, commutator_error=commutator)
    end
    return (spin_squared=spin2, total_spin=spins, spatial=rows)
end

function atomic_validation()
    rows = NamedTuple[]
    for U in (0.5, 1.0)
        J = U / 4
        expected_by_N = ([0.0], zeros(4),
            sort([U - 3J, U - 3J, U - 3J, U - J, U - J, U + J]),
            fill(3U - 5J, 4), [6U - 10J])
        for N in 0:4
            actual = Float64[]
            for nup in max(0, N - 2):min(2, N)
                H = ED.sector_hamiltonian(zeros(2, 2), U, nup, N - nup; J=J)
                append!(actual, eigvals(Symmetric(Matrix(H))))
            end
            sort!(actual)
            expected = expected_by_N[N + 1]
            length(actual) == length(expected) || error("atomic multiplicity mismatch")
            for i in eachindex(actual)
                difference = abs(actual[i] - expected[i])
                difference <= 1e-12 || throw(ErrorException("atomic spectrum mismatch"))
                push!(rows, (U=U, J=J, N=N, index=i, energy=actual[i], expected=expected[i], absolute_error=difference))
            end
        end
    end
    return rows
end

function cluster_validation(label, torus, U, nup, ndown)
    println("Validating $label: U=$U, (Nup,Ndown)=($nup,$ndown)"); flush(stdout)
    kinetic = Geometry.paper_kinetic_matrix(torus)
    H = ED.sector_hamiltonian(kinetic, U, nup, ndown)
    dense_seconds = @elapsed dense = dense_low_spectrum(H)
    symmetry = ground_symmetry_summary(H, torus, dense)
    lanczos_rows = map((7, 29)) do seed
        seconds = @elapsed solution = Lanczos.lowest_lanczos(H; seed=seed, maxiter=400)
        difference = abs(solution.energy - dense.energies[1])
        difference <= 1e-9 || error("dense/Lanczos ground energies disagree")
        (seed=seed, energy=solution.energy, residual=solution.residual,
            iterations=solution.iterations, energy_error=difference,
            seconds=seconds, workspace_bytes=solution.workspace_bytes)
    end
    println("  dimension=$(size(H,1)), E0=$(dense.energies[1]), multiplicity=$(dense.multiplicity), gap=$(dense.gap)"); flush(stdout)
    return (label=label, nsites=torus.ncells, U=U, J=U/4, nup=nup, ndown=ndown,
        dimension=size(H, 1), dense=dense, symmetry=symmetry, lanczos=lanczos_rows,
        dense_seconds=dense_seconds, operator_bytes=Base.summarysize(H),
        operator_estimated_bytes=H.estimated_bytes)
end

function write_csv(path, header, rows)
    open(path, "w") do io
        println(io, header)
        for row in rows
            println(io, join(Tuple(row), ','))
        end
    end
end

function write_report(output, atoms, clusters, resources)
    open(joinpath(output, "report.md"), "w") do io
        println(io, "# PRL 101, 237004 — milestone 2\n")
        println(io, "The full local interaction of Eq. (2) is implemented and validated for small clusters. It includes intraorbital U, interorbital U′=U−2J, Hund spin exchange, and pair hopping with J′=J. The calculations below use J=U/4 and the uncentered Hamiltonian exactly as printed.\n")
        println(io, "## Atomic validation\n")
        println(io, "All 16 atomic states agree with the analytic multiplets at U=0.5 and U=1. At U=1, J=0.25:\n")
        println(io, "| Electrons | Energy | Multiplicity | Total spin |\n|---:|---:|---:|---:|\n| 0 | 0 | 1 | 0 |\n| 1 | 0 | 4 | 1/2 |\n| 2 | 0.25 | 3 | 1 |\n| 2 | 0.75 | 2 | 0 |\n| 2 | 1.25 | 1 | 0 |\n| 3 | 1.75 | 4 | 1/2 |\n| 4 | 3.5 | 1 | 0 |\n")
        @printf(io, "Largest atomic energy error: %.3g. The test suite separately constructs the literal interaction from Jordan–Wigner matrices and compares every one-/two-site particle/spin block, including its signs and SU(2) conservation.\n\n", maximum(row.absolute_error for row in atoms))
        println(io, "## Finite-cluster checks\n")
        println(io, "| Cluster | U | N↑,N↓ | Dimension | Ground energy (cluster total) | Ground multiplicity in this Sz sector | Gap to next state | Total spins in ground manifold |\n|---|---:|---|---:|---:|---:|---:|---|")
        for c in clusters
            spins = join([@sprintf("%.6f", s) for s in c.symmetry.total_spin], "; ")
            @printf(io, "| %s | %.1f | %d,%d | %d | %.12f | %d | %.8g | %s |\n",
                c.label, c.U, c.nup, c.ndown, c.dimension, c.dense.energies[1], c.dense.multiplicity, c.dense.gap, spins)
        end
        println(io, "\nEach case compares dense diagonalization against two Lanczos starts. Direct original-operator residuals are recorded in `lanczos_comparison.csv`; the low dense spectrum and gap are in `low_energy_spectrum.csv`. Ground-state spin and spatial symmetries use the complete densely resolved manifold, rather than a single arbitrary vector.\n")
        println(io, "The periodic 2×2 cases are half filled (N=8). The tilted eight-site case contains only two electrons (N=2) and validates its active interorbital hopping; it is not the half-filled Fig. 2(a) calculation. At periodic 2×2, t4 cancels from the kinetic matrix, while Hund exchange and pair transfer still couple orbitals.\n")
        println(io, "The symmetry checks include fermionic signs for translations and C4, the orbital action xz→yz and yz→−xz, Hamiltonian commutators, and ground-subspace closure. Listed rotation/translation eigenvalues are spectra of separate symmetry actions; they are not a full point-group irrep assignment.\n")
        println(io, "## Eight-site target resource audit\n")
        println(io, "| N↑,N↓ | Full fixed-spin dimension | Largest momentum block | One full Float64 vector (GiB) | 128 vectors in largest block (GiB) |\n|---|---:|---:|---:|---:|")
        for row in resources
            @printf(io, "| %d,%d | %s | %s | %.4f | %.4f |\n", row.Nup, row.Ndown,
                string(row.full_dimension), string(row.largest_momentum_dimension),
                Float64(row.full_vector_bytes)/1024^3, Float64(row.reduced_128_vector_bytes)/1024^3)
        end
        println(io, "\nCounts are computed from translation characters without enumerating the large basis. Vector sizes are exact raw storage; state indexing, operator data, restarts, and other arrays add memory. Complex vectors double these numbers. The current explicit-basis, fully reorthogonalized backend is intended for small-sector validation. It refuses these target sectors before allocating them. A production translation-resolved solver is not implemented in this milestone.\n")
        println(io, "## Reproduce\n\n```bash\nOPENBLAS_NUM_THREADS=1 julia --project=. scripts/run_prl_101_237004_milestone2.jl --output-dir=results/prl_101_237004/milestone2_rerun\njulia --project=. test/runtests.jl\n```\n")
        println(io, "Use a new output path. Energy units are (pdσ)²/Δpd, with pdπ/pdσ=−0.2. The output contains source hashes and explicit numerical tolerances. P2 validates the interacting Hamiltonian and small-cluster tools; no magnetic-order, VCA, or pairing panel is claimed reproduced. The next milestone targets Fig. 2(a) at eight-site half filling, N=16.\n")
    end
end

function main(arguments=ARGS)
    output = DEFAULT_OUTPUT
    for arg in arguments
        startswith(arg, "--output-dir=") || throw(ArgumentError("only --output-dir=PATH is supported"))
        output = abspath(split(arg, '='; limit=2)[2])
    end
    ispath(output) && error("output path already exists: $output")
    atoms = atomic_validation()
    square, tilted = Geometry.periodic_square_torus(), Geometry.standard_eight_site_torus()
    resources = Geometry.resource_estimates(tilted)
    for row in resources
        refused = false
        try
            ED.sector_basis(16, row.Nup, row.Ndown)
        catch exception
            exception isa ArgumentError || rethrow()
            refused = true
        end
        refused || error("a target sector unexpectedly bypassed the small-basis guard")
    end
    clusters = [cluster_validation("periodic_2x2", square, U, 4, 4) for U in (0.5, 1.0)]
    push!(clusters, cluster_validation("tilted_8site_low_filling", tilted, 1.0, 1, 1))
    mkpath(dirname(output))
    staging = mktempdir(dirname(output); prefix="milestone2.partial.")
    write_csv(joinpath(staging, "atomic_spectrum.csv"), "U,J,N,index,energy,expected,absolute_error", atoms)
    summary_rows, low_rows, lanczos_rows, symmetry_rows, spin_rows = (Tuple[] for _ in 1:5)
    for c in clusters
        push!(summary_rows, (c.label, c.nsites, c.U, c.J, c.nup, c.ndown, c.dimension,
            c.dense.energies[1], c.dense.multiplicity, c.dense.gap,
            maximum(c.dense.residuals), c.dense.degeneracy_tolerance,
            c.dense_seconds, c.operator_bytes, c.operator_estimated_bytes))
        for i in eachindex(c.dense.energies)
            push!(low_rows, (c.label, c.U, i, c.dense.energies[i], c.dense.residuals[i], i <= c.dense.multiplicity))
        end
        for row in c.lanczos
            push!(lanczos_rows, (c.label, c.U, row.seed, row.energy, row.energy_error,
                row.residual, row.iterations, row.seconds, row.workspace_bytes))
        end
        for row in c.symmetry.spatial, (i, value) in enumerate(row.eigenvalues)
            push!(symmetry_rows, (c.label, c.U, row.label, i, real(value), imag(value),
                row.leakage, row.unitarity_error, row.commutator_error))
        end
        for i in eachindex(c.symmetry.total_spin)
            push!(spin_rows, (c.label, c.U, i, c.symmetry.spin_squared[i], c.symmetry.total_spin[i]))
        end
    end
    write_csv(joinpath(staging, "cluster_summary.csv"), "cluster,sites,U,J,Nup,Ndown,dimension,E0,ground_multiplicity_in_Sz_sector,gap,dense_max_residual,degeneracy_tolerance,dense_seconds,operator_actual_bytes,operator_bound_bytes", summary_rows)
    write_csv(joinpath(staging, "low_energy_spectrum.csv"), "cluster,U,index,energy,residual,in_ground_manifold", low_rows)
    write_csv(joinpath(staging, "lanczos_comparison.csv"), "cluster,U,seed,energy,abs_error_vs_dense,residual,iterations,seconds,workspace_bound_bytes", lanczos_rows)
    write_csv(joinpath(staging, "ground_symmetries.csv"), "cluster,U,symmetry,index,eigenvalue_real,eigenvalue_imag,manifold_leakage,unitarity_error,commutator_error", symmetry_rows)
    write_csv(joinpath(staging, "ground_spin.csv"), "cluster,U,index,spin_squared,total_spin", spin_rows)
    write_csv(joinpath(staging, "eight_site_resources.csv"), "sector,N,Nup,Ndown,full_dimension,largest_momentum_dimension,full_vector_bytes,reduced_vector_bytes,full_three_vector_bytes,reduced_three_vector_bytes,full_128_vector_bytes,reduced_128_vector_bytes,full_dense_bytes,reduced_dense_bytes,production_solver_available",
        [(r.label, r.N, r.Nup, r.Ndown, r.full_dimension, r.largest_momentum_dimension,
          r.full_vector_bytes, r.reduced_vector_bytes, r.full_three_vector_bytes,
          r.reduced_three_vector_bytes, r.full_128_vector_bytes, r.reduced_128_vector_bytes,
          r.full_dense_bytes, r.reduced_dense_bytes, r.symmetry_reduced_solver_available) for r in resources])
    write_csv(joinpath(staging, "eight_site_momentum_dimensions.csv"), "sector,kx,ky,dimension",
        [(r.label, block.kx, block.ky, block.fixed_Nup_Ndown_dimension) for r in resources for block in r.momentum_blocks])
    write_report(staging, atoms, clusters, resources)
    open(joinpath(staging, "metadata.txt"), "w") do io
        println(io, "paper=https://doi.org/10.1103/PhysRevLett.101.237004\nsource_pdf_sha256=3b4eaec2eb6aa397b44a2662387ef6d43a9f677e4fdcec3c14839f671b6493ae\njulia_version=$VERSION")
        println(io, "milestone=P2\nenergy_unit=(pd_sigma)^2/Delta_pd\npdpi_pdsigma=-0.2\nJ=U/4\nUprime=U-2J\npair_hopping=J\nchemical_potential=0\ninteraction_centered=false\norbital_order=(dxz,dyz)")
        println(io, "fock_bit_order=all_up_orbital_fast_then_all_down_orbital_fast\nhxy=+4*t4*sin(kx)*sin(ky)\nperiodic_images=accumulated\natomic_atol=1e-12\ndense_residual_atol=1e-10\nlanczos_atol=1e-11\nlanczos_rtol=1e-12\nenergy_comparison_atol=1e-9\ndegeneracy_atol=1e-10\ndegeneracy_rtol=1e-10\nsymmetry_atol=1e-8\nseeds=7,29")
        println(io, "local_basis_limit=100000\noperator_memory_budget_bytes=$(512*1024^2)\ndense_workspace_budget_bytes=$(1024^3)\nlarge_target_basis_allocated=false\nproduction_symmetry_reduced_solver_available=false\nfigures2_to4_reproduced=false")
        for file in ("prl_101_237004_ed.jl", "prl_101_237004_geometry.jl", "prl_101_237004_lanczos.jl", "prl_101_237004_model.jl", "two_orbital_tilted_cluster_ed.jl", "run_prl_101_237004_milestone2.jl")
            println(io, "source_sha256 $(bytes2hex(sha256(read(joinpath(@__DIR__,file))))) scripts/$file")
        end
        source_path = joinpath(ROOT, "src", "noninteracting.jl")
        digest = bytes2hex(sha256(read(source_path)))
        println(io, "source_sha256 $digest src/noninteracting.jl")
    end
    open(joinpath(staging, "checksums.sha256"), "w") do io
        for name in sort(readdir(staging))
            name == "checksums.sha256" && continue
            digest = bytes2hex(sha256(read(joinpath(staging, name))))
            println(io, "$digest  $name")
        end
    end
    mv(staging, output)
    println("Milestone 2 validated and saved to $output")
    return output
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    PRL101237004Milestone2.main()
end
