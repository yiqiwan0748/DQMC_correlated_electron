#!/usr/bin/env julia
module PRL101237004Milestone3

using LinearAlgebra, Printf, SHA, Dates
include("prl_101_237004_geometry.jl")
include("prl_101_237004_momentum_basis.jl")
include("prl_101_237004_momentum_operator.jl")
include("prl_101_237004_restarted_lanczos.jl")
include("prl_101_237004_momentum_observables.jl")
const G = PRL101237004Geometry
const B = PRL101237004MomentumBasis
const O = PRL101237004MomentumOperator
const L = PRL101237004RestartedLanczos
const S = PRL101237004MomentumObservables
const ROOT = normpath(joinpath(@__DIR__, ".."))
const DEFAULT_OUTPUT = joinpath(ROOT, "results", "prl_101_237004", "milestone3")
const MOMENTA = Dict("gamma"=>(0.0,0.0), "stripe"=>(pi,0.0),
                     "M"=>(pi,pi), "diagonal"=>(pi/2,pi/2))
const CORE_SOURCES = vcat("scripts/" .* ["prl_101_237004_model.jl", "prl_101_237004_geometry.jl",
    "two_orbital_tilted_cluster_ed.jl", "prl_101_237004_momentum_basis.jl",
    "prl_101_237004_momentum_operator.jl", "prl_101_237004_restarted_lanczos.jl",
    "prl_101_237004_momentum_observables.jl"], ["src/noninteracting.jl"])
source_hashes() = Dict(name=>bytes2hex(open(sha256, joinpath(ROOT,name))) for name in CORE_SOURCES)

function write_csv(path, header, rows)
    temporary = path * ".partial"
    open(temporary,"w") do io
        println(io, header)
        for row in rows
            println(io, join(row,','))
        end
    end
    mv(temporary,path; force=true)
end

"""Solve one inequivalent momentum block. Each job has its own checkpoint and
plain numerical outputs. Existing completed jobs are preserved; --resume uses
only a checkpoint whose physical metadata and core source hashes match.
"""
function run_job(output, U, label; nev=1,
                 krylovdim=(label=="diagonal" ? 9 : 16), keep=3,
                 max_matvecs=600, atol=1e-9, seed=7, start="random", resume=false,
                 initial_checkpoint="")
    haskey(MOMENTA,label) || throw(ArgumentError("unknown momentum label $label"))
    start in ("random","free") || throw(ArgumentError("start must be random or free"))
    isfinite(U) && U >= 0 || throw(ArgumentError("U must be finite and nonnegative"))
    start=="free" && label!="gamma" && throw(ArgumentError("half-filled closed shell has gamma momentum"))
    resume && !isempty(initial_checkpoint) && throw(ArgumentError("resume and initial-checkpoint are exclusive"))
    !isempty(initial_checkpoint) && !isfile(initial_checkpoint) && error("initial checkpoint does not exist")
    jobname = "U" * replace(string(Float64(U)),'.'=>'p') * "_" * label * "_seed" * string(seed)
    folder = joinpath(output,jobname)
    checkpoint = joinpath(output,"checkpoints",jobname*".jls")
    isfile(joinpath(folder,"energies.csv")) && error("completed job already exists: $folder")
    resume && !isfile(checkpoint) && error("resume requires an existing checkpoint: $checkpoint")
    ispath(folder) && !resume && error("partial job exists; use --resume after reviewing it: $folder")
    mkpath(folder)
    kx,ky = MOMENTA[label]
    metadata = (; model="PRL101237004 literal Eq1+Eq2", nsites=8, Nup=8, Ndown=8,
        U=Float64(U), J=Float64(U/4), ratio=-0.2, kx,ky, source_hashes=source_hashes())
    if !resume
        snapshot = joinpath(folder,"source_snapshot")
        mkpath(snapshot)
        for name in vcat(CORE_SOURCES,["scripts/"*basename(@__FILE__)])
            mkpath(dirname(joinpath(snapshot,name)))
            cp(joinpath(ROOT,name),joinpath(snapshot,name))
        end
    end
    torus = G.standard_eight_site_torus()
    basis_seconds = @elapsed b = B.build_momentum_basis(torus,8,8,kx,ky)
    K = G.paper_kinetic_matrix(torus)
    operator_seconds = @elapsed H = O.momentum_hamiltonian(b,K,U)
    initial = nothing
    initial_record = nothing
    if resume && isfile(checkpoint)
        saved = L.read_lanczos_checkpoint(checkpoint)
        saved.metadata == metadata || error("checkpoint metadata or source hashes differ")
        saved.configuration.nev == nev || error("checkpoint nev differs")
        initial = saved.vectors
        println("Resuming best Ritz vectors at prior count $(saved.matvecs)")
    elseif !isempty(initial_checkpoint)
        seed_state = L.read_lanczos_checkpoint(initial_checkpoint)
        # A checkpoint is only a starting vector. U/J may differ; the new H
        # and its directly evaluated residual determine the new eigenpair.
        # Basis ordering, particle counts, and momentum must agree exactly.
        sm = seed_state.metadata
        (sm.nsites,sm.Nup,sm.Ndown,sm.kx,sm.ky,seed_state.dimension) ==
            (8,8,8,kx,ky,length(b)) || error("initial checkpoint basis sector differs")
        prior_basis_hash = get(sm.source_hashes,"scripts/prl_101_237004_momentum_basis.jl",
            get(sm.source_hashes,"prl_101_237004_momentum_basis.jl",""))
        prior_basis_hash == metadata.source_hashes["scripts/prl_101_237004_momentum_basis.jl"] ||
            error("initial checkpoint basis ordering source differs")
        initial = copy(@view seed_state.vectors[:,1])
        initial_record = (; path=abspath(initial_checkpoint),sha256=bytes2hex(open(sha256,initial_checkpoint)),
            previous_U=sm.U,previous_J=sm.J,previous_count=seed_state.matvecs,
            previous_converged=seed_state.converged)
        seed_state=nothing
        GC.gc()
    elseif start=="free"
        free = S.free_slater_start(b,K)
        initial = free.vector
        println("Free start: E=$(free.unprojected_energy), projection weight=$(free.projection_weight)")
    end
    println("$(now()) $jobname: dimension=$(length(b)), scalar=$(eltype(H)), nev=$nev, krylovdim=$krylovdim")
    flush(stdout)
    open(joinpath(folder,"metadata.txt"),resume ? "a" : "w") do io
        println(io, "Physical metadata: ",metadata)
        println(io, "Julia: ",VERSION,"; threads: ",Threads.nthreads(),"; BLAS threads: ",BLAS.get_num_threads())
        println(io, "Started: ",now(),"; start: ",start,"; seed: ",seed,"; resume: ",resume)
        initial_record===nothing || println(io,"Initial checkpoint (first vector only): ",initial_record)
        println(io, "Solver: nev=",nev,"; krylovdim=",krylovdim,"; keep=",keep,
            "; max_matvecs=",max_matvecs,"; atol=",atol,"; rtol=0; max_bytes=",4*1024^3)
        resume && println(io,"Warm resume from previous attempt count: ",saved.matvecs,
            "; previous configuration: ",saved.configuration)
        println(io, "Basis seconds: ",basis_seconds,"; operator seconds: ",operator_seconds)
        println(io, "Operator and basis live bytes: ",Base.summarysize(H))
    end
    progress_path = joinpath(folder,resume ? "progress_resume_"*Dates.format(now(),"yyyymmddTHHMMSSsss")*".csv" : "progress.csv")
    progress_mode = "w"
    elapsed = @elapsed solution = open(progress_path, progress_mode) do io
        progress_mode=="w" && println(io,"timestamp,matvecs,restarts,root,energy,residual_estimate,direct_residual,converged")
        progress = function(info)
            for i in eachindex(info.values)
                println(io,join((now(), info.matvecs,info.restarts,i,info.values[i],
                    info.residual_estimates[i],info.residuals===nothing ? "" : info.residuals[i],info.converged),','))
            end
            flush(io)
            @printf("%s %s: mv=%d E=%.12f estimated residual=%.3g%s\n",string(now()),
                jobname,info.matvecs,info.values[1],info.residual_estimates[1],info.converged ? " converged" : "")
            flush(stdout)
        end
        L.restarted_lowest(H; nev,krylovdim,keep,max_matvecs,atol,rtol=0.0,seed,
            max_bytes=4*1024^3,initial_vector=initial,checkpoint_path=checkpoint,
            checkpoint_every=30,checkpoint_metadata=metadata,progress)
    end
    solution.converged || error("job did not converge; checkpoint saved for explicit resume")
    # S² is evaluated in the existing fixed-spin block, without another large
    # vector. Its expectation tests spin before applying singlet isotropy.
    if label=="gamma"
        v = @view solution.vectors[:,1]
        structure = S.spin_structure_factors(b,v)
        spin2 = S.total_spin_squared(b,v)
        abs(spin2) <= 1e-7 || error("candidate ground state is not a singlet: S²=$spin2")
        rows = [(q[1]/pi,q[2]/pi,structure.szsz_per_site[i],structure.szsz_raw[i],
                 3structure.szsz_per_site[i]) for (i,q) in enumerate(structure.momenta)]
        write_csv(joinpath(folder,"structure_factors.csv"),
            "qx_over_pi,qy_over_pi,Szz_per_site,Szz_raw,Sdot_per_site_singlet",rows)
        write_csv(joinpath(folder,"spin_checks.csv"),"norm_squared,total_spin_squared,local_Sdot_from_momentum_sum",
            [(structure.norm_squared,spin2,3sum(structure.szsz_per_site)/8)])
    end
    write_csv(joinpath(folder,"energies.csv"),"U,J,k_label,kx_over_pi,ky_over_pi,dimension,root,energy,residual,matvecs,seconds,solver_workspace_bytes",
        [(U,U/4,label,kx/pi,ky/pi,length(b),i,solution.values[i],solution.residuals[i],
          solution.matvecs,elapsed,solution.estimated_workspace_bytes) for i in eachindex(solution.values)])
    println("Finished $jobname in $(round(elapsed;digits=2)) seconds; energies=$(solution.values), residuals=$(solution.residuals)")
    flush(stdout)
    return nothing
end

function main(arguments=ARGS)
    options = Dict("output-dir"=>DEFAULT_OUTPUT,"U"=>"0.5","k"=>"gamma", "seed"=>"7", "start"=>"random",
                   "nev"=>"1", "krylovdim"=>"", "keep"=>"3", "max-matvecs"=>"600", "atol"=>"1e-9",
                   "initial-checkpoint"=>"")
    resume = false
    for arg in arguments
        if arg=="--resume"
            resume=true
        else
            startswith(arg,"--") && occursin('=',arg) || throw(ArgumentError("use --key=value"))
            key,value = split(arg[3:end],'=';limit=2)
            haskey(options,key) || throw(ArgumentError("unknown option --$key"))
            options[key]=value
        end
    end
    label = options["k"]
    nev = parse(Int,options["nev"])
    m = isempty(options["krylovdim"]) ? (label=="diagonal" ? 9 : 16) : parse(Int,options["krylovdim"])
    run_job(abspath(options["output-dir"]),parse(Float64,options["U"]),label; nev,krylovdim=m,
        keep=parse(Int,options["keep"]), max_matvecs=parse(Int,options["max-matvecs"]),
        atol=parse(Float64,options["atol"]),seed=parse(Int,options["seed"]),start=options["start"],resume,
        initial_checkpoint=options["initial-checkpoint"])
end

end # module
if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Milestone3.main()
end
