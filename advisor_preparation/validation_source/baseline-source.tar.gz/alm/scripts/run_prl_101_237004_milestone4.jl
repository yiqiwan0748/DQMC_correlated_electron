#!/usr/bin/env julia

# Fig. 2(b), with a fixed physical chemical potential and an independently
# stationary reference chemical potential at every field. No figure values
# enter the calculation. Completed scans are never overwritten.
include("prl_101_237004_vca_campaign.jl")
using .PRL101237004VCACampaign
using LinearAlgebra

function main(args=ARGS)
    output=PRL101237004VCACampaign.DEFAULT_OUTPUT
    label="fig2b_L48_q24"
    for arg in args
        if startswith(arg,"--output-dir=")
            output=abspath(split(arg,'=';limit=2)[2])
        elseif startswith(arg,"--label=")
            label=split(arg,'=';limit=2)[2]
            occursin(r"^[A-Za-z0-9_-]+$",label) || error("label must be a simple directory name")
        elseif arg=="--help"
            println("Usage: julia --project=. scripts/run_prl_101_237004_milestone4.jl [--output-dir=PATH] [--label=NAME]")
            println("Recomputes both Fig. 2(b) curves at U=1, J=1/4, SK ratio=-0.2, mu=.85, L48, quadrature24, block48.")
            println("Use a fresh label for another run. Binary reference caches are reused after metadata and source checks.")
            return
        else
            error("unknown argument: $arg")
        end
    end
    BLAS.set_num_threads(1)
    folder=joinpath(output,"scans",label)
    any(isfile(joinpath(folder,string(c)*".csv")) for c in (:stripe_y,:neel)) &&
        error("a completed curve already exists; use a fresh --label")
    PRL101237004VCACampaign.scan_curve(collect(0:20)./200,:stripe_y;
        mu=.85,physical_L=48,order=24,block_steps=48,U=1.0,ratio=-.2,output,label)
    PRL101237004VCACampaign.scan_curve(collect(0:4)./200,:neel;
        mu=.85,physical_L=48,order=24,block_steps=48,U=1.0,ratio=-.2,output,label)
end

abspath(PROGRAM_FILE)==abspath(@__FILE__) && main()
