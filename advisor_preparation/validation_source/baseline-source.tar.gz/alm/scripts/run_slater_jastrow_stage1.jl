#!/usr/bin/env julia

module RunSlaterJastrowStage1

using AltermagnetDQMCTrial
using Dates
using LinearAlgebra
using Serialization
using SHA
using TOML

include(joinpath(@__DIR__, "sample_slater_jastrow_vmc.jl"))
include(joinpath(@__DIR__, "hubbard_ed_benchmarks.jl"))
const SJ = SlaterJastrowTrials
const VMC = SlaterJastrowVMC
const ED = SJ.ED

function parse_options(arguments)
    any(arg -> arg in ("--help", "-h"), arguments) && return nothing
    options = Dict{String,String}()
    for arg in arguments
        startswith(arg, "--") || throw(ArgumentError("use --name=value"))
        pieces = split(arg[3:end], '='; limit=2)
        length(pieces) == 2 || throw(ArgumentError("use --name=value"))
        name, value = pieces
        name in ("output-dir", "measurements") || throw(ArgumentError("unknown option: $name"))
        haskey(options, name) && throw(ArgumentError("duplicate option: $name"))
        isempty(value) && throw(ArgumentError("empty option: $name"))
        options[name] = value
    end
    measurements = parse(Int, get(options, "measurements", "10000"))
    measurements >= 1000 && measurements % 500 == 0 || throw(ArgumentError(
        "measurements must be a multiple of 500 and at least 1000",
    ))
    return (output_dir=abspath(get(options, "output-dir", "results/slater_jastrow_stage1")),
            measurements=measurements)
end

function write_rows(path, rows)
    isempty(rows) && throw(ArgumentError("cannot write an empty table"))
    names = keys(first(rows))
    open(path, "w") do io
        println(io, join(string.(names), ','))
        for row in rows
            keys(row) == names || error("CSV row schema changed")
            println(io, join((replace(string(value), '"' => "\"\"") |> x ->
                occursin(r"[,\n\r\"]", x) ? "\"$x\"" : x for value in values(row)), ','))
        end
    end
end

function save_sources(output)
    root = dirname(@__DIR__)
    paths = ["Project.toml", "Manifest.toml", "src/AltermagnetDQMCTrial.jl",
             "src/noninteracting.jl", "src/realspace_kinetic.jl", "src/constrained_path_afqmc.jl",
             "scripts/two_orbital_open_cluster_ed.jl", "scripts/hubbard_ed_benchmarks.jl",
             "scripts/slater_jastrow_trials.jl", "scripts/sample_slater_jastrow_vmc.jl",
             "scripts/run_slater_jastrow_stage1.jl", "test/slater_jastrow_trials_tests.jl",
             "test/slater_jastrow_vmc_tests.jl", "test/run_slater_jastrow_stage1_tests.jl"]
    # Include every package source because the package entrypoint loads all of them.
    append!(paths, [joinpath("src", name) for name in readdir(joinpath(root, "src"))
                    if endswith(name, ".jl")])
    hashes = Dict{String,String}()
    for path in sort!(unique(paths))
        source = joinpath(root, path)
        destination = joinpath(output, "source_snapshot", path)
        mkpath(dirname(destination))
        cp(source, destination)
        hashes[path] = bytes2hex(sha256(read(source)))
    end
    open(joinpath(output, "source_hashes.toml"), "w") do io
        TOML.print(io, hashes; sorted=true)
    end
    return hashes
end

function dimer_checks(output)
    rows = NamedTuple[]
    for U in (0.0, 4.0, 12.0, 20.0)
        H = SJ.benchmark_hamiltonian([0.0 -1.0; -1.0 0.0], U, 1, 1)
        trial = SlaterTrial(ones(2, 1), ones(2, 1); label="bonding_dimer")
        fit = SJ.optimize_onsite_jastrow(H, trial)
        result = SJ.variational_evaluation(H, fit.state; Lx=1, Ly=1)
        oracle = HubbardEDBenchmarks.analytic_hubbard_dimer(U)
        energy_error = abs(result.energy - oracle.ground_singlet_energy)
        # 2e-10 is well above tiny optimizer/eigensolver roundoff, below all study energy scales.
        energy_error <= 2.0e-10 || error("analytic dimer check failed")
        push!(rows, (U=U, g=fit.g, analytic_g=asinh(U / 4), energy=result.energy,
                     exact_energy=oracle.ground_singlet_energy, absolute_error=energy_error,
                     energy_variance=result.energy_variance,
                     double_occupancy=result.double_occupancy_total,
                     exact_double_occupancy=oracle.ground_double_occupancy_total))
    end
    write_rows(joinpath(output, "analytic_dimers.csv"), rows)
end

function exact_ground_space(H)
    dense = ED.dense_sector_hamiltonian(H)
    count = min(8, size(H, 1))
    eigensystem = eigen(Symmetric(dense), 1:count)
    # Resolve the full degenerate ground space before interpreting diagonal correlations.
    ground_count = count <= 1 ? 1 : sum(abs.(eigensystem.values .- first(eigensystem.values)) .<= 1.0e-9)
    ground_count < count || count == size(H, 1) || error("ground space exceeds eight eigenvectors")
    vectors = eigensystem.vectors[:, 1:ground_count]
    residual = maximum(norm(H * vectors[:, i] - eigensystem.values[i] * vectors[:, i])
                       for i in 1:ground_count)
    residual <= 1.0e-9 || error("ED residual too large: $residual")
    diagonal = SJ.diagonal_observables(H; Lx=2, Ly=2)
    probabilities = vec(sum(abs2, vectors; dims=2)) ./ ground_count
    means = map(values -> dot(probabilities, values), diagonal)
    gap = ground_count < count ? eigensystem.values[ground_count + 1] - eigensystem.values[1] : NaN
    return (energy=first(eigensystem.values), vectors=vectors, means=means,
            rank=ground_count, gap=gap, residual=residual)
end

function run_study(options)
    ispath(options.output_dir) && throw(ArgumentError("output already exists; refusing overwrite"))
    mkpath(dirname(options.output_dir))
    mkdir(options.output_dir)
    output = options.output_dir
    hashes = save_sources(output)
    metadata = Dict("started_utc" => string(now(UTC)), "julia_version" => string(VERSION),
        "scope" => "onsite Jastrow finite-sector oracle and enumerated VMC validation",
        "optimization" => "exact finite sums over g; finite field grid; not unrestricted orbital optimization",
        "afqmc_correlated_trial_implemented" => false,
        "production_campaign_changed" => false, "boundary" => "open", "Lx" => 2, "Ly" => 2,
        "U" => 12.0, "Nup" => 3, "Ndown" => 3, "density_per_cell" => 1.5,
        "interaction" => "U sum_a (n_a_up-1/2)(n_a_down-1/2)", "physical_field" => 0.0,
        "g_bounds" => [0.0, 6.0], "g_tolerance" => 1.0e-6,
        "field_magnitudes" => [0.0, 0.01, 0.1, 0.5, 1.0, 2.0, 4.0],
        "vmc_seeds" => [51411, 51412, 51413], "vmc_measurements" => options.measurements,
        "vmc_warmup" => 2000, "vmc_steps_between" => 2, "vmc_block_size" => 100,
        "vmc_proposal" => "mixed", "vmc_global_probability" => 0.1,
        "ground_degeneracy_tolerance" => 1.0e-9, "status" => "started")
    write_metadata() = open(joinpath(output, "metadata.toml"), "w") do io
        TOML.print(io, metadata; sorted=true)
    end
    write_metadata()
    dimer_checks(output)
    println("Analytic dimer checks passed through U=20.")
    flush(stdout)
    kinetic = ED.open_cluster_kinetic_matrix(2, 2)
    H = SJ.benchmark_hamiltonian(kinetic, 12.0, 3, 3)
    maximum(abs, kinetic[1:2:end, 2:2:end]) > 0 || error("interorbital hopping missing")
    problem = CPAFQMCProblem(kinetic, 12.0, 3, 3; lattice_size=2, cell_count=4)
    ground = exact_ground_space(H)
    write_rows(joinpath(output, "ed_reference.csv"), [merge(
        (energy=ground.energy, ground_rank=ground.rank, gap=ground.gap, residual=ground.residual),
        ground.means)])
    println("Open 2x2 ED: dimension=$(size(H, 1)), energy=$(ground.energy), ground_rank=$(ground.rank)")
    flush(stdout)
    families = (("free", :free, 1), ("alm_plus", :altermagnetic, 1),
                ("alm_minus", :altermagnetic, -1), ("stripe_x_plus", :stripe_x, 1),
                ("stripe_x_minus", :stripe_x, -1), ("stripe_y_plus", :stripe_y, 1),
                ("stripe_y_minus", :stripe_y, -1))
    scans, summaries, sampling, diagnostics, blocks = (NamedTuple[] for _ in 1:5)
    mkpath(joinpath(output, "trials"))
    mkpath(joinpath(output, "vmc_samples"))
    for (label, pattern, sign) in families
        candidates = NamedTuple[]
        fields = pattern == :free ? [0.0] : metadata["field_magnitudes"]
        for magnitude in fields
            field = sign * magnitude
            trial = one_body_trial(problem; pattern=pattern, field_strength=field)
            bare = SJ.onsite_jastrow_state(H, trial)
            bare_energy = dot(bare, H * bare)
            fit = SJ.optimize_onsite_jastrow(H, trial)
            push!(candidates, (; field, trial, bare, bare_energy, fit))
            push!(scans, (family=label, field=field, bare_energy=bare_energy, g=fit.g,
                          correlated_energy=fit.energy, boundary_hit=fit.boundary_hit,
                          evaluations=fit.evaluations))
        end
        bare_choice = candidates[argmin([row.bare_energy for row in candidates])]
        choice = candidates[argmin([row.fit.energy for row in candidates])]
        choices = (("bare", bare_choice, bare_choice.bare, 0.0),
                   ("jastrow", choice, choice.fit.state, choice.fit.g))
        for (kind, candidate, state, g) in choices
            result = SJ.variational_evaluation(H, state; Lx=2, Ly=2)
            result.energy >= ground.energy - 1.0e-9 || error("variational bound violated")
            id = label * "_" * kind
            push!(summaries, merge((trial_id=id, family=label, kind=kind, field=candidate.field, g=g,
                field_boundary_hit=pattern != :free && abs(candidate.field) == maximum(fields),
                g_search_boundary_hit=kind == "jastrow" && candidate.fit.boundary_hit,
                energy_error=result.energy - ground.energy,
                ground_space_weight=sum(abs2, transpose(ground.vectors) * state),
                delta_second_moment_error=result.m_alm_squared - ground.means.m_alm_squared,
                odd_qx_error=result.odd_qx - ground.means.odd_qx,
                odd_qy_error=result.odd_qy - ground.means.odd_qy,
                odd_qxy_error=result.odd_qxy - ground.means.odd_qxy), result))
            open(joinpath(output, "trials", id * ".jls"), "w") do io
                serialize(io, (format="onsite-jastrow-enumerated-oracle-v1", afqmc_compatible=false,
                    kinetic=kinetic, U=12.0, Nup=3, Ndown=3, Lx=2, Ly=2, boundary=:open,
                    g=g, trial=candidate.trial, state=state, up_basis=H.basis.up_states,
                    down_basis=H.basis.down_states, source_hashes=hashes))
            end
            for seed in metadata["vmc_seeds"]
                mc = VMC.sample_vmc(H, state; Lx=2, Ly=2, seed=seed, warmup=2000,
                    measurements=options.measurements, steps_between=2, block_size=100,
                    proposal=:mixed, global_probability=0.1)
                sample_rows = [NamedTuple{keys(mc.samples)}(Tuple(v[i] for v in values(mc.samples)))
                               for i in 1:options.measurements]
                write_rows(joinpath(output, "vmc_samples", "$(id)_seed$(seed).csv"), sample_rows)
                push!(diagnostics, merge((trial_id=id,), mc.diagnostics,
                    (quantum_energy_variance=mc.exact.energy_variance,
                     node_variance_contribution=mc.exact.node_variance_contribution)))
                for name in keys(mc.means)
                    estimate, reference, se = mc.means[name], mc.exact.means[name], mc.errors[name]
                    push!(sampling, (trial_id=id, seed=seed, quantity=name, estimate=estimate,
                        standard_error=se, exact_trial_mean=reference,
                        absolute_error=abs(estimate - reference),
                        within_six_block_errors=abs(estimate - reference) <= max(6se, 1.0e-10)))
                    for block_size in (50, 100, 250, 500)
                        block_error = VMC._blocked_error(mc.samples[name], block_size)
                        push!(blocks, (trial_id=id, seed=seed, quantity=name,
                            block_size=block_size, blocks=div(options.measurements, block_size),
                            standard_error=block_error))
                    end
                end
            end
        end
        write_rows(joinpath(output, "field_scan.csv"), scans)
        write_rows(joinpath(output, "trial_summary.csv"), summaries)
        write_rows(joinpath(output, "vmc_checks.csv"), sampling)
        write_rows(joinpath(output, "vmc_diagnostics.csv"), diagnostics)
        write_rows(joinpath(output, "block_sensitivity.csv"), blocks)
        println("$label: best bare E=$(bare_choice.bare_energy); Jastrow E=$(choice.fit.energy), g=$(choice.fit.g)")
        flush(stdout)
    end
    metadata["status"] = "complete"
    metadata["finished_utc"] = string(now(UTC))
    metadata["vmc_checks_outside_six_errors"] = count(row -> !row.within_six_block_errors, sampling)
    metadata["sampling_validation"] = metadata["vmc_checks_outside_six_errors"] == 0 ?
        "passed_fixed_seed_finite_sum_checks_not_asymptotic_convergence" : "failed"
    metadata["interpretation"] = "trial-quality benchmark; VMC sampling checks are not AFQMC-bias validation"
    write_metadata()
    metadata["vmc_checks_outside_six_errors"] == 0 || error(
        "VMC checks failed; results preserved, do not promote this trial study",
    )
    return output
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        println("Usage: julia --project=. scripts/run_slater_jastrow_stage1.jl [--output-dir=PATH] [--measurements=10000]")
        return nothing
    end
    BLAS.set_num_threads(2)
    return run_study(options)
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    RunSlaterJastrowStage1.main()
end
