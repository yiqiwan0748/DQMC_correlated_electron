#!/usr/bin/env julia

module RunSlaterJastrowStage2

using AltermagnetDQMCTrial
using Dates
using LinearAlgebra
using Serialization
using SHA
using TOML

include(joinpath(@__DIR__, "run_slater_jastrow_stage1.jl"))
const Stage1 = RunSlaterJastrowStage1
const SlaterJastrowTrials = Stage1.SJ
include(joinpath(@__DIR__, "slater_jastrow_symmetry.jl"))
const SJ = SlaterJastrowTrials
const SY = SlaterJastrowSymmetry
const ED = SJ.ED

function parse_options(arguments)
    any(arg -> arg in ("--help", "-h"), arguments) && return nothing
    options = Dict{String,String}()
    for arg in arguments
        startswith(arg, "--") || throw(ArgumentError("use --name=value"))
        pieces = split(arg[3:end], '='; limit=2)
        length(pieces) == 2 || throw(ArgumentError("use --name=value"))
        key, value = pieces
        key in ("output-dir", "stage1-dir") || throw(ArgumentError("unknown option: $key"))
        haskey(options, key) && throw(ArgumentError("duplicate option: $key"))
        isempty(value) && throw(ArgumentError("empty option: $key"))
        options[key] = value
    end
    return (output_dir=abspath(get(options, "output-dir", "results/slater_jastrow_stage2")),
            stage1_dir=abspath(get(options, "stage1-dir",
                "results/slater_jastrow_stage1_20260911_v2")))
end

"""Bounded exact energy fit; the caller supplies states, never ED targets."""
function optimize_g(H, make_state; bounds=(0.0, 6.0), tolerance=1.0e-6, grid_points=25)
    length(bounds) == 2 || throw(ArgumentError("bounds need two endpoints"))
    a0, b0 = bounds
    all(x -> x isa Real && !(x isa Bool) && isfinite(x), (a0, b0, tolerance)) ||
        throw(ArgumentError("bounds and tolerance must be finite real numbers"))
    0 <= a0 < b0 && tolerance >= 16eps(Float64) * max(1, abs(a0), abs(b0)) ||
        throw(ArgumentError("invalid search bounds or tolerance"))
    grid_points isa Integer && !(grid_points isa Bool) && grid_points >= 3 ||
        throw(ArgumentError("grid_points must be an integer >=3"))
    history = NamedTuple{(:g, :energy),Tuple{Float64,Float64}}[]
    function objective(g)
        state = SJ._normalized_state(H, make_state(g))
        energy = dot(state, H * state)
        isfinite(energy) || error("nonfinite objective")
        push!(history, (g=Float64(g), energy=Float64(energy)))
        return energy
    end
    grid = collect(range(Float64(a0), Float64(b0); length=grid_points))
    energies = objective.(grid)
    ratio = (sqrt(5.0) - 1) / 2
    for i in eachindex(grid)
        lo, hi = max(1, i - 1), min(length(grid), i + 1)
        energies[i] <= energies[lo] && energies[i] <= energies[hi] || continue
        energies[lo] == energies[i] == energies[hi] && continue
        a, b = grid[lo], grid[hi]
        c, d = b - ratio * (b - a), a + ratio * (b - a)
        fc, fd = objective(c), objective(d)
        for _ in 1:256
            b - a <= tolerance && break
            if fc <= fd
                b, d, fd = d, c, fc
                c = b - ratio * (b - a)
                fc = objective(c)
            else
                a, c, fc = c, d, fd
                d = a + ratio * (b - a)
                fd = objective(d)
            end
        end
        b - a <= tolerance || error("g refinement failed to converge")
        objective((a + b) / 2)
    end
    best = history[argmin(getproperty.(history, :energy))]
    return (g=best.g, energy=best.energy, state=SJ._normalized_state(H, make_state(best.g)),
            boundary_hit=min(abs(best.g - a0), abs(best.g - b0)) <= tolerance,
            history=history)
end

function jastrow_on_vector(H, psi)
    state = SJ._normalized_state(H, psi)
    support = findall(!iszero, state)
    minimum_doubles = minimum(H.double_occupancies[support])
    cached = (logs=log.(abs.(state)), signs=sign.(state), support=support,
              minimum_doubles=minimum_doubles)
    return g -> SJ._onsite_state(H, cached, g)
end

function spin_resolved_ground(H, ops, ground)
    spin_matrix = Symmetric(transpose(ground.vectors) * ops.s2 * ground.vectors)
    decomposition = eigen(spin_matrix)
    vectors = ground.vectors * decomposition.vectors
    rows = NamedTuple[]
    for i in eachindex(decomposition.values)
        value = decomposition.values[i]
        spin = round(Int, (sqrt(max(0.0, 1 + 4value)) - 1) / 2)
        spin in ops.allowed_spins || error("ED ground spin is outside the allowed set")
        residual = norm(ops.s2 * vectors[:, i] - spin * (spin + 1) * vectors[:, i])
        residual <= 1.0e-8 || error("ground eigenspace does not resolve total spin")
        push!(rows, (index=i, spin=spin, s2=value, spin_residual=residual,
                     energy=dot(vectors[:, i], H * vectors[:, i])))
    end
    return (rows=rows, vectors=vectors)
end

function evaluate(H, ops, ground, psi)
    state = SJ._normalized_state(H, psi)
    observables = SJ.variational_evaluation(H, state; Lx=2, Ly=2)
    observables.energy >= ground.energy - 1.0e-9 || error("variational bound violated")
    return merge(observables, SY.spin_diagnostics(ops, state),
        (energy_error=observables.energy - ground.energy,
         ground_space_weight=sum(abs2, transpose(ground.vectors) * state)))
end

function mixture_evaluation(left, right)
    keys(left) == keys(right) || throw(ArgumentError("mixture schemas differ"))
    means = map((a, b) -> (a + b) / 2, left, right)
    # A mixture's variance includes the spread between its component means.
    return merge(means,
        (energy_variance=means.energy_variance + (left.energy - right.energy)^2 / 4,
         s2_variance=means.s2_variance + (left.s2_mean - right.s2_mean)^2 / 4))
end

function ensemble_evaluation(results)
    isempty(results) && throw(ArgumentError("ensemble must be nonempty"))
    names = keys(first(results))
    all(row -> keys(row) == names, results) || throw(ArgumentError("ensemble schemas differ"))
    means = NamedTuple{names}(map(name -> sum(getproperty(row, name) for row in results) /
                                 length(results), names))
    return merge(means,
        (energy_variance=means.energy_variance + sum((row.energy - means.energy)^2
            for row in results) / length(results),
         s2_variance=means.s2_variance + sum((row.s2_mean - means.s2_mean)^2
            for row in results) / length(results)))
end

function load_stage1(directory)
    metadata = TOML.parsefile(joinpath(directory, "metadata.toml"))
    for (key, value) in (("Lx", 2), ("Ly", 2), ("U", 12.0), ("Nup", 3),
                         ("Ndown", 3), ("boundary", "open"), ("physical_field", 0.0))
        get(metadata, key, nothing) == value || error("stage1 model mismatch: $key")
    end
    hashes = TOML.parsefile(joinpath(directory, "source_hashes.toml"))
    for (path, expected) in hashes
        isabspath(path) && error("snapshot path must be relative")
        ".." in splitpath(path) && error("snapshot path cannot escape its root")
        bytes2hex(sha256(read(joinpath(directory, "source_snapshot", path)))) == expected ||
            error("stage1 snapshot checksum mismatch: $path")
    end
    paths = [joinpath(directory, "trials", name * ".jls")
             for name in ("alm_plus_jastrow", "alm_minus_jastrow")]
    inputs = deserialize.(paths)
    for input in inputs
        input.format == "onsite-jastrow-enumerated-oracle-v1" && !input.afqmc_compatible ||
            error("unsupported stage1 trial payload")
        input.U == 12.0 && input.Nup == input.Ndown == 3 && input.Lx == input.Ly == 2 &&
            input.boundary == :open || error("stage1 trial model mismatch")
        input.source_hashes == hashes || error("stage1 trial source metadata mismatch")
    end
    return (plus=inputs[1], minus=inputs[2],
            input_hashes=Dict(basename(path) => bytes2hex(sha256(read(path))) for path in paths))
end

function save_sources(output)
    hashes = Stage1.save_sources(output)
    for path in ("scripts/slater_jastrow_symmetry.jl", "scripts/run_slater_jastrow_stage2.jl",
                 "test/slater_jastrow_symmetry_tests.jl", "test/run_slater_jastrow_stage2_tests.jl")
        source = joinpath(dirname(@__DIR__), path)
        destination = joinpath(output, "source_snapshot", path)
        mkpath(dirname(destination))
        cp(source, destination)
        hashes[path] = bytes2hex(sha256(read(source)))
    end
    open(joinpath(output, "source_hashes.toml"), "w") do io
        TOML.print(io, hashes; sorted=true)
    end
    return hashes
end

function run_study(options)
    ispath(options.output_dir) && throw(ArgumentError("output already exists; refusing overwrite"))
    inputs = load_stage1(options.stage1_dir)
    H = SJ.benchmark_hamiltonian(ED.open_cluster_kinetic_matrix(2, 2), 12.0, 3, 3)
    for input in (inputs.plus, inputs.minus)
        input.kinetic == H.kinetic || error("stage1 kinetic mismatch")
        input.up_basis == H.basis.up_states && input.down_basis == H.basis.down_states ||
            error("stage1 basis order mismatch")
        reconstructed = SJ.onsite_jastrow_state(H, input.trial; g=input.g)
        norm(reconstructed - input.state) <= 1.0e-10 || error("saved trial reconstruction failed")
    end
    mkpath(dirname(options.output_dir))
    mkdir(options.output_dir)
    output = options.output_dir
    hashes = save_sources(output)
    metadata = Dict{String,Any}("started_utc" => string(now(UTC)), "status" => "started",
        "julia_version" => string(VERSION), "Lx" => 2, "Ly" => 2, "U" => 12.0,
        "Nup" => 3, "Ndown" => 3, "boundary" => "open", "physical_field" => 0.0,
        "stage1_dir" => options.stage1_dir, "stage1_trial_hashes" => inputs.input_hashes,
        "scope" => "bounded exact-vector spin-symmetry trial diagnostic",
        "optimization" => "energy only, independent g fits and same ALM field grid for every spin sector",
        "field_magnitudes" => [0.0, 0.01, 0.1, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0],
        "g_bounds" => [0.0, 6.0], "g_tolerance" => 1.0e-6,
        "projection_weight_tolerance" => 1.0e-12,
        "afqmc_correlated_trial_implemented" => false, "production_campaign_changed" => false,
        "vmc_sampling_performed" => false)
    save_metadata() = open(joinpath(output, "metadata.toml"), "w") do io
        TOML.print(io, metadata; sorted=true)
    end
    save_metadata()
    try
        ops = SY.spin_operators(H)
        ground = Stage1.exact_ground_space(H)
        ground_spin = spin_resolved_ground(H, ops, ground)
        Stage1.write_rows(joinpath(output, "ed_spin.csv"), ground_spin.rows)
        Stage1.write_rows(joinpath(output, "ed_reference.csv"), [merge(
            (rank=ground.rank, gap=ground.gap, residual=ground.residual),
            ensemble_evaluation([evaluate(H, ops, ground, ground_spin.vectors[:, i])
                for i in axes(ground_spin.vectors, 2)]))])
        metadata["ground_spins"] = [row.spin for row in ground_spin.rows]
        metadata["ground_rank"] = ground.rank
        println("ED E=$(ground.energy), total spins=$(metadata["ground_spins"])")
        flush(stdout)

        mkpath(joinpath(output, "states"))
        function save_state(id, state; details=NamedTuple())
            open(joinpath(output, "states", id * ".jls"), "w") do io
                serialize(io, (format="spin-projected-enumerated-oracle-v1", afqmc_compatible=false,
                    kinetic=inputs.plus.kinetic, U=12.0, Nup=3, Ndown=3, Lx=2, Ly=2,
                    boundary=:open, state=state, up_basis=H.basis.up_states,
                    down_basis=H.basis.down_states, details=details, source_hashes=hashes))
            end
        end
        for i in axes(ground_spin.vectors, 2)
            save_state("ed_ground_$i", ground_spin.vectors[:, i])
        end
        psi = inputs.plus.state
        reversed = SY.spin_reverse(ops, psi)
        partner_error = min(norm(reversed - inputs.minus.state), norm(reversed + inputs.minus.state))
        partner_error <= 1.0e-6 || error("independent opposite trial is not the spin-reversed partner")
        metadata["stage1_opposite_partner_error_up_to_global_sign"] = partner_error
        frozen = NamedTuple[]
        left, right = evaluate(H, ops, ground, psi), evaluate(H, ops, ground, reversed)
        function frozen_row(id, state; retained_weight=1.0)
            result = evaluate(H, ops, ground, state)
            push!(frozen, merge((id=id, retained_weight=retained_weight), result))
            save_state(id, state; details=(stage="fixed_stage1_parameters", g=inputs.plus.g))
        end
        frozen_row("original", psi)
        frozen_row("spin_reversed", reversed)
        push!(frozen, merge((id="incoherent_equal_mixture", retained_weight=1.0),
                            mixture_evaluation(left, right)))
        for parity in (-1, 1)
            combined = (psi + parity * reversed) / 2
            weight = sum(abs2, combined)
            weight > 1.0e-12 && frozen_row("flip_$(parity)", combined / sqrt(weight);
                                          retained_weight=weight)
        end
        pair = SY.coherent_pair(H, ops, psi)
        frozen_row("coherent_pair_minimum", pair.state)
        metadata["frozen_pair_rank"] = pair.rank
        metadata["frozen_pair_coefficients"] = pair.coefficients
        metadata["frozen_pair_metric_eigenvalues"] = pair.metric_eigenvalues
        for spin in ops.allowed_spins
            projected = SY.project_total_spin(ops, psi, spin)
            projected.present && frozen_row("spin_$(spin)", projected.state;
                                             retained_weight=projected.retained_weight)
        end
        Stage1.write_rows(joinpath(output, "frozen_comparison.csv"), frozen)

        problem = CPAFQMCProblem(inputs.plus.kinetic, 12.0, 3, 3; lattice_size=2, cell_count=4)
        scans, histories = NamedTuple[], NamedTuple[]
        best = Dict{String,Any}()
        for field in metadata["field_magnitudes"]
            trial = one_body_trial(problem; pattern=:altermagnetic, field_strength=field)
            bare = SJ.onsite_jastrow_state(H, trial)
            candidates = [(family=family, vector=bare, weight=1.0)
                          for family in ("bare", "single_jastrow")]
            opposite = SY.spin_reverse(ops, bare)
            for parity in (-1, 1)
                vector = (bare + parity * opposite) / 2
                weight = sum(abs2, vector)
                weight > 1.0e-12 && push!(candidates,
                    (family="flip_$(parity)", vector=vector / sqrt(weight), weight=weight))
            end
            for spin in ops.allowed_spins
                projected = SY.project_total_spin(ops, bare, spin)
                projected.present && push!(candidates,
                    (family="spin_$(spin)", vector=projected.state, weight=projected.retained_weight))
            end
            for candidate in candidates
                make_state = jastrow_on_vector(H, candidate.vector)
                fit = candidate.family == "bare" ?
                    (g=0.0, energy=dot(bare, H * bare), state=bare, boundary_hit=false,
                     history=[(g=0.0, energy=dot(bare, H * bare))]) : optimize_g(H, make_state)
                for step in fit.history
                    push!(histories, merge((family=candidate.family, field=field), step))
                end
                result = evaluate(H, ops, ground, fit.state)
                row = merge((family=candidate.family, field=field, g=fit.g,
                    uncorrelated_projection_weight=candidate.weight,
                    field_boundary_hit=field == maximum(metadata["field_magnitudes"]),
                    g_boundary_hit=fit.boundary_hit), result)
                push!(scans, row)
                if !haskey(best, candidate.family) || fit.energy < best[candidate.family].row.energy
                    best[candidate.family] = (row=row, state=fit.state, trial=trial)
                end
            end
            println("Finished field magnitude $field")
            flush(stdout)
        end
        Stage1.write_rows(joinpath(output, "field_scan.csv"), scans)
        Stage1.write_rows(joinpath(output, "g_search_history.csv"), histories)
        selected = [best[key].row for key in sort!(collect(keys(best)))]
        Stage1.write_rows(joinpath(output, "optimized_comparison.csv"), selected)
        for key in keys(best)
            entry = best[key]
            save_state("optimized_" * key, entry.state;
                       details=(stage="energy_refitted", field=entry.row.field, g=entry.row.g,
                                family=key, trial=entry.trial))
        end
        metadata["lowest_variational_family"] = selected[argmin(getproperty.(selected, :energy))].family
        metadata["status"] = "complete"
        metadata["finished_utc"] = string(now(UTC))
        save_metadata()
        println("Completed exact symmetry diagnostic: $output")
        return (frozen=frozen, optimized=selected, ground_spins=metadata["ground_spins"])
    catch exception
        metadata["status"] = "failed"
        metadata["failure"] = sprint(showerror, exception)
        metadata["finished_utc"] = string(now(UTC))
        save_metadata()
        rethrow()
    end
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        println("Usage: julia --project=. scripts/run_slater_jastrow_stage2.jl [--output-dir=NEW_DIR] [--stage1-dir=DIR]")
        return
    end
    previous_threads = BLAS.get_num_threads()
    try
        BLAS.set_num_threads(2)
        run_study(options)
    finally
        BLAS.set_num_threads(previous_threads)
    end
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    RunSlaterJastrowStage2.main()
end
