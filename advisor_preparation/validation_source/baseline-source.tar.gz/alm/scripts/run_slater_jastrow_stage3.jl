#!/usr/bin/env julia

module RunSlaterJastrowStage3

using AltermagnetDQMCTrial
using Dates
using LinearAlgebra
using Serialization
using SHA
using Statistics
using TOML

include(joinpath(@__DIR__, "run_slater_jastrow_stage2.jl"))
const Stage2 = RunSlaterJastrowStage2
const Stage1 = Stage2.Stage1
const SlaterJastrowTrials = Stage2.SJ
include(joinpath(@__DIR__, "correlated_trial_afqmc.jl"))
const CA = CorrelatedTrialAFQMC
const SJ = SlaterJastrowTrials
const ED = SJ.ED

function parse_options(arguments)
    any(arg -> arg in ("--help", "-h"), arguments) && return nothing
    raw = Dict{String,String}()
    for arg in arguments
        startswith(arg, "--") || throw(ArgumentError("use --name=value"))
        pieces = split(arg[3:end], '='; limit=2)
        length(pieces) == 2 || throw(ArgumentError("use --name=value"))
        key, value = pieces
        key in ("output-dir", "stage2-dir", "profile", "resume") ||
            throw(ArgumentError("unknown option: $key"))
        haskey(raw, key) && throw(ArgumentError("duplicate option: $key"))
        isempty(value) && throw(ArgumentError("empty option: $key"))
        raw[key] = value
    end
    profile = get(raw, "profile", "quick")
    profile in ("pilot", "quick", "extended", "projection", "population", "sampling", "ed_sampling") ||
        throw(ArgumentError("unknown profile"))
    resume = get(raw, "resume", "false")
    resume in ("true", "false") || throw(ArgumentError("resume must be true or false"))
    return (output_dir=abspath(get(raw, "output-dir", "results/slater_jastrow_stage3")),
            stage2_dir=abspath(get(raw, "stage2-dir", "results/slater_jastrow_stage2_20260911_v1")),
            profile=profile, resume=resume == "true")
end

function validation_plan(profile)
    profile in ("pilot", "quick", "extended", "projection", "population", "sampling", "ed_sampling") ||
        throw(ArgumentError("unknown profile"))
    jobs = NamedTuple[]
    function add(family, seed, dtau, walkers, warmup, measurements, spacing, bp; tag="base")
        push!(jobs, (id="$(tag)_$(family)_dt$(dtau)_seed$(seed)", family=family,
            seed=seed, dtau=dtau, walkers=walkers, warmup_time=warmup,
            measurements=measurements, spacing=spacing, bp_time=bp, block_size=4))
    end
    if profile == "pilot"
        for family in ("bare", "single_jastrow", "spin_0")
            add(family, 61411, 0.04, 16, 0.8, 8, 0.08, 0.32; tag="pilot")
        end
    elseif profile == "projection"
        for warmup in (32.0, 64.0), seed in (61411, 61412, 61413),
            family in ("bare", "spin_0")
            add(family, seed, 0.02, 64, warmup, 24, 0.08, 0.8;
                tag="projection_tau$(warmup)")
        end
    elseif profile == "population"
        for walkers in (64, 128), seed in (61411, 61412, 61413)
            add("spin_0", seed, 0.02, walkers, 64.0, 96, 0.08, 0.8;
                tag="population_W$(walkers)")
        end
    elseif profile in ("sampling", "ed_sampling")
        family = profile == "ed_sampling" ? "ed_control" : "spin_0"
        for initializer in ("common", "weak_field"), seed in (91421, 91422, 91423)
            add(family, seed, 0.02, 128, 64.0, 384, 0.08, 0.8;
                tag="$(profile)_$(initializer)")
            jobs[end] = merge(jobs[end], (initializer=initializer,))
        end
    else
        for dtau in (0.04, 0.02), seed in (61411, 61412, 61413),
            family in ("bare", "single_jastrow", "spin_0")
            add(family, seed, dtau, 64, 4.0, 24, 0.08, 0.8)
        end
        add("ed_control", 61411, 0.02, 32, 2.0, 12, 0.08, 0.4; tag="algebraic")
        if profile == "extended"
            for seed in (61411, 61412, 61413), family in ("bare", "spin_0")
                add(family, seed, 0.02, 128, 8.0, 40, 0.08, 1.6; tag="longer")
            end
        end
    end
    return jobs
end

function parameters(job)
    steps(time) = begin
        value = round(Int, time / job.dtau)
        isapprox(value * job.dtau, time; atol=1e-12, rtol=1e-12) ||
            throw(ArgumentError("time is not commensurate with dtau"))
        value
    end
    return CPAFQMCParameters(dtau=job.dtau, walker_count=job.walkers,
        warmup_steps=steps(job.warmup_time), measurement_count=job.measurements,
        steps_between_measurements=steps(job.spacing), back_propagation_steps=steps(job.bp_time),
        minimum_backprop_ancestors=2, orthogonalize_every=5, population_control_every=5,
        overlap_refresh_every=16, error_block_size=job.block_size, seed=job.seed)
end

function exact_transition(H, left, right, diagonals)
    terms = left .* right
    overlap = sum(terms)
    scale = sum(abs, terms)
    isfinite(overlap) && abs(overlap) > 1e-12 * scale && scale > 0 ||
        error("exact reference has a zero or cancellation-dominated overlap")
    return merge((energy=dot(left, H * right) / overlap,),
                 map(values -> dot(terms, values) / overlap, diagonals))
end

"""Unconstrained deterministic finite-time Trotter reference, not an ED fit."""
function finite_time_reference(H, oracle, initializer, params)
    right = CA.determinant_amplitudes(H, initializer.up, initializer.down)
    right ./= norm(right)
    potential = exp.(-params.dtau .* H.U .* (H.double_occupancies .-
        (H.basis.Nup + H.basis.Ndown) / 2 .+ H.basis.nmodes / 4))
    function propagate(vector)
        next = CA.apply_kinetic_to_vector(oracle, vector)
        next .*= potential
        next = CA.apply_kinetic_to_vector(oracle, next)
        return next ./ norm(next)
    end
    left = copy(oracle.trial)
    for _ in 1:params.back_propagation_steps
        left = propagate(left)
    end
    history = [copy(right)]
    diagonals = SJ.diagonal_observables(H; Lx=oracle.Lx, Ly=oracle.Ly)
    records = NamedTuple[]
    total = params.warmup_steps + params.measurement_count * params.steps_between_measurements
    for step in 1:total
        right = propagate(right)
        push!(history, right)
        length(history) > params.back_propagation_steps + 1 && popfirst!(history)
        if step > params.warmup_steps &&
           (step - params.warmup_steps) % params.steps_between_measurements == 0
            length(history) == params.back_propagation_steps + 1 ||
                error("finite-time reference lacks its anchor")
            push!(records, (step=step,
                mixed=exact_transition(H, oracle.trial, right, diagonals),
                backpropagated=exact_transition(H, left, first(history), diagonals)))
        end
    end
    return records
end

function load_inputs(directory)
    metadata = TOML.parsefile(joinpath(directory, "metadata.toml"))
    get(metadata, "status", "") == "complete" || error("stage2 is incomplete")
    hashes = TOML.parsefile(joinpath(directory, "source_hashes.toml"))
    for (path, hash) in hashes
        isabspath(path) && error("snapshot path must be relative")
        ".." in splitpath(path) && error("invalid snapshot path")
        bytes2hex(sha256(read(joinpath(directory, "source_snapshot", path)))) == hash ||
            error("stage2 checksum mismatch: $path")
    end
    H = SJ.benchmark_hamiltonian(ED.open_cluster_kinetic_matrix(2, 2), 12.0, 3, 3)
    inputs, input_hashes = Dict{String,Any}(), Dict{String,String}()
    for family in ("bare", "single_jastrow", "spin_0", "ed_control")
        name = family == "ed_control" ? "ed_ground_1" : "optimized_" * family
        path = joinpath(directory, "states", name * ".jls")
        input = deserialize(path)
        input.format == "spin-projected-enumerated-oracle-v1" && !input.afqmc_compatible ||
            error("unsupported stage2 payload")
        input.kinetic == H.kinetic && input.U == H.U && input.Nup == input.Ndown == 3 &&
            input.Lx == input.Ly == 2 && input.boundary == :open || error("stage2 model mismatch")
        input.up_basis == H.basis.up_states && input.down_basis == H.basis.down_states ||
            error("stage2 basis mismatch")
        input.source_hashes == hashes || error("stage2 payload source mismatch")
        isapprox(norm(input.state), 1; atol=1e-12, rtol=0) || error("input trial is not normalized")
        if family != "ed_control"
            check = SJ.onsite_jastrow_state(H, input.details.trial; g=input.details.g)
            if family == "spin_0"
                check = Stage2.SY.project_total_spin(Stage2.SY.spin_operators(H), check, 0).state
            end
            min(norm(check - input.state), norm(check + input.state)) <= 1e-10 ||
                error("trial reconstruction failed for $family")
        end
        inputs[family] = input
        input_hashes[family] = bytes2hex(sha256(read(path)))
    end
    return (H=H, inputs=inputs, hashes=input_hashes,
            initializer=inputs["spin_0"].details.trial)
end

function job_initializer(inputs, job)
    name = hasproperty(job, :initializer) ? job.initializer : "common"
    name == "common" && return inputs.initializer
    name == "weak_field" || throw(ArgumentError("unknown starting determinant: $name"))
    H = inputs.H
    size(H.kinetic, 1) == 8 || throw(ArgumentError("weak-field initializer requires the 2x2 benchmark"))
    problem = CPAFQMCProblem(H.kinetic, H.U, H.basis.Nup, H.basis.Ndown;
                            lattice_size=2, cell_count=4)
    return one_body_trial(problem; pattern=:altermagnetic, field_strength=1.0)
end

function source_paths()
    return ("scripts/correlated_trial_afqmc.jl", "scripts/run_slater_jastrow_stage3.jl",
            "test/correlated_trial_afqmc_tests.jl", "test/run_slater_jastrow_stage3_tests.jl")
end

function save_sources(output)
    hashes = Stage2.save_sources(output)
    for path in source_paths()
        source = joinpath(dirname(@__DIR__), path)
        destination = joinpath(output, "source_snapshot", path)
        mkpath(dirname(destination))
        cp(source, destination)
        hashes[path] = bytes2hex(sha256(read(source)))
    end
    open(joinpath(output, "source_hashes.toml"), "w") do io
        TOML.print(io, hashes; sorted=true)
    end
    return hashes
end

function atomic_serialize(path, object)
    temporary = path * ".partial"
    open(temporary, "w") do io
        serialize(io, object)
        flush(io)
    end
    mv(temporary, path; force=true)
end

function atomic_toml(path, object)
    temporary = path * ".partial"
    open(temporary, "w") do io
        TOML.print(io, object; sorted=true)
        flush(io)
    end
    mv(temporary, path; force=true)
end

function measurement_row(job, index, observed, reference, state)
    mixed, bp = observed.mixed, observed.backpropagated
    isnothing(bp) && error("this study requires back propagation")
    row = (job_id=job.id, measurement=index, step=observed.step,
        projection_time=observed.step * job.dtau, bp_time=job.bp_time,
        distinct_ancestors=observed.distinct_backprop_ancestors,
        constraint_rejections=state.base.constraint_rejections,
        killed_walkers=state.base.killed_walkers,
        overlap_evaluations=observed.metadata.overlap_evaluations,
        numerical_failures=observed.metadata.numerical_failures,
        numerical_overlap_failures=observed.metadata.numerical_overlap_failures,
        minimum_overlap_fraction=observed.metadata.minimum_overlap_fraction)
    for (prefix, sampled, exact) in (("mixed", mixed, reference.mixed),
                                    ("bp", bp, reference.backpropagated))
        for quantity in (:energy, :delta_alm, :m_alm_squared, :double_occupancy_total,
                         :odd_q0, :odd_qx, :odd_qy, :odd_qxy)
            key = Symbol(prefix * "_" * string(quantity))
            exact_key = Symbol("reference_" * string(key))
            row = merge(row, NamedTuple{(key, exact_key)}((getproperty(sampled, quantity),
                                                       getproperty(exact, quantity))))
        end
    end
    return row
end

function block_sensitivity(job, rows)
    results = NamedTuple[]
    for block_size in (1, 2, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192)
        length(rows) % block_size == 0 && length(rows) >= 2block_size || continue
        for key in (:mixed_energy, :bp_energy, :bp_delta_alm, :bp_m_alm_squared)
            stats = blocked_statistics([getproperty(row, key) for row in rows], block_size)
            push!(results, (job_id=job.id, quantity=string(key), block_size=block_size,
                            mean=stats.mean, error=stats.error, blocks=stats.blocks))
        end
    end
    return results
end

function blocked_statistics(values, block_size)
    count = length(values)
    block_size isa Integer && !(block_size isa Bool) && block_size > 0 ||
        throw(ArgumentError("block_size must be positive"))
    count % block_size == 0 && count >= 2block_size ||
        throw(ArgumentError("at least two complete blocks are required"))
    all(isfinite, values) || throw(ArgumentError("samples must be finite"))
    blocks = vec(mean(reshape(Float64.(values), block_size, :); dims=1))
    return (mean=mean(values), error=std(blocks) / sqrt(length(blocks)), blocks=length(blocks))
end

function summarize(job, rows, ground)
    summaries = NamedTuple[]
    for prefix in ("mixed", "bp"), quantity in (:energy, :delta_alm, :m_alm_squared,
        :double_occupancy_total, :odd_q0, :odd_qx, :odd_qy, :odd_qxy)
        key = Symbol(prefix * "_" * string(quantity))
        reference_key = Symbol("reference_" * string(key))
        values = [getproperty(row, key) for row in rows]
        references = [getproperty(row, reference_key) for row in rows]
        stats = blocked_statistics(values, job.block_size)
        difference = blocked_statistics(values .- references, job.block_size)
        ed = quantity == :energy ? ground.energy : getproperty(ground.means, quantity)
        summary = (job_id=job.id, family=job.family, dtau=job.dtau, seed=job.seed,
            walkers=job.walkers, warmup_time=job.warmup_time, bp_time=job.bp_time,
            estimator=prefix, quantity=string(quantity), mean=stats.mean, error=stats.error,
            blocks=stats.blocks, exact_finite_time_mean=mean(references),
            finite_time_reference_drift=last(references) - first(references),
            difference_from_finite_time=difference.mean,
            difference_error=difference.error, ed=ed, difference_from_ed=stats.mean - ed,
            minimum_ancestors=minimum(getproperty.(rows, :distinct_ancestors)))
        hasproperty(job, :initializer) && (summary = merge(summary, (initializer=job.initializer,)))
        push!(summaries, summary)
    end
    return summaries
end

function aggregate_seeds(summaries)
    if !isempty(summaries)
        explicit_initializer = hasproperty(first(summaries), :initializer)
        all(row -> hasproperty(row, :initializer) == explicit_initializer, summaries) ||
            error("cannot mix implicit and explicit starting-determinant summaries")
    end
    groups = Dict{Tuple,Vector{Any}}()
    for row in summaries
        key = (row.family, row.dtau, row.walkers, row.warmup_time, row.bp_time,
               row.estimator, row.quantity,
               hasproperty(row, :initializer) ? row.initializer : "common")
        push!(get!(groups, key, Any[]), row)
    end
    output = NamedTuple[]
    for key in sort!(collect(keys(groups)))
        rows = groups[key]
        length(unique(row.seed for row in rows)) == length(rows) || error("duplicate seed in group")
        means = [row.mean for row in rows]
        within_error = sqrt(sum(row.error^2 for row in rows)) / length(rows)
        between_error = length(rows) > 1 ? std(means) / sqrt(length(rows)) : NaN
        combined = (family=key[1], dtau=key[2], walkers=key[3], warmup_time=key[4],
            bp_time=key[5], estimator=key[6], quantity=key[7], seeds=length(rows),
            mean=mean(means), within_seed_error=within_error, between_seed_error=between_error,
            ed=first(rows).ed, difference_from_ed=mean(means) - first(rows).ed,
            exact_finite_time_mean=mean(row.exact_finite_time_mean for row in rows),
            minimum_ancestors=minimum(row.minimum_ancestors for row in rows))
        hasproperty(first(rows), :initializer) && (combined = merge(combined, (initializer=key[8],)))
        push!(output, combined)
    end
    return output
end

function validate_checkpoint(checkpoint, job, inputs, source_hashes)
    checkpoint.format == "correlated-afqmc-stage3-checkpoint-v1" &&
        checkpoint.job == job && checkpoint.source_hashes == source_hashes &&
        checkpoint.input_hashes == inputs.hashes || error("checkpoint provenance mismatch")
    state, rows = checkpoint.state, checkpoint.rows
    params = parameters(job)
    state.base.parameters == params || error("checkpoint parameters mismatch")
    if hasproperty(job, :initializer)
        initializer = job_initializer(inputs, job)
        # The base state retains the starting orbitals, even after walkers evolve.
        for spin in (:up, :down)
            stored, expected = getproperty(state.base.trial, spin), getproperty(initializer, spin)
            size(stored) == size(expected) &&
                isapprox(stored, expected; atol=1e-12, rtol=1e-12) ||
                error("checkpoint starting determinant mismatch")
        end
    end
    state.oracle.H.kinetic == inputs.H.kinetic && state.oracle.H.U == inputs.H.U &&
        state.oracle.H.basis.Nup == inputs.H.basis.Nup &&
        state.oracle.H.basis.Ndown == inputs.H.basis.Ndown || error("checkpoint model mismatch")
    expected = inputs.inputs[job.family].state
    min(norm(state.oracle.trial - expected), norm(state.oracle.trial + expected)) <= 1e-12 ||
        error("checkpoint trial mismatch")
    state.numerical_failures == state.numerical_overlap_failures == 0 ||
        error("cannot resume a state with a recorded numerical failure")
    0 <= length(rows) <= params.measurement_count || error("invalid checkpoint measurement count")
    for (index, row) in enumerate(rows)
        row.measurement == index && row.job_id == job.id &&
            row.step == params.warmup_steps + index * params.steps_between_measurements ||
            error("checkpoint rows are not a complete measurement prefix")
    end
    if isempty(rows)
        0 <= state.base.step <= params.warmup_steps || error("invalid warmup checkpoint step")
    else
        state.base.step == params.warmup_steps + length(rows) * params.steps_between_measurements ||
            error("checkpoint step and measurements disagree")
    end
    return nothing
end

function run_job(job, output, inputs, source_hashes)
    directory = joinpath(output, "jobs", job.id)
    mkpath(directory)
    checkpoint_path = joinpath(directory, "checkpoint.jls")
    params = parameters(job)
    initializer = job_initializer(inputs, job)
    if isfile(checkpoint_path)
        checkpoint = deserialize(checkpoint_path)
        validate_checkpoint(checkpoint, job, inputs, source_hashes)
        state, rows = checkpoint.state, checkpoint.rows
    else
        state = CA.initialize_correlated_afqmc(inputs.H, params;
            trial_state=inputs.inputs[job.family].state, initializer=initializer, Lx=2, Ly=2)
        rows = NamedTuple[]
    end
    save_checkpoint() = atomic_serialize(checkpoint_path,
        (format="correlated-afqmc-stage3-checkpoint-v1", job=job, state=state, rows=rows,
         source_hashes=source_hashes, input_hashes=inputs.hashes))
    reference = finite_time_reference(inputs.H, state.oracle, initializer, params)
    while state.base.step < params.warmup_steps
        CA.step_correlated_afqmc!(state)
        state.base.step % 20 == 0 && save_checkpoint()
    end
    save_checkpoint()
    while length(rows) < params.measurement_count
        index = length(rows) + 1
        target = params.warmup_steps + index * params.steps_between_measurements
        while state.base.step < target
            CA.step_correlated_afqmc!(state)
        end
        state.base.step == target || error("checkpoint step and measurement count disagree")
        observed = CA.measure_correlated_afqmc(state)
        push!(rows, measurement_row(job, index, observed, reference[index], state))
        save_checkpoint()
    end
    Stage1.write_rows(joinpath(directory, "measurements.csv"), rows)
    Stage1.write_rows(joinpath(directory, "block_sensitivity.csv"), block_sensitivity(job, rows))
    return rows
end

function run_study(options)
    if ispath(options.output_dir)
        options.resume && isdir(options.output_dir) ||
            throw(ArgumentError("output exists; explicit --resume=true is required"))
    else
        options.resume && throw(ArgumentError("cannot resume a missing output"))
    end
    inputs = load_inputs(options.stage2_dir)
    jobs = validation_plan(options.profile)
    if options.resume
        metadata = TOML.parsefile(joinpath(options.output_dir, "metadata.toml"))
        check_resume_status(metadata)
        metadata["profile"] == options.profile && metadata["stage2_dir"] == options.stage2_dir &&
            metadata["input_hashes"] == inputs.hashes || error("resume settings mismatch")
        hashes = TOML.parsefile(joinpath(options.output_dir, "source_hashes.toml"))
        for (path, hash) in hashes
            bytes2hex(sha256(read(joinpath(dirname(@__DIR__), path)))) == hash ||
                error("current source changed; cannot resume: $path")
            bytes2hex(sha256(read(joinpath(options.output_dir, "source_snapshot", path)))) == hash ||
                error("snapshot checksum mismatch: $path")
        end
    else
        mkpath(options.output_dir)
        hashes = save_sources(options.output_dir)
        metadata = Dict{String,Any}("started_utc" => string(now(UTC)),
            "profile" => options.profile, "stage2_dir" => options.stage2_dir,
            "input_hashes" => inputs.hashes, "julia_version" => string(VERSION),
            "scope" => "bounded exact-Fock correlated-trial constrained-path AFQMC validation",
            "production_campaign_changed" => false, "production_solver_changed" => false,
            "trial_coefficients_truncated" => false, "maximum_spatial_modes" => 8,
            "backpropagation" => "ordinary CP-BP; retains constraint and finite-length bias",
            "finite_reference" => "unconstrained symmetric Trotter projection at matching times",
            "ground_state_convergence_established" => false,
            "systematic_error_eliminated" => false, "completed_jobs" => String[])
        Stage1.write_rows(joinpath(options.output_dir, "plan.csv"), jobs)
    end
    metadata["status"] = "running"
    save_metadata() = atomic_toml(joinpath(options.output_dir, "metadata.toml"), metadata)
    save_metadata()
    try
        ground = Stage1.exact_ground_space(inputs.H)
        control = inputs.inputs["ed_control"].state
        norm(inputs.H * control - ground.energy * control) <= 1e-10 ||
            error("saved ED trial fails the independently recomputed ground energy")
        Stage1.write_rows(joinpath(options.output_dir, "ed_reference.csv"), [merge(
            (energy=ground.energy, rank=ground.rank, gap=ground.gap, residual=ground.residual),
            ground.means)])
        summaries = NamedTuple[]
        for (index, job) in enumerate(jobs)
            println("[$index/$(length(jobs))] $(job.id)")
            flush(stdout)
            rows = run_job(job, options.output_dir, inputs, hashes)
            append!(summaries, summarize(job, rows, ground))
            Stage1.write_rows(joinpath(options.output_dir, "summary.csv"), summaries)
            if !(job.id in metadata["completed_jobs"])
                push!(metadata["completed_jobs"], job.id)
            end
            save_metadata()
        end
        Stage1.write_rows(joinpath(options.output_dir, "seed_summary.csv"), aggregate_seeds(summaries))
        metadata["status"] = "complete"
        pop!(metadata, "last_error", nothing)
        metadata["finished_utc"] = string(now(UTC))
        save_metadata()
        return summaries
    catch exception
        metadata["status"] = exception isa InterruptException ? "interrupted" : "failed"
        metadata["last_error"] = sprint(showerror, exception)
        save_metadata()
        rethrow()
    end
end

function check_resume_status(metadata)
    get(metadata, "status", "") in ("running", "interrupted", "complete") ||
        throw(ArgumentError("this run failed; inspect the error and use a fresh output after correcting it"))
    return nothing
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        println("Usage: julia --project=. scripts/run_slater_jastrow_stage3.jl [--profile=pilot|quick|extended|projection|population|sampling|ed_sampling] [--output-dir=DIR] [--stage2-dir=DIR] [--resume=true|false]")
        return
    end
    previous = BLAS.get_num_threads()
    try
        BLAS.set_num_threads(2)
        run_study(options)
    finally
        BLAS.set_num_threads(previous)
    end
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    RunSlaterJastrowStage3.main()
end
