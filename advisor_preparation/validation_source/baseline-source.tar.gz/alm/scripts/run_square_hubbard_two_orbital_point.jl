#!/usr/bin/env julia

# Execute one isolated two-orbital DQMC point from an immutable snapshot of
# square_hubbard_two_orbital.jl. The beta-sweep driver supplies all overrides
# through an allowlisted set of environment variables and consumes the
# structured files written here; the human-readable tutorial output is kept in
# stdout.log only.

using Dates
using SHA

const PARAMETER_ENV = (
    (:U, "DQMC_U", Float64),
    (:μ, "DQMC_MU", Float64),
    (:density_tuning, "DQMC_DENSITY_TUNING", Bool),
    (:target_density, "DQMC_TARGET_DENSITY", Float64),
    (:minimum_tuning_average_sign, "DQMC_MIN_TUNING_SIGN", Float64),
    (:β, "DQMC_BETA", Float64),
    (:L, "DQMC_L", Int),
    (:Δτ, "DQMC_DTAU", Float64),
    (:n_stab, "DQMC_N_STAB", Int),
    (:N_burnin, "DQMC_N_BURNIN", Int),
    (:N_measurements, "DQMC_N_MEASUREMENTS", Int),
    (:N_sweeps, "DQMC_N_SWEEPS", Int),
    (:N_bins, "DQMC_N_BINS", Int),
    (:seed, "DQMC_SEED", Int),
)

required_env(key::AbstractString) = haskey(ENV, key) ? ENV[key] :
    error("required environment variable $key is not set")

function parse_bool(value::AbstractString)
    normalized = lowercase(strip(value))
    normalized in ("true", "1", "yes") && return true
    normalized in ("false", "0", "no") && return false
    error("cannot parse Boolean value: $value")
end

parse_value(::Type{Bool}, value::AbstractString) = parse_bool(value)
parse_value(::Type{T}, value::AbstractString) where {T} = parse(T, strip(value))

function csv_escape(value)
    text = value === nothing ? "" : string(value)
    occursin(r"[,\"\n\r]", text) || return text
    return "\"" * replace(text, "\"" => "\"\"") * "\""
end

function write_table(path::AbstractString, rows::AbstractVector{<:NamedTuple})
    isempty(rows) && return nothing
    columns = propertynames(first(rows))
    open(path, "w") do io
        println(io, join(string.(columns), ','))
        for row in rows
            println(io, join((csv_escape(getproperty(row, column)) for column in columns), ','))
        end
    end
    return nothing
end

function write_key_values(path::AbstractString, row::NamedTuple)
    open(path, "w") do io
        for column in propertynames(row)
            value = replace(string(getproperty(row, column)), '\n' => ' ', '\r' => ' ')
            println(io, column, '=', value)
        end
    end
    return nothing
end

function write_tuning_profile(path::AbstractString, tuner)
    isnothing(tuner) && return nothing
    isempty(tuner.profile) && return nothing
    write_table(path, tuner.profile)
    return nothing
end

function write_error(path::AbstractString, err, backtrace)
    open(path, "w") do io
        showerror(io, err, backtrace)
        println(io)
    end
    return nothing
end

source_snapshot = abspath(required_env("DQMC_SOURCE_SNAPSHOT"))
original_source = abspath(required_env("DQMC_ORIGINAL_SOURCE"))
output_dir = abspath(required_env("DQMC_OUTPUT_DIR"))
run_phase = required_env("DQMC_RUN_PHASE")
run_label = required_env("DQMC_RUN_LABEL")

isfile(source_snapshot) || error("source snapshot does not exist: $source_snapshot")
mkpath(output_dir)
source = read(source_snapshot, String)
source_sha256 = bytes2hex(sha256(source))

overrides = Dict{Symbol,Any}()
for (symbol, key, value_type) in PARAMETER_ENV
    raw = required_env(key)
    pattern = Regex("(?m)^" * string(symbol) * raw"\s*=")
    count = length(collect(eachmatch(pattern, source)))
    count == 1 || error(
        "expected exactly one top-level assignment for $symbol in the snapshot, found $count",
    )
    overrides[symbol] = parse_value(value_type, raw)
end

mapped_counts = Dict(symbol => 0 for symbol in keys(overrides))
function map_top_level(expression)
    if expression isa Expr && expression.head === :(=)
        lhs = expression.args[1]
        if lhs isa Symbol && haskey(overrides, lhs)
            mapped_counts[lhs] += 1
            return Expr(:(=), lhs, overrides[lhs])
        end
    elseif expression isa Expr && expression.head === :toplevel
        return Expr(:toplevel, map(map_top_level, expression.args)...)
    end
    return expression
end

run_scope = Module(gensym(:TwoOrbitalDQMCPoint))
try
    Base.include_string(map_top_level, run_scope, source, original_source)
    for symbol in keys(overrides)
        mapped_counts[symbol] == 1 || error(
            "override mapper replaced $(mapped_counts[symbol]) assignments for $symbol instead of one",
        )
    end
catch err
    if isdefined(run_scope, :density_tuner)
        write_tuning_profile(
            joinpath(output_dir, "density_tuning_profile_partial.csv"),
            getproperty(run_scope, :density_tuner),
        )
    end
    write_error(joinpath(output_dir, "error.txt"), err, catch_backtrace())
    write(joinpath(output_dir, "attempt_status.txt"), "FAILED\n")
    rethrow()
end

value(symbol::Symbol) = getproperty(run_scope, symbol)
real_float(x) = Float64(real(x))

tuner = value(:density_tuner)
final_tuning = isnothing(tuner) ? nothing : last(tuner.profile)
sign_mean = real_float(value(:sign_avg))
sign_error = Float64(value(:sign_std))
density_mean = real_float(value(:density_avg))
density_error = Float64(value(:density_std))
target = Float64(value(:target_density))
initial_mu = Float64(overrides[:μ])
final_mu = Float64(value(:μ))
sign_magnitude = abs(sign_mean)

summary = (
    schema_version=1,
    run_label=run_label,
    phase=run_phase,
    status="COMPLETE",
    timestamp_utc=Dates.format(Dates.now(Dates.UTC), dateformat"yyyy-mm-ddTHH:MM:SS") * "Z",
    source_sha256=source_sha256,
    julia_version=string(VERSION),
    t1=Float64(value(:model_parameters).t1),
    t2=Float64(value(:model_parameters).t2),
    t3=Float64(value(:model_parameters).t3),
    t4=Float64(value(:model_parameters).t4),
    U=Float64(value(:U)),
    L=Int(value(:L)),
    number_of_cells=Int(value(:N_cells)),
    single_spin_dimension=Int(value(:N)),
    beta=Float64(value(:β)),
    dtau=Float64(value(:Δτ)),
    time_slices=Int(value(:Lτ)),
    target_density=target,
    density_tuning=Bool(value(:density_tuning)),
    initial_mu=initial_mu,
    final_instantaneous_mu=final_mu,
    newest_half_mean_mu=isnothing(final_tuning) ? final_mu : Float64(final_tuning.mean_mu),
    newest_half_mean_density=isnothing(final_tuning) ? density_mean : Float64(final_tuning.mean_density),
    tuning_steps=isnothing(tuner) ? 0 : Int(tuner.steps),
    tuning_window_average_sign=isnothing(final_tuning) ? sign_mean : Float64(final_tuning.average_sign),
    tuning_kappa=isnothing(final_tuning) ? NaN : Float64(final_tuning.kappa),
    minimum_tuning_average_sign=Float64(value(:minimum_tuning_average_sign)),
    stabilization_period=Int(value(:n_stab)),
    burnin_sweeps=Int(value(:N_burnin)),
    measurements=Int(value(:N_measurements)),
    sweeps_between_measurements=Int(value(:N_sweeps)),
    bins=Int(value(:N_bins)),
    measurements_per_bin=Int(value(:N_binsize)),
    seed=Int(value(:seed)),
    acceptance_rate=Float64(value(:acceptance_rate)),
    largest_greens_error=Float64(value(:δG)),
    runtime_seconds=Float64(value(:runtime)),
    average_sign=sign_mean,
    average_sign_magnitude=sign_magnitude,
    average_sign_standard_error=sign_error,
    sign_lower_2se=max(0.0, sign_magnitude - 2sign_error),
    sign_upper_2se=min(1.0, sign_magnitude + 2sign_error),
    total_density=density_mean,
    total_density_standard_error=density_error,
    density_target_difference=density_mean - target,
    density_compatible_2se=abs(density_mean - target) <= 2density_error,
    doping=Float64(value(:doping_avg)),
    doping_standard_error=density_error / 4,
    orbital_x_density=real_float(value(:density_x_avg)),
    orbital_x_density_standard_error=Float64(value(:density_x_std)),
    orbital_y_density=real_float(value(:density_y_avg)),
    orbital_y_density_standard_error=Float64(value(:density_y_std)),
    orbital_x_double_occupancy=real_float(value(:double_x_avg)),
    orbital_x_double_occupancy_standard_error=Float64(value(:double_x_std)),
    orbital_y_double_occupancy=real_float(value(:double_y_avg)),
    orbital_y_double_occupancy_standard_error=Float64(value(:double_y_std)),
)

bins = [(
    bin=index,
    measurements=Int(value(:N_binsize)),
    average_sign=Float64(value(:avg_sign)[index]),
    signed_total_density=real_float(value(:total_density)[index]),
    signed_orbital_x_density=real_float(value(:orbital_x_density)[index]),
    signed_orbital_y_density=real_float(value(:orbital_y_density)[index]),
    signed_orbital_x_double_occupancy=real_float(value(:double_occupancy_x)[index]),
    signed_orbital_y_double_occupancy=real_float(value(:double_occupancy_y)[index]),
) for index in eachindex(value(:avg_sign))]

write_table(joinpath(output_dir, "summary.csv"), [summary])
write_key_values(joinpath(output_dir, "summary.txt"), summary)
write_table(joinpath(output_dir, "bins.csv"), bins)
write_tuning_profile(joinpath(output_dir, "density_tuning_profile.csv"), tuner)
write(joinpath(output_dir, "source_sha256.txt"), source_sha256 * "\n")
write(joinpath(output_dir, "attempt_status.txt"), "COMPLETE\n")

