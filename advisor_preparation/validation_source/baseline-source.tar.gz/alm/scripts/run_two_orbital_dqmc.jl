using AltermagnetDQMCTrial
using LinearAlgebra: BLAS

# Keep small dense runs predictable on laptops. This does not change the
# Monte Carlo algorithm or the number of DQMC sweeps.
BLAS.set_num_threads(1)

# Edit this block for your run. These deliberately small defaults are a
# software demonstration, not a reproduction of the paper's phase diagram.
parameters = DQMCParameters(
    L=3,
    beta=1.0,
    dtau=0.1,
    U=2.0,
    mu=-1.897,
    stabilization_period=5,
    burnin_sweeps=20,
    measurement_sweeps=50,
    sweeps_between_measurements=1,
    seed=20250817,
)

summary = run_dqmc_smoke(
    parameters;
    case_name="two_orbital_paper_model",
)

println("Two-orbital DQMC run complete")
for name in propertynames(summary)
    println(rpad(string(name), 34), " = ", getproperty(summary, name))
end
