#!/usr/bin/env bash

# Restartable U=0, L=4 full-hopping spectral benchmark for the standalone PC.
# It is designed to be launched by Windows Task Scheduler through wsl.exe.

set -Eeuo pipefail

WORKDIR=/mnt/c/Users/YQW/DQMCStandalone
OUT=benchmark_data/u0_full_hopping_L4_beta10_n1.42
PAYLOAD="$OUT/u0_L4_beta10_n1.42.jls"
JULIA=/home/yqw/.juliaup/bin/julia
MU=-2.1694621270886527

cd "$WORKDIR"
mkdir -p "$OUT"
exec >> "$OUT/task.log" 2>&1

finish() {
    local status=$?
    trap - EXIT
    echo "WINDOWS_TASK_FINISHED=$(date -Iseconds)"
    echo "WINDOWS_TASK_EXIT_STATUS=$status"
    exit "$status"
}
trap finish EXIT

echo "WINDOWS_TASK_STARTED=$(date -Iseconds)"
echo "U=0 full-hopping spectral benchmark: beta=10, L=4, n=1.42"
echo "Exact finite-grid chemical potential: mu=$MU"

if [[ ! -f "$PAYLOAD" ]]; then
    "$JULIA" --project=. \
        square_hubbard_two_orbital_observables.jl \
        0 10 "$MU" 4 1.42 \
        --u0-check \
        --measure-greens \
        --greens-every=50 \
        --seed=1001 \
        --output="$PAYLOAD"
else
    echo "Reusing completed payload: $PAYLOAD"
fi

"$JULIA" --project=. \
    plot_u0_l4_spectral_benchmark.jl \
    "$PAYLOAD" \
    "$OUT/u0_L4_spectral_benchmark.png"

echo "U0_L4_SPECTRAL_BENCHMARK_COMPLETE"
