#!/usr/bin/env julia
module PRL101237004Fig3ReferenceGrid

using LinearAlgebra, SHA, TOML, Dates
include("run_prl_101_237004_fig3.jl")
const P=PRL101237004Fig3Run
const D=P.D
const S=D.S

function run(;input=joinpath(D.OUTPUT,"refined"),output=joinpath(D.OUTPUT,"comparison"),
             source=joinpath(D.ROOT,"results","prl_101_237004","fig3_reference","fig3d_color_cells.csv"))
    BLAS.set_num_threads(1)
    isfile(joinpath(input,"completed.toml")) || error("primary production must be complete")
    destination=joinpath(output,"fermi_source_grid_predictions.csv")
    isfile(destination) && error("source-grid prediction exists")
    sourcehash=D.filehash(source)
    cases=D.scalar_csv(source)
    length(cases)==3600 || error("expected native60x60 source color grid")
    config=TOML.parsefile(joinpath(input,"configuration.toml"))
    depth=config["spectral_block_steps"]
    loaded=P.load_spectral_case(D.CASES[2];input=D.INPUT,output=input,block_steps=depth)
    hashes=D.snapshot(joinpath(output,"grid_provenance"),vcat(P.SOURCES,["scripts/sample_prl_101_237004_fig3_reference_grid.jl"]))
    rows=Tuple[]
    for (registration,xkey,ykey) in (
        ("native_cell_centers","kx_over_pi_center","ky_over_pi_center"),
        ("uniform_cell_centers","kx_over_pi_uniform_center_inferred","ky_over_pi_uniform_center_inferred"),
        ("lower_left_corners","kx_over_pi_left","ky_over_pi_bottom"),
        ("lower_right_corners","kx_over_pi_right","ky_over_pi_bottom"),
        ("upper_left_corners","kx_over_pi_left","ky_over_pi_top"),
        ("upper_right_corners","kx_over_pi_right","ky_over_pi_top"))
        points=[(pi*D.number(row,xkey),pi*D.number(row,ykey)) for row in cases]
        intensity=zeros(length(points))
        for rotation in 0:3
            rotated=[rotation==0 ? (x,y) : rotation==1 ? (-y,x) : rotation==2 ? (-x,-y) : (y,-x) for (x,y) in points]
            values=S.spectral_grid(S.spectral_plan(loaded.problem,rotated),[0.];eta=.05).total
            intensity .+= vec(values)./4
        end
        append!(rows,[(registration,parse(Int,row["ix_0based"]),parse(Int,row["iy_0based"]),
            points[i]...,intensity[i]) for (i,row) in enumerate(cases)])
    end
    D.R.V.write_csv(destination,"registration,ix,iy,kx,ky,A_C4_states_per_Fe_per_energy",rows)
    D.filehash(source)==sourcehash || error("source grid changed during sampling")
    D.guard(hashes)
    D.write_toml(joinpath(output,"grid_provenance","completed.toml"),Dict(
        "completed_utc"=>string(now(UTC)),"source_grid_sha256"=>sourcehash,
        "prediction_sha256"=>D.filehash(destination),"spectral_block_steps"=>depth,
        "input_configuration_sha256"=>D.filehash(joinpath(input,"configuration.toml")),
        "primary_registration"=>"native_cell_centers","source_sha256"=>hashes,
        "limits"=>"Corner samples are predeclared registration checks, not optimized shifts. No amplitude fit; paper colorbar normalization and energy-window convention are unspecified."))
    println("Saved ",length(rows)," source-grid predictions across six declared registrations.")
end

end
if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Fig3ReferenceGrid.run()
end
