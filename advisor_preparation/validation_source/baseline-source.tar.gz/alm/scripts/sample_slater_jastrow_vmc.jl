#!/usr/bin/env julia

if !isdefined(@__MODULE__, :SlaterJastrowTrials)
    include(joinpath(@__DIR__, "slater_jastrow_trials.jl"))
end

module SlaterJastrowVMC

using LinearAlgebra
using Random
using Statistics
import ..SlaterJastrowTrials

const SJ = SlaterJastrowTrials

export sample_vmc

function _count(value::Integer, name::AbstractString; minimum::Int=1)
    value isa Bool && throw(ArgumentError("$name must be an integer, not Bool"))
    value >= minimum || throw(ArgumentError("$name must be at least $minimum"))
    return try
        Int(value)
    catch
        throw(ArgumentError("$name must fit in an Int"))
    end
end

function _blocked_error(values::Vector{Float64}, block_size::Int)
    blocks = reshape(values, block_size, :)
    block_means = vec(mean(blocks; dims=1))
    return std(block_means; corrected=true) / sqrt(length(block_means))
end

function _occupation_lists(states, nmodes)
    occupied = [[mode for mode in 1:nmodes if SJ.ED._occupied(state, mode)] for state in states]
    empty = [[mode for mode in 1:nmodes if !SJ.ED._occupied(state, mode)] for state in states]
    return (; occupied, empty)
end

function _exchange_candidate(rng, basis, current, occupations)
    down_count = length(basis.down_states)
    up_index = div(current - 1, down_count) + 1
    down_index = mod(current - 1, down_count) + 1
    up, down = SJ.ED._basis_state(basis, current)
    spin = rand(rng, 1:2)
    index = spin == 1 ? up_index : down_index
    occupied, empty = occupations[spin].occupied[index], occupations[spin].empty[index]
    (isempty(occupied) || isempty(empty)) && return current
    source, destination = rand(rng, occupied), rand(rng, empty)
    mask = (UInt64(1) << (source - 1)) | (UInt64(1) << (destination - 1))
    return spin == 1 ? SJ.ED._basis_index(basis, xor(up, mask), down) :
                      SJ.ED._basis_index(basis, up, xor(down, mask))
end

"""
    sample_vmc(H, psi; Lx, Ly, seed=20260911, warmup=1000,
               measurements=10000, steps_between=1, block_size=100,
               max_dimension=5000, proposal=:uniform, global_probability=0.1)

Check a real wavefunction by sampling its squared amplitudes in an enumerated
fixed-particle-number sector. This is a bounded small-cluster validation tool,
not a scalable production VMC implementation. `psi` need not be normalized.

Uniform proposals over the entire basis are symmetric and can connect separate
pieces of the wavefunction's nonzero support. Optional `proposal=:mixed` uses
global moves with probability `global_probability`, otherwise exchanging one
uniformly chosen occupied/empty mode in a uniformly chosen spin sector. The
fixed particle counts make those proposals symmetric; empty/full sectors give
self proposals. Strictly positive global probability preserves connectivity.
Uniform mode retains its original RNG sequence and reports global probability 1.
Each measurement follows exactly
`steps_between` proposals; a rejection retains the current state and therefore
can produce repeated samples. A private `Xoshiro(seed)` leaves the global RNG
unchanged. The starting state is the first largest-amplitude basis state.

`samples` holds basis indices, local energies, and diagonal observables. `means`
and `errors` hold their means and blocked standard errors (excluding indices).
Use at least two complete blocks; no samples are dropped. Blocking reduces
autocorrelation error but does not establish error convergence by itself.
`diagnostics` counts all proposals, including warmup and accepted self proposals.

`exact` records finite-sum checks, not an ED ground-state solution. With exact
wavefunction nodes, the variance of sampled local energies can miss nonzero
components of `H*psi` at those nodes. Its `node_variance_contribution` explicitly
reports this difference from the full quantum `energy_variance`.
"""
function sample_vmc(
    H::SJ.ED.SectorHamiltonian,
    psi::AbstractVector{<:Real};
    Lx::Integer,
    Ly::Integer,
    seed::Integer=20260911,
    warmup::Integer=1000,
    measurements::Integer=10000,
    steps_between::Integer=1,
    block_size::Integer=100,
    max_dimension::Integer=5000,
    proposal=:uniform,
    global_probability=0.1,
)
    proposal in (:uniform, :mixed) || throw(ArgumentError("proposal must be :uniform or :mixed"))
    global_probability isa Real && !(global_probability isa Bool) &&
        isfinite(global_probability) && 0 < global_probability <= 1 ||
        throw(ArgumentError("global_probability must be finite and in (0, 1]"))
    probability = Float64(global_probability)
    0 < probability <= 1 || throw(ArgumentError("global_probability is not representable in Float64"))
    limit = _count(max_dimension, "max_dimension")
    dimension = size(H, 1)
    dimension <= limit || throw(ArgumentError(
        "sector dimension $dimension exceeds max_dimension=$limit",
    ))
    length(psi) == dimension || throw(DimensionMismatch(
        "wavefunction length must match the sector dimension",
    ))
    nseed = _count(seed, "seed"; minimum=0)
    nwarmup = _count(warmup, "warmup"; minimum=0)
    nmeasurements = _count(measurements, "measurements")
    nbetween = _count(steps_between, "steps_between")
    nblock = _count(block_size, "block_size")
    nmeasurements % nblock == 0 || throw(ArgumentError(
        "measurements must be a multiple of block_size; samples are never dropped",
    ))
    nblocks = div(nmeasurements, nblock)
    nblocks >= 2 || throw(ArgumentError("at least two complete blocks are required"))
    nproposals = try
        Base.checked_add(nwarmup, Base.checked_mul(nmeasurements, nbetween))
    catch error
        error isa OverflowError || rethrow()
        throw(ArgumentError("total proposal count must fit in an Int"))
    end

    amplitudes = Float64.(psi)
    all(isfinite, amplitudes) || throw(ArgumentError("wavefunction must be finite"))
    scale = maximum(abs, amplitudes)
    scale > 0 || throw(ArgumentError("wavefunction must have nonzero norm"))
    amplitudes ./= scale
    amplitudes ./= norm(amplitudes)
    support = .!iszero.(amplitudes)
    any((.!iszero.(psi)) .& .!support) && throw(ArgumentError(
        "wavefunction normalization underflowed a nonzero amplitude",
    ))
    probabilities = abs2.(amplitudes)
    any(support .& iszero.(probabilities)) && throw(ArgumentError(
        "wavefunction squared amplitudes underflowed on the nonzero support",
    ))
    Hpsi = H * amplitudes
    all(isfinite, Hpsi) || throw(ArgumentError("Hamiltonian action must be finite"))
    local_energy = zeros(Float64, dimension)
    local_energy[support] .= Hpsi[support] ./ amplitudes[support]
    all(isfinite, local_energy) || throw(ArgumentError("local energies must be finite"))
    diagonal = SJ.diagonal_observables(H; Lx=Lx, Ly=Ly)
    all(values(diagonal)) do observable
        length(observable) == dimension && all(isfinite, observable)
    end || throw(ArgumentError("diagonal observables must be finite sector vectors"))
    observable_names = (:energy, keys(diagonal)...)
    observable_values = (local_energy, values(diagonal)...)

    exact_energy = dot(amplitudes, Hpsi)
    isfinite(exact_energy) || throw(ArgumentError("variational energy must be finite"))
    residual_squared = abs2.(Hpsi .- exact_energy .* amplitudes)
    all(isfinite, residual_squared) && isfinite(sum(residual_squared)) ||
        throw(ArgumentError("energy variance must be finite"))
    exact_means = NamedTuple{observable_names}(Tuple(
        dot(probabilities, values) for values in observable_values
    ))
    exact = (
        energy=exact_energy,
        energy_variance=sum(residual_squared),
        local_energy_variance=sum(residual_squared[support]),
        node_variance_contribution=sum(residual_squared[.!support]),
        means=exact_means,
    )

    log_weights = fill(-Inf, dimension)
    log_weights[support] .= 2 .* log.(abs.(amplitudes[support]))
    rng = Xoshiro(nseed)
    current = argmax(abs.(amplitudes))
    accepted = 0
    moves = 0
    node_proposals = 0
    global_proposals = 0
    exchange_proposals = 0
    occupations = proposal == :mixed ? (
        _occupation_lists(H.basis.up_states, H.basis.nmodes),
        _occupation_lists(H.basis.down_states, H.basis.nmodes),
    ) : nothing
    function propose!()
        candidate = if proposal == :uniform || rand(rng) < probability
            global_proposals += 1
            rand(rng, 1:dimension)
        else
            exchange_proposals += 1
            _exchange_candidate(rng, H.basis, current, occupations)
        end
        uniform = rand(rng)
        if !support[candidate]
            node_proposals += 1
            return
        end
        if log(uniform) < min(0.0, log_weights[candidate] - log_weights[current])
            accepted += 1
            moves += candidate != current
            current = candidate
        end
        return
    end

    for _ in 1:nwarmup
        propose!()
    end
    indices = Vector{Int}(undef, nmeasurements)
    measured = ntuple(_ -> Vector{Float64}(undef, nmeasurements), length(observable_names))
    for measurement in 1:nmeasurements
        for _ in 1:nbetween
            propose!()
        end
        indices[measurement] = current
        for observable in eachindex(observable_names)
            measured[observable][measurement] = observable_values[observable][current]
        end
    end
    samples = merge((state_indices=indices,), NamedTuple{observable_names}(measured))
    means = NamedTuple{observable_names}(map(mean, measured))
    errors = NamedTuple{observable_names}(map(values -> _blocked_error(values, nblock), measured))
    all(isfinite, means) && all(isfinite, errors) ||
        throw(ArgumentError("sample means and blocked errors must be finite"))
    diagnostics = (
        seed=nseed,
        warmup=nwarmup,
        measurements=nmeasurements,
        steps_between=nbetween,
        block_size=nblock,
        blocks=nblocks,
        proposal=proposal,
        global_probability=proposal == :uniform ? 1.0 : probability,
        dimension=dimension,
        support_count=count(support),
        node_count=count(.!support),
        proposals=nproposals,
        accepted=accepted,
        rejected=nproposals - accepted,
        moves=moves,
        node_proposals=node_proposals,
        global_proposals=global_proposals,
        exchange_proposals=exchange_proposals,
        acceptance_rate=accepted / nproposals,
        move_rate=moves / nproposals,
    )
    return (; samples, means, errors, diagnostics, exact)
end

end # module SlaterJastrowVMC
