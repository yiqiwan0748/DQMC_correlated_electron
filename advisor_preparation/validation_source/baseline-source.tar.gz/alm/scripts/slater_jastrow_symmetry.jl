#!/usr/bin/env julia

if !isdefined(@__MODULE__, :SlaterJastrowTrials)
    include(joinpath(@__DIR__, "slater_jastrow_trials.jl"))
end

module SlaterJastrowSymmetry

using LinearAlgebra
using SparseArrays
import ..SlaterJastrowTrials

const SJ = SlaterJastrowTrials

export spin_operators, spin_reverse, spin_diagnostics, project_total_spin,
       coherent_pair

"""
    spin_operators(H)

Build bounded, occupation-basis total-spin operators in an `Nup == Ndown`
sector. `raising` is S+ from this sector into `(Nup+1,Ndown-1)`, so
`s2 = raising' * raising` is S^2 at Sz=0. Both matrices are sparse. The
neighboring sector is checked against the same enumeration cap before allocation.

`flip_permutation` exchanges the two occupation bit patterns. `flip_sign`
is `(-1)^Nup`, the fermion reordering sign for the literal species swap
`F*c_up^dagger*F^-1 = c_down^dagger` and its inverse. Thus F^2=1, and F has
eigenvalue `(-1)^(Nup+S)` on total spin S at Sz=0. This convention differs
by a fixed phase from a pi spin rotation; F-even does not always mean singlet.

The operators do not assume that H commutes with spin. In particular, a
nonzero magnetic pinning field can break that symmetry.
"""
function spin_operators(H::SJ.ED.SectorHamiltonian)
    SJ._check_dimension(H)
    basis = H.basis
    basis.Nup == basis.Ndown || throw(ArgumentError(
        "spin symmetry oracle currently requires Nup == Ndown",
    ))
    modes, particles = basis.nmodes, basis.Nup
    dimension = length(basis)
    T = eltype(H)
    flip_permutation = Vector{Int}(undef, dimension)
    for index in 1:dimension
        up, down = SJ.ED._basis_state(basis, index)
        flip_permutation[index] = SJ.ED._basis_index(basis, down, up)
    end

    if particles == 0 || particles == modes
        raising = spzeros(T, 0, dimension)
    else
        neighbor_dimension = binomial(big(modes), particles + 1) *
                             binomial(big(modes), particles - 1)
        neighbor_dimension <= SJ.MAX_DIMENSION || throw(ArgumentError(
            "spin-raising sector dimension $neighbor_dimension exceeds $(SJ.MAX_DIMENSION)",
        ))
        neighbor = SJ.ED.sector_basis(modes, particles + 1, particles - 1)
        rows, columns, values = Int[], Int[], T[]
        for column in 1:dimension
            up, down = SJ.ED._basis_state(basis, column)
            for mode in 1:modes
                bit = UInt64(1) << (mode - 1)
                !iszero(down & bit) && iszero(up & bit) || continue
                # Down annihilation crosses the entire up block; up creation
                # then crosses just the occupied lower-index up modes.
                below = bit - UInt64(1)
                parity = particles + count_ones(down & below) + count_ones(up & below)
                row = SJ.ED._basis_index(neighbor, up | bit, xor(down, bit))
                push!(rows, row)
                push!(columns, column)
                push!(values, iseven(parity) ? one(T) : -one(T))
            end
        end
        raising = sparse(rows, columns, values, Int(neighbor_dimension), dimension)
    end
    s2 = sparse(transpose(raising) * raising)
    dropzeros!(s2)
    return (s2=s2, raising=raising, flip_permutation=flip_permutation,
            flip_sign=iseven(particles) ? 1 : -1,
            allowed_spins=0:min(particles, modes - particles),
            nmodes=modes, Nup=particles, Ndown=particles)
end

function _checked_state(ops, psi)
    psi isa AbstractVector{<:Real} || throw(ArgumentError("state must be a real vector"))
    length(psi) == size(ops.s2, 1) || throw(DimensionMismatch("state has wrong size"))
    all(isfinite, psi) || throw(ArgumentError("state must be finite"))
    return psi
end

function _normalized_state(ops, psi)
    _checked_state(ops, psi)
    scale = maximum(abs, psi)
    scale > 0 || throw(ArgumentError("state must be nonzero"))
    state = psi ./ scale
    state ./= norm(state)
    all(isfinite, state) || throw(ArgumentError("state cannot be normalized"))
    return state
end

"""Apply the signed species swap linearly, without normalizing or fixing phase."""
function spin_reverse(ops, psi)
    _checked_state(ops, psi)
    return ops.flip_sign .* psi[ops.flip_permutation]
end

"""Normalized expectations of S^2 and F, plus the quantum variance of S^2."""
function spin_diagnostics(ops, psi)
    state = _normalized_state(ops, psi)
    action = ops.s2 * state
    mean = dot(state, action)
    variance = sum(abs2, action .- mean .* state)
    return (s2_mean=mean, s2_variance=variance,
            spin_flip_expectation=dot(state, spin_reverse(ops, state)))
end

function _check_tolerance(value, name; allow_zero)
    value isa Real && !(value isa Bool) && isfinite(value) || throw(ArgumentError(
        "$name must be a finite real number",
    ))
    (allow_zero ? 0 <= value < 1 : 0 < value < 1) || throw(ArgumentError(
        "$name must lie in $(allow_zero ? "[0,1)" : "(0,1)")",
    ))
    return value
end

"""
    project_total_spin(ops, psi, S; support_tolerance=1e-12)

Apply the exact finite-sector polynomial projector onto S^2=S(S+1), with
floating-point arithmetic. All allowed integer spins enter the polynomial;
no ED eigenvectors or Hamiltonian energies enter it. Input is normalized first.

`retained_weight` is the projected probability, not amplitude. A weight at or
below `support_tolerance` returns `present=false,state=nothing`; otherwise the
returned state is normalized. The cutoff prevents amplifying roundoff from an
absent spin sector. It is not a physical approximation to an absent component.
"""
function project_total_spin(ops, psi, S; support_tolerance=1.0e-12)
    S isa Integer && !(S isa Bool) && S in ops.allowed_spins || throw(ArgumentError(
        "target spin must be an integer in $(ops.allowed_spins)",
    ))
    _check_tolerance(support_tolerance, "support_tolerance"; allow_zero=true)
    state = _normalized_state(ops, psi)
    target = S * (S + 1)
    for other in ops.allowed_spins
        other == S && continue
        eigenvalue = other * (other + 1)
        state = (ops.s2 * state .- eigenvalue .* state) ./ (target - eigenvalue)
    end
    weight = sum(abs2, state)
    isfinite(weight) || throw(ArgumentError("spin projection produced a nonfinite weight"))
    present = weight > support_tolerance
    return (state=present ? state ./ sqrt(weight) : nothing,
            retained_weight=weight, present=present, target_spin=Int(S))
end

"""
    coherent_pair(H, ops, psi; overlap_tolerance=1e-10)

Minimize energy in the coherent span of normalized `psi` and `F*psi`. This
combines amplitudes, not probabilities or measured order parameters. A 2-by-2
overlap eigensystem removes directions whose metric eigenvalue is at most
`overlap_tolerance` times the largest eigenvalue, avoiding a singular solve.

Returns the normalized state, its energy, retained rank, the two coefficients
relative to the normalized input pair, and both original metric eigenvalues.
The coefficient and state phase is fixed together by the largest state entry.
This pair can restore spin-swap parity, but generally does not fix total spin.
"""
function coherent_pair(H::SJ.ED.SectorHamiltonian, ops, psi;
                       overlap_tolerance=1.0e-10)
    SJ._check_dimension(H)
    size(H, 1) == size(ops.s2, 1) &&
        (H.basis.nmodes, H.basis.Nup, H.basis.Ndown) ==
        (ops.nmodes, ops.Nup, ops.Ndown) || throw(DimensionMismatch(
            "Hamiltonian and spin operators must use the same sector",
        ))
    _check_tolerance(overlap_tolerance, "overlap_tolerance"; allow_zero=false)
    state = _normalized_state(ops, psi)
    pair = hcat(state, spin_reverse(ops, state))
    metric = eigen(Symmetric(transpose(pair) * pair))
    keep = findall(value -> value > overlap_tolerance * maximum(metric.values),
                   metric.values)
    isempty(keep) && error("normalized pair unexpectedly has no retained direction")
    transform = metric.vectors[:, keep] * Diagonal(inv.(sqrt.(metric.values[keep])))
    orthogonal = pair * transform
    actions = hcat((H * view(orthogonal, :, column) for column in axes(orthogonal, 2))...)
    reduced = eigen(Symmetric(transpose(orthogonal) * actions))
    coefficients = transform * reduced.vectors[:, 1]
    optimized = pair * coefficients
    normalization = norm(optimized)
    optimized ./= normalization
    coefficients ./= normalization
    if optimized[argmax(abs.(optimized))] < 0
        optimized .*= -1
        coefficients .*= -1
    end
    energy = dot(optimized, H * optimized)
    isfinite(energy) || error("coherent pair produced a nonfinite energy")
    return (state=optimized, energy=energy, rank=length(keep),
            coefficients=coefficients, metric_eigenvalues=metric.values)
end

end # module
