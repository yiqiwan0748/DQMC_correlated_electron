#!/usr/bin/env julia

module SlaterJastrowTrials

using AltermagnetDQMCTrial: SlaterTrial
using LinearAlgebra

include(joinpath(@__DIR__, "two_orbital_open_cluster_ed.jl"))
const ED = TwoOrbitalOpenClusterED

export benchmark_hamiltonian, onsite_jastrow_state, diagonal_observables,
       variational_evaluation, optimize_onsite_jastrow, exact_trial_overlap

const MAX_DIMENSION = 5000

"""Build a bounded ED oracle with the same centered Hubbard interaction as AFQMC."""
function benchmark_hamiltonian(kinetic, U, Nup, Ndown; max_dimension=MAX_DIMENSION)
    max_dimension isa Integer && !(max_dimension isa Bool) && 0 < max_dimension <= MAX_DIMENSION ||
        throw(ArgumentError("max_dimension must be an integer in 1:$MAX_DIMENSION"))
    size(kinetic, 1) == size(kinetic, 2) || throw(DimensionMismatch("kinetic must be square"))
    modes = size(kinetic, 1)
    0 < modes <= 64 && iseven(modes) ||
        throw(ArgumentError("benchmark requires an even number of modes in 2:64"))
    all(isfinite, kinetic) || throw(ArgumentError("kinetic must be finite"))
    for count in (Nup, Ndown)
        count isa Integer && !(count isa Bool) && 0 <= count <= modes ||
            throw(ArgumentError("particle counts must be integers in 0:M"))
    end
    dimension = binomial(big(modes), Nup) * binomial(big(modes), Ndown)
    dimension <= max_dimension || throw(ArgumentError(
        "enumerated Jastrow benchmark dimension $dimension exceeds $max_dimension",
    ))
    return ED.sector_hamiltonian(kinetic, U, Nup, Ndown; h=0)
end

function _check_dimension(H)
    length(H.basis) <= MAX_DIMENSION || throw(ArgumentError(
        "this enumerated trial oracle is limited to $MAX_DIMENSION configurations",
    ))
end

function _slater_logs(H, trial::SlaterTrial)
    _check_dimension(H)
    basis = H.basis
    size(trial.up) == (basis.nmodes, basis.Nup) ||
        throw(DimensionMismatch("up orbitals do not match the sector"))
    size(trial.down) == (basis.nmodes, basis.Ndown) ||
        throw(DimensionMismatch("down orbitals do not match the sector"))
    all(isfinite, trial.up) && all(isfinite, trial.down) ||
        throw(ArgumentError("trial orbitals must be finite"))
    T = promote_type(eltype(H), eltype(trial.up))
    function spin_logs(states, orbitals)
        logs, signs = T[], T[]
        for state in states
            occupied = [mode for mode in 1:basis.nmodes if ED._occupied(state, mode)]
            magnitude, sign = isempty(occupied) ? (zero(T), one(T)) :
                logabsdet(orbitals[occupied, :])
            push!(logs, magnitude)
            push!(signs, sign)
        end
        return logs, signs
    end
    up_logs, up_signs = spin_logs(basis.up_states, trial.up)
    down_logs, down_signs = spin_logs(basis.down_states, trial.down)
    # ED uses all up creation operators before all down operators; down varies fastest.
    logs = [u + d for u in up_logs for d in down_logs]
    signs = [u * d for u in up_signs for d in down_signs]
    support = findall(!iszero, signs)
    isempty(support) && throw(ArgumentError("trial has zero support in this sector"))
    all(isfinite, logs[support]) || throw(ArgumentError("nonfinite determinant amplitude"))
    return (logs=logs, signs=signs, support=support,
            minimum_doubles=minimum(H.double_occupancies[support]))
end

function _onsite_state(H, cached, g)
    g isa Real && !(g isa Bool) && isfinite(g) && g >= 0 ||
        throw(ArgumentError("g must be finite and nonnegative"))
    # Subtract the smallest supported double count to keep large-g states representable.
    logarithms = cached.logs .- g .* (H.double_occupancies .- cached.minimum_doubles)
    shift = maximum(logarithms[cached.support])
    state = zeros(eltype(logarithms), length(logarithms))
    for index in cached.support
        state[index] = cached.signs[index] * exp(logarithms[index] - shift)
    end
    state ./= norm(state)
    all(isfinite, state) || throw(ArgumentError("Jastrow state cannot be normalized"))
    return state
end

"""
    onsite_jastrow_state(H, trial; g=0)

Enumerate the normalized real state exp(-g*sum_a n_a_up*n_a_down)|trial>.
This is a small-cluster oracle, not an AFQMC trial adapter or a scalable VMC
representation. The determinant's occupation-basis signs are retained.
"""
function onsite_jastrow_state(H, trial::SlaterTrial; g=0.0)
    return _onsite_state(H, _slater_logs(H, trial), g)
end

function _normalized_state(H, psi)
    _check_dimension(H)
    psi isa AbstractVector{<:Real} || throw(ArgumentError("state must be a real vector"))
    length(psi) == length(H.basis) || throw(DimensionMismatch("state has wrong size"))
    all(isfinite, psi) || throw(ArgumentError("state must be finite"))
    scale = maximum(abs, psi)
    scale > 0 || throw(ArgumentError("state must be nonzero"))
    vector = psi ./ scale
    return vector ./ norm(vector)
end

"""
Diagonal spin observables in the orbital-fast basis. The four fixed form
factors are q=(0,0),(pi,0),(0,pi),(pi,pi), even for open boundaries; they are
not crystal-momentum sectors on an open cluster. odd_q is |sum(Sxz-Syz)|^2/Nc.
"""
function diagonal_observables(H; Lx, Ly)
    _check_dimension(H)
    for extent in (Lx, Ly)
        extent isa Integer && !(extent isa Bool) && extent > 0 ||
            throw(ArgumentError("Lx and Ly must be positive integers"))
    end
    2big(Lx) * Ly == H.basis.nmodes || throw(DimensionMismatch("geometry does not match modes"))
    cells = Lx * Ly
    T = eltype(H)
    mx = zeros(T, length(H.basis))
    my = similar(mx)
    odd_q0, odd_qx, odd_qy, odd_qxy = (similar(mx) for _ in 1:4)
    for index in eachindex(mx)
        up, down = ED._basis_state(H.basis, index)
        sum_x = sum_y = zero(T)
        sums = zeros(T, 4)
        for cell in 1:cells
            m_x = Int(ED._occupied(up, 2cell - 1)) - Int(ED._occupied(down, 2cell - 1))
            m_y = Int(ED._occupied(up, 2cell)) - Int(ED._occupied(down, 2cell))
            sum_x += m_x
            sum_y += m_y
            x, y = mod(cell - 1, Lx), div(cell - 1, Lx)
            odd = (m_x - m_y) / 2
            sums .+= odd .* (1, iseven(x) ? 1 : -1, iseven(y) ? 1 : -1,
                             iseven(x + y) ? 1 : -1)
        end
        mx[index], my[index] = sum_x / cells, sum_y / cells
        odd_q0[index], odd_qx[index], odd_qy[index], odd_qxy[index] = abs2.(sums) ./ cells
    end
    delta = (mx .- my) ./ 2
    return (mx=mx, my=my, m_fm=(mx .+ my) ./ 2, delta_alm=delta,
            m_alm_squared=abs2.(delta), double_occupancy_total=copy(H.double_occupancies),
            odd_q0=odd_q0, odd_qx=odd_qx, odd_qy=odd_qy, odd_qxy=odd_qxy)
end

"""Exact finite-sum expectations in a supplied state, not the ED ground state."""
function variational_evaluation(H, psi; Lx, Ly)
    state = _normalized_state(H, psi)
    work = H * state
    energy = dot(state, work)
    energy_variance = sum(abs2, work .- energy .* state)
    diagonals = diagonal_observables(H; Lx=Lx, Ly=Ly)
    probabilities = abs2.(state)
    means = map(values -> dot(probabilities, values), diagonals)
    centered = H.U * (means.double_occupancy_total -
                     (H.basis.Nup + H.basis.Ndown) / 2 + H.basis.nmodes / 4)
    field_energy = -H.h * dot(probabilities, H.oalm_values)
    return merge((energy=energy, energy_variance=energy_variance,
                  kinetic_energy=energy - centered - field_energy,
                  centered_interaction_energy=centered, field_energy=field_energy), means)
end

"""
Minimize exact finite-sum energy over nonnegative g for a fixed determinant.
A coarse grid brackets candidate minima, then golden-section refinement is
applied to each. This bounded search is not a proof of global optimization.
No Monte Carlo noise, ED target energy, or magnetic observable enters the loss.
"""
function optimize_onsite_jastrow(H, trial::SlaterTrial;
                               g_bounds=(0.0, 6.0), g_tolerance=1.0e-6,
                               grid_points=25)
    length(g_bounds) == 2 || throw(ArgumentError("g_bounds needs two endpoints"))
    left, right = g_bounds
    all(x -> x isa Real && !(x isa Bool) && isfinite(x), (left, right, g_tolerance)) ||
        throw(ArgumentError("search bounds and tolerance must be finite real numbers"))
    0 <= left < right && g_tolerance > 0 || throw(ArgumentError("invalid g search interval"))
    g_tolerance >= 16eps(Float64) * max(1.0, abs(left), abs(right)) ||
        throw(ArgumentError("g_tolerance is below the search's Float64 resolution"))
    grid_points isa Integer && !(grid_points isa Bool) && grid_points >= 3 ||
        throw(ArgumentError("grid_points must be an integer >= 3"))
    cached = _slater_logs(H, trial)
    history = NamedTuple{(:g, :energy),Tuple{Float64,Float64}}[]
    function objective(g)
        state = _onsite_state(H, cached, g)
        energy = dot(state, H * state)
        isfinite(energy) || error("nonfinite variational energy")
        push!(history, (g=Float64(g), energy=Float64(energy)))
        return energy
    end
    grid = collect(range(Float64(left), Float64(right); length=grid_points))
    energies = objective.(grid)
    ratio = (sqrt(5.0) - 1) / 2
    for index in eachindex(grid)
        lo, hi = max(1, index - 1), min(length(grid), index + 1)
        energies[index] <= energies[lo] && energies[index] <= energies[hi] || continue
        # A flat objective needs no refinement; retain the earliest grid point.
        energies[lo] == energies[index] == energies[hi] && continue
        a, b = grid[lo], grid[hi]
        c, d = b - ratio * (b - a), a + ratio * (b - a)
        fc, fd = objective(c), objective(d)
        for _ in 1:256
            b - a <= g_tolerance && break
            if fc <= fd
                b, d, fd = d, c, fc
                c = b - ratio * (b - a)
                fc = objective(c)
            else
                a, c, fc = c, d, fd
                d = a + ratio * (b - a)
                fd = objective(d)
            end
        end
        b - a <= g_tolerance || error("g search did not reach its requested tolerance")
        objective((a + b) / 2)
    end
    best = history[argmin([row.energy for row in history])]
    state = _onsite_state(H, cached, best.g)
    return (g=best.g, energy=best.energy, state=state,
            boundary_hit=min(abs(best.g - left), abs(best.g - right)) <= g_tolerance,
            search_converged=true,
            evaluations=length(history), history=history,
            optimization="bounded exact finite-sum search for fixed determinant")
end

"""
Exact occupation-basis overlap with a canonical Slater walker, for validating
a future correlated-trial AFQMC implementation. Does not impose a constraint.
The supplied psi is not renormalized, so scaling it scales the overlap.
"""
function exact_trial_overlap(H, psi, walker::SlaterTrial)
    length(psi) == length(H.basis) || throw(DimensionMismatch("state has wrong size"))
    psi isa AbstractVector{<:Real} && all(isfinite, psi) ||
        throw(ArgumentError("state must be a finite real vector"))
    cached = _slater_logs(H, walker)
    bare = cached.signs .* exp.(cached.logs)
    return dot(psi, bare)
end

end # module
