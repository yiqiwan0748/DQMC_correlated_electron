# # Two-Orbital Square-Lattice Hubbard DQMC
#
# Adapted working copy of reference/square_hubbard.jl. The stabilized
# equal-time propagation and local Ising-field update algorithm are retained.
# The executable sections below use the published (d_xz,d_yz) hopping matrix,
# with one Hubbard field per cell-orbital. The original one-orbital correlation
# measurements are disabled because their hard-coded orbital-(1,1) operators
# are not complete observables for the two-orbital model.
#
# The following introductory prose documents the original tutorial; the
# adaptation is identified explicitly at each changed executable section.
# 
# This tutorial implements a determinant quantum Monte Carlo (DQMC) simulation from "scratch"
# using the [`JDQMCFramework.jl`](https://github.com/SmoQySuite/JDQMCFramework.jl.git) package, along with several others.
# The purpose of this tutorial is to empower researchers to write their own lightweight DQMC codes
# in order to address specific research needs that fall outside the scope of existing high-level
# DQMC packages like [`SmoQyDQMC.jl`](https://github.com/SmoQySuite/SmoQyDQMC.jl.git), and to enable
# rapid prototyping of algorithmic improvements to existing DQMC methods.
#
# This tutorial is relatively long as a lot goes into writing a full DQMC code.
# However, in spite of the length, each step is relatively straightforward.
# This is made possible by leveraging the functionality exported by
# [`JDQMCFramework.jl`](https://github.com/SmoQySuite/JDQMCFramework.jl.git) and other packages.
# For instance, the [`JDQMCFramework.jl`](https://github.com/SmoQySuite/JDQMCFramework.jl.git) package takes care of all the
# numerical stabilization nonsense that is one of the most challenging parts of writing a DQMC code.
# Also, implementing various correlation measurements in a DQMC simulation is typically very time consuming and challenging,
# as it requires working through arduous Wick's contractions, and then implementing each term.
# Once again, this hurdle is largely avoided by leveraging the functionality exported by the
# [`JDQMCMeasurements.jl`](https://github.com/SmoQySuite/JDQMCMeasurements.jl.git) package,
# which implements a variety of standard correlation function measurements for arbitrary lattice geometries.
#
# The repulsive Hubbard model Hamiltonian on a square lattice considered in this tutorial is given by
# ```math
# \hat{H} = -t \sum_{\sigma,\langle i,j\rangle} (\hat{c}^{\dagger}_{\sigma,i} \hat{c}^{\phantom \dagger}_{\sigma,j} + {\rm h.c.})
#   + U \sum_i (\hat{n}_{\uparrow,i}-\tfrac{1}{2})(\hat{n}_{\downarrow,i}-\tfrac{1}{2}) - \mu \sum_{\sigma,i} \hat{n}_{\sigma,i},
# ```
# where ``\hat{c}^\dagger_{\sigma,i} (\hat{c}^{\phantom \dagger}_{\sigma,i})`` creates (annihilates) a spin ``\sigma``
# electron on site ``i`` in the lattice, and ``\hat{n}_{\sigma,i} = \hat{c}^\dagger_{\sigma,i} \hat{c}^{\phantom \dagger}_{\sigma,i}``
# is the spin-``\sigma`` electron number operator for site ``i``. In the above Hamiltonian, ``t`` is the nearest neighbor hopping integral,
# ``\mu`` is the chemical potential, and ``U > 0`` controls the strength of the on-site Hubbard repulsion.
# Lastly, if ``\mu = 0.0,`` then the Hamiltonian is particle-hole symmetric, ensuring the system is half-filled ``(\langle n_\sigma \rangle = \tfrac{1}{2})``
# and that there is no sign problem. In the case of ``\mu \ne 0`` there will be a sign problem.
# For the published two-orbital hopping model, ``\mu=0`` does not by itself guarantee
# particle-hole symmetry, so this working copy always measures and reweights by the sign.
#
# Run this working copy from the repository root:
# ```
# julia --project=. scripts/square_hubbard_two_orbital.jl
# ```
#
# We begin by importing the relevant packages we will need to use in this example.
# Note that to run this tutorial you will need to install all the required Julia packages.
# However, this is straightforward as all the packages used in this tutorial are registered
# with the Julia [General](https://github.com/JuliaRegistries/General.git)
# package registry. This means they can all be easily installed with the Julia package manager
# using the `add` command in the same way that the [`JDQMCFramework.jl`](https://github.com/SmoQySuite/JDQMCFramework.jl.git)
# package is installed.

## Import relevant standard template libraries.
using Random
using LinearAlgebra

## Provides framework for implementing DQMC code.
import JDQMCFramework as jdqmcf

## Exports methods for measuring various correlation functions in a DQMC simulation.
import JDQMCMeasurements as jdqmcm

## Validated two-orbital hopping construction.
using AltermagnetDQMCTrial: ModelParameters, realspace_kinetic_matrix

# Keep dense linear algebra single-threaded for predictable small runs.
BLAS.set_num_threads(1)

# Now we define the relevant Hamiltonian parameter values that we want to simulate.
# The ``L=3`` and ``\beta=1`` defaults below are a quick smoke run; ``L=3`` is the
# smallest square torus that still exercises every published hopping channel.
# This tutorial includes many print statements so that when
# the tutorial is run users can keep track of what is going on. That said, for a DQMC code
# that will be used in actual research you will want to replace the print statements with code
# that writes relevant information and measurement results to file.

## Published two-orbital hopping parameters in units of t.
model_parameters = ModelParameters()
println("Hopping t1 = ", model_parameters.t1)
println("Hopping t2 = ", model_parameters.t2)
println("Hopping t3 = ", model_parameters.t3)
println("Hopping t4 = ", model_parameters.t4)

length(ARGS) == 4 || error(
    "Usage: julia --project=. scripts/square_hubbard_two_orbital.jl U beta initial_mu L",
)

## Hubbard interaction.
U = parse(Float64, ARGS[1])
println("Hubbard interaction, U = ", U)

## Initial chemical potential. This is the noninteracting upper-vHs energy anchor.
μ = parse(Float64, ARGS[3])
println("Initial chemical potential, mu = ", μ)

## Dynamically tune μ to the target density using Phys. Rev. E 105, 045311.
## With the small sampling counts below this is an experimental smoke run;
## freeze the tuned μ and rethermalize before collecting production data.
density_tuning = true
println("Dynamic density tuning enabled = ", density_tuning)

## Target particles per physical two-orbital cell (allowed range 0 to 4).
target_density = 1.42
println("Target density per cell = ", target_density)
println("Target doping, delta = (n-2)/4 = ", (target_density - 2) / 4)

## Characteristic energy u0 in the PRE compressibility scale alpha=N_cells/u0.
tuning_energy_scale = abs(model_parameters.t1)
println("Density-tuner characteristic energy = ", tuning_energy_scale)

## The PRE paper assumes sign-positive sampling. This real-sign DQMC adaptation
## stops instead of dividing by an unreliable newest-half sign denominator.
minimum_tuning_average_sign = 0.05
println("Minimum tuning-window average sign magnitude = ", minimum_tuning_average_sign)

## Inverse temperature.
β = parse(Float64, ARGS[2])
println("Inverse temperature, beta = ", β)

## Lattice size.
L = parse(Int, ARGS[4])
println("Linear lattice size, L = ", L)
#jl println()

# Next we define the relevant DQMC simulation parameters.

## Discretization in imaginary time.
Δτ = 0.05
println("Discretization in imaginary time, dtau = ", Δτ)

## Length of imaginary time axis.
time_slice_ratio = β / Δτ
Lτ = round(Int, time_slice_ratio)
time_slice_tolerance = 64eps(typeof(time_slice_ratio)) * max(1, abs(time_slice_ratio))
abs(time_slice_ratio - Lτ) <= time_slice_tolerance || error(
    "beta/dtau must be integral within tolerance $time_slice_tolerance",
)
println("Length of imaginary time axis, Ltau = ", Lτ)

## Use asymmetric propagators. Symmetric propagators require partial wrapping
## around orbital-resolved measurements, which this minimal working copy omits.
symmetric = false
symmetric && error("this working copy supports only symmetric=false")
println("Whether symmetric or asymmetric propagator matrices are used, symmetric = ", symmetric)

## Period with which numerical stabilization is performed i.e.
## how many imaginary time slices separate more expensive recomputation
## of the Green's function matrix using numerically stable routines.
n_stab = 5
println("Numerical stabilization period, n_stab = ", n_stab)

## The number of burnin sweeps through the lattice performing local updates that
## are performed to thermalize the system.
N_burnin = 20000
N_burnin >= 0 || error("N_burnin must be nonnegative")
println("Number of burnin sweeps, N_burnin = ", N_burnin)

## The number of measurements made once the system is thermalized.
N_measurements = 10000
N_measurements > 0 || error("N_measurements must be positive")
println("Number of measurements, N_measurements = ", N_measurements)

## Number of local update sweeps separating sequential measurements.
N_sweeps = 1
N_sweeps > 0 || error("N_sweeps must be positive")
println("Number of local update sweeps separating measurements, n_sweeps = ", N_sweeps)

## Number of bins used to performing a binning analysis when calculating final error bars
## for measured observables.
N_bins = 50
N_bins > 1 || error("N_bins must be greater than one for jackknife errors")
println("Number of measurement bins, N_bins = ", N_bins)

## Number of measurements averaged over per measurement bin.
N_measurements % N_bins == 0 || error("N_measurements must be divisible by N_bins")
N_binsize = N_measurements ÷ N_bins
println("Number of measurements per bin, N_binsize = ", N_binsize)
#jl println()

# Now we initialize the random number generator (RNG) that will be used in the rest of the simulation.

## Initialize random number generator.
seed = 20250817
rng = Xoshiro(seed)
println("Random seed used to initialize RNG, seed = ", seed)
#jl println()

## Two orbitals per physical cell, ordered (d_xz,d_yz).
N_cells = L^2
N = 2 * N_cells
println("Physical cells, N_cells = ", N_cells)
println("Single-particle dimension per spin, N = ", N)

# Now let us calculated the exponentiated electron kinetic energy matrix ``e^{-\Delta\tau^\prime K}``,
# where
# ```math
# \hat{K} = -t \sum_{\sigma,\langle i,j\rangle} (\hat{c}^{\dagger}_{\sigma,i} \hat{c}^{\phantom \dagger}_{\sigma,j} + {\rm h.c.})
#         = \sum_\sigma \hat{\mathbf{c}}^\dagger_\sigma K \hat{\mathbf{c}}^{\phantom\dagger}_\sigma
# ```
# and ``\hat{\mathbf{c}}^{\dagger}_{\sigma,i} = \left[ \hat{c}^{\dagger}_{\sigma,1} \ , \ \dots \ , \ \hat{c}^{\dagger}_{\sigma,N} \right]``
# is a row vector of electron creation operators.
# Note that if `symmetric = true`, i.e. the symmetric definition for the propagator matrices
# ```math
# B_{\sigma,l} = e^{-\Delta\tau^\prime K} \cdot e^{-\Delta\tau V_{\sigma,l}} \cdot e^{-\Delta\tau^\prime K}
# ```
# is being used, then ``\Delta\tau^\prime = \tfrac{1}{2} \Delta\tau``.
# If the asymmetric definition
# ```math
# B_{\sigma,l} = e^{-\Delta\tau V_{\sigma,l}} \cdot e^{-\Delta\tau^\prime K}
# ```
# is used (`symmetric = false`), then ``\Delta\tau^\prime = \Delta\tau.``
#
# This working copy calculates ``e^{-\Delta\tau^\prime K}`` exactly. The reference
# checkerboard breakup is one-orbital-specific and is therefore not used here.

## Define Δτ′=Δτ/2 if symmetric = true, otherwise Δτ′=Δτ
Δτ′ = symmetric ? Δτ/2 : Δτ

## Build the published bare hopping matrix; μ remains in the slice potential.
K = realspace_kinetic_matrix(L, model_parameters)
size(K) == (N, N) || error("unexpected two-orbital kinetic-matrix size")
issymmetric(K) || error("two-orbital kinetic matrix must be symmetric")

## Exact dense kinetic propagator and its inverse.
expnΔτ′K = exp(-Δτ′*K)
exppΔτ′K = exp(+Δτ′*K)

# In this example we are going to introduce an Ising Hubbard-Stratonovich (HS) field to decouple
# the Hubbard interaction. The Ising HS transformation
# ```math
# e^{-\Delta\tau U (\hat{n}_{\uparrow,i,l}-\tfrac{1}{2})(\hat{n}_{\downarrow,i,l}-\tfrac{1}{2})} = 
#   \frac{1}{2} e^{-\tfrac{1}{4} \Delta\tau U} \sum_{s_{i,l} = \pm 1} e^{\alpha s_{i,l}(\hat{n}_{\uparrow,i,l}-\hat{n}_{\downarrow,i,l})}
# ```
# is introduced for all imaginary time slices ``l \in [1, L_\tau]`` and sites ``i \in [1, N]`` in the lattice, where
# ```math
# \alpha = \cosh^{-1}\left( e^{\tfrac{1}{2}\Delta\tau U} \right)
# ```
# is a constant. We start the simulation from a random ``s_{i,l}`` Ising HS field configuration.

## Define constant associated Ising Hubbard-Stratonovich (HS) transformation.
α = acosh(exp(Δτ*U/2))

## Initialize a random Ising HS configuration.
s = rand(rng, -1:2:1, N, Lτ)
#md println("Random initial Ising HS configuration, s =")
#md show(stdout, "text/plain", s)
#nb println("Random initial Ising HS configuration, s =")
#nb show(stdout, "text/plain", s)

# Next we initialize a propagator matrix ``B_{\sigma,l}`` for each imaginary time slice ``l \in [1,L_\tau]``.
# The vectors `Bup` and `Bdn` contain the ``L_\tau`` exact propagators, with the
# symmetric or asymmetric form selected by `symmetric` above.

## Matrix element type for exponentiated electron kinetic energy matrix exp{-Δτ′⋅K}
T_expnΔτK = eltype(K)

## Matrix element type for diagonal exponentiated electron potential energy matrix exp{-Δτ⋅V[σ,l]}
T_expnΔτV = typeof(α)

## Initialize empty vector to contain propagator matrices for each imaginary time slice.
if symmetric
    Bup = jdqmcf.SymExactPropagator{T_expnΔτK, T_expnΔτV}[]
    Bdn = jdqmcf.SymExactPropagator{T_expnΔτK, T_expnΔτV}[]
else
    Bup = jdqmcf.AsymExactPropagator{T_expnΔτK, T_expnΔτV}[]
    Bdn = jdqmcf.AsymExactPropagator{T_expnΔτK, T_expnΔτV}[]
end;

# Having an initialized the vector `Bup` and `Bdn` that will contain the propagator matrices, we now construct the
# propagator matrices for each time-slice based on the initial HS field configuration `s`.

## Iterate over time-slices.
for l in 1:Lτ

    ## Get the HS fields associated with the current time-slice l.
    s_l = @view s[:,l]

    ## Calculate the spin-up diagonal exponentiated potential energy
    ## matrix exp{-Δτ⋅V[↑,l]} = exp{-Δτ⋅(-α/Δτ⋅s[i,l]-μ)} = exp{+α⋅s[i,l] + Δτ⋅μ}.
    expnΔτVup = zeros(T_expnΔτV, N)
    @. expnΔτVup = exp(+α * s_l + Δτ*μ)

    ## Calculate the spin-down diagonal exponentiated potential energy
    ## matrix exp{-Δτ⋅V[↓,l]} = exp{-Δτ⋅(+α/Δτ⋅s[i,l]-μ)} = exp{-α⋅s[i,l] + Δτ⋅μ}.
    expnΔτVdn = zeros(T_expnΔτV, N)
    @. expnΔτVdn = exp(-α * s_l + Δτ*μ)
    
    ## Initialize spin-up and spin-down propagator matrix for the current time-slice l.
    if symmetric
        push!(Bup, jdqmcf.SymExactPropagator(expnΔτVup, expnΔτ′K, exppΔτ′K))
        push!(Bdn, jdqmcf.SymExactPropagator(expnΔτVdn, expnΔτ′K, exppΔτ′K))
    else
        push!(Bup, jdqmcf.AsymExactPropagator(expnΔτVup, expnΔτ′K, exppΔτ′K))
        push!(Bdn, jdqmcf.AsymExactPropagator(expnΔτVdn, expnΔτ′K, exppΔτ′K))
    end
end

# Now we instantiate two instances for the [`FermionGreensCalculator`](@ref) type, one for each spin
# species, spin up and spin down. This object enables the efficient and numerically stable calculation
# of the Green's functions behind-the-scenes, so that we do not need to concern ourselves with
# implementing numerical stabilization routines ourselves.

## Initialize a FermionGreensCalculator for both spin up and down electrons.
fermion_greens_calc_up = jdqmcf.FermionGreensCalculator(Bup, β, Δτ, n_stab)
fermion_greens_calc_dn = jdqmcf.FermionGreensCalculator(Bdn, β, Δτ, n_stab);

# Next we calculate the equal-time Green's function matrices
# ```math
# G_\sigma(0,0) = [1 + B_\sigma(\beta,0)]^{-1} = [1 + B_{\sigma,L_\tau} \dots B_{\sigma,1}]^{-1}
# ```
# for both electron spin species, ``\sigma = (\uparrow, \downarrow).``

## Calculate spin-up equal-time Green's function matrix.
Gup = zeros(eltype(K), N, N)
logdetGup, sgndetGup = jdqmcf.calculate_equaltime_greens!(Gup, fermion_greens_calc_up)

## Calculate spin-down equal-time Green's function matrix.
Gdn = zeros(eltype(K), N, N)
logdetGdn, sgndetGdn = jdqmcf.calculate_equaltime_greens!(Gdn, fermion_greens_calc_dn);

# Equal-time, orbital-resolved scalar measurements.
avg_sign = zeros(eltype(Gup), N_bins)
total_density = zeros(eltype(Gup), N_bins)
orbital_x_density = zeros(eltype(Gup), N_bins)
orbital_y_density = zeros(eltype(Gup), N_bins)
double_occupancy_x = zeros(eltype(Gup), N_bins)
double_occupancy_y = zeros(eltype(Gup), N_bins)

# Below we implement a function that sweeps through all time-slices and sites in the lattice,
# attempting an update to each Ising HS field ``s_{i,l}``.

## Function to perform local updates to all Ising HS fields.
function local_update!(
    Gup::Matrix{T}, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
    Gdn::Matrix{T}, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
    s, μ, α, Δτ, δG, rng
) where {T<:Number}

    ## Length of imaginary time axis.
    Lτ = length(Bup)

    ## Number of sites in lattice.
    N = size(Gup,1)

    ## Allocate temporary arrays that will be used to avoid dynamic memory allocation.
    A = zeros(T, N, N)
    u = zeros(T, N)
    v = zeros(T, N)

    ## Allocate vector of integers to contain random permutation specifying the order in which
    ## sites are iterated over at each imaginary time slice when performing local updates.
    perm = collect(1:size(Gup,1))

    ## Variable to keep track of the acceptance rate.
    acceptance_rate = 0.0

    ## Iterate over imaginary time slices.
    for l in fermion_greens_calc_up

        ## Propagate equal-time Green's function matrix to current imaginary time
        ## G(τ±Δτ,τ±Δτ) ==> G(τ,τ) depending on whether iterating over imaginary
        ## time in the forward or reverse direction
        jdqmcf.propagate_equaltime_greens!(Gup, fermion_greens_calc_up, Bup)
        jdqmcf.propagate_equaltime_greens!(Gdn, fermion_greens_calc_dn, Bdn)

        ## If using symmetric propagator definition (symmetric = true), then apply
        ## the transformation G ==> G̃ = exp{+Δτ⋅K/2}⋅G⋅exp{-Δτ⋅K/2}.
        ## If asymmetric propagator definition is used (symmetric = false),
        ## then this does nothing.
        jdqmcf.partially_wrap_greens_reverse!(Gup, Bup[l], A)
        jdqmcf.partially_wrap_greens_reverse!(Gdn, Bdn[l], A)

        ## Get the HS fields associated with the current imaginary time-slice.
        s_l = @view s[:,l]

        ## Perform local updates HS fields associated with the current imaginary time slice.
        (logdetGup, sgndetGup, logdetGdn, sgndetGdn, acceptance_rate_l) = _local_update!(
            Gup, logdetGup, sgndetGup, Bup[l], Gdn, logdetGdn, sgndetGdn, Bdn[l],
            s_l, μ, α, Δτ, rng, perm, u, v
        )

        ## Record the acceptance rate
        acceptance_rate += acceptance_rate_l / Lτ

        ## If using symmetric propagator definition (symmetric = true), then apply
        ## the transformation G̃ ==> G = exp{-Δτ⋅K/2}⋅G̃⋅exp{+Δτ⋅K/2}.
        ## If asymmetric propagator definition is used (symmetric = false),
        ## then this does nothing.
        jdqmcf.partially_wrap_greens_forward!(Gup, Bup[l], A)
        jdqmcf.partially_wrap_greens_forward!(Gdn, Bdn[l], A)

        ## Periodically re-calculate the Green's function matrix for numerical stability.
        logdetGup, sgndetGup, δGup, δθup = jdqmcf.stabilize_equaltime_greens!(
            Gup, logdetGup, sgndetGup, fermion_greens_calc_up, Bup, update_B̄ = true
        )
        logdetGdn, sgndetGdn, δGdn, δθdn = jdqmcf.stabilize_equaltime_greens!(
            Gdn, logdetGdn, sgndetGdn, fermion_greens_calc_dn, Bdn, update_B̄ = true
        )

        ## Record largest numerical error corrected by numerical stabilization.
        δG = max(δG, δGup, δGdn)

        ## Keep up and down spin Green's functions synchronized as iterating over imaginary time.
        iterate(fermion_greens_calc_dn, fermion_greens_calc_up)
    end

    return logdetGup, sgndetGup, logdetGdn, sgndetGdn, δG, acceptance_rate
end

## Iterate over all sites for single imaginary time-slice, attempting a local
## update to each corresponding Ising HS field.
function _local_update!(
    Gup, logdetGup, sgndetGup, Bup, Gdn, logdetGdn, sgndetGdn, Bdn,
    s, μ, α, Δτ, rng, perm, u, v
)

    ## Randomize the order in which the sites are iterated over.
    shuffle!(rng, perm)

    ## Counter for number of accepted updates.
    accepted = 0

    ## Iterate over sites in lattice.
    for i in perm

        ## Calculate the change in the diagonal potential energy matrix element
        ## assuming the sign of the Ising HS field is changed.
        ΔVup = -α/Δτ * (-2*s[i])
        ΔVdn = +α/Δτ * (-2*s[i])

        ## Calculate the determinant ratio associated with the proposed update.
        Rup, Δup = jdqmcf.local_update_det_ratio(Gup, ΔVup, i, Δτ)
        Rdn, Δdn = jdqmcf.local_update_det_ratio(Gdn, ΔVdn, i, Δτ)

        ## Calculate the acceptance probability based on the Metropolis accept/reject criteria.
        P = min(1.0, abs(Rup * Rdn))

        ## Randomly Accept or reject the proposed update with the specified probability.
        if rand(rng) < P

            ## Increment the accepted update counter.
            accepted += 1

            ## Flip the appropriate Ising HS field.
            s[i] = -s[i]

            ## Update the Green's function matrices.
            logdetGup, sgndetGup = jdqmcf.local_update_greens!(
                Gup, logdetGup, sgndetGup, Bup, Rup, Δup, i, u, v
            )
            logdetGdn, sgndetGdn = jdqmcf.local_update_greens!(
                Gdn, logdetGdn, sgndetGdn, Bdn, Rdn, Δdn, i, u, v
            )
        end
    end

    ## Calculate the acceptance rate.
    acceptance_rate = accepted / length(perm)

    return logdetGup, sgndetGup, logdetGdn, sgndetGdn, acceptance_rate
end;

# Next we implement a function to make measurements during the simulation, including time-displaced measurements.
# Note that if we want to calculate the expectation value for some observable ``\langle \mathcal{O} \rangle``,
# then during the simulation we actually measure ``\langle \mathcal{S O} \rangle_{\mathcal{W}}``, where
# ``\langle \bullet \rangle_{\mathcal{W}}`` denotes an average with respect to states sampled according
# to the DQMC weights
# ```math
# \mathcal{W} = | \det G_\uparrow^{-1} \det G_\downarrow^{-1} |,
# ```
# such that
# ```math
# \mathcal{S} = \text{sign}(\det G_\uparrow^{-1} \det G_\downarrow^{-1})
# ```
# is the sign associated with each state. The reweighting method is then used at the end of a simulation
# to recover the correct expectation value according to
# ```math
# \langle \mathcal{O} \rangle = \frac{ \langle \mathcal{SO} \rangle_{\mathcal{W}} }{ \langle \mathcal{S} \rangle_{\mathcal{W}} },
# ```
# where ``\langle \mathcal{S} \rangle_{\mathcal{W}}`` is the average sign measured over the course of the simulation.

## Make measurements.
function make_measurements!(
    Gup, logdetGup, sgndetGup, Gup_ττ, Gup_τ0, Gup_0τ, Bup, fermion_greens_calc_up,
    Gdn, logdetGdn, sgndetGdn, Gdn_ττ, Gdn_τ0, Gdn_0τ, Bdn, fermion_greens_calc_dn,
    unit_cell, lattice, bond_trivial, bond_px, bond_nx, bond_py, bond_ny,
    bin, avg_sign, density, double_occ, C_greens, C_spinz, C_density,
    C_loc_swave, C_ext_swave, C_dwave
)


    ## Initialize time-displaced Green's function matrices for both spin species:
    ## G(τ=0,τ=0) = G(0,0)
    ## G(τ=0,0)   = G(0,0)
    ## G(0,τ=0)   = -(I-G(0,0))
    jdqmcf.initialize_unequaltime_greens!(Gup_τ0, Gup_0τ, Gup_ττ, Gup)
    jdqmcf.initialize_unequaltime_greens!(Gdn_τ0, Gdn_0τ, Gdn_ττ, Gdn)

    ## Calculate the current sign.
    sgn = sign(inv(sgndetGup) * inv(sgndetGdn))

    ## Measure the average sign.
    avg_sign[bin] += sgn

    ## Measure the density.
    nup = jdqmcm.measure_n(Gup)
    ndn = jdqmcm.measure_n(Gdn)
    density[bin] += sgn * (nup + ndn)

    ## Measure the double occupancy.
    double_occ[bin] += sgn * jdqmcm.measure_double_occ(Gup, Gdn)

    ## Measure equal-time correlation functions.
    make_correlation_measurements!(
        Gup, Gup_ττ, Gup_τ0, Gup_0τ, Gdn, Gdn_ττ, Gdn_τ0, Gdn_0τ,
        unit_cell, lattice, bond_trivial, bond_px, bond_nx, bond_py, bond_ny,
        bin, 0, sgn, C_greens, C_spinz, C_density, C_loc_swave, C_ext_swave, C_dwave
    )

    ## Iterate over imaginary time slices.
    for l in fermion_greens_calc_up

        ## Propagate equal-time Green's function matrix to current imaginary time
        ## G(τ±Δτ,τ±Δτ) ==> G(τ,τ) depending on whether iterating over imaginary
        ## time in the forward or reverse direction
        jdqmcf.propagate_unequaltime_greens!(Gup_τ0, Gup_0τ, Gup_ττ, fermion_greens_calc_up, Bup)
        jdqmcf.propagate_unequaltime_greens!(Gdn_τ0, Gdn_0τ, Gdn_ττ, fermion_greens_calc_dn, Bdn)

        ## Measure time-displaced correlation function measurements for τ = l⋅Δτ.
        make_correlation_measurements!(
            Gup, Gup_ττ, Gup_τ0, Gup_0τ, Gdn, Gdn_ττ, Gdn_τ0, Gdn_0τ,
            unit_cell, lattice, bond_trivial, bond_px, bond_nx, bond_py, bond_ny,
            bin, l, sgn, C_greens, C_spinz, C_density, C_loc_swave, C_ext_swave, C_dwave,
        )

        ## Periodically re-calculate the Green's function matrix for numerical stability.
        logdetGup, sgndetGup, δGup, δθup = jdqmcf.stabilize_unequaltime_greens!(
            Gup_τ0, Gup_0τ, Gup_ττ, logdetGup, sgndetGup, fermion_greens_calc_up, Bup, update_B̄=false
        )
        logdetGdn, sgndetGdn, δGdn, δθdn = jdqmcf.stabilize_unequaltime_greens!(
            Gdn_τ0, Gdn_0τ, Gdn_ττ, logdetGdn, sgndetGdn, fermion_greens_calc_dn, Bdn, update_B̄=false
        )

        ## Keep up and down spin Green's functions synchronized as iterating over imaginary time.
        iterate(fermion_greens_calc_dn, fermion_greens_calc_up)
    end

    return nothing
end

## Make time-displaced measurements.
function make_correlation_measurements!(
    Gup, Gup_ττ, Gup_τ0, Gup_0τ, Gdn, Gdn_ττ, Gdn_τ0, Gdn_0τ,
    unit_cell, lattice, bond_trivial, bond_px, bond_nx, bond_py, bond_ny,
    bin, l, sgn, C_greens, C_spinz, C_density, C_loc_swave, C_ext_swave, C_dwave,
    tmp = zeros(eltype(C_greens), lattice.L...)
)

    ## Get a view into the arrays accumulating the correlation measurements
    ## for the current imaginary time-slice and bin.
    C_greens_bin_l  = @view C_greens[bin,:,:,l+1]
    C_spinz_bin_l = @view C_spinz[bin,:,:,l+1]
    C_density_bin_l = @view C_density[bin,:,:,l+1]
    C_loc_swave_bin_l = @view C_loc_swave[bin,:,:,l+1]
    C_ext_swave_bin_l = @view C_ext_swave[bin,:,:,l+1]
    C_dwave_bin_l = @view C_dwave[bin,:,:,l+1]

    ## Measure Green's function for both spin-up and spin-down.
    jdqmcm.greens!(C_greens_bin_l, 1, 1, unit_cell, lattice, Gup_τ0, sgn)
    jdqmcm.greens!(C_greens_bin_l, 1, 1, unit_cell, lattice, Gdn_τ0, sgn)

    ## Measure spin-z spin-spin correlation.
    jdqmcm.spin_z_correlation!(
        C_spinz_bin_l, 1, 1, unit_cell, lattice,
        Gup_τ0, Gup_0τ, Gup_ττ, Gup, Gdn_τ0, Gdn_0τ, Gdn_ττ, Gdn, sgn
    )

    ## Measure density-density correlation.
    jdqmcm.density_correlation!(
        C_density_bin_l, 1, 1, unit_cell, lattice,
        Gup_τ0, Gup_0τ, Gup_ττ, Gup, Gdn_τ0, Gdn_0τ, Gdn_ττ, Gdn, sgn
    )

    ## Measure local s-wave correlation measurement.
    jdqmcm.pair_correlation!(
        C_loc_swave_bin_l, bond_trivial, bond_trivial, unit_cell, lattice, Gup_τ0, Gdn_τ0, sgn
    )

    ## Group the nearest-neighbor bonds together.
    bonds = (bond_px, bond_nx, bond_py, bond_ny)

    ## d-wave correlation phases.
    dwave_phases = (+1, +1, -1, -1)

    ## Iterate over all pairs of nearest-neigbbor bonds.
    for i in eachindex(bonds)
        for j in eachindex(bonds)
            ## Measure pair correlation associated with bond pair.
            fill!(tmp, 0)
            jdqmcm.pair_correlation!(
                tmp, bonds[i], bonds[j], unit_cell, lattice, Gup_τ0, Gdn_τ0, sgn
            )
            ## Add contribution to extended s-wave and d-wave pair correlation.
            @. C_ext_swave_bin_l += tmp / 4
            @. C_dwave_bin_l += dwave_phases[i] * dwave_phases[j] * tmp / 4
        end
    end

    return nothing
end;

## Measure sign, density, and intra-orbital double occupancy per physical cell.
function make_two_orbital_measurements!(
    Gup, sgndetGup, Gdn, sgndetGdn, L, bin,
    avg_sign, total_density, orbital_x_density, orbital_y_density,
    double_occupancy_x, double_occupancy_y,
)
    sgn = sign(sgndetGup * sgndetGdn)
    unit = one(eltype(Gup))
    density_x = zero(eltype(Gup))
    density_y = zero(eltype(Gup))
    double_x = zero(eltype(Gup))
    double_y = zero(eltype(Gup))

    for cell in 1:L^2
        index_x = 2 * cell - 1
        index_y = index_x + 1
        occupation_up_x = unit - Gup[index_x, index_x]
        occupation_down_x = unit - Gdn[index_x, index_x]
        occupation_up_y = unit - Gup[index_y, index_y]
        occupation_down_y = unit - Gdn[index_y, index_y]

        density_x += occupation_up_x + occupation_down_x
        density_y += occupation_up_y + occupation_down_y
        double_x += occupation_up_x * occupation_down_x
        double_y += occupation_up_y * occupation_down_y
    end

    inverse_cells = inv(convert(eltype(Gup), L^2))
    density_x *= inverse_cells
    density_y *= inverse_cells
    double_x *= inverse_cells
    double_y *= inverse_cells

    avg_sign[bin] += sgn
    total_density[bin] += sgn * (density_x + density_y)
    orbital_x_density[bin] += sgn * density_x
    orbital_y_density[bin] += sgn * density_y
    double_occupancy_x[bin] += sgn * double_x
    double_occupancy_y[bin] += sgn * double_y
    return nothing
end

# PRE Algorithm 1 state. All statistics use the newest half of the history.
mutable struct DynamicChemicalPotentialTuner{T<:AbstractFloat}
    target_density::T
    target_number::T
    beta::T
    compressibility_scale::T
    minimum_average_sign::T
    number_of_cells::Int
    steps::Int
    window_start::Int
    window_count::Int
    mean_mu::T
    m2_mu::T
    sign_sum::T
    signed_number_sum::T
    signed_number_squared_sum::T
    mu_samples::Vector{T}
    sign_samples::Vector{T}
    signed_number_samples::Vector{T}
    signed_number_squared_samples::Vector{T}
    profile::Vector{NamedTuple}
end

function DynamicChemicalPotentialTuner(;
    target_density::Real,
    beta::Real,
    number_of_cells::Integer,
    characteristic_energy::Real=1.0,
    minimum_average_sign::Real=0.05,
)
    density, inverse_temperature, energy_scale, sign_floor = promote(
        float(target_density),
        float(beta),
        float(characteristic_energy),
        float(minimum_average_sign),
    )
    T = typeof(density)
    cells = Int(number_of_cells)
    isfinite(density) && zero(T) <= density <= convert(T, 4) ||
        throw(ArgumentError("target_density must be finite and in [0,4]"))
    isfinite(inverse_temperature) && inverse_temperature > zero(T) ||
        throw(ArgumentError("beta must be finite and positive"))
    cells > 0 || throw(ArgumentError("number_of_cells must be positive"))
    isfinite(energy_scale) && energy_scale > zero(T) ||
        throw(ArgumentError("characteristic_energy must be finite and positive"))
    isfinite(sign_floor) && zero(T) <= sign_floor < one(T) ||
        throw(ArgumentError("minimum_average_sign must be in [0,1)"))

    return DynamicChemicalPotentialTuner{T}(
        density,
        density * convert(T, cells),
        inverse_temperature,
        convert(T, cells) / energy_scale,
        sign_floor,
        cells,
        0,
        1,
        0,
        zero(T),
        zero(T),
        zero(T),
        zero(T),
        zero(T),
        T[],
        T[],
        T[],
        T[],
        NamedTuple[],
    )
end

# Numerically stable Welford addition/removal for the newest-half μ window.
function _add_mu_sample!(tuner::DynamicChemicalPotentialTuner{T}, value::T) where {T}
    new_count = tuner.window_count + 1
    difference = value - tuner.mean_mu
    tuner.mean_mu += difference / new_count
    tuner.m2_mu += difference * (value - tuner.mean_mu)
    tuner.window_count = new_count
    return nothing
end

function _remove_mu_sample!(tuner::DynamicChemicalPotentialTuner{T}, value::T) where {T}
    old_count = tuner.window_count
    old_count > 0 || error("cannot remove a sample from an empty tuning window")
    if old_count == 1
        tuner.window_count = 0
        tuner.mean_mu = zero(T)
        tuner.m2_mu = zero(T)
        return nothing
    end

    new_count = old_count - 1
    old_mean = tuner.mean_mu
    new_mean = (old_count * old_mean - value) / new_count
    new_m2 = tuner.m2_mu - (value - old_mean) * (value - new_mean)
    tuner.window_count = new_count
    tuner.mean_mu = new_mean
    tuner.m2_mu = max(zero(T), new_m2)
    return nothing
end

# Add one QMC sample and return the next chemical potential from PRE Eqs. (2)-(8).
function record_density_tuning_step!(
    tuner::DynamicChemicalPotentialTuner{T},
    mu::Real,
    particle_number::Real,
    particle_number_squared::Real,
    configuration_sign::Real,
) where {T}
    mu_value = convert(T, mu)
    number_value = convert(T, particle_number)
    number_squared_value = convert(T, particle_number_squared)
    sign_value = convert(T, configuration_sign)
    all(isfinite, (mu_value, number_value, number_squared_value, sign_value)) ||
        error("density-tuning sample contains a non-finite value")
    abs(sign_value) == one(T) ||
        error("density tuning requires a real nonzero determinant sign")

    push!(tuner.mu_samples, mu_value)
    push!(tuner.sign_samples, sign_value)
    push!(tuner.signed_number_samples, sign_value * number_value)
    push!(
        tuner.signed_number_squared_samples,
        sign_value * number_squared_value,
    )
    tuner.steps += 1
    _add_mu_sample!(tuner, mu_value)
    tuner.sign_sum += sign_value
    tuner.signed_number_sum += sign_value * number_value
    tuner.signed_number_squared_sum += sign_value * number_squared_value

    # With zero-based paper index t, ceil(t/2)+1 becomes fld(steps,2)+1.
    desired_window_start = fld(tuner.steps, 2) + 1
    while tuner.window_start < desired_window_start
        index = tuner.window_start
        _remove_mu_sample!(tuner, tuner.mu_samples[index])
        tuner.sign_sum -= tuner.sign_samples[index]
        tuner.signed_number_sum -= tuner.signed_number_samples[index]
        tuner.signed_number_squared_sum -=
            tuner.signed_number_squared_samples[index]
        tuner.window_start += 1
    end

    iszero(tuner.sign_sum) && error(
        "density tuning stopped: newest-half sign denominator is zero",
    )
    average_sign = tuner.sign_sum / tuner.window_count
    abs(average_sign) >= tuner.minimum_average_sign || error(
        "density tuning stopped: newest-half average sign $(average_sign) " *
        "is below the configured threshold $(tuner.minimum_average_sign)",
    )

    mean_number = tuner.signed_number_sum / tuner.sign_sum
    mean_number_squared =
        tuner.signed_number_squared_sum / tuner.sign_sum
    raw_number_variance = mean_number_squared - mean_number^2
    variance_tolerance = 256eps(T) * max(
        one(T),
        abs(mean_number_squared),
        abs(mean_number)^2,
    )
    raw_number_variance >= -variance_tolerance || error(
        "density tuning stopped: sign-reweighted particle-number variance " *
        "is negative beyond roundoff",
    )
    number_variance = max(zero(T), raw_number_variance)
    mu_variance = max(zero(T), tuner.m2_mu / tuner.window_count)

    kappa_fluctuation = tuner.beta * number_variance
    kappa_minimum =
        tuner.compressibility_scale / sqrt(convert(T, tuner.steps))
    mu_variance_floor =
        eps(T) * max(one(T), abs(tuner.mean_mu)^2)
    kappa_maximum = if mu_variance > mu_variance_floor
        sqrt(number_variance / mu_variance)
    else
        convert(T, Inf)
    end
    kappa = max(
        kappa_minimum,
        min(kappa_maximum, kappa_fluctuation),
    )
    isfinite(kappa) && kappa > zero(T) ||
        error("density tuner produced an invalid compressibility")

    next_mu =
        tuner.mean_mu + (tuner.target_number - mean_number) / kappa
    isfinite(next_mu) ||
        error("density tuner produced a non-finite chemical potential")

    entry = (
        step=tuner.steps - 1,
        window_count=tuner.window_count,
        mu_used=mu_value,
        mean_mu=tuner.mean_mu,
        next_mu=next_mu,
        mean_density=mean_number / tuner.number_of_cells,
        number_variance=number_variance,
        average_sign=average_sign,
        kappa_fluctuation=kappa_fluctuation,
        kappa_minimum=kappa_minimum,
        kappa_maximum=kappa_maximum,
        kappa=kappa,
    )
    push!(tuner.profile, entry)
    return entry
end

# QMC estimators for <N> and <N^2> at fixed HS field.
# For each spin, Var(N | s) = tr(G - G^2), so the required PRE sample is
# N^(2) = N^2 + sum_sigma tr(G_sigma - G_sigma^2).
function total_particle_number_moments(
    Gup::AbstractMatrix{T},
    Gdn::AbstractMatrix{T},
) where {T<:Real}
    size(Gup) == size(Gdn) || throw(DimensionMismatch(
        "spin Green matrices must have the same size",
    ))
    size(Gup, 1) == size(Gup, 2) || throw(DimensionMismatch(
        "Green matrices must be square",
    ))

    particle_number = zero(T)
    conditional_variance = zero(T)
    for greens in (Gup, Gdn)
        for i in axes(greens, 1)
            particle_number += one(T) - greens[i, i]
            conditional_variance += greens[i, i]
            for j in axes(greens, 2)
                conditional_variance -= greens[i, j] * greens[j, i]
            end
        end
    end
    particle_number_squared =
        particle_number^2 + conditional_variance
    all(isfinite, (particle_number, particle_number_squared)) ||
        error("particle-number estimator is not finite")
    return particle_number, particle_number_squared
end

# Every μ change affects every time-slice propagator. Rebuild all diagonal
# potentials and all stabilized products before the next HS-field sweep.
function refresh_chemical_potential!(
    Gup,
    logdetGup,
    sgndetGup,
    Bup,
    fermion_greens_calc_up,
    Gdn,
    logdetGdn,
    sgndetGdn,
    Bdn,
    fermion_greens_calc_dn,
    s,
    new_mu,
    alpha,
    dtau,
)
    valid_potential(value) = isfinite(value) && value > zero(value)
    for time_slice in eachindex(Bup, Bdn)
        fields = @view s[:, time_slice]
        potential_up = Bup[time_slice].expmΔτV
        potential_down = Bdn[time_slice].expmΔτV
        @. potential_up = exp(+alpha * fields + dtau * new_mu)
        @. potential_down = exp(-alpha * fields + dtau * new_mu)
        all(valid_potential, potential_up) &&
            all(valid_potential, potential_down) ||
            error("chemical-potential update overflowed or underflowed a slice potential")
    end

    logdetGup, sgndetGup = jdqmcf.calculate_equaltime_greens!(
        Gup,
        fermion_greens_calc_up,
        Bup,
    )
    logdetGdn, sgndetGdn = jdqmcf.calculate_equaltime_greens!(
        Gdn,
        fermion_greens_calc_dn,
        Bdn,
    )
    return logdetGup, sgndetGup, logdetGdn, sgndetGdn
end

# SmoQy-style control point: measure N and N^2, advance the PRE tuner, then
# refresh every μ-dependent DQMC object before continuing the Markov chain.
function update_chemical_potential!(
    tuner::DynamicChemicalPotentialTuner,
    mu,
    Gup,
    logdetGup,
    sgndetGup,
    Bup,
    fermion_greens_calc_up,
    Gdn,
    logdetGdn,
    sgndetGdn,
    Bdn,
    fermion_greens_calc_dn,
    s,
    alpha,
    dtau,
)
    particle_number, particle_number_squared =
        total_particle_number_moments(Gup, Gdn)
    configuration_sign = sign(sgndetGup * sgndetGdn)
    tuning_step = record_density_tuning_step!(
        tuner,
        mu,
        particle_number,
        particle_number_squared,
        configuration_sign,
    )
    next_mu = tuning_step.next_mu

    if next_mu != mu
        logdetGup, sgndetGup, logdetGdn, sgndetGdn =
            refresh_chemical_potential!(
                Gup,
                logdetGup,
                sgndetGup,
                Bup,
                fermion_greens_calc_up,
                Gdn,
                logdetGdn,
                sgndetGdn,
                Bdn,
                fermion_greens_calc_dn,
                s,
                next_mu,
                alpha,
                dtau,
            )
    end
    return next_mu, logdetGup, sgndetGup, logdetGdn, sgndetGdn
end


# Now we will write a top-level function to run the simulation, including both the thermalization
# and measurement portions of the simulation.

## High-level function to run the DQMC simulation.
function run_simulation!(
    s, μ, α, Δτ, rng, N_burnin, N_bins, N_binsize, N_sweeps, density_tuner,
    Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
    Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn, L,
    avg_sign, total_density, orbital_x_density, orbital_y_density,
    double_occupancy_x, double_occupancy_y,
)

    ## Get start time for simulation.
    t_start = time()

    ## Initialize variable to keep track of largest corrected numerical error.
    δG = 0.0

    ## The acceptance rate on local updates.
    acceptance_rate = 0.0

#jl     println("Beginning Thermalization Updates")

    ## Perform burnin updates to thermalize system.
    for n in 1:N_burnin

        ## Match the SmoQy workflow: tune μ immediately before each sweep.
        if !isnothing(density_tuner)
            (μ, logdetGup, sgndetGup, logdetGdn, sgndetGdn) =
                update_chemical_potential!(
                    density_tuner, μ,
                    Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
                    Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
                    s, α, Δτ,
                )
        end

        ## Attempt local update to every Ising HS field.
        (logdetGup, sgndetGup, logdetGdn, sgndetGdn, δG′, ac) = local_update!(
            Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
            Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
            s, μ, α, Δτ, δG, rng
        )

        ## Record max numerical error.
        δG = max(δG, δG′)

        ## Update acceptance rate.
        acceptance_rate += ac
    end

#jl     println()
#jl     println("Beginning Measurements.")

    ## Iterate over measurement bins.
    for bin in 1:N_bins

        ## Iterate over updates and measurements in bin.
        for n in 1:N_binsize

            ## Iterate over number of local update sweeps per measurement.
            for sweep in 1:N_sweeps
                ## Keep tuning active during sampling, as in PRE Algorithm 1.
                if !isnothing(density_tuner)
                    (μ, logdetGup, sgndetGup, logdetGdn, sgndetGdn) =
                        update_chemical_potential!(
                            density_tuner, μ,
                            Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
                            Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
                            s, α, Δτ,
                        )
                end

                ## Attempt local update to every Ising HS field.
                (logdetGup, sgndetGup, logdetGdn, sgndetGdn, δG′, ac) = local_update!(
                    Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
                    Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
                    s, μ, α, Δτ, δG, rng
                )

                ## Record max numerical error.
                δG = max(δG, δG′)

                ## Update acceptance rate.
                acceptance_rate += ac
            end

            ## Make measurements.
            make_two_orbital_measurements!(
                Gup, sgndetGup, Gdn, sgndetGdn, L, bin,
                avg_sign, total_density, orbital_x_density, orbital_y_density,
                double_occupancy_x, double_occupancy_y,
            )
        end

        ## Normalize accumulated measurements by the bin size.
        avg_sign[bin] /= N_binsize
        total_density[bin] /= N_binsize
        orbital_x_density[bin] /= N_binsize
        orbital_y_density[bin] /= N_binsize
        double_occupancy_x[bin] /= N_binsize
        double_occupancy_y[bin] /= N_binsize
    end

    ## Calculate the final acceptance rate for local updates.
    acceptance_rate /= (N_burnin + N_bins * N_binsize * N_sweeps)

#jl     println()
#jl     println("Simuilation Complete.")
#jl     println()

    ## Get simulation runtime
    runtime = time() - t_start

    return acceptance_rate, δG, runtime, μ
end;

# Now let us run our DQMC simulation.

## Initialize the PRE density tuner after all helper definitions are available.
density_tuner = if density_tuning
    DynamicChemicalPotentialTuner(
        target_density=target_density,
        beta=β,
        number_of_cells=N_cells,
        characteristic_energy=tuning_energy_scale,
        minimum_average_sign=minimum_tuning_average_sign,
    )
else
    nothing
end

## Run the DQMC simulation.
acceptance_rate, δG, runtime, μ = run_simulation!(
    s, μ, α, Δτ, rng, N_burnin, N_bins, N_binsize, N_sweeps, density_tuner,
    Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
    Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn, L,
    avg_sign, total_density, orbital_x_density, orbital_y_density,
    double_occupancy_x, double_occupancy_y,
)
println("Acceptance Rate = ", acceptance_rate)
println("Largest Numerical Error = ", δG)
println("Simulation Run Time (sec) = ", runtime)
if !isnothing(density_tuner)
    final_tuning = last(density_tuner.profile)
    println("Density tuning steps = ", density_tuner.steps)
    println("Final instantaneous tuned mu = ", μ)
    println("Newest-half mean mu = ", final_tuning.mean_mu)
    println("Newest-half mean density = ", final_tuning.mean_density)
    println("Newest-half average sign = ", final_tuning.average_sign)
    println("Final bounded compressibility = ", final_tuning.kappa)
    println("Final fluctuation compressibility = ", final_tuning.kappa_fluctuation)
end

# Having completed the DQMC simulation, the next step is the analyze the results,
# calculating the mean and error for various measuremed observables.
# We will first calculate the relevant global measurements, including the 
# average density ``\langle n \rangle = \langle n_\uparrow + n_\downarrow \rangle``
# and double occupancy ``\langle n_\uparrow n_\downarrow \rangle.``
# Note that the binning method is used to calculate the error bar for the correlated data.
# The Jackknife algorithm is also used to propagate error and correct for bias when evaluating
# ```math
# \langle \mathcal{O} \rangle = \frac{ \langle \mathcal{S O} \rangle_\mathcal{W} }{ \langle \mathcal{S} \rangle_\mathcal{W} }
# ```
# to account for the sign problem.

## Calculate the average sign for the simulation.
sign_avg, sign_std = jdqmcm.jackknife(identity, avg_sign)
println("Avg Sign, S = ", real(sign_avg), " +/- ", sign_std)

## Calculate total density per physical cell and the paper's doping convention.
density_avg, density_std = jdqmcm.jackknife(/, total_density, avg_sign)
println("Total density per cell, n = ", real(density_avg), " +/- ", density_std)
doping_avg = (real(density_avg) - 2) / 4
println("Doping, delta = (n-2)/4 = ", doping_avg, " +/- ", density_std / 4)

## Calculate orbital-resolved densities.
density_x_avg, density_x_std = jdqmcm.jackknife(/, orbital_x_density, avg_sign)
density_y_avg, density_y_std = jdqmcm.jackknife(/, orbital_y_density, avg_sign)
println("d_xz density, n_x = ", real(density_x_avg), " +/- ", density_x_std)
println("d_yz density, n_y = ", real(density_y_avg), " +/- ", density_y_std)

## Calculate orbital-resolved intra-orbital double occupancy.
double_x_avg, double_x_std = jdqmcm.jackknife(/, double_occupancy_x, avg_sign)
double_y_avg, double_y_std = jdqmcm.jackknife(/, double_occupancy_y, avg_sign)
println("d_xz double occupancy = ", real(double_x_avg), " +/- ", double_x_std)
println("d_yz double occupancy = ", real(double_y_avg), " +/- ", double_y_std)
