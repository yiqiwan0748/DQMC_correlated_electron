# Minimal two-orbital adaptation of the square-lattice Hubbard DQMC tutorial.
#
# The one-body model is Eq. (1)-(2) and the interaction is Eq. (3) of
# Phys. Rev. B 111, L020401 (2025).  The PRB calculation itself uses gRISB,
# not DQMC, so beta, dtau, mu, lattice size, and Monte Carlo workloads below
# are editable DQMC starting choices rather than parameters quoted by the paper.
#
# This observables copy also measures the Eq. 4 altermagnetic one-point and
# equal-time structure factor.  With --measure-greens it additionally stores
# stabilized, binned, sign-weighted G_ab,sigma(k,tau) for offline analytic
# continuation.  The optional chemical-potential tuning
# phase adapts Phys. Rev. E 105, 045311 (2022), with real-sign reweighting and
# a finite-step safeguard described below.  It is followed by a fixed-mu
# rethermalization, so the reported sign is still measured in one ensemble.
# The one-orbital tutorial's correlation section is not copied because its
# orbital indices are hard-coded to (1, 1).
#
# Example:
#   julia --project=. square_hubbard_two_orbital_observables.jl \
#       2.0 10.0 -2.515 4 1.42 --measure-greens --greens-every=50

using Random
using LinearAlgebra
using Dates

import JDQMCFramework as jdqmcf
import JDQMCMeasurements as jdqmcm
import LatticeUtilities as lu
import Checkerboard as cb

include(joinpath(@__DIR__, "two_orbital_observable_tools.jl"))
using .TwoOrbitalObservableTools

BLAS.set_num_threads(1)

# -----------------------------------------------------------------------------
# Model and DQMC parameters
# -----------------------------------------------------------------------------

const ORBITAL_X = 1 # d_xz
const ORBITAL_Y = 2 # d_yz

# The default is a short sign-first run.  Use --production to recover the
# original tutorial-size workload.  Use --tune-mu to tune to the target density
# before the fixed-mu sign measurement.  Use --u0-check for a quick
# free-fermion check, whose average sign must be +1.
if "--help" in ARGS || "-h" in ARGS
    println(
        "Usage: script.jl U beta initial_mu L target_density ",
        "[--tune-mu] [--production] [--u0-check] [--atomic-check] ",
        "[--measure-greens] [--greens-every=N] ",
        "[--tune-sweeps=N] [--seed=N] [--output=PATH]",
    )
    exit()
end
length(ARGS) >= 5 || error(
    "Usage: script.jl U beta initial_mu L target_density " *
    "[--tune-mu] [--production] [--u0-check] [--atomic-check] " *
    "[--measure-greens] " *
    "[--greens-every=N] [--tune-sweeps=N] [--seed=N] [--output=PATH]",
)

input_U = parse(Float64, ARGS[1])
input_beta = parse(Float64, ARGS[2])
input_mu = parse(Float64, ARGS[3])
input_L = parse(Int, ARGS[4])
input_n = parse(Float64, ARGS[5])
isfinite(input_U) && input_U >= 0 || error("U must be finite and nonnegative")
isfinite(input_beta) && input_beta > 0 || error("beta must be finite and positive")
isfinite(input_mu) || error("initial_mu must be finite")

production_run = false
tune_mu = false
u0_check = false
atomic_check = false
measure_greens = false
greens_every = 50
requested_tune_sweeps = nothing
requested_seed = nothing
requested_output_path = nothing
for argument in ARGS[6:end]
    if argument == "--production"
        global production_run = true
    elseif argument == "--tune-mu"
        global tune_mu = true
    elseif argument == "--u0-check"
        global u0_check = true
    elseif argument == "--atomic-check"
        global atomic_check = true
    elseif argument == "--measure-greens"
        global measure_greens = true
    elseif startswith(argument, "--greens-every=")
        global greens_every = parse(Int, split(argument, "="; limit=2)[2])
    elseif startswith(argument, "--tune-sweeps=")
        global requested_tune_sweeps =
            parse(Int, split(argument, "="; limit=2)[2])
    elseif startswith(argument, "--seed=")
        global requested_seed = parse(Int, split(argument, "="; limit=2)[2])
    elseif startswith(argument, "--output=")
        global requested_output_path = split(argument, "="; limit=2)[2]
        isempty(requested_output_path) && error("--output path must be nonempty")
    else
        error("Unknown optional argument: $argument")
    end
end
u0_check && atomic_check &&
    error("choose either --u0-check or --atomic-check, not both")
greens_every > 0 || error("--greens-every must be positive")
!isnothing(requested_tune_sweeps) && !tune_mu &&
    error("--tune-sweeps requires --tune-mu")
!isnothing(requested_tune_sweeps) && requested_tune_sweeps <= 0 &&
    error("--tune-sweeps must be positive")
!isnothing(requested_seed) && requested_seed < 0 &&
    error("--seed must be nonnegative")

# Overall hopping scale and the PRB hopping parameters (paper Eq. 2).
t = 1.0
t1 = atomic_check ? 0.0 : -t
t2 = atomic_check ? 0.0 : -1.75t
t3 = atomic_check ? 0.0 : -0.85t
t4 = atomic_check ? 0.0 : -0.65t

println("Hopping parameters:")
println("  t1 = ", t1)
println("  t2 = ", t2)
println("  t3 = ", t3)
println("  t4 = ", t4)
atomic_check && println(
    "Interacting exact benchmark mode: zero hopping (independent Hubbard atoms)",
)

# Purely intraorbital Hubbard interaction (paper Eq. 3).
# U=4 is only a finite-temperature DQMC starting point; the paper does not
# specify a DQMC parameter set.  The validation mode overrides it before it is
# used or printed.
U = u0_check ? 0.0 : input_U
println("Intraorbital Hubbard interaction, U = ", U)

# The paper works at fixed doping and does not define a corresponding chemical
# potential.  mu=-1.9 is an editable bare-band starting point near its first
# reported van Hove region, not an interacting fixed-density calibration.
μ = input_mu
println("Chemical potential starting point, mu = ", μ)

# Density is the total number of electrons per physical cell (range 0 to 4).
# This is the repository's converged bare-band filling at the PRB's first,
# upper-energy van Hove singularity.  Edit this one number to tune elsewhere.
# To target the paper's rounded delta=-0.145 literally under the inferred
# delta=(n-2)/4 convention, use target_density = 1.42 instead.
target_density = input_n
maximum_tuner_mu_step = 0.5
0.0 <= target_density <= 4.0 || error(
    "Target density per physical cell must lie between 0 and 4",
)
tune_mu && println(
    "Target density per physical cell, n_target = ",
    target_density,
)
tune_mu && println(
    "Maximum chemical-potential step during tuning = ",
    maximum_tuner_mu_step,
)

# These finite-temperature settings are not supplied by the PRB paper.
β = input_beta
L = input_L
Δτ = 0.05

println("Inverse temperature, beta = ", β)
println("Linear lattice size, L = ", L)
println("Imaginary-time step, dtau = ", Δτ)

L >= 2 || error("This script requires L >= 2")
Lτ = round(Int, β / Δτ)
isapprox(Lτ * Δτ, β; atol=64eps(Float64) * max(1.0, β), rtol=0.0) ||
    error("beta/dtau must be an integer")
println("Number of imaginary-time slices, Ltau = ", Lτ)

# Retain the tutorial's exact, asymmetric propagator as the default.
symmetric = false
checkerboard = false
n_stab = 1

println("Symmetric propagators, symmetric = ", symmetric)
println("Checkerboard approximation, checkerboard = ", checkerboard)
println("Stabilization period, n_stab = ", n_stab)

# In tuning mode, N_tune sweeps adjust mu, after which N_burnin additional
# sweeps rethermalize at the frozen value.  The quick values are diagnostics;
# increase both before treating the tuned mu as a production calibration.
default_tune_sweeps = production_run ? 20_000 : 400
N_tune = tune_mu ?
    (isnothing(requested_tune_sweeps) ? default_tune_sweeps : requested_tune_sweeps) :
    0
N_burnin = production_run ? (tune_mu ? 2_000 : 2_500) :
             (u0_check ? 0 : 100)
N_measurements = production_run ? 10_000 : 500
N_sweeps = 1
N_bins = production_run ? 50 : 10
N_measurements % N_bins == 0 || error(
    "N_measurements must be divisible by N_bins",
)
N_binsize = N_measurements ÷ N_bins

println(
    "Run mode = ",
    production_run ? "long tutorial workload" : "quick sign diagnostic",
)
production_run || println(
    "Quick mode is a smoke estimate, not a precision sign measurement.",
)
u0_check && println("U=0 validation mode enabled")
println("Number of chemical-potential tuning sweeps, N_tune = ", N_tune)
println("Number of burn-in sweeps, N_burnin = ", N_burnin)
println("Number of measurements, N_measurements = ", N_measurements)
println("Sweeps between measurements, N_sweeps = ", N_sweeps)
println("Number of bins, N_bins = ", N_bins)
println("Measurements per bin, N_binsize = ", N_binsize)
println("Eq. 4 altermagnetic measurements enabled = true")
println("Unequal-time Green measurements enabled = ", measure_greens)
measure_greens && println(
    "Unequal-time Green measurement stride = ",
    greens_every,
)

# Fixed seed makes repeated runs directly comparable.  Change it for an
# independent chain and report every seed used.
seed = isnothing(requested_seed) ? 12_345 : requested_seed
rng = Xoshiro(seed)
println("Random seed, seed = ", seed)
timestamp = Dates.format(now(), "yyyymmdd_HHMMSS")
output_path = isnothing(requested_output_path) ?
    "observable_data_U$(U)_beta$(input_beta)_L$(input_L)_seed$(seed)_$(timestamp).jls" :
    requested_output_path
output_path = abspath(output_path)
ispath(output_path) && error("refusing to overwrite existing output: $output_path")
output_parent = dirname(output_path)
mkpath(output_parent)
mktemp(output_parent) do _, io
    write(io, "output preflight")
end
println("Observable output file = ", output_path)
println()

# -----------------------------------------------------------------------------
# Two-orbital square lattice and the PRB kinetic matrix
# -----------------------------------------------------------------------------

# The two degenerate orbitals occupy the same physical lattice site.  Their
# order is (d_xz, d_yz), matching the PRB Bloch basis.
unit_cell = lu.UnitCell(
    lattice_vecs=[[1.0, 0.0], [0.0, 1.0]],
    basis_vecs=[[0.0, 0.0], [0.0, 0.0]],
)

lattice = lu.Lattice(
    L=[L, L],
    periodic=[true, true],
)

# Each Bond describes one directed positive-displacement hopping type.  Both
# interorbital orders are needed so the Bloch Hamiltonian remains real and
# symmetric.  With the tutorial convention K[i,j] = -hopping, these twelve
# hopping amplitudes reproduce
#
#   eps_x  = -2t1 cos(kx) - 2t2 cos(ky) - 4t3 cos(kx)cos(ky)
#   eps_y  = -2t2 cos(kx) - 2t1 cos(ky) - 4t3 cos(kx)cos(ky)
#   eps_xy = -4t4 sin(kx)sin(ky).
kinetic_bonds = [
    lu.Bond(orbitals=(ORBITAL_X, ORBITAL_X), displacement=[1, 0]),
    lu.Bond(orbitals=(ORBITAL_Y, ORBITAL_Y), displacement=[1, 0]),
    lu.Bond(orbitals=(ORBITAL_X, ORBITAL_X), displacement=[0, 1]),
    lu.Bond(orbitals=(ORBITAL_Y, ORBITAL_Y), displacement=[0, 1]),
    lu.Bond(orbitals=(ORBITAL_X, ORBITAL_X), displacement=[1, 1]),
    lu.Bond(orbitals=(ORBITAL_X, ORBITAL_Y), displacement=[1, 1]),
    lu.Bond(orbitals=(ORBITAL_Y, ORBITAL_X), displacement=[1, 1]),
    lu.Bond(orbitals=(ORBITAL_Y, ORBITAL_Y), displacement=[1, 1]),
    lu.Bond(orbitals=(ORBITAL_X, ORBITAL_X), displacement=[1, -1]),
    lu.Bond(orbitals=(ORBITAL_X, ORBITAL_Y), displacement=[1, -1]),
    lu.Bond(orbitals=(ORBITAL_Y, ORBITAL_X), displacement=[1, -1]),
    lu.Bond(orbitals=(ORBITAL_Y, ORBITAL_Y), displacement=[1, -1]),
]

bond_hoppings = [
    t1, t2,
    t2, t1,
    t3, -t4, -t4, t3,
    t3, +t4, +t4, t3,
]

# Build one table at a time so every neighbor-table column has an explicitly
# aligned hopping amplitude.  Each table contains L^2 translated bonds.
neighbor_tables = [
    lu.build_neighbor_table([bond], unit_cell, lattice)
    for bond in kinetic_bonds
]
neighbor_table = hcat(neighbor_tables...)
hopping_amplitudes = reduce(vcat, [
    fill(hopping, size(table, 2))
    for (hopping, table) in zip(bond_hoppings, neighbor_tables)
])

N_cells = L^2
N = lu.nsites(unit_cell, lattice)
N == 2N_cells || error("Expected two orbitals per physical cell")
N_bonds = size(neighbor_table, 2)
length(hopping_amplitudes) == N_bonds || error(
    "Every neighbor-table column must have one hopping amplitude",
)

println("Number of physical cells = ", N_cells)
println("One-spin matrix dimension, 2L^2 = ", N)
println("Number of translated directed bond entries = ", N_bonds)
println()

Δτ′ = symmetric ? Δτ / 2 : Δτ
T_kinetic = eltype(hopping_amplitudes)

if checkerboard
    expnΔτ′K = cb.CheckerboardMatrix(
        neighbor_table,
        hopping_amplitudes,
        Δτ′,
    )
else
    # Actual one-body coefficients are minus the listed hopping amplitudes.
    # Accumulation is required when distinct periodic bonds alias at small L.
    K = zeros(T_kinetic, N, N)
    for bond in 1:N_bonds
        i, j = neighbor_table[1, bond], neighbor_table[2, bond]
        matrix_element = -hopping_amplitudes[bond]
        K[i, j] += matrix_element
        K[j, i] += matrix_element
    end
    issymmetric(K) || error("The kinetic matrix must be real symmetric")

    expnΔτ′K = exp(-Δτ′ * K)
    exppΔτ′K = exp(+Δτ′ * K)
end

# -----------------------------------------------------------------------------
# HS fields, propagators, and equal-time Green matrices
# -----------------------------------------------------------------------------

# This is the standard discrete Hirsch decoupling of the paper's shifted
# intraorbital interaction.  There is one independent field per site-orbital.
α = acosh(exp(Δτ * U / 2))
s = rand(rng, Int8[-1, 1], N, Lτ)

T_expnΔτK = T_kinetic
T_expnΔτV = typeof(α)

if checkerboard && symmetric
    Bup = jdqmcf.SymChkbrdPropagator{T_expnΔτK, T_expnΔτV}[]
    Bdn = jdqmcf.SymChkbrdPropagator{T_expnΔτK, T_expnΔτV}[]
elseif checkerboard && !symmetric
    Bup = jdqmcf.AsymChkbrdPropagator{T_expnΔτK, T_expnΔτV}[]
    Bdn = jdqmcf.AsymChkbrdPropagator{T_expnΔτK, T_expnΔτV}[]
elseif !checkerboard && symmetric
    Bup = jdqmcf.SymExactPropagator{T_expnΔτK, T_expnΔτV}[]
    Bdn = jdqmcf.SymExactPropagator{T_expnΔτK, T_expnΔτV}[]
else
    Bup = jdqmcf.AsymExactPropagator{T_expnΔτK, T_expnΔτV}[]
    Bdn = jdqmcf.AsymExactPropagator{T_expnΔτK, T_expnΔτV}[]
end

for l in 1:Lτ
    s_l = @view s[:, l]

    # The chemical-potential factor is kept in the diagonal potential, exactly
    # as in the original tutorial.  This is equivalent to K -> K - mu*I.
    expnΔτVup = zeros(T_expnΔτV, N)
    expnΔτVdn = zeros(T_expnΔτV, N)
    @. expnΔτVup = exp(+α * s_l + Δτ * μ)
    @. expnΔτVdn = exp(-α * s_l + Δτ * μ)

    if checkerboard && symmetric
        push!(Bup, jdqmcf.SymChkbrdPropagator(expnΔτVup, expnΔτ′K))
        push!(Bdn, jdqmcf.SymChkbrdPropagator(expnΔτVdn, expnΔτ′K))
    elseif checkerboard && !symmetric
        push!(Bup, jdqmcf.AsymChkbrdPropagator(expnΔτVup, expnΔτ′K))
        push!(Bdn, jdqmcf.AsymChkbrdPropagator(expnΔτVdn, expnΔτ′K))
    elseif !checkerboard && symmetric
        push!(Bup, jdqmcf.SymExactPropagator(
            expnΔτVup,
            expnΔτ′K,
            exppΔτ′K,
        ))
        push!(Bdn, jdqmcf.SymExactPropagator(
            expnΔτVdn,
            expnΔτ′K,
            exppΔτ′K,
        ))
    else
        push!(Bup, jdqmcf.AsymExactPropagator(
            expnΔτVup,
            expnΔτ′K,
            exppΔτ′K,
        ))
        push!(Bdn, jdqmcf.AsymExactPropagator(
            expnΔτVdn,
            expnΔτ′K,
            exppΔτ′K,
        ))
    end
end

fermion_greens_calc_up = jdqmcf.FermionGreensCalculator(
    Bup,
    β,
    Δτ,
    n_stab,
)
fermion_greens_calc_dn = jdqmcf.FermionGreensCalculator(
    Bdn,
    β,
    Δτ,
    n_stab,
)

Gup = zeros(T_kinetic, N, N)
logdetGup, sgndetGup = jdqmcf.calculate_equaltime_greens!(
    Gup,
    fermion_greens_calc_up,
)

Gdn = zeros(T_kinetic, N, N)
logdetGdn, sgndetGdn = jdqmcf.calculate_equaltime_greens!(
    Gdn,
    fermion_greens_calc_dn,
)

# Binned sign denominators and sign-weighted observable numerators.
avg_sign = zeros(T_kinetic, N_bins)
density = zeros(T_kinetic, N_bins)
density_x = zeros(T_kinetic, N_bins)
density_y = zeros(T_kinetic, N_bins)
double_occ = zeros(T_kinetic, N_bins)
double_occ_x = zeros(T_kinetic, N_bins)
double_occ_y = zeros(T_kinetic, N_bins)

# Eq. 4 signed numerators use the same measurement bins and sign denominator.
altermagnetic_signed_bins =
    zeros(T_kinetic, N_bins, length(ALTERMAGNETIC_FIELDS))

# Unequal-time measurements can use a lower cadence, so they need their own
# paired sign denominators and counts. Keep sums, not fragile per-bin ratios.
green_sign_sums = zeros(T_kinetic, N_bins)
green_counts = zeros(Int, N_bins)
green_maximum_stabilization_errors = zeros(T_kinetic, N_bins, 2)
green_signed_real_space_bins = measure_greens ?
    zeros(Complex{T_kinetic}, N_bins, 2, 2, 2, L, L, Lτ + 1) :
    nothing

# -----------------------------------------------------------------------------
# Local HS updates (same flow as the one-orbital tutorial)
# -----------------------------------------------------------------------------

function local_update!(
    Gup::Matrix{T}, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
    Gdn::Matrix{T}, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
    s, α, Δτ, δG, rng,
) where {T<:Number}
    Lτ = length(Bup)
    N = size(Gup, 1)

    A = zeros(T, N, N)
    u = zeros(T, N)
    v = zeros(T, N)
    perm = collect(1:N)
    acceptance_rate = 0.0

    for l in fermion_greens_calc_up
        jdqmcf.propagate_equaltime_greens!(
            Gup,
            fermion_greens_calc_up,
            Bup,
        )
        jdqmcf.propagate_equaltime_greens!(
            Gdn,
            fermion_greens_calc_dn,
            Bdn,
        )

        jdqmcf.partially_wrap_greens_reverse!(Gup, Bup[l], A)
        jdqmcf.partially_wrap_greens_reverse!(Gdn, Bdn[l], A)

        s_l = @view s[:, l]
        logdetGup, sgndetGup, logdetGdn, sgndetGdn, acceptance_rate_l =
            _local_update!(
                Gup, logdetGup, sgndetGup, Bup[l],
                Gdn, logdetGdn, sgndetGdn, Bdn[l],
                s_l, α, Δτ, rng, perm, u, v,
            )
        acceptance_rate += acceptance_rate_l / Lτ

        jdqmcf.partially_wrap_greens_forward!(Gup, Bup[l], A)
        jdqmcf.partially_wrap_greens_forward!(Gdn, Bdn[l], A)

        logdetGup, sgndetGup, δGup, _ =
            jdqmcf.stabilize_equaltime_greens!(
                Gup,
                logdetGup,
                sgndetGup,
                fermion_greens_calc_up,
                Bup;
                update_B̄=true,
            )
        logdetGdn, sgndetGdn, δGdn, _ =
            jdqmcf.stabilize_equaltime_greens!(
                Gdn,
                logdetGdn,
                sgndetGdn,
                fermion_greens_calc_dn,
                Bdn;
                update_B̄=true,
            )
        δG = max(δG, δGup, δGdn)

        # Keep the down-spin calculator synchronized with the up-spin loop.
        iterate(fermion_greens_calc_dn, fermion_greens_calc_up)
    end

    return (
        logdetGup,
        sgndetGup,
        logdetGdn,
        sgndetGdn,
        δG,
        acceptance_rate,
    )
end

function _local_update!(
    Gup, logdetGup, sgndetGup, Bup,
    Gdn, logdetGdn, sgndetGdn, Bdn,
    s, α, Δτ, rng, perm, u, v,
)
    shuffle!(rng, perm)
    accepted = 0

    for i in perm
        ΔVup = +2α * s[i] / Δτ
        ΔVdn = -2α * s[i] / Δτ

        Rup, Δup = jdqmcf.local_update_det_ratio(Gup, ΔVup, i, Δτ)
        Rdn, Δdn = jdqmcf.local_update_det_ratio(Gdn, ΔVdn, i, Δτ)
        probability = min(1.0, abs(Rup * Rdn))

        if rand(rng) < probability
            accepted += 1
            s[i] = -s[i]

            logdetGup, sgndetGup = jdqmcf.local_update_greens!(
                Gup,
                logdetGup,
                sgndetGup,
                Bup,
                Rup,
                Δup,
                i,
                u,
                v,
            )
            logdetGdn, sgndetGdn = jdqmcf.local_update_greens!(
                Gdn,
                logdetGdn,
                sgndetGdn,
                Bdn,
                Rdn,
                Δdn,
                i,
                u,
                v,
            )
        end
    end

    acceptance_rate = accepted / length(perm)
    return logdetGup, sgndetGup, logdetGdn, sgndetGdn, acceptance_rate
end

# -----------------------------------------------------------------------------
# PRE chemical-potential tuner
# -----------------------------------------------------------------------------

# This small state contains only the quantities needed for Eqs. (2)-(8) and
# the QMC estimators in Eqs. (16)-(18) of Phys. Rev. E 105, 045311 (2022).
# Direct sums over the most recent half of the trajectory keep this educational
# implementation easy to audit; their cost is negligible here.
mutable struct DensityTuner{T<:AbstractFloat}
    target_particle_number::T
    inverse_temperature::T
    kappa_scale::T
    maximum_mu_step::T
    sign_tolerance::T
    mu_trajectory::Vector{T}
    signed_N_trajectory::Vector{T}
    signed_N2_trajectory::Vector{T}
    sign_trajectory::Vector{T}
end

function DensityTuner(;
    target_density_per_cell,
    inverse_temperature,
    system_size,
    energy_scale,
    maximum_mu_step=0.5,
    sign_tolerance=0.05,
)
    T = promote_type(
        typeof(float(target_density_per_cell)),
        typeof(float(inverse_temperature)),
        typeof(float(energy_scale)),
        typeof(float(maximum_mu_step)),
        typeof(float(sign_tolerance)),
    )
    target = T(target_density_per_cell)
    beta = T(inverse_temperature)
    scale = T(energy_scale)
    max_step = T(maximum_mu_step)
    sign_tol = T(sign_tolerance)

    0 <= target <= 4 || error("Target density must lie between 0 and 4")
    beta > 0 || error("Inverse temperature must be positive")
    system_size > 0 || error("System size must be positive")
    scale > 0 || error("Tuner energy scale must be positive")
    max_step > 0 || error("Maximum tuner step must be positive")
    sign_tol > 0 || error("Sign tolerance must be positive")

    # system_size counts site-orbitals (2L^2), while target is per two-orbital
    # physical cell.  Thus the density passed to the extensive PRE equations
    # is target/2 and N_target = system_size*target/2.
    target_particle_number = T(system_size) * target / 2
    # Counting the two orbitals as the system volume follows SmoQy's density
    # normalization.  It is a multiorbital choice for the paper's approximate
    # scale alpha=V/u0, not an additional physical parameter.
    kappa_scale = T(system_size) / scale
    return DensityTuner{T}(
        target_particle_number,
        beta,
        kappa_scale,
        max_step,
        sign_tol,
        T[],
        T[],
        T[],
        T[],
    )
end

configuration_sign(sgndetGup, sgndetGdn) =
    sign(inv(sgndetGup) * inv(sgndetGdn))

function update_density_tuner!(
    tuner::DensityTuner{T},
    current_mu,
    density_per_site_orbital,
    particle_number_squared,
    sample_sign,
    system_size,
) where {T}
    mu = T(current_mu)
    sign_value = T(real(sample_sign))
    particle_number = T(system_size) * T(real(density_per_site_orbital))
    particle_number_squared_value = T(real(particle_number_squared))
    all(isfinite, (mu, sign_value, particle_number,
                   particle_number_squared_value)) ||
        error("The density tuner received a non-finite sample")

    # The DQMC chain samples the absolute determinant weight.  Store signed
    # numerators so both <N> and <N^2> use the same sign reweighting as the
    # production observables.  This matches MuTuner's real-sign extension;
    # the PRE benchmarks themselves are sign-problem-free.
    push!(tuner.mu_trajectory, mu)
    push!(tuner.signed_N_trajectory, sign_value * particle_number)
    push!(
        tuner.signed_N2_trajectory,
        sign_value * particle_number_squared_value,
    )
    push!(tuner.sign_trajectory, sign_value)

    nsamples = length(tuner.mu_trajectory)
    first_sample = fld(nsamples, 2) + 1
    window = first_sample:nsamples
    window_length = length(window)

    mu_mean = sum(@view tuner.mu_trajectory[window]) / window_length
    signed_N_mean =
        sum(@view tuner.signed_N_trajectory[window]) / window_length
    signed_N2_mean =
        sum(@view tuner.signed_N2_trajectory[window]) / window_length
    sign_mean = sum(@view tuner.sign_trajectory[window]) / window_length
    mu_variance = sum(
        (value - mu_mean)^2 for
        value in view(tuner.mu_trajectory, window)
    ) / window_length

    valid_sign = isfinite(sign_mean) && abs(sign_mean) > tuner.sign_tolerance
    N_mean = valid_sign ? signed_N_mean / sign_mean : T(NaN)
    N2_mean = valid_sign ? signed_N2_mean / sign_mean : T(NaN)
    N_variance = N2_mean - N_mean^2

    # A tiny negative variance can arise from roundoff.  A materially negative
    # sign-reweighted value instead marks this window as too noisy to steer mu.
    variance_tolerance = T(256) * eps(T) *
        max(one(T), abs(N2_mean), abs(N_mean)^2)
    valid_variance = isfinite(N_variance) &&
                     N_variance >= -variance_tolerance
    if valid_variance
        N_variance = max(zero(T), N_variance)
    end

    kappa_min = tuner.kappa_scale / sqrt(T(nsamples))
    kappa_fluctuation = tuner.inverse_temperature * N_variance
    # kappa_max is undefined at startup when Var(mu)=0.  Choosing kappa_min in
    # that case is the MuTuner implementation's startup safeguard, not Eq. (8).
    kappa_max = nsamples == 1 || iszero(mu_variance) || !valid_variance ||
                N_variance / mu_variance < 0 ?
                kappa_min : sqrt(N_variance / mu_variance)
    kappa = valid_sign && valid_variance ?
            max(kappa_min, min(kappa_max, kappa_fluctuation)) : kappa_min
    valid_update = valid_sign && valid_variance &&
                   isfinite(kappa) && kappa > 0

    # Equation (2) corrects the recent-window mean, not the instantaneous mu.
    proposed_mu = valid_update ?
                  mu_mean + (tuner.target_particle_number - N_mean) / kappa :
                  mu
    isfinite(proposed_mu) || (proposed_mu = mu_mean)

    # This finite-step guard is an implementation safeguard, not part of the
    # PRE equations.  It prevents a nearly vanishing average sign from causing
    # one noisy window to make an arbitrarily large propagator rescaling.
    mu_next = mu + clamp(
        proposed_mu - mu,
        -tuner.maximum_mu_step,
        tuner.maximum_mu_step,
    )
    density_per_cell = 2N_mean / T(system_size)

    return (
        mu_next=mu_next,
        mu_mean=mu_mean,
        density_per_cell=density_per_cell,
        sign_mean=sign_mean,
        particle_number_variance=N_variance,
        kappa=kappa,
        valid_update=valid_update,
        first_sample=first_sample,
        last_sample=nsamples,
    )
end

function apply_chemical_potential!(
    new_mu,
    current_mu,
    delta_tau,
    Gup,
    Bup,
    fermion_greens_calc_up,
    Gdn,
    Bdn,
    fermion_greens_calc_dn,
)
    delta_mu = new_mu - current_mu
    potential_scale = exp(delta_tau * delta_mu)
    isfinite(new_mu) || error("Density tuner proposed a non-finite mu")
    isfinite(potential_scale) && potential_scale > 0 ||
        error("Chemical-potential propagator scale is invalid")
    length(Bup) == length(Bdn) || error("Spin propagator lengths differ")

    # Every diagonal potential contains exp(+delta_tau*mu).  After modifying
    # all slices, use the three-argument routine to rebuild B-bar, all cached
    # factorizations, and the equal-time Green matrix from scratch.
    for l in eachindex(Bup, Bdn)
        Bup[l].expmΔτV .*= potential_scale
        Bdn[l].expmΔτV .*= potential_scale
    end
    logdetGup, sgndetGup = jdqmcf.calculate_equaltime_greens!(
        Gup,
        fermion_greens_calc_up,
        Bup,
    )
    logdetGdn, sgndetGdn = jdqmcf.calculate_equaltime_greens!(
        Gdn,
        fermion_greens_calc_dn,
        Bdn,
    )
    return logdetGup, sgndetGup, logdetGdn, sgndetGdn
end

# -----------------------------------------------------------------------------
# Sign-first measurements
# -----------------------------------------------------------------------------

function make_measurements!(
    Gup, sgndetGup,
    Gdn, sgndetGdn,
    unit_cell,
    L,
    bin,
    avg_sign,
    density,
    density_x,
    density_y,
    double_occ,
    double_occ_x,
    double_occ_y,
    altermagnetic_signed_bins,
)
    # Stored determinant signs describe det(G_sigma); the Monte Carlo weight
    # contains det(inv(G_sigma)), whose sign is the same reciprocal sign.
    sample_sign = configuration_sign(sgndetGup, sgndetGdn)

    n_x = jdqmcm.measure_n(Gup, ORBITAL_X, unit_cell) +
          jdqmcm.measure_n(Gdn, ORBITAL_X, unit_cell)
    n_y = jdqmcm.measure_n(Gup, ORBITAL_Y, unit_cell) +
          jdqmcm.measure_n(Gdn, ORBITAL_Y, unit_cell)
    d_x = jdqmcm.measure_double_occ(
        Gup,
        Gdn,
        ORBITAL_X,
        unit_cell,
    )
    d_y = jdqmcm.measure_double_occ(
        Gup,
        Gdn,
        ORBITAL_Y,
        unit_cell,
    )

    avg_sign[bin] += sample_sign
    density[bin] += sample_sign * (n_x + n_y)
    density_x[bin] += sample_sign * n_x
    density_y[bin] += sample_sign * n_y
    double_occ[bin] += sample_sign * (d_x + d_y)
    double_occ_x[bin] += sample_sign * d_x
    double_occ_y[bin] += sample_sign * d_y
    accumulate_altermagnetic!(
        view(altermagnetic_signed_bins, bin, :),
        Gup,
        Gdn,
        L,
        sample_sign,
    )
    return sample_sign
end

function run_simulation!(
    s, α, Δτ, rng,
    N_tune, N_burnin, N_bins, N_binsize, N_sweeps,
    mu_start, target_density, maximum_mu_step,
    inverse_temperature, system_size, energy_scale,
    Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
    Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
    unit_cell, lattice, L, stabilization_period,
    measure_greens, greens_every,
    avg_sign, density, density_x, density_y,
    double_occ, double_occ_x, double_occ_y,
    altermagnetic_signed_bins,
    green_sign_sums, green_counts, green_signed_real_space_bins,
    green_maximum_stabilization_errors,
)
    t_start = time()
    δG = 0.0
    acceptance_rate = 0.0
    current_mu = mu_start
    tuning_summary = nothing

    if N_tune > 0
        tuner = DensityTuner(
            target_density_per_cell=target_density,
            inverse_temperature=inverse_temperature,
            system_size=system_size,
            energy_scale=energy_scale,
            maximum_mu_step=maximum_mu_step,
        )
        progress_interval = max(1, N_tune ÷ 10)

        println("Beginning chemical-potential tuning updates")
        for tuning_sweep in 1:N_tune
            logdetGup, sgndetGup, logdetGdn, sgndetGdn, δG′, ac =
                local_update!(
                    Gup, logdetGup, sgndetGup,
                    Bup, fermion_greens_calc_up,
                    Gdn, logdetGdn, sgndetGdn,
                    Bdn, fermion_greens_calc_dn,
                    s, α, Δτ, δG, rng,
                )
            δG = max(δG, δG′)
            acceptance_rate += ac

            density_per_site_orbital =
                jdqmcm.measure_n(Gup) + jdqmcm.measure_n(Gdn)
            particle_number_squared = jdqmcm.measure_Nsqrd(Gup, Gdn)
            sample_sign = configuration_sign(sgndetGup, sgndetGdn)
            tuning_summary = update_density_tuner!(
                tuner,
                current_mu,
                density_per_site_orbital,
                particle_number_squared,
                sample_sign,
                system_size,
            )

            new_mu = tuning_summary.mu_next
            logdetGup, sgndetGup, logdetGdn, sgndetGdn =
                apply_chemical_potential!(
                    new_mu,
                    current_mu,
                    Δτ,
                    Gup,
                    Bup,
                    fermion_greens_calc_up,
                    Gdn,
                    Bdn,
                    fermion_greens_calc_dn,
                )
            current_mu = new_mu

            if tuning_sweep == 1 ||
               tuning_sweep % progress_interval == 0 ||
               tuning_sweep == N_tune
                println(
                    "  tuning sweep ", tuning_sweep, " of ", N_tune,
                    ": mu = ", round(current_mu; digits=6),
                    ", recent n = ",
                    round(tuning_summary.density_per_cell; digits=6),
                    ", recent sign = ",
                    round(tuning_summary.sign_mean; digits=6),
                    ", update valid = ", tuning_summary.valid_update,
                )
            end
        end

        println("Chemical-potential tuning phase complete")
        println("  mu frozen for fixed-ensemble validation = ", current_mu)
        println(
            "  recent-window density estimate = ",
            tuning_summary.density_per_cell,
        )
        println(
            "  recent-window average sign = ",
            tuning_summary.sign_mean,
        )
        tuning_summary.valid_update || println(
            "  WARNING: final tuning window was too noisy for a valid update",
        )
    end

    println("Beginning fixed-mu thermalization updates at mu = ", current_mu)
    for _ in 1:N_burnin
        logdetGup, sgndetGup, logdetGdn, sgndetGdn, δG′, ac =
            local_update!(
                Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
                Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
                s, α, Δτ, δG, rng,
            )
        δG = max(δG, δG′)
        acceptance_rate += ac
    end

    # Report the update acceptance of the measured fixed-mu ensemble, not a
    # mixture with the preceding adaptive-mu and rethermalization sweeps.
    acceptance_rate = 0.0
    println("Beginning measurements")
    for bin in 1:N_bins
        for measurement_in_bin in 1:N_binsize
            for _ in 1:N_sweeps
                logdetGup, sgndetGup, logdetGdn, sgndetGdn, δG′, ac =
                    local_update!(
                        Gup, logdetGup, sgndetGup,
                        Bup, fermion_greens_calc_up,
                        Gdn, logdetGdn, sgndetGdn,
                        Bdn, fermion_greens_calc_dn,
                        s, α, Δτ, δG, rng,
                    )
                δG = max(δG, δG′)
                acceptance_rate += ac
            end

            sample_sign = make_measurements!(
                Gup, sgndetGup,
                Gdn, sgndetGdn,
                unit_cell,
                L,
                bin,
                avg_sign,
                density,
                density_x,
                density_y,
                double_occ,
                double_occ_x,
                double_occ_y,
                altermagnetic_signed_bins,
            )

            if measure_greens &&
               mod(measurement_in_bin - 1, greens_every) == 0
                green_result = accumulate_unequal_time_greens!(
                    view(green_signed_real_space_bins, bin, :, :, :, :, :, :),
                    sample_sign,
                    Bup,
                    Bdn,
                    inverse_temperature,
                    Δτ,
                    stabilization_period,
                    unit_cell,
                    lattice,
                )
                green_sign_sums[bin] += sample_sign
                green_counts[bin] += 1
                for spin in 1:2
                    green_maximum_stabilization_errors[bin, spin] = max(
                        green_maximum_stabilization_errors[bin, spin],
                        green_result.maximum_stabilization_error[spin],
                    )
                end
            end
        end

        avg_sign[bin] /= N_binsize
        density[bin] /= N_binsize
        density_x[bin] /= N_binsize
        density_y[bin] /= N_binsize
        double_occ[bin] /= N_binsize
        double_occ_x[bin] /= N_binsize
        double_occ_y[bin] /= N_binsize
        altermagnetic_signed_bins[bin, :] ./= N_binsize

        println(
            "  completed bin ", bin, " of ", N_bins,
            measure_greens ? " (Green samples: $(green_counts[bin]))" : "",
        )
    end

    update_sweeps = N_bins * N_binsize * N_sweeps
    # Roundoff from averaging one rate per time slice can exceed one by a few
    # ulps in the exactly accepted U=0 case.
    acceptance_rate = clamp(acceptance_rate / update_sweeps, 0.0, 1.0)
    runtime = time() - t_start
    return (
        acceptance_rate,
        δG,
        runtime,
        current_mu,
        tuning_summary,
    )
end

# -----------------------------------------------------------------------------
# Run and report
# -----------------------------------------------------------------------------

acceptance_rate, δG, runtime, mu_measured, tuning_summary = run_simulation!(
    s, α, Δτ, rng,
    N_tune, N_burnin, N_bins, N_binsize, N_sweeps,
    μ, target_density, maximum_tuner_mu_step, β, N, abs(t),
    Gup, logdetGup, sgndetGup, Bup, fermion_greens_calc_up,
    Gdn, logdetGdn, sgndetGdn, Bdn, fermion_greens_calc_dn,
    unit_cell, lattice, L, n_stab,
    measure_greens, greens_every,
    avg_sign, density, density_x, density_y,
    double_occ, double_occ_x, double_occ_y,
    altermagnetic_signed_bins,
    green_sign_sums, green_counts, green_signed_real_space_bins,
    green_maximum_stabilization_errors,
)

println()
println("Simulation complete")
println("Chemical potential used for measurements, mu = ", mu_measured)
println("Fixed-mu measurement-sweep acceptance rate = ", acceptance_rate)
println("Largest corrected Green-function error = ", δG)
println("Runtime (seconds) = ", runtime)

green_signed_momentum_bins = measure_greens ?
    momentum_space_green_bins(
        green_signed_real_space_bins,
        unit_cell,
        lattice;
        copy_input=false,
    ) :
    nothing
tau_grid = [time_slice * Δτ for time_slice in 0:Lτ]
momentum_grid = [2pi * momentum_index / L for momentum_index in 0:(L - 1)]

sign_avg, sign_std = jdqmcm.jackknife(identity, avg_sign)
density_avg, density_std = jdqmcm.jackknife(/, density, avg_sign)
density_x_avg, density_x_std = jdqmcm.jackknife(/, density_x, avg_sign)
density_y_avg, density_y_std = jdqmcm.jackknife(/, density_y, avg_sign)
double_occ_avg, double_occ_std = jdqmcm.jackknife(
    /,
    double_occ,
    avg_sign,
)
double_occ_x_avg, double_occ_x_std = jdqmcm.jackknife(
    /,
    double_occ_x,
    avg_sign,
)
double_occ_y_avg, double_occ_y_std = jdqmcm.jackknife(
    /,
    double_occ_y,
    avg_sign,
)

altermagnetic_estimates = zeros(ComplexF64, length(ALTERMAGNETIC_FIELDS))
altermagnetic_standard_errors = zeros(Float64, length(ALTERMAGNETIC_FIELDS))
for column in eachindex(ALTERMAGNETIC_FIELDS)
    estimate, standard_error = jdqmcm.jackknife(
        /,
        view(altermagnetic_signed_bins, :, column),
        avg_sign,
    )
    altermagnetic_estimates[column] = estimate
    altermagnetic_standard_errors[column] = standard_error
end

println()
println("Average sign = ", real(sign_avg), " +/- ", sign_std)
println("Density per physical cell, n = ", real(density_avg), " +/- ", density_std)
target_compatible = nothing
if tune_mu
    density_residual = real(density_avg) - target_density
    # This is a validation label, not a convergence proof.  The small absolute
    # floor makes the deterministic U=0 check insensitive to roundoff.
    density_tolerance = max(2 * density_std, 1e-10)
    target_compatible = abs(density_residual) <= density_tolerance
    println(
        "Density residual, n - n_target = ",
        density_residual,
        " (target ",
        target_density,
        ")",
    )
    println(
        "Fixed-mu target check (within 2 standard errors) = ",
        target_compatible ? "TARGET_COMPATIBLE" : "NOT_AT_TARGET",
    )
    target_compatible || println(
        "WARNING: interpret the sign only at the reported mu, not at n_target",
    )
end
# This normalization is inferred from the density axis in Fig. 1; the paper
# does not write it explicitly in Eqs. (1)-(3).
doping_avg = (real(density_avg) - 2) / 4
doping_std = density_std / 4
println("Normalized doping, delta=(n-2)/4 = ", doping_avg, " +/- ", doping_std)
println("  d_xz density, n_x = ", real(density_x_avg), " +/- ", density_x_std)
println("  d_yz density, n_y = ", real(density_y_avg), " +/- ", density_y_std)
println(
    "Double occupancy summed over orbitals = ",
    real(double_occ_avg),
    " +/- ",
    double_occ_std,
)
println(
    "  d_xz double occupancy = ",
    real(double_occ_x_avg),
    " +/- ",
    double_occ_x_std,
)
println(
    "  d_yz double occupancy = ",
    real(double_occ_y_avg),
    " +/- ",
    double_occ_y_std,
)

altermagnetic_labels = (
    "d_xz magnetization per cell, m_x",
    "d_yz magnetization per cell, m_y",
    "Uniform orbital-averaged magnetization, m_fm",
    "Eq. 4 altermagnetic one-point order, Delta_alm",
    "Altermagnetic q=0 structure factor, S_alm(q=0)",
    "Altermagnetic squared moment, m_alm^2",
)
println()
for column in eachindex(ALTERMAGNETIC_FIELDS)
    println(
        altermagnetic_labels[column],
        " = ",
        real(altermagnetic_estimates[column]),
        " +/- ",
        altermagnetic_standard_errors[column],
    )
end
println(
    "Finite-size ordering diagnostic: use S_alm(q=0) and m_alm^2; ",
    "Delta_alm averages to zero without a symmetry-breaking field.",
)

basic_bins = Dict{String,Any}(
    "average_sign" => copy(avg_sign),
    "density" => copy(density),
    "density_x" => copy(density_x),
    "density_y" => copy(density_y),
    "double_occupancy" => copy(double_occ),
    "double_occupancy_x" => copy(double_occ_x),
    "double_occupancy_y" => copy(double_occ_y),
)
metadata = Dict{String,Any}(
    "U" => U,
    "beta" => β,
    "dtau" => Δτ,
    "L" => L,
    "Ltau" => Lτ,
    "mu_start" => μ,
    "mu_measured" => mu_measured,
    "target_density" => target_density,
    "target_compatible" => target_compatible,
    "t1" => t1,
    "t2" => t2,
    "t3" => t3,
    "t4" => t4,
    "seed" => seed,
    "stabilization_period" => n_stab,
    "tuning_sweeps" => N_tune,
    "burnin_sweeps" => N_burnin,
    "measurement_count" => N_measurements,
    "bin_count" => N_bins,
    "measurements_per_bin" => N_binsize,
    "greens_every" => measure_greens ? greens_every : nothing,
    "atomic_check" => atomic_check,
    "runtime_seconds" => runtime,
    "largest_equal_time_greens_error" => δG,
)
payload = build_observable_payload(
    metadata=metadata,
    tau=tau_grid,
    momenta=momentum_grid,
    basic_bins=basic_bins,
    altermagnetic_signed_bins=copy(altermagnetic_signed_bins),
    green_sign_sums=copy(green_sign_sums),
    green_counts=copy(green_counts),
    green_signed_momentum_bins=green_signed_momentum_bins,
    green_maximum_stabilization_errors=
        copy(green_maximum_stabilization_errors),
)
saved_path = save_observable_payload(output_path, payload)
println()
println("Saved observable data = ", saved_path)

if measure_greens
    trace_numerators = trace_green_channel(payload)
    trace_statistics = sign_reweighted_channel_statistics(
        trace_numerators,
        green_sign_sums,
        green_counts;
        minimum_average_sign=0.05,
    )
    continuation_ready =
        trace_statistics.full_denominator_usable &&
        trace_statistics.leave_one_out_denominators_usable &&
        maximum(green_maximum_stabilization_errors) <= 1e-8
    println("Unequal-time Green samples = ", sum(green_counts))
    println(
        "Unequal-time Green average sign = ",
        trace_statistics.full_average_sign,
    )
    println(
        "Largest unequal-time stabilization correction = ",
        maximum(green_maximum_stabilization_errors),
    )
    println("Analytic-continuation numerical eligibility = ",
        continuation_ready ? "ELIGIBLE" : "NOT_ELIGIBLE")
    println("Eligibility checks denominators and stabilization only; ",
        "production statistics and continuation robustness remain separate.")
end

if u0_check
    isapprox(real(sign_avg), 1.0; atol=100eps(Float64), rtol=0.0) || error(
        "U=0 validation failed: the average sign is not +1",
    )
    println("U=0 average-sign validation passed")

    if tune_mu
        # At U=0 the HS fields decouple, so this is a deterministic end-to-end
        # check of the tuner, propagator rescaling, and Green reconstruction.
        isapprox(
            real(density_avg),
            target_density;
            atol=1e-10,
            rtol=0.0,
        ) || error("U=0 density-tuning validation failed")
        println("U=0 density-tuning validation passed")
    end

    if measure_greens
        green_validation = validate_u0_green_payload(payload)
        println(
            "U=0 exact all-k/all-tau Green maximum error = ",
            green_validation.maximum_error,
        )
        println(
            "U=0 endpoint identity maximum error = ",
            green_validation.endpoint_error,
        )
        green_validation.passed || error(
            "U=0 unequal-time Green validation failed",
        )
        println("U=0 unequal-time Green validation passed")
    end
end
