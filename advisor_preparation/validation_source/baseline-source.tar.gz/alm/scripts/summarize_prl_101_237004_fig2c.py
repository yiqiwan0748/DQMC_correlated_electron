#!/usr/bin/env python3
"""Assemble the final Fig. 2(c) report from completed, independently audited data.

Uses only Python's standard library. This does not run a numerical solver,
fit the paper, substitute refined points for production, or infer completion
from partial files. The parent campaign owns the final artifact manifest.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile
import tomllib


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / "results/prl_101_237004/fig2c"
CURVES = ((-0.2, "r_minus_0p2", "numerical_audit_blue"),
          (-0.5, "r_minus_0p5", "numerical_audit_red"))
US = (0.5, 0.75, 1.0, 2.0, 4.0)
FREQUENCIES = (1e-5, 0.001, 0.01, 0.1, 1.0, 10.0)
ALLOWANCE = 0.002
SMOOTH_REFINEMENT_POINTS = {(-0.2, 0.75), (-0.2, 1.0), (-0.2, 2.0), (-0.5, 2.0), (-0.5, 4.0)}
QUADRATURE_COLUMNS = (
    "ratio", "U", "h", "production_order", "refined_order", "production_profile",
    "field_difference_method", "mu_refined", "mu_prime_refined", "Omega_refined",
    "F_refined", "density_refined", "mu_prime_gradient_refined", "moment_refined",
    "Omega_refined_minus_production", "F_refined_minus_production",
    "moment_refined_minus_production", "density_refined_minus_production",
    "h_gradient_step1e_4_refined", "h_gradient_change", "h_curvature_step1e_4_refined",
    "F_depth96_minus48", "moment_depth96_minus48", "density_depth96_minus48",
    "mu_prime_gradient_depth96_minus48", "center_refinement_method")


class ReportError(ValueError):
    """Missing, incomplete, or inconsistent final input."""


def number(row: dict, name: str) -> float:
    try:
        value = float(row[name])
    except (KeyError, TypeError, ValueError) as exc:
        raise ReportError(f"missing/non-numeric column {name!r}") from exc
    if not math.isfinite(value):
        raise ReportError(f"nonfinite {name}: {value}")
    return value


def boolean(row: dict, name: str) -> bool:
    value = str(row.get(name, "")).lower()
    if value not in ("true", "false"):
        raise ReportError(f"invalid boolean {name}: {value!r}")
    return value == "true"


def integer(row: dict, name: str) -> int:
    value = number(row, name)
    if not value.is_integer():
        raise ReportError(f"noninteger {name}: {value}")
    return int(value)


def same(a: float, b: float, description: str, atol: float = 1e-10) -> None:
    if not math.isfinite(a) or not math.isfinite(b) or abs(a - b) > atol:
        raise ReportError(f"{description} differs: {a} versus {b}")


def key(row: dict, u_column: str = "U") -> tuple[float, float]:
    r, u = number(row, "ratio"), number(row, u_column)
    matches = [(rr, uu) for rr, _, _ in CURVES for uu in US
               if abs(r - rr) <= 1e-12 and abs(u - uu) <= 1e-12]
    if len(matches) != 1:
        raise ReportError(f"unexpected Fig. 2(c) point r={r}, U={u}")
    return matches[0]


def indexed(rows: list[dict], u_column: str = "U") -> dict:
    result = {}
    for row in rows:
        point = key(row, u_column)
        if point in result:
            raise ReportError(f"duplicate point {point}")
        result[point] = row
    return result


class Inputs:
    def __init__(self, directory: Path):
        self.directory = directory
        self.hashes: dict[Path, str] = {}

    def path(self, name: str | Path) -> Path:
        path = Path(name)
        return path if path.is_absolute() else self.directory / path

    def require(self, names: list[str]) -> None:
        missing = [str(self.path(name)) for name in names if not self.path(name).is_file()]
        if missing:
            raise ReportError("required final inputs are missing:\n  " + "\n  ".join(missing))

    def read(self, name: str | Path) -> bytes:
        path = self.path(name)
        if not path.is_file():
            raise ReportError(f"required final input is missing: {path}")
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        old = self.hashes.setdefault(path, digest)
        if digest != old:
            raise ReportError(f"input changed while preparing report: {path}")
        return data

    def text(self, name: str | Path) -> str:
        return self.read(name).decode("utf-8")

    def csv(self, name: str | Path, required: tuple[str, ...] = ()) -> list[dict]:
        reader = csv.DictReader(io.StringIO(self.text(name)))
        names = reader.fieldnames or []
        if len(names) != len(set(names)) or any(n not in names for n in required):
            raise ReportError(f"missing/duplicate CSV columns in {name}")
        rows = list(reader)
        if any(None in row or any(v is None for v in row.values()) for row in rows):
            raise ReportError(f"malformed CSV row in {name}")
        return rows

    def toml(self, name: str | Path) -> dict:
        return tomllib.loads(self.text(name))

    def unchanged(self) -> None:
        for path, digest in self.hashes.items():
            if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise ReportError(f"input changed while preparing report: {path}")


def verify_output_marker(inputs: Inputs, marker_path: Path) -> dict:
    marker = inputs.toml(marker_path)
    hashes = marker.get("output_sha256")
    if not isinstance(hashes, dict) or not hashes:
        raise ReportError(f"empty output hash marker: {marker_path}")
    for name, expected in hashes.items():
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ReportError("unsafe output hash path")
        if hashlib.sha256(inputs.read(marker_path.parent / relative)).hexdigest() != expected:
            raise ReportError(f"output hash differs: {marker_path.parent / relative}")
    return marker


def load_smooth_refinement(inputs: Inputs, scans: dict) -> dict:
    """Read only a completed five-point audit; partial folders remain explicit."""
    folder = Path("original_field_refinement")
    if not inputs.path(folder).is_dir():
        return dict(status="absent", rows={})
    marker_path = folder / "completed.toml"
    if not inputs.path(marker_path).is_file():
        return dict(status="incomplete", rows={}, failed=inputs.path(folder / "failure.toml").is_file())
    marker = verify_output_marker(inputs, marker_path)
    if marker.get("completed_points") != 5 or marker.get("source_and_input_hashes_unchanged") is not True:
        raise ReportError("smooth-field audit lacks its five-point completion/hash guard")
    if not {"provenance.toml", "refinement_summary.csv"} <= set(marker["output_sha256"]):
        raise ReportError("smooth-field completion omits required summary/provenance hashes")
    provenance = inputs.toml(folder / "provenance.toml")
    sources = provenance.get("source_sha256", {})
    originals = provenance.get("input_sha256", {})
    if not sources or not originals:
        raise ReportError("smooth-field audit lacks source/input hashes")
    for name, sha in sources.items():
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ReportError("unsafe smooth-field source path")
        if hashlib.sha256(inputs.read(folder / "source_snapshot" / relative)).hexdigest() != sha:
            raise ReportError("smooth-field source snapshot hash differs")
    expected_inputs = set()
    for ratio, u in SMOOTH_REFINEMENT_POINTS:
        label = next(label for r, label, _ in CURVES if r == ratio)
        expected_inputs.update(f"runs/{label}/U{u}/{name}" for name in
                               ("result.csv", "provenance.txt", "completed.txt", "field_derivatives.csv"))
    if set(originals) != expected_inputs:
        raise ReportError("smooth-field audit does not retain the expected five production inputs")
    for name, sha in originals.items():
        for path in (Path(name), folder / "inputs" / name):
            if hashlib.sha256(inputs.read(path)).hexdigest() != sha:
                raise ReportError("smooth-field copied/current input hash differs")
    rows = indexed(inputs.csv(folder / "refinement_summary.csv"))
    if set(rows) != SMOOTH_REFINEMENT_POINTS:
        raise ReportError("smooth-field refinement must contain its five unique expected points")
    for point, row in rows.items():
        prod = scans[point]
        for field, column in (("production_h", "h"), ("production_moment_abs", "moment_abs_muB_per_Fe"),
                              ("production_F", "F_per_Fe")):
            same(number(row, field), number(prod, column), "smooth-field production value")
        summary_relative = Path(row["summary_path"])
        label = next(label for r, label, _ in CURVES if r == point[0])
        if summary_relative != Path("points") / f"{label}_U{point[1]}" / "summary.toml":
            raise ReportError("smooth-field summary path does not match its point")
        point_marker = verify_output_marker(inputs, folder / summary_relative.parent / "completed.toml")
        if "summary.toml" not in point_marker["output_sha256"]:
            raise ReportError("smooth-field point marker omits summary")
        summary = inputs.toml(folder / summary_relative)
        if summary.get("converged") is not True:
            raise ReportError("smooth-field point did not converge")
        for field in ("ratio", "U", "production_h", "refined_h", "h_change", "production_moment_abs",
                      "refined_moment_abs", "moment_abs_change", "production_F", "refined_F", "F_change",
                      "refined_density", "refined_mu_prime_gradient", "field_step", "quadrature_order",
                      "block_steps", "physical_L"):
            same(number(row, field), float(summary[field]), "smooth-field summary/CSV value")
        same(number(row, "refined_h_gradient"), float(summary["refined_gradient"]), "refined field gradient")
        for refined, original, difference in (("refined_h", "production_h", "h_change"),
                ("refined_moment_abs", "production_moment_abs", "moment_abs_change"),
                ("refined_F", "production_F", "F_change")):
            same(number(row, refined)-number(row, original), number(row, difference), "smooth-field recorded shift")
        same(number(row, "field_step"), 5e-5, "smooth-field step", 1e-14)
        if any(integer(row, field) != 48 for field in ("quadrature_order", "block_steps", "physical_L")) or \
           row["field_difference_method"] != "held_potential_Omega" or \
           summary.get("field_difference_method") != "held_potential_Omega":
            raise ReportError("unexpected smooth-field numerical method")
        if abs(number(row, "refined_h_gradient")) > 5.00001e-7 or \
           abs(number(row, "refined_density")-2) > 2.00001e-10 or \
           abs(number(row, "refined_mu_prime_gradient")) > 2.00001e-10:
            raise ReportError("smooth-field point fails its stated refined residual criteria")
        lo, hi = summary["initial_bracket_gradients"]
        if not lo < 0 < hi:
            raise ReportError("smooth-field refinement lacks its negative-to-positive bracket")
    return dict(status="complete", rows=rows)


def load_final_inputs(inputs: Inputs) -> dict:
    required = ["plots/fig2c_comparison.csv", "plots/provenance.txt",
                "plots/fig2c_staggered_moment.png", "plots/fig2c_reference_difference.png",
                "selected_U4_blue_audit/summary.toml", "selected_U4_blue_audit/completed.toml",
                "selected_U4_blue_audit/field_refinement/summary.toml",
                "selected_U4_blue_audit/field_refinement/completed.toml",
                "lowU_reference_pilot/summary.toml", "lowU_reference_pilot/same_N_spin_comparison.csv",
                "lowU_blue_reference_pilot/summary.toml",
                "validation/validation.txt"]
    for _, label, audit in CURVES:
        required += [f"scans/{label}.csv", f"{audit}/completed.txt",
                     f"{audit}/quadrature_and_field.csv", f"{audit}/green_depth.csv",
                     f"{audit}/reference_sectors.csv", f"{audit}/provenance.txt"]
    inputs.require(required)
    scans = {}
    for ratio, label, _ in CURVES:
        rows = inputs.csv(f"scans/{label}.csv", ("ratio", "U", "h", "density", "mu_prime_gradient"))
        if len(rows) != 5 or set(indexed(rows)) != {(ratio, u) for u in US}:
            raise ReportError(f"{label} must have the five completed nominal U points")
        scans.update(indexed(rows))
    comparisons = indexed(inputs.csv("plots/fig2c_comparison.csv"), "U_nominal")
    if set(comparisons) != set(scans):
        raise ReportError("plot comparison does not cover exactly the ten production points")
    diagnostics = {}
    all_green = []
    for ratio, label, audit in CURVES:
        completion = inputs.text(f"{audit}/completed.txt")
        if "Completed" not in completion or "audited points=5" not in completion:
            raise ReportError(f"{audit} lacks its five-point completion record")
        inputs.read(f"{audit}/provenance.txt")
        aggregate_manifest = inputs.path(f"{audit}/output_sha256.json")
        if aggregate_manifest.is_file():
            hashes = json.loads(inputs.text(aggregate_manifest))
            if not isinstance(hashes, dict) or not hashes:
                raise ReportError("empty aggregate audit hash manifest")
            for name, expected_hash in hashes.items():
                relative = Path(name)
                if relative.is_absolute() or ".." in relative.parts:
                    raise ReportError("unsafe aggregate audit manifest path")
                if hashlib.sha256(inputs.read(Path(audit) / relative)).hexdigest() != expected_hash:
                    raise ReportError(f"aggregate audit output hash differs: {audit}/{name}")
            aggregation = json.loads(inputs.text(f"{audit}/aggregation.json"))
            if set(indexed(aggregation.get("points", []))) != {(ratio, u) for u in US}:
                raise ReportError("aggregate point-to-batch map does not cover its five points")
        quad = indexed(inputs.csv(f"{audit}/quadrature_and_field.csv", QUADRATURE_COLUMNS))
        sector_summary = indexed(inputs.csv(f"{audit}/reference_sectors.csv"))
        expected = {(ratio, u) for u in US}
        if set(quad) != expected or set(sector_summary) != expected:
            raise ReportError(f"{audit} does not cover its five production points")
        green = inputs.csv(f"{audit}/green_depth.csv")
        seen = set()
        for row in green:
            point = key(row)
            if point not in expected or row.get("spin") not in ("up", "down"):
                raise ReportError(f"unexpected Green-depth point in {audit}")
            same(number(row, "h"), number(scans[point], "h"), "Green-audited field")
            omega = number(row, "omega")
            if omega not in FREQUENCIES:
                raise ReportError(f"unexpected audit frequency {omega}")
            item = (*point, row["spin"], omega)
            if item in seen:
                raise ReportError("duplicate Green-depth probe")
            seen.add(item)
            number(row, "Green_norm_difference")
            number(row, "Green_relative_difference")
            all_green.append(row)
        if len(seen) != 60:
            raise ReportError(f"{audit} needs both spins and six frequencies at each point")
        for point in expected:
            prod, q, s = scans[point], quad[point], sector_summary[point]
            _, u = point
            h, mu, mup = (number(prod, n) for n in ("h", "mu", "mu_prime"))
            same(number(q, "h"), h, "audited field")
            same(number(s, "h"), h, "sector-audited field")
            same(number(s, "mu_prime"), mup, "sector-audited reference potential")
            for column in QUADRATURE_COLUMNS:
                if column not in ("production_profile", "field_difference_method", "center_refinement_method"):
                    number(q, column)
            original = q["production_profile"] == "original"
            if q["production_profile"] not in ("original", "low_frequency"):
                raise ReportError("unknown production integration profile")
            expected_method = "held_potential_Omega" if original else "refilled_canonical_F"
            if q["field_difference_method"] != expected_method:
                raise ReportError("integration profile and field-difference method disagree")
            expected_center = "fixed_relative_d" if original else "refilled_stationary_solution"
            if q["center_refinement_method"] != expected_center:
                raise ReportError("integration profile and center-refinement method disagree")
            if integer(q, "production_order") != integer(prod, "quadrature_order") or \
               integer(q, "refined_order") != 2 * integer(q, "production_order"):
                raise ReportError("audit must double the recorded production order")
            for refined_column, production_column, difference_column in (
                ("Omega_refined", "Omega_per_Fe", "Omega_refined_minus_production"),
                ("F_refined", "F_per_Fe", "F_refined_minus_production"),
                ("moment_refined", "moment_signed_muB_per_Fe", "moment_refined_minus_production"),
                ("density_refined", "density", "density_refined_minus_production"),
                ("h_gradient_step1e_4_refined", "h_derivative", "h_gradient_change")):
                same(number(q, refined_column) - number(prod, production_column),
                     number(q, difference_column), f"audit {difference_column}")
            same(number(q, "F_refined"), number(q, "Omega_refined") + 2 * number(q, "mu_refined"),
                 "refined canonical F", 1e-9)
            if original:
                same(number(q, "mu_prime_refined") - number(q, "mu_refined"), mup - mu,
                     "refined relative chemical potential", 1e-9)
            folder = f"{audit}/sectors/{label}_U{u}"
            meta = inputs.toml(f"{folder}/metadata.toml")
            sectors = inputs.csv(f"{folder}/sectors.csv")
            if len(sectors) != 81 or meta.get("sector_count") != 81:
                raise ReportError(f"{folder} needs all 81 spin/particle sectors")
            states = {}
            for sr in sectors:
                nu, nd, n = (integer(sr, x) for x in ("Nup", "Ndown", "N"))
                if not 0 <= nu <= 8 or not 0 <= nd <= 8 or n != nu + nd or (nu, nd) in states:
                    raise ReportError(f"invalid sector census in {folder}")
                if number(sr, "dimension") != math.comb(8, nu) * math.comb(8, nd):
                    raise ReportError(f"sector dimension differs in {folder}")
                number(sr, "energy_canonical"); number(sr, "direct_residual")
                states[nu, nd] = sr
            target = number(states[4, 4], "energy_canonical")
            lower = max((target - number(sr, "energy_canonical")) / (8 - number(sr, "N"))
                        for sr in states.values() if number(sr, "N") < 8)
            upper = min((number(sr, "energy_canonical") - target) / (number(sr, "N") - 8)
                        for sr in states.values() if number(sr, "N") > 8)
            same(lower, float(meta["mu_lower"]), "independent all-N lower bound")
            same(upper, float(meta["mu_upper"]), "independent all-N upper bound")
            same(target, float(meta["target_energy_canonical"]), "target reference energy")
            same(max(number(sr, "direct_residual") for sr in states.values()),
                 number(s, "max_sector_residual"), "maximum sector residual")
            same_n_lowest = all(number(sr, "energy_canonical") >= target - 1e-9
                               for sr in states.values() if number(sr, "N") == 8)
            if same_n_lowest != boolean(s, "target_lowest_at_same_N"):
                raise ReportError("same-N reference-ground classification differs")
            for name, value in (("ratio", ratio), ("U", u), ("h", h), ("mu", mu), ("mu_prime", mup)):
                same(float(meta["physical_metadata"][name]), value, f"sector metadata {name}")
            margin = min(number(sr, "energy_canonical") - number(sr, "N") * mup - (target - 8 * mup)
                         for pair, sr in states.items() if pair != (4, 4))
            same(margin, number(s, "minimum_competing_grand_energy_margin"), "sector grand-energy margin", 2e-9)
            same(meta["mu_lower"], number(s, "all_N_mu_lower"), "all-N lower bound")
            same(meta["mu_upper"], number(s, "all_N_mu_upper"), "all-N upper bound")
            for name, value in (("U", u), ("J", u / 4)):
                same(float(meta[name]), value, f"{folder} {name}")
            pd = f"runs/{label}/U{u}"
            resolved_source = inputs.path(f"{pd}/source_snapshot/scripts/run_prl_101_237004_fig2c_resolved.jl")
            if resolved_source.is_file() == original:
                raise ReportError("audit profile disagrees with selected point's driver snapshot")
            inputs.read(f"{pd}/provenance.txt")
            if "Completed" not in inputs.text(f"{pd}/completed.txt"):
                raise ReportError(f"missing completed production point {pd}")
            actual = inputs.csv(f"{pd}/result.csv")
            if len(actual) != 1 or actual[0] != prod:
                raise ReportError(f"assembled scan differs from its selected point {pd}")
            field_rows = inputs.csv(f"{pd}/field_derivatives.csv")
            selected = [r for r in field_rows if abs(number(r, "h") - h) < 1e-12]
            if len(selected) != 1:
                raise ReportError(f"missing unique selected field derivative in {pd}")
            side_column = "left_Omega" if original else "left_F"
            if side_column not in selected[0]:
                raise ReportError("production side-value columns disagree with audited derivative method")
            same(number(selected[0], "gradient"), number(prod, "h_derivative"), "production field derivative")
            diagnostics[point] = dict(q=q, sector=s, margin=margin, sector_metadata=meta,
                                      production_curvature=number(selected[0], "curvature"),
                                      production_step=number(selected[0], "step"), audit_directory=audit)
    for point, prod in scans.items():
        c = comparisons[point]
        ratio, u = point
        for column, expected in (("J", u / 4), ("physical_L", 48)):
            same(number(prod, column), expected, f"production {column}")
        mappings = (("moment_abs_muB_per_Fe", "moment_VCA_muB_per_Fe"),
                    ("h", "h"), ("mu", "mu"), ("mu_prime", "mu_prime"),
                    ("density", "density"), ("mu_prime_gradient", "mu_prime_gradient"),
                    ("h_derivative", "h_derivative"), ("F_per_Fe", "F_per_Fe"))
        for pcol, ccol in mappings:
            same(number(prod, pcol), number(c, ccol), f"comparison {pcol}")
        if prod["stationarity_status"] != c["stationarity_status"]:
            raise ReportError("plot and production status differ")
        expected_method = ("central_Omega_held_mu_mu_prime"
                           if diagnostics[point]["q"]["field_difference_method"] == "held_potential_Omega"
                           else "central_F_resolved_half_filling_mu_prime")
        if c.get("field_difference_method") != expected_method:
            raise ReportError("plot and numerical audit field methods disagree")
        m = number(prod, "moment_abs_muB_per_Fe")
        same(m, abs(number(prod, "moment_signed_muB_per_Fe")), "moment magnitude")
        same(number(prod, "F_per_Fe"), number(prod, "Omega_per_Fe") + 2 * number(prod, "mu"), "canonical F", 1e-9)
        same(number(c, "moment_vertical_extraction_allowance"), ALLOWANCE, "vertical extraction allowance", 1e-12)
        diff = m - number(c, "moment_published_muB_per_Fe")
        same(diff, number(c, "moment_difference_muB_per_Fe"), "raw moment difference")
        if boolean(c, "within_vertical_allowance") != (abs(diff) <= ALLOWANCE):
            raise ReportError("comparison count does not use the raw vertical difference")
        if abs(u - number(c, "U_reference_digitized")) > number(c, "U_extraction_allowance"):
            raise ReportError("nominal U lies outside its stated horizontal extraction allowance")
        if abs(number(prod, "density") - 2) > 1.00001e-7 or abs(number(prod, "mu_prime_gradient")) > 1.00001e-7:
            raise ReportError("a production point fails its recorded filling/stationarity criteria")
        if abs(number(prod, "h_derivative")) > 2.1e-6:
            raise ReportError("a production point exceeds the declared field-derivative reader limit")
        if prod["stationarity_status"] not in ("magnetic_minimum", "paramagnetic_minimum"):
            raise ReportError("unresolved production status")
    validation = inputs.text("validation/validation.txt")
    if not re.search(r"exit\s+code\s+0\b", validation, re.I):
        raise ReportError("final validation does not record exit code 0")
    count = re.search(r"Passing assertions:\s*([\d,]+)(?:\s+in\s+([\d,]+)\s+test sets)?", validation)
    if not count:
        raise ReportError("final validation lacks its passing-assertion count")
    weak, weak_status = [], None
    status_path = inputs.path("weak_mesh_audit/status.toml")
    if status_path.is_file():
        weak_status = inputs.toml(status_path)
        if weak_status.get("status") not in ("completed", "not_run", "blocked"):
            raise ReportError("unknown explicit weak-mesh status")
        if any(not str(weak_status.get(name, "")).strip() for name in ("scope", "reason")):
            raise ReportError("explicit weak-mesh status requires scope and reason")
    if weak_status is None or weak_status["status"] == "completed":
        weak = inputs.csv("weak_mesh_audit/weak_mesh_summary.csv", (
            "ratio", "U", "h", "baseline_L", "audit_L", "frequency_profile",
            "field_derivative_policy", "baseline_occupation_policy", "L96_occupation_policy",
            "fixed_variable_status", "filling_resolved", "L96_mu", "L96_mu_prime",
            "L96_F", "L96_density", "L96_mu_prime_gradient", "L96_moment_abs",
            "refilled_moment_difference", "L96_h_derivative_step2e4", "L96_h_derivative_step1e4",
            "L96_zero_curvature", "L96_energy_gain", "q48_q96_F_difference",
            "q48_q96_moment_difference", "nearby_status", "nearby_h", "nearby_moment_abs",
            "nearby_h_derivative", "complete_status", "limits"))
        if not weak or "Completed" not in inputs.text("weak_mesh_audit/completed.txt"):
            raise ReportError("weak-mesh audit is incomplete")
        inputs.read("weak_mesh_audit/provenance.txt")
        for row in weak:
            point = key(row)
            same(number(row, "h"), number(scans[point], "h"), "weak-mesh production field")
            if row["complete_status"] != "complete" or not boolean(row, "filling_resolved"):
                raise ReportError("weak-mesh canonical filling comparison is incomplete")
            if (integer(row, "baseline_L"), integer(row, "audit_L")) != (48, 96):
                raise ReportError("unexpected weak-point momentum meshes")
            if row["field_derivative_policy"] != "refilled_canonical_F" or \
               row["frequency_profile"] != "refined_low_frequency":
                raise ReportError("unexpected weak-point quadrature or field method")
            for name in ("L96_mu", "L96_mu_prime", "L96_F", "L96_density",
                         "L96_mu_prime_gradient", "L96_moment_abs", "refilled_moment_difference",
                         "L96_h_derivative_step2e4", "L96_h_derivative_step1e4", "L96_zero_curvature",
                         "L96_energy_gain", "q48_q96_F_difference", "q48_q96_moment_difference",
                         "nearby_h", "nearby_moment_abs", "nearby_h_derivative"):
                number(row, name)
            fixed_names = ("fixed_variable_moment_difference", "fixed_variable_density_difference",
                           "fixed_variable_gradient_difference")
            if row["fixed_variable_status"] == "integer_policy_fixed_potentials":
                for name in fixed_names:
                    number(row, name)
            elif row["fixed_variable_status"] == "not_evaluated_degenerate_occupation_policy":
                for name in fixed_names:
                    if str(row.get(name, "")).lower() != "nan":
                        raise ReportError("undefined fixed-potential comparison must be marked NaN")
            else:
                raise ReportError("unknown weak-mesh fixed-potential comparison status")
    selected = inputs.toml("selected_U4_blue_audit/summary.toml")
    correction = inputs.toml("selected_U4_blue_audit/field_refinement/summary.toml")
    if not correction.get("converged", False):
        raise ReportError("selected U4 field refinement is incomplete")
    same(float(selected["h"]), number(scans[-0.2, 4.0], "h"), "selected U4 audit point")
    same(float(selected["moment_original"]), number(scans[-0.2, 4.0], "moment_signed_muB_per_Fe"), "selected U4 audit moment")
    red_zero = inputs.toml("lowU_reference_pilot/summary.toml")
    blue_zero = inputs.toml("lowU_blue_reference_pilot/summary.toml")
    zero_spin = inputs.csv("lowU_reference_pilot/same_N_spin_comparison.csv")
    spin_gap = min(number(r, "energy_above_same_N_minimum") for r in zero_spin if abs(number(r, "Sz")) == 1)
    inputs.read("plots/provenance.txt")
    inputs.read(ROOT / "docs/prl_101_237004_fig2c_method.md")
    for path in ("selected_U4_blue_audit/completed.toml", "selected_U4_blue_audit/field_refinement/completed.toml"):
        marker = inputs.toml(path)
        folder = Path(path).parent
        for name, expected in marker.get("output_sha256", {}).items():
            if hashlib.sha256(inputs.read(folder / name)).hexdigest() != expected:
                raise ReportError(f"selected-point output hash differs: {folder / name}")
    smooth = load_smooth_refinement(inputs, scans)
    return dict(scans=scans, comparisons=comparisons, diagnostics=diagnostics, green=all_green,
                validation=validation, test_count=int(count[1].replace(",", "")),
                test_sets=int(count[2].replace(",", "")) if count[2] else None,
                weak=weak, weak_status=weak_status, selected=selected, correction=correction, red_zero=red_zero,
                blue_zero=blue_zero, red_spin_gap=spin_gap, smooth_refinement=smooth)


def fmt(value: float) -> str:
    return f"{value:.6g}"


def cell(value) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def render_smooth_refinement(audit: dict, comparisons: dict, inputs: Inputs, output: Path) -> list[str]:
    link_path = Path(os.path.relpath(inputs.path("original_field_refinement/refinement_summary.csv"), output.parent)).as_posix()
    if audit["status"] == "absent":
        return ["The separate five-point refinement of the other original smooth solutions is not available; no re-optimized moment shifts are inferred from their fixed-field checks.", ""]
    if audit["status"] == "incomplete":
        detail = " A failure record is present." if audit.get("failed") else ""
        return ["**The five-point original-field refinement is incomplete.** Its directory exists without the full completion marker; provisional rows are excluded from this report." + detail, ""]
    rows = audit["rows"]
    lines = ["The separate [five-point field refinement](" + link_path + ") re-optimizes the other original smooth solutions. It uses q48 on the expanded frequency partition, physical L48, block depth48, and field step5×10⁻⁵. Every center re-solves filling and μ′ stationarity; held-potential Ω sides must remain in zero-mismatch integer occupation intervals. A negative-to-positive derivative bracket and a 5×10⁻⁷ residual support a nearby minimum. This tests the local moment response to field refinement, beyond evaluating integration or depth changes at the original h.", "",
             "| r | U | Field shift | Magnitude shift (μB/Fe) | Production difference from paper | Refined difference from paper | Within ±0.002: production→refined |",
             "|---:|---:|---:|---:|---:|---:|:---|"]
    for point, row in sorted(rows.items(), reverse=True):
        comp = comparisons[point]
        production_difference = number(comp, "moment_difference_muB_per_Fe")
        refined_difference = number(row, "refined_moment_abs") - number(comp, "moment_published_muB_per_Fe")
        before = "yes" if abs(production_difference) <= ALLOWANCE else "no"
        after = "yes" if abs(refined_difference) <= ALLOWANCE else "no"
        lines.append(f"| {point[0]:g} | {point[1]:g} | {number(row,'h_change'):+.7g} | {number(row,'moment_abs_change'):+.7g} | {production_difference:+.8f} | {refined_difference:+.8f} | {before}→{after} |")
    edge_point = (-0.2, 2.0)
    edge_before = number(comparisons[edge_point], "moment_difference_muB_per_Fe")
    edge_after = number(rows[edge_point], "refined_moment_abs") - number(comparisons[edge_point], "moment_published_muB_per_Fe")
    max_shift = max(abs(number(row, "moment_abs_change")) for row in rows.values())
    max_gradient = max(abs(number(row, "refined_h_gradient")) for row in rows.values())
    lines += ["", f"Across these five local refinements, the largest magnitude change is {max_shift:.7g} μB/Fe and the largest refined field residual is {max_gradient:.7g}. Blue U=2 changes its raw ordinate difference from {edge_before:+.8f} to {edge_after:+.8f} μB/Fe; the refined value is {'inside' if abs(edge_after)<=ALLOWANCE else 'outside'} the ±0.002 graphics band. No horizontal uncertainty is folded into either classification. The main ten-point table and its production comparison count are unchanged. These local checks do not certify a global or thermodynamic minimum.", ""]
    return lines


def interpret_weak_mesh(row: dict) -> list[str]:
    """Interpret validated fixed-field and nearby-search records separately."""
    final_moment = number(row, "L96_moment_abs")
    change = number(row, "refilled_moment_difference")
    baseline = final_moment-change
    relative = f" ({100*change/baseline:+.3f}%)" if abs(baseline)>1e-14 else ""
    text = (f"At r={number(row,'ratio'):g}, U={number(row,'U'):g}, re-solving filling at the saved field "
            f"h={number(row,'h'):.9g} changes the moment from {baseline:.9f} on L{integer(row,'baseline_L')} "
            f"to {final_moment:.9f} μB/Fe on L{integer(row,'audit_L')}: {change:+.7g} μB/Fe{relative}. "
            f"The q48→96 moment change is {number(row,'q48_q96_moment_difference'):+.6g} μB/Fe. "
            f"The L96 field derivatives at steps 2×10⁻⁴ and 10⁻⁴ are {number(row,'L96_h_derivative_step2e4'):.7g} "
            f"and {number(row,'L96_h_derivative_step1e4'):.7g}; the zero-field curvature is "
            f"{number(row,'L96_zero_curvature'):.7g}, and the saved-field energy gain over zero field is "
            f"{number(row,'L96_energy_gain'):.8g} per Fe.")
    if row["fixed_variable_status"] == "not_evaluated_degenerate_occupation_policy":
        text += " The fixed-potential comparison is undefined for its recorded occupation policy; the quoted mesh change uses refilled canonical solutions."
    status = row["nearby_status"]
    if status == "nearby_stationarity_resolved":
        nearby = (f"A bounded nearby search reaches h={number(row,'nearby_h'):.9g}, "
                  f"|m|={number(row,'nearby_moment_abs'):.9f} μB/Fe, with field derivative "
                  f"{number(row,'nearby_h_derivative'):.7g}. This is a local stationary-point check, "
                  "not a global or thermodynamic minimum certificate. The mesh change quoted above remains the comparison at the saved h.")
    elif status == "not_triggered":
        nearby = "No nearby field re-optimization was triggered. The L96 moment and mesh change quoted above are the refilled comparison at the saved h, not an independently located L96 minimum."
    else:
        label = "only a local estimate" if status == "local_estimate_only" else f"status `{cell(status)}`"
        nearby = (f"**The bounded nearby search established {label}, not a converged re-optimized L96 minimum.** "
                  f"Its last estimate has h={number(row,'nearby_h'):.9g}, |m|={number(row,'nearby_moment_abs'):.9f} μB/Fe, "
                  f"and field derivative {number(row,'nearby_h_derivative'):.7g}. The reported mesh shift therefore applies "
                  "at the saved h; it does not supply a corrected minimum or a thermodynamic error bound.")
    return [text, "", nearby, ""]


def render_report(data: dict, inputs: Inputs, output: Path) -> str:
    scans, comparisons, diag = data["scans"], data["comparisons"], data["diagnostics"]
    points = [(ratio, u) for ratio, _, _ in CURVES for u in US]
    link = lambda label, path: f"[{label}]({Path(os.path.relpath(inputs.path(path), output.parent)).as_posix()})"
    inside = sum(boolean(comparisons[p], "within_vertical_allowance") for p in points)
    lines = ["# PRL 101, 237004: Figure 2(c)", ""]
    if inside < 10:
        lines += [f"**The ten moments have been calculated, but Figure 2(c) is not quantitatively reproduced within the stated vertical extraction allowance: {inside}/10 raw differences lie within ±0.002 μB/Fe.**", ""]
    else:
        lines += ["**All 10 raw moment differences lie within the stated ±0.002 μB/Fe vertical extraction allowance.** This pointwise graphics comparison is not a proof that all numerical choices reproduce the authors' procedure.", ""]
    lines += ["The calculation uses the original printed Slater–Koster hoppings and full PRL interaction, with `J=U/4`, an open four-Fe `2×2` reference, and a `48×48` physical momentum mesh. No fitted scale, offset, parameter adjustment, or replacement by an audit value is applied to the production table.", "",
              "The comparison uses the inferred nominal U values. Horizontal graphics uncertainty is retained separately and is **not folded into** the ±0.002 ordinate count. That allowance is neither solver error nor an estimate of the authors' numerical error.", "",
              "![Published and calculated moments](" + Path(os.path.relpath(inputs.path("plots/fig2c_staggered_moment.png"), output.parent)).as_posix() + ")", "",
              "| r | U | h | Calculated magnitude (μB/Fe) | Published m | Raw difference | Within ±0.002 | Selected state |",
              "|---:|---:|---:|---:|---:|---:|:---:|:---|"]
    for point in points:
        p, c = scans[point], comparisons[point]
        r, u = point
        status = "finite stripe field" if p["stationarity_status"] == "magnetic_minimum" else "zero-field candidate"
        lines.append(f"| {r:g} | {u:g} | {number(p,'h'):.8g} | {number(c,'moment_VCA_muB_per_Fe'):.7f} | {number(c,'moment_published_muB_per_Fe'):.7f} | {number(c,'moment_difference_muB_per_Fe'):+.7f} | {'yes' if boolean(c,'within_vertical_allowance') else 'no'} | {status} |")
    lines += ["", link("The comparison CSV", "plots/fig2c_comparison.csv") + " retains the nominal and digitized U, both extraction allowances, both moments, and complete production variables. Lines in the plot only connect calculated samples; there is no extrapolation below U=0.5.", "",
              "The PRL warns of numerical instability at small U for r=−0.2 without specifying its boundary. The r=−0.5 source ordinate at U=0.5 is compatible with zero at extraction precision. These statements do not supply missing values or locate an exact critical U.", "",
              "## Stationarity and numerical checks", "",
              "Each production center enforces n=2 and reference-potential stationarity. Field energies are compared using F=Ω+2μ per Fe, because physical μ can vary between centers. Original points use held-potential Ω side differences; resolved-driver points re-solve filling at both sides and difference canonical F. The method is recorded separately for every point below. At a smooth constrained center both approaches estimate the same envelope derivative; a finite-mesh partially occupied Fermi shell requires the canonical treatment. See " + link("the method and its limits", ROOT / "docs/prl_101_237004_fig2c_method.md") + ".", "",
              "For an unresolved integer occupation jump, the resolved solver brackets the Fermi shell and forms its canonical fractional-occupation ensemble. Where two Fermi groups meet at a relative-potential cusp, acceptance also requires coalescing potentials, a shrinking bracket, continuity of canonical F, and stationary ensemble residuals; choosing one limiting group alone can give a different moment. Frequency integration has extra intervals near zero to resolve the limiting poles. This finite-mesh prescription and the nearby-branch search are implementation choices, not a reconstruction of an undocumented procedure in the paper.", ""]
    metrics = [
        ("Production max |n−2|", max(abs(number(p,"density")-2) for p in scans.values())),
        ("Production max |∂Ω/∂μ′|", max(abs(number(p,"mu_prime_gradient")) for p in scans.values())),
        ("Production max |h derivative|, step 2×10⁻⁴", max(abs(number(p,"h_derivative")) for p in scans.values())),
        ("Max refined minus production canonical F per Fe", max(abs(number(d["q"],"F_refined_minus_production")) for d in diag.values())),
        ("Max refined minus production signed moment", max(abs(number(d["q"],"moment_refined_minus_production")) for d in diag.values())),
        ("Max refined minus production density", max(abs(number(d["q"],"density_refined_minus_production")) for d in diag.values())),
        ("Max refined |n−2|", max(abs(number(d["q"],"density_refined")-2) for d in diag.values())),
        ("Max refined |∂Ω/∂μ′|", max(abs(number(d["q"],"mu_prime_gradient_refined")) for d in diag.values())),
        ("Max depth48→96 canonical F change", max(abs(number(d["q"],"F_depth96_minus48")) for d in diag.values())),
        ("Max depth48→96 signed-moment change", max(abs(number(d["q"],"moment_depth96_minus48")) for d in diag.values())),
        ("Max final-frequency depth48→96 Green Frobenius difference", max(number(r,"Green_norm_difference") for r in data["green"])),
        ("Max reference-sector direct eigenpair residual", max(number(d["sector"],"max_sector_residual") for d in diag.values())),
        ("Max independent reference ground-energy difference", max(abs(number(d["sector"],"target_E0_difference")) for d in diag.values())),
        ("Minimum competing reference grand-energy margin", min(d["margin"] for d in diag.values())),
    ]
    lines += ["| Check | Observed value |", "|:---|---:|"]
    lines += [f"| {label.replace('|', '&#124;')} | {fmt(value)} |" for label, value in metrics]
    orders = sorted({int(number(p,"quadrature_order")) for p in scans.values()})
    depths = sorted({int(number(p,"block_steps")) for p in scans.values()})
    stable = sum(d["margin"] >= -1e-9 and boolean(d["sector"],"target_lowest_at_same_N") for d in diag.values())
    lines += ["", f"Recorded production quadrature orders: {orders}; block-Krylov depths: {depths}. All final integration audits use the low-frequency partition and twice the production order. The original points therefore undergo both order doubling and a partition change; their center evaluation holds d=μ′−μ fixed and measures the resulting stationarity residual. Resolved points retain their partition and re-solve filling and μ′ stationarity, including the required ensemble treatment. The actual refined μ and μ′ are recorded in the audit CSV. Canonical F is the meaningful energy comparison when the common potential moves.", "",
              f"The independent final-point audits check both spin Green matrices at six production-μ′ imaginary frequencies from 10⁻⁵ to 10, and all 81 reference particle/spin sectors at each of the ten points: **{stable}/10 selected references have no lower computed competing sector within 10⁻⁹**. This totals 810 sector calculations; small residuals alone do not rigorously certify the lowest eigenvalue. A finite Green probe grid is not a uniform frequency error bound.", "",
              "The original h-search tolerance is 2×10⁻⁶ at step 2×10⁻⁴; filling and μ′ residual acceptance is 10⁻⁷. Refined field derivatives below remain separate diagnostics and are not silently substituted for production values.", "",
              "| r | U | Order change / production profile | Field method | Search h derivative | Refined derivative, step 10⁻⁴ | Refined curvature | Reference grand-energy margin |",
              "|---:|---:|:---|:---|---:|---:|---:|---:|"]
    for point in points:
        p, d = scans[point], diag[point]
        q = d["q"]
        profile = "original" if q["production_profile"] == "original" else "low frequency"
        method = "held Ω" if q["field_difference_method"] == "held_potential_Omega" else "refilled F"
        lines.append(f"| {point[0]:g} | {point[1]:g} | {integer(q,'production_order')}→{integer(q,'refined_order')} / {profile} | {method} | {fmt(number(p,'h_derivative'))} | {fmt(number(q,'h_gradient_step1e_4_refined'))} | {fmt(number(q,'h_curvature_step1e_4_refined'))} | {fmt(d['margin'])} |")
    above_threshold = sum(abs(number(d["q"], "h_gradient_step1e_4_refined")) > 2e-6 for d in diag.values())
    lines += ["", f"**{above_threshold}/10 refined field derivatives exceed the original 2×10⁻⁶ production threshold** after changing the integration and halving the field step. Audit completion therefore does not mean that every field-step check passes that threshold. Small integration/depth moment changes evaluated at the original h do not bound the moment change after re-optimizing h.", ""]
    lines += ["", "The curvature column follows the recorded field method: partial Ωhh for held potentials, constrained F curvature for refilled sides. An interior partial Ωhh is not the curvature after both chemical potentials relax. Interior minima are assessed with negative-to-positive constrained derivative brackets. At a smooth spin-symmetric h=0 solution the mixed derivatives vanish; the following comparison checks whether its curvature sign survives the step refinement. Across a finite-mesh occupation change the resolved driver instead checks canonical F directly.", ""]
    zero_points = [p for p in points if scans[p]["stationarity_status"] == "paramagnetic_minimum"]
    if zero_points:
        lines += ["| Zero-field candidate | Curvature at step 2×10⁻⁴ | Refined curvature at step 10⁻⁴ | Sign check |", "|:---|---:|---:|:---|"]
        for point in zero_points:
            d = diag[point]
            first, second = d["production_curvature"], number(d["q"],"h_curvature_step1e_4_refined")
            status = "positive at both sampled steps" if first > 0 and second > 0 else "unresolved: positivity does not survive"
            lines.append(f"| r={point[0]:g}, U={point[1]:g} | {fmt(first)} | {fmt(second)} | {status} |")
    else:
        lines.append("No final production point selected h=0.")
    lines += ["", "Zero moment alone is not evidence of stability. These calculations search the stripe channel on a finite field grid and one nearby filling branch; they can miss narrow wells or other stationary μ′ branches and do not establish a complete magnetic phase diagram.", "",
              "## Selected momentum-mesh and field refinements", ""]
    selected, corrected = data["selected"], data["correction"]
    residual_gap = float(corrected["refined_moment_abs"]) - number(comparisons[-0.2,4.0], "moment_published_muB_per_Fe")
    lines += [f"For r=−0.2, U=4, q24→48 changes the moment by {fmt(float(selected['moment_q48_minus_q24']))}; depth48→96 changes it by {fmt(float(selected['moment_depth96_minus48']))}; physical L48→96 at fixed reference and potentials changes it by {fmt(float(selected['mesh_moment_change_fixed_variables']))} μB/Fe. The mesh density change is {fmt(float(selected['mesh_density_change_fixed_variables']))}, and the μ′-gradient change is {fmt(float(selected['mesh_gradient_change_fixed_variables']))}. " + ("Filling was re-solved on L96." if selected["mesh_filling_resolved"] else "The measured residual shift did not trigger an L96 filling re-solve."), "",
              f"A separate q48, step5×10⁻⁵ constrained field search, with filling re-solved at every center, gives h={float(corrected['refined_h']):.12g} and |m|={float(corrected['refined_moment_abs']):.10f}. The moment-magnitude change is {float(corrected['refined_moment_abs'])-number(scans[-0.2,4.0],'moment_abs_muB_per_Fe'):+.6g} μB/Fe; its field derivative is {fmt(float(corrected['refined_gradient']))}. The raw difference from the published U=4 ordinate is still {residual_gap:+.7f} μB/Fe. " + link("This selected-point audit", "selected_U4_blue_audit/summary.toml") + " and " + link("its constrained field refinement", "selected_U4_blue_audit/field_refinement/summary.toml") + " are diagnostics; the production table above is unchanged.", "",
              ]
    lines += render_smooth_refinement(data["smooth_refinement"], comparisons, inputs, output)
    if data["weak"]:
        lines += ["The separate " + link("weak-point mesh audit", "weak_mesh_audit/weak_mesh_summary.csv") + " reports the following machine-recorded outcomes. Its source, input, detailed filling records, and completion marker remain in the same directory. A finite-mesh occupation interval is not a thermodynamic insulating gap.", ""]
    else:
        status = data["weak_status"]
        lines += ["**The weak-point momentum-mesh audit has not been completed.** The explicit " + link("status record", "weak_mesh_audit/status.toml") + f" gives status `{cell(status['status'])}` for {cell(status['scope'])}: {cell(status['reason'])}. No weak-point mesh error estimate is inferred from the U=4 check.", ""]
    # The weak-point owner supplies an explicit machine summary. Preserve its
    # literal field meanings rather than infer a conclusion from prose logs.
    for index, row in enumerate(data["weak"], 1):
        if len(data["weak"]) > 1:
            lines += [f"Weak-point record {index}:", ""]
        lines += interpret_weak_mesh(row)
        lines += ["| Recorded weak-mesh quantity | Value |", "|:---|:---|"]
        for name, value in row.items():
            lines.append(f"| {cell(name.replace('_',' '))} | {cell(value)} |")
        lines.append("")
    blue_gap = data["blue_zero"]["lowest_Sz0_energies"][1] - data["blue_zero"]["lowest_Sz0_energies"][0]
    lines += [f"Independent zero-field reference checks found no higher-Sz ground partners for either U=0.5 ratio. For r=−0.5, the nearest Sz=±1 sectors lie {data['red_spin_gap']:.9g} higher. For r=−0.2, four Sz=0 roots resolve a nondegenerate singlet with first gap {blue_gap:.9g}; its independently computed S² is {fmt(data['blue_zero']['ground_subspace_S_squared_eigenvalues'][0])}. These checks remove the tested spin-multiplet ambiguity; they do not by themselves prove a physical paramagnetic phase.", "",
              "## Validation, provenance, and reproduction", ""]
    sets = f" in {data['test_sets']} test sets" if data["test_sets"] else ""
    lines += [f"The final repository suite records **{data['test_count']:,} passing assertions{sets}**, exit code 0: " + link("validation record", "validation/validation.txt") + ". Synthetic recording/plotter checks are separate bookkeeping checks and are not added to this numerical-suite count. The physical moment normalization also has an independent external-field derivative test and a saturated atomic limit of 2 μB per Fe.", "",
              "The final scans retain completed original-driver points and include retries from the adaptive and resolved extensions. Each selected point retains its own source snapshot and completion record; available `.point_sources.txt` sidecars preserve that distinction. Failed attempts are not plotted. Curve audit folders may aggregate disjoint completed batches: their `aggregation.json`, `output_sha256.json`, and copied `batches/` preserve every original source, input, and point association. The report verifies those output hashes when present, reads only final named scans, completed general audits, and an explicit weak-mesh audit status, and does not create numerical results.", "",
              "Detailed final-point audit records: " + link("blue audit", "numerical_audit_blue/completed.txt") + ", " + link("red audit", "numerical_audit_red/completed.txt") + ". The source extraction and model choices are documented in " + link("the Fig. 2(c) source audit", ROOT / "docs/prl_101_237004_fig2c_reference.md") + " and " + link("the method", ROOT / "docs/prl_101_237004_fig2c_method.md") + ".", "",
              "To match the saved campaign's numerical conventions, start in an unused output directory and compute its six original-method points first: blue U=4, 2, 1, 0.75 and red U=4, 2. Then run the resolved driver for both ratios in that same directory. It validates and reuses those six completed points and calculates the remaining four using the resolved integration and canonical field differences. Run these commands from the repository root:", "",
              "```bash",
              "for prl_U in 4 2 1 0.75; do",
              '  OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. scripts/run_prl_101_237004_fig2c.jl --ratio=-0.2 --U="$prl_U" --output-dir=results/prl_101_237004/fig2c_rerun',
              "done",
              "for prl_U in 4 2; do",
              '  OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. scripts/run_prl_101_237004_fig2c.jl --ratio=-0.5 --U="$prl_U" --output-dir=results/prl_101_237004/fig2c_rerun',
              "done",
              "OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. scripts/run_prl_101_237004_fig2c_resolved.jl --ratio=-0.2 --output-dir=results/prl_101_237004/fig2c_rerun",
              "OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. scripts/run_prl_101_237004_fig2c_resolved.jl --ratio=-0.5 --output-dir=results/prl_101_237004/fig2c_rerun",
              "julia --project=. scripts/plot_prl_101_237004_fig2c.jl --input-root=results/prl_101_237004/fig2c_rerun --quadrature-orders=24,48",
              "OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. test/runtests.jl",
              "```", "",
              "For a uniform refined-method calculation instead, use a separate unused directory and run the resolved driver directly for all ten points:", "",
              "```bash",
              "OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. scripts/run_prl_101_237004_fig2c_resolved.jl --ratio=-0.2 --output-dir=results/prl_101_237004/fig2c_uniform_rerun",
              "OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. scripts/run_prl_101_237004_fig2c_resolved.jl --ratio=-0.5 --output-dir=results/prl_101_237004/fig2c_uniform_rerun",
              "```", "",
              "The uniform calculation uses low-frequency order48 integration and fully refilled canonical field differences everywhere. It may differ from the saved mixed-profile campaign at finite integration and field-step tolerances; neither recipe promises bitwise equality across runs or hardware.", "",
              "The numerical audit scripts retain their exact invocations and independent source snapshots. After the required final audits and validation are present, generate this report with:", "",
              "```bash", "python3 scripts/summarize_prl_101_237004_fig2c.py", "```", "",
              "Use `--input-root=PATH --output=PATH` to select inputs and destination. Existing reports are preserved unless `--overwrite` is explicitly supplied. `--check-only` validates all required inputs without writing a report.", "",
              "The next milestone is Fig. 3(a–d): one-particle spectra, density of states, and Fermi-level intensity from the VCA reference solutions, with the paper's stated 0.05 broadening and separate spectral-weight, causality, and mesh checks. No result for those panels is claimed here.", "",
              f"Generated {dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')} by `scripts/summarize_prl_101_237004_fig2c.py`.", ""]
    return "\n".join(lines)


def write_report(path: Path, text: str, overwrite: bool) -> None:
    if path.exists() and not overwrite:
        raise ReportError(f"report already exists; use --overwrite explicitly: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".fig2c-report-", dir=path.parent)
    temp = Path(name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        if overwrite:
            os.replace(temp, path)
        else:
            # Atomic no-clobber publication on the same filesystem.
            os.link(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args(argv)
    directory = args.input_root.resolve()
    output = (args.output or directory / "report.md").resolve()
    try:
        if output.exists() and not args.overwrite and not args.check_only:
            raise ReportError(f"report already exists; use --overwrite explicitly: {output}")
        inputs = Inputs(directory)
        data = load_final_inputs(inputs)
        text = render_report(data, inputs, output)
        inputs.unchanged()
        inside = sum(boolean(r, "within_vertical_allowance") for r in data["comparisons"].values())
        if args.check_only:
            print(f"Final inputs validated: 10 production points, 810 reference sectors, {inside}/10 within the raw vertical allowance.")
        else:
            write_report(output, text, args.overwrite)
            print(f"Wrote {output}; {inside}/10 raw moment differences within ±0.002 μB/Fe.")
    except (ReportError, OSError, KeyError, TypeError, tomllib.TOMLDecodeError, json.JSONDecodeError) as exc:
        print(f"Report not generated: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
