#!/usr/bin/env python3
"""Build a Fig. 3 report from completed, hashed production and audit artifacts.

No numerical solver, fitting, extraction, or data substitution is performed.
Completed refined production is preferred; an unfinished refined directory
cannot silently fall back to the original result. Existing reports are kept
unless --overwrite is explicitly supplied.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile
import tomllib

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "results/prl_101_237004/fig3"
REFERENCE = ROOT / "results/prl_101_237004/fig3_reference"
CASES = {"blue_U0": (-.2, 0.), "blue_U0p5": (-.2, .5), "blue_U1": (-.2, 1.),
         "blue_U2": (-.2, 2.), "red_U1": (-.5, 1.)}
INTERACTING = set(CASES) - {"blue_U0"}


class InputError(ValueError):
    pass


def number(row, name):
    try:
        # Julia prints its irrational constant symbolically in CSV momentum
        # columns. Accept that exact known literal without evaluating text.
        value = math.pi if row[name] == "π" else float(row[name])
    except (KeyError, TypeError, ValueError) as exc:
        raise InputError(f"missing/non-numeric {name}") from exc
    if not math.isfinite(value):
        raise InputError(f"nonfinite {name}")
    return value


def same(a, b, label, atol=1e-10):
    if not math.isfinite(a) or not math.isfinite(b) or abs(a-b)>atol:
        raise InputError(f"{label} differs: {a} versus {b}")


def indexed(rows, expected):
    result = {}
    for row in rows:
        name = row.get("case")
        if name in result or name not in expected:
            raise InputError(f"duplicate/unexpected case {name}")
        result[name] = row
    if set(result) != set(expected):
        raise InputError(f"incomplete case coverage; expected {sorted(expected)}")
    return result


def relative(name):
    p = Path(name)
    if p.is_absolute() or ".." in p.parts:
        raise InputError(f"unsafe artifact path: {name}")
    return p


class Inputs:
    def __init__(self):
        self.hashes = {}

    def read(self, path):
        path = Path(path)
        if not path.is_file():
            raise InputError(f"required completed input missing: {path}")
        data = path.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        if self.hashes.setdefault(path, sha) != sha:
            raise InputError(f"input changed during report generation: {path}")
        return data

    def sha(self, path):
        self.read(path)
        return self.hashes[Path(path)]

    def text(self, path):
        return self.read(path).decode("utf-8")

    def json(self, path):
        return json.loads(self.text(path))

    def toml(self, path):
        return tomllib.loads(self.text(path))

    def csv(self, path):
        reader = csv.DictReader(io.StringIO(self.text(path)))
        if not reader.fieldnames or len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise InputError(f"invalid CSV columns: {path}")
        rows = list(reader)
        if any(None in r or any(v is None for v in r.values()) for r in rows):
            raise InputError(f"malformed CSV: {path}")
        return rows

    def verify(self, base, hashes):
        if not isinstance(hashes, dict) or not hashes:
            raise InputError(f"missing hash manifest under {base}")
        for name, sha in hashes.items():
            if not re.fullmatch(r"[0-9a-f]{64}", str(sha)) or self.sha(Path(base)/relative(name)) != sha:
                raise InputError(f"artifact hash differs: {base}/{name}")

    def unchanged(self):
        for path, sha in self.hashes.items():
            if hashlib.sha256(path.read_bytes()).hexdigest() != sha:
                raise InputError(f"input changed during report generation: {path}")


def text_marker(inputs, path, required):
    text = inputs.text(path)
    if not text.startswith("Completed"):
        raise InputError(f"incomplete audit: {path}")
    hashes = {}
    for line in text.splitlines():
        match = re.fullmatch(r"([0-9a-f]{64}) +(.+)", line)
        if match:
            sha, name = match.groups()
            if name in hashes:
                raise InputError("duplicate completion checksum")
            hashes[name] = sha
    if not set(required) <= set(hashes):
        raise InputError(f"completion marker omits required files: {path}")
    inputs.verify(Path(path).parent, hashes)
    return text


def production(inputs, directory):
    marker = inputs.toml(directory/"completed.toml")
    if marker.get("status") != "spectral_grids_computed" or marker.get("source_hashes_unchanged") is not True:
        raise InputError("spectral production is incomplete")
    config = inputs.toml(directory/"configuration.toml")
    inputs.verify(directory/"source_snapshot", config["source_sha256"])
    same(number(config,"eta"), .05, "production broadening")
    same(number(config,"physical_DOS_L"), 48, "physical DOS mesh")
    if set(marker.get("case_completion_sha256", {})) != set(CASES):
        raise InputError("production needs all five cases")
    records = {}
    for case, (ratio, u) in CASES.items():
        folder = directory/"cases"/case
        if inputs.sha(folder/"completed.toml") != marker["case_completion_sha256"][case]:
            raise InputError("case completion checksum differs")
        done = inputs.toml(folder/"completed.toml")
        if done.get("case") != case:
            raise InputError("case completion identifies another case")
        expected = {"parameters.toml", "dos.csv"}
        if case in ("blue_U0p5", "red_U1"):
            expected.add("path.csv")
        if case == "blue_U0p5":
            expected.add("fermi_intensity.csv")
        if set(done.get("output_sha256", {})) != expected:
            raise InputError("case output census differs")
        inputs.verify(folder, done["output_sha256"])
        p = inputs.toml(folder/"parameters.toml")
        if p.get("case") != case:
            raise InputError("parameter case differs")
        for field, value in (("ratio",ratio),("U",u),("J",u/4),("physical_L",48)):
            same(number(p,field), value, f"{case} {field}")
        for field in ("h","mu","mu_prime"):
            number(p,field)
        if u:
            if number(p,"block_steps") not in (48,96,192):
                raise InputError("unknown spectral reference depth")
            for name, sha in p["input_sha256"].items():
                base = directory if name.startswith("reference_cache/") else directory/"inputs/fig2c"
                if inputs.sha(base/relative(name)) != sha:
                    raise InputError("copied inherited Fig2c input hash differs")
            if "spectral_reference_cache" in p:
                if inputs.sha(directory/relative(p["spectral_reference_cache"])) != p["spectral_reference_sha256"]:
                    raise InputError("primary spectral reference cache hash differs")
        dos = inputs.csv(folder/"dos.csv")
        if len(dos) != 601:
            raise InputError("production DOS grid requires 601 energy points")
        for i,row in enumerate(dos):
            same(number(row,"omega_minus_mu"), -3+.01*i, "DOS grid", 2e-12)
            if number(row,"DOS_states_per_Fe_per_energy") < -1e-10:
                raise InputError("negative production DOS")
        zero = number(dos[300],"DOS_states_per_Fe_per_energy")
        records[case] = dict(parameters=p, dos=dos, zero=zero)
    return dict(directory=directory, configuration=config, records=records)


def numerical_audit(inputs, directory, baseline):
    text_marker(inputs, directory/"completed.txt", ("audit_summary.csv","provenance.toml"))
    provenance = inputs.toml(directory/"provenance.toml")
    inputs.verify(directory/"source_snapshot",provenance["source_sha256"])
    rows = indexed(inputs.csv(directory/"audit_summary.csv"), CASES)
    details = {}
    for case,row in rows.items():
        folder=directory/case
        text_marker(inputs,folder/"completed.txt",("selected_poles.csv","density.csv","spectrum_summary.csv",
                    "dos_comparison.csv","dos_fine.csv","input.toml"))
        meta=inputs.toml(folder/"input.toml")
        p=baseline["records"][case]["parameters"]
        for name in ("U","J","ratio","h","mu","mu_prime"):
            same(number(meta,name),number(p,name),"audit stationary parameters")
        summary=inputs.csv(folder/"spectrum_summary.csv")
        if len(summary)!=1 or any(summary[0].get(k)!=v for k,v in row.items()
            if k not in ("density_max_target_error","residue_max_weight_error","causal_minimum")):
            raise InputError("audit case and combined summaries differ")
        if row.get("status")!="complete":
            raise InputError("incomplete spectrum audit")
        for name in row:
            if name not in ("case","status"):
                number(row,name)
        same(number(row,"normalization_states_per_Fe"),4,"spectral normalization")
        same(number(row,"eta"),.05,"audit broadening")
        poles=inputs.csv(folder/"selected_poles.csv")
        if len(poles)!=4 or len({(number(r,"kx"),number(r,"ky"),number(r,"spin")) for r in poles})!=4:
            raise InputError("selected-k audit needs two momenta and both spins")
        for r in poles:
            if r["case"]!=case or number(r,"spin") not in (1,2):
                raise InputError("pole audit case/spin differs")
            for name in r:
                if name!="case":number(r,name)
            same(number(r,"weight_per_spin"),2,"selected-k weight per spin",2e-9)
            same(number(r,"window_exact")+number(r,"omitted_lorentzian_weight"),
                 number(r,"weight_per_spin"),"finite-window weight accounting")
        density=inputs.csv(folder/"density.csv")
        expected=1 if case=="blue_U0" else 4 if case=="blue_U0p5" else 2
        if len(density)!=expected or any(r["case"]!=case for r in density):
            raise InputError("density audit coverage differs")
        for r in density:
            same(number(r,"canonical_density")-2,number(r,"target_error"),"zero-broadening density error")
        same(max(abs(number(r,"target_error")) for r in density),number(row,"density_max_target_error"),"density summary")
        same(max(abs(number(r,"weight_per_spin")-2) for r in poles),number(row,"residue_max_weight_error"),"residue summary")
        same(min(number(r,"minimum_causal_eigenvalue") for r in poles),number(row,"causal_minimum"),"causality summary")
        details[case]=dict(poles=poles,density=density)
    return rows,details


def depth_audit(inputs,directory,primary,original_audit):
    text_marker(inputs,directory/"completed.txt",("provenance.toml","depth_summary.csv"))
    provenance=inputs.toml(directory/"provenance.toml")
    inputs.verify(directory/"source_snapshot",provenance["source_sha256"])
    if provenance["original_audit_completion_sha256"]!=inputs.sha(original_audit/"completed.txt"):
        raise InputError("depth audit refers to another initial audit")
    rows=indexed(inputs.csv(directory/"depth_summary.csv"),INTERACTING)
    for case,row in rows.items():
        if row.get("status")!="complete":raise InputError("incomplete depth refinement")
        for name in row:
            if name not in ("case","status"):number(row,name)
        for name in ("U","ratio","h","mu","mu_prime"):
            same(number(row,name),number(primary["records"][case]["parameters"],name),"depth-audit center")
        same(number(row,"baseline_blocks"),96,"depth baseline")
        same(number(row,"refined_blocks"),192,"depth refinement")
        refs=inputs.toml(directory/case/"references.toml")
        for depth in (96,192):
            if inputs.sha(directory/relative(refs[f"block{depth}_cache"]))!=refs[f"block{depth}_sha256"]:
                raise InputError("depth reference cache hash differs")
        if refs["block96_sha256"]!=primary["records"][case]["parameters"]["spectral_reference_sha256"]:
            raise InputError("depth audit uses another primary reference")
    return rows


def mesh_audit(inputs,directory,primary,depth_directory):
    text_marker(inputs,directory/"completed.txt",("provenance.toml","mesh_summary.csv"))
    provenance=inputs.toml(directory/"provenance.toml")
    inputs.verify(directory/"source_snapshot",provenance["source_sha256"])
    if provenance["depth_completion_sha256"]!=inputs.sha(depth_directory/"completed.txt"):
        raise InputError("mesh audit refers to another depth audit")
    rows=indexed(inputs.csv(directory/"mesh_summary.csv"),INTERACTING)
    for case,row in rows.items():
        if row.get("status")!="complete":raise InputError("incomplete primary mesh audit")
        for name in row:
            if name not in ("case","status"):number(row,name)
        for name in ("U","ratio","h","mu","mu_prime","block_steps"):
            same(number(row,name),number(primary["records"][case]["parameters"],name),"mesh-audit center")
        for name,value in (("physical_L",48),("audit_L",96),("eta",.05)):
            same(number(row,name),value,"mesh-audit convention")
        same(number(row,"density")-2,number(row,"density_target_error"),"primary density error")
        same(number(row,"window_weight")+number(row,"omitted_window_weight_from_exact_sumrule"),4,"mesh finite-window accounting")
        ref=inputs.toml(directory/case/"reference.toml")
        if inputs.sha(directory/relative(ref["cache"]))!=ref["sha256"]:
            raise InputError("mesh-audit reference cache hash differs")
        p=primary["records"][case]["parameters"]
        if ref["sha256"]!=p["spectral_reference_sha256"]:
            raise InputError("mesh audit uses another primary reference")
    return rows


def load(inputs,directory,reference_dir):
    original=production(inputs,directory)
    deeper=directory/"refined"
    if deeper.is_dir():
        primary=production(inputs,deeper)
        for case in CASES:
            for name in ("U","J","ratio","h","mu","mu_prime"):
                same(number(primary["records"][case]["parameters"],name),
                     number(original["records"][case]["parameters"],name),"unchanged variational center")
    else:
        primary=original
    audit,details=numerical_audit(inputs,directory/"numerical_audit",original)
    depths=depth_audit(inputs,directory/"depth_refinement_audit",primary,directory/"numerical_audit")
    mesh=mesh_audit(inputs,directory/"refined_mesh_audit",primary,directory/"depth_refinement_audit")
    plots=primary["directory"]/"plots"
    plot_prov=inputs.toml(plots/"provenance.toml")
    inputs.verify(plots,plot_prov["output_sha256"])
    inputs.verify(ROOT,plot_prov["input_sha256"])
    same(number(plot_prov,"ridge_count"),49,"displayed ridge count")
    source_done=inputs.json(reference_dir/"completed.json")
    if source_done.get("status")!="completed" or source_done.get("validation_status")!="passed":
        raise InputError("source extraction incomplete")
    inputs.verify(reference_dir,source_done["output_sha256"])
    if inputs.sha(ROOT/relative(source_done["source_document"]))!=source_done["source_document_sha256"]:
        raise InputError("source extraction documentation hash differs")
    source_prov=inputs.json(reference_dir/"provenance.json")
    inputs.verify(reference_dir,source_prov["output_sha256"])
    source=inputs.json(reference_dir/"fig3_metadata.json")
    for panel in ("3a","3b"):
        if source["ridgelines"][panel]["ridge_count"]!=48:raise InputError("unexpected source ridge count")
    comparison_dir=primary["directory"]/"comparison"
    if not comparison_dir.is_dir():comparison_dir=directory/"comparison"
    comparison_done=inputs.json(comparison_dir/"completed.json")
    if comparison_done.get("status")!="completed":raise InputError("comparison completion missing")
    inputs.verify(comparison_dir,comparison_done["output_sha256"])
    comparison_plots=inputs.toml(comparison_dir/"plots/provenance.toml")
    inputs.verify(comparison_dir/"plots",comparison_plots["output_sha256"])
    inputs.verify(ROOT,comparison_plots["input_sha256"])
    comparison=inputs.json(comparison_dir/"report.json")
    if comparison.get("status")!="completed":raise InputError("paper comparison incomplete")
    inputs.verify(ROOT,comparison["input_sha256"])
    dos_comparison=indexed(comparison["dos"],set(CASES)-{"red_U1"})
    for case,row in dos_comparison.items():
        same(number(row,"U"),CASES[case][1],"DOS comparison U")
        same(number(row,"calculated_DOS_at_zero"),primary["records"][case]["zero"],"primary DOS(0)")
        raw=primary["directory"]/"cases"/case/"dos.csv"
        expected_key=raw.relative_to(ROOT).as_posix()
        if comparison["input_sha256"].get(expected_key)!=inputs.sha(raw):
            raise InputError("comparison does not identify the primary production DOS")
        for name in ("points","omega_allowance","dos_allowance","max_abs","rms","median_abs","within_vertical_allowance"):
            number(row,name)
        if not 0<=number(row,"within_vertical_allowance")<=number(row,"points"):
            raise InputError("invalid DOS comparison count")
    validation=inputs.text(directory/"validation/validation.txt")
    count=re.search(r"Passing assertions:\s*([\d,]+)(?:\s+in\s+([\d,]+)\s+test sets)?",validation)
    if not re.search(r"exit\s+code\s+0\b",validation,re.I) or not count:
        raise InputError("final repository validation lacks passing count or exit code0")
    tests=inputs.json(directory/"validation/test_summary.json")
    if tests.get("exit_code")!=0 or tests.get("source_hashes_unchanged") is not True:
        raise InputError("repository validation is incomplete or its sources changed")
    same(number(tests,"passing_assertions"),int(count[1].replace(",","")),"test assertion count")
    if count[2]:same(number(tests,"test_sets"),int(count[2].replace(",","")),"test set count")
    if sum(tests["test_set_counts"].values())!=tests["passing_assertions"] or len(tests["test_set_counts"])!=tests["test_sets"]:
        raise InputError("repository test totals do not match their set breakdown")
    for filename in ("test_sources.sha256","numerical_sources.sha256"):
        hashes={}
        for line in inputs.text(directory/"validation"/filename).splitlines():
            match=re.fullmatch(r"([0-9a-f]{64}) +(.+)",line)
            if not match or match[2] in hashes:raise InputError("invalid validation source manifest")
            hashes[match[2]]=match[1]
        inputs.verify(ROOT,hashes)
    inputs.read(ROOT/"docs/prl_101_237004_fig3_method.md")
    inputs.read(ROOT/"docs/prl_101_237004_fig3_reference.md")
    red_peak=inputs.csv(directory/"depth_refinement_audit/red_U1/path_largest_difference.csv")
    if len(red_peak)!=1:raise InputError("expected one largest red depth discrepancy")
    same(abs(number(red_peak[0],"difference")),number(depths["red_U1"],"path_max_abs"),"red peak discrepancy")
    return dict(original=original,primary=primary,audit=audit,details=details,depth=depths,mesh=mesh,
                source=source,comparison=comparison,dos_comparison=dos_comparison,
                plots=plots,comparison_directory=comparison_dir,reference_directory=reference_dir,
                red_peak=red_peak[0],source_validation_checks=source_done["validation_checks"],
                test_count=int(count[1].replace(",","")),test_sets=int(count[2].replace(",","")) if count[2] else None)


def fmt(x):return f"{float(x):.6g}"
def clean(x):return str(x).replace("|","\\|").replace("\n"," ")


def render(data,directory,output):
    primary=data["primary"];records=primary["records"]
    link=lambda label,path:f"[{label}]({Path(os.path.relpath(path,output.parent)).as_posix()})"
    image=lambda path:Path(os.path.relpath(path,output.parent)).as_posix()
    blocks=sorted({int(r["parameters"].get("block_steps",0)) for name,r in records.items() if name!="blue_U0"})
    lines=["# PRL 101, 237004: Figure 3", "",
           "**All four spectral panels have been calculated, but quantitative reproduction of the paper is not established.** The DOS comparison uses unscaled plotted ordinates; the ridgelines and Fermi-surface image have incomplete sampling or amplitude specifications.","",
           f"The primary curves use Green-function block depth {', '.join(map(str,blocks))}; the original depth 48 production is retained. The deeper calculation holds every saved h, μ, and μ′ fixed. It refines the real-axis Green function and does not re-optimize the variational state.","",
           f"![Figure 3 reconstruction]({image(data['plots']/'fig3_reconstruction.png')})","",
           "## Parameters and spectral convention","",
           "| Case / panel | r | U | J | h | μ | μ′ | DOS at ω−μ=0 |",
           "|:---|---:|---:|---:|---:|---:|---:|---:|"]
    labels={"blue_U0":"U=0 / c","blue_U0p5":"U=0.5 / a,c,d","blue_U1":"U=1 / c","blue_U2":"U=2 / c","red_U1":"U=1 / b"}
    for case in CASES:
        r=records[case];p=r["parameters"]
        lines.append("| "+labels[case]+" | "+" | ".join(f"{number(p,k):.12g}" for k in ("ratio","U","J","h","mu","mu_prime"))+f" | {r['zero']:.9g} |")
    lines += ["", "The model retains the original printed Slater–Koster hoppings, full PRL interaction, J=U/4, orbitals (xz,yz), and an open four-Fe reference with a (0,π) stripe field. Both spins and both orbitals are summed: the full spectral weight is four states per Fe. The energy coordinate is ω−μ. The caption specifies a broadening of 0.05 immediately after panels (a,b), without defining the kernel or half-width/full-width convention. Here η=0.05 is the Lorentzian half width, also used for the k-integrated DOS; a separate DOS broadening is not printed.","",
              "The free curve uses exact one-body cancellation and the half-filled chemical potential of the stated L48 mesh. The interacting centers inherit Figure 2(c)'s documented moment discrepancies, finite-mesh sensitivity, and nearby-branch search limits. Increasing spectral depth does not remove those inherited errors. See "+link("the Figure 2(c) report",ROOT/"results/prl_101_237004/fig2c/report.md")+" and "+link("the spectral method",ROOT/"docs/prl_101_237004_fig3_method.md")+".","",
              "## Comparison with the published figure","",
              "Panels (a,b) follow Y→M→Γ→Y→X from bottom to top. The source contains 48 visible traces per panel; the reconstruction displays 49 traces from a denser 193-point path. Exact source momentum sampling and absolute ridge amplitudes are not printed. The fixed display gain and offsets are documented plotting choices, so these panels are not a point-by-point quantitative ridge reproduction. "+link("Heatmaps without offsets",data["plots"]/"fig3_spectral_heatmaps.png")+" show the same physical spectral intensities.","",
              "Panel (c) compares the visible DOS polylines without fitting an amplitude or energy shift. The printed normalization formula is absent; the visible free-curve area near four supports, but does not establish exactly, the chosen four-state convention. Clipped U=2 peaks and legend-occluded vertices are excluded, and endpoints outside the calculated energy window are not extrapolated. Counts and RMS below summarize retained native vector vertices: they are neither uniform-frequency norms nor independent statistical samples. Graphics extraction allowances are not numerical error bars, and horizontal uncertainty is not folded into the vertical count.","",
              "| U | Retained vertices | Within vertical allowance | Maximum absolute difference | Native-vertex RMS difference | Printed DOS(0), when recoverable |",
              "|---:|---:|---:|---:|---:|---:|"]
    for case in ("blue_U0","blue_U0p5","blue_U1","blue_U2"):
        row=data["dos_comparison"][case]
        paper=row.get("paper_DOS_at_zero_if_interpolable")
        lines.append(f"| {number(row,'U'):g} | {int(number(row,'points'))} | {int(number(row,'within_vertical_allowance'))}/{int(number(row,'points'))} | {fmt(row['max_abs'])} | {fmt(row['rms'])} | {'unavailable' if paper is None else fmt(paper)} |")
    allowances={(number(r,"omega_allowance"),number(r,"dos_allowance")) for r in data["dos_comparison"].values()}
    total=sum(int(number(r,"points")) for r in data["dos_comparison"].values())
    within=sum(int(number(r,"within_vertical_allowance")) for r in data["dos_comparison"].values())
    lines += ["", f"**{within}/{total} retained DOS vertices fall within the vertical graphics allowance.** Recorded (energy, DOS) allowances: "+", ".join(f"(±{a:g}, ±{b:g})" for a,b in sorted(allowances))+". These raw-ordinate discrepancies must be assessed alongside the numerical changes below. "+link("DOS overlay",data["comparison_directory"]/"plots/fig3c_dos_comparison.png")+" and "+link("complete comparison and paired data",data["comparison_directory"]/"report.json")+" retain the selected samples and extraction limits.","",
              "Panel (d) is the equal arithmetic mean of four rotations of A(k,0), with the raw stripe intensity retained. The paper states rotational symmetrization but leaves the spectral quantity, energy window, weights, and absolute colorbar normalization unspecified. Its 60×60 painted cells do not determine the 48×48 physical VCA mesh. Only the registered shape is compared; palette rank is not an absolute spectral amplitude.",""]
    fs=data["comparison"]["fermi_shape"]
    lines += [f"At the recorded registration `{clean(fs['registration'])}`, the Spearman rank correlation is **{fmt(fs['spearman_rank'])}** and the high-intensity top-decile intersection-over-union is **{fmt(fs['top_decile_intersection_over_union'])}**. The inclusive 90th-order-statistic cutoff keeps all ties: it selects {int(number(fs,'source_selected_count'))} source cells and {int(number(fs,'calculated_selected_count'))} calculated cells, rather than exactly 10% each. These are descriptive shape metrics, not a fitted normalization or an exact Fermi-surface error bound. "+link("Shape comparison",data["comparison_directory"]/"plots/fig3d_shape_comparison.png")+".",""]
    if fs.get("registration_audits"):
        lines += ["Registration sensitivity is retained explicitly:","","| Registration | Spearman rank | Top-decile overlap | Selected source / calculated |","|:---|---:|---:|---:|"]
        for row in fs["registration_audits"]:
            lines.append(f"| {clean(row['registration'])} | {fmt(row['spearman_rank'])} | {fmt(row['top_decile_intersection_over_union'])} | {int(number(row,'source_selected_count'))} / {int(number(row,'calculated_selected_count'))} |")
        lines.append("")
    lines += ["## Numerical checks and their limits","",
              "The initial 48→96 audit found real-axis changes large enough to motivate the deeper primary curves. Passing the earlier imaginary-axis checks did not imply convergence everywhere on the real axis.","",
              "| Case | 48→96 DOS max change | 48→96 path max change |",
              "|:---|---:|---:|"]
    for case in CASES:
        row=data["audit"][case]
        lines.append(f"| {case} | "+" | ".join(fmt(row[k]) for k in ("block48_96_DOS_max_abs","block48_96_path_max_abs"))+" |")
    lines += ["", "The independent 96→192 comparison keeps the same stationary parameters and η. It checks all 193 path momenta on energy steps 0.025, the DOS on L48, and a 96×96 Fermi-level grid for panel (d). Relative L2 values below are fractions, not percentages.", "",
              "| Case | 96→192 DOS max change | DOS relative L2 | Path max change | Path relative L2 | FS max change |",
              "|:---|---:|---:|---:|---:|---:|"]
    for case in CASES:
        if case not in data["depth"]:continue
        row=data["depth"][case]
        lines.append(f"| {case} | "+" | ".join(fmt(row[k]) for k in ("dos_max_abs","dos_relative_l2","path_max_abs","path_relative_l2"))+f" | {fmt(row['fs_max_abs']) if case=='blue_U0p5' else 'not audited'} |")
    red=data["depth"]["red_U1"]
    lines += ["", f"The red U=1 panel retains a localized depth change of {fmt(red['path_max_abs'])} at ω−μ={fmt(data['red_peak']['omega'])}. Its path relative L2 change is {100*number(red,'path_relative_l2'):.4g}%, and the maximum change is {100*number(red,'path_max_abs_over_peak'):.4g}% of the refined path peak. This nonuniform high-energy sensitivity remains a limitation of the depth 96 primary panel.","",
              "Primary-depth mesh and density checks are separate. For interacting cases, this table uses depth 96; the unchanged analytic U=0 result comes from the initial audit. Mesh comparisons keep h, μ, and μ′ fixed.","",
              "| Case | L48→L96 DOS max change | Mesh relative L2 | Zero-broadening density error | [-3,3] DOS weight | Energy-step 0.01→0.005 area change |",
              "|:---|---:|---:|---:|---:|---:|"]
    for case in CASES:
        if case=="blue_U0":
            row=data["audit"][case]
            vals=[fmt(row["mesh_L48_L96_max_abs"]),"not recorded",fmt(row["density_max_target_error"]),fmt(row["L48_window_weight"]),fmt(row["window_dx01_dx005_difference"])]
        else:
            row=data["mesh"][case]
            vals=[fmt(row[k]) for k in ("mesh_max_abs","mesh_relative_l2","density_target_error","window_weight","frequency_dx01_dx005_difference")]
        lines.append(f"| {case} | "+" | ".join(vals)+" |")
    poles=[row for detail in data["details"].values() for row in detail["poles"]]
    weight=max(abs(number(r,"weight_per_spin")-2) for r in poles)
    causal=min(number(r,"minimum_causal_eigenvalue") for r in poles)
    oracle=max(number(r,"direct_green_error") for r in poles)
    primary_m0=max(abs(number(r,"zeroth_moment_error")) for r in data["mesh"].values())
    lines += ["", f"The independent auxiliary-pole audit checks two momenta in each original depth-48 case. Its maximum per-spin residue-weight error is {weight:.6g}, minimum spectral-matrix eigenvalue is {causal:.6g}, and maximum direct auxiliary-pole Green discrepancy is {oracle:.6g}. The primary depth-96 reference zeroth-moment matrix error is at most {primary_m0:.6g}. Exact pole residues and arctangent Lorentzian integrals separate full weight from the finite plotted window. The expected total is four states per Fe; finite-window deficits include genuine omitted tails.","",
              "Half filling is checked at zero broadening. The blue U=0.5 case uses the saved half-occupied shell via symmetric side limits; other interacting cases use their saved integer intervals, and U=0 uses exact bare poles. The occupied finite-η DOS integral is not used as a density test. Suppressed intensity at η=0.05 alone does not prove a hard gap.","",
              "The L96 DOS comparison does not supply a new stationary L96 state. Depth and selected-momentum checks provide measured numerical evidence, not a uniform Brillouin-zone or thermodynamic error bound. "+link("Initial audit",directory/"numerical_audit/audit_summary.csv")+", "+link("96→192 audit",directory/"depth_refinement_audit/depth_summary.csv")+", and "+link("primary-depth mesh audit",directory/"refined_mesh_audit/mesh_summary.csv")+" retain every measured change.","",
              "## Validation and rerunning","",
              f"The repository validation records **{data['test_count']:,} passing assertions"+(f" in {data['test_sets']} test sets" if data['test_sets'] else "")+"**, exit code 0. "+link("Validation record",directory/"validation/validation.txt")+f". Source extraction separately passed {data['source_validation_checks']} checks. Postprocessing checks are separate from numerical assertions.","",
              "Run the primary spectral calculation from the repository root using a fresh output directory and the frozen Figure 2(c) inputs:","","```bash",
              "OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. scripts/run_prl_101_237004_fig3.jl --block-steps=96 --output-dir=results/prl_101_237004/fig3_rerun --input-root=results/prl_101_237004/fig2c",
              "julia --project=. scripts/plot_prl_101_237004_fig3.jl --input-root=results/prl_101_237004/fig3_rerun",
              "OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --project=. test/runtests.jl","```","",
              "The audit and comparison entry points retain their exact commands and input/source hashes. This report is generated only after their completion records exist:","","```bash",
              "python3 scripts/summarize_prl_101_237004_fig3.py --check-only",
              "python3 scripts/summarize_prl_101_237004_fig3.py","```","",
              "The original production, deeper production, extracted source, and comparisons remain separate. Report generation verifies their recorded hashes and never replaces numerical data or rescales it to the paper. Existing reports require explicit `--overwrite`.","",
              "The next milestone is Figure 4: pairing calculations and their independent checks. No pairing calculation is started or claimed in this report.","",
              "Source extraction: "+link("reference notes",ROOT/"docs/prl_101_237004_fig3_reference.md")+"; "+link("source metadata",data["reference_directory"]/"fig3_metadata.json")+". Generated "+dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")+".",""]
    return "\n".join(lines)


def publish(path,text,overwrite):
    if path.exists() and not overwrite:raise InputError("report exists; use --overwrite explicitly")
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=".fig3-report-",dir=path.parent)
    temp=Path(name)
    try:
        with os.fdopen(fd,"w",encoding="utf-8") as handle:handle.write(text)
        if overwrite:os.replace(temp,path)
        else:os.link(temp,path)
    finally:temp.unlink(missing_ok=True)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root",type=Path,default=DEFAULT)
    parser.add_argument("--reference-root",type=Path,default=REFERENCE)
    parser.add_argument("--output",type=Path)
    parser.add_argument("--check-only",action="store_true")
    parser.add_argument("--overwrite",action="store_true")
    args=parser.parse_args(argv)
    directory=args.input_root.resolve();output=(args.output or directory/"report.md").resolve()
    try:
        if output.exists() and not args.overwrite and not args.check_only:raise InputError("report exists; use --overwrite explicitly")
        inputs=Inputs();data=load(inputs,directory,args.reference_root.resolve())
        text=render(data,directory,output);inputs.unchanged()
        if args.check_only:print(f"Validated Fig3 report inputs; primary={data['primary']['directory']}")
        else:publish(output,text,args.overwrite);print(f"Wrote {output}")
    except (InputError,OSError,KeyError,TypeError,ValueError) as exc:
        print(f"Figure3 report not generated: {exc}",file=sys.stderr);return 2
    return 0


if __name__=="__main__":
    raise SystemExit(main())
