#!/usr/bin/env julia

module PRL101237004Milestone3Summary

using Printf, SHA, Dates
include("plot_prl_101_237004_fig2a.jl")
include("prl_101_237004_model.jl")
const P = PRL101237004Fig2aPlot
const MODEL = PRL101237004Model
const SECTORS = ((label="gamma", q=(0.0,0.0), multiplicity=1),
                 (label="stripe", q=(1.0,0.0), multiplicity=2),
                 (label="M", q=(1.0,1.0), multiplicity=1),
                 (label="diagonal", q=(0.5,0.5), multiplicity=4))
const OUTPUTS = ("energy_sector_comparison.csv", "report.md", "report_provenance.txt")

jobname(U,label,seed) = "U"*replace(string(U),'.'=>'p')*"_"*label*"_seed"*string(seed)
roundoff(energy) = 64eps(Float64)*max(1,abs(energy))
flag(value) = value ? "PASS" : "FAIL"
fmt(value) = @sprintf("%.10g",value)
filehash(path) = bytes2hex(open(sha256,path))

function integer(row,field)
    value = P.number(row,field)
    isinteger(value) || error("noninteger $field")
    return Int(value)
end

function read_metrics(path)
    rows = P.read_scalar_csv(path,("quantity","value"))
    length(unique(row["quantity"] for row in rows))==length(rows) || error("duplicate audit metric: $path")
    return Dict(row["quantity"]=>P.number(row,"value") for row in rows)
end

function read_campaign(input)
    jobs,sources = NamedTuple[],String[]
    for U in (0.5,1.0), sector in SECTORS, seed in (sector.label=="gamma" ? (7,29) : (7,))
        name = jobname(U,sector.label,seed)
        directory = joinpath(input,name)
        path = joinpath(directory,"energies.csv")
        rows = P.read_scalar_csv(path,("U","J","k_label","kx_over_pi","ky_over_pi",
            "dimension","root","energy","residual","matvecs","seconds","solver_workspace_bytes"))
        roots = sort([integer(row,"root") for row in rows])
        roots==collect(1:length(rows)) || error("root indices must be contiguous from one: $path")
        sort!(rows;by=row->integer(row,"root"))
        for row in rows
            abs(P.number(row,"U")-U)<=1e-12 && abs(P.number(row,"J")-U/4)<=1e-12 || error("wrong couplings: $path")
            row["k_label"]==sector.label || error("wrong momentum label: $path")
            P.periodic_distance(P.number(row,"kx_over_pi"),sector.q[1])<=1e-12 &&
                P.periodic_distance(P.number(row,"ky_over_pi"),sector.q[2])<=1e-12 || error("wrong momentum: $path")
            integer(row,"dimension")>0 && integer(row,"matvecs")>0 || error("invalid solver dimensions/counts: $path")
            P.number(row,"residual")>=0 && P.number(row,"seconds")>=0 || error("negative residual/time: $path")
            integer(row,"solver_workspace_bytes")>0 || error("invalid memory estimate: $path")
        end
        length(unique(integer(row,"dimension") for row in rows))==1 || error("inconsistent dimension: $path")
        all(P.number(rows[i],"energy")<=P.number(rows[i+1],"energy")+1e-12 for i in 1:length(rows)-1) ||
            error("roots are not in energy order: $path")
        energy = P.number(first(rows),"energy")
        target = sector.label=="gamma" ? 1e-9 : 1e-7
        residual_pass = all(P.number(row,"residual")<=target+roundoff(P.number(row,"energy")) for row in rows)
        push!(jobs,(;U,name,directory,sector.label,sector.q,sector.multiplicity,seed,rows,energy,target,residual_pass))
        push!(sources,path)
        # Metadata is retained as text, never evaluated as executable Julia.
        metadata = joinpath(directory,"metadata.txt")
        isfile(metadata) || error("completed job metadata is missing: $metadata")
        if seed==29
            record = read(metadata,String)
            occursin(r"start:\s*random;\s*seed:\s*29;",record) || error("independent replica must record random seed 29: $metadata")
            occursin("Initial checkpoint",record) && error("independent replica was initialized from a checkpoint: $metadata")
        end
        push!(sources,metadata)
    end
    return jobs,sources
end

function replica_check(canonical,replica,sources)
    structures = map((canonical,replica)) do job
        path = joinpath(job.directory,"structure_factors.csv")
        rows = P.read_scalar_csv(path,("qx_over_pi","qy_over_pi","Szz_raw","Szz_per_site","Sdot_per_site_singlet"))
        length(rows)==8 || error("replica must contain all eight q: $path")
        push!(sources,path)
        for q in P.ALLOWED_Q
            row = P.unique_q(rows,q)
            isapprox(P.number(row,"Szz_raw"),8P.number(row,"Szz_per_site");atol=5e-11,rtol=1e-12) || error("replica spin normalization mismatch")
            isapprox(P.number(row,"Sdot_per_site_singlet"),3P.number(row,"Szz_per_site");atol=5e-11,rtol=1e-12) || error("replica spin isotropy conversion mismatch")
        end
        checkpath = joinpath(job.directory,"spin_checks.csv")
        checks = P.read_scalar_csv(checkpath,("norm_squared","total_spin_squared"))
        length(checks)==1 || error("expected one spin-check row: $checkpath")
        push!(sources,checkpath)
        abs(P.number(only(checks),"norm_squared")-1)<=1e-7 || error("replica norm check failed")
        abs(P.number(only(checks),"total_spin_squared"))<=1e-7 || error("replica is not a verified singlet")
        return rows
    end
    energy_difference = abs(canonical.energy-replica.energy)
    spin_difference = maximum(abs(P.number(P.unique_q(structures[1],q),"Szz_raw")-
        P.number(P.unique_q(structures[2],q),"Szz_raw")) for q in P.ALLOWED_Q)
    return (;U=canonical.U,energy_difference,spin_difference,
        energy_pass=energy_difference<=1e-8,spin_pass=spin_difference<=1e-6)
end

function read_audit(job,sources)
    path = joinpath(job.directory,"independent_audit.csv")
    audit = read_metrics(path)
    required = ("U","J","ground_energy","recorded_direct_residual","norm_squared",
        "onsite_total_z_squared","fourier_mean_Szz_per_site","onsite_fourier_sumrule_error",
        "C4_expectation_real","C4_expectation_imag","C4_residual_to_nearest_eigenvalue")
    all(haskey(audit,k) for k in required) || error("incomplete independent audit: $path")
    abs(audit["U"]-job.U)<=1e-12 && abs(audit["J"]-job.U/4)<=1e-12 || error("wrong audited coupling")
    abs(audit["ground_energy"]-job.energy)<=1e-11 || error("audit energy differs from completed job")
    abs(audit["recorded_direct_residual"]-P.number(first(job.rows),"residual"))<=1e-12 || error("audit residual differs from completed job")
    abs(abs(audit["onsite_total_z_squared"]-audit["fourier_mean_Szz_per_site"])-
        audit["onsite_fourier_sumrule_error"])<=1e-13 || error("audit sum-rule metric is inconsistent")
    structure_path = joinpath(job.directory,"structure_factors.csv")
    structure = P.read_scalar_csv(structure_path,("Szz_per_site",))
    abs(sum(P.number(row,"Szz_per_site") for row in structure)/8-audit["fourier_mean_Szz_per_site"])<=2e-11 ||
        error("independent audit and completed structure factors disagree")
    push!(sources,path)
    provenance = joinpath(job.directory,"audit_source_provenance.csv")
    P.read_scalar_csv(provenance,("source","checkpoint_sha256","snapshot_sha256","current_sha256","status"))
    push!(sources,provenance)
    audit_metadata = joinpath(job.directory,"audit_metadata.txt")
    isfile(audit_metadata) || error("audit metadata is missing: $audit_metadata")
    push!(sources,audit_metadata)
    literal = nothing
    if haskey(audit,"literal_transition_sampled_rows")
        literal_path = joinpath(job.directory,"literal_transition_audit.csv")
        rows = P.read_scalar_csv(literal_path,("row","orbit_length","maximum_coefficient_error"))
        length(rows)==audit["literal_transition_sampled_rows"] || error("literal audit sample count differs")
        isempty(rows) && error("literal audit contains no samples")
        max_error = maximum(P.number(row,"maximum_coefficient_error") for row in rows)
        max_error==audit["literal_transition_maximum_coefficient_error"] || error("literal audit maximum differs")
        max_error>=0 || error("negative literal audit error")
        literal = (;count=length(rows),max_error,pass=max_error<=2e-12)
        push!(sources,literal_path)
        orbital_path = joinpath(job.directory,"orbital_structure_diagnostic.csv")
        isfile(orbital_path) && push!(sources,orbital_path)
    end
    free = haskey(audit,"U0_max_Wick_Slater_raw_Szz_error")
    free_pass = false
    if free
        for key in ("U0_Wick_energy","U0_projected_energy","U0_direct_residual","U0_orbital_gap","U0_projection_weight")
            haskey(audit,key) || error("incomplete U=0 audit: $path")
        end
        wickpath = joinpath(job.directory,"audit_u0_wick.csv")
        wick = P.read_scalar_csv(wickpath,("qx_over_pi","qy_over_pi","Wick_Szz_raw","Slater_Szz_raw","absolute_difference"))
        length(wick)==8 || error("U=0 audit requires all eight momenta")
        for q in P.ALLOWED_Q
            row = P.unique_q(wick,q)
            abs(abs(P.number(row,"Wick_Szz_raw")-P.number(row,"Slater_Szz_raw"))-
                P.number(row,"absolute_difference"))<=1e-13 || error("inconsistent U=0 comparison row")
        end
        max_difference = maximum(P.number(row,"absolute_difference") for row in wick)
        abs(max_difference-audit["U0_max_Wick_Slater_raw_Szz_error"])<=1e-13 || error("U=0 audit maximum differs from its CSV")
        targets = (0.0,2.0,4.0,0.0)
        expected_free = all(abs(P.number(P.unique_q(wick,class.q),"Wick_Szz_raw")-target)<=2e-10
            for (class,target) in zip(P.CLASSES,targets))
        free_pass = expected_free && audit["U0_max_Wick_Slater_raw_Szz_error"]<=2e-10 &&
            audit["U0_direct_residual"]<=2e-10 && audit["U0_orbital_gap"]>1e-10 &&
            abs(audit["U0_Wick_energy"]-audit["U0_projected_energy"])<=2e-10 &&
            abs(audit["U0_projection_weight"]-1)<=2e-10
        push!(sources,wickpath)
    end
    return (;U=job.U,metrics=audit,free,free_pass,literal,
        pass=abs(audit["norm_squared"]-1)<=1e-7 && audit["onsite_fourier_sumrule_error"]<=2e-11 &&
             audit["C4_residual_to_nearest_eigenvalue"]<=1e-7 && (literal===nothing || literal.pass))
end

function verify_plot_csv(path,data)
    rows = P.read_scalar_csv(path,("U","qx_over_pi","qy_over_pi","Szz_raw","S_published",
        "difference","reference_extraction_allowance","ground_energy","ground_residual"))
    length(rows)==8 || error("plot comparison must contain eight points")
    for d in data, comparison in d.comparisons
        found = filter(row->abs(P.number(row,"U")-d.U)<=1e-12 && P.same_q(row,(comparison.qx,comparison.qy)),rows)
        length(found)==1 || error("missing/duplicate plot comparison")
        row = only(found)
        for (key,value) in (("Szz_raw",comparison.Szz_raw),("S_published",comparison.reference),
            ("difference",comparison.difference),("reference_extraction_allowance",comparison.allowance),
            ("ground_energy",d.energy),("ground_residual",d.residual))
            isapprox(P.number(row,key),value;atol=5e-11,rtol=1e-12) || error("stale plot comparison: $key")
        end
    end
end

function write_report(path,jobs,data,replicas,audits,minimum_checks)
    comparison_pass = all(row.within_extraction_allowance for d in data for row in d.comparisons)
    numerical_pass = all(job.residual_pass for job in jobs) && all(r.energy_pass && r.spin_pass for r in replicas) &&
        all(a.pass for a in audits) && all(m.pass for m in minimum_checks) && any(a.free && a.free_pass for a in audits)
    outcome = numerical_pass && comparison_pass ? "PASS: Figure 2(a) agrees within the graphics extraction allowance." :
        comparison_pass ? "NOT COMPLETE: the plotted points agree, but one or more numerical validation checks failed." :
        "DISCREPANCY: Figure 2(a) does not agree within the graphics extraction allowance."
    open(path,"w") do io
        println(io,"# PRL 101, 237004 — milestone 3: eight-site Figure 2(a)\n")
        println(io,"**",outcome,"**\n")
        println(io,"Generated ",now()," from ten completed jobs: eight symmetry-inequivalent momentum searches across the two U values, plus two independent Gamma starts. Numerical checks: **",flag(numerical_pass),"**; published-curve comparison: **",flag(comparison_pass),"**. No interacting rescaling or parameter fit was applied.\n")
        println(io,"| U | q/π | Computed raw Szz | Published | Difference | Allowance | Result |\n|---:|:---:|---:|---:|---:|---:|:---:|")
        for d in data, r in d.comparisons
            println(io,"| ",d.U," | (",r.qx,",",r.qy,") | ",fmt(r.Szz_raw)," | ",fmt(r.reference)," | ",fmt(r.difference)," | ±",fmt(r.allowance)," | ",flag(r.within_extraction_allowance)," |")
        end
        println(io,"\nThe ±0.006 interval describes extraction of the published vector graphics. It is not a statistical interval, an author-supplied uncertainty, or an observable error inferred from a Lanczos residual. Full values are in [the comparison CSV](plots/fig2a_comparison.csv).\n")
        println(io,"![Computed and published Figure 2(a)](plots/fig2a_spin_structure.png)\n\n![Differences from the published curve](plots/fig2a_reference_difference.png)\n")
        println(io,"## Hamiltonian and observable\n")
        p = MODEL.slater_koster_parameters(-0.2)
        println(io,"The calculation uses literal Eqs. (1) and (2) of the [PRL](https://doi.org/10.1103/PhysRevLett.101.237004): orbital order (dxz,dyz), pdπ/pdσ=−0.2, energy unit (pdσ)²/Δpd, and hoppings (t1,t2,t3,t4)=",tuple(p.t1,p.t2,p.t3,p.t4),". The torus has primitive translations (2,2) and (−2,2), eight Fe sites, and Nup=Ndown=8. Periodic images of coincident hopping bonds are added. U=0.5 or 1, J=U/4, U′=U−2J, and pair hopping J′=J. The Hund term is −2J Sxz·Syz, with physical spin one-half. No chemical-potential energy shift is included.\n")
        println(io,"The authors' [2012 erratum](https://doi.org/10.1103/PhysRevB.85.139904) corrects a missing factor of two in the ab contribution to the Slater–Koster t4 formula. At these parameters the corrected formula gives t4=−0.19840044, compared with the original −0.07899972. The erratum states that the erroneous expression was also used in the PRL calculations; it supplies revised follow-up Fermi surfaces but no replacement magnetic curves. This report therefore retains the original printed Hamiltonian for comparison with the original Figure 2(a). The erratum does not establish the cause of any numerical discrepancy shown here.\n")
        println(io,"With Sz_i=(n_i↑−n_i↓)/2 summed over both orbitals, the plotted raw quantity is ⟨Sz(q)Sz(−q)⟩. Thus raw Szz=8 Szz per Fe=(8/3) Sdot per Fe for these verified singlets. This convention is **inferred** from the independent U=0 curve in [the authors' follow-up](https://arxiv.org/abs/0901.3544), which gives (0,2,4,0) at the four plotted classes. Neither publication prints a complete S(q) operator formula. See [the reference audit](",joinpath(P.ROOT,"docs","prl_101_237004_fig2_reference.md"),") for the extraction, inference, and limits.\n")
        println(io,"## Sector and independent-start checks\n")
        println(io,"| U | Momentum class | C4 multiplicity | Seed | Lowest energy | Direct residual | Target | Result |\n|---:|:---|---:|---:|---:|---:|---:|:---:|")
        for j in jobs
            println(io,"| ",j.U," | ",j.label," | ",j.multiplicity," | ",j.seed," | ",@sprintf("%.14f",j.energy)," | ",fmt(P.number(first(j.rows),"residual"))," | ",j.target," | ",flag(j.residual_pass)," |")
        end
        println(io,"\nTargets allow an additional 64ε max(1,|E|) for Float64 roundoff. [The energy CSV](energy_sector_comparison.csv) retains every completed root; Gamma replicas are marked separately and do not add new momentum classes. Its matvec counts and elapsed times describe the final solver invocation. For resumed jobs, earlier work remains recorded in metadata.txt and the separate progress CSV files; these columns are not total campaign costs.\n")
        for r in replicas
            println(io,"- U=",r.U,": independent Gamma starts differ by ",fmt(r.energy_difference)," in energy (limit 1e−8; ",flag(r.energy_pass),") and by at most ",fmt(r.spin_difference)," in raw Szz over all eight q (limit 1e−6; ",flag(r.spin_pass),").")
        end
        for m in minimum_checks
            println(io,"- U=",m.U,": Gamma is a minimum among the four searched class representatives within 1e−8: ",flag(m.pass),"; minimum recorded class is ",m.minimum_label," at E=",@sprintf("%.14f",m.minimum_energy),".")
        end
        println(io,"\nC4 maps the eight momenta into Gamma (1), stripe (2), M (1), and diagonal (4). The Hamiltonian is spin-rotation invariant and N=16 is even, so every integer-total-spin multiplet contains an Sz=0 state represented in this particle sector. Searching these momentum classes therefore covers the possible ground-state symmetry sectors, subject to finding each block's lowest state.\n")
        println(io,"The direct residual verifies the approximate eigenvector equation and bounds the reported energy's distance to the spectrum. Without a spectral-gap bound, it does not certify eigenvector or observable error, or establish that the state is lowest. Sector searches and independent random starts provide strong numerical evidence, not a rigorous global certificate or a proof of nondegeneracy. No excitation gap is inferred from the second Krylov Ritz value or an unfinished root.\n")
        println(io,"## Independent observable audits\n")
        for a in audits
            m = a.metrics
            println(io,"- U=",a.U,": direct onsite/Fourier sum-rule difference ",fmt(m["onsite_fourier_sumrule_error"])," (limit 2e−11); local physical ⟨S²⟩=",fmt(3m["onsite_total_z_squared"]),"; C4 expectation ",fmt(m["C4_expectation_real"])," + i ",fmt(m["C4_expectation_imag"]),", residual to its nearest C4 eigenvalue ",fmt(m["C4_residual_to_nearest_eigenvalue"])," (limit 1e−7). Combined audit: ",flag(a.pass),".")
            if a.literal!==nothing
                println(io,"- U=",a.U,": literal fermionic operators and direct translations agree with the production Hamiltonian on ",a.literal.count," sampled rows; maximum coefficient difference ",fmt(a.literal.max_error)," (limit 2e−12). This samples production rows and supplements the exhaustive small-sector operator tests; it is not an exhaustive eight-site matrix comparison.")
            end
            if a.free
                println(io,"- U=0 audit attached to U=",a.U,": independent Wick/projected-Slater raw-Szz maximum difference ",fmt(m["U0_max_Wick_Slater_raw_Szz_error"]),", direct free-state residual ",fmt(m["U0_direct_residual"]),", and one-particle gap ",fmt(m["U0_orbital_gap"]),". Free benchmark: ",flag(a.free_pass),".")
            end
        end
        println(io,"\nEach canonical Gamma folder retains independent_audit.csv, audit_source_provenance.csv, and its source snapshot. The audit distinguishes exact production-source matches from the explicitly checked validation-only operator change and legacy transitive-source supplements. A supplement is not retroactively described as a recorded production hash.\n")
        input = dirname(first(jobs).directory)
        pilot = joinpath(input,"pilot_U0p5_gamma_seed7_nev2")
        if isdir(pilot)
            println(io,"The retained two-root pilot directory is excluded from the completed-sector table. Its lowest Ritz vector after 124 matrix applications seeded the canonical U=0.5 Gamma refinement, which required 17 further applications. The converged U=0.5 vector then seeded the U=1 Gamma calculation. Both have separate seed-29 replicas started from random vectors. The pilot did not finish its two-root request; its partial estimates do not establish an excitation gap.\n")
        end
        validation = filter(name->occursin(r"(?i)(validation|test)",name) && isfile(joinpath(input,name)),readdir(input))
        if isempty(validation)
            println(io,"Full-suite validation is recorded separately; no full-suite output was attached when this report was generated. The generator does not infer a test count from the presence of source files.\n")
        else
            println(io,"Separate validation artifacts: ",join(["[$name]($name)" for name in validation],", "),". Their contents, rather than this generator, establish test results and counts.\n")
        end
        println(io,"## Reproduce from the repository root\n")
        println(io,"Use a fresh output directory; completed jobs are deliberately preserved. The following commands run sequentially to bound memory. Defaults request one root, keep three Ritz vectors, and use Krylov dimension 16 (9 for the complex diagonal block). During this campaign the later real non-Gamma searches used dimension 22 and four BLAS threads to improve convergence speed. Each job's metadata records its actual settings; changing these settings can change iteration counts while preserving the directly checked eigenpair accuracy.\n")
        println(io,raw"""```bash
export JULIA_NUM_THREADS=4 OPENBLAS_NUM_THREADS=1
out=results/prl_101_237004/milestone3_reproduction
for U in 0.5 1.0; do
  julia --project=. scripts/run_prl_101_237004_milestone3.jl --output-dir="$out" --U="$U" --k=gamma --seed=7 --start=free --nev=1 --krylovdim=16 --keep=3 --atol=1e-9
  julia --project=. scripts/run_prl_101_237004_milestone3.jl --output-dir="$out" --U="$U" --k=gamma --seed=29 --start=random --nev=1 --krylovdim=16 --keep=3 --atol=1e-9
  for k in stripe M; do
    julia --project=. scripts/run_prl_101_237004_milestone3.jl --output-dir="$out" --U="$U" --k="$k" --seed=7 --start=random --nev=1 --krylovdim=16 --keep=3 --atol=1e-7
  done
  julia --project=. scripts/run_prl_101_237004_milestone3.jl --output-dir="$out" --U="$U" --k=diagonal --seed=7 --start=random --nev=1 --krylovdim=9 --keep=3 --atol=1e-7
done
julia --project=. scripts/audit_prl_101_237004_milestone3.jl --job-dir="$out/U0p5_gamma_seed7" --diagnostics
julia --project=. scripts/audit_prl_101_237004_milestone3.jl --job-dir="$out/U1p0_gamma_seed7" --diagnostics
julia --project=. scripts/plot_prl_101_237004_fig2a.jl --input-root="$out"
julia --project=. scripts/summarize_prl_101_237004_milestone3.jl --input-root="$out"
julia --project=. test/runtests.jl
```""")
        println(io,"\nU=1 may instead use --initial-checkpoint pointing to the U=0.5 Gamma checkpoint as a starting vector; the runner checks basis compatibility and directly recomputes the new eigenpair residual. The seed-29 random starts remain independent. The default maximum is 600 matvecs; --resume requires matching checkpoint metadata and numerical source hashes. Recreating plots or this report in place requires --overwrite; that flag does not replace simulation outputs.\n")
        println(io,"Milestone 3 concerns the finite eight-site Figure 2(a). It does not establish bulk magnetic order or reproduce the later VCA, spectral-function, or pairing panels.")
    end
end

function summarize(input,reference;overwrite=false)
    input = abspath(input)
    isdir(input) || error("campaign directory does not exist: $input")
    !overwrite && any(ispath(joinpath(input,name)) for name in OUTPUTS) && error("summary output exists; use --overwrite")
    # Whitelisted names exclude unfinished pilots and unrelated diagnostics.
    jobs,sources = read_campaign(input)
    data,plot_sources = P.collect_comparison(input,reference)
    append!(sources,plot_sources)
    comparison_path = joinpath(input,"plots","fig2a_comparison.csv")
    verify_plot_csv(comparison_path,data)
    push!(sources,comparison_path)
    replicas,audits,minimum_checks = NamedTuple[],NamedTuple[],NamedTuple[]
    for U in (0.5,1.0)
        canonical = only(filter(j->j.U==U && j.label=="gamma" && j.seed==7,jobs))
        replica = only(filter(j->j.U==U && j.label=="gamma" && j.seed==29,jobs))
        push!(replicas,replica_check(canonical,replica,sources))
        push!(audits,read_audit(canonical,sources))
        representatives = filter(j->j.U==U && j.seed==7,jobs)
        lowest = representatives[argmin(j.energy for j in representatives)]
        push!(minimum_checks,(;U,minimum_label=lowest.label,minimum_energy=lowest.energy,
            pass=canonical.energy<=lowest.energy+1e-8))
    end
    any(a.free for a in audits) || error("at least one canonical audit must include the independent U=0 benchmark")
    append!(sources,[abspath(@__FILE__),joinpath(@__DIR__,"prl_101_237004_model.jl")])
    stage = mktempdir(input;prefix=".milestone3_summary_")
    try
        open(joinpath(stage,"energy_sector_comparison.csv"),"w") do io
            println(io,"job,U,J,k_label,kx_over_pi,ky_over_pi,C4_multiplicity,seed,is_replica,dimension,root,energy,residual,residual_target,residual_roundoff_allowance,residual_pass,energy_minus_canonical_gamma,matvecs,seconds,solver_workspace_bytes")
            for job in jobs, row in job.rows
                canonical = only(filter(j->j.U==job.U && j.label=="gamma" && j.seed==7,jobs))
                energy,residual = P.number(row,"energy"),P.number(row,"residual")
                println(io,join((job.name,job.U,job.U/4,job.label,job.q...,job.multiplicity,job.seed,job.seed==29,
                    integer(row,"dimension"),integer(row,"root"),energy,residual,job.target,roundoff(energy),
                    residual<=job.target+roundoff(energy),energy-canonical.energy,integer(row,"matvecs"),
                    P.number(row,"seconds"),integer(row,"solver_workspace_bytes")),','))
            end
        end
        write_report(joinpath(stage,"report.md"),jobs,data,replicas,audits,minimum_checks)
        open(joinpath(stage,"report_provenance.txt"),"w") do io
            println(io,"Generated: ",now(),"; Julia: ",VERSION)
            println(io,"Input and generator SHA-256:")
            for path in sort(unique(sources))
                println(io,filehash(path),"  ",abspath(path))
            end
            println(io,"Generated output SHA-256:")
            for name in OUTPUTS[1:2]
                println(io,filehash(joinpath(stage,name)),"  ",name)
            end
        end
        for name in OUTPUTS
            mv(joinpath(stage,name),joinpath(input,name);force=overwrite)
        end
    finally
        rm(stage;recursive=true,force=true)
    end
    println("Generated completed-campaign report: ",joinpath(input,"report.md"))
    return nothing
end

function main(arguments=ARGS)
    options = Dict("input-root"=>P.DEFAULT_INPUT,"reference"=>P.DEFAULT_REFERENCE)
    overwrite = false
    for argument in arguments
        if argument=="--overwrite"
            overwrite=true
        elseif argument=="--help"
            println("Usage: julia --project=. scripts/summarize_prl_101_237004_milestone3.jl [--input-root=DIR] [--reference=CSV] [--overwrite]")
            println("Requires ten completed jobs, two canonical independent audits (at least one with U=0), and plots/fig2a_comparison.csv. Writes report.md, energy_sector_comparison.csv, report_provenance.txt only.")
            return nothing
        else
            startswith(argument,"--") && occursin('=',argument) || error("use --key=value")
            key,value = split(argument[3:end],'=';limit=2)
            haskey(options,key) || error("unknown option --$key")
            options[key]=value
        end
    end
    summarize(options["input-root"],options["reference"];overwrite)
end

end

if abspath(PROGRAM_FILE)==@__FILE__
    PRL101237004Milestone3Summary.main()
end
