#!/usr/bin/env julia

# Sequential fixed-density beta scan for square_hubbard_two_orbital.jl.
# At each beta this performs (1) dynamic chemical-potential tuning, followed by
# (2) a fresh, fixed-mu, rethermalized run whose average sign is used for the
# threshold decision. Every phase runs in a separate Julia process and saves
# its log, summary, raw bins, and (for tuning) complete PRE tuner history.

using Dates
using Printf
using SHA

# Physics requested for this scan.
const U_SCAN = 2.0
const L_SCAN = 4
const TARGET_DENSITY = 1.42
const DTAU_SCAN = 0.05
const INITIAL_MU = -1.897
const SIGN_THRESHOLD = 0.1
const MINIMUM_TUNING_SIGN = 0.05
const STABILIZATION_PERIOD = 5

# The tutorial's 20/50 settings are only a smoke test. These defaults are a
# moderate first scan; all counts can be overridden through the DQMC_SCAN_*
# environment variables listed by --help.
const DEFAULT_TUNE_BURNIN = 200
const DEFAULT_TUNE_MEASUREMENTS = 800
const DEFAULT_PRODUCTION_BURNIN = 400
const DEFAULT_PRODUCTION_MEASUREMENTS = 1600
const DEFAULT_SWEEPS_BETWEEN = 2
const DEFAULT_BINS = 16
const DEFAULT_BASE_SEED = 20250817
const DEFAULT_DENSITY_ABSOLUTE_TOLERANCE = 0.02

function usage(io::IO=stdout)
    println(io, "Usage:")
    println(io, "  julia --project=. scripts/sweep_square_hubbard_two_orbital_beta.jl [beta ...]")
    println(io)
    println(io, "With no beta arguments, scans beta = 1,2,...,16 in order and stops")
    println(io, "once the fixed-mu sign is confidently below 0.1.")
    println(io)
    println(io, "Optional workload environment variables:")
    println(io, "  DQMC_SCAN_TUNE_BURNIN, DQMC_SCAN_TUNE_MEASUREMENTS")
    println(io, "  DQMC_SCAN_PRODUCTION_BURNIN, DQMC_SCAN_PRODUCTION_MEASUREMENTS")
    println(io, "  DQMC_SCAN_SWEEPS_BETWEEN, DQMC_SCAN_BINS, DQMC_SCAN_BASE_SEED")
    println(io, "  DQMC_SCAN_DENSITY_TOLERANCE, DQMC_SCAN_OUTPUT")
end

if any(argument -> argument in ("-h", "--help"), ARGS)
    usage()
    exit()
end

parse_env(::Type{T}, key::AbstractString, default) where {T} =
    haskey(ENV, key) ? parse(T, strip(ENV[key])) : convert(T, default)

tune_burnin = parse_env(Int, "DQMC_SCAN_TUNE_BURNIN", DEFAULT_TUNE_BURNIN)
tune_measurements = parse_env(Int, "DQMC_SCAN_TUNE_MEASUREMENTS", DEFAULT_TUNE_MEASUREMENTS)
production_burnin = parse_env(Int, "DQMC_SCAN_PRODUCTION_BURNIN", DEFAULT_PRODUCTION_BURNIN)
production_measurements = parse_env(Int, "DQMC_SCAN_PRODUCTION_MEASUREMENTS", DEFAULT_PRODUCTION_MEASUREMENTS)
sweeps_between = parse_env(Int, "DQMC_SCAN_SWEEPS_BETWEEN", DEFAULT_SWEEPS_BETWEEN)
number_of_bins = parse_env(Int, "DQMC_SCAN_BINS", DEFAULT_BINS)
base_seed = parse_env(Int, "DQMC_SCAN_BASE_SEED", DEFAULT_BASE_SEED)
density_absolute_tolerance = parse_env(
    Float64,
    "DQMC_SCAN_DENSITY_TOLERANCE",
    DEFAULT_DENSITY_ABSOLUTE_TOLERANCE,
)

for (name, value) in (
    ("tune burn-in", tune_burnin),
    ("tune measurements", tune_measurements),
    ("production burn-in", production_burnin),
    ("production measurements", production_measurements),
    ("sweeps between measurements", sweeps_between),
    ("number of bins", number_of_bins),
)
    value > 0 || error("$name must be positive")
end
number_of_bins > 1 || error("number of bins must exceed one")
tune_measurements % number_of_bins == 0 || error(
    "tune measurements must be divisible by the number of bins",
)
production_measurements % number_of_bins == 0 || error(
    "production measurements must be divisible by the number of bins",
)
density_absolute_tolerance >= 0 || error("density tolerance must be nonnegative")

betas = isempty(ARGS) ? collect(1.0:1.0:16.0) : parse.(Float64, ARGS)
all(isfinite, betas) && all(>(0), betas) || error("all beta values must be finite and positive")
issorted(betas) || error("beta values must be supplied in increasing order")
length(unique(betas)) == length(betas) || error("beta values must not be repeated")
for beta in betas
    ratio = beta / DTAU_SCAN
    slices = round(Int, ratio)
    tolerance = 64eps(ratio) * max(1, abs(ratio))
    abs(ratio - slices) <= tolerance || error(
        "beta=$beta is incompatible with dtau=$DTAU_SCAN because beta/dtau is not integral",
    )
end

repo_root = normpath(joinpath(@__DIR__, ".."))
source_path = joinpath(@__DIR__, "square_hubbard_two_orbital.jl")
point_runner = joinpath(@__DIR__, "run_square_hubbard_two_orbital_point.jl")
isfile(source_path) || error("working script not found: $source_path")
isfile(point_runner) || error("point runner not found: $point_runner")

source = read(source_path, String)
source_hash = bytes2hex(sha256(source))
git_commit = try
    cd(repo_root) do
        readchomp(`git rev-parse HEAD`)
    end
catch
    "unavailable"
end
git_status = try
    cd(repo_root) do
        readchomp(`git status --short`)
    end
catch
    "unavailable"
end

timestamp = Dates.format(Dates.now(), dateformat"yyyymmdd_HHMMSS")
default_output = joinpath(
    repo_root,
    "results",
    "two_orbital_beta_sign_scan_" * timestamp * "_" * source_hash[1:10],
)
result_root = abspath(get(ENV, "DQMC_SCAN_OUTPUT", default_output))
ispath(result_root) && error("refusing to overwrite existing output path: $result_root")
mkpath(result_root)

source_snapshot = joinpath(result_root, "square_hubbard_two_orbital_snapshot.jl")
write(source_snapshot, source)
write(joinpath(result_root, "source_sha256.txt"), source_hash * "\n")

function csv_escape(value)
    text = value === nothing ? "" : string(value)
    occursin(r"[,\"\n\r]", text) || return text
    return "\"" * replace(text, "\"" => "\"\"") * "\""
end

function write_single_row(path::AbstractString, row::NamedTuple)
    columns = propertynames(row)
    open(path, "w") do io
        println(io, join(string.(columns), ','))
        println(io, join((csv_escape(getproperty(row, column)) for column in columns), ','))
    end
end

config = (
    schema_version=1,
    created_utc=Dates.format(Dates.now(Dates.UTC), dateformat"yyyy-mm-ddTHH:MM:SS") * "Z",
    source_path=source_path,
    source_sha256=source_hash,
    git_commit=git_commit,
    git_dirty=!isempty(git_status),
    U=U_SCAN,
    L=L_SCAN,
    target_density=TARGET_DENSITY,
    target_doping=(TARGET_DENSITY - 2) / 4,
    dtau=DTAU_SCAN,
    beta_values=join(betas, ';'),
    sign_threshold=SIGN_THRESHOLD,
    initial_mu=INITIAL_MU,
    minimum_tuning_sign=MINIMUM_TUNING_SIGN,
    stabilization_period=STABILIZATION_PERIOD,
    tune_burnin=tune_burnin,
    tune_measurements=tune_measurements,
    production_burnin=production_burnin,
    production_measurements=production_measurements,
    sweeps_between_measurements=sweeps_between,
    bins=number_of_bins,
    base_seed=base_seed,
    density_absolute_tolerance=density_absolute_tolerance,
)
write_single_row(joinpath(result_root, "scan_config.csv"), config)
write(joinpath(result_root, "git_status_at_start.txt"), git_status * (isempty(git_status) ? "" : "\n"))

function read_key_values(path::AbstractString)
    values = Dict{String,String}()
    for line in eachline(path)
        isempty(strip(line)) && continue
        pieces = split(line, '='; limit=2)
        length(pieces) == 2 || error("invalid summary line in $path: $line")
        values[pieces[1]] = pieces[2]
    end
    return values
end

function beta_slug(index::Int, beta::Float64)
    text = replace(@sprintf("%.3f", beta), '-' => 'm', '.' => 'p')
    return @sprintf("beta_%03d_%s", index, text)
end

function run_phase(
    beta_dir::AbstractString,
    phase::AbstractString,
    beta::Float64,
    mu::Float64,
    tuning::Bool,
    burnin::Int,
    measurements::Int,
    seed::Int,
)
    phase_dir = joinpath(beta_dir, phase)
    ispath(phase_dir) && error("refusing to overwrite phase directory: $phase_dir")
    mkpath(phase_dir)

    environment = copy(ENV)
    settings = Dict(
        "DQMC_SOURCE_SNAPSHOT" => source_snapshot,
        "DQMC_ORIGINAL_SOURCE" => source_path,
        "DQMC_OUTPUT_DIR" => phase_dir,
        "DQMC_RUN_PHASE" => phase,
        "DQMC_RUN_LABEL" => basename(beta_dir) * "_" * phase,
        "DQMC_U" => string(U_SCAN),
        "DQMC_MU" => string(mu),
        "DQMC_DENSITY_TUNING" => string(tuning),
        "DQMC_TARGET_DENSITY" => string(TARGET_DENSITY),
        "DQMC_MIN_TUNING_SIGN" => string(MINIMUM_TUNING_SIGN),
        "DQMC_BETA" => string(beta),
        "DQMC_L" => string(L_SCAN),
        "DQMC_DTAU" => string(DTAU_SCAN),
        "DQMC_N_STAB" => string(STABILIZATION_PERIOD),
        "DQMC_N_BURNIN" => string(burnin),
        "DQMC_N_MEASUREMENTS" => string(measurements),
        "DQMC_N_SWEEPS" => string(sweeps_between),
        "DQMC_N_BINS" => string(number_of_bins),
        "DQMC_SEED" => string(seed),
    )
    merge!(environment, settings)

    command = `$(Base.julia_cmd()) --startup-file=no --history-file=no --threads=1 --project=$(repo_root) $(point_runner)`
    log_path = joinpath(phase_dir, "stdout.log")
    succeeded = open(log_path, "w") do io
        try
            run(pipeline(setenv(command, environment), stdout=io, stderr=io))
            true
        catch err
            println(io)
            println(io, "Sweep driver observed child-process failure:")
            showerror(io, err)
            println(io)
            false
        end
    end
    succeeded || return nothing

    summary_path = joinpath(phase_dir, "summary.txt")
    isfile(summary_path) || error("completed child did not write $summary_path")
    return read_key_values(summary_path)
end

function append_decision(path::AbstractString, row::NamedTuple)
    columns = propertynames(row)
    first_row = !isfile(path)
    open(path, first_row ? "w" : "a") do io
        first_row && println(io, join(string.(columns), ','))
        println(io, join((csv_escape(getproperty(row, column)) for column in columns), ','))
    end
end

println("Two-orbital fixed-density beta scan")
println("  U = $U_SCAN, L = $L_SCAN, target density = $TARGET_DENSITY, dtau = $DTAU_SCAN")
println("  beta values = ", join(betas, ", "))
println("  result directory = $result_root")
println("  source SHA-256 = $source_hash")
println()

let decision_file = joinpath(result_root, "beta_scan_summary.csv"),
    current_mu = INITIAL_MU,
    scan_outcome = "NO_CONFIRMED_CROSSING_IN_REQUESTED_RANGE"

for (index, beta) in enumerate(betas)
    beta_dir = joinpath(result_root, beta_slug(index, beta))
    mkpath(beta_dir)
    tune_seed = base_seed + 2index - 2
    production_seed = tune_seed + 1

    println("beta=$beta: tuning mu from $current_mu ...")
    tune = run_phase(
        beta_dir,
        "tune",
        beta,
        current_mu,
        true,
        tune_burnin,
        tune_measurements,
        tune_seed,
    )
    if isnothing(tune)
        scan_outcome = "TUNING_FAILED_AT_BETA_$(beta)"
        write(joinpath(result_root, "scan_status.txt"), scan_outcome * "\n")
        error("density-tuning phase failed at beta=$beta; see $(joinpath(beta_dir, "tune", "stdout.log"))")
    end

    tuned_mu = parse(Float64, tune["newest_half_mean_mu"])
    isfinite(tuned_mu) || error("tuning returned a non-finite mean mu at beta=$beta")
    println("beta=$beta: fixed-mu production at mu=$tuned_mu ...")
    production = run_phase(
        beta_dir,
        "fixed_mu",
        beta,
        tuned_mu,
        false,
        production_burnin,
        production_measurements,
        production_seed,
    )
    if isnothing(production)
        scan_outcome = "FIXED_MU_RUN_FAILED_AT_BETA_$(beta)"
        write(joinpath(result_root, "scan_status.txt"), scan_outcome * "\n")
        error("fixed-mu phase failed at beta=$beta; see $(joinpath(beta_dir, "fixed_mu", "stdout.log"))")
    end

    average_sign = parse(Float64, production["average_sign"])
    sign_error = parse(Float64, production["average_sign_standard_error"])
    sign_magnitude = abs(average_sign)
    lower = max(0.0, sign_magnitude - 2sign_error)
    upper = min(1.0, sign_magnitude + 2sign_error)
    density = parse(Float64, production["total_density"])
    density_error = parse(Float64, production["total_density_standard_error"])
    density_tolerance = max(density_absolute_tolerance, 2density_error)
    density_compatible = abs(density - TARGET_DENSITY) <= density_tolerance
    point_estimate_below = sign_magnitude < SIGN_THRESHOLD

    classification = if !density_compatible
        "RETUNE_REQUIRED"
    elseif upper < SIGN_THRESHOLD
        "CONFIRMED_BELOW"
    elseif lower >= SIGN_THRESHOLD
        "CONFIRMED_ABOVE"
    else
        "INCONCLUSIVE_NEAR_THRESHOLD"
    end

    decision = (
        beta=beta,
        time_slices=round(Int, beta / DTAU_SCAN),
        tuned_mu=tuned_mu,
        tuning_newest_half_density=parse(Float64, tune["newest_half_mean_density"]),
        tuning_newest_half_average_sign=parse(Float64, tune["tuning_window_average_sign"]),
        average_sign=average_sign,
        average_sign_standard_error=sign_error,
        sign_lower_2se=lower,
        sign_upper_2se=upper,
        point_estimate_below_0p1=point_estimate_below,
        total_density=density,
        total_density_standard_error=density_error,
        density_tolerance=density_tolerance,
        density_compatible=density_compatible,
        classification=classification,
        tune_seed=tune_seed,
        production_seed=production_seed,
        tune_directory=relpath(joinpath(beta_dir, "tune"), result_root),
        production_directory=relpath(joinpath(beta_dir, "fixed_mu"), result_root),
    )
    append_decision(decision_file, decision)

    @printf(
        "beta=%.3f: |sign|=%.6f +/- %.6f, n=%.6f +/- %.6f -> %s\n",
        beta,
        sign_magnitude,
        sign_error,
        density,
        density_error,
        classification,
    )

    current_mu = tuned_mu
    if classification == "CONFIRMED_BELOW"
        scan_outcome = "FIRST_TESTED_BETA_CONFIRMED_BELOW_0P1=$(beta)"
        break
    elseif classification == "RETUNE_REQUIRED"
        scan_outcome = "RETUNE_REQUIRED_AT_BETA_$(beta)"
        println("Stopping because the fixed-mu density is not compatible with the target.")
        break
    end
end

write(joinpath(result_root, "scan_status.txt"), scan_outcome * "\n")
println()
println("Scan finished: $scan_outcome")
println("Saved results: $result_root")
end

