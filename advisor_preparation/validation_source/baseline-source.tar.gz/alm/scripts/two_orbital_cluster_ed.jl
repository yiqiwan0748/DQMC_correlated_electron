#!/usr/bin/env julia

module TwoOrbitalClusterED

using LinearAlgebra
using Serialization

# Reuse the validated hopping construction without loading the DQMC or plotting
# dependencies of the main package. Its ModelParameters type stays namespaced.
module ValidatedKinetic
include(joinpath(@__DIR__, "..", "src", "noninteracting.jl"))
include(joinpath(@__DIR__, "..", "src", "realspace_kinetic.jl"))
end

export solve_two_orbital_cluster,
       solve_two_orbital_ground_state,
       broaden_cluster_spectra,
       altermagnetic_xy_diagnostics,
       tune_cluster_mu,
       many_body_spin_pairing_error,
       ground_state_spin_pairing_error,
       spin_pairing_error,
       scan_spin_degeneracy,
       compare_cluster_payload,
       save_cluster_result

const CLUSTER_LIMITATION =
    "L=2 periodic t4 cancels: two independent four-site orbital clusters. " *
    "This is an exact finite-cluster benchmark, not evidence for bulk altermagnetism."

const L2_MOMENTA = ((0, 0), (1, 0), (0, 1), (1, 1))

function _translated_fock_state(state::Int, nx::Int, ny::Int)
    destinations = Int[]
    translated = 0
    for mode in 1:8
        state & (1 << (mode - 1)) == 0 && continue
        site = mod(mode - 1, 4) + 1
        spin_offset = mode > 4 ? 4 : 0
        x = mod(site - 1, 2)
        y = div(site - 1, 2)
        destination_site = mod(x + nx, 2) + 2mod(y + ny, 2) + 1
        destination = spin_offset + destination_site
        push!(destinations, destination)
        translated |= 1 << (destination - 1)
    end
    inversions = sum((
        destinations[left] > destinations[right]
        for left in eachindex(destinations)
        for right in (left + 1):length(destinations)
    ); init=0)
    return translated, iseven(inversions) ? 1.0 : -1.0
end

function _translation_matrix(basis, indices, nx::Int, ny::Int)
    translation = zeros(Float64, length(basis), length(basis))
    for (column, state) in enumerate(basis)
        translated, sign = _translated_fock_state(state, nx, ny)
        translation[indices[translated], column] = sign
    end
    return translation
end

function _momentum_basis(identity_sector, translation_x, translation_y, nx, ny)
    sign_x = iszero(nx) ? 1.0 : -1.0
    sign_y = iszero(ny) ? 1.0 : -1.0
    projector = (identity_sector + sign_x * translation_x) *
                (identity_sector + sign_y * translation_y) / 4
    decomposition = eigen(Symmetric((projector + transpose(projector)) / 2))
    selected = findall(value -> value > 0.5, decomposition.values)
    return decomposition.vectors[:, selected]
end

function _momentum_diagonalization(hamiltonian, basis, indices)
    dimension = length(basis)
    identity_sector = Matrix{Float64}(I, dimension, dimension)
    translation_x = _translation_matrix(basis, indices, 1, 0)
    translation_y = _translation_matrix(basis, indices, 0, 1)
    energies = Float64[]
    vector_blocks = Matrix{Float64}[]
    kx_indices = Int[]
    ky_indices = Int[]
    for (nx, ny) in L2_MOMENTA
        momentum_basis = _momentum_basis(
            identity_sector, translation_x, translation_y, nx, ny,
        )
        isempty(momentum_basis) && continue
        block = Symmetric(transpose(momentum_basis) * hamiltonian * momentum_basis)
        decomposition = eigen(block)
        append!(energies, decomposition.values)
        push!(vector_blocks, momentum_basis * decomposition.vectors)
        append!(kx_indices, fill(nx + 1, length(decomposition.values)))
        append!(ky_indices, fill(ny + 1, length(decomposition.values)))
    end
    length(energies) == dimension || error("momentum projectors are incomplete")
    vectors = hcat(vector_blocks...)
    permutation = sortperm(eachindex(energies); by=index -> (
        energies[index], kx_indices[index], ky_indices[index],
    ))
    return (
        values=energies[permutation],
        vectors=vectors[:, permutation],
        kx_indices=kx_indices[permutation],
        ky_indices=ky_indices[permutation],
        translation_x=translation_x,
        translation_y=translation_y,
    )
end

# The largest block is binomial(4,2)^2 = 36. The bit order is four up
# modes followed by four down modes, each in x-fast site order.
function _orbital_sectors(kinetic, U, mu, spin_field=0.0)
    sectors = Dict{Tuple{Int,Int},Any}()
    for nup in 0:4, ndown in 0:4
        basis = [state for state in 0:255
                 if count_ones(state & 15) == nup && count_ones(state >> 4) == ndown]
        indices = Dict(state => index for (index, state) in enumerate(basis))
        hamiltonian = zeros(Float64, length(basis), length(basis))
        doubles = zeros(Float64, length(basis))
        for (column, state) in enumerate(basis)
            doubles[column] = count_ones((state & 15) & (state >> 4))
            hamiltonian[column, column] =
                U * (doubles[column] - (nup + ndown) / 2 + 1) -
                mu * (nup + ndown) - spin_field * (nup - ndown) / 2
            for spin in 0:1, source in 1:4, destination in 1:4
                hopping = kinetic[destination, source]
                iszero(hopping) && continue
                source_bit = 1 << (source + 4spin - 1)
                state & source_bit == 0 && continue
                intermediate = state ⊻ source_bit
                destination_bit = 1 << (destination + 4spin - 1)
                intermediate & destination_bit != 0 && continue
                parity = count_ones(state & (source_bit - 1)) +
                         count_ones(intermediate & (destination_bit - 1))
                final_state = intermediate | destination_bit
                hamiltonian[indices[final_state], column] +=
                    iseven(parity) ? hopping : -hopping
            end
        end
        issymmetric(hamiltonian) || error("Fock Hamiltonian is not symmetric")
        decomposition = _momentum_diagonalization(hamiltonian, basis, indices)
        sectors[(nup, ndown)] = (
            basis=basis, indices=indices, energies=decomposition.values,
            vectors=decomposition.vectors, doubles=doubles,
            kx_indices=decomposition.kx_indices,
            ky_indices=decomposition.ky_indices,
            translation_x=decomposition.translation_x,
            translation_y=decomposition.translation_y,
            hamiltonian=hamiltonian,
        )
    end
    return sectors
end

function _orbital_levels(sectors)
    levels = [(energy=sector.energies[index], Nup=nup, Ndown=ndown,
               N=nup + ndown, Sz=(nup - ndown) / 2,
               eigen_index=index,
               kx_index=sector.kx_indices[index], ky_index=sector.ky_indices[index],
               kx=(sector.kx_indices[index] - 1) * pi,
               ky=(sector.ky_indices[index] - 1) * pi)
              for nup in 0:4 for ndown in 0:4
              for sector in (sectors[(nup, ndown)],)
              for index in eachindex(sector.energies)]
    return sort!(levels; by=level -> (
        level.energy, level.Nup, level.Ndown, level.kx_index, level.ky_index,
    ))
end

function _combine_orbital_levels(orbital_levels)
    levels = [(
        energy=first_level.energy + second_level.energy,
        Nup=first_level.Nup + second_level.Nup,
        Ndown=first_level.Ndown + second_level.Ndown,
        N=first_level.N + second_level.N,
        Sz=first_level.Sz + second_level.Sz,
        kx_index=mod(
            first_level.kx_index + second_level.kx_index - 2,
            2,
        ) + 1,
        ky_index=mod(
            first_level.ky_index + second_level.ky_index - 2,
            2,
        ) + 1,
    ) for first_level in orbital_levels[1] for second_level in orbital_levels[2]]
    levels = [merge(level, (
        kx=(level.kx_index - 1) * pi,
        ky=(level.ky_index - 1) * pi,
    )) for level in levels]
    return sort!(levels; by=level -> (
        level.energy, level.Nup, level.Ndown, level.kx_index, level.ky_index,
    ))
end

function _momentum_annihilation(lower, upper, spin, nx, ny)
    operator = zeros(Float64, length(lower.basis), length(upper.basis))
    for (column, state) in enumerate(upper.basis), site in 1:4
        bit = 1 << (site + 4(spin - 1) - 1)
        state & bit == 0 && continue
        row = lower.indices[state ⊻ bit]
        x = mod(site - 1, 2)
        y = div(site - 1, 2)
        # 1/sqrt(Ncells) = 1/2. All phases on this cluster are exactly +/-1.
        parity = count_ones(state & (bit - 1)) + nx * x + ny * y
        operator[row, column] = iseven(parity) ? 0.5 : -0.5
    end
    return operator
end

function _merge_spectral_peaks(frequencies, weights)
    merged_frequencies = Float64[]
    merged_weights = Float64[]
    # 1e-10 resolves roundoff copies of an ED transition. It is far below
    # physical hopping scales or any intended spectral broadening.
    for index in sortperm(frequencies)
        frequency, weight = frequencies[index], weights[index]
        weight > 0 || continue
        if !isempty(merged_frequencies) && abs(frequency - merged_frequencies[end]) <= 1.0e-10
            total = merged_weights[end] + weight
            merged_frequencies[end] += weight / total * (frequency - merged_frequencies[end])
            merged_weights[end] = total
        else
            push!(merged_frequencies, frequency)
            push!(merged_weights, weight)
        end
    end
    # At low temperature, transitions out of thermally inaccessible states can
    # retain weights as small as 1e-100. Degenerate eigenspaces are free to
    # rotate independently in the two spin-sector diagonalizations, so those
    # numerically null transitions need not be represented by identical lists.
    # Removing only total weights below 100 eps preserves the spectral measure
    # to machine precision and makes the symmetry audit basis-independent.
    keep = findall(>(100eps(Float64)), merged_weights)
    return (
        frequencies=merged_frequencies[keep],
        weights=merged_weights[keep],
    )
end

function _fermion_kernel(frequency, tau, beta)
    # Stable even when beta*abs(frequency) exceeds the exponential range.
    if frequency >= 0
        return exp(-tau * frequency) / (1 + exp(-beta * frequency))
    end
    return exp((beta - tau) * frequency) / (1 + exp(beta * frequency))
end

function _solve_orbital(kinetic, U, mu, beta, tau, spin_field=0.0)
    sectors = _orbital_sectors(kinetic, U, mu, spin_field)
    levels = _orbital_levels(sectors)
    energy_shift = first(levels).energy
    probabilities = Dict(key => exp.(-beta .* (sector.energies .- energy_shift))
                         for (key, sector) in sectors)
    partition_scaled = sum(sum(value) for value in values(probabilities))
    for value in values(probabilities)
        value ./= partition_scaled
    end
    particle_number = 0.0
    spin_polarization = 0.0
    double_occupancy = 0.0
    grand_energy = 0.0
    for ((nup, ndown), sector) in sectors
        probability = probabilities[(nup, ndown)]
        particle_number += (nup + ndown) * sum(probability)
        spin_polarization += (nup - ndown) * sum(probability)
        grand_energy += dot(probability, sector.energies)
        double_diagonal = vec(transpose(sector.doubles) * abs2.(sector.vectors))
        double_occupancy += dot(probability, double_diagonal)
    end

    green = zeros(Float64, 2, 2, 2, length(tau))
    peaks = Array{NamedTuple{(:frequencies, :weights),Tuple{Vector{Float64},Vector{Float64}}}}(
        undef, 2, 2, 2,
    )
    for spin in 1:2, ny in 0:1, nx in 0:1
        frequencies, weights = Float64[], Float64[]
        for nup in 0:4, ndown in 0:4
            (spin == 1 ? nup : ndown) == 0 && continue
            upper_key = (nup, ndown)
            lower_key = spin == 1 ? (nup - 1, ndown) : (nup, ndown - 1)
            upper, lower = sectors[upper_key], sectors[lower_key]
            operator = _momentum_annihilation(lower, upper, spin, nx, ny)
            amplitudes = transpose(lower.vectors) * operator * upper.vectors
            for initial in eachindex(lower.energies), final in eachindex(upper.energies)
                amplitude_squared = abs2(amplitudes[initial, final])
                # Drop only amplitudes below 1e-12: their spectral weight is
                # below 1e-24 per transition, well below Float64 sum accuracy.
                amplitude_squared <= 1.0e-24 && continue
                frequency = upper.energies[final] - lower.energies[initial]
                weight = (probabilities[lower_key][initial] +
                          probabilities[upper_key][final]) * amplitude_squared
                push!(frequencies, frequency)
                push!(weights, weight)
            end
        end
        channel = _merge_spectral_peaks(frequencies, weights)
        peaks[spin, nx + 1, ny + 1] = channel
        for (index, time) in enumerate(tau)
            green[spin, nx + 1, ny + 1, index] = sum(
                weight * _fermion_kernel(frequency, time, beta)
                for (frequency, weight) in zip(channel.frequencies, channel.weights)
            )
        end
    end
    return (
        green=green, peaks=peaks, levels=levels, particle_number=particle_number,
        spin_polarization=spin_polarization,
        double_occupancy=double_occupancy, grand_energy=grand_energy,
        log_partition=log(partition_scaled) - beta * energy_shift,
    )
end

function _particle_number_from_canonical_levels(levels, mu, beta)
    grand_energies = [level.energy - mu * level.N for level in levels]
    energy_shift = minimum(grand_energies)
    weights = exp.(-beta .* (grand_energies .- energy_shift))
    return dot(weights, getproperty.(levels, :N)) / sum(weights)
end

"""
    tune_cluster_mu(U, target_density, beta;
        parameters=ValidatedKinetic.ModelParameters(), h_alm=0,
        mu_bounds=(-40, 40), density_tolerance=1e-10,
        mu_tolerance=1e-12, max_iterations=200)

Tune the centered-interaction chemical potential of the periodic 2x2 cluster
to a requested grand-canonical density per physical cell. The density includes
both orbitals and both spins, so its range is zero to four. Canonical spectra
are diagonalized only once; changing `mu` then shifts a level by `-mu*N`.

This is finite-temperature grand-canonical tuning, not a canonical fixed-N
calculation. At very low temperature a density inside a finite-size plateau
may be unreachable to the requested tolerance; in that case `converged=false`
is returned once the chemical-potential interval is exhausted.
"""
function tune_cluster_mu(
    U::Real, target_density::Real, beta::Real;
    parameters=ValidatedKinetic.ModelParameters(),
    h_alm::Real=0.0,
    mu_bounds=(-40.0, 40.0),
    density_tolerance::Real=1.0e-10,
    mu_tolerance::Real=1.0e-12,
    max_iterations::Integer=200,
)
    interaction = Float64(U)
    target = Float64(target_density)
    inverse_temperature = Float64(beta)
    field = Float64(h_alm)
    isfinite(interaction) && interaction >= 0 ||
        throw(ArgumentError("U must be finite and nonnegative"))
    isfinite(target) && 0 < target < 4 ||
        throw(ArgumentError("target_density must lie strictly between zero and four"))
    isfinite(inverse_temperature) && inverse_temperature > 0 ||
        throw(ArgumentError("beta must be finite and positive"))
    isfinite(field) || throw(ArgumentError("h_alm must be finite"))
    length(mu_bounds) == 2 || throw(ArgumentError("mu_bounds must contain two values"))
    lower_mu, upper_mu = Float64(mu_bounds[1]), Float64(mu_bounds[2])
    isfinite(lower_mu) && isfinite(upper_mu) && lower_mu < upper_mu ||
        throw(ArgumentError("mu_bounds must be finite and increasing"))
    density_tol = Float64(density_tolerance)
    chemical_tol = Float64(mu_tolerance)
    isfinite(density_tol) && density_tol > 0 ||
        throw(ArgumentError("density_tolerance must be finite and positive"))
    isfinite(chemical_tol) && chemical_tol > 0 ||
        throw(ArgumentError("mu_tolerance must be finite and positive"))
    max_iterations isa Bool && throw(ArgumentError("max_iterations must be a positive integer"))
    max_iterations > 0 || throw(ArgumentError("max_iterations must be a positive integer"))

    hopping = (t1=Float64(parameters.t1), t2=Float64(parameters.t2),
               t3=Float64(parameters.t3), t4=Float64(parameters.t4))
    all(isfinite, values(hopping)) || throw(ArgumentError("hoppings must be finite"))
    model = ValidatedKinetic.ModelParameters(; hopping...)
    kinetic = ValidatedKinetic.realspace_kinetic_matrix(2, model)
    iszero(kinetic[1:2:8, 2:2:8]) || error("L=2 orbital factorization failed")
    canonical_levels = ntuple(orbital -> _orbital_levels(_orbital_sectors(
        kinetic[orbital:2:8, orbital:2:8], interaction, 0.0,
        orbital == 1 ? field : -field,
    )), 2)
    density_at(mu) = sum(
        _particle_number_from_canonical_levels(levels, mu, inverse_temperature)
        for levels in canonical_levels
    ) / 4

    lower_density, upper_density = density_at(lower_mu), density_at(upper_mu)
    lower_density <= target <= upper_density || throw(ArgumentError(
        "target density $target is not bracketed: n($lower_mu)=$lower_density, " *
        "n($upper_mu)=$upper_density",
    ))
    midpoint = (lower_mu + upper_mu) / 2
    density = density_at(midpoint)
    iterations = 0
    converged = abs(density - target) <= density_tol
    while !converged && iterations < max_iterations
        iterations += 1
        if density < target
            lower_mu = midpoint
            lower_density = density
        else
            upper_mu = midpoint
            upper_density = density
        end
        midpoint = lower_mu + (upper_mu - lower_mu) / 2
        density = density_at(midpoint)
        converged = abs(density - target) <= density_tol
        if upper_mu - lower_mu <= chemical_tol * max(1.0, abs(midpoint))
            break
        end
    end
    return (
        mu=midpoint,
        density=density,
        target_density=target,
        residual=density - target,
        converged=converged,
        iterations=iterations,
        bracket=(mu=(lower_mu, upper_mu), density=(lower_density, upper_density)),
    )
end

"""
    solve_two_orbital_cluster(U, mu, beta, tau;
        parameters=ValidatedKinetic.ModelParameters(), include_full_spectrum=false,
        h_alm=0)

Exact grand-canonical thermal solution of the existing model on a 2x2 periodic
cluster. The L=2 cancellation of interorbital hopping factorizes the Hamiltonian
into two four-site problems (256 states each, number-sector blocks <=36).

`green` and `spectral_peaks` have axes `(spin, orbital, kx_index, ky_index[,tau])`.
Each spin/orbital spectral channel integrates to one. `spin_trace_green` sums
both diagonal orbitals and has spectral normalization two per spin. The Green
function uses `<c(tau)c†(0)>`, with no leading minus; omega is relative to the
same centered-interaction chemical potential used by DQMC. Density and double
occupancy are per physical cell, summed over its two orbitals.

At zero field no magnetic domain is selected. Momentum labels on the spectra
describe an electron addition/removal operator; the many-body levels carry
exact total translation momentum as well as N_up, N_down, and S_z. The optional
complete grand spectrum is 65,536 pairwise energy sums, never a
65,536-square matrix.

`h_alm` adds the explicit source `-h_alm*O_alm`, where
`O_alm=(1/2)sum_i[(n_x_up-n_x_down)-(n_y_up-n_y_down)]`. It is zero by default.
A nonzero value explicitly selects a domain; it is not spontaneous symmetry
breaking on the finite cluster.
"""
function solve_two_orbital_cluster(
    U::Real, mu::Real, beta::Real, tau;
    parameters=ValidatedKinetic.ModelParameters(), include_full_spectrum::Bool=false,
    h_alm::Real=0.0,
)
    U, mu, beta, h_alm = Float64(U), Float64(mu), Float64(beta), Float64(h_alm)
    isfinite(U) && U >= 0 || throw(ArgumentError("U must be finite and nonnegative"))
    isfinite(mu) || throw(ArgumentError("mu must be finite"))
    isfinite(beta) && beta > 0 || throw(ArgumentError("beta must be finite and positive"))
    isfinite(h_alm) || throw(ArgumentError("h_alm must be finite"))
    tau_values = Float64.(collect(tau))
    !isempty(tau_values) && all(time -> isfinite(time) && 0 <= time <= beta, tau_values) ||
        throw(ArgumentError("tau must be nonempty and lie in [0,beta]"))
    hopping = (t1=Float64(parameters.t1), t2=Float64(parameters.t2),
               t3=Float64(parameters.t3), t4=Float64(parameters.t4))
    all(isfinite, values(hopping)) || throw(ArgumentError("hoppings must be finite"))
    model = ValidatedKinetic.ModelParameters(; hopping...)
    kinetic = ValidatedKinetic.realspace_kinetic_matrix(2, model)
    iszero(kinetic[1:2:8, 2:2:8]) || error("L=2 orbital factorization failed")
    orbitals = ntuple(orbital -> _solve_orbital(
        kinetic[orbital:2:8, orbital:2:8], U, mu, beta, tau_values,
        orbital == 1 ? h_alm : -h_alm,
    ), 2)
    green = zeros(Float64, 2, 2, 2, 2, length(tau_values))
    peaks = Array{eltype(orbitals[1].peaks)}(undef, 2, 2, 2, 2)
    for orbital in 1:2
        green[:, orbital, :, :, :] .= orbitals[orbital].green
        peaks[:, orbital, :, :] .= orbitals[orbital].peaks
    end
    spin_trace = dropdims(sum(green; dims=2); dims=2)
    full_many_body_levels = include_full_spectrum ?
        _combine_orbital_levels(map(orbital -> orbital.levels, orbitals)) : nothing
    full_spectrum = isnothing(full_many_body_levels) ? nothing :
        [level.energy for level in full_many_body_levels]
    moments = map(channel -> sum(channel.weights), peaks)
    orbital_magnetizations = ntuple(
        orbital -> orbitals[orbital].spin_polarization / 4,
        2,
    )
    return (
        L=2, U=U, mu=mu, beta=beta, h_alm=h_alm,
        hopping=hopping, tau=tau_values,
        momenta=[0.0, Float64(pi)], kinetic=kinetic,
        density=sum(orbital.particle_number for orbital in orbitals) / 4,
        double_occupancy=sum(orbital.double_occupancy for orbital in orbitals) / 4,
        orbital_magnetizations=orbital_magnetizations,
        delta_alm=(orbital_magnetizations[1] - orbital_magnetizations[2]) / 2,
        o_alm_per_cell=(orbital_magnetizations[1] - orbital_magnetizations[2]) / 2,
        o_alm=2 * (orbital_magnetizations[1] - orbital_magnetizations[2]),
        total_spin_z_per_cell=(orbital_magnetizations[1] + orbital_magnetizations[2]) / 2,
        grand_energy_per_cell=sum(orbital.grand_energy for orbital in orbitals) / 4,
        log_partition=sum(orbital.log_partition for orbital in orbitals),
        green=green, spin_trace_green=spin_trace, spectral_peaks=peaks,
        orbital_levels=map(orbital -> orbital.levels, orbitals),
        full_many_body_levels=full_many_body_levels,
        full_grand_spectrum=full_spectrum,
        spin_green_max_difference=maximum(abs, green[1, :, :, :, :] - green[2, :, :, :, :]),
        spectral_moment_max_error=maximum(abs, moments .- 1),
        hilbert_dimension=65_536,
        largest_full_number_sector_dimension=4_900,
        largest_full_momentum_sector_dimension=1_252,
        largest_factorized_orbital_number_block=36,
        largest_factorized_orbital_momentum_block=12,
        # Backward-compatible aliases; these refer to the blocks that the
        # factorized implementation constructs, not full eight-orbital blocks.
        largest_number_sector_block=36,
        largest_diagonalized_block=12,
        limitation=CLUSTER_LIMITATION,
    )
end

function _fixed_particle_product_states(orbital_levels, particle_number::Int)
    states = Any[]
    for first_level in orbital_levels[1], second_level in orbital_levels[2]
        first_level.N + second_level.N == particle_number || continue
        kx_index = mod(first_level.kx_index + second_level.kx_index - 2, 2) + 1
        ky_index = mod(first_level.ky_index + second_level.ky_index - 2, 2) + 1
        push!(states, (
            energy=first_level.energy + second_level.energy,
            Nup=first_level.Nup + second_level.Nup,
            Ndown=first_level.Ndown + second_level.Ndown,
            N=particle_number,
            Sz=first_level.Sz + second_level.Sz,
            kx_index=kx_index,
            ky_index=ky_index,
            kx=(kx_index - 1) * pi,
            ky=(ky_index - 1) * pi,
            orbital1=first_level,
            orbital2=second_level,
        ))
    end
    return sort!(states; by=state -> (
        state.energy, state.Nup, state.Ndown, state.kx_index, state.ky_index,
    ))
end

function _public_ground_level(state)
    first_level, second_level = state.orbital1, state.orbital2
    o_alm = ((first_level.Nup - first_level.Ndown) -
             (second_level.Nup - second_level.Ndown)) / 2
    return (
        energy=state.energy,
        Nup=state.Nup,
        Ndown=state.Ndown,
        N=state.N,
        Sz=state.Sz,
        kx_index=state.kx_index,
        ky_index=state.ky_index,
        kx=state.kx,
        ky=state.ky,
        o_alm=o_alm,
        orbital1_Nup=first_level.Nup,
        orbital1_Ndown=first_level.Ndown,
        orbital1_Sz=first_level.Sz,
        orbital1_kx_index=first_level.kx_index,
        orbital1_ky_index=first_level.ky_index,
        orbital2_Nup=second_level.Nup,
        orbital2_Ndown=second_level.Ndown,
        orbital2_Sz=second_level.Sz,
        orbital2_kx_index=second_level.kx_index,
        orbital2_ky_index=second_level.ky_index,
    )
end

function _particle_sector_ground_energies(orbital_levels, tolerance)
    energies = [Float64[] for _ in 0:16]
    for first_level in orbital_levels[1], second_level in orbital_levels[2]
        push!(energies[first_level.N + second_level.N + 1],
              first_level.energy + second_level.energy)
    end
    return [begin
        ground_energy = minimum(sector)
        (
            N=N,
            energy=ground_energy,
            degeneracy=count(energy -> abs(energy - ground_energy) <= tolerance, sector),
            dimension=length(sector),
        )
    end for (N, sector) in zip(0:16, energies)]
end

function _fixed_N_sector_ground_energies(states, tolerance)
    groups = Dict{NTuple{4,Int},Vector{Float64}}()
    for state in states
        key = (state.Nup, state.Ndown, state.kx_index, state.ky_index)
        push!(get!(groups, key, Float64[]), state.energy)
    end
    rows = [begin
        ground_energy = minimum(energies)
        (
            N=first(key) + key[2],
            Nup=key[1],
            Ndown=key[2],
            Sz=(key[1] - key[2]) / 2,
            kx_index=key[3],
            ky_index=key[4],
            kx=(key[3] - 1) * pi,
            ky=(key[4] - 1) * pi,
            energy=ground_energy,
            degeneracy=count(energy -> abs(energy - ground_energy) <= tolerance,
                             energies),
            dimension=length(energies),
        )
    end for (key, energies) in groups]
    return sort!(rows; by=row -> (row.Nup, row.Ndown, row.kx_index, row.ky_index))
end

function _ground_state_spectral_peaks(
    sectors, ground_states, mu_reference,
)
    peak_type = NamedTuple{
        (:frequencies, :weights),
        Tuple{Vector{Float64},Vector{Float64}},
    }
    peaks = Array{peak_type}(undef, 2, 2, 2, 2)
    addition_peaks = similar(peaks)
    removal_peaks = similar(peaks)
    inverse_degeneracy = 1 / length(ground_states)

    for spin in 1:2, orbital in 1:2, ny in 0:1, nx in 0:1
        addition_frequencies, addition_weights = Float64[], Float64[]
        removal_frequencies, removal_weights = Float64[], Float64[]
        amplitude_cache = Dict{Tuple{Int,Int,Int,Int},Matrix{Float64}}()
        for ground_state in ground_states
            active = orbital == 1 ? ground_state.orbital1 : ground_state.orbital2
            spectator = orbital == 1 ? ground_state.orbital2 : ground_state.orbital1
            active_key = (active.Nup, active.Ndown)

            spin_occupation = spin == 1 ? active.Nup : active.Ndown
            if spin_occupation > 0
                lower_key = spin == 1 ?
                    (active.Nup - 1, active.Ndown) :
                    (active.Nup, active.Ndown - 1)
                cache_key = (lower_key[1], lower_key[2], active_key[1], active_key[2])
                amplitudes = get!(amplitude_cache, cache_key) do
                    lower, upper = sectors[orbital][lower_key], sectors[orbital][active_key]
                    operator = _momentum_annihilation(lower, upper, spin, nx, ny)
                    transpose(lower.vectors) * operator * upper.vectors
                end
                lower = sectors[orbital][lower_key]
                for final_index in eachindex(lower.energies)
                    amplitude_squared = abs2(amplitudes[final_index, active.eigen_index])
                    amplitude_squared > 1.0e-24 || continue
                    final_energy = lower.energies[final_index] + spectator.energy
                    push!(removal_frequencies,
                          ground_state.energy - final_energy - mu_reference)
                    push!(removal_weights, inverse_degeneracy * amplitude_squared)
                end
            end

            if spin_occupation < 4
                upper_key = spin == 1 ?
                    (active.Nup + 1, active.Ndown) :
                    (active.Nup, active.Ndown + 1)
                cache_key = (active_key[1], active_key[2], upper_key[1], upper_key[2])
                amplitudes = get!(amplitude_cache, cache_key) do
                    lower, upper = sectors[orbital][active_key], sectors[orbital][upper_key]
                    operator = _momentum_annihilation(lower, upper, spin, nx, ny)
                    transpose(lower.vectors) * operator * upper.vectors
                end
                upper = sectors[orbital][upper_key]
                for final_index in eachindex(upper.energies)
                    amplitude_squared = abs2(amplitudes[active.eigen_index, final_index])
                    amplitude_squared > 1.0e-24 || continue
                    final_energy = upper.energies[final_index] + spectator.energy
                    push!(addition_frequencies,
                          final_energy - ground_state.energy - mu_reference)
                    push!(addition_weights, inverse_degeneracy * amplitude_squared)
                end
            end
        end

        addition = _merge_spectral_peaks(addition_frequencies, addition_weights)
        removal = _merge_spectral_peaks(removal_frequencies, removal_weights)
        combined = _merge_spectral_peaks(
            vcat(removal.frequencies, addition.frequencies),
            vcat(removal.weights, addition.weights),
        )
        peaks[spin, orbital, nx + 1, ny + 1] = combined
        addition_peaks[spin, orbital, nx + 1, ny + 1] = addition
        removal_peaks[spin, orbital, nx + 1, ny + 1] = removal
    end
    return peaks, addition_peaks, removal_peaks
end

function _level_double_occupancy(level, sectors)
    sector = sectors[(level.Nup, level.Ndown)]
    probabilities = abs2.(sector.vectors[:, level.eigen_index])
    return dot(sector.doubles, probabilities)
end

"""
    solve_two_orbital_ground_state(U, N;
        parameters=ValidatedKinetic.ModelParameters(), h_alm=0,
        degeneracy_tolerance=2e-10, mu_reference=:midgap,
        include_full_spectrum=false)

Exact zero-temperature canonical solution of the periodic 2x2 two-orbital
cluster at integer particle number `N`. The density is exactly `N/4`. An
equal-weight density matrix is used over the complete fixed-`N` ground-state
manifold, including every spin and momentum partner within the explicit
absolute `degeneracy_tolerance`.

The raw addition and removal Lehmann poles have axes
`(spin, orbital, kx_index, ky_index)` and are combined in `spectral_peaks`.
Their frequencies are measured relative to numeric `mu_reference`. With the
default `:midgap`, this is
`((E0(N)-E0(N-1)) + (E0(N+1)-E0(N)))/2`. Consequently occupied removal poles
normally lie below zero and addition poles above zero. `N=0` and `N=16` are
not accepted because a two-sided midgap spectrum requires both neighboring
particle sectors.

The source convention is the same as in `solve_two_orbital_cluster`:
`-h_alm*O_alm`. A nonzero field explicitly selects a domain; it does not prove
spontaneous symmetry breaking on a finite cluster. Periodic L=2 also cancels
`t4` exactly.
"""
function solve_two_orbital_ground_state(
    U::Real, N::Integer;
    parameters=ValidatedKinetic.ModelParameters(),
    h_alm::Real=0.0,
    degeneracy_tolerance::Real=2.0e-10,
    mu_reference=:midgap,
    include_full_spectrum::Bool=false,
)
    N isa Bool && throw(ArgumentError("N must be an integer from 1 to 15"))
    1 <= N <= 15 || throw(ArgumentError("N must lie between 1 and 15"))
    interaction = Float64(U)
    field = Float64(h_alm)
    tolerance = Float64(degeneracy_tolerance)
    isfinite(interaction) && interaction >= 0 ||
        throw(ArgumentError("U must be finite and nonnegative"))
    isfinite(field) || throw(ArgumentError("h_alm must be finite"))
    isfinite(tolerance) && tolerance > 0 ||
        throw(ArgumentError("degeneracy_tolerance must be finite and positive"))

    hopping = (t1=Float64(parameters.t1), t2=Float64(parameters.t2),
               t3=Float64(parameters.t3), t4=Float64(parameters.t4))
    all(isfinite, values(hopping)) || throw(ArgumentError("hoppings must be finite"))
    model = ValidatedKinetic.ModelParameters(; hopping...)
    kinetic = ValidatedKinetic.realspace_kinetic_matrix(2, model)
    iszero(kinetic[1:2:8, 2:2:8]) || error("L=2 orbital factorization failed")
    sectors = ntuple(orbital -> _orbital_sectors(
        kinetic[orbital:2:8, orbital:2:8], interaction, 0.0,
        orbital == 1 ? field : -field,
    ), 2)
    orbital_levels = map(_orbital_levels, sectors)
    particle_sector_grounds = _particle_sector_ground_energies(
        orbital_levels, tolerance,
    )
    energy_N_minus = particle_sector_grounds[N].energy
    energy_N = particle_sector_grounds[N + 1].energy
    energy_N_plus = particle_sector_grounds[N + 2].energy
    mu_minus = energy_N - energy_N_minus
    mu_plus = energy_N_plus - energy_N
    midpoint = (mu_minus + mu_plus) / 2
    reference_scheme = mu_reference
    reference = if mu_reference === :midgap
        midpoint
    elseif mu_reference === :minus
        mu_minus
    elseif mu_reference === :plus
        mu_plus
    elseif mu_reference === :zero
        0.0
    elseif mu_reference isa Real
        Float64(mu_reference)
    else
        throw(ArgumentError(
            "mu_reference must be a finite number or :midgap, :minus, :plus, or :zero",
        ))
    end
    isfinite(reference) || throw(ArgumentError("mu_reference must be finite"))

    fixed_N_states = _fixed_particle_product_states(orbital_levels, Int(N))
    ground_energy = first(fixed_N_states).energy
    ground_states = [state for state in fixed_N_states
                     if abs(state.energy - ground_energy) <= tolerance]
    isempty(ground_states) && error("failed to construct the ground-state manifold")
    excited_energies = [state.energy for state in fixed_N_states
                        if state.energy > ground_energy + tolerance]
    same_N_gap = isempty(excited_energies) ? Inf : minimum(excited_energies) - ground_energy
    public_ground_levels = map(_public_ground_level, ground_states)
    sector_ground_energies = _fixed_N_sector_ground_energies(
        fixed_N_states, tolerance,
    )

    peaks, addition_peaks, removal_peaks = _ground_state_spectral_peaks(
        sectors, ground_states, reference,
    )
    moments = map(channel -> sum(channel.weights), peaks)
    addition_moments = map(channel -> sum(channel.weights), addition_peaks)
    removal_moments = map(channel -> sum(channel.weights), removal_peaks)

    spin_orbital_numbers = zeros(Float64, 2, 2)
    o_alm = 0.0
    o_alm_squared = 0.0
    double_occupancy = 0.0
    for state in ground_states
        first_level, second_level = state.orbital1, state.orbital2
        spin_orbital_numbers[1, 1] += first_level.Nup
        spin_orbital_numbers[2, 1] += first_level.Ndown
        spin_orbital_numbers[1, 2] += second_level.Nup
        spin_orbital_numbers[2, 2] += second_level.Ndown
        state_o_alm = ((first_level.Nup - first_level.Ndown) -
                       (second_level.Nup - second_level.Ndown)) / 2
        o_alm += state_o_alm
        o_alm_squared += state_o_alm^2
        double_occupancy += _level_double_occupancy(first_level, sectors[1]) +
                            _level_double_occupancy(second_level, sectors[2])
    end
    spin_orbital_numbers ./= length(ground_states)
    o_alm /= length(ground_states)
    o_alm_squared /= length(ground_states)
    double_occupancy /= length(ground_states)
    orbital_magnetizations = ntuple(orbital ->
        (spin_orbital_numbers[1, orbital] - spin_orbital_numbers[2, orbital]) / 4,
        2,
    )
    full_many_body_levels = include_full_spectrum ?
        _combine_orbital_levels(orbital_levels) : nothing
    full_spectrum = isnothing(full_many_body_levels) ? nothing :
        [level.energy for level in full_many_body_levels]

    return (
        L=2,
        U=interaction,
        N=Int(N),
        particle_number=Int(N),
        density=N / 4,
        h_alm=field,
        hopping=hopping,
        momenta=[0.0, Float64(pi)],
        kinetic=kinetic,
        ensemble="zero-temperature canonical fixed particle number",
        temperature=0.0,
        ground_energy=ground_energy,
        ground_energy_per_cell=ground_energy / 4,
        ground_degeneracy=length(ground_states),
        ground_levels=public_ground_levels,
        ground_states=public_ground_levels,
        same_N_gap=same_N_gap,
        mu_minus=mu_minus,
        mu_plus=mu_plus,
        charge_gap=mu_plus - mu_minus,
        midgap_mu=midpoint,
        mu_reference=reference,
        mu_reference_scheme=reference_scheme,
        degeneracy_tolerance=tolerance,
        sector_ground_energies=sector_ground_energies,
        particle_sector_ground_energies=particle_sector_grounds,
        spin_orbital_numbers=spin_orbital_numbers,
        orbital_particle_numbers=vec(sum(spin_orbital_numbers; dims=1)),
        spin_particle_numbers=vec(sum(spin_orbital_numbers; dims=2)),
        orbital_magnetizations=orbital_magnetizations,
        total_spin_z_per_cell=(orbital_magnetizations[1] +
                               orbital_magnetizations[2]) / 2,
        delta_alm=(orbital_magnetizations[1] - orbital_magnetizations[2]) / 2,
        delta_alm_per_cell=o_alm / 4,
        o_alm=o_alm,
        o_alm_per_cell=o_alm / 4,
        o_alm_squared=o_alm_squared,
        o_alm2_per_cell2=o_alm_squared / 16,
        double_occupancy=double_occupancy / 4,
        spectral_peaks=peaks,
        addition_spectral_peaks=addition_peaks,
        removal_spectral_peaks=removal_peaks,
        spectral_zeroth_moments=moments,
        addition_spectral_zeroth_moments=addition_moments,
        removal_spectral_zeroth_moments=removal_moments,
        spectral_moment_max_error=maximum(abs, moments .- 1; init=0.0),
        orbital_levels=orbital_levels,
        full_many_body_levels=full_many_body_levels,
        full_canonical_spectrum=full_spectrum,
        hilbert_dimension=65_536,
        largest_full_number_sector_dimension=4_900,
        largest_full_momentum_sector_dimension=1_252,
        largest_factorized_orbital_number_block=36,
        largest_factorized_orbital_momentum_block=12,
        largest_number_sector_block=36,
        largest_diagonalized_block=12,
        limitation=CLUSTER_LIMITATION,
    )
end

"""
    broaden_cluster_spectra(result, omega; eta=0.1)

Broaden the exact Lehmann delta peaks with normalized Lorentzians of half-width
`eta`. The returned `spectral` array has axes
`(spin, orbital, kx_index, ky_index, omega_index)`. `spin_trace` sums the two
orbitals and `dos` additionally averages over the four cluster momenta, so the
infinite-window zeroth moments are respectively two and two per spin.

Broadening is presentation-only: the exact pole frequencies and weights remain
available in `result.spectral_peaks`.
"""
function broaden_cluster_spectra(result, omega; eta::Real=0.1)
    eta_value = Float64(eta)
    isfinite(eta_value) && eta_value > 0 ||
        throw(ArgumentError("eta must be finite and positive"))
    omega_values = Float64.(collect(omega))
    !isempty(omega_values) && all(isfinite, omega_values) ||
        throw(ArgumentError("omega must be nonempty and finite"))
    all(diff(omega_values) .> 0) ||
        throw(ArgumentError("omega must be strictly increasing"))

    spectral = zeros(Float64, 2, 2, 2, 2, length(omega_values))
    for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
        channel = result.spectral_peaks[spin, orbital, kx, ky]
        for (frequency, weight) in zip(channel.frequencies, channel.weights)
            @. spectral[spin, orbital, kx, ky, :] +=
                weight * eta_value /
                (pi * ((omega_values - frequency)^2 + eta_value^2))
        end
    end
    spin_trace = dropdims(sum(spectral; dims=2); dims=2)
    dos = dropdims(sum(spin_trace; dims=(2, 3)); dims=(2, 3)) ./ 4
    return (
        omega=omega_values,
        eta=eta_value,
        spectral=spectral,
        spin_trace=spin_trace,
        dos=dos,
        total_dos=vec(sum(dos; dims=1)),
    )
end

"""
    altermagnetic_xy_diagnostics(result, omega; eta=0.1)

Broaden the exact spectrum and compare the spin-resolved orbital traces at
`X=(pi,0)` and `Y=(0,pi)`. With the explicit source `-h_alm*O_alm`, the
remaining spin-reversal-plus-C4 symmetry requires
`A_up(X)=A_down(Y)`, `A_down(X)=A_up(Y)`, and equal momentum-averaged spin DOS.
At zero field, the stronger same-momentum equality also holds.

The returned same-X contrast is a response to an imposed source on this finite
cluster. It is not a spontaneous order parameter or a critical-U detector.
"""
function altermagnetic_xy_diagnostics(result, omega; eta::Real=0.1)
    broadened = broaden_cluster_spectra(result, omega; eta=eta)
    x_up = vec(copy(broadened.spin_trace[1, 2, 1, :]))
    x_down = vec(copy(broadened.spin_trace[2, 2, 1, :]))
    y_up = vec(copy(broadened.spin_trace[1, 1, 2, :]))
    y_down = vec(copy(broadened.spin_trace[2, 1, 2, :]))
    delta_x = x_up - x_down
    delta_y = y_up - y_down
    rotated_partner_error = max(
        maximum(abs, x_up - y_down; init=0.0),
        maximum(abs, x_down - y_up; init=0.0),
    )
    return (
        omega=broadened.omega,
        eta=broadened.eta,
        x_up=x_up,
        x_down=x_down,
        y_up=y_up,
        y_down=y_down,
        delta_x=delta_x,
        delta_y=delta_y,
        dos_up=vec(copy(broadened.dos[1, :])),
        dos_down=vec(copy(broadened.dos[2, :])),
        xy_rotated_partner_max_error=rotated_partner_error,
        xy_contrast_antisymmetry_max_error=maximum(abs, delta_x + delta_y; init=0.0),
        dos_spin_max_error=maximum(
            abs, broadened.dos[1, :] - broadened.dos[2, :]; init=0.0,
        ),
        x_same_momentum_spin_contrast_max=maximum(abs, delta_x; init=0.0),
        y_same_momentum_spin_contrast_max=maximum(abs, delta_y; init=0.0),
        broadened=broadened,
    )
end

"""
    many_body_spin_pairing_error(result)

Compare the complete zero-field many-body spectra in every
`(N_up,N_down,kx,ky)` sector against `(N_down,N_up,kx,ky)`. The result must
have been created with `include_full_spectrum=true`. This checks the precise
energy pairing requested for `+S_z` and `-S_z` without confusing many-body
levels with poles of `A(k,omega)`.
"""
function many_body_spin_pairing_error(result)
    iszero(result.h_alm) || throw(ArgumentError(
        "many_body_spin_pairing_error is a zero-field audit; h_alm must equal zero",
    ))
    isnothing(result.full_many_body_levels) && throw(ArgumentError(
        "solve with include_full_spectrum=true to audit all many-body levels",
    ))
    groups = Dict{NTuple{4,Int},Vector{Float64}}()
    for level in result.full_many_body_levels
        key = (level.Nup, level.Ndown, level.kx_index, level.ky_index)
        push!(get!(groups, key, Float64[]), level.energy)
    end
    maximum_error = 0.0
    maximum_length_mismatch = 0
    for ((nup, ndown, kx, ky), energies) in groups
        partner = groups[(ndown, nup, kx, ky)]
        maximum_length_mismatch = max(
            maximum_length_mismatch,
            abs(length(energies) - length(partner)),
        )
        if length(energies) == length(partner)
            left, right = sort(energies), sort(partner)
            maximum_error = max(
                maximum_error,
                maximum(abs, left - right; init=0.0),
            )
        else
            maximum_error = Inf
        end
    end
    return (
        energy=maximum_error,
        length_mismatch=maximum_length_mismatch,
        maximum=maximum_error,
        sectors_checked=length(groups),
    )
end

"""
    spin_pairing_error(result)

Compare every exact spin-up Lehmann channel with its spin-down partner. A
zero-field spin-independent finite Hamiltonian must give identical pole lists.
The returned errors separately cover pole frequencies, weights, imaginary-time
Green functions, and spectral-list lengths. A nonzero `h_alm` is rejected
because the source intentionally removes same-momentum spin pairing.
"""
function spin_pairing_error(result)
    iszero(result.h_alm) || throw(ArgumentError(
        "spin_pairing_error is a zero-field audit; h_alm must equal zero",
    ))
    frequency_error = 0.0
    weight_error = 0.0
    length_mismatch = 0
    for orbital in 1:2, ky in 1:2, kx in 1:2
        up = result.spectral_peaks[1, orbital, kx, ky]
        down = result.spectral_peaks[2, orbital, kx, ky]
        length_mismatch = max(
            length_mismatch,
            abs(length(up.frequencies) - length(down.frequencies)),
            abs(length(up.weights) - length(down.weights)),
        )
        if length(up.frequencies) == length(down.frequencies)
            frequency_error = max(
                frequency_error,
                maximum(abs, up.frequencies .- down.frequencies; init=0.0),
            )
        else
            frequency_error = Inf
        end
        if length(up.weights) == length(down.weights)
            weight_error = max(
                weight_error,
                maximum(abs, up.weights .- down.weights; init=0.0),
            )
        else
            weight_error = Inf
        end
    end
    green_error = maximum(
        abs,
        result.green[1, :, :, :, :] .- result.green[2, :, :, :, :];
        init=0.0,
    )
    return (
        frequency=frequency_error,
        weight=weight_error,
        green=green_error,
        length_mismatch=length_mismatch,
        maximum=max(frequency_error, weight_error, green_error),
    )
end

"""
    ground_state_spin_pairing_error(result)

Audit the raw zero-temperature canonical result under spin reversal. At zero
source field, fixed-`N` sector ground energies and every spin-up/down Lehmann
pole and weight must pair. This routine intentionally rejects `h_alm != 0`,
where same-momentum spin pairing has been explicitly removed by the source.
"""
function ground_state_spin_pairing_error(result)
    iszero(result.h_alm) || throw(ArgumentError(
        "ground_state_spin_pairing_error is a zero-field audit; h_alm must equal zero",
    ))
    hasproperty(result, :ground_energy) && hasproperty(result, :sector_ground_energies) ||
        throw(ArgumentError("result is not a canonical ground-state ED result"))

    sector_energies = Dict(
        (row.Nup, row.Ndown, row.kx_index, row.ky_index) => row.energy
        for row in result.sector_ground_energies
    )
    sector_energy_error = 0.0
    for ((nup, ndown, kx, ky), energy) in sector_energies
        partner = get(sector_energies, (ndown, nup, kx, ky), Inf)
        sector_energy_error = max(sector_energy_error, abs(energy - partner))
    end

    frequency_error = 0.0
    weight_error = 0.0
    length_mismatch = 0
    channels_checked = 0
    for orbital in 1:2, ky in 1:2, kx in 1:2
        channels_checked += 1
        up = result.spectral_peaks[1, orbital, kx, ky]
        down = result.spectral_peaks[2, orbital, kx, ky]
        length_mismatch = max(
            length_mismatch,
            abs(length(up.frequencies) - length(down.frequencies)),
            abs(length(up.weights) - length(down.weights)),
        )
        if length(up.frequencies) == length(down.frequencies)
            frequency_error = max(
                frequency_error,
                maximum(abs, up.frequencies .- down.frequencies; init=0.0),
            )
        else
            frequency_error = Inf
        end
        if length(up.weights) == length(down.weights)
            weight_error = max(
                weight_error,
                maximum(abs, up.weights .- down.weights; init=0.0),
            )
        else
            weight_error = Inf
        end
    end
    return (
        energy=sector_energy_error,
        sector_energy=sector_energy_error,
        frequency=frequency_error,
        weight=weight_error,
        length_mismatch=length_mismatch,
        sectors_checked=length(sector_energies),
        channels_checked=channels_checked,
        maximum=max(sector_energy_error, frequency_error, weight_error),
    )
end

"""
    scan_spin_degeneracy(U_values, mu, beta; tau=nothing,
                         parameters=ValidatedKinetic.ModelParameters(),
                         tolerance=2e-10, omega=nothing, eta=0.1)

Run the exact periodic 2x2 thermal solver at every requested interaction and
audit spin-up/down equality. `mu` is the code chemical potential in the
particle-hole-centered interaction convention and is held fixed; this is not a
fixed-density scan. If `omega` is supplied, the maximum difference of the two
Lorentzian-broadened spin DOS curves is checked as well.

This finite zero-field calculation is a symmetry audit, not a spontaneous-order
detector. Spin reversal requires the exact thermal spectra to remain paired for
every `U`; a reported break therefore identifies numerical inconsistency. In
addition, periodic L=2 cancels `t4` and cannot determine the bulk altermagnetic
onset.
"""
function scan_spin_degeneracy(
    U_values, mu::Real, beta::Real;
    tau=nothing,
    parameters=ValidatedKinetic.ModelParameters(),
    tolerance::Real=2.0e-10,
    omega=nothing,
    eta::Real=0.1,
)
    interactions = Float64.(collect(U_values))
    !isempty(interactions) && all(value -> isfinite(value) && value >= 0, interactions) ||
        throw(ArgumentError("U_values must be nonempty, finite, and nonnegative"))
    tolerance_value = Float64(tolerance)
    isfinite(tolerance_value) && tolerance_value >= 0 ||
        throw(ArgumentError("tolerance must be finite and nonnegative"))
    beta_value = Float64(beta)
    times = isnothing(tau) ? [0.0, beta_value / 2, beta_value] : Float64.(collect(tau))
    omega_values = isnothing(omega) ? nothing : Float64.(collect(omega))

    rows = NamedTuple[]
    for interaction in interactions
        exact = solve_two_orbital_cluster(
            interaction, mu, beta_value, times; parameters=parameters,
        )
        pairing = spin_pairing_error(exact)
        broadened_error = if isnothing(omega_values)
            0.0
        else
            broadened = broaden_cluster_spectra(exact, omega_values; eta=eta)
            maximum(abs, broadened.dos[1, :] .- broadened.dos[2, :]; init=0.0)
        end
        maximum_error = max(pairing.maximum, broadened_error)
        push!(rows, (
            U=interaction,
            mu=Float64(mu),
            beta=beta_value,
            density=exact.density,
            double_occupancy=exact.double_occupancy,
            grand_energy_per_cell=exact.grand_energy_per_cell,
            spin_green_max_difference=pairing.green,
            spin_pole_frequency_max_difference=pairing.frequency,
            spin_pole_weight_max_difference=pairing.weight,
            spin_pole_length_mismatch=pairing.length_mismatch,
            broadened_spin_dos_max_difference=broadened_error,
            maximum_spin_pairing_error=maximum_error,
            spin_pairing_audit_failed=maximum_error > tolerance_value,
        ))
    end
    first_failure_index = findfirst(row -> row.spin_pairing_audit_failed, rows)
    return (
        rows=rows,
        tolerance=tolerance_value,
        first_audit_failure_U=isnothing(first_failure_index) ? nothing :
                              rows[first_failure_index].U,
        any_audit_failure=!isnothing(first_failure_index),
        ensemble="fixed code chemical potential (not fixed density)",
        conclusion="No unbiased finite-cluster spontaneous symmetry breaking can be inferred; " *
                   "periodic L=2 also cancels t4.",
    )
end

function _paired_ratio(numerators, signs, counts; minimum_average_sign=0.05)
    nbin = length(signs)
    nbin >= 2 && length(numerators) == nbin && length(counts) == nbin ||
        throw(ArgumentError("paired statistics require at least two equal-length bin arrays"))
    isfinite(minimum_average_sign) && 0 < minimum_average_sign < 1 ||
        throw(ArgumentError("minimum_average_sign must lie strictly between zero and one"))
    all(isfinite, numerators) && all(isfinite, signs) ||
        throw(ArgumentError("nonfinite bin data"))
    all(count -> count isa Integer && !(count isa Bool) && count > 0, counts) ||
        throw(ArgumentError("bin counts must be positive integers"))
    all(abs(signs[bin]) <= counts[bin] + 256eps(Float64) * counts[bin] for bin in 1:nbin) ||
        throw(ArgumentError("a sign sum exceeds its measurement count"))
    total_sign, total_count = sum(signs), sum(counts)
    abs(total_sign) / total_count >= minimum_average_sign ||
        throw(ArgumentError("full Green average sign is below $minimum_average_sign"))
    total = sum(numerators)
    leave_one_out = Float64[]
    for bin in 1:nbin
        denominator = total_sign - signs[bin]
        abs(denominator) / (total_count - counts[bin]) >= minimum_average_sign ||
            throw(ArgumentError("a leave-one-bin-out average sign is too small"))
        push!(leave_one_out, real((total - numerators[bin]) / denominator))
    end
    center = sum(leave_one_out) / nbin
    error = sqrt((nbin - 1) / nbin * sum(abs2(value - center) for value in leave_one_out))
    return (value=real(total / total_sign), standard_error=error,
            imaginary=imag(total / total_sign), average_sign=total_sign / total_count)
end

"""Return spin-trace G comparisons using paired sign-ratio jackknife errors.

This reports discrepancies, not a benchmark pass: finite-dtau bias, sampling,
and correlated comparisons require a separate convergence assessment.
"""
function compare_cluster_payload(payload, exact)
    iszero(exact.h_alm) || error("DQMC comparison requires h_alm=0")
    payload["kind"] == "two_orbital_dqmc_observables" || error("unsupported payload kind")
    payload["schema_version"] == 1 || error("unsupported payload schema")
    Tuple(payload["green_axes"]) ==
        (:bin, :spin, :destination_orbital, :source_orbital, :kx_index, :ky_index, :tau_index) ||
        error("unsupported Green axes")
    occursin("no leading minus", payload["green_convention"]) || error("unsupported Green convention")
    metadata = payload["metadata"]
    metadata["L"] == 2 || error("cluster ED comparison requires L=2")
    for (key, value) in (("U", exact.U), ("mu_measured", exact.mu), ("beta", exact.beta),
                         ("t1", exact.hopping.t1), ("t2", exact.hopping.t2),
                         ("t3", exact.hopping.t3), ("t4", exact.hopping.t4))
        metadata[key] == value || error("ED and DQMC $key do not match")
    end
    Float64.(payload["tau"]) == exact.tau || error("ED and DQMC tau grids differ")
    isapprox(Float64.(payload["momenta"]), exact.momenta; atol=1.0e-12, rtol=0) ||
        error("unsupported momentum grid")
    greens = payload["green_signed_momentum_bins"]
    greens === nothing && error("input has no unequal-time measurements")
    signs, counts = payload["green_sign_sums"], payload["green_counts"]
    size(greens) == (length(signs), 2, 2, 2, 2, 2, length(exact.tau)) ||
        error("unexpected Green bin shape")
    rows = NamedTuple[]
    for spin in 1:2, ky in 1:2, kx in 1:2, time in eachindex(exact.tau)
        bins = greens[:, spin, 1, 1, kx, ky, time] + greens[:, spin, 2, 2, kx, ky, time]
        measured = _paired_ratio(bins, signs, counts)
        exact_value = exact.spin_trace_green[spin, kx, ky, time]
        difference = measured.value - exact_value
        push!(rows, (
            spin=spin, kx_index=kx, ky_index=ky, tau=exact.tau[time],
            dqmc=measured.value, standard_error=measured.standard_error,
            ed=exact_value, difference=difference,
            difference_over_error=measured.standard_error > 0 ? difference / measured.standard_error : NaN,
            imaginary=measured.imaginary, average_sign=measured.average_sign,
        ))
    end
    return rows
end

function save_cluster_result(directory, result; comparison=nothing, input_path=nothing)
    destination = abspath(directory)
    ispath(destination) && throw(ArgumentError("refusing to overwrite output directory: $destination"))
    mkpath(destination)
    open(joinpath(destination, "exact_cluster.jls"), "w") do io
        serialize(io, Dict("schema_version" => 1, "kind" => "two_orbital_L2_cluster_ed", "result" => result))
    end
    open(joinpath(destination, "thermodynamics.csv"), "w") do io
        println(io, "U,mu,beta,h_alm,density_per_cell,double_occupancy_per_cell,grand_energy_per_cell,log_partition,m_x,m_y,O_alm_per_cell,total_Sz_per_cell")
        println(io, join((result.U, result.mu, result.beta, result.h_alm,
                         result.density, result.double_occupancy,
                         result.grand_energy_per_cell, result.log_partition,
                         result.orbital_magnetizations[1],
                         result.orbital_magnetizations[2],
                         result.o_alm_per_cell,
                         result.total_spin_z_per_cell), ','))
    end
    open(joinpath(destination, "green_spin_trace.csv"), "w") do io
        println(io, "spin,kx_index,ky_index,kx,ky,tau,G_spin_orbital_trace")
        for spin in 1:2, ky in 1:2, kx in 1:2, time in eachindex(result.tau)
            println(io, join((spin == 1 ? "up" : "down", kx, ky,
                result.momenta[kx], result.momenta[ky], result.tau[time],
                result.spin_trace_green[spin, kx, ky, time]), ','))
        end
    end
    open(joinpath(destination, "spectral_poles.csv"), "w") do io
        println(io, "spin,orbital,kx_index,ky_index,kx,ky,omega,weight")
        for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
            channel = result.spectral_peaks[spin, orbital, kx, ky]
            for (frequency, weight) in zip(channel.frequencies, channel.weights)
                println(io, join((spin == 1 ? "up" : "down", orbital, kx, ky,
                    result.momenta[kx], result.momenta[ky], frequency, weight), ','))
            end
        end
    end
    open(joinpath(destination, "orbital_many_body_levels.csv"), "w") do io
        println(io, "orbital,N_up,N_down,N,Sz,kx_index,ky_index,kx,ky,grand_energy")
        for orbital in 1:2, level in result.orbital_levels[orbital]
            println(io, join((orbital, level.Nup, level.Ndown, level.N, level.Sz,
                level.kx_index, level.ky_index, level.kx, level.ky, level.energy), ','))
        end
    end
    if result.full_many_body_levels !== nothing
        open(joinpath(destination, "full_many_body_levels.csv"), "w") do io
            println(io, "index,N_up,N_down,N,Sz,kx_index,ky_index,kx,ky,grand_energy")
            for (index, level) in enumerate(result.full_many_body_levels)
                println(io, join((index, level.Nup, level.Ndown, level.N, level.Sz,
                    level.kx_index, level.ky_index, level.kx, level.ky,
                    level.energy), ','))
            end
        end
    end
    if comparison !== nothing
        open(joinpath(destination, "dqmc_green_comparison.csv"), "w") do io
            println(io, join(keys(first(comparison)), ','))
            for row in comparison
                println(io, join(values(row), ','))
            end
        end
    end
    open(joinpath(destination, "metadata.txt"), "w") do io
        println(io, result.limitation)
        println(io, "L=2; periodic boundary conditions; orbital basis=(d_xz,d_yz)")
        println(io, "H=K+U sum[(n_up-1/2)(n_down-1/2)]-mu N-h_alm O_alm")
        println(io, "U=$(result.U); mu=$(result.mu); beta=$(result.beta); h_alm=$(result.h_alm); hoppings=$(result.hopping)")
        println(io, "G=<c(tau)c^dagger(0)>; no leading minus sign; omega relative to mu")
        println(io, "G spin trace sums two orbitals: zeroth moment=2 per spin; each orbital channel=1")
        println(io, "c_k=(1/sqrt(4)) sum_r exp(-ik.r)c_r; k components=0,pi")
        println(io, "Hilbert dimension=65536; N=0..16; Sz=-4..4")
        println(io, "Formal full fixed-(Nup,Ndown) maximum=4900; full momentum-sector maximum=1252")
        println(io, "Factorized orbital number block maximum=36; actual diagonalized momentum block maximum=12")
        println(io, "Many-body levels have N_up,N_down,Sz and exact translation momentum labels; total S is not assigned")
        println(io, "Explicit altermagnetic source h_alm=$(result.h_alm); h_alm=0 selects no magnetic domain")
        println(io, "orbital magnetizations per cell=$(result.orbital_magnetizations); Delta_alm=$(result.delta_alm)")
        println(io, "spin Green maximum difference=$(result.spin_green_max_difference)")
        println(io, "spectral zeroth moment maximum error=$(result.spectral_moment_max_error)")
        println(io, "DQMC comparison input=$(input_path === nothing ? "none" : abspath(input_path))")
        println(io, "No DQMC benchmark pass is asserted; finite-dtau and sampling checks remain separate")
    end
    return destination
end

function main(args=ARGS)
    if "--help" in args
        println("""
Usage: julia --project=. scripts/two_orbital_cluster_ed.jl [options]
  --U=2 --mu=0 --beta=1 --dtau=0.1   One small exact point, no simulation or sweep
  --h-alm=0                           Explicit source coupled as -h*O_alm
  --t1=-1 --t2=-1.75 --t3=-0.85 --t4=-0.65
  --input=DATA.jls                    Read L=2 DQMC parameters/tau and compare G
  --output-dir=results/cluster_ed_U2   Required; must not already exist
  --full-spectrum                    Store all 65536 labeled levels in JLS and CSV
--input cannot be combined with physical/grid overrides. Spin traces sum both
orbitals, with spectral weight two per spin. $(CLUSTER_LIMITATION)
""")
        return nothing
    end
    options = Dict{String,String}()
    include_full_spectrum = false
    for arg in args
        if arg == "--full-spectrum"
            include_full_spectrum = true
            continue
        end
        startswith(arg, "--") && occursin('=', arg) || error("use --name=value options; see --help")
        key, value = split(arg[3:end], '='; limit=2)
        key in ("U", "mu", "beta", "dtau", "h-alm", "t1", "t2", "t3", "t4", "input", "output-dir") ||
            error("unknown option --$key")
        haskey(options, key) && error("duplicate option --$key")
        options[key] = value
    end
    haskey(options, "output-dir") || error("--output-dir is required; see --help")
    ispath(options["output-dir"]) && error("output directory already exists")
    input_path = get(options, "input", nothing)
    payload = nothing
    if input_path !== nothing
        any(key -> haskey(options, key), ("U", "mu", "beta", "dtau", "h-alm", "t1", "t2", "t3", "t4")) &&
            error("--input reads its physical parameters and tau; do not also override them")
        payload = open(deserialize, input_path)
        metadata = payload["metadata"]
        metadata["L"] == 2 || error("--input requires L=2")
        U, mu, beta = metadata["U"], metadata["mu_measured"], metadata["beta"]
        hopping = ValidatedKinetic.ModelParameters(
            metadata["t1"], metadata["t2"], metadata["t3"], metadata["t4"],
        )
        tau = payload["tau"]
        h_alm = 0.0
    else
        U = parse(Float64, get(options, "U", "2"))
        mu = parse(Float64, get(options, "mu", "0"))
        beta = parse(Float64, get(options, "beta", "1"))
        dtau = parse(Float64, get(options, "dtau", "0.1"))
        isfinite(beta) && beta > 0 && isfinite(dtau) && dtau > 0 || error("beta/dtau must be positive and finite")
        slices = round(Int, beta / dtau)
        slices >= 1 && isapprox(slices * dtau, beta; atol=1.0e-12, rtol=1.0e-12) ||
            error("beta/dtau must be integral")
        tau = collect(range(0.0, beta; length=slices + 1))
        hopping = ValidatedKinetic.ModelParameters(
            parse(Float64, get(options, "t1", "-1")), parse(Float64, get(options, "t2", "-1.75")),
            parse(Float64, get(options, "t3", "-0.85")), parse(Float64, get(options, "t4", "-0.65")),
        )
        h_alm = parse(Float64, get(options, "h-alm", "0"))
    end
    result = solve_two_orbital_cluster(U, mu, beta, tau;
        parameters=hopping, include_full_spectrum=include_full_spectrum, h_alm=h_alm)
    comparison = payload === nothing ? nothing : compare_cluster_payload(payload, result)
    destination = save_cluster_result(options["output-dir"], result; comparison=comparison, input_path=input_path)
    println(CLUSTER_LIMITATION)
    println("density=$(result.density); double occupancy=$(result.double_occupancy)")
    println("O_alm/cell=$(result.o_alm_per_cell); total Sz/cell=$(result.total_spin_z_per_cell)")
    println("spin G difference=$(result.spin_green_max_difference); spectral moment error=$(result.spectral_moment_max_error)")
    println("Saved exact ED outputs to $destination")
    return result
end

end # module

if abspath(PROGRAM_FILE) == @__FILE__
    TwoOrbitalClusterED.main()
end
