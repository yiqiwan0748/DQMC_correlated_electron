#!/usr/bin/env julia

# This file deliberately layers additional zero-temperature observables on the
# validated periodic-L=2 solver.  It does not alter the production solver or
# its serialized result format.
if !isdefined(@__MODULE__, :TwoOrbitalClusterED)
    include(joinpath(@__DIR__, "two_orbital_cluster_ed.jl"))
end

module TwoOrbitalGroundObservables

using LinearAlgebra
using SparseArrays
using ..TwoOrbitalClusterED

const ED = TwoOrbitalClusterED
const DEFAULT_TOLERANCE = 2.0e-10
const NCELLS = 4

export classify_ground_symmetries,
       c4_fock_action,
       ground_state_dynamical_correlation,
       ground_state_correlation_suite,
       evaluate_lehmann_green,
       retarded_green,
       matsubara_green,
       noninteracting_cluster_self_energy,
       bare_cluster_energies

function _validate_inputs(U, N, tolerance)
    interaction = Float64(U)
    N isa Bool && throw(ArgumentError("N must be an integer from 1 to 15"))
    N isa Integer || throw(ArgumentError("N must be an integer from 1 to 15"))
    particle_number = Int(N)
    1 <= particle_number <= 15 ||
        throw(ArgumentError("N must lie between 1 and 15"))
    tol = Float64(tolerance)
    isfinite(interaction) && interaction >= 0 ||
        throw(ArgumentError("U must be finite and nonnegative"))
    isfinite(tol) && tol > 0 ||
        throw(ArgumentError("tolerance must be finite and positive"))
    return interaction, particle_number, tol
end

function _prepare(U, N; parameters=ED.ValidatedKinetic.ModelParameters(),
                  tolerance=DEFAULT_TOLERANCE)
    interaction, particle_number, tol = _validate_inputs(U, N, tolerance)
    model = ED.ValidatedKinetic.ModelParameters(
        Float64(parameters.t1), Float64(parameters.t2),
        Float64(parameters.t3), Float64(parameters.t4),
    )
    kinetic = ED.ValidatedKinetic.realspace_kinetic_matrix(2, model)
    # The observables below exploit the exact L=2 factorization.  Refuse to
    # silently use them if the kinetic construction ever changes that fact.
    maximum(abs, kinetic[1:2:8, 2:2:8]; init=0.0) <= 20eps(Float64) ||
        error("periodic L=2 orbital factorization is required")
    sectors = ntuple(orbital -> ED._orbital_sectors(
        kinetic[orbital:2:8, orbital:2:8], interaction, 0.0,
    ), 2)
    orbital_levels = map(ED._orbital_levels, sectors)
    states = ED._fixed_particle_product_states(orbital_levels, particle_number)
    ground_energy = first(states).energy
    ground_states = [state for state in states
                     if abs(state.energy - ground_energy) <= tol]
    return (
        U=interaction, N=particle_number, tolerance=tol, parameters=model,
        kinetic=kinetic, sectors=sectors, orbital_levels=orbital_levels,
        states=states, ground_energy=ground_energy, ground_states=ground_states,
    )
end

function _fixed_N_basis(N::Int)
    basis = [state for state in 0:65_535 if count_ones(state) == N]
    indices = Dict(state => index for (index, state) in enumerate(basis))
    return basis, indices
end

function _product_wavefunctions(prepared, selected_states, basis_indices)
    wavefunctions = zeros(Float64, length(basis_indices), length(selected_states))
    for (column, state) in enumerate(selected_states)
        first_level, second_level = state.orbital1, state.orbital2
        first_sector = prepared.sectors[1][(first_level.Nup, first_level.Ndown)]
        second_sector = prepared.sectors[2][(second_level.Nup, second_level.Ndown)]
        first_vector = view(first_sector.vectors, :, first_level.eigen_index)
        second_vector = view(second_sector.vectors, :, second_level.eigen_index)
        for (first_index, first_fock) in enumerate(first_sector.basis)
            first_coefficient = first_vector[first_index]
            abs(first_coefficient) > 20eps(Float64) || continue
            for (second_index, second_fock) in enumerate(second_sector.basis)
                coefficient = first_coefficient * second_vector[second_index]
                abs(coefficient) > 20eps(Float64) || continue
                combined_fock = first_fock | (second_fock << 8)
                wavefunctions[basis_indices[combined_fock], column] = coefficient
            end
        end
    end
    return wavefunctions
end

function _apply_fermion(state::Int, mode::Int, create::Bool)
    bit = 1 << mode
    occupied = state & bit != 0
    create == occupied && return nothing
    sign = iseven(count_ones(state & (bit - 1))) ? 1.0 : -1.0
    return (create ? state | bit : state & ~bit), sign
end

function _total_spin_raising(basis, indices)
    rows, columns, values = Int[], Int[], Float64[]
    for (column, state) in enumerate(basis), orbital in 0:1, site in 0:3
        up_mode = 8orbital + site
        down_mode = 8orbital + 4 + site
        removed = _apply_fermion(state, down_mode, false)
        isnothing(removed) && continue
        intermediate, first_sign = removed
        inserted = _apply_fermion(intermediate, up_mode, true)
        isnothing(inserted) && continue
        destination, second_sign = inserted
        push!(rows, indices[destination])
        push!(columns, column)
        push!(values, first_sign * second_sign)
    end
    return sparse(rows, columns, values, length(basis), length(basis))
end

function _total_spin_squared_action(basis, indices, wavefunctions)
    raising = _total_spin_raising(basis, indices)
    lowering = transpose(raising)
    up_mask = 0x0f0f
    down_mask = 0xf0f0
    sz_squared = [((count_ones(state & up_mask) -
                    count_ones(state & down_mask)) / 2)^2 for state in basis]
    return sz_squared .* wavefunctions +
           (raising * (lowering * wavefunctions) +
            lowering * (raising * wavefunctions)) / 2
end

"""
    c4_fock_action(state)

Apply a counterclockwise 90-degree spatial rotation together with the orbital
transformation `d_xz -> d_yz`, `d_yz -> -d_xz` to a 16-mode Fock state.  Modes
are ordered exactly as in `TwoOrbitalClusterED`: the eight modes of `d_xz`
(four up, then four down), followed by the eight modes of `d_yz`.

The returned `(state, phase)` includes both the `d_yz -> -d_xz` phase and the
fermionic sign needed to restore canonical creation-operator order.
"""
function c4_fock_action(state::Integer)
    0 <= state <= 65_535 || throw(ArgumentError("state must fit in 16 bits"))
    destinations = Int[]
    orbital_phase = 1.0
    for source_mode in 0:15
        state & (1 << source_mode) == 0 && continue
        orbital = source_mode < 8 ? 1 : 2
        within_orbital = mod(source_mode, 8)
        spin_offset = within_orbital >= 4 ? 4 : 0
        site = mod(within_orbital, 4)
        x, y = mod(site, 2), div(site, 2)
        # (x,y) -> (-y,x); modulo two, -y and y label the same cell.
        rotated_site = mod(-y, 2) + 2mod(x, 2)
        destination_orbital = 3 - orbital
        orbital == 2 && (orbital_phase = -orbital_phase)
        destination_mode = 8(destination_orbital - 1) + spin_offset + rotated_site
        push!(destinations, destination_mode)
    end
    destination_state = sum(1 << mode for mode in destinations; init=0)
    inversions = sum((destinations[i] > destinations[j]
                      for i in eachindex(destinations)
                      for j in (i + 1):length(destinations)); init=0)
    fermion_phase = iseven(inversions) ? 1.0 : -1.0
    return destination_state, orbital_phase * fermion_phase
end

function _c4_action(basis, indices, wavefunctions)
    rotated = zeros(Float64, size(wavefunctions))
    for (source, state) in enumerate(basis)
        destination, phase = c4_fock_action(state)
        rotated[indices[destination], :] .+= phase .* wavefunctions[source, :]
    end
    return rotated
end

function _energy_manifolds(states, count::Int, tolerance)
    count > 0 || throw(ArgumentError("manifolds must be positive"))
    groups = Vector{Vector{Any}}()
    for state in states
        if isempty(groups) ||
           abs(state.energy - first(last(groups)).energy) > tolerance
            length(groups) == count && break
            push!(groups, Any[state])
        else
            push!(last(groups), state)
        end
    end
    return groups
end

function _spin_label(squared_spin)
    raw_spin = (sqrt(max(0.0, 1 + 4real(squared_spin))) - 1) / 2
    spin = round(2raw_spin) / 2
    return iszero(spin) ? 0.0 : spin
end

function _c4_label(value)
    roots = ComplexF64[1, im, -1, -im]
    labels = ("+1", "+i", "-1", "-i")
    return labels[argmin(abs.(value .- roots))]
end

function _sector_row(state, manifold_index, ground_energy)
    return (
        manifold=manifold_index,
        energy=state.energy,
        excitation_energy=state.energy - ground_energy,
        Nup=state.Nup, Ndown=state.Ndown, Sz=state.Sz,
        kx=state.kx, ky=state.ky,
        kx_index=state.kx_index, ky_index=state.ky_index,
        orbital1_Nup=state.orbital1.Nup,
        orbital1_Ndown=state.orbital1.Ndown,
        orbital1_eigen_index=state.orbital1.eigen_index,
        orbital2_Nup=state.orbital2.Nup,
        orbital2_Ndown=state.orbital2.Ndown,
        orbital2_eigen_index=state.orbital2.eigen_index,
    )
end

"""
    classify_ground_symmetries(U, N; manifolds=6, ...)

Classify complete low-energy manifolds of the zero-field periodic 2x2 model.
Total `S^2` and the many-fermion `C4` representation are constructed explicitly
in the fixed-`N` Fock basis and projected into each *complete* degenerate energy
manifold.  Thus accidental choices of eigenvectors inside a degenerate block do
not affect the reported spin or rotation content.

`spin_content` counts states and SU(2) irreps separately.  `c4_content` gives
the multiplicity of the roots `+1,+i,-1,-i`; the joint table resolves `C4`
within each total-spin subspace.  On the 2x2 torus, `C4` exchanges X and Y, so
individual X/Y product labels need not themselves be rotation eigenstates.
"""
function classify_ground_symmetries(
    U::Real, N::Integer;
    parameters=ED.ValidatedKinetic.ModelParameters(),
    manifolds::Integer=6,
    tolerance::Real=DEFAULT_TOLERANCE,
)
    manifolds isa Bool && throw(ArgumentError("manifolds must be positive"))
    prepared = _prepare(U, N; parameters=parameters, tolerance=tolerance)
    groups = _energy_manifolds(prepared.states, Int(manifolds), prepared.tolerance)
    basis, basis_indices = _fixed_N_basis(prepared.N)
    rows = Any[]
    sector_rows = Any[]
    for (manifold_index, group) in enumerate(groups)
        append!(sector_rows, (_sector_row(state, manifold_index,
                                          prepared.ground_energy) for state in group))
        wavefunctions = _product_wavefunctions(prepared, group, basis_indices)
        identity_group = Matrix{Float64}(I, length(group), length(group))
        gram_residual = norm(transpose(wavefunctions) * wavefunctions - identity_group)

        s2_wavefunctions = _total_spin_squared_action(
            basis, basis_indices, wavefunctions,
        )
        s2_representation = Hermitian((transpose(wavefunctions) * s2_wavefunctions +
                                      transpose(s2_wavefunctions) * wavefunctions) / 2)
        s2_decomposition = eigen(s2_representation)
        spin_values = _spin_label.(s2_decomposition.values)
        spin_content = [begin
            state_count = count(==(spin), spin_values)
            multiplet_dimension = round(Int, 2spin + 1)
            (
                S=spin,
                S2=spin * (spin + 1),
                state_count=state_count,
                irrep_count=state_count / multiplet_dimension,
                irrep_count_is_integer=iszero(mod(state_count, multiplet_dimension)),
            )
        end for spin in sort!(unique(spin_values))]
        s2_quantization_residual = maximum(
            abs(s2_decomposition.values[index] -
                spin_values[index] * (spin_values[index] + 1))
            for index in eachindex(spin_values);
            init=0.0,
        )

        c4_wavefunctions = _c4_action(basis, basis_indices, wavefunctions)
        c4_representation = transpose(wavefunctions) * c4_wavefunctions
        c4_unitarity_residual = norm(
            adjoint(c4_representation) * c4_representation - identity_group,
        )
        c4_leakage = norm(c4_wavefunctions - wavefunctions * c4_representation)
        c4_spin_commutator = norm(
            Matrix(s2_representation) * c4_representation -
            c4_representation * Matrix(s2_representation),
        )
        c4_values = eigvals(complex(c4_representation))
        c4_labels = _c4_label.(c4_values)
        c4_content = [(eigenvalue=label, count=count(==(label), c4_labels))
                      for label in ("+1", "+i", "-1", "-i")
                      if count(==(label), c4_labels) > 0]

        joint_content = Any[]
        for spin in sort!(unique(spin_values))
            selected = findall(==(spin), spin_values)
            spin_basis = s2_decomposition.vectors[:, selected]
            restricted_c4 = adjoint(spin_basis) * c4_representation * spin_basis
            labels = _c4_label.(eigvals(complex(restricted_c4)))
            for label in ("+1", "+i", "-1", "-i")
                multiplicity = count(==(label), labels)
                multiplicity == 0 && continue
                push!(joint_content, (S=spin, c4=label, state_count=multiplicity))
            end
        end

        push!(rows, (
            index=manifold_index,
            energy=first(group).energy,
            excitation_energy=first(group).energy - prepared.ground_energy,
            degeneracy=length(group),
            spin_content=spin_content,
            c4_character=tr(c4_representation),
            c4_content=c4_content,
            joint_spin_c4_content=joint_content,
            gram_residual=gram_residual,
            s2_quantization_residual=s2_quantization_residual,
            c4_unitarity_residual=c4_unitarity_residual,
            c4_leakage=c4_leakage,
            c4_spin_commutator=c4_spin_commutator,
        ))
    end
    return (
        L=2, U=prepared.U, N=prepared.N, ground_energy=prepared.ground_energy,
        ground=first(rows), manifolds=rows, sector_levels=sector_rows,
        fixed_N_dimension=length(basis),
        tolerance=prepared.tolerance,
        c4_convention="(x,y)->(-y,x), dxz->dyz, dyz->-dxz",
        ensemble="complete zero-temperature canonical energy manifolds",
        limitation=ED.CLUSTER_LIMITATION,
    )
end

function _operator_definition(kind::Symbol)
    if kind === :o_alm || kind === :spin_altermagnetic
        return (local_kind=:spin, orbital_signs=(1.0, -1.0), canonical=:spin_altermagnetic)
    elseif kind === :spin_total
        return (local_kind=:spin, orbital_signs=(1.0, 1.0), canonical=:spin_total)
    elseif kind === :orbital_density
        return (local_kind=:half_charge, orbital_signs=(1.0, -1.0), canonical=:orbital_density)
    elseif kind === :charge
        return (local_kind=:charge, orbital_signs=(1.0, 1.0), canonical=:charge)
    end
    throw(ArgumentError(
        "operator must be :o_alm, :spin_altermagnetic, :spin_total, " *
        ":orbital_density, or :charge",
    ))
end

function _normalization_scale(normalization::Symbol)
    normalization === :none && return 1.0
    normalization === :sqrt_cells && return inv(sqrt(Float64(NCELLS)))
    normalization === :cells && return 1 / Float64(NCELLS)
    throw(ArgumentError("normalization must be :none, :sqrt_cells, or :cells"))
end

function _site_phase(nx::Int, ny::Int, site::Int)
    x, y = mod(site - 1, 2), div(site - 1, 2)
    return iseven(nx * x + ny * y) ? 1.0 : -1.0
end

function _one_orbital_diagonal(sector, nx, ny, local_kind)
    values = zeros(Float64, length(sector.basis))
    for (index, state) in enumerate(sector.basis), site in 1:4
        up = (state & (1 << (site - 1))) != 0
        down = (state & (1 << (site + 3))) != 0
        local_value = if local_kind === :spin
            (Int(up) - Int(down)) / 2
        elseif local_kind === :half_charge
            (Int(up) + Int(down)) / 2
        else
            Int(up) + Int(down)
        end
        values[index] += _site_phase(nx, ny, site) * local_value
    end
    return values
end

function _operator_matrix(prepared, orbital, level, nx, ny, local_kind)
    sector = prepared.sectors[orbital][(level.Nup, level.Ndown)]
    diagonal = _one_orbital_diagonal(sector, nx, ny, local_kind)
    return transpose(sector.vectors) * (diagonal .* sector.vectors)
end

function _merge_bosonic_peaks(frequencies, weights, tolerance)
    merged_frequencies, merged_weights = Float64[], Float64[]
    for index in sortperm(frequencies)
        weight = weights[index]
        weight > 100eps(Float64) || continue
        frequency = abs(frequencies[index]) <= tolerance ? 0.0 : frequencies[index]
        if !isempty(merged_frequencies) &&
           abs(frequency - merged_frequencies[end]) <= tolerance
            total = merged_weights[end] + weight
            merged_frequencies[end] +=
                weight / total * (frequency - merged_frequencies[end])
            merged_weights[end] = total
        else
            push!(merged_frequencies, frequency)
            push!(merged_weights, weight)
        end
    end
    return (frequencies=merged_frequencies, weights=merged_weights)
end

function _operator_value_on_product_fock(first_fock, second_fock, nx, ny,
                                         definition, scale)
    total = 0.0
    for (orbital, state) in ((1, first_fock), (2, second_fock)), site in 1:4
        up = (state & (1 << (site - 1))) != 0
        down = (state & (1 << (site + 3))) != 0
        local_value = if definition.local_kind === :spin
            (Int(up) - Int(down)) / 2
        elseif definition.local_kind === :half_charge
            (Int(up) + Int(down)) / 2
        else
            Int(up) + Int(down)
        end
        total += definition.orbital_signs[orbital] *
                 _site_phase(nx, ny, site) * local_value
    end
    return scale * total
end

function _direct_ground_moments(prepared, definition, nx, ny, scale)
    mean_value = 0.0
    equal_time = 0.0
    inverse_degeneracy = 1 / length(prepared.ground_states)
    for ground in prepared.ground_states
        first = ground.orbital1
        second = ground.orbital2
        first_sector = prepared.sectors[1][(first.Nup, first.Ndown)]
        second_sector = prepared.sectors[2][(second.Nup, second.Ndown)]
        first_probabilities = abs2.(view(first_sector.vectors, :, first.eigen_index))
        second_probabilities = abs2.(view(second_sector.vectors, :, second.eigen_index))
        for (i, first_fock) in enumerate(first_sector.basis),
            (j, second_fock) in enumerate(second_sector.basis)
            probability = inverse_degeneracy *
                          first_probabilities[i] * second_probabilities[j]
            value = _operator_value_on_product_fock(
                first_fock, second_fock, nx, ny, definition, scale,
            )
            mean_value += probability * value
            equal_time += probability * abs2(value)
        end
    end
    return mean_value, equal_time
end

function _dynamical_correlation(prepared, kind, nx, ny, normalization)
    definition = _operator_definition(kind)
    kind === :o_alm && (nx != 0 || ny != 0) && throw(ArgumentError(
        ":o_alm is specifically the q=(0,0) altermagnetic spin operator; " *
        "use :spin_altermagnetic for finite q",
    ))
    scale = _normalization_scale(normalization)
    matrix_cache = Dict{Tuple{Int,Int,Int,Int,Int,Symbol},Matrix{Float64}}()
    frequencies, weights = Float64[], Float64[]
    inverse_degeneracy = 1 / length(prepared.ground_states)
    for ground in prepared.ground_states
        first, second = ground.orbital1, ground.orbital2
        amplitudes = Dict{Tuple{Int,Int},Float64}()
        for orbital in 1:2
            active = orbital == 1 ? first : second
            spectator = orbital == 1 ? second : first
            cache_key = (orbital, active.Nup, active.Ndown, nx, ny, definition.local_kind)
            matrix = get!(matrix_cache, cache_key) do
                _operator_matrix(prepared, orbital, active, nx, ny, definition.local_kind)
            end
            coefficient = scale * definition.orbital_signs[orbital]
            for final_index in axes(matrix, 1)
                amplitude = coefficient * matrix[final_index, active.eigen_index]
                abs(amplitude) > 1.0e-14 || continue
                final_key = orbital == 1 ?
                    (final_index, spectator.eigen_index) :
                    (spectator.eigen_index, final_index)
                amplitudes[final_key] = get(amplitudes, final_key, 0.0) + amplitude
            end
        end
        first_sector = prepared.sectors[1][(first.Nup, first.Ndown)]
        second_sector = prepared.sectors[2][(second.Nup, second.Ndown)]
        for ((first_index, second_index), amplitude) in amplitudes
            weight = inverse_degeneracy * abs2(amplitude)
            weight > 100eps(Float64) || continue
            final_energy = first_sector.energies[first_index] +
                           second_sector.energies[second_index]
            frequency = final_energy - prepared.ground_energy
            frequency >= -prepared.tolerance || error(
                "Lehmann construction produced a state below the ground energy",
            )
            push!(frequencies, max(0.0, frequency))
            push!(weights, weight)
        end
    end
    peaks = _merge_bosonic_peaks(frequencies, weights, prepared.tolerance)
    mean_value, direct_equal_time = _direct_ground_moments(
        prepared, definition, nx, ny, scale,
    )
    lehmann_equal_time = sum(peaks.weights)
    elastic_weight = sum(weight for (frequency, weight) in
                         zip(peaks.frequencies, peaks.weights)
                         if abs(frequency) <= prepared.tolerance; init=0.0)
    inelastic_weight = lehmann_equal_time - elastic_weight
    regular_susceptibility = 2sum(
        weight / frequency for (frequency, weight) in
        zip(peaks.frequencies, peaks.weights)
        if frequency > prepared.tolerance;
        init=0.0,
    )
    degenerate_elastic_fluctuation = elastic_weight - abs2(mean_value)
    # Every q=0 operator offered here is a linear combination of the four
    # separately conserved N_(orbital,spin) charges of this factorized model.
    # The O_alm case is the physically important one, but reporting the same
    # fact for total spin/charge avoids a misleading finite susceptibility.
    conserved_q_zero = nx == 0 && ny == 0
    susceptibility_status = if degenerate_elastic_fluctuation > 20prepared.tolerance
        :ill_defined_degenerate_ground_manifold
    elseif conserved_q_zero
        :zero_retarded_commutator_for_conserved_operator
    else
        :regular_inelastic_value_available
    end
    interpretation = conserved_q_zero ?
        (definition.canonical === :spin_altermagnetic ?
        "On periodic L=2, O_alm commutes with H. Its exact spectral weight is " *
        "elastic at omega=0. A finite ground-manifold variance does not define " *
        "a linear T=0 susceptibility: an infinitesimal source selects a sector." :
        "This q=0 density is conserved by the factorized periodic-L=2 model, " *
        "so its retarded commutator vanishes and its weight is elastic.") :
        "The complete degenerate ground manifold is averaged with equal weight."
    return (
        L=2, U=prepared.U, N=prepared.N,
        operator=definition.canonical, requested_operator=kind,
        momentum=(nx * pi, ny * pi), momentum_indices=(nx, ny),
        normalization=normalization,
        definition=definition.canonical === :spin_total ?
            "sum_i exp(iq.r_i) [Szi,xz+Szi,yz]" :
            definition.canonical === :spin_altermagnetic ?
            "sum_i exp(iq.r_i) [Szi,xz-Szi,yz]" :
            definition.canonical === :orbital_density ?
            "(1/2)sum_i exp(iq.r_i) [n_i,xz-n_i,yz]" :
            "sum_i exp(iq.r_i) [n_i,xz+n_i,yz]",
        peaks=peaks,
        mean=mean_value,
        equal_time=direct_equal_time,
        connected_equal_time=direct_equal_time - abs2(mean_value),
        elastic_weight=elastic_weight,
        degenerate_elastic_fluctuation=degenerate_elastic_fluctuation,
        inelastic_weight=inelastic_weight,
        lehmann_sum_rule_residual=lehmann_equal_time - direct_equal_time,
        regular_inelastic_static_susceptibility=regular_susceptibility,
        susceptibility_status=susceptibility_status,
        ground_degeneracy=length(prepared.ground_states),
        retarded_commutator_vanishes=conserved_q_zero,
        interpretation=interpretation,
    )
end

"""
    ground_state_dynamical_correlation(U, N; operator=:o_alm, q=(0,0), ...)

Return the exact zero-temperature Lehmann measure of a diagonal spin/charge
density operator.  Frequencies are nonnegative excitation energies and the
integrated measure equals `<O^dagger O>`.  The zero-frequency entry is retained
explicitly; `connected_equal_time` subtracts only `|<O>|^2`, not transitions
within a degenerate ground manifold.
"""
function ground_state_dynamical_correlation(
    U::Real, N::Integer;
    operator::Symbol=:o_alm,
    q=(0, 0),
    normalization::Symbol=:none,
    parameters=ED.ValidatedKinetic.ModelParameters(),
    tolerance::Real=DEFAULT_TOLERANCE,
)
    length(q) == 2 || throw(ArgumentError("q must contain two indices"))
    nx, ny = q
    nx isa Integer && ny isa Integer && nx in 0:1 && ny in 0:1 ||
        throw(ArgumentError("q entries must be the L=2 momentum indices 0 or 1"))
    prepared = _prepare(U, N; parameters=parameters, tolerance=tolerance)
    return _dynamical_correlation(
        prepared, operator, Int(nx), Int(ny), normalization,
    )
end

"""
    ground_state_correlation_suite(U, N; ...)

Compute `S_z(q,omega)`, its altermagnetic/orbital-spin analogue, and the
orbital-density response at all four periodic-L=2 momenta, plus the unnormalised
`O_alm` response.  The expensive ED preparation is shared across channels.
"""
function ground_state_correlation_suite(
    U::Real, N::Integer;
    parameters=ED.ValidatedKinetic.ModelParameters(),
    tolerance::Real=DEFAULT_TOLERANCE,
    normalization::Symbol=:sqrt_cells,
)
    prepared = _prepare(U, N; parameters=parameters, tolerance=tolerance)
    channels = Dict{Tuple{Symbol,Int,Int},Any}()
    for kind in (:spin_total, :spin_altermagnetic, :orbital_density),
        ny in 0:1, nx in 0:1
        channels[(kind, nx, ny)] = _dynamical_correlation(
            prepared, kind, nx, ny, normalization,
        )
    end
    o_alm = _dynamical_correlation(prepared, :o_alm, 0, 0, :none)
    return (
        L=2, U=prepared.U, N=prepared.N, normalization=normalization,
        channels=channels, o_alm=o_alm,
        momenta=((0.0, 0.0), (pi, 0.0), (0.0, pi), (pi, pi)),
        ground_energy=prepared.ground_energy,
        ground_degeneracy=length(prepared.ground_states),
        limitation=ED.CLUSTER_LIMITATION,
    )
end

function _validate_complex_points(points)
    values = ComplexF64.(points isa Number ? [points] : collect(points))
    !isempty(values) && all(value -> isfinite(real(value)) && isfinite(imag(value)), values) ||
        throw(ArgumentError("evaluation points must be nonempty and finite"))
    return values
end

"""
    evaluate_lehmann_green(result, z; pole_tolerance=1e-12)

Evaluate `G(z)=sum_j w_j/(z-omega_j)` from the raw zero-temperature addition
and removal poles in a ground-state ED result.  Exact/near poles are marked in
`at_pole` and returned as complex NaN rather than overflowing silently.
"""
function evaluate_lehmann_green(result, z;
                                pole_tolerance::Real=1.0e-12)
    tolerance = Float64(pole_tolerance)
    isfinite(tolerance) && tolerance > 0 ||
        throw(ArgumentError("pole_tolerance must be finite and positive"))
    points = _validate_complex_points(z)
    values = fill(ComplexF64(NaN, NaN), 2, 2, 2, 2, length(points))
    at_pole = falses(size(values))
    for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
        channel = result.spectral_peaks[spin, orbital, kx, ky]
        for (point_index, point) in enumerate(points)
            singular = any(frequency -> abs(point - frequency) <= tolerance,
                           channel.frequencies)
            at_pole[spin, orbital, kx, ky, point_index] = singular
            singular && continue
            values[spin, orbital, kx, ky, point_index] = sum(
                weight / (point - frequency)
                for (frequency, weight) in
                zip(channel.frequencies, channel.weights);
                init=0.0 + 0.0im,
            )
        end
    end
    return (z=points, values=values, at_pole=at_pole,
            pole_tolerance=tolerance)
end

function retarded_green(result, omega; eta::Real=0.05,
                        pole_tolerance::Real=1.0e-12)
    width = Float64(eta)
    isfinite(width) && width >= 0 ||
        throw(ArgumentError("eta must be finite and nonnegative"))
    frequencies = Float64.(omega isa Number ? [omega] : collect(omega))
    !isempty(frequencies) && all(isfinite, frequencies) ||
        throw(ArgumentError("omega must be nonempty and finite"))
    evaluated = evaluate_lehmann_green(
        result, complex.(frequencies, width);
        pole_tolerance=pole_tolerance,
    )
    return merge(evaluated, (omega=frequencies, eta=width,
                             spectral=-imag.(evaluated.values) ./ pi))
end

function matsubara_green(result, omega_n;
                         pole_tolerance::Real=1.0e-12)
    frequencies = Float64.(omega_n isa Number ? [omega_n] : collect(omega_n))
    !isempty(frequencies) && all(isfinite, frequencies) ||
        throw(ArgumentError("omega_n must be nonempty and finite"))
    evaluated = evaluate_lehmann_green(
        result, im .* frequencies; pole_tolerance=pole_tolerance,
    )
    return merge(evaluated, (omega_n=frequencies,))
end

"""Bare orbital energies `epsilon_alpha(k)` on the periodic 2x2 grid."""
function bare_cluster_energies(result)
    energies = zeros(Float64, 2, 2, 2)
    parameters = ED.ValidatedKinetic.ModelParameters(;
        t1=result.hopping.t1, t2=result.hopping.t2,
        t3=result.hopping.t3, t4=result.hopping.t4,
    )
    for ky in 1:2, kx in 1:2
        block = ED.ValidatedKinetic.bloch_hamiltonian(
            result.momenta[kx], result.momenta[ky], parameters,
        )
        maximum(abs, block - Diagonal(diag(block)); init=0.0) <= 1.0e-12 ||
            error("scalar orbital self-energy requires diagonal L=2 Bloch blocks")
        energies[:, kx, ky] = diag(block)
    end
    return energies
end

"""
    noninteracting_cluster_self_energy(result, z; ...)

Evaluate the diagonal orbital self-energy
`Sigma(z)=z+mu_reference-epsilon(k)-1/G(z)`.  This is a cluster Dyson
diagnostic in the orbital basis (valid here because periodic L=2 cancels
interorbital hopping) and is intentionally restricted to `h_alm=0`.  An
explicit source changes the bare spin/orbital energies and must not be
misidentified as interaction self-energy.  Points at an exact Green-function pole or within
`green_zero_tolerance` of a Green-function zero are returned as NaN and marked
invalid instead of producing misleading infinities.
"""
function noninteracting_cluster_self_energy(
    result, z;
    pole_tolerance::Real=1.0e-12,
    green_zero_tolerance::Real=1.0e-12,
)
    hasproperty(result, :h_alm) || throw(ArgumentError(
        "the ED result must expose h_alm so the bare propagator is unambiguous",
    ))
    iszero(result.h_alm) || throw(ArgumentError(
        "noninteracting_cluster_self_energy is defined only for h_alm=0; " *
        "an explicit source must be included in the bare propagator",
    ))
    zero_tolerance = Float64(green_zero_tolerance)
    isfinite(zero_tolerance) && zero_tolerance > 0 ||
        throw(ArgumentError("green_zero_tolerance must be finite and positive"))
    green = evaluate_lehmann_green(
        result, z; pole_tolerance=pole_tolerance,
    )
    bare_energies = bare_cluster_energies(result)
    self_energy = fill(ComplexF64(NaN, NaN), size(green.values))
    near_green_zero = falses(size(green.values))
    valid = falses(size(green.values))
    for point_index in eachindex(green.z), spin in 1:2, orbital in 1:2,
        ky in 1:2, kx in 1:2
        index = (spin, orbital, kx, ky, point_index)
        green.at_pole[index...] && continue
        value = green.values[index...]
        if !isfinite(real(value)) || !isfinite(imag(value)) ||
           abs(value) <= zero_tolerance
            near_green_zero[index...] = true
            continue
        end
        inverse_bare = green.z[point_index] + result.mu_reference -
                       bare_energies[orbital, kx, ky]
        self_energy[index...] = inverse_bare - inv(value)
        valid[index...] = true
    end
    return (
        z=green.z, values=self_energy, valid=valid,
        at_green_pole=green.at_pole, near_green_zero=near_green_zero,
        green=green.values, bare_energies=bare_energies,
        mu_reference=result.mu_reference,
        pole_tolerance=green.pole_tolerance,
        green_zero_tolerance=zero_tolerance,
    )
end

end # module TwoOrbitalGroundObservables
