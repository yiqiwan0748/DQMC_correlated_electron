module TwoOrbitalObservableTools

using LinearAlgebra
using Serialization

import JDQMCFramework as jdqmcf
import JDQMCMeasurements as jdqmcm

export ALTERMAGNETIC_FIELDS,
       altermagnetic_observables_from_greens,
       accumulate_altermagnetic!,
       accumulate_unequal_time_greens!,
       momentum_space_green_bins,
       build_observable_payload,
       save_observable_payload,
       load_observable_payload,
       sign_reweighted_channel_statistics,
       trace_green_channel,
       exact_free_momentum_greens,
       validate_u0_green_payload

const ALTERMAGNETIC_FIELDS = (
    :mx,
    :my,
    :m_fm,
    :delta_alm,
    :S_alm_q0,
    :m_alm_squared,
)

"""
    altermagnetic_observables_from_greens(Gup, Gdn, L)

Return one auxiliary-field configuration's *raw*, sign-unweighted Eq. 4
observables. The Green-function convention is
`G[p,q] = <c_p c_q^dagger>`, and orbital-fast indexing uses odd entries for
`d_xz` and even entries for `d_yz`.

`S_alm_q0` includes the complete equal-time Wick contraction, including the
same-mode contact term. It is not the square of `delta_alm`.
"""
function altermagnetic_observables_from_greens(
    greens_up::AbstractMatrix{<:Real},
    greens_down::AbstractMatrix{<:Real},
    L::Integer,
)
    L > 0 || throw(ArgumentError("L must be positive"))
    number_of_cells = Int(L)^2
    dimension = 2 * number_of_cells
    size(greens_up) == (dimension, dimension) || throw(DimensionMismatch(
        "greens_up must have size (2L^2, 2L^2)",
    ))
    size(greens_down) == (dimension, dimension) || throw(DimensionMismatch(
        "greens_down must have size (2L^2, 2L^2)",
    ))

    T = promote_type(
        typeof(float(zero(eltype(greens_up)))),
        typeof(float(zero(eltype(greens_down)))),
    )
    unit = one(T)
    half = unit / 2
    occupations_up = Vector{T}(undef, dimension)
    occupations_down = Vector{T}(undef, dimension)
    for index in 1:dimension
        occupations_up[index] = unit - convert(T, greens_up[index, index])
        occupations_down[index] = unit - convert(T, greens_down[index, index])
    end

    magnetization_x_sum = zero(T)
    magnetization_y_sum = zero(T)
    for cell in 0:(number_of_cells - 1)
        index_x = 2 * cell + 1
        index_y = index_x + 1
        magnetization_x_sum +=
            occupations_up[index_x] - occupations_down[index_x]
        magnetization_y_sum +=
            occupations_up[index_y] - occupations_down[index_y]
    end

    cells = convert(T, number_of_cells)
    mx = magnetization_x_sum / cells
    my = magnetization_y_sum / cells
    m_fm = half * (mx + my)
    delta_alm = half * (mx - my)
    total_alm_mean = cells * delta_alm

    total_alm_covariance = zero(T)
    for row in 1:dimension, column in 1:dimension
        weight_row = isodd(row) ? half : -half
        weight_column = isodd(column) ? half : -half

        density_up_row_column =
            (row == column ? unit : zero(T)) -
            convert(T, greens_up[row, column])
        density_up_column_row =
            (row == column ? unit : zero(T)) -
            convert(T, greens_up[column, row])
        density_down_row_column =
            (row == column ? unit : zero(T)) -
            convert(T, greens_down[row, column])
        density_down_column_row =
            (row == column ? unit : zero(T)) -
            convert(T, greens_down[column, row])

        contact_up = row == column ? occupations_up[row] : zero(T)
        contact_down = row == column ? occupations_down[row] : zero(T)
        total_alm_covariance += weight_row * weight_column * (
            contact_up - density_up_row_column * density_up_column_row +
            contact_down - density_down_row_column * density_down_column_row
        )
    end

    total_alm_second_moment = total_alm_mean^2 + total_alm_covariance
    S_alm_q0 = total_alm_second_moment / cells
    m_alm_squared = S_alm_q0 / cells
    return (
        mx=mx,
        my=my,
        m_fm=m_fm,
        delta_alm=delta_alm,
        S_alm_q0=S_alm_q0,
        m_alm_squared=m_alm_squared,
    )
end

"""Accumulate one sign-weighted Eq. 4 sample into a bin row."""
function accumulate_altermagnetic!(
    bin_row::AbstractVector,
    greens_up,
    greens_down,
    L::Integer,
    configuration_sign::Real,
)
    length(bin_row) == length(ALTERMAGNETIC_FIELDS) ||
        throw(DimensionMismatch("the altermagnetic bin row needs six entries"))
    raw = altermagnetic_observables_from_greens(greens_up, greens_down, L)
    for (column, name) in enumerate(ALTERMAGNETIC_FIELDS)
        bin_row[column] += configuration_sign * getproperty(raw, name)
    end
    return raw
end

function _initialize_private_unequal_time_sector(
    propagators,
    beta,
    dtau,
    stabilization_period,
)
    private_propagators = deepcopy(propagators)
    calculator = jdqmcf.FermionGreensCalculator(
        private_propagators,
        beta,
        dtau,
        stabilization_period,
    )
    dimension = length(first(private_propagators).expmΔτV)
    green_00 = zeros(eltype(first(private_propagators).expmΔτV), dimension, dimension)
    logdet_green, signdet_green =
        jdqmcf.calculate_equaltime_greens!(green_00, calculator)
    green_tau_0 = similar(green_00)
    green_0_tau = similar(green_00)
    green_tau_tau = similar(green_00)
    jdqmcf.initialize_unequaltime_greens!(
        green_tau_0,
        green_0_tau,
        green_tau_tau,
        green_00,
    )
    return (
        propagators=private_propagators,
        calculator=calculator,
        green_00=green_00,
        green_tau_0=green_tau_0,
        green_0_tau=green_0_tau,
        green_tau_tau=green_tau_tau,
        logdet_green=logdet_green,
        signdet_green=signdet_green,
    )
end

function _add_all_orbital_greens!(
    output,
    time_index::Int,
    up,
    down,
    unit_cell,
    lattice,
    configuration_sign,
)
    for destination_orbital in 1:2, source_orbital in 1:2
        jdqmcm.greens!(
            view(
                output,
                1,
                destination_orbital,
                source_orbital,
                :,
                :,
                time_index,
            ),
            destination_orbital,
            source_orbital,
            unit_cell,
            lattice,
            up.green_tau_0,
            configuration_sign,
        )
        jdqmcm.greens!(
            view(
                output,
                2,
                destination_orbital,
                source_orbital,
                :,
                :,
                time_index,
            ),
            destination_orbital,
            source_orbital,
            unit_cell,
            lattice,
            down.green_tau_0,
            configuration_sign,
        )
    end
    return nothing
end

"""
    accumulate_unequal_time_greens!(output, expected_sign, ...)

Reconstruct a private, stabilized unequal-time Green traversal and add one
configuration's sign-weighted `G_ab,sigma(r,tau)` to `output`. The output axes
are `(spin, destination_orbital, source_orbital, x, y, tau_index)`.

The sampled equal-time state and its calculators are not mutated. This slower
observational implementation is intentionally used as the correctness oracle
for any future rank-1 unequal-time optimization.
"""
function accumulate_unequal_time_greens!(
    output::AbstractArray{<:Complex,6},
    expected_sign::Real,
    propagators_up,
    propagators_down,
    beta::Real,
    dtau::Real,
    stabilization_period::Integer,
    unit_cell,
    lattice,
)
    length(propagators_up) == length(propagators_down) ||
        throw(DimensionMismatch("spin propagator counts differ"))
    Ltau = length(propagators_up)
    L = lattice.L[1]
    lattice.L == [L, L] || throw(ArgumentError("the lattice must be square"))
    size(output) == (2, 2, 2, L, L, Ltau + 1) ||
        throw(DimensionMismatch(
            "output must have size (2,2,2,L,L,Ltau+1)",
        ))

    up = _initialize_private_unequal_time_sector(
        propagators_up,
        beta,
        dtau,
        stabilization_period,
    )
    down = _initialize_private_unequal_time_sector(
        propagators_down,
        beta,
        dtau,
        stabilization_period,
    )
    configuration_sign = sign(inv(up.signdet_green) * inv(down.signdet_green))
    configuration_sign == expected_sign || error(
        "private unequal-time reconstruction changed the configuration sign",
    )

    _add_all_orbital_greens!(
        output,
        1,
        up,
        down,
        unit_cell,
        lattice,
        configuration_sign,
    )

    maximum_error_up = zero(real(eltype(output)))
    maximum_error_down = zero(real(eltype(output)))
    visited = falses(Ltau)
    for time_slice in up.calculator
        jdqmcf.propagate_unequaltime_greens!(
            up.green_tau_0,
            up.green_0_tau,
            up.green_tau_tau,
            up.calculator,
            up.propagators,
        )
        jdqmcf.propagate_unequaltime_greens!(
            down.green_tau_0,
            down.green_0_tau,
            down.green_tau_tau,
            down.calculator,
            down.propagators,
        )
        up_logdet, up_signdet, correction_up, _ =
            jdqmcf.stabilize_unequaltime_greens!(
                up.green_tau_0,
                up.green_0_tau,
                up.green_tau_tau,
                up.logdet_green,
                up.signdet_green,
                up.calculator,
                up.propagators;
                update_B̄=false,
            )
        down_logdet, down_signdet, correction_down, _ =
            jdqmcf.stabilize_unequaltime_greens!(
                down.green_tau_0,
                down.green_0_tau,
                down.green_tau_tau,
                down.logdet_green,
                down.signdet_green,
                down.calculator,
                down.propagators;
                update_B̄=false,
            )
        corrected_configuration_sign =
            sign(inv(up_signdet) * inv(down_signdet))
        corrected_configuration_sign == configuration_sign || error(
            "unequal-time stabilization changed the determinant sign",
        )
        # Named tuples are immutable; replace only the evolving scalar fields.
        up = merge(up, (logdet_green=up_logdet, signdet_green=up_signdet))
        down = merge(
            down,
            (logdet_green=down_logdet, signdet_green=down_signdet),
        )
        maximum_error_up = max(maximum_error_up, correction_up)
        maximum_error_down = max(maximum_error_down, correction_down)

        _add_all_orbital_greens!(
            output,
            time_slice + 1,
            up,
            down,
            unit_cell,
            lattice,
            configuration_sign,
        )
        visited[time_slice] = true
        iterate(down.calculator, up.calculator)
    end
    all(visited) || error("the unequal-time traversal missed a time slice")
    all(isfinite, output) || error(
        "unequal-time propagation produced a non-finite Green function",
    )
    return (
        configuration_sign=configuration_sign,
        maximum_stabilization_error=(maximum_error_up, maximum_error_down),
    )
end

"""
    momentum_space_green_bins(real_space_bins, unit_cell, lattice)

Fourier transform signed numerator bins, either on a copy (the default) or in place with `copy_input=false`. Input and output
axes are `(bin, spin, destination_orbital, source_orbital, x_or_kx, y_or_ky,
tau_index)`. Both orbitals share the same intracell position, so the basis
phase vanishes.
"""
function momentum_space_green_bins(
    real_space_bins::AbstractArray{<:Complex,7},
    unit_cell,
    lattice;
    copy_input::Bool=true,
)
    momentum_bins = copy_input ? copy(real_space_bins) : real_space_bins
    T = typeof(float(real(zero(eltype(momentum_bins)))))
    jdqmcm.fourier_transform!(
        momentum_bins,
        zeros(T, 2),
        (1, 2, 3, 4, 7),
        unit_cell,
        lattice,
    )
    return momentum_bins
end

function build_observable_payload(;
    metadata,
    tau,
    momenta,
    basic_bins,
    altermagnetic_signed_bins,
    green_sign_sums,
    green_counts,
    green_signed_momentum_bins,
    green_maximum_stabilization_errors,
)
    return Dict{String,Any}(
        "schema_version" => 1,
        "kind" => "two_orbital_dqmc_observables",
        "model" => "PRB 111 L020401 two-orbital Hubbard model",
        "orbital_names" => ("d_xz", "d_yz"),
        "momentum_convention" =>
            "kx,ky=2pi*n/L with zero-based n; unnormalized forward transform",
        "basic_bin_normalization" =>
            "signed means over all scalar measurements in each bin",
        "green_bin_normalization" =>
            "signed numerator sums; divide only by paired green_sign_sums",
        "trace_channel_normalization" =>
            "sum spin and diagonal orbitals; divide by 4 for unit spectral moment",
        "metadata" => metadata,
        "tau" => collect(tau),
        "momenta" => collect(momenta),
        "basic_bins" => basic_bins,
        "altermagnetic_fields" => collect(ALTERMAGNETIC_FIELDS),
        "altermagnetic_signed_bins" => altermagnetic_signed_bins,
        "green_sign_sums" => collect(green_sign_sums),
        "green_counts" => collect(green_counts),
        "green_signed_momentum_bins" => green_signed_momentum_bins,
        "green_maximum_stabilization_errors" =>
            green_maximum_stabilization_errors,
        "green_axes" => (
            :bin,
            :spin,
            :destination_orbital,
            :source_orbital,
            :kx_index,
            :ky_index,
            :tau_index,
        ),
        "green_convention" =>
            "G=<T c(tau)c^dagger(0)>; no leading minus sign",
    )
end

"""Serialize one completed run without adding a file-format dependency."""
function save_observable_payload(path::AbstractString, payload; overwrite=false)
    isempty(path) && throw(ArgumentError("output path must be nonempty"))
    isfile(path) && !overwrite && throw(ArgumentError(
        "refusing to overwrite existing output: $path",
    ))
    parent = dirname(abspath(path))
    mkpath(parent)
    open(path, "w") do io
        serialize(io, payload)
    end
    return abspath(path)
end

function load_observable_payload(path::AbstractString)
    payload = open(deserialize, path)
    payload isa AbstractDict || error("observable file does not contain a dictionary")
    get(payload, "schema_version", nothing) == 1 || error(
        "unsupported observable schema version",
    )
    return payload
end

function _usable_sign_denominator(sign_sum, count, minimum_average_sign)
    count > 0 || return false
    average_sign = sign_sum / count
    return isfinite(average_sign) && abs(average_sign) > minimum_average_sign
end

"""
    sign_reweighted_channel_statistics(numerator_bins, sign_sums, counts;
                                       minimum_average_sign=0.05)

Return the full sign-reweighted imaginary-time vector and its common-block
ratio-jackknife covariance. `numerator_bins` has shape `(bin,tau)` and stores
signed sums, not ratios or means.
"""
function sign_reweighted_channel_statistics(
    numerator_bins::AbstractMatrix,
    sign_sums::AbstractVector,
    counts::AbstractVector{<:Integer};
    minimum_average_sign::Real=0.05,
)
    number_of_bins, number_of_times = size(numerator_bins)
    length(sign_sums) == number_of_bins || throw(DimensionMismatch(
        "sign_sums length must equal the number of bins",
    ))
    length(counts) == number_of_bins || throw(DimensionMismatch(
        "counts length must equal the number of bins",
    ))
    number_of_bins > 1 || throw(ArgumentError(
        "at least two Green-function bins are required",
    ))
    isfinite(minimum_average_sign) && 0 <= minimum_average_sign < 1 ||
        throw(ArgumentError("minimum_average_sign must be finite and in [0,1)"))

    full_sign = sum(sign_sums)
    full_count = sum(counts)
    full_usable = _usable_sign_denominator(
        full_sign,
        full_count,
        minimum_average_sign,
    )
    full_numerator = vec(sum(numerator_bins; dims=1))
    full_values = full_usable ? full_numerator ./ full_sign : missing

    leave_one_out = Matrix{eltype(numerator_bins)}(
        undef,
        number_of_bins,
        number_of_times,
    )
    leave_one_out_usable = trues(number_of_bins)
    for bin in 1:number_of_bins
        denominator = full_sign - sign_sums[bin]
        count = full_count - counts[bin]
        usable = _usable_sign_denominator(
            denominator,
            count,
            minimum_average_sign,
        )
        leave_one_out_usable[bin] = usable
        if usable
            leave_one_out[bin, :] .=
                (full_numerator .- view(numerator_bins, bin, :)) ./ denominator
        else
            fill!(view(leave_one_out, bin, :), zero(eltype(leave_one_out)))
        end
    end

    covariance = missing
    standard_errors = missing
    if full_usable && all(leave_one_out_usable) && all(isfinite, leave_one_out)
        # Spectral inputs below are real positive trace/diagonal channels.
        real_leave_one_out = real.(leave_one_out)
        center = vec(sum(real_leave_one_out; dims=1)) ./ number_of_bins
        covariance_value = zeros(Float64, number_of_times, number_of_times)
        for bin in 1:number_of_bins
            deviation = view(real_leave_one_out, bin, :) .- center
            covariance_value .+= deviation * transpose(deviation)
        end
        covariance_value .*= (number_of_bins - 1) / number_of_bins
        covariance = covariance_value
        standard_errors = sqrt.(max.(zero(Float64), diag(covariance_value)))
    end
    return (
        values=full_values,
        covariance=covariance,
        standard_errors=standard_errors,
        full_average_sign=full_count == 0 ? NaN : full_sign / full_count,
        full_denominator_usable=full_usable,
        leave_one_out_denominators_usable=all(leave_one_out_usable),
        leave_one_out_usable=leave_one_out_usable,
        full_sign_sum=full_sign,
        full_count=full_count,
    )
end

"""
    trace_green_channel(payload; kx_index=nothing, ky_index=nothing)

Build signed numerator bins for the positive spin-and-orbital trace. With no
momentum indices, average over all momenta to obtain the local channel used for
the DOS. With both indices, return the total channel at that momentum for
`A(k,omega)`.
"""
function trace_green_channel(payload; kx_index=nothing, ky_index=nothing)
    greens = payload["green_signed_momentum_bins"]
    ndims(greens) == 7 || throw(DimensionMismatch(
        "green_signed_momentum_bins must have seven axes",
    ))
    number_of_bins = size(greens, 1)
    L = size(greens, 5)
    size(greens, 6) == L || throw(DimensionMismatch(
        "momentum axes must form a square grid",
    ))
    number_of_times = size(greens, 7)
    (isnothing(kx_index) && isnothing(ky_index)) ||
        (!isnothing(kx_index) && !isnothing(ky_index)) ||
        throw(ArgumentError("supply both momentum indices or neither"))

    output = zeros(eltype(greens), number_of_bins, number_of_times)
    if isnothing(kx_index)
        for bin in 1:number_of_bins, time_index in 1:number_of_times,
            ky in 1:L, kx in 1:L, orbital in 1:2, spin in 1:2
            output[bin, time_index] +=
                greens[bin, spin, orbital, orbital, kx, ky, time_index] / L^2
        end
    else
        1 <= kx_index <= L && 1 <= ky_index <= L ||
            throw(ArgumentError("momentum indices must lie in 1:L"))
        for bin in 1:number_of_bins, time_index in 1:number_of_times,
            orbital in 1:2, spin in 1:2
            output[bin, time_index] += greens[
                bin,
                spin,
                orbital,
                orbital,
                kx_index,
                ky_index,
                time_index,
            ]
        end
    end
    return output
end

function _stable_free_fermion_kernel(energy, tau, beta)
    if energy >= 0
        return exp(-tau * energy) / (1 + exp(-beta * energy))
    end
    return exp((beta - tau) * energy) / (1 + exp(beta * energy))
end

function _bloch_hamiltonian(kx, ky, t1, t2, t3, t4)
    epsilon_x =
        -2t1 * cos(kx) - 2t2 * cos(ky) - 4t3 * cos(kx) * cos(ky)
    epsilon_y =
        -2t2 * cos(kx) - 2t1 * cos(ky) - 4t3 * cos(kx) * cos(ky)
    epsilon_xy = -4t4 * sin(kx) * sin(ky)
    return [epsilon_x epsilon_xy; epsilon_xy epsilon_y]
end

"""Exact finite-grid U=0 Green matrix in the same no-leading-minus convention."""
function exact_free_momentum_greens(
    tau,
    momenta,
    beta,
    mu,
    t1,
    t2,
    t3,
    t4,
)
    L = length(momenta)
    output = zeros(ComplexF64, 2, 2, 2, L, L, length(tau))
    for (ky_index, ky) in pairs(momenta),
        (kx_index, kx) in pairs(momenta)
        hamiltonian = _bloch_hamiltonian(kx, ky, t1, t2, t3, t4)
        hamiltonian[1, 1] -= mu
        hamiltonian[2, 2] -= mu
        decomposition = eigen(Symmetric(hamiltonian))
        for (time_index, time) in pairs(tau)
            spectral_values = [
                _stable_free_fermion_kernel(energy, time, beta)
                for energy in decomposition.values
            ]
            green = decomposition.vectors * Diagonal(spectral_values) *
                    transpose(decomposition.vectors)
            for spin in 1:2
                output[spin, :, :, kx_index, ky_index, time_index] .= green
            end
        end
    end
    return output
end

function validate_u0_green_payload(payload; atol=5.0e-10)
    metadata = payload["metadata"]
    metadata["U"] == 0 || throw(ArgumentError(
        "U=0 validation requires metadata U == 0",
    ))
    sign_sums = payload["green_sign_sums"]
    counts = payload["green_counts"]
    all(counts .> 0) || error("every Green bin needs at least one sample")
    isapprox(sum(sign_sums), sum(counts); atol=100eps(Float64), rtol=0.0) ||
        error("U=0 Green samples must all have positive sign")
    measured = dropdims(
        sum(payload["green_signed_momentum_bins"]; dims=1);
        dims=1,
    ) ./ sum(sign_sums)
    expected = exact_free_momentum_greens(
        payload["tau"],
        payload["momenta"],
        metadata["beta"],
        metadata["mu_measured"],
        metadata["t1"],
        metadata["t2"],
        metadata["t3"],
        metadata["t4"],
    )
    maximum_error = maximum(abs.(measured .- expected))
    endpoint_error = maximum(abs.(
        measured[:, :, :, :, :, 1] .+
        measured[:, :, :, :, :, end] .-
        reshape(Matrix{ComplexF64}(I, 2, 2), 1, 2, 2, 1, 1)
    ))
    passed = maximum_error <= atol && endpoint_error <= atol
    return (
        passed=passed,
        maximum_error=maximum_error,
        endpoint_error=endpoint_error,
        tolerance=atol,
    )
end

end # module
