#!/usr/bin/env julia

module ValidateConstrainedPathAFQMC

using AltermagnetDQMCTrial
using Dates

include(joinpath(@__DIR__, "hubbard_ed_benchmarks.jl"))
include(joinpath(@__DIR__, "two_orbital_open_cluster_ed.jl"))
include(joinpath(@__DIR__, "two_orbital_cluster_ed.jl"))

using .HubbardEDBenchmarks
using .TwoOrbitalOpenClusterED
using .TwoOrbitalClusterED

export DQMC_BRIDGE_POINT,
       parse_options,
       validation_plan,
       exact_thermal_bridge,
       run_validation,
       main

const DQMC_BRIDGE_POINT = (
    L=2,
    U=2.0,
    beta=10.0,
    mu=-4.043283631438571,
    Nup=2,
    Ndown=2,
)

const THERMODYNAMIC_QUANTITIES = (
    :density,
    :doping,
    :kinetic_energy_per_cell,
    :shifted_interaction_energy_per_cell,
    :internal_energy_per_cell,
    :grand_energy_per_cell,
)

const HELP = """
Validate constrained-path AFQMC against analytic results, exact diagonalization,
and finite-temperature DQMC.

Usage:
  julia --project=. scripts/validate_constrained_path_afqmc.jl [options]

Options use --name=value:
  --profile=quick            quick or standard
  --seed-offset=0            integer added to every stochastic seed
  --output-dir=results/cp_afqmc_validation

The output directory must not already exist. The quick profile is a smoke and
regression check. Only the standard profile is meant to judge convergence, and
even it does not remove constrained-path bias or authorize a strong-U physics run.
"""

function _parse_integer(raw::AbstractString, name::AbstractString)
    return try
        parse(Int, raw)
    catch
        throw(ArgumentError("--$name must be an integer"))
    end
end

function parse_options(arguments=ARGS)
    any(argument -> argument in ("--help", "-h"), arguments) && return nothing
    allowed = Set(("profile", "seed-offset", "output-dir"))
    raw = Dict{String,String}()
    for argument in arguments
        startswith(argument, "--") || throw(ArgumentError(
            "arguments must use --name=value",
        ))
        pieces = split(argument[3:end], '='; limit=2)
        length(pieces) == 2 || throw(ArgumentError(
            "argument $argument must use --name=value",
        ))
        name, value = pieces
        name in allowed || throw(ArgumentError("unknown option --$name"))
        haskey(raw, name) && throw(ArgumentError("duplicate option --$name"))
        raw[name] = value
    end
    profile_string = lowercase(get(raw, "profile", "quick"))
    profile_string in ("quick", "standard") || throw(ArgumentError(
        "--profile must be quick or standard",
    ))
    output_raw = get(raw, "output-dir", "results/cp_afqmc_validation")
    isempty(output_raw) && throw(ArgumentError("--output-dir must not be empty"))
    return (
        profile=Symbol(profile_string),
        seed_offset=_parse_integer(get(raw, "seed-offset", "0"), "seed-offset"),
        output_dir=abspath(output_raw),
    )
end

function validation_plan(profile::Union{Symbol,AbstractString})
    selected = Symbol(lowercase(String(profile)))
    trial_specs = (
        (label="free", pattern=:free, field=0.0),
        (label="alm_plus", pattern=:altermagnetic, field=0.1),
        (label="alm_minus", pattern=:altermagnetic, field=-0.1),
        (label="stripe_x", pattern=:stripe_x, field=0.1),
        (label="stripe_y", pattern=:stripe_y, field=0.1),
        (label="neel", pattern=:neel, field=0.1),
    )
    if selected == :quick
        return (
            profile=:quick,
            interpretation="smoke_and_regression_only",
            periodic_trials=trial_specs[[1, 2, 4]],
            periodic_dtaus=(0.04, 0.02),
            periodic_seeds=(1103, 2207),
            periodic_walkers=64,
            periodic_projection_time=3.2,
            periodic_measurements=12,
            periodic_measurement_spacing=0.08,
            periodic_backpropagation_time=0.6,
            periodic_block_size=3,
            periodic_population_control_every=5,
            dimer_dtaus=Dict(4.0 => (0.04, 0.02), 20.0 => (0.01, 0.005)),
            dimer_seeds=(317,),
            dimer_walkers=240,
            dimer_projection_time=1.5,
            dimer_measurements=12,
            strong_dimer_measurements=12,
            dimer_measurement_spacing=0.02,
            dimer_backpropagation_time=0.4,
            dimer_block_size=3,
            dimer_population_control_every=5,
            dimer_convergence_variants=(),
            open_trials=trial_specs[[1, 2, 4]],
            open_dtaus=(0.02,),
            open_seeds=(3109,),
            open_walkers=64,
            open_projection_time=3.0,
            open_measurements=12,
            open_measurement_spacing=0.08,
            open_backpropagation_time=0.8,
            open_block_size=3,
            open_population_control_every=5,
            doped_open_trials=trial_specs[[1]],
            doped_open_seeds=(5101,),
            doped_open_backpropagation_time=0.8,
            doped_open_long_backpropagation_time=0.8,
            doped_open_long_measurements=12,
            doped_open_population_control_every=5,
            dqmc_dtaus=(0.1, 0.05),
            dqmc_seeds=(7741,),
            dqmc_warmup_sweeps=16,
            dqmc_measurement_sweeps=32,
            dqmc_block_size=8,
            dqmc_stabilization_period=5,
            dqmc_minimum_sign_effective_count=16.0,
            dqmc_drift_block_size=8,
            dqmc_block_stability_sizes=(8,),
            dqmc_block_error_ratio_maximum=2.0,
            dqmc_consistency_sigma=4.0,
            dqmc_random_difference_sigma=3.0,
            dqmc_density_consistency_precision=0.002,
            dqmc_energy_consistency_precision=0.02,
            dqmc_extrapolation_floor=0.02,
            dqmc_extrapolation_precision=0.01,
            dqmc_extrapolation_maximum_reduced_chi_squared=9.0,
            sigma_gate=6.0,
        )
    elseif selected == :standard
        return (
            profile=:standard,
            interpretation="convergence_validation_not_constraint_bias_removal",
            periodic_trials=trial_specs,
            periodic_dtaus=(0.04, 0.02, 0.01),
            periodic_seeds=(1103, 2207, 3301),
            periodic_walkers=256,
            periodic_projection_time=8.0,
            periodic_measurements=40,
            periodic_measurement_spacing=0.1,
            periodic_backpropagation_time=2.0,
            periodic_block_size=5,
            periodic_population_control_every=5,
            dimer_dtaus=Dict(4.0 => (0.04, 0.02, 0.01),
                              20.0 => (0.01, 0.005, 0.0025)),
            dimer_seeds=(317, 401, 509),
            dimer_walkers=480,
            dimer_projection_time=4.0,
            dimer_measurements=40,
            strong_dimer_measurements=240,
            dimer_measurement_spacing=0.04,
            dimer_backpropagation_time=1.5,
            dimer_block_size=5,
            dimer_population_control_every=5,
            dimer_convergence_variants=(
                (label="projection8", projection_time=8.0, walkers=480,
                 population_control_every=5, backpropagation_time=1.5),
                (label="walkers960", projection_time=4.0, walkers=960,
                 population_control_every=5, backpropagation_time=1.5),
                (label="population10", projection_time=4.0, walkers=480,
                 population_control_every=10, backpropagation_time=1.5),
                (label="backprop3", projection_time=4.0, walkers=480,
                 population_control_every=5, backpropagation_time=3.0),
            ),
            open_trials=trial_specs,
            open_dtaus=(0.04, 0.02, 0.01),
            open_seeds=(3109, 4211),
            open_walkers=256,
            open_projection_time=8.0,
            open_measurements=40,
            open_measurement_spacing=0.1,
            open_backpropagation_time=2.0,
            open_block_size=5,
            open_population_control_every=5,
            doped_open_trials=trial_specs,
            doped_open_seeds=(5101, 6203, 7307),
            doped_open_backpropagation_time=2.0,
            doped_open_long_backpropagation_time=4.0,
            doped_open_long_measurements=120,
            doped_open_population_control_every=5,
            dqmc_dtaus=(0.1, 0.05, 0.025),
            dqmc_seeds=(7741, 9901),
            dqmc_warmup_sweeps=1024,
            dqmc_measurement_sweeps=8192,
            dqmc_block_size=128,
            dqmc_stabilization_period=5,
            dqmc_minimum_sign_effective_count=128.0,
            dqmc_drift_block_size=256,
            dqmc_block_stability_sizes=(64, 128, 256),
            dqmc_block_error_ratio_maximum=2.0,
            dqmc_consistency_sigma=4.0,
            dqmc_random_difference_sigma=3.0,
            dqmc_density_consistency_precision=0.002,
            dqmc_energy_consistency_precision=0.02,
            dqmc_extrapolation_floor=0.02,
            dqmc_extrapolation_precision=0.01,
            dqmc_extrapolation_maximum_reduced_chi_squared=9.0,
            sigma_gate=5.0,
        )
    end
    throw(ArgumentError("profile must be quick or standard"))
end

function _check_row(;
    check_id,
    stage,
    profile,
    system,
    boundary,
    method,
    quantity,
    U=missing,
    beta=missing,
    mu=missing,
    Nup=missing,
    Ndown=missing,
    trial="",
    dtau=missing,
    seed=missing,
    estimate=missing,
    standard_error=missing,
    reference=missing,
    absolute_error=missing,
    allowed_error=missing,
    passed=false,
    required=true,
    note="",
)
    return (
        check_id=String(check_id),
        stage=String(stage),
        profile=String(profile),
        system=String(system),
        boundary=String(boundary),
        method=String(method),
        quantity=String(quantity),
        U=U,
        beta=beta,
        mu=mu,
        Nup=Nup,
        Ndown=Ndown,
        trial=String(trial),
        dtau=dtau,
        seed=seed,
        estimate=estimate,
        standard_error=standard_error,
        reference=reference,
        absolute_error=absolute_error,
        allowed_error=allowed_error,
        passed=Bool(passed),
        required=Bool(required),
        note=String(note),
    )
end

function _numeric_check!(checks; estimate, reference, floor, sigma=0.0,
                         standard_error=missing, precision_ceiling=nothing,
                         kwargs...)
    usable = estimate isa Real && reference isa Real &&
        isfinite(estimate) && isfinite(reference)
    usable_error = standard_error isa Real && isfinite(standard_error) &&
        standard_error >= 0
    allowed = max(Float64(floor), usable_error ? sigma * abs(standard_error) : 0.0)
    error = usable ? abs(estimate - reference) : missing
    passed = usable && error <= allowed
    comparison = _check_row(
        ; kwargs...,
        estimate=estimate,
        standard_error=standard_error,
        reference=reference,
        absolute_error=error,
        allowed_error=allowed,
        passed=passed,
    )
    push!(checks, comparison)

    precision_passed = true
    if !isnothing(precision_ceiling)
        ceiling = Float64(precision_ceiling)
        isfinite(ceiling) && ceiling >= 0 || throw(ArgumentError(
            "precision_ceiling must be finite and nonnegative",
        ))
        precision_error = usable_error ? abs(Float64(standard_error)) : missing
        precision_passed = usable_error && precision_error <= ceiling
        push!(checks, merge(comparison, (
            check_id=comparison.check_id * ":precision",
            quantity=comparison.quantity * "_standard_error",
            estimate=standard_error,
            standard_error=missing,
            reference=0.0,
            absolute_error=precision_error,
            allowed_error=ceiling,
            passed=precision_passed,
            note=comparison.note *
                "; required one-sigma precision ceiling prevents a noisy " *
                "estimate from passing only through the sigma allowance",
        )))
    end
    return passed && precision_passed
end

function _boolean_check!(checks; value::Bool, kwargs...)
    push!(checks, _check_row(
        ; kwargs...,
        estimate=value ? 1.0 : 0.0,
        reference=1.0,
        absolute_error=value ? 0.0 : 1.0,
        allowed_error=0.0,
        passed=value,
    ))
    return value
end

function _error_check!(checks, profile, stage, system, method, error;
                       boundary="none", check_id=stage)
    message = sprint(showerror, error)
    push!(checks, _check_row(
        check_id=check_id,
        stage=stage,
        profile=profile,
        system=system,
        boundary=boundary,
        method=method,
        quantity="completed_without_exception",
        estimate=0.0,
        reference=1.0,
        absolute_error=1.0,
        allowed_error=0.0,
        passed=false,
        required=true,
        note=message,
    ))
    return nothing
end

function _run_row(;
    run_id,
    method,
    system,
    boundary,
    status="ok",
    U=missing,
    beta=missing,
    mu=missing,
    Nup=missing,
    Ndown=missing,
    variant="",
    trial="",
    trial_pattern="",
    trial_field=missing,
    trial_up_shell_gap=missing,
    trial_down_shell_gap=missing,
    dtau=missing,
    seed=missing,
    walkers=missing,
    warmup_steps=missing,
    planned_warmup_time=missing,
    measurement_count=missing,
    steps_between_measurements=missing,
    backpropagation_steps=missing,
    population_control_every=missing,
    population_controls=missing,
    orthogonalize_every=missing,
    overlap_refresh_every=missing,
    block_size=missing,
    projection_time=missing,
    total_projection_time=missing,
    runtime_seconds=missing,
    energy=missing,
    energy_standard_error=missing,
    mixed_kinetic_energy=missing,
    mixed_kinetic_energy_standard_error=missing,
    mixed_interaction_energy=missing,
    mixed_interaction_energy_standard_error=missing,
    mixed_double_per_cell=missing,
    mixed_double_per_cell_standard_error=missing,
    backpropagated_energy=missing,
    backpropagated_energy_standard_error=missing,
    backpropagated_kinetic_energy=missing,
    backpropagated_kinetic_energy_standard_error=missing,
    backpropagated_interaction_energy=missing,
    backpropagated_interaction_energy_standard_error=missing,
    backpropagated_double_per_cell=missing,
    backpropagated_double_per_cell_standard_error=missing,
    S_alm_q0=missing,
    S_alm_q0_standard_error=missing,
    S_fm_q0=missing,
    S_fm_q0_standard_error=missing,
    density=missing,
    average_sign=missing,
    sign_effective_count=missing,
    acceptance_rate=missing,
    maximum_recompute_error=missing,
    constraint_rejections=missing,
    killed_walkers=missing,
    overlap_inverse_failures=missing,
    minimum_backprop_ancestors=missing,
    note="",
)
    return (
        run_id=String(run_id), method=String(method), system=String(system),
        boundary=String(boundary), status=String(status), U=U, beta=beta, mu=mu,
        Nup=Nup, Ndown=Ndown, variant=String(variant), trial=String(trial),
        trial_pattern=String(trial_pattern), trial_field=trial_field,
        trial_up_shell_gap=trial_up_shell_gap,
        trial_down_shell_gap=trial_down_shell_gap,
        dtau=dtau, seed=seed, walkers=walkers, warmup_steps=warmup_steps,
        planned_warmup_time=planned_warmup_time,
        measurement_count=measurement_count,
        steps_between_measurements=steps_between_measurements,
        backpropagation_steps=backpropagation_steps,
        population_control_every=population_control_every,
        population_controls=population_controls,
        orthogonalize_every=orthogonalize_every,
        overlap_refresh_every=overlap_refresh_every,
        block_size=block_size, projection_time=projection_time,
        total_projection_time=total_projection_time,
        runtime_seconds=runtime_seconds,
        energy=energy, energy_standard_error=energy_standard_error,
        mixed_kinetic_energy=mixed_kinetic_energy,
        mixed_kinetic_energy_standard_error=mixed_kinetic_energy_standard_error,
        mixed_interaction_energy=mixed_interaction_energy,
        mixed_interaction_energy_standard_error=
            mixed_interaction_energy_standard_error,
        mixed_double_per_cell=mixed_double_per_cell,
        mixed_double_per_cell_standard_error=mixed_double_per_cell_standard_error,
        backpropagated_energy=backpropagated_energy,
        backpropagated_energy_standard_error=
            backpropagated_energy_standard_error,
        backpropagated_kinetic_energy=backpropagated_kinetic_energy,
        backpropagated_kinetic_energy_standard_error=
            backpropagated_kinetic_energy_standard_error,
        backpropagated_interaction_energy=backpropagated_interaction_energy,
        backpropagated_interaction_energy_standard_error=
            backpropagated_interaction_energy_standard_error,
        backpropagated_double_per_cell=backpropagated_double_per_cell,
        backpropagated_double_per_cell_standard_error=
            backpropagated_double_per_cell_standard_error,
        S_alm_q0=S_alm_q0, S_alm_q0_standard_error=S_alm_q0_standard_error,
        S_fm_q0=S_fm_q0, S_fm_q0_standard_error=S_fm_q0_standard_error,
        density=density, average_sign=average_sign,
        sign_effective_count=sign_effective_count,
        acceptance_rate=acceptance_rate,
        maximum_recompute_error=maximum_recompute_error,
        constraint_rejections=constraint_rejections, killed_walkers=killed_walkers,
        overlap_inverse_failures=overlap_inverse_failures,
        minimum_backprop_ancestors=minimum_backprop_ancestors,
        note=String(note),
    )
end

function _sample_row(;
    run_id,
    sample,
    step=missing,
    sign=missing,
    density=missing,
    kinetic_energy_per_cell=missing,
    interaction_energy_per_cell=missing,
    internal_energy_per_cell=missing,
    grand_energy_per_cell=missing,
    mixed_energy=missing,
    mixed_kinetic_energy=missing,
    mixed_interaction_energy=missing,
    mixed_double_per_cell=missing,
    backpropagated_energy=missing,
    backpropagated_kinetic_energy=missing,
    backpropagated_interaction_energy=missing,
    backpropagated_double_per_cell=missing,
    S_alm_q0=missing,
    S_fm_q0=missing,
    distinct_backprop_ancestors=missing,
)
    return (
        run_id=String(run_id), sample=Int(sample), step=step, sign=sign,
        density=density, kinetic_energy_per_cell=kinetic_energy_per_cell,
        interaction_energy_per_cell=interaction_energy_per_cell,
        internal_energy_per_cell=internal_energy_per_cell,
        grand_energy_per_cell=grand_energy_per_cell,
        mixed_energy=mixed_energy, mixed_kinetic_energy=mixed_kinetic_energy,
        mixed_interaction_energy=mixed_interaction_energy,
        mixed_double_per_cell=mixed_double_per_cell,
        backpropagated_energy=backpropagated_energy,
        backpropagated_kinetic_energy=backpropagated_kinetic_energy,
        backpropagated_interaction_energy=backpropagated_interaction_energy,
        backpropagated_double_per_cell=backpropagated_double_per_cell,
        S_alm_q0=S_alm_q0, S_fm_q0=S_fm_q0,
        distinct_backprop_ancestors=distinct_backprop_ancestors,
    )
end

_steps_for_time(time, dtau; minimum=1) = max(minimum, round(Int, time / dtau))

function _trial_requests(plan, family::Symbol)
    dtaus = getproperty(plan, Symbol(family, :_dtaus))
    trials = getproperty(plan, Symbol(family, :_trials))
    seeds = getproperty(plan, Symbol(family, :_seeds))
    if plan.profile == :quick
        return [(
            dtau=dtau, trial=trial, base_seed=seed,
        ) for dtau in dtaus for trial in trials for seed in seeds]
    end

    # Standard uses a sparse cross: the free trial scans every dtau and seed,
    # while every other trial is checked at the finest dtau and first seed.
    # This separates time-step/seed tests from trial-bias tests without paying
    # for their full Cartesian product.
    requests = [(
        dtau=dtau, trial=first(trials), base_seed=seed,
    ) for dtau in dtaus for seed in seeds]
    for trial in trials[2:end]
        push!(requests, (
            dtau=minimum(dtaus), trial=trial, base_seed=first(seeds),
        ))
    end
    return requests
end

function _dimer_requests(plan, U)
    dtaus = plan.dimer_dtaus[U]
    seeds = plan.dimer_seeds
    if plan.profile == :quick || U == 20.0
        return [(dtau=dtau, base_seed=seed)
                for dtau in dtaus for seed in seeds]
    end
    requests = [(dtau=dtau, base_seed=first(seeds)) for dtau in dtaus]
    for seed in seeds[2:end]
        push!(requests, (dtau=minimum(dtaus), base_seed=seed))
    end
    return requests
end

function _strong_dimer_convergence_requests(plan)
    plan.profile == :standard || return NamedTuple[]
    dtau = minimum(plan.dimer_dtaus[20.0])
    return [(
        dtau=dtau,
        base_seed=seed,
        variant=variant.label,
        projection_time=variant.projection_time,
        walkers=variant.walkers,
        population_control_every=variant.population_control_every,
        backpropagation_time=variant.backpropagation_time,
    ) for variant in plan.dimer_convergence_variants for seed in plan.dimer_seeds]
end

function _doped_open_requests(plan)
    dtau = minimum(plan.open_dtaus)
    free_trial = first(plan.doped_open_trials)
    requests = [(
        variant="baseline",
        dtau=dtau,
        trial=free_trial,
        base_seed=seed,
        measurement_count=plan.open_measurements,
        backpropagation_time=plan.doped_open_backpropagation_time,
        population_control_every=plan.doped_open_population_control_every,
    ) for seed in plan.doped_open_seeds]
    plan.profile == :quick && return requests

    first_seed = first(plan.doped_open_seeds)
    for trial in plan.doped_open_trials[2:end]
        push!(requests, (
            variant=trial.label,
            dtau=dtau,
            trial=trial,
            base_seed=first_seed,
            measurement_count=plan.open_measurements,
            backpropagation_time=plan.doped_open_backpropagation_time,
            population_control_every=plan.doped_open_population_control_every,
        ))
    end
    for seed in plan.doped_open_seeds
        push!(requests, (
            variant="backprop4",
            dtau=dtau,
            trial=free_trial,
            base_seed=seed,
            measurement_count=plan.doped_open_long_measurements,
            backpropagation_time=plan.doped_open_long_backpropagation_time,
            population_control_every=plan.doped_open_population_control_every,
        ))
        push!(requests, (
            variant="population10",
            dtau=dtau,
            trial=free_trial,
            base_seed=seed,
            measurement_count=plan.open_measurements,
            backpropagation_time=plan.doped_open_backpropagation_time,
            population_control_every=10,
        ))
    end
    return requests
end

function _cp_controls(
    plan,
    family::Symbol,
    dtau,
    seed;
    backpropagation=true,
    walker_count=nothing,
    projection_time=nothing,
    measurement_count=nothing,
    backpropagation_time=nothing,
    population_control_every=nothing,
    error_block_size=nothing,
)
    walkers = isnothing(walker_count) ?
        getproperty(plan, Symbol(family, :_walkers)) : Int(walker_count)
    warmup_time = isnothing(projection_time) ?
        getproperty(plan, Symbol(family, :_projection_time)) : projection_time
    warmup = _steps_for_time(
        warmup_time, dtau,
    )
    measurements = isnothing(measurement_count) ?
        getproperty(plan, Symbol(family, :_measurements)) : Int(measurement_count)
    separation = _steps_for_time(
        getproperty(plan, Symbol(family, :_measurement_spacing)), dtau,
    )
    backpropagation_time_value = isnothing(backpropagation_time) ?
        getproperty(plan, Symbol(family, :_backpropagation_time)) :
        backpropagation_time
    backpropagation_steps = backpropagation ?
        _steps_for_time(backpropagation_time_value, dtau) : 0
    population_interval = isnothing(population_control_every) ?
        getproperty(plan, Symbol(family, :_population_control_every)) :
        Int(population_control_every)
    block_size = isnothing(error_block_size) ?
        getproperty(plan, Symbol(family, :_block_size)) : Int(error_block_size)
    return CPAFQMCParameters(
        dtau=dtau,
        walker_count=walkers,
        warmup_steps=warmup,
        measurement_count=measurements,
        steps_between_measurements=separation,
        orthogonalize_every=5,
        population_control_every=population_interval,
        overlap_refresh_every=16,
        back_propagation_steps=backpropagation_steps,
        minimum_backprop_ancestors=2,
        error_block_size=block_size,
        seed=seed,
    )
end

function _record_cp_run!(runs, samples, checks, profile, run_id, system,
                         boundary, problem, controls, trial; variant="")
    start_time = time_ns()
    result = run_cp_afqmc(problem, controls; trial=trial)
    runtime = (time_ns() - start_time) / 1.0e9
    summary, diagnostics = result.summary, result.diagnostics
    push!(runs, _run_row(
        run_id=run_id,
        method="CP-AFQMC",
        system=system,
        boundary=boundary,
        U=problem.U,
        Nup=problem.Nup,
        Ndown=problem.Ndown,
        variant=variant,
        trial=result.trial_label,
        trial_pattern=diagnostics.trial_pattern,
        trial_field=diagnostics.trial_field_strength,
        trial_up_shell_gap=diagnostics.trial_up_shell_gap,
        trial_down_shell_gap=diagnostics.trial_down_shell_gap,
        dtau=controls.dtau,
        seed=controls.seed,
        walkers=controls.walker_count,
        warmup_steps=controls.warmup_steps,
        planned_warmup_time=controls.warmup_steps * controls.dtau,
        measurement_count=controls.measurement_count,
        steps_between_measurements=controls.steps_between_measurements,
        backpropagation_steps=controls.back_propagation_steps,
        population_control_every=controls.population_control_every,
        population_controls=diagnostics.population_controls,
        orthogonalize_every=controls.orthogonalize_every,
        overlap_refresh_every=controls.overlap_refresh_every,
        block_size=controls.error_block_size,
        projection_time=diagnostics.projection_time,
        total_projection_time=diagnostics.projection_time,
        runtime_seconds=runtime,
        energy=summary.energy,
        energy_standard_error=summary.energy_standard_error,
        mixed_kinetic_energy=summary.mixed_kinetic_energy,
        mixed_kinetic_energy_standard_error=
            summary.mixed_kinetic_energy_standard_error,
        mixed_interaction_energy=summary.mixed_interaction_energy,
        mixed_interaction_energy_standard_error=
            summary.mixed_interaction_energy_standard_error,
        mixed_double_per_cell=summary.mixed_double_occupancy_per_cell,
        mixed_double_per_cell_standard_error=
            summary.mixed_double_occupancy_standard_error,
        backpropagated_energy=summary.backpropagated_energy,
        backpropagated_energy_standard_error=
            summary.backpropagated_energy_standard_error,
        backpropagated_kinetic_energy=summary.backpropagated_kinetic_energy,
        backpropagated_kinetic_energy_standard_error=
            summary.backpropagated_kinetic_energy_standard_error,
        backpropagated_interaction_energy=
            summary.backpropagated_interaction_energy,
        backpropagated_interaction_energy_standard_error=
            summary.backpropagated_interaction_energy_standard_error,
        backpropagated_double_per_cell=
            summary.backpropagated_double_occupancy_per_cell,
        backpropagated_double_per_cell_standard_error=
            summary.backpropagated_double_occupancy_standard_error,
        S_alm_q0=summary.S_alm_q0,
        S_alm_q0_standard_error=summary.S_alm_q0_standard_error,
        S_fm_q0=summary.S_fm_q0,
        S_fm_q0_standard_error=summary.S_fm_q0_standard_error,
        density=summary.density,
        constraint_rejections=diagnostics.constraint_rejections,
        killed_walkers=diagnostics.killed_walkers,
        overlap_inverse_failures=diagnostics.overlap_inverse_failures,
        minimum_backprop_ancestors=
            diagnostics.minimum_distinct_backprop_ancestors,
    ))
    for (sample_index, measurement) in enumerate(result.measurements)
        push!(samples, _sample_row(
            run_id=run_id,
            sample=sample_index,
            step=measurement.step,
            mixed_energy=measurement.mixed_total_energy,
            mixed_kinetic_energy=measurement.mixed_kinetic_energy,
            mixed_interaction_energy=measurement.mixed_interaction_energy,
            mixed_double_per_cell=measurement.mixed_double_occupancy_per_cell,
            backpropagated_energy=measurement.backpropagated_total_energy,
            backpropagated_kinetic_energy=
                measurement.backpropagated_kinetic_energy,
            backpropagated_interaction_energy=
                measurement.backpropagated_interaction_energy,
            backpropagated_double_per_cell=
                measurement.backpropagated_double_occupancy_per_cell,
            S_alm_q0=measurement.S_alm_q0,
            S_fm_q0=measurement.S_fm_q0,
            distinct_backprop_ancestors=
                measurement.distinct_backprop_ancestors,
        ))
    end
    finite_summary = isfinite(summary.energy) &&
        isfinite(summary.mixed_double_occupancy_per_cell)
    ancestry_ok = controls.back_propagation_steps == 0 ||
        (!ismissing(diagnostics.minimum_distinct_backprop_ancestors) &&
         diagnostics.minimum_distinct_backprop_ancestors >=
            controls.minimum_backprop_ancestors)
    imaginary_ok = controls.back_propagation_steps == 0 ||
        isnothing(problem.lattice_size) ||
        (!ismissing(diagnostics.maximum_spin_structure_imaginary_part) &&
         diagnostics.maximum_spin_structure_imaginary_part <= 1.0e-9)
    health = finite_summary &&
        diagnostics.final_live_walkers == controls.walker_count &&
        diagnostics.overlap_inverse_failures == 0 && ancestry_ok && imaginary_ok
    _boolean_check!(checks;
        value=health,
        check_id=run_id * ":health",
        stage="cp_run_health",
        profile=profile,
        system=system,
        boundary=boundary,
        method="CP-AFQMC",
        quantity="finite_stable_live_population",
        U=problem.U,
        Nup=problem.Nup,
        Ndown=problem.Ndown,
        trial=result.trial_label,
        dtau=controls.dtau,
        seed=controls.seed,
        note="requires finite estimators, full live population, no overlap inverse " *
             "failure, adequate BP ancestry, and real spin structure",
    )
    return result
end

function _failed_run!(runs, checks, profile, run_id, method, system, boundary,
                      error; U=missing, Nup=missing, Ndown=missing, trial="",
                      dtau=missing, seed=missing, variant="", controls=nothing)
    message = sprint(showerror, error)
    push!(runs, _run_row(
        run_id=run_id, method=method, system=system, boundary=boundary,
        status="error", U=U, Nup=Nup, Ndown=Ndown, trial=trial,
        variant=variant, dtau=dtau, seed=seed,
        walkers=isnothing(controls) ? missing : controls.walker_count,
        warmup_steps=isnothing(controls) ? missing : controls.warmup_steps,
        planned_warmup_time=isnothing(controls) ? missing :
            controls.warmup_steps * controls.dtau,
        measurement_count=isnothing(controls) ? missing :
            controls.measurement_count,
        steps_between_measurements=isnothing(controls) ? missing :
            controls.steps_between_measurements,
        backpropagation_steps=isnothing(controls) ? missing :
            controls.back_propagation_steps,
        population_control_every=isnothing(controls) ? missing :
            controls.population_control_every,
        orthogonalize_every=isnothing(controls) ? missing :
            controls.orthogonalize_every,
        overlap_refresh_every=isnothing(controls) ? missing :
            controls.overlap_refresh_every,
        block_size=isnothing(controls) ? missing : controls.error_block_size,
        note=message,
    ))
    _error_check!(checks, profile, "stochastic_run", system, method, error;
                  boundary=boundary, check_id=run_id * ":completed")
    return nothing
end

function _sample_standard_error(values)
    count = length(values)
    count < 2 && return missing
    center = sum(values) / count
    return sqrt(sum((value - center)^2 for value in values) /
                (count * (count - 1)))
end

function _pool_independent_estimates(values, standard_errors)
    count = length(values)
    count > 0 || throw(ArgumentError("cannot pool zero estimates"))
    length(standard_errors) == count || throw(DimensionMismatch(
        "values and standard_errors must have equal length",
    ))
    all(value -> value isa Real && isfinite(value), values) ||
        throw(ArgumentError("pooled estimates must be finite real numbers"))
    all(error -> error isa Real && isfinite(error) && error >= 0,
        standard_errors) || throw(ArgumentError(
        "pooled standard errors must be finite and nonnegative",
    ))
    estimates = Float64.(values)
    errors = Float64.(standard_errors)
    center = sum(estimates) / count
    within_chain_error = sqrt(sum(abs2, errors)) / count
    between_seed_error = count < 2 ? 0.0 : _sample_standard_error(estimates)
    return (
        mean=center,
        standard_error=max(within_chain_error, between_seed_error),
        within_chain_standard_error=within_chain_error,
        between_seed_standard_error=between_seed_error,
        count=count,
    )
end

const CP_VALIDATION_QUANTITIES = (
    :energy,
    :backpropagated_kinetic_energy,
    :backpropagated_interaction_energy,
    :backpropagated_double_occupancy_per_cell,
    :S_alm_q0,
)

function _cp_summary_quantity(summary, quantity::Symbol)
    error_name = if quantity == :backpropagated_double_occupancy_per_cell
        :backpropagated_double_occupancy_standard_error
    else
        Symbol(quantity, :_standard_error)
    end
    hasproperty(summary, quantity) || throw(ArgumentError(
        "CP summary has no quantity $quantity",
    ))
    hasproperty(summary, error_name) || throw(ArgumentError(
        "CP summary has no standard error for $quantity",
    ))
    estimate = getproperty(summary, quantity)
    standard_error = getproperty(summary, error_name)
    estimate isa Real && isfinite(estimate) || throw(ArgumentError(
        "CP estimate $quantity must be a finite real number",
    ))
    standard_error isa Real && isfinite(standard_error) && standard_error >= 0 ||
        throw(ArgumentError(
            "CP standard error for $quantity must be finite and nonnegative",
        ))
    return (estimate=Float64(estimate), standard_error=Float64(standard_error))
end

function _pool_cp_records(records, quantity::Symbol)
    isempty(records) && throw(ArgumentError("cannot pool zero CP records"))
    values = Float64[]
    errors = Float64[]
    for record in records
        value = _cp_summary_quantity(record.summary, quantity)
        push!(values, value.estimate)
        push!(errors, value.standard_error)
    end
    return _pool_independent_estimates(values, errors)
end

function _cp_measurement_value(measurement, quantity::Symbol)
    field = if quantity == :energy
        :mixed_total_energy
    elseif quantity == :backpropagated_kinetic_energy
        :backpropagated_kinetic_energy
    elseif quantity == :backpropagated_interaction_energy
        :backpropagated_interaction_energy
    elseif quantity == :backpropagated_double_occupancy_per_cell
        :backpropagated_double_occupancy_per_cell
    elseif quantity == :S_alm_q0
        :S_alm_q0
    else
        throw(ArgumentError(
            "CP measurements have no paired value for $quantity",
        ))
    end
    hasproperty(measurement, field) || throw(ArgumentError(
        "CP measurement has no field $field",
    ))
    value = getproperty(measurement, field)
    value isa Real && isfinite(value) || throw(ArgumentError(
        "paired CP measurement $field must be finite and real",
    ))
    return Float64(value)
end

function _paired_cp_block_shift(first_record, second_record, quantity::Symbol)
    all(record -> hasproperty(record, :measurements) &&
        hasproperty(record, :block_size), (first_record, second_record)) ||
        throw(ArgumentError(
            "paired CP records require measurements and block_size",
        ))
    block_size = Int(first_record.block_size)
    block_size == Int(second_record.block_size) || throw(ArgumentError(
        "paired CP records must use the same block size",
    ))
    block_size > 0 || throw(ArgumentError(
        "paired CP block size must be positive",
    ))
    count = min(
        length(first_record.measurements),
        length(second_record.measurements),
    )
    count >= 2 * block_size && count % block_size == 0 ||
        throw(ArgumentError(
            "paired CP measurement count must contain whole blocks and at " *
            "least two blocks",
        ))
    differences = Vector{Float64}(undef, count)
    for index in 1:count
        first_measurement = first_record.measurements[index]
        second_measurement = second_record.measurements[index]
        first_measurement.step == second_measurement.step || throw(
            ArgumentError("paired CP measurements must have matching steps"),
        )
        differences[index] =
            _cp_measurement_value(first_measurement, quantity) -
            _cp_measurement_value(second_measurement, quantity)
    end
    block_count = div(count, block_size)
    block_means = [
        sum(@view differences[
            ((block - 1) * block_size + 1):(block * block_size)
        ]) / block_size for block in 1:block_count
    ]
    center = sum(differences) / count
    block_center = sum(block_means) / block_count
    deviations = sum(abs2(value - block_center) for value in block_means)
    return (
        mean=center,
        standard_error=sqrt(deviations / (block_count * (block_count - 1))),
        measurement_count=count,
        block_count=block_count,
    )
end

function _matched_cp_seed_shift(
    first_records,
    second_records,
    expected_seeds,
    quantity::Symbol,
    ;
    paired_measurements=false,
)
    expected = sort!(Int[seed for seed in expected_seeds])
    isempty(expected) && throw(ArgumentError("expected_seeds must not be empty"))
    length(unique(expected)) == length(expected) || throw(ArgumentError(
        "expected_seeds must be distinct",
    ))
    first_by_seed = Dict(record.seed => record for record in first_records)
    second_by_seed = Dict(record.seed => record for record in second_records)
    complete = length(first_by_seed) == length(first_records) &&
        length(second_by_seed) == length(second_records) &&
        sort!(collect(keys(first_by_seed))) == expected &&
        sort!(collect(keys(second_by_seed))) == expected
    complete || return (
        complete=false,
        expected_seeds=Tuple(expected),
        first_seeds=Tuple(sort!(collect(keys(first_by_seed)))),
        second_seeds=Tuple(sort!(collect(keys(second_by_seed)))),
        pool=nothing,
        paired_measurements=paired_measurements,
    )

    differences = Float64[]
    errors = Float64[]
    for seed in expected
        if paired_measurements
            difference = _paired_cp_block_shift(
                first_by_seed[seed], second_by_seed[seed], quantity,
            )
            push!(differences, difference.mean)
            push!(errors, difference.standard_error)
        else
            first_value = _cp_summary_quantity(
                first_by_seed[seed].summary, quantity,
            )
            second_value = _cp_summary_quantity(
                second_by_seed[seed].summary, quantity,
            )
            difference = _difference_with_error(
                first_value.estimate,
                first_value.standard_error,
                second_value.estimate,
                second_value.standard_error,
            )
            push!(differences, difference.difference)
            push!(errors, difference.standard_error)
        end
    end
    return (
        complete=true,
        expected_seeds=Tuple(expected),
        first_seeds=Tuple(expected),
        second_seeds=Tuple(expected),
        pool=_pool_independent_estimates(differences, errors),
        paired_measurements=paired_measurements,
    )
end

function _matched_cp_measurement_identity(
    first_records,
    second_records,
    expected_seeds,
    quantity::Symbol,
)
    expected = sort!(Int[seed for seed in expected_seeds])
    first_by_seed = Dict(record.seed => record for record in first_records)
    second_by_seed = Dict(record.seed => record for record in second_records)
    complete = !isempty(expected) && length(unique(expected)) == length(expected) &&
        length(first_by_seed) == length(first_records) &&
        length(second_by_seed) == length(second_records) &&
        sort!(collect(keys(first_by_seed))) == expected &&
        sort!(collect(keys(second_by_seed))) == expected
    complete || return (complete=false, identical=false, compared=0)

    compared = 0
    identical = true
    for seed in expected
        first_measurements = first_by_seed[seed].measurements
        second_measurements = second_by_seed[seed].measurements
        count = min(length(first_measurements), length(second_measurements))
        count > 0 || return (complete=false, identical=false, compared=compared)
        for index in 1:count
            first_measurement = first_measurements[index]
            second_measurement = second_measurements[index]
            if first_measurement.step != second_measurement.step ||
               _cp_measurement_value(first_measurement, quantity) !=
                   _cp_measurement_value(second_measurement, quantity)
                identical = false
            end
            compared += 1
        end
    end
    return (complete=true, identical=identical, compared=compared)
end

function _finite_positive_ratio(values)
    isempty(values) && throw(ArgumentError("ratio requires at least one value"))
    all(value -> value isa Real, values) || throw(ArgumentError(
        "ratio values must be real numbers",
    ))
    converted = Float64.(values)
    valid = all(value -> isfinite(value) && value > 0, converted)
    return (
        valid=valid,
        ratio=valid ? maximum(converted) / minimum(converted) : Inf,
        minimum=valid ? minimum(converted) : missing,
        maximum=valid ? maximum(converted) : missing,
    )
end

function _difference_with_error(first_value, first_error, second_value, second_error)
    all(value -> value isa Real && isfinite(value),
        (first_value, second_value)) || throw(ArgumentError(
        "difference estimates must be finite real numbers",
    ))
    all(error -> error isa Real && isfinite(error) && error >= 0,
        (first_error, second_error)) || throw(ArgumentError(
        "difference standard errors must be finite and nonnegative",
    ))
    difference = Float64(first_value) - Float64(second_value)
    return (
        difference=difference,
        absolute_difference=abs(difference),
        standard_error=hypot(Float64(first_error), Float64(second_error)),
    )
end

function _strict_consistency_check!(
    checks;
    estimate,
    reference,
    standard_error,
    absolute_cap,
    sigma,
    precision_ceiling,
    kwargs...,
)
    cap = Float64(absolute_cap)
    multiplier = Float64(sigma)
    ceiling = Float64(precision_ceiling)
    isfinite(cap) && cap >= 0 || throw(ArgumentError(
        "absolute_cap must be finite and nonnegative",
    ))
    isfinite(multiplier) && multiplier >= 0 || throw(ArgumentError(
        "sigma must be finite and nonnegative",
    ))
    isfinite(ceiling) && ceiling > 0 || throw(ArgumentError(
        "precision_ceiling must be finite and positive",
    ))
    usable = estimate isa Real && reference isa Real &&
        isfinite(estimate) && isfinite(reference)
    usable_error = standard_error isa Real && isfinite(standard_error) &&
        standard_error > 0
    error = usable ? abs(Float64(estimate) - Float64(reference)) : missing
    allowed = usable_error ? min(cap, multiplier * Float64(standard_error)) : 0.0
    comparison_passed = usable && usable_error && error <= allowed
    comparison = _check_row(
        ; kwargs...,
        estimate=estimate,
        standard_error=standard_error,
        reference=reference,
        absolute_error=error,
        allowed_error=allowed,
        passed=comparison_passed,
    )
    push!(checks, comparison)

    precision_error = usable_error ? Float64(standard_error) : missing
    precision_passed = usable_error && precision_error <= ceiling
    push!(checks, merge(comparison, (
        check_id=comparison.check_id * ":precision",
        quantity=comparison.quantity * "_combined_standard_error",
        estimate=standard_error,
        standard_error=missing,
        reference=0.0,
        absolute_error=precision_error,
        allowed_error=ceiling,
        passed=precision_passed,
        note=comparison.note *
            "; a finite strictly positive combined error must also be at most " *
            string(ceiling),
    )))
    return comparison_passed && precision_passed
end

function _statistical_consistency_check!(
    checks;
    estimate,
    reference,
    standard_error,
    sigma,
    precision_ceiling,
    kwargs...,
)
    multiplier = Float64(sigma)
    ceiling = Float64(precision_ceiling)
    isfinite(multiplier) && multiplier > 0 || throw(ArgumentError(
        "sigma must be finite and positive",
    ))
    isfinite(ceiling) && ceiling > 0 || throw(ArgumentError(
        "precision_ceiling must be finite and positive",
    ))
    usable = estimate isa Real && reference isa Real &&
        isfinite(estimate) && isfinite(reference)
    usable_error = standard_error isa Real && isfinite(standard_error) &&
        standard_error > 0
    error = usable ? abs(Float64(estimate) - Float64(reference)) : missing
    allowed = usable_error ? multiplier * Float64(standard_error) : 0.0
    comparison_passed = usable && usable_error && error <= allowed
    comparison = _check_row(
        ; kwargs...,
        estimate=estimate,
        standard_error=standard_error,
        reference=reference,
        absolute_error=error,
        allowed_error=allowed,
        passed=comparison_passed,
    )
    push!(checks, comparison)

    precision_error = usable_error ? Float64(standard_error) : missing
    precision_passed = usable_error && precision_error <= ceiling
    push!(checks, merge(comparison, (
        check_id=comparison.check_id * ":precision",
        quantity=comparison.quantity * "_combined_standard_error",
        estimate=standard_error,
        standard_error=missing,
        reference=0.0,
        absolute_error=precision_error,
        allowed_error=ceiling,
        passed=precision_passed,
        note=comparison.note *
            "; a finite strictly positive combined error must also be at most " *
            string(ceiling),
    )))
    return comparison_passed && precision_passed
end

function _doped_open_quantity_specs(profile, exact)
    caps = profile == :quick ? (
        energy=0.08,
        kinetic=0.20,
        interaction=0.12,
        double=0.03,
        spin=0.08,
    ) : (
        energy=0.02,
        kinetic=0.06,
        interaction=0.03,
        double=0.005,
        spin=0.01,
    )
    return (
        (quantity=:energy, label="mixed_total_energy",
         reference=exact.energy, cap=caps.energy),
        (quantity=:backpropagated_kinetic_energy,
         label="backpropagated_kinetic_energy",
         reference=exact.kinetic_energy, cap=caps.kinetic),
        (quantity=:backpropagated_interaction_energy,
         label="backpropagated_centered_interaction_energy",
         reference=exact.centered_interaction_energy, cap=caps.interaction),
        (quantity=:backpropagated_double_occupancy_per_cell,
         label="backpropagated_double_occupancy_per_cell",
         reference=exact.double_occupancy / 4, cap=caps.double),
        (quantity=:S_alm_q0, label="backpropagated_S_alm_q0",
         reference=exact.oalm2 / 4, cap=caps.spin),
    )
end

function _add_cp_pool_exact_checks!(
    checks,
    profile,
    check_prefix,
    records,
    exact;
    trial,
    note,
)
    pools = Dict{Symbol,Any}()
    for spec in _doped_open_quantity_specs(profile, exact)
        pool = _pool_cp_records(records, spec.quantity)
        pools[spec.quantity] = pool
        _numeric_check!(checks;
            check_id=check_prefix * ":" * spec.label,
            stage="cp_open_doped_vs_ed",
            profile=profile,
            system="open_2x2_two_orbital_doped_N6",
            boundary="open",
            method="CP-AFQMC",
            quantity=spec.label,
            U=2.0,
            Nup=3,
            Ndown=3,
            trial=trial,
            estimate=pool.mean,
            standard_error=pool.standard_error,
            reference=spec.reference,
            floor=spec.cap,
            sigma=0.0,
            precision_ceiling=spec.cap / 2,
            note=note * "; fixed absolute cap independent of sigma; error " *
                 "is the larger of the propagated within-chain error and the " *
                 "standard error across seed means",
        )
    end
    return pools
end

function _add_cp_shift_checks!(
    checks,
    profile,
    check_prefix,
    first_records,
    second_records,
    expected_seeds,
    specs;
    system,
    U,
    Nup,
    Ndown,
    note,
    paired_measurements=false,
)
    for spec in specs
        shift = _matched_cp_seed_shift(
            first_records, second_records, expected_seeds, spec.quantity,
            ; paired_measurements=paired_measurements,
        )
        _boolean_check!(checks;
            value=shift.complete,
            check_id=check_prefix * ":" * spec.label * ":seed_grid",
            stage="cp_convergence_summary",
            profile=profile,
            system=system,
            boundary="open",
            method="CP-AFQMC",
            quantity=spec.label * "_matched_seed_grid_complete",
            U=U,
            Nup=Nup,
            Ndown=Ndown,
            note=note * "; expected seeds=" * join(expected_seeds, ';'),
        )
        shift.complete || continue
        _strict_consistency_check!(checks;
            check_id=check_prefix * ":" * spec.label,
            stage="cp_convergence_summary",
            profile=profile,
            system=system,
            boundary="open",
            method="CP-AFQMC",
            quantity=spec.label * "_pooled_shift",
            U=U,
            Nup=Nup,
            Ndown=Ndown,
            estimate=shift.pool.mean,
            reference=0.0,
            standard_error=shift.pool.standard_error,
            absolute_cap=spec.cap,
            sigma=5.0,
            precision_ceiling=spec.cap / 2,
            note=note * (paired_measurements ?
                 "; matching measurement blocks are differenced before their " *
                 "errors are estimated" :
                 "; independent within-chain errors are combined by hypot") *
                 "; the pool uses the larger of its within-chain and " *
                 "across-seed error estimates; " *
                 "both sigma and absolute caps apply",
        )
    end
    return nothing
end


function _summary_quantity(summary, quantity::Symbol)
    estimate_name = quantity
    error_name = Symbol(quantity, :_standard_error)
    validity_name = Symbol(quantity, :_jackknife_valid)
    estimate = getproperty(summary, estimate_name)
    standard_error = getproperty(summary, error_name)
    valid = summary.denominator_guard_passed &&
        getproperty(summary, validity_name) &&
        estimate isa Real && isfinite(estimate) &&
        standard_error isa Real && isfinite(standard_error) &&
        standard_error >= 0
    return (
        valid=valid,
        estimate=estimate,
        standard_error=standard_error,
    )
end

function _sign_reweighted_half_drift(
    signs,
    observations,
    quantity::Symbol;
    block_size::Integer,
    minimum_absolute_average_sign::Real=0.02,
    minimum_sign_effective_count::Real=0.0,
)
    count = length(signs)
    block_size > 0 || throw(ArgumentError("block_size must be positive"))
    length(observations) == count || throw(DimensionMismatch(
        "signs and observations must have equal length",
    ))
    iseven(count) && count >= 4 * block_size || throw(ArgumentError(
        "half-drift input must split into two halves with at least two blocks each",
    ))
    half = div(count, 2)
    half % block_size == 0 || throw(ArgumentError(
        "block_size must divide each half of the drift input",
    ))
    minimum_effective_count = Float64(minimum_sign_effective_count)
    isfinite(minimum_effective_count) && minimum_effective_count >= 0 ||
        throw(ArgumentError(
            "minimum_sign_effective_count must be finite and nonnegative",
        ))
    first_summary = summarize_sign_reweighted_thermodynamics(
        @view(signs[1:half]),
        @view(observations[1:half]);
        block_size=block_size,
        minimum_absolute_average_sign=minimum_absolute_average_sign,
    )
    second_summary = summarize_sign_reweighted_thermodynamics(
        @view(signs[(half + 1):count]),
        @view(observations[(half + 1):count]);
        block_size=block_size,
        minimum_absolute_average_sign=minimum_absolute_average_sign,
    )
    first_statistic = _summary_quantity(first_summary, quantity)
    second_statistic = _summary_quantity(second_summary, quantity)
    first_effective_count = half * first_summary.average_sign^2
    second_effective_count = half * second_summary.average_sign^2
    valid = first_statistic.valid && second_statistic.valid &&
        isfinite(first_effective_count) && isfinite(second_effective_count) &&
        first_effective_count >= minimum_effective_count &&
        second_effective_count >= minimum_effective_count
    difference = if valid
        _difference_with_error(
            first_statistic.estimate,
            first_statistic.standard_error,
            second_statistic.estimate,
            second_statistic.standard_error,
        )
    else
        (difference=missing, absolute_difference=missing, standard_error=missing)
    end
    return merge((
        valid=valid,
        quantity=quantity,
        first_estimate=first_statistic.estimate,
        first_standard_error=first_statistic.standard_error,
        second_estimate=second_statistic.estimate,
        second_standard_error=second_statistic.standard_error,
        first_average_sign=first_summary.average_sign,
        second_average_sign=second_summary.average_sign,
        first_sign_effective_count=first_effective_count,
        second_sign_effective_count=second_effective_count,
        minimum_sign_effective_count=minimum_effective_count,
        samples_per_half=half,
        block_size=Int(block_size),
    ), difference)
end

function _sign_reweighted_block_error_scan(
    signs,
    observations,
    quantity::Symbol,
    block_sizes;
    minimum_absolute_average_sign::Real=0.02,
)
    count = length(signs)
    length(observations) == count || throw(DimensionMismatch(
        "signs and observations must have equal length",
    ))
    sizes = Int.(collect(block_sizes))
    !isempty(sizes) && all(>(0), sizes) || throw(ArgumentError(
        "block sizes must be nonempty and positive",
    ))
    length(unique(sizes)) == length(sizes) || throw(ArgumentError(
        "block sizes must be distinct",
    ))
    all(size -> count % size == 0 && div(count, size) >= 2, sizes) ||
        throw(ArgumentError(
            "every block size must divide the samples and leave at least two blocks",
        ))
    errors = Float64[]
    estimates = Float64[]
    summaries_valid = true
    for block_size in sizes
        summary = summarize_sign_reweighted_thermodynamics(
            signs,
            observations;
            block_size=block_size,
            minimum_absolute_average_sign=minimum_absolute_average_sign,
        )
        statistic = _summary_quantity(summary, quantity)
        summaries_valid &= statistic.valid
        push!(errors, statistic.valid ? Float64(statistic.standard_error) : NaN)
        push!(estimates, statistic.valid ? Float64(statistic.estimate) : NaN)
    end
    ratio = _finite_positive_ratio(errors)
    estimate_scale = all(isfinite, estimates) ?
        max(1.0, maximum(abs, estimates)) : 1.0
    positive_error_floor = 100 * eps(Float64) * estimate_scale
    errors_above_floor = all(error -> isfinite(error) &&
        error > positive_error_floor, errors)
    central_spread = all(isfinite, estimates) ?
        maximum(estimates) - minimum(estimates) : Inf
    return (
        valid=summaries_valid && ratio.valid && errors_above_floor,
        quantity=quantity,
        block_sizes=sizes,
        estimates=estimates,
        standard_errors=errors,
        ratio=ratio.ratio,
        minimum_standard_error=ratio.minimum,
        maximum_standard_error=ratio.maximum,
        positive_error_floor=positive_error_floor,
        central_spread=central_spread,
        central_tolerance=100 * eps(Float64) * estimate_scale,
    )
end

function _weighted_dtau_squared_fit(dtaus, values, standard_errors)
    count = length(dtaus)
    count >= 3 || throw(ArgumentError(
        "dtau-squared extrapolation requires at least three points",
    ))
    length(values) == count && length(standard_errors) == count ||
        throw(DimensionMismatch(
            "dtaus, values, and standard_errors must have equal length",
        ))
    all(dtau -> dtau isa Real && isfinite(dtau) && dtau > 0, dtaus) ||
        throw(ArgumentError("dtaus must be finite and positive"))
    all(value -> value isa Real && isfinite(value), values) ||
        throw(ArgumentError("fit values must be finite real numbers"))
    all(error -> error isa Real && isfinite(error) && error > 0,
        standard_errors) || throw(ArgumentError(
        "fit standard errors must be finite and strictly positive",
    ))
    x = abs2.(Float64.(dtaus))
    length(unique(x)) == count || throw(ArgumentError(
        "dtau-squared fit points must be distinct",
    ))
    y = Float64.(values)
    errors = Float64.(standard_errors)
    minimum_error = 100 * eps(Float64) * max(1.0, maximum(abs, y))
    all(error -> error > minimum_error, errors) || throw(ArgumentError(
        "fit standard errors are too small to define finite weights",
    ))
    weights = inv.(abs2.(errors))
    weight_sum = sum(weights)
    x_center = sum(weights .* x) / weight_sum
    y_center = sum(weights .* y) / weight_sum
    centered_x_sum = sum(weights .* abs2.(x .- x_center))
    isfinite(weight_sum) && weight_sum > 0 &&
        isfinite(centered_x_sum) && centered_x_sum > 0 || throw(ArgumentError(
        "dtau-squared fit has a singular weighted design matrix",
    ))
    slope = sum(weights .* (x .- x_center) .* (y .- y_center)) /
        centered_x_sum
    intercept = y_center - slope * x_center
    residuals = y .- (intercept .+ slope .* x)
    chi_squared = sum(weights .* abs2.(residuals))
    degrees_of_freedom = count - 2
    reduced_chi_squared = chi_squared / degrees_of_freedom
    variance_scale = max(1.0, reduced_chi_squared)
    intercept_variance = variance_scale *
        (inv(weight_sum) + x_center^2 / centered_x_sum)
    slope_variance = variance_scale / centered_x_sum
    covariance = -variance_scale * x_center / centered_x_sum
    return (
        intercept=intercept,
        intercept_standard_error=sqrt(intercept_variance),
        slope=slope,
        slope_standard_error=sqrt(slope_variance),
        intercept_slope_covariance=covariance,
        chi_squared=chi_squared,
        degrees_of_freedom=degrees_of_freedom,
        reduced_chi_squared=reduced_chi_squared,
        variance_scale=variance_scale,
        minimum_standard_error=minimum_error,
        point_count=count,
    )
end

function _add_cp_comparison!(checks, profile, run_id, result, reference;
                             system, boundary, energy_floor, double_floor,
                             spin_reference=missing, spin_floor=0.0)
    summary = result.summary
    common = (
        stage="cp_vs_ed",
        profile=profile,
        system=system,
        boundary=boundary,
        method="CP-AFQMC",
        U=result.problem.U,
        Nup=result.problem.Nup,
        Ndown=result.problem.Ndown,
        trial=result.trial_label,
        dtau=result.parameters.dtau,
        seed=result.parameters.seed,
    )
    _numeric_check!(checks;
        common...,
        check_id=run_id * ":energy",
        quantity="mixed_total_energy",
        estimate=summary.energy,
        standard_error=summary.energy_standard_error,
        reference=reference.energy,
        floor=energy_floor,
        sigma=profile == :quick ? 6.0 : 0.0,
        precision_ceiling=energy_floor / 2,
        note=profile == :quick ?
            "quick smoke comparison with sigma-expanded tolerance" :
            "standard comparison uses a fixed absolute cap independent of sigma",
    )
    if !ismissing(reference.double_per_cell) &&
       !ismissing(summary.backpropagated_double_occupancy_per_cell)
        _numeric_check!(checks;
            common...,
            check_id=run_id * ":double",
            quantity="backpropagated_double_occupancy_per_cell",
            estimate=summary.backpropagated_double_occupancy_per_cell,
            standard_error=
                summary.backpropagated_double_occupancy_standard_error,
            reference=reference.double_per_cell,
            floor=double_floor,
            sigma=profile == :quick ? 6.0 : 0.0,
            precision_ceiling=double_floor / 2,
            note=(profile == :quick ?
                "quick smoke comparison; " :
                "standard fixed absolute cap; ") *
                "pure estimator; mixed double occupancy is not used",
        )
    end
    if !ismissing(spin_reference) && !ismissing(summary.S_alm_q0)
        _numeric_check!(checks;
            common...,
            check_id=run_id * ":S_alm_q0",
            quantity="backpropagated_S_alm_q0",
            estimate=summary.S_alm_q0,
            standard_error=summary.S_alm_q0_standard_error,
            reference=spin_reference,
            floor=spin_floor,
            sigma=profile == :quick ? 6.0 : 0.0,
            precision_ceiling=spin_floor / 2,
            note=(profile == :quick ?
                "quick smoke comparison; " :
                "standard fixed absolute cap; ") *
                "S_alm(0)=<O_alm^2>/Ncell",
        )
    end
    return nothing
end

function exact_thermal_bridge()
    point = DQMC_BRIDGE_POINT
    exact = solve_two_orbital_cluster(
        point.U, point.mu, point.beta, [0.0]; include_full_spectrum=false,
    )
    first_levels, second_levels = exact.orbital_levels
    energy_shift = minimum(
        first.energy + second.energy
        for first in first_levels for second in second_levels
    )
    partition = 0.0
    target_sector_weight = 0.0
    for first in first_levels, second in second_levels
        weight = exp(-point.beta * (
            first.energy + second.energy - energy_shift
        ))
        partition += weight
        if first.Nup + second.Nup == point.Nup &&
           first.Ndown + second.Ndown == point.Ndown
            target_sector_weight += weight
        end
    end
    interaction = point.U * (
        exact.double_occupancy - exact.density / 2 + 0.5
    )
    internal = exact.grand_energy_per_cell + point.mu * exact.density
    kinetic = internal - interaction
    return (
        raw=exact,
        density=exact.density,
        doping=(exact.density - 2) / 4,
        kinetic_energy_per_cell=kinetic,
        shifted_interaction_energy_per_cell=interaction,
        internal_energy_per_cell=internal,
        grand_energy_per_cell=exact.grand_energy_per_cell,
        double_occupancy_per_cell=exact.double_occupancy,
        target_sector_probability=target_sector_weight / partition,
    )
end

function _run_dqmc!(runs, samples, checks, profile, plan, dtau, seed,
                    exact_thermal)
    point = DQMC_BRIDGE_POINT
    run_id = "dqmc_L2_U2_dt$(dtau)_seed$(seed)"
    parameters = DQMCParameters(
        L=point.L,
        beta=point.beta,
        dtau=dtau,
        U=point.U,
        mu=point.mu,
        stabilization_period=plan.dqmc_stabilization_period,
        burnin_sweeps=plan.dqmc_warmup_sweeps,
        measurement_sweeps=plan.dqmc_measurement_sweeps,
        sweeps_between_measurements=1,
        seed=seed,
    )
    start_time = time_ns()
    state = initialize_dqmc_state(parameters)
    for _ in 1:parameters.burnin_sweeps
        sweep_all_time_slices!(state)
    end
    signs = Vector{Float64}(undef, parameters.measurement_sweeps)
    observations = Vector{NamedTuple}(undef, parameters.measurement_sweeps)
    for measurement in 1:parameters.measurement_sweeps
        sweep_all_time_slices!(state)
        signs[measurement] =
            measure_basic_observables(state).configuration_sign
        observations[measurement] = measure_thermodynamic_observables(state)
        observation = observations[measurement]
        push!(samples, _sample_row(
            run_id=run_id,
            sample=measurement,
            sign=signs[measurement],
            density=observation.density,
            kinetic_energy_per_cell=observation.kinetic_energy_per_cell,
            interaction_energy_per_cell=
                observation.shifted_interaction_energy_per_cell,
            internal_energy_per_cell=observation.internal_energy_per_cell,
            grand_energy_per_cell=observation.grand_energy_per_cell,
        ))
    end
    recomputation = recompute_equal_time_greens!(state)
    runtime = (time_ns() - start_time) / 1.0e9
    summary = summarize_sign_reweighted_thermodynamics(
        signs,
        observations;
        block_size=plan.dqmc_block_size,
        minimum_absolute_average_sign=0.02,
    )
    consistency_energy_standard_error =
        summary.internal_energy_per_cell_standard_error
    if profile == :standard
        for (quantity, precision_ceiling) in (
            (:density, plan.dqmc_density_consistency_precision),
            (:internal_energy_per_cell,
             plan.dqmc_energy_consistency_precision),
        )
            drift = _sign_reweighted_half_drift(
                signs,
                observations,
                quantity;
                block_size=plan.dqmc_drift_block_size,
                minimum_absolute_average_sign=0.02,
                minimum_sign_effective_count=
                    plan.dqmc_minimum_sign_effective_count / 2,
            )
            _statistical_consistency_check!(checks;
                check_id=run_id * ":" * String(quantity) * "_half_drift",
                stage="dqmc_equilibration",
                profile=profile,
                system="periodic_L2_two_orbital",
                boundary="periodic",
                method="finite-temperature DQMC",
                quantity=String(quantity) * "_first_half_minus_second_half",
                U=point.U,
                beta=point.beta,
                mu=point.mu,
                dtau=dtau,
                seed=seed,
                estimate=drift.valid ? drift.difference : missing,
                standard_error=drift.valid ? drift.standard_error : missing,
                reference=0.0,
                sigma=plan.dqmc_random_difference_sigma,
                precision_ceiling=precision_ceiling,
                note="same post-burn chain split into two contiguous halves; " *
                     "each half is sign reweighted separately with " *
                     "$(plan.dqmc_drift_block_size)-sample leave-one-block-out " *
                     "jackknife errors, combined with hypot; each half must " *
                     "also have sign-effective count at least " *
                     string(plan.dqmc_minimum_sign_effective_count / 2) *
                     "; observed half counts=" *
                     string(drift.first_sign_effective_count) * "," *
                     string(drift.second_sign_effective_count),
            )
        end

        block_scan = _sign_reweighted_block_error_scan(
            signs,
            observations,
            :internal_energy_per_cell,
            plan.dqmc_block_stability_sizes;
            minimum_absolute_average_sign=0.02,
        )
        ratio_passed = block_scan.valid &&
            block_scan.ratio <= plan.dqmc_block_error_ratio_maximum
        push!(checks, _check_row(
            check_id=run_id * ":internal_energy_block_error_stability",
            stage="dqmc_autocorrelation",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="finite-temperature DQMC",
            quantity="internal_energy_block_error_max_to_min_ratio",
            U=point.U,
            beta=point.beta,
            mu=point.mu,
            dtau=dtau,
            seed=seed,
            estimate=block_scan.valid ? block_scan.ratio : missing,
            reference=1.0,
            absolute_error=block_scan.valid ? block_scan.ratio - 1.0 : missing,
            allowed_error=plan.dqmc_block_error_ratio_maximum - 1.0,
            passed=ratio_passed,
            required=true,
            note="block sizes=" * join(block_scan.block_sizes, ';') *
                 "; standard_errors=" * join(block_scan.standard_errors, ';') *
                 "; every error must be finite and strictly greater than " *
                 string(block_scan.positive_error_floor) *
                 ", then max(error)/min(error) must be at most " *
                 string(plan.dqmc_block_error_ratio_maximum) *
                 "; zero never passes",
        ))
        central_stable = all(isfinite, block_scan.estimates) &&
            block_scan.central_spread <= block_scan.central_tolerance
        push!(checks, _check_row(
            check_id=run_id * ":internal_energy_block_center_invariance",
            stage="dqmc_autocorrelation",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="finite-temperature DQMC",
            quantity="internal_energy_block_center_spread",
            U=point.U,
            beta=point.beta,
            mu=point.mu,
            dtau=dtau,
            seed=seed,
            estimate=block_scan.central_spread,
            reference=0.0,
            absolute_error=block_scan.central_spread,
            allowed_error=block_scan.central_tolerance,
            passed=central_stable,
            required=true,
            note="the sign-reweighted full-chain center must be independent of " *
                 "the jackknife block partition to floating-point tolerance",
        ))
        consistency_energy_standard_error = block_scan.valid ?
            block_scan.maximum_standard_error : NaN
    end
    acceptance = state.accepted_updates / state.attempted_updates
    sign_effective_count = parameters.measurement_sweeps * summary.average_sign^2
    push!(runs, _run_row(
        run_id=run_id,
        method="finite-temperature DQMC",
        system="periodic_L2_two_orbital",
        boundary="periodic",
        U=point.U,
        beta=point.beta,
        mu=point.mu,
        dtau=dtau,
        seed=seed,
        warmup_steps=parameters.burnin_sweeps,
        measurement_count=parameters.measurement_sweeps,
        steps_between_measurements=1,
        block_size=plan.dqmc_block_size,
        runtime_seconds=runtime,
        energy=summary.internal_energy_per_cell,
        energy_standard_error=summary.internal_energy_per_cell_standard_error,
        density=summary.density,
        average_sign=summary.average_sign,
        sign_effective_count=sign_effective_count,
        acceptance_rate=acceptance,
        maximum_recompute_error=recomputation.maximum,
    ))
    health = summary.configuration_signs_valid &&
        summary.raw_observables_finite && summary.finite_results &&
        summary.denominator_guard_passed &&
        recomputation.maximum <= 1.0e-8 &&
        abs(summary.average_sign) >= 0.02 && 0 < acceptance < 1
    _boolean_check!(checks;
        value=health,
        check_id=run_id * ":health",
        stage="dqmc_run_health",
        profile=profile,
        system="periodic_L2_two_orbital",
        boundary="periodic",
        method="finite-temperature DQMC",
        quantity="finite_sign_reweighted_stable_chain",
        U=point.U,
        beta=point.beta,
        mu=point.mu,
        dtau=dtau,
        seed=seed,
        note="requires valid signs, guarded jackknife denominators, stable Green " *
             "recomputation, and both accepted and rejected updates",
    )
    sign_count_passed = isfinite(sign_effective_count) &&
        sign_effective_count >= plan.dqmc_minimum_sign_effective_count
    push!(checks, _check_row(
        check_id=run_id * ":sign_effective_count",
        stage="dqmc_run_health",
        profile=profile,
        system="periodic_L2_two_orbital",
        boundary="periodic",
        method="finite-temperature DQMC",
        quantity="measurement_count_times_average_sign_squared",
        U=point.U,
        beta=point.beta,
        mu=point.mu,
        dtau=dtau,
        seed=seed,
        estimate=sign_effective_count,
        reference=plan.dqmc_minimum_sign_effective_count,
        absolute_error=sign_count_passed ? 0.0 :
            plan.dqmc_minimum_sign_effective_count - sign_effective_count,
        allowed_error=0.0,
        passed=sign_count_passed,
        required=true,
        note="minimum sign-reweighting count N*<sign>^2; this diagnoses sign " *
             "loss but does not account for autocorrelation",
    ))
    floors = profile == :quick ? Dict(
        :density => 0.05,
        :doping => 0.015,
        :kinetic_energy_per_cell => 0.15,
        :shifted_interaction_energy_per_cell => 0.12,
        :internal_energy_per_cell => 0.15,
        :grand_energy_per_cell => 0.15,
    ) : Dict(
        :density => 0.02,
        :doping => 0.006,
        :kinetic_energy_per_cell => 0.08,
        :shifted_interaction_energy_per_cell => 0.05,
        :internal_energy_per_cell => 0.08,
        :grand_energy_per_cell => 0.08,
    )
    for quantity in THERMODYNAMIC_QUANTITIES
        _numeric_check!(checks;
            check_id=run_id * ":" * String(quantity),
            stage="dqmc_vs_exact_thermal_ed",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="finite-temperature DQMC",
            quantity=String(quantity),
            U=point.U,
            beta=point.beta,
            mu=point.mu,
            dtau=dtau,
            seed=seed,
            estimate=getproperty(summary, quantity),
            standard_error=getproperty(
                summary, Symbol(quantity, :_standard_error),
            ),
            reference=getproperty(exact_thermal, quantity),
            floor=floors[quantity],
            sigma=plan.sigma_gate,
            precision_ceiling=floors[quantity] / 2,
            note="DQMC is grand canonical and finite temperature; reference is " *
                 "the exact thermal ED result, not the CP ground-state value",
        )
    end
    return (
        run_id=run_id,
        dtau=dtau,
        seed=seed,
        summary=summary,
        density_consistency_standard_error=summary.density_standard_error,
        energy_consistency_standard_error=consistency_energy_standard_error,
    )
end

function _csv_cell(value)
    (ismissing(value) || isnothing(value)) && return ""
    string_value = string(value)
    if any(character -> character in (',', '"', '\n', '\r'), string_value)
        return '"' * replace(string_value, "\"" => "\"\"") * '"'
    end
    return string_value
end

function _write_csv(path, rows)
    isempty(rows) && throw(ArgumentError("cannot write an empty CSV: $path"))
    names = propertynames(first(rows))
    all(row -> propertynames(row) == names, rows) || throw(ArgumentError(
        "CSV rows have inconsistent columns: $path",
    ))
    open(path, "w") do io
        println(io, join(String.(names), ','))
        for row in rows
            println(io, join((_csv_cell(getproperty(row, name)) for name in names), ','))
        end
    end
    return path
end

function _write_output(output_dir, options, plan, checks, runs, samples)
    (ispath(output_dir) || islink(output_dir)) && throw(ArgumentError(
        "refusing to overwrite output path: $output_dir",
    ))
    parent = dirname(output_dir)
    mkpath(parent)
    staging = mktempdir(parent; prefix=".$(basename(output_dir)).tmp-")
    required = [check for check in checks if check.required]
    passed = all(check.passed for check in required)
    try
        _write_csv(joinpath(staging, "checks.csv"), checks)
        _write_csv(joinpath(staging, "runs.csv"), runs)
        _write_csv(joinpath(staging, "samples.csv"), samples)
        open(joinpath(staging, "metadata.txt"), "w") do io
            println(io, "format_version=2")
            println(io, "generated_utc=", Dates.format(
                Dates.now(Dates.UTC), dateformat"yyyy-mm-ddTHH:MM:SS.sssZ",
            ))
            println(io, "profile=", options.profile)
            println(io, "profile_interpretation=", plan.interpretation)
            println(io, "seed_offset=", options.seed_offset)
            println(io, "output_policy=refuse_existing_then_atomic_rename")
            println(io, "required_check_count=", length(required))
            println(io, "required_pass_count=", count(check -> check.passed, required))
            println(io, "overall_passed=", passed)
            println(io, "dqmc_L=", DQMC_BRIDGE_POINT.L)
            println(io, "dqmc_U=", DQMC_BRIDGE_POINT.U)
            println(io, "dqmc_beta=", DQMC_BRIDGE_POINT.beta)
            println(io, "dqmc_mu=", DQMC_BRIDGE_POINT.mu)
            println(io, "periodic_dtaus=", join(plan.periodic_dtaus, ';'))
            println(io, "periodic_seeds=", join(
                (seed + options.seed_offset for seed in plan.periodic_seeds), ';',
            ))
            println(io, "periodic_trials=", join(
                (trial.label for trial in plan.periodic_trials), ';',
            ))
            println(io, "periodic_request_count=", length(
                _trial_requests(plan, :periodic),
            ))
            println(io, "open_request_count=", length(
                _trial_requests(plan, :open),
            ))
            println(io, "dimer_U20_baseline_request_count=", length(
                _dimer_requests(plan, 20.0),
            ))
            println(io, "dimer_U20_convergence_request_count=", length(
                _strong_dimer_convergence_requests(plan),
            ))
            println(io, "doped_open_request_count=", length(
                _doped_open_requests(plan),
            ))
            println(io, "trial_grid_policy=", plan.profile == :quick ?
                "full_cartesian" :
                "free_trial_all_dtau_seeds;other_trials_finest_dtau_first_seed")
            println(io, "dqmc_dtaus=", join(plan.dqmc_dtaus, ';'))
            println(io, "dqmc_seeds=", join(
                (seed + options.seed_offset for seed in plan.dqmc_seeds), ';',
            ))
            println(io, "dqmc_measurements_per_run=",
                plan.dqmc_measurement_sweeps)
            println(io, "dqmc_warmup_sweeps_per_run=",
                plan.dqmc_warmup_sweeps)
            println(io, "strong_dimer_measurements_per_run=",
                plan.strong_dimer_measurements)
            println(io, "doped_open_long_bp_measurements_per_run=",
                plan.doped_open_long_measurements)
            println(io, "dqmc_minimum_sign_effective_count=",
                plan.dqmc_minimum_sign_effective_count)
            println(io, "estimated_standard_runtime=roughly_45_to_120_minutes_" *
                "on_one_modern_laptop_CPU")
            println(io, "julia_version=", VERSION)
            println(io, "hamiltonian=centered repulsive two-orbital Hubbard")
            println(io, "cp_energy_estimator=mixed")
            println(io, "cp_other_estimators=backpropagated")
            println(io, "cp_projection_time_columns=planned_warmup_time_is_the_" *
                "premeasurement_projection;projection_time_and_total_projection_" *
                "time_are_the_backward_compatible_and_explicit_total_elapsed_values")
            println(io, "cp_run_audit_fields=variant;trial_pattern;trial_shell_gaps;" *
                "population_interval_and_count;stabilization_intervals;all_mixed_" *
                "and_backpropagated_scalar_estimates_and_standard_errors")
            println(io, "cp_standard_accuracy_gate=fixed_absolute_cap_independent_" *
                "of_sigma_plus_a_separate_one_sigma_precision_ceiling")
            println(io, "cp_quick_accuracy_gate=legacy_small_benchmarks_use_" *
                "sigma_expansion;doped_open_E_K_V_D_S_use_fixed_smoke_caps;" *
                "all_use_precision_ceilings")
            println(io, "dimer_U20_standard_grid=three_dtau_by_three_seeds;fine_" *
                "dtau_variants=projection8_walkers960_population10_backprop3")
            println(io, "dimer_U20_caps=pooled_energy_accuracy_0.04_se_0.02;" *
                "backprop3_double_per_site_accuracy_0.001_se_0.0005;control_" *
                "shifts_use_the_same_energy_and_double_caps")
            println(io, "doped_open_standard_grid=free_bp2_three_seeds;five_" *
                "nonfree_trials_first_seed;free_bp4_three_seeds;free_population10_" *
                "bp2_three_seeds")
            println(io, "doped_open_standard_caps=energy_0.02;kinetic_0.06;" *
                "interaction_0.03;double_per_cell_0.005;S_alm_q0_0.01;" *
                "each_precision_ceiling_is_half_its_cap")
            println(io, "cp_control_shift_pooling=matched_seed_differences;within_" *
                "chain_errors_use_paired_blocks_when_only_BP_length_changes_and_" *
                "otherwise_combine_by_hypot;then_unweighted_pool_with_between_" *
                "seed_uncertainty;requires_sigma_absolute_and_precision_caps")
            println(io, "dqmc_samples=raw estimators with one separate sign column")
            println(io, "dqmc_checks=sign-reweighted ratios with blocked jackknife errors")
            println(io, "dqmc_half_drift_gate=standard_only;same_post_burn_chain_" *
                "split_into_two_contiguous_halves;each_half_sign_reweighted_" *
                "separately;block_size=$(plan.dqmc_drift_block_size);" *
                "difference_error=hypot;requires_" *
                string(plan.dqmc_random_difference_sigma) *
                "_sigma_agreement_and_a_separate_precision_limit;" *
                "minimum_half_sign_effective_count=" *
                string(plan.dqmc_minimum_sign_effective_count / 2))
            println(io, "dqmc_block_error_stability_gate=standard_only;" *
                "quantity=internal_energy_per_cell;block_sizes=" *
                join(plan.dqmc_block_stability_sizes, ';') *
                ";criterion=every_error_finite_and_strictly_positive_then_" *
                "max_over_min_at_most_" *
                string(plan.dqmc_block_error_ratio_maximum) *
                ";zero_error_fails")
            println(io, "dqmc_seed_consistency_gate=standard_only;exactly_two_" *
                "prespecified_independent_seeds_at_each_dtau;density_and_" *
                "internal_energy;difference_error=hypot;requires_" *
                string(plan.dqmc_random_difference_sigma) *
                "_sigma_agreement_and_a_separate_precision_limit")
            println(io, "dqmc_consistency_sigma=", plan.dqmc_consistency_sigma)
            println(io, "dqmc_random_difference_sigma=",
                plan.dqmc_random_difference_sigma)
            println(io, "dqmc_density_consistency_error_ceiling=",
                plan.dqmc_density_consistency_precision)
            println(io, "dqmc_energy_consistency_error_ceiling=",
                plan.dqmc_energy_consistency_precision)
            println(io, "dqmc_dtau_squared_extrapolation=standard_only;pool_" *
                "seeds_unweighted_at_each_dtau;fit=a_plus_b_times_dtau_squared;" *
                "weights=inverse_pooled_variance;intercept_error=propagated_" *
                "covariance_times_max_1_reduced_chi_squared;requires_all_three_" *
                "standard_dtau_values")
            println(io, "dqmc_extrapolation_absolute_cap=",
                plan.dqmc_extrapolation_floor)
            println(io, "dqmc_extrapolation_error_ceiling=",
                plan.dqmc_extrapolation_precision)
            println(io, "dqmc_extrapolation_maximum_reduced_chi_squared=",
                plan.dqmc_extrapolation_maximum_reduced_chi_squared)
            println(io, "dqmc_cp_bridge=quick_uses_finest_dtau_seed_pool;" *
                "standard_uses_three_point_dtau_squared_intercept")
            println(io, "precision_gate=required_one_sigma_error_at_most_half_" *
                "the_absolute_tolerance")
            println(io, "seed_pooling=unweighted_mean_over_prespecified_independent_" *
                "seeds;combined_error=max(root_sum_square_within_chain_errors/" *
                "seed_count,standard_error_across_seed_means)_to_avoid_double_" *
                "counting_the_same_Monte_Carlo_noise")
            println(io, "dtau_shift=paired_free_trial_coarse_minus_fine_at_matched_seeds")
            println(io, "sign_effective_count=measurement_count_times_average_sign_squared;" *
                "does_not_include_autocorrelation")
            println(io, "constraint=positive trial-overlap path; no mirror correction")
            println(io, "warning=passing does not remove constrained-path bias")
            println(io, "warning=quick profile is not a production physics gate")
        end
        open(joinpath(staging, "status.txt"), "w") do io
            println(io, passed ? "PASS" : "FAIL")
        end
        (ispath(output_dir) || islink(output_dir)) && throw(ArgumentError(
            "output path appeared while validation was running: $output_dir",
        ))
        mv(staging, output_dir)
    catch
        ispath(staging) && rm(staging; recursive=true)
        rethrow()
    end
    return (passed=passed, output_dir=output_dir)
end

function run_validation(options)
    (ispath(options.output_dir) || islink(options.output_dir)) &&
        throw(ArgumentError(
            "refusing to overwrite output path: $(options.output_dir)",
        ))
    plan = validation_plan(options.profile)
    profile = plan.profile
    checks = NamedTuple[]
    runs = NamedTuple[]
    samples = NamedTuple[]
    dimer_references = Dict{Float64,Any}()

    for U in (0.0, 4.0, 20.0)
        try
            benchmark = benchmark_hubbard_dimer(U, 1.0; atol=1.0e-12, rtol=1.0e-12)
            dimer_references[U] = benchmark.analytic
            _boolean_check!(checks;
                value=benchmark.passed,
                check_id="dimer_exact_U$(U)",
                stage="analytic_vs_numerical_ed",
                profile=profile,
                system="hubbard_dimer",
                boundary="open",
                method="analytic+full-Hilbert ED",
                quantity="spectrum_energy_gap_and_double_occupancy",
                U=U,
                Nup=1,
                Ndown=1,
                note="repository analytic and independent numerical dimer solvers",
            )
        catch error
            _error_check!(checks, profile, "analytic_vs_numerical_ed",
                          "hubbard_dimer", "full-Hilbert ED", error;
                          boundary="open", check_id="dimer_exact_U$(U)")
        end
    end

    if haskey(dimer_references, 0.0)
        reference = dimer_references[0.0]
        problem = CPAFQMCProblem([0.0 -1.0; -1.0 0.0], 0.0, 1, 1; cell_count=2)
        controls = CPAFQMCParameters(
            dtau=0.05, walker_count=8, warmup_steps=4,
            measurement_count=4, steps_between_measurements=2,
            orthogonalize_every=2, population_control_every=2,
            back_propagation_steps=0, error_block_size=2,
            seed=19 + options.seed_offset,
        )
        run_id = "cp_dimer_U0"
        try
            result = _record_cp_run!(runs, samples, checks, profile, run_id,
                "hubbard_dimer", "open", problem, controls,
                one_body_trial(problem))
            _add_cp_comparison!(checks, profile, run_id, result, (
                energy=reference.ground_singlet_energy,
                double_per_cell=missing,
            ); system="hubbard_dimer", boundary="open",
               energy_floor=1.0e-11, double_floor=0.0)
        catch error
            _failed_run!(runs, checks, profile, run_id, "CP-AFQMC",
                "hubbard_dimer", "open", error; U=0.0, Nup=1, Ndown=1,
                trial="free", dtau=0.05, seed=controls.seed)
        end
    end

    dimer_records = NamedTuple[]
    for U in (4.0, 20.0)
        haskey(dimer_references, U) || continue
        reference = dimer_references[U]
        for request in _dimer_requests(plan, U)
            dtau = request.dtau
            seed = request.base_seed + options.seed_offset
            problem = CPAFQMCProblem(
                [0.0 -1.0; -1.0 0.0], U, 1, 1; cell_count=2,
            )
            controls = _cp_controls(
                plan, :dimer, dtau, seed;
                measurement_count=profile == :standard && U == 20.0 ?
                    plan.strong_dimer_measurements : nothing,
            )
            run_id = "cp_dimer_U$(U)_dt$(dtau)_seed$(seed)"
            try
                result = _record_cp_run!(runs, samples, checks, profile, run_id,
                    "hubbard_dimer", "open", problem, controls,
                    one_body_trial(problem); variant="baseline")
                energy_floor = profile == :quick ? (U == 20 ? 0.15 : 0.10) :
                    (U == 20 ? 0.08 : 0.04)
                double_floor = profile == :quick ? 0.015 : 0.008
                double_reference = profile == :standard && U == 20.0 ?
                    missing : reference.ground_double_occupancy_per_site
                _add_cp_comparison!(checks, profile, run_id, result, (
                    energy=reference.ground_singlet_energy,
                    double_per_cell=double_reference,
                ); system="hubbard_dimer", boundary="open",
                   energy_floor=energy_floor, double_floor=double_floor)
                push!(dimer_records, (
                    U=U,
                    variant="baseline",
                    dtau=dtau,
                    seed=seed,
                    summary=result.summary,
                    measurements=result.measurements,
                    block_size=controls.error_block_size,
                ))
            catch error
                _failed_run!(runs, checks, profile, run_id, "CP-AFQMC",
                    "hubbard_dimer", "open", error; U=U, Nup=1, Ndown=1,
                    trial="free", dtau=dtau, seed=seed)
            end
        end
    end

    if profile == :standard && haskey(dimer_references, 20.0)
        U = 20.0
        problem = CPAFQMCProblem(
            [0.0 -1.0; -1.0 0.0], U, 1, 1; cell_count=2,
        )
        trial = one_body_trial(problem)
        for request in _strong_dimer_convergence_requests(plan)
            seed = request.base_seed + options.seed_offset
            controls = _cp_controls(
                plan, :dimer, request.dtau, seed;
                walker_count=request.walkers,
                projection_time=request.projection_time,
                measurement_count=plan.strong_dimer_measurements,
                backpropagation_time=request.backpropagation_time,
                population_control_every=request.population_control_every,
            )
            run_id = "cp_dimer_U20_dt$(request.dtau)_$(request.variant)_seed$(seed)"
            try
                result = _record_cp_run!(runs, samples, checks, profile, run_id,
                    "hubbard_dimer", "open", problem, controls, trial;
                    variant=request.variant)
                push!(dimer_records, (
                    U=U,
                    variant=request.variant,
                    dtau=request.dtau,
                    seed=seed,
                    summary=result.summary,
                    measurements=result.measurements,
                    block_size=controls.error_block_size,
                ))
            catch error
                _failed_run!(runs, checks, profile, run_id, "CP-AFQMC",
                    "hubbard_dimer", "open", error; U=U, Nup=1, Ndown=1,
                    trial="free", dtau=request.dtau, seed=seed,
                    variant=request.variant, controls=controls)
            end
        end

        expected_seeds = sort!(collect(plan.dimer_seeds) .+ options.seed_offset)
        expected_grid = Set(
            (Float64(dtau), seed) for dtau in plan.dimer_dtaus[U]
            for seed in expected_seeds
        )
        observed_baseline = [record for record in dimer_records
                             if record.U == U && record.variant == "baseline"]
        observed_grid = Set((record.dtau, record.seed)
                            for record in observed_baseline)
        _boolean_check!(checks;
            value=length(observed_baseline) == length(expected_grid) &&
                observed_grid == expected_grid,
            check_id="dimer_U20_baseline_grid",
            stage="cp_convergence_summary",
            profile=profile,
            system="hubbard_dimer",
            boundary="open",
            method="CP-AFQMC",
            quantity="complete_dtau_seed_grid",
            U=U,
            Nup=1,
            Ndown=1,
            note="standard requires every one of three dtau values at all three " *
                 "prespecified independent seeds",
        )

        fine_dtau = minimum(plan.dimer_dtaus[U])
        coarse_dtau = maximum(plan.dimer_dtaus[U])
        fine_baseline = [record for record in dimer_records
                         if record.U == U && record.variant == "baseline" &&
                            record.dtau == fine_dtau]
        coarse_baseline = [record for record in dimer_records
                           if record.U == U && record.variant == "baseline" &&
                              record.dtau == coarse_dtau]
        if length(fine_baseline) == length(expected_seeds)
            energy_pool = _pool_cp_records(fine_baseline, :energy)
            _numeric_check!(checks;
                check_id="dimer_U20_fine_pooled_energy",
                stage="cp_vs_analytic",
                profile=profile,
                system="hubbard_dimer",
                boundary="open",
                method="CP-AFQMC",
                quantity="fine_dtau_pooled_mixed_energy",
                U=U,
                Nup=1,
                Ndown=1,
                dtau=fine_dtau,
                estimate=energy_pool.mean,
                standard_error=energy_pool.standard_error,
                reference=dimer_references[U].ground_singlet_energy,
                floor=0.04,
                sigma=0.0,
                precision_ceiling=0.02,
                note="fixed absolute accuracy cap; unweighted three-seed pool " *
                     "uses the larger of its within-chain and across-seed " *
                     "error estimates",
            )
        end

        dimer_shift_specs = (
            (quantity=:energy, label="mixed_energy", cap=0.04),
            (quantity=:backpropagated_double_occupancy_per_cell,
             label="backpropagated_double_per_site", cap=0.001),
        )
        _add_cp_shift_checks!(
            checks, profile, "dimer_U20_coarse_to_fine",
            coarse_baseline, fine_baseline, expected_seeds, dimer_shift_specs;
            system="hubbard_dimer", U=U, Nup=1, Ndown=1,
            note="coarsest-to-finest baseline comparison",
        )

        for variant in plan.dimer_convergence_variants
            variant_records = [record for record in dimer_records
                               if record.U == U &&
                                  record.variant == variant.label]
            if variant.label == "backprop3"
                identity = _matched_cp_measurement_identity(
                    variant_records, fine_baseline, expected_seeds, :energy,
                )
                _boolean_check!(checks;
                    value=identity.complete && identity.identical,
                    check_id="dimer_U20_backprop3_mixed_path_identity",
                    stage="cp_convergence_summary",
                    profile=profile,
                    system="hubbard_dimer",
                    boundary="open",
                    method="CP-AFQMC",
                    quantity="mixed_energy_path_identity",
                    U=U,
                    Nup=1,
                    Ndown=1,
                    note="changing only back-propagation length must leave " *
                         "every mixed-estimator sample unchanged; compared=" *
                         string(identity.compared),
                )
                _add_cp_shift_checks!(
                    checks, profile, "dimer_U20_$(variant.label)_shift",
                    variant_records, fine_baseline, expected_seeds,
                    (dimer_shift_specs[2],);
                    system="hubbard_dimer", U=U, Nup=1, Ndown=1,
                    note="one-knob $(variant.label) comparison against the " *
                         "fine baseline",
                    paired_measurements=true,
                )
                continue
            end
            _add_cp_shift_checks!(
                checks, profile, "dimer_U20_$(variant.label)_shift",
                variant_records, fine_baseline, expected_seeds,
                dimer_shift_specs;
                system="hubbard_dimer", U=U, Nup=1, Ndown=1,
                note="one-knob $(variant.label) comparison against the fine " *
                     "baseline",
            )
        end

        long_backprop = [record for record in dimer_records
                         if record.U == U && record.variant == "backprop3"]
        if length(long_backprop) == length(expected_seeds)
            double_pool = _pool_cp_records(
                long_backprop, :backpropagated_double_occupancy_per_cell,
            )
            _numeric_check!(checks;
                check_id="dimer_U20_backprop3_pooled_double",
                stage="cp_vs_analytic",
                profile=profile,
                system="hubbard_dimer",
                boundary="open",
                method="CP-AFQMC",
                quantity="backpropagated_double_occupancy_per_site",
                U=U,
                Nup=1,
                Ndown=1,
                dtau=fine_dtau,
                estimate=double_pool.mean,
                standard_error=double_pool.standard_error,
                reference=dimer_references[U].ground_double_occupancy_per_site,
                floor=0.001,
                sigma=0.0,
                precision_ceiling=0.0005,
                note="tight strong-U accuracy gate uses BP time 3, not the " *
                     "shorter BP time 1.5 baseline",
            )
        end
    end

    periodic_exact = nothing
    periodic_kinetic = realspace_kinetic_matrix(2)
    try
        periodic_exact = ground_state_observables(
            periodic_kinetic, 2.0, 2, 2;
            method=:lanczos, maxiter=180, atol=1.0e-11, rtol=1.0e-10,
        )
        _boolean_check!(checks;
            value=periodic_exact.converged && periodic_exact.residual <= 5.0e-8,
            check_id="periodic_generic_ed_health",
            stage="generic_fixed_sector_ed",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="matrix-free Lanczos ED",
            quantity="converged_residual",
            U=2.0,
            Nup=2,
            Ndown=2,
            note="arbitrary-kinetic fixed-sector ED; residual=" *
                 string(periodic_exact.residual),
        )
    catch error
        _error_check!(checks, profile, "generic_fixed_sector_ed",
                      "periodic_L2_two_orbital", "matrix-free Lanczos ED",
                      error; boundary="periodic",
                      check_id="periodic_generic_ed_health")
    end

    periodic_records = NamedTuple[]
    if !isnothing(periodic_exact)
        problem = two_orbital_cp_afqmc_problem(2, 2.0, 2, 2)
        reference = (
            energy=periodic_exact.energy,
            double_per_cell=periodic_exact.double_occupancy / 4,
        )
        spin_reference = periodic_exact.oalm2 / 4
        for request in _trial_requests(plan, :periodic)
            dtau = request.dtau
            trial_spec = request.trial
            seed = request.base_seed + options.seed_offset
            controls = _cp_controls(plan, :periodic, dtau, seed)
            trial = one_body_trial(
                problem; pattern=trial_spec.pattern,
                field_strength=trial_spec.field,
            )
            run_id = "cp_periodic_dt$(dtau)_$(trial_spec.label)_seed$(seed)"
            try
                result = _record_cp_run!(runs, samples, checks, profile, run_id,
                    "periodic_L2_two_orbital", "periodic", problem, controls,
                    trial)
                _add_cp_comparison!(checks, profile, run_id, result, reference;
                    system="periodic_L2_two_orbital", boundary="periodic",
                    energy_floor=profile == :quick ? 0.06 : 0.03,
                    double_floor=profile == :quick ? 0.025 : 0.012,
                    spin_reference=spin_reference,
                    spin_floor=profile == :quick ? 0.06 : 0.03)
                push!(periodic_records, (
                    dtau=dtau, trial=trial_spec.label, seed=seed,
                    energy=result.summary.energy,
                    standard_error=result.summary.energy_standard_error,
                ))
            catch error
                _failed_run!(runs, checks, profile, run_id, "CP-AFQMC",
                    "periodic_L2_two_orbital", "periodic", error;
                    U=2.0, Nup=2, Ndown=2, trial=trial_spec.label,
                    dtau=dtau, seed=seed)
            end
        end
    end

    fine_cp_summary = nothing
    if !isnothing(periodic_exact) && !isempty(periodic_records)
        fine_dtau = minimum(plan.periodic_dtaus)
        coarse_dtau = maximum(plan.periodic_dtaus)
        fine = [record for record in periodic_records
                if record.dtau == fine_dtau && record.trial == "free"]
        coarse = [record for record in periodic_records
                  if record.dtau == coarse_dtau && record.trial == "free"]
        expected_seeds = sort!(collect(plan.periodic_seeds) .+ options.seed_offset)
        fine_by_seed = Dict(record.seed => record for record in fine)
        coarse_by_seed = Dict(record.seed => record for record in coarse)
        matched_seeds = sort!(collect(intersect(
            Set(keys(fine_by_seed)), Set(keys(coarse_by_seed)),
        )))
        complete_matched_grid = matched_seeds == expected_seeds
        _boolean_check!(checks;
            value=complete_matched_grid,
            check_id="periodic_matched_free_seed_grid",
            stage="cp_convergence_summary",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="CP-AFQMC",
            quantity="matched_free_trial_seed_grid_complete",
            U=2.0, Nup=2, Ndown=2,
            note="time-step and bridge summaries require the same independent " *
                 "free-trial seeds at the coarsest and finest dtau",
        )
        if !isempty(matched_seeds)
        fine_pool = _pool_independent_estimates(
            [fine_by_seed[seed].energy for seed in matched_seeds],
            [fine_by_seed[seed].standard_error for seed in matched_seeds],
        )
        fine_mean = fine_pool.mean
        fine_se = fine_pool.standard_error
        fine_cp_summary = (
            energy_per_cell=fine_mean / 4,
            standard_error_per_cell=fine_se / 4,
            seed_count=fine_pool.count,
        )
        _numeric_check!(checks;
            check_id="periodic_fine_dtau_pooled_energy",
            stage="cp_convergence_summary",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="CP-AFQMC",
            quantity="fine_dtau_pooled_mixed_energy",
            U=2.0, Nup=2, Ndown=2, dtau=fine_dtau,
            estimate=fine_mean,
            standard_error=fine_se,
            reference=periodic_exact.energy,
            floor=profile == :quick ? 0.04 : 0.02,
            sigma=profile == :quick ? plan.sigma_gate : 0.0,
            precision_ceiling=(profile == :quick ? 0.04 : 0.02) / 2,
            note="unweighted free-trial mean across independent matched seeds; " *
                 "error is the larger of the within-chain and across-seed " *
                 "estimates",
        )
        paired_shifts = [
            fine_by_seed[seed].energy - coarse_by_seed[seed].energy
            for seed in matched_seeds
        ]
        paired_errors = [
            hypot(
                fine_by_seed[seed].standard_error,
                coarse_by_seed[seed].standard_error,
            ) for seed in matched_seeds
        ]
        shift_pool = _pool_independent_estimates(paired_shifts, paired_errors)
        timestep_shift = abs(shift_pool.mean)
        _numeric_check!(checks;
            check_id="periodic_dtau_shift",
            stage="cp_convergence_summary",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="CP-AFQMC",
            quantity="coarse_to_fine_energy_shift",
            U=2.0, Nup=2, Ndown=2,
            estimate=timestep_shift,
            standard_error=shift_pool.standard_error,
            reference=0.0,
            floor=profile == :quick ? 0.06 : 0.03,
            sigma=profile == :quick ? plan.sigma_gate : 0.0,
            precision_ceiling=(profile == :quick ? 0.06 : 0.03) / 2,
            note="paired coarse-to-fine shift for the free trial at identical " *
                 "independent seeds; the pool uses the larger of its " *
                 "within-chain and across-seed error estimates",
        )
        fine_all_trials = [record for record in periodic_records
                           if record.dtau == fine_dtau]
        trial_means = [
            sum(record.energy for record in fine_all_trials
                if record.trial == trial.label) /
            count(record -> record.trial == trial.label, fine_all_trials)
            for trial in plan.periodic_trials
        ]
        seed_means = [
            sum(record.energy for record in fine_all_trials
                if record.seed == seed + options.seed_offset &&
                   record.trial == "free") /
            count(record -> record.seed == seed + options.seed_offset &&
                record.trial == "free", fine_all_trials)
            for seed in plan.periodic_seeds
        ]
        _numeric_check!(checks;
            check_id="periodic_trial_spread",
            stage="cp_convergence_summary",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="CP-AFQMC",
            quantity="fine_dtau_trial_energy_spread",
            estimate=maximum(trial_means) - minimum(trial_means),
            reference=0.0,
            floor=profile == :quick ? 0.06 : 0.03,
            required=false,
            note="descriptive only because the sparse trial grid does not " *
                 "support a pooled uncertainty; required trial gates use the " *
                 "doped open exact cluster",
        )
        _numeric_check!(checks;
            check_id="periodic_seed_spread",
            stage="cp_convergence_summary",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="CP-AFQMC",
            quantity="fine_dtau_seed_energy_spread",
            estimate=maximum(seed_means) - minimum(seed_means),
            reference=0.0,
            floor=profile == :quick ? 0.06 : 0.03,
            required=false,
            note="descriptive only; the required fine-dtau pooled check carries " *
                 "the conservative pooled uncertainty",
        )
        end
    end

    open_kinetic = open_cluster_kinetic_matrix(2, 2)
    for U in (0.0, 2.0)
        open_exact = nothing
        try
            open_exact = ground_state_observables(
                open_kinetic, U, 1, 1; method=:dense,
            )
            _boolean_check!(checks;
                value=open_exact.converged && open_exact.residual <= 1.0e-10,
                check_id="open_generic_ed_U$(U)_health",
                stage="generic_fixed_sector_ed",
                profile=profile,
                system="open_2x2_two_orbital",
                boundary="open",
                method="dense fixed-sector ED",
                quantity="converged_residual",
                U=U, Nup=1, Ndown=1,
                note="generic kinetic retains nonzero t4 interorbital hopping",
            )
        catch error
            _error_check!(checks, profile, "generic_fixed_sector_ed",
                "open_2x2_two_orbital", "dense fixed-sector ED", error;
                boundary="open", check_id="open_generic_ed_U$(U)_health")
        end
        isnothing(open_exact) && continue
        problem = CPAFQMCProblem(
            open_kinetic, U, 1, 1; lattice_size=2, cell_count=4,
        )
        if iszero(U)
            controls = CPAFQMCParameters(
                dtau=0.05, walker_count=8, warmup_steps=4,
                measurement_count=4, steps_between_measurements=2,
                orthogonalize_every=2, population_control_every=2,
                back_propagation_steps=2, minimum_backprop_ancestors=2,
                error_block_size=2, seed=29 + options.seed_offset,
            )
            requested = ((label="free", pattern=:free, field=0.0,
                          controls=controls),)
        else
            requested = Tuple((
                label=request.trial.label,
                pattern=request.trial.pattern,
                field=request.trial.field,
                controls=_cp_controls(
                    plan, :open, request.dtau,
                    request.base_seed + options.seed_offset,
                ),
            ) for request in _trial_requests(plan, :open))
        end
        for request in requested
            controls = request.controls
            run_id = "cp_open_U$(U)_dt$(controls.dtau)_$(request.label)_seed$(controls.seed)"
            try
                result = _record_cp_run!(runs, samples, checks, profile, run_id,
                    "open_2x2_two_orbital", "open", problem, controls,
                    one_body_trial(problem; pattern=request.pattern,
                                   field_strength=request.field))
                exact_reference = (
                    energy=open_exact.energy,
                    double_per_cell=open_exact.double_occupancy / 4,
                )
                exact_spin = open_exact.oalm2 / 4
                exact_tolerance = iszero(U) ? 1.0e-10 :
                    (profile == :quick ? 0.06 : 0.035)
                double_tolerance = iszero(U) ? 1.0e-10 :
                    (profile == :quick ? 0.02 : 0.01)
                spin_tolerance = iszero(U) ? 1.0e-10 :
                    (profile == :quick ? 0.06 : 0.03)
                _add_cp_comparison!(checks, profile, run_id, result,
                    exact_reference; system="open_2x2_two_orbital",
                    boundary="open", energy_floor=exact_tolerance,
                    double_floor=double_tolerance,
                    spin_reference=exact_spin, spin_floor=spin_tolerance)
            catch error
                _failed_run!(runs, checks, profile, run_id, "CP-AFQMC",
                    "open_2x2_two_orbital", "open", error; U=U, Nup=1,
                    Ndown=1, trial=request.label, dtau=controls.dtau,
                    seed=controls.seed)
            end
        end
    end

    # This doped fixed sector is important because it has a genuine open-cluster
    # interorbital hopping matrix and is away from the N=2 dilute benchmark.
    doped_open_exact = nothing
    try
        doped_open_exact = ground_state_observables(
            open_kinetic, 2.0, 3, 3;
            method=:lanczos, maxiter=220, atol=1.0e-11, rtol=1.0e-10,
        )
        _boolean_check!(checks;
            value=doped_open_exact.converged &&
                doped_open_exact.residual <= 5.0e-8,
            check_id="open_doped_N6_generic_ed_health",
            stage="generic_fixed_sector_ed",
            profile=profile,
            system="open_2x2_two_orbital_doped_N6",
            boundary="open",
            method="matrix-free Lanczos ED",
            quantity="converged_residual",
            U=2.0, Nup=3, Ndown=3,
            note="doped N=6 sector with nonzero t4; residual=" *
                 string(doped_open_exact.residual),
        )
    catch error
        _error_check!(checks, profile, "generic_fixed_sector_ed",
            "open_2x2_two_orbital_doped_N6", "matrix-free Lanczos ED",
            error; boundary="open", check_id="open_doped_N6_generic_ed_health")
    end
    if !isnothing(doped_open_exact)
        problem = CPAFQMCProblem(
            open_kinetic, 2.0, 3, 3; lattice_size=2, cell_count=4,
        )
        doped_records = NamedTuple[]
        requests = _doped_open_requests(plan)
        for request in requests
            seed = request.base_seed + options.seed_offset
            controls = _cp_controls(
                plan, :open, request.dtau, seed;
                measurement_count=request.measurement_count,
                backpropagation_time=request.backpropagation_time,
                population_control_every=request.population_control_every,
            )
            run_id = "cp_open_doped_N6_dt$(request.dtau)_" *
                "$(request.variant)_$(request.trial.label)_seed$(seed)"
            try
                result = _record_cp_run!(runs, samples, checks, profile, run_id,
                    "open_2x2_two_orbital_doped_N6", "open", problem, controls,
                    one_body_trial(
                        problem; pattern=request.trial.pattern,
                        field_strength=request.trial.field,
                    ); variant=request.variant)
                push!(doped_records, (
                    variant=request.variant,
                    trial=request.trial.label,
                    dtau=request.dtau,
                    seed=seed,
                    summary=result.summary,
                    measurements=result.measurements,
                    block_size=controls.error_block_size,
                ))
            catch error
                _failed_run!(runs, checks, profile, run_id, "CP-AFQMC",
                    "open_2x2_two_orbital_doped_N6", "open", error;
                    U=2.0, Nup=3, Ndown=3, trial=request.trial.label,
                    dtau=request.dtau, seed=seed, variant=request.variant,
                    controls=controls)
            end
        end

        expected_keys = Set((
            request.variant,
            request.trial.label,
            request.base_seed + options.seed_offset,
        ) for request in requests)
        observed_keys = Set((record.variant, record.trial, record.seed)
                            for record in doped_records)
        _boolean_check!(checks;
            value=length(expected_keys) == length(requests) &&
                observed_keys == expected_keys,
            check_id="open_doped_N6_request_grid",
            stage="cp_convergence_summary",
            profile=profile,
            system="open_2x2_two_orbital_doped_N6",
            boundary="open",
            method="CP-AFQMC",
            quantity="prespecified_request_grid_complete",
            U=2.0,
            Nup=3,
            Ndown=3,
            note=profile == :quick ?
                "quick requires one BP-enabled free-trial smoke run" :
                "standard requires free BP2/BP4/pop10 seed grids and five " *
                "prespecified nonfree trials",
        )

        baseline = [record for record in doped_records
                    if record.variant == "baseline"]
        if profile == :quick
            if !isempty(baseline)
                _add_cp_pool_exact_checks!(
                    checks, profile, "open_doped_N6_quick", baseline,
                    doped_open_exact; trial="free",
                    note="one BP-enabled free-trial smoke run",
                )
            end
        else
            expected_seeds = sort!(
                collect(plan.doped_open_seeds) .+ options.seed_offset,
            )
            backprop4 = [record for record in doped_records
                         if record.variant == "backprop4"]
            population10 = [record for record in doped_records
                            if record.variant == "population10"]
            if length(baseline) == length(expected_seeds)
                _add_cp_pool_exact_checks!(
                    checks, profile, "open_doped_N6_free_bp2", baseline,
                    doped_open_exact; trial="free",
                    note="free trial, BP time 2, population interval 5",
                )
            end
            if length(backprop4) == length(expected_seeds)
                _add_cp_pool_exact_checks!(
                    checks, profile, "open_doped_N6_free_bp4", backprop4,
                    doped_open_exact; trial="free",
                    note="free trial, BP time 4, population interval 5",
                )
            end

            consistency_specs = _doped_open_quantity_specs(
                profile, doped_open_exact,
            )
            bp_identity = _matched_cp_measurement_identity(
                backprop4, baseline, expected_seeds, :energy,
            )
            _boolean_check!(checks;
                value=bp_identity.complete && bp_identity.identical,
                check_id="open_doped_N6_bp2_vs_bp4_mixed_path_identity",
                stage="cp_convergence_summary",
                profile=profile,
                system="open_2x2_two_orbital_doped_N6",
                boundary="open",
                method="CP-AFQMC",
                quantity="mixed_energy_path_identity",
                U=2.0,
                Nup=3,
                Ndown=3,
                note="changing only back-propagation length must leave every " *
                     "shared mixed-estimator sample unchanged; compared=" *
                     string(bp_identity.compared),
            )
            _add_cp_shift_checks!(
                checks, profile, "open_doped_N6_bp2_vs_bp4",
                backprop4, baseline, expected_seeds, consistency_specs[2:end];
                system="open_2x2_two_orbital_doped_N6", U=2.0,
                Nup=3, Ndown=3,
                note="BP time 4 compared with BP time 2",
                paired_measurements=true,
            )
            _add_cp_shift_checks!(
                checks, profile, "open_doped_N6_pop5_vs_pop10",
                population10, baseline, expected_seeds, consistency_specs;
                system="open_2x2_two_orbital_doped_N6", U=2.0,
                Nup=3, Ndown=3,
                note="population-control interval 10 compared with 5",
            )

            first_seed = first(expected_seeds)
            for trial in plan.doped_open_trials[2:end]
                trial_records = [record for record in doped_records
                                 if record.variant == trial.label]
                if !isempty(trial_records)
                    _add_cp_pool_exact_checks!(
                        checks, profile, "open_doped_N6_$(trial.label)",
                        trial_records, doped_open_exact; trial=trial.label,
                        note="prespecified nonfree trial at the first seed",
                    )
                end
            end
            for (first_label, second_label, pair_label) in (
                ("alm_plus", "alm_minus", "alm_domain"),
                ("stripe_x", "stripe_y", "stripe_rotation"),
            )
                first_records = [record for record in doped_records
                                 if record.variant == first_label]
                second_records = [record for record in doped_records
                                  if record.variant == second_label]
                _add_cp_shift_checks!(
                    checks, profile, "open_doped_N6_$(pair_label)",
                    first_records, second_records, (first_seed,),
                    consistency_specs;
                    system="open_2x2_two_orbital_doped_N6", U=2.0,
                    Nup=3, Ndown=3,
                    note="$first_label compared with $second_label for even " *
                         "observables",
                )
            end
        end
    end

    exact_thermal = nothing
    try
        exact_thermal = exact_thermal_bridge()
        kinetic_error = maximum(abs,
            exact_thermal.raw.kinetic - periodic_kinetic,
        )
        _numeric_check!(checks;
            check_id="thermal_ed_model_identity",
            stage="exact_thermal_bridge",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="factorized grand-canonical ED",
            quantity="maximum_kinetic_matrix_difference",
            U=DQMC_BRIDGE_POINT.U,
            beta=DQMC_BRIDGE_POINT.beta,
            mu=DQMC_BRIDGE_POINT.mu,
            estimate=kinetic_error,
            reference=0.0,
            floor=1.0e-12,
            note="proves the thermal ED bridge uses the package kinetic matrix",
        )
        _numeric_check!(checks;
            check_id="thermal_ed_density_plateau",
            stage="exact_thermal_bridge",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="factorized grand-canonical ED",
            quantity="density",
            U=DQMC_BRIDGE_POINT.U,
            beta=DQMC_BRIDGE_POINT.beta,
            mu=DQMC_BRIDGE_POINT.mu,
            estimate=exact_thermal.density,
            reference=1.0,
            floor=1.0e-4,
            note="mu lies in the N=4 finite-cluster plateau at beta=10",
        )
        target_sector_threshold = 0.9999
        target_sector_passed = isfinite(exact_thermal.target_sector_probability) &&
            exact_thermal.target_sector_probability > target_sector_threshold
        push!(checks, _check_row(
            check_id="thermal_ed_target_spin_sector_probability",
            stage="exact_thermal_bridge",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="factorized grand-canonical ED",
            quantity="probability_Nup2_Ndown2",
            U=DQMC_BRIDGE_POINT.U,
            beta=DQMC_BRIDGE_POINT.beta,
            mu=DQMC_BRIDGE_POINT.mu,
            Nup=DQMC_BRIDGE_POINT.Nup,
            Ndown=DQMC_BRIDGE_POINT.Ndown,
            estimate=exact_thermal.target_sector_probability,
            reference=target_sector_threshold,
            absolute_error=target_sector_passed ? 0.0 :
                target_sector_threshold - exact_thermal.target_sector_probability,
            allowed_error=0.0,
            passed=target_sector_passed,
            required=true,
            note="exact grand-canonical probability of the same fixed spin sector " *
                 "used by CP-AFQMC must be strictly greater than 0.9999",
        ))
        if !isnothing(periodic_exact)
            _numeric_check!(checks;
                check_id="thermal_to_ground_energy_bridge",
                stage="exact_thermal_bridge",
                profile=profile,
                system="periodic_L2_two_orbital",
                boundary="periodic",
                method="grand-canonical ED vs fixed-sector ED",
                quantity="internal_energy_per_cell",
                U=DQMC_BRIDGE_POINT.U,
                beta=DQMC_BRIDGE_POINT.beta,
                mu=DQMC_BRIDGE_POINT.mu,
                estimate=exact_thermal.internal_energy_per_cell,
                reference=periodic_exact.energy / 4,
                floor=5.0e-4,
                note="this small exact gap makes the CP-to-DQMC comparison meaningful",
            )
        end
    catch error
        _error_check!(checks, profile, "exact_thermal_bridge",
            "periodic_L2_two_orbital", "factorized grand-canonical ED", error;
            boundary="periodic", check_id="thermal_ed_completed")
    end

    dqmc_records = NamedTuple[]
    if !isnothing(exact_thermal)
        for dtau in plan.dqmc_dtaus, base_seed in plan.dqmc_seeds
            seed = base_seed + options.seed_offset
            try
                push!(dqmc_records, _run_dqmc!(
                    runs, samples, checks, profile, plan, dtau, seed,
                    exact_thermal,
                ))
            catch error
                run_id = "dqmc_L2_U2_dt$(dtau)_seed$(seed)"
                _failed_run!(runs, checks, profile, run_id,
                    "finite-temperature DQMC", "periodic_L2_two_orbital",
                    "periodic", error; U=2.0, dtau=dtau, seed=seed)
            end
        end
    end

    dqmc_bridge_summary = nothing
    if !isempty(dqmc_records)
        fine_dtau = minimum(plan.dqmc_dtaus)
        coarse_dtau = maximum(plan.dqmc_dtaus)
        fine_by_seed = Dict(
            record.seed => record for record in dqmc_records
            if record.dtau == fine_dtau
        )
        coarse_by_seed = Dict(
            record.seed => record for record in dqmc_records
            if record.dtau == coarse_dtau
        )
        expected_seeds = sort!(collect(plan.dqmc_seeds) .+ options.seed_offset)
        matched_seeds = sort!(collect(intersect(
            Set(keys(fine_by_seed)), Set(keys(coarse_by_seed)),
        )))
        _boolean_check!(checks;
            value=matched_seeds == expected_seeds,
            check_id="dqmc_matched_seed_dtau_grid",
            stage="dqmc_convergence_summary",
            profile=profile,
            system="periodic_L2_two_orbital",
            boundary="periodic",
            method="finite-temperature DQMC",
            quantity="matched_seed_coarse_and_fine_dtau_grid_complete",
            U=DQMC_BRIDGE_POINT.U,
            beta=DQMC_BRIDGE_POINT.beta,
            mu=DQMC_BRIDGE_POINT.mu,
            note="the time-step check requires every independent seed at both " *
                 "the coarsest and finest dtau",
        )
        if !isempty(matched_seeds) && fine_dtau < coarse_dtau
            try
                paired_shifts = [
                    fine_by_seed[seed].summary.internal_energy_per_cell -
                    coarse_by_seed[seed].summary.internal_energy_per_cell
                    for seed in matched_seeds
                ]
                paired_errors = [
                    hypot(
                        fine_by_seed[seed].summary.internal_energy_per_cell_standard_error,
                        coarse_by_seed[seed].summary.internal_energy_per_cell_standard_error,
                    ) for seed in matched_seeds
                ]
                shift_pool = _pool_independent_estimates(
                    paired_shifts, paired_errors,
                )
                shift_floor = profile == :quick ? 0.15 : 0.04
                _numeric_check!(checks;
                    check_id="dqmc_dtau_shift",
                    stage="dqmc_convergence_summary",
                    profile=profile,
                    system="periodic_L2_two_orbital",
                    boundary="periodic",
                    method="finite-temperature DQMC",
                    quantity="coarse_to_fine_internal_energy_shift_per_cell",
                    U=DQMC_BRIDGE_POINT.U,
                    beta=DQMC_BRIDGE_POINT.beta,
                    mu=DQMC_BRIDGE_POINT.mu,
                    dtau=fine_dtau,
                    estimate=abs(shift_pool.mean),
                    standard_error=shift_pool.standard_error,
                    reference=0.0,
                    floor=shift_floor,
                    sigma=plan.sigma_gate,
                    precision_ceiling=shift_floor / 2,
                    note="paired finest-minus-coarsest shift at matched seeds; " *
                         "the pool uses the larger of its within-chain and " *
                         "across-seed error estimates",
                )
            catch error
                _error_check!(checks, profile, "dqmc_convergence_summary",
                    "periodic_L2_two_orbital", "finite-temperature DQMC",
                    error; boundary="periodic", check_id="dqmc_dtau_shift")
            end
        end

        if profile == :standard
            energy_pools = Dict{Float64,Any}()
            density_pools = Dict{Float64,Any}()
            expected_seed_count_ok = length(expected_seeds) == 2 &&
                length(unique(expected_seeds)) == 2
            _boolean_check!(checks;
                value=expected_seed_count_ok,
                check_id="dqmc_standard_seed_pair_configured",
                stage="dqmc_seed_consistency",
                profile=profile,
                system="periodic_L2_two_orbital",
                boundary="periodic",
                method="finite-temperature DQMC",
                quantity="exactly_two_distinct_standard_seeds_configured",
                U=DQMC_BRIDGE_POINT.U,
                beta=DQMC_BRIDGE_POINT.beta,
                mu=DQMC_BRIDGE_POINT.mu,
                note="matched-seed consistency is a two-independent-chain check " *
                     "at every DQMC dtau",
            )
            for dtau in plan.dqmc_dtaus
                selected = [record for record in dqmc_records
                            if record.dtau == dtau]
                actual_seeds = sort!([record.seed for record in selected])
                complete = expected_seed_count_ok &&
                    actual_seeds == expected_seeds
                _boolean_check!(checks;
                    value=complete,
                    check_id="dqmc_dt$(dtau)_matched_seed_grid",
                    stage="dqmc_seed_consistency",
                    profile=profile,
                    system="periodic_L2_two_orbital",
                    boundary="periodic",
                    method="finite-temperature DQMC",
                    quantity="matched_seed_pair_complete_at_dtau",
                    U=DQMC_BRIDGE_POINT.U,
                    beta=DQMC_BRIDGE_POINT.beta,
                    mu=DQMC_BRIDGE_POINT.mu,
                    dtau=dtau,
                    note="requires exactly the two prespecified distinct seeds; " *
                         "missing and duplicate records fail",
                )
                complete || continue

                by_seed = Dict(record.seed => record for record in selected)
                first_record = by_seed[expected_seeds[1]]
                second_record = by_seed[expected_seeds[2]]
                for (quantity, first_value, first_error,
                     second_value, second_error, precision_ceiling) in (
                    (
                        :density,
                        first_record.summary.density,
                        first_record.density_consistency_standard_error,
                        second_record.summary.density,
                        second_record.density_consistency_standard_error,
                        plan.dqmc_density_consistency_precision,
                    ),
                    (
                        :internal_energy_per_cell,
                        first_record.summary.internal_energy_per_cell,
                        first_record.energy_consistency_standard_error,
                        second_record.summary.internal_energy_per_cell,
                        second_record.energy_consistency_standard_error,
                        plan.dqmc_energy_consistency_precision,
                    ),
                )
                    try
                        difference = _difference_with_error(
                            first_value,
                            first_error,
                            second_value,
                            second_error,
                        )
                        _statistical_consistency_check!(checks;
                            check_id="dqmc_dt$(dtau):" * String(quantity) *
                                "_seed_consistency",
                            stage="dqmc_seed_consistency",
                            profile=profile,
                            system="periodic_L2_two_orbital",
                            boundary="periodic",
                            method="finite-temperature DQMC",
                            quantity=String(quantity) *
                                "_first_seed_minus_second_seed",
                            U=DQMC_BRIDGE_POINT.U,
                            beta=DQMC_BRIDGE_POINT.beta,
                            mu=DQMC_BRIDGE_POINT.mu,
                            dtau=dtau,
                            estimate=difference.difference,
                            standard_error=difference.standard_error,
                            reference=0.0,
                            sigma=plan.dqmc_random_difference_sigma,
                            precision_ceiling=precision_ceiling,
                            note="two independent chains at the same dtau; " *
                                 "blocked sign-reweighted errors combine with " *
                                 "hypot; agreement must satisfy the sigma " *
                                 "limit and the separate error ceiling",
                        )
                    catch error
                        _error_check!(checks, profile,
                            "dqmc_seed_consistency",
                            "periodic_L2_two_orbital",
                            "finite-temperature DQMC", error;
                            boundary="periodic",
                            check_id="dqmc_dt$(dtau):" * String(quantity) *
                                "_seed_consistency")
                    end
                end

                try
                    density_pools[Float64(dtau)] =
                        _pool_independent_estimates(
                            [record.summary.density for record in selected],
                            [record.density_consistency_standard_error
                             for record in selected],
                        )
                    energy_pools[Float64(dtau)] =
                        _pool_independent_estimates(
                            [record.summary.internal_energy_per_cell
                             for record in selected],
                            [record.energy_consistency_standard_error
                             for record in selected],
                        )
                catch error
                    _error_check!(checks, profile, "dqmc_seed_pooling",
                        "periodic_L2_two_orbital",
                        "finite-temperature DQMC", error;
                        boundary="periodic",
                        check_id="dqmc_dt$(dtau):seed_pooling")
                end
            end

            fit_grid_complete = length(plan.dqmc_dtaus) == 3 &&
                length(unique(plan.dqmc_dtaus)) == 3 &&
                all(dtau -> haskey(energy_pools, Float64(dtau)) &&
                    haskey(density_pools, Float64(dtau)), plan.dqmc_dtaus)
            _boolean_check!(checks;
                value=fit_grid_complete,
                check_id="dqmc_dtau_squared_fit_grid",
                stage="dqmc_dtau_extrapolation",
                profile=profile,
                system="periodic_L2_two_orbital",
                boundary="periodic",
                method="finite-temperature DQMC",
                quantity="three_dtau_seed_pools_complete",
                U=DQMC_BRIDGE_POINT.U,
                beta=DQMC_BRIDGE_POINT.beta,
                mu=DQMC_BRIDGE_POINT.mu,
                note="requires seed-pooled estimates at all three standard " *
                     "dtau values before fitting a + b*dtau^2",
            )
            if fit_grid_complete
                try
                    fit_dtaus = Float64.(collect(plan.dqmc_dtaus))
                    fit = _weighted_dtau_squared_fit(
                        fit_dtaus,
                        [energy_pools[dtau].mean for dtau in fit_dtaus],
                        [energy_pools[dtau].standard_error
                         for dtau in fit_dtaus],
                    )
                    fit_quality_passed =
                        isfinite(fit.reduced_chi_squared) &&
                        fit.reduced_chi_squared <=
                            plan.dqmc_extrapolation_maximum_reduced_chi_squared
                    push!(checks, _check_row(
                        check_id="dqmc_dtau_squared_fit_quality",
                        stage="dqmc_dtau_extrapolation",
                        profile=profile,
                        system="periodic_L2_two_orbital",
                        boundary="periodic",
                        method="finite-temperature DQMC",
                        quantity="reduced_chi_squared",
                        U=DQMC_BRIDGE_POINT.U,
                        beta=DQMC_BRIDGE_POINT.beta,
                        mu=DQMC_BRIDGE_POINT.mu,
                        estimate=fit.reduced_chi_squared,
                        reference=0.0,
                        absolute_error=fit.reduced_chi_squared,
                        allowed_error=
                            plan.dqmc_extrapolation_maximum_reduced_chi_squared,
                        passed=fit_quality_passed,
                        required=true,
                        note="three seed-pooled energies fit to a + b*dtau^2 " *
                             "with inverse-variance weights; dof=1",
                    ))
                    _strict_consistency_check!(checks;
                        check_id="dqmc_dtau_squared_intercept_vs_thermal_ed",
                        stage="dqmc_dtau_extrapolation",
                        profile=profile,
                        system="periodic_L2_two_orbital",
                        boundary="periodic",
                        method="finite-temperature DQMC",
                        quantity="zero_dtau_internal_energy_per_cell",
                        U=DQMC_BRIDGE_POINT.U,
                        beta=DQMC_BRIDGE_POINT.beta,
                        mu=DQMC_BRIDGE_POINT.mu,
                        dtau=0.0,
                        estimate=fit.intercept,
                        standard_error=fit.intercept_standard_error,
                        reference=exact_thermal.internal_energy_per_cell,
                        absolute_cap=plan.dqmc_extrapolation_floor,
                        sigma=plan.dqmc_consistency_sigma,
                        precision_ceiling=plan.dqmc_extrapolation_precision,
                        note="weighted linear extrapolation in dtau^2 using all " *
                             "three standard values; each point is an unweighted " *
                             "pool of the two seeds and the intercept covariance " *
                             "is propagated, with max(1,reduced chi-squared) " *
                             "variance scaling",
                    )
                    dqmc_bridge_summary = (
                        mean=fit.intercept,
                        standard_error=fit.intercept_standard_error,
                        method="three-point weighted dtau^2 intercept",
                    )
                catch error
                    _error_check!(checks, profile,
                        "dqmc_dtau_extrapolation",
                        "periodic_L2_two_orbital",
                        "finite-temperature DQMC", error;
                        boundary="periodic",
                        check_id="dqmc_dtau_squared_fit_completed")
                end
            end
        else
            finest_dqmc_dtau = minimum(plan.dqmc_dtaus)
            selected = [record for record in dqmc_records
                        if record.dtau == finest_dqmc_dtau]
            if !isempty(selected) && all(record ->
                record.summary.internal_energy_per_cell isa Real &&
                record.energy_consistency_standard_error isa Real,
                selected)
                dqmc_pool = _pool_independent_estimates(
                    [record.summary.internal_energy_per_cell
                     for record in selected],
                    [record.energy_consistency_standard_error
                     for record in selected],
                )
                dqmc_bridge_summary = (
                    mean=dqmc_pool.mean,
                    standard_error=dqmc_pool.standard_error,
                    method="finest-dtau seed pool",
                )
            end
        end
    end

    if !isnothing(fine_cp_summary) && !isnothing(dqmc_bridge_summary)
            dqmc_mean = dqmc_bridge_summary.mean
            dqmc_se = dqmc_bridge_summary.standard_error
            cp_se = fine_cp_summary.standard_error_per_cell
            combined_se = hypot(cp_se, dqmc_se)
            _numeric_check!(checks;
                check_id="cp_vs_dqmc_energy_bridge",
                stage="cross_method_bridge",
                profile=profile,
                system="periodic_L2_two_orbital",
                boundary="periodic",
                method="CP-AFQMC vs finite-temperature DQMC",
                quantity="internal_energy_per_cell",
                U=DQMC_BRIDGE_POINT.U,
                beta=DQMC_BRIDGE_POINT.beta,
                mu=DQMC_BRIDGE_POINT.mu,
                estimate=fine_cp_summary.energy_per_cell,
                standard_error=combined_se,
                reference=dqmc_mean,
                floor=profile == :quick ? 0.12 : 0.06,
                sigma=plan.sigma_gate,
                precision_ceiling=(profile == :quick ? 0.12 : 0.06) / 2,
                note="fixed-N ground CP and grand-canonical beta=10 DQMC are joined " *
                     "only after the exact ED ensemble bridge passes; each method " *
                     "uses a free-trial unweighted mean over independent seeds, " *
                     "with the larger of its within-chain and across-seed error " *
                     "estimates; " *
                     "DQMC bridge estimate=" * dqmc_bridge_summary.method,
            )
    end

    isempty(runs) && push!(runs, _run_row(
        run_id="no_stochastic_runs", method="none", system="none",
        boundary="none", status="error", note="no stochastic run completed",
    ))
    isempty(samples) && push!(samples, _sample_row(
        run_id="no_samples", sample=0,
    ))
    output = _write_output(
        options.output_dir, options, plan, checks, runs, samples,
    )
    return (
        passed=output.passed,
        output_dir=output.output_dir,
        checks=checks,
        runs=runs,
        samples=samples,
        plan=plan,
    )
end

function main(arguments=ARGS)
    options = parse_options(arguments)
    if isnothing(options)
        print(HELP)
        return nothing
    end
    result = run_validation(options)
    required = count(check -> check.required, result.checks)
    passed = count(check -> check.required && check.passed, result.checks)
    println("Saved validation output to ", result.output_dir)
    println("Required checks passed: ", passed, "/", required)
    println("Overall result: ", result.passed ? "PASS" : "FAIL")
    return result
end

end

if abspath(PROGRAM_FILE) == @__FILE__
    result = try
        ValidateConstrainedPathAFQMC.main()
    catch error
        showerror(stderr, error, catch_backtrace())
        println(stderr)
        exit(2)
    end
    if !isnothing(result) && !result.passed
        exit(1)
    end
end
