#!/usr/bin/env julia

# Compare a zero-hopping DQMC dataset with a 16-state exact diagonalization of
# one two-orbital Hubbard atom. Every cell and orbital is independent in this
# limit, so the one-cell ED values are exact at any lattice size.

using LinearAlgebra

import JDQMCMeasurements as jdqmcm

include(joinpath(@__DIR__, "two_orbital_observable_tools.jl"))
include(joinpath(@__DIR__, "two_orbital_atom_ed.jl"))
using .TwoOrbitalObservableTools
using .TwoOrbitalAtomED

length(ARGS) == 1 || error(
    "Usage: julia --project=. validate_two_orbital_exact_benchmarks.jl DATA.jls",
)

payload = load_observable_payload(ARGS[1])
metadata = payload["metadata"]
get(metadata, "atomic_check", false) || error(
    "the supplied run was not made with --atomic-check",
)
all(iszero, (metadata["t1"], metadata["t2"], metadata["t3"], metadata["t4"])) ||
    error("the atomic ED benchmark requires all hoppings to be zero")

U = metadata["U"]
beta = metadata["beta"]
mu = metadata["mu_measured"]
L = metadata["L"]
tau = payload["tau"]
exact = solve_two_orbital_atom(U, mu, beta, tau)

basic = payload["basic_bins"]
sign_bins = basic["average_sign"]

function ratio_result(numerator_bins)
    estimate, standard_error = jdqmcm.jackknife(
        /,
        numerator_bins,
        sign_bins,
    )
    return (estimate=real(estimate), standard_error=standard_error)
end

function compare_scalar(name, measured, exact_value; absolute_floor=1.0e-3)
    difference = abs(measured.estimate - exact_value)
    tolerance = max(5 * measured.standard_error, absolute_floor)
    passed = isfinite(difference) && difference <= tolerance
    println(
        rpad(name, 30),
        " DQMC = ", measured.estimate,
        " +/- ", measured.standard_error,
        "   ED = ", exact_value,
        "   ", passed ? "PASS" : "FAIL",
    )
    return passed
end

density = ratio_result(basic["density"])
double_occupancy = ratio_result(basic["double_occupancy"])
altermagnetic = payload["altermagnetic_signed_bins"]
S_alm = ratio_result(view(altermagnetic, :, 5))
m_alm_squared = ratio_result(view(altermagnetic, :, 6))

checks = Bool[]
push!(checks, compare_scalar("Density per cell", density, exact.density))
push!(checks, compare_scalar(
    "Double occupancy (2 orbitals)",
    double_occupancy,
    exact.double_occupancy,
))
push!(checks, compare_scalar(
    "S_alm(q=0)",
    S_alm,
    exact.S_alm_q0,
))
push!(checks, compare_scalar(
    "m_alm^2",
    m_alm_squared,
    exact.S_alm_q0 / L^2,
))

green_bins = payload["green_signed_momentum_bins"]
green_bins === nothing && error(
    "the exact Green benchmark requires a run made with --measure-greens",
)
# Normalize the spin/orbital trace to one fermion mode. Its spectral zeroth
# moment is one and it can be fed directly to a positive continuation kernel.
normalized_trace_bins = trace_green_channel(payload) ./ 4
green_statistics = sign_reweighted_channel_statistics(
    normalized_trace_bins,
    payload["green_sign_sums"],
    payload["green_counts"];
    minimum_average_sign=0.0,
)
green_statistics.values === missing && error(
    "the Green sign denominator is unusable",
)
green_statistics.standard_errors === missing && error(
    "the Green jackknife covariance is unusable",
)
measured_green = real.(green_statistics.values)
green_error = abs.(measured_green .- exact.green)
green_tolerance = max.(
    5 .* green_statistics.standard_errors,
    5.0e-3,
)
green_passed = all(green_error .<= green_tolerance)
endpoint_error = abs(measured_green[1] + measured_green[end] - 1)
endpoint_passed = endpoint_error <= max(
    5 * hypot(
        green_statistics.standard_errors[1],
        green_statistics.standard_errors[end],
    ),
    5.0e-3,
)
push!(checks, green_passed)
push!(checks, endpoint_passed)

# The trace is the continuation input, but also check every diagonal spin,
# orbital, and momentum channel so cancellations cannot hide a convention bug.
maximum_diagonal_error = 0.0
maximum_diagonal_error_ratio = 0.0
all_diagonal_channels_passed = true
for spin in 1:2, orbital in 1:2, kx in 1:L, ky in 1:L
    channel_statistics = sign_reweighted_channel_statistics(
        green_bins[:, spin, orbital, orbital, kx, ky, :],
        payload["green_sign_sums"],
        payload["green_counts"];
        minimum_average_sign=0.0,
    )
    channel_error = abs.(real.(channel_statistics.values) .- exact.green)
    channel_tolerance = max.(
        5 .* channel_statistics.standard_errors,
        5.0e-3,
    )
    global maximum_diagonal_error = max(
        maximum_diagonal_error,
        maximum(channel_error),
    )
    global maximum_diagonal_error_ratio = max(
        maximum_diagonal_error_ratio,
        maximum(channel_error ./ channel_tolerance),
    )
    global all_diagonal_channels_passed &=
        all(channel_error .<= channel_tolerance)
end

# Zero hopping cannot mix the two orbitals, so every off-diagonal channel must
# vanish configuration by configuration up to floating-point roundoff.
maximum_offdiagonal = 0.0
for spin in 1:2, destination in 1:2, source in 1:2
    destination == source && continue
    for kx in 1:L, ky in 1:L
        channel_statistics = sign_reweighted_channel_statistics(
            green_bins[:, spin, destination, source, kx, ky, :],
            payload["green_sign_sums"],
            payload["green_counts"];
            minimum_average_sign=0.0,
        )
        global maximum_offdiagonal = max(
            maximum_offdiagonal,
            maximum(abs, channel_statistics.values),
        )
    end
end
offdiagonal_passed = maximum_offdiagonal <= 1.0e-10
push!(checks, all_diagonal_channels_passed)
push!(checks, offdiagonal_passed)

println(
    rpad("G_loc(tau), max error", 30),
    " DQMC-ED = ", maximum(green_error),
    "   ", green_passed ? "PASS" : "FAIL",
)
println(
    rpad("G(0)+G(beta)=1", 30),
    " error = ", endpoint_error,
    "   ", endpoint_passed ? "PASS" : "FAIL",
)
println(
    rpad("All diagonal G channels", 30),
    " max error = ", maximum_diagonal_error,
    "; max error/tolerance = ", maximum_diagonal_error_ratio,
    "   ", all_diagonal_channels_passed ? "PASS" : "FAIL",
)
println(
    rpad("Off-diagonal orbital G", 30),
    " max magnitude = ", maximum_offdiagonal,
    "   ", offdiagonal_passed ? "PASS" : "FAIL",
)
println("Exact spectral peak frequencies = ", exact.peak_frequencies)
println("Exact spectral peak weights = ", exact.peak_weights)
println("Exact spectral zeroth moment = ", exact.spectral_zeroth_moment)
println("ED Hilbert-space dimension = ", exact.hilbert_dimension)

if all(checks)
    println("Exact interacting Hubbard-atom benchmark PASSED")
else
    error("Exact interacting Hubbard-atom benchmark FAILED")
end
