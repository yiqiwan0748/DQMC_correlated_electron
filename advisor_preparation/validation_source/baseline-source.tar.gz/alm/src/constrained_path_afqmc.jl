using FFTW: fft
using LinearAlgebra: Diagonal, Symmetric, dot, eigen, inv, issymmetric, logabsdet,
                     opnorm, qr
using Random: AbstractRNG, Xoshiro, rand, shuffle!

"""
    CPAFQMCProblem(kinetic, U, Nup, Ndown; lattice_size=nothing,
                   cell_count=size(kinetic, 1))

Fixed-particle real Hubbard problem for constrained-path AFQMC. `kinetic` is
the one-spin hopping matrix and every row is one interacting spatial mode.
For the two-orbital square model, set `lattice_size=L` and `cell_count=L^2`.
"""
struct CPAFQMCProblem{T<:AbstractFloat}
    kinetic::Matrix{T}
    U::T
    Nup::Int
    Ndown::Int
    lattice_size::Union{Nothing,Int}
    cell_count::Int
end

function CPAFQMCProblem(
    kinetic::AbstractMatrix{<:Real},
    U::Real,
    Nup::Integer,
    Ndown::Integer;
    lattice_size::Union{Nothing,Integer}=nothing,
    cell_count::Integer=size(kinetic, 1),
)
    size(kinetic, 1) == size(kinetic, 2) ||
        throw(DimensionMismatch("kinetic must be square"))
    issymmetric(kinetic) ||
        throw(ArgumentError("real constrained-path AFQMC requires symmetric kinetic"))
    all(isfinite, kinetic) ||
        throw(ArgumentError("kinetic entries must be finite"))
    isfinite(U) && U >= 0 ||
        throw(ArgumentError("U must be finite and nonnegative"))
    (Nup isa Bool || Ndown isa Bool) &&
        throw(ArgumentError("Nup and Ndown must be particle counts"))
    dimension = size(kinetic, 1)
    0 <= Nup <= dimension || throw(ArgumentError("Nup must lie in 0:M"))
    0 <= Ndown <= dimension || throw(ArgumentError("Ndown must lie in 0:M"))
    cells = Int(cell_count)
    cells > 0 || throw(ArgumentError("cell_count must be positive"))
    L = isnothing(lattice_size) ? nothing : Int(lattice_size)
    if !isnothing(L)
        L > 0 || throw(ArgumentError("lattice_size must be positive"))
        dimension == 2 * L^2 || throw(DimensionMismatch(
            "a two-orbital L-by-L problem must have kinetic size 2L^2",
        ))
        cells == L^2 || throw(ArgumentError(
            "cell_count must equal L^2 when lattice_size is supplied",
        ))
    end
    T = promote_type(
        typeof(float(U)),
        typeof(float(zero(eltype(kinetic)))),
    )
    return CPAFQMCProblem{T}(
        Matrix{T}(kinetic), convert(T, U), Int(Nup), Int(Ndown), L, cells,
    )
end

"""Construct the periodic two-orbital problem with the repository's hopping convention."""
function two_orbital_cp_afqmc_problem(
    L::Integer,
    U::Real,
    Nup::Integer,
    Ndown::Integer;
    model_parameters::ModelParameters=DEFAULT_PARAMETERS,
)
    lattice_size = _checked_lattice_size(L)
    return CPAFQMCProblem(
        realspace_kinetic_matrix(lattice_size, model_parameters),
        U,
        Nup,
        Ndown;
        lattice_size=lattice_size,
        cell_count=lattice_size^2,
    )
end

"""Two spin-separated Slater determinants used to impose the path constraint."""
struct SlaterTrial{T<:AbstractFloat}
    up::Matrix{T}
    down::Matrix{T}
    label::String
    pattern::Symbol
    field_strength::Union{Missing,T}
    up_shell_gap::Union{Missing,T}
    down_shell_gap::Union{Missing,T}
end

function _cp_canonical_columns(matrix::AbstractMatrix{T}) where {T<:AbstractFloat}
    rows, columns = size(matrix)
    columns == 0 && return zeros(T, rows, 0)
    columns <= rows || throw(DimensionMismatch(
        "a Slater matrix cannot have more columns than rows",
    ))
    factorization = qr(Matrix{T}(matrix))
    Q = Matrix(factorization.Q[:, 1:columns])
    R = Matrix(factorization.R)
    tolerance = 64 * eps(T) * max(one(T), maximum(abs, R))
    for column in 1:columns
        abs(R[column, column]) > tolerance || throw(ArgumentError(
            "Slater matrix columns must be linearly independent",
        ))
        if R[column, column] < zero(T)
            @views Q[:, column] .*= -one(T)
        end
    end
    return Q
end

function SlaterTrial(
    up::AbstractMatrix{<:Real},
    down::AbstractMatrix{<:Real};
    label::AbstractString="custom",
)
    size(up, 1) == size(down, 1) || throw(DimensionMismatch(
        "the up and down trial matrices must have the same row count",
    ))
    all(isfinite, up) && all(isfinite, down) ||
        throw(ArgumentError("trial-state entries must be finite"))
    T = promote_type(
        typeof(float(zero(eltype(up)))),
        typeof(float(zero(eltype(down)))),
    )
    return SlaterTrial{T}(
        _cp_canonical_columns(Matrix{T}(up)),
        _cp_canonical_columns(Matrix{T}(down)),
        String(label),
        :custom,
        missing,
        missing,
        missing,
    )
end

function _cp_shell_gap(values::AbstractVector{T}, particles::Int) where {T}
    particles == 0 && return missing
    particles == length(values) && return missing
    return values[particles + 1] - values[particles]
end

function _cp_trial_pattern(
    problem::CPAFQMCProblem{T},
    pattern::Symbol,
) where {T}
    dimension = size(problem.kinetic, 1)
    pattern == :free && return zeros(T, dimension)
    L = problem.lattice_size
    isnothing(L) && throw(ArgumentError(
        "non-free trial patterns require a two-orbital lattice_size",
    ))
    field = Vector{T}(undef, dimension)
    for y in 1:L, x in 1:L, orbital in 1:2
        index = single_particle_index(x, y, orbital, L)
        field[index] = if pattern == :altermagnetic
            orbital == 1 ? one(T) : -one(T)
        elseif pattern == :stripe_x
            isodd(x - 1) ? -one(T) : one(T)
        elseif pattern == :stripe_y
            isodd(y - 1) ? -one(T) : one(T)
        elseif pattern == :neel
            isodd(x + y) ? one(T) : -one(T)
        else
            throw(ArgumentError(
                "pattern must be :free, :altermagnetic, :stripe_x, :stripe_y, or :neel",
            ))
        end
    end
    return field
end

"""
    one_body_trial(problem; pattern=:free, field_strength=1e-3)

Build a real spin-separated trial determinant. A nonzero field is used only
to choose the trial orbitals; it is not added to the projected Hamiltonian.
Ordinary ferromagnetism must be tested by changing `(Nup,Ndown)` at fixed `N`.
"""
function one_body_trial(
    problem::CPAFQMCProblem{T};
    pattern::Symbol=:free,
    field_strength::Real=1.0e-3,
) where {T}
    isfinite(field_strength) ||
        throw(ArgumentError("field_strength must be finite"))
    pattern_vector = _cp_trial_pattern(problem, pattern)
    h = convert(T, field_strength)
    one_body_up = problem.kinetic - Diagonal(h .* pattern_vector)
    one_body_down = problem.kinetic + Diagonal(h .* pattern_vector)
    decomposition_up = eigen(Symmetric(one_body_up))
    decomposition_down = eigen(Symmetric(one_body_down))
    vectors_up = decomposition_up.vectors
    vectors_down = decomposition_down.vectors
    up = problem.Nup == 0 ? zeros(T, size(problem.kinetic, 1), 0) :
         vectors_up[:, 1:problem.Nup]
    down = problem.Ndown == 0 ? zeros(T, size(problem.kinetic, 1), 0) :
           vectors_down[:, 1:problem.Ndown]
    signed_field = pattern == :free ? zero(T) : h
    label = pattern == :free ? "free" :
        string(pattern, "(h=", signed_field, ")")
    return SlaterTrial{T}(
        _cp_canonical_columns(up),
        _cp_canonical_columns(down),
        label,
        pattern,
        signed_field,
        _cp_shell_gap(decomposition_up.values, problem.Nup),
        _cp_shell_gap(decomposition_down.values, problem.Ndown),
    )
end

"""Numerical controls for one constrained-path projection."""
struct CPAFQMCParameters{T<:AbstractFloat}
    dtau::T
    walker_count::Int
    warmup_steps::Int
    measurement_count::Int
    steps_between_measurements::Int
    orthogonalize_every::Int
    population_control_every::Int
    overlap_refresh_every::Int
    back_propagation_steps::Int
    minimum_backprop_ancestors::Int
    error_block_size::Int
    seed::Int
end

function CPAFQMCParameters(;
    dtau::Real=0.02,
    walker_count::Integer=200,
    warmup_steps::Integer=200,
    measurement_count::Integer=40,
    steps_between_measurements::Integer=5,
    orthogonalize_every::Integer=5,
    population_control_every::Integer=5,
    overlap_refresh_every::Integer=16,
    back_propagation_steps::Integer=20,
    minimum_backprop_ancestors::Integer=2,
    error_block_size::Integer=5,
    seed::Integer=1234,
)
    time_step = float(dtau)
    T = typeof(time_step)
    isfinite(time_step) && time_step > zero(T) ||
        throw(ArgumentError("dtau must be finite and positive"))
    walker_count >= 2 || throw(ArgumentError("walker_count must be at least two"))
    warmup_steps >= 0 || throw(ArgumentError("warmup_steps must be nonnegative"))
    measurement_count > 0 ||
        throw(ArgumentError("measurement_count must be positive"))
    steps_between_measurements > 0 || throw(ArgumentError(
        "steps_between_measurements must be positive",
    ))
    orthogonalize_every > 0 ||
        throw(ArgumentError("orthogonalize_every must be positive"))
    population_control_every > 0 || throw(ArgumentError(
        "population_control_every must be positive",
    ))
    overlap_refresh_every > 0 ||
        throw(ArgumentError("overlap_refresh_every must be positive"))
    back_propagation_steps >= 0 || throw(ArgumentError(
        "back_propagation_steps must be nonnegative",
    ))
    minimum_backprop_ancestors > 0 || throw(ArgumentError(
        "minimum_backprop_ancestors must be positive",
    ))
    minimum_backprop_ancestors <= walker_count || throw(ArgumentError(
        "minimum_backprop_ancestors must not exceed walker_count",
    ))
    error_block_size > 0 ||
        throw(ArgumentError("error_block_size must be positive"))
    measurement_count % error_block_size == 0 || throw(ArgumentError(
        "error_block_size must divide measurement_count",
    ))
    return CPAFQMCParameters{T}(
        time_step,
        Int(walker_count),
        Int(warmup_steps),
        Int(measurement_count),
        Int(steps_between_measurements),
        Int(orthogonalize_every),
        Int(population_control_every),
        Int(overlap_refresh_every),
        Int(back_propagation_steps),
        Int(minimum_backprop_ancestors),
        Int(error_block_size),
        Int(seed),
    )
end

mutable struct _CPWalker{T<:AbstractFloat}
    up::Matrix{T}
    down::Matrix{T}
    log_weight::T
    log_overlap::T
    alive::Bool
    anchor_up::Matrix{T}
    anchor_down::Matrix{T}
    anchor_id::Int
    fields::Vector{Vector{Int8}}
    field_end_ids::Vector{Int}
end

"""Mutable constrained-path population state, exposed for controlled tests and restarts."""
mutable struct CPAFQMCState{T<:AbstractFloat,R<:AbstractRNG}
    problem::CPAFQMCProblem{T}
    parameters::CPAFQMCParameters{T}
    trial::SlaterTrial{T}
    walkers::Vector{_CPWalker{T}}
    kinetic_half::Matrix{T}
    gamma::T
    rng::R
    site_order::Vector{Int}
    step::Int
    next_lineage_id::Int
    constraint_rejections::Int
    killed_walkers::Int
    population_controls::Int
    overlap_inverse_failures::Int
    maximum_overlap_condition::T
end

function _cp_component_log_overlap(
    left::AbstractMatrix{T},
    right::AbstractMatrix{T},
) where {T<:AbstractFloat}
    size(left) == size(right) ||
        throw(DimensionMismatch("left and right Slater matrices must match"))
    size(left, 2) == 0 && return (zero(T), 1)
    log_magnitude, overlap_sign = logabsdet(transpose(left) * right)
    sign_integer = overlap_sign > zero(T) ? 1 : overlap_sign < zero(T) ? -1 : 0
    return (convert(T, log_magnitude), sign_integer)
end

function _cp_combined_log_overlap(
    trial::SlaterTrial{T},
    up::AbstractMatrix{T},
    down::AbstractMatrix{T},
) where {T<:AbstractFloat}
    log_up, sign_up = _cp_component_log_overlap(trial.up, up)
    log_down, sign_down = _cp_component_log_overlap(trial.down, down)
    return (log_up + log_down, sign_up * sign_down)
end

"""
    transition_density_matrix(left, right)

Return `C[i,j] = <left|c_j^dagger c_i|right>/<left|right>` for two Slater
determinants with the same particle number.
"""
function transition_density_matrix(
    left::AbstractMatrix{<:Real},
    right::AbstractMatrix{<:Real},
)
    size(left) == size(right) ||
        throw(DimensionMismatch("left and right Slater matrices must match"))
    T = promote_type(
        typeof(float(zero(eltype(left)))),
        typeof(float(zero(eltype(right)))),
    )
    rows, columns = size(left)
    columns == 0 && return zeros(T, rows, rows)
    left_typed = Matrix{T}(left)
    right_typed = Matrix{T}(right)
    overlap = transpose(left_typed) * right_typed
    return right_typed * (overlap \ transpose(left_typed))
end

function _cp_local_energy_from_densities(
    problem::CPAFQMCProblem{T},
    density_up::AbstractMatrix{T},
    density_down::AbstractMatrix{T},
) where {T}
    kinetic_energy = zero(T)
    for row in axes(problem.kinetic, 1), column in axes(problem.kinetic, 2)
        kinetic_energy += problem.kinetic[row, column] *
            (density_up[column, row] + density_down[column, row])
    end
    double_occupancy = zero(T)
    centered_interaction = zero(T)
    half = one(T) / 2
    for index in axes(problem.kinetic, 1)
        nup = density_up[index, index]
        ndown = density_down[index, index]
        double_occupancy += nup * ndown
        centered_interaction += (nup - half) * (ndown - half)
    end
    interaction_energy = problem.U * centered_interaction
    return (
        total=kinetic_energy + interaction_energy,
        kinetic=kinetic_energy,
        interaction=interaction_energy,
        double_occupancy=double_occupancy,
    )
end

"""Evaluate the mixed local energy between supplied left and right determinants."""
function mixed_local_energy(
    problem::CPAFQMCProblem{T},
    left_up::AbstractMatrix{<:Real},
    left_down::AbstractMatrix{<:Real},
    right_up::AbstractMatrix{<:Real},
    right_down::AbstractMatrix{<:Real},
) where {T}
    density_up = Matrix{T}(transition_density_matrix(left_up, right_up))
    density_down = Matrix{T}(transition_density_matrix(left_down, right_down))
    return _cp_local_energy_from_densities(problem, density_up, density_down)
end

function _cp_validate_trial(
    problem::CPAFQMCProblem{T},
    trial::SlaterTrial{T},
) where {T}
    dimension = size(problem.kinetic, 1)
    size(trial.up) == (dimension, problem.Nup) || throw(DimensionMismatch(
        "up trial must have size (M,Nup)",
    ))
    size(trial.down) == (dimension, problem.Ndown) || throw(DimensionMismatch(
        "down trial must have size (M,Ndown)",
    ))
    return nothing
end

"""Initialize a walker population from the same trial determinant."""
function initialize_cp_afqmc(
    problem::CPAFQMCProblem{T},
    parameters::CPAFQMCParameters;
    trial::SlaterTrial=one_body_trial(problem),
) where {T}
    typed_parameters = CPAFQMCParameters(
        dtau=convert(T, parameters.dtau),
        walker_count=parameters.walker_count,
        warmup_steps=parameters.warmup_steps,
        measurement_count=parameters.measurement_count,
        steps_between_measurements=parameters.steps_between_measurements,
        orthogonalize_every=parameters.orthogonalize_every,
        population_control_every=parameters.population_control_every,
        overlap_refresh_every=parameters.overlap_refresh_every,
        back_propagation_steps=parameters.back_propagation_steps,
        minimum_backprop_ancestors=parameters.minimum_backprop_ancestors,
        error_block_size=parameters.error_block_size,
        seed=parameters.seed,
    )
    typed_trial = SlaterTrial{T}(
        _cp_canonical_columns(Matrix{T}(trial.up)),
        _cp_canonical_columns(Matrix{T}(trial.down)),
        trial.label,
        trial.pattern,
        ismissing(trial.field_strength) ? missing :
            convert(T, trial.field_strength),
        ismissing(trial.up_shell_gap) ? missing :
            convert(T, trial.up_shell_gap),
        ismissing(trial.down_shell_gap) ? missing :
            convert(T, trial.down_shell_gap),
    )
    _cp_validate_trial(problem, typed_trial)
    kinetic_half, _ = dense_slice_propagators(
        problem.kinetic, typed_parameters.dtau / 2,
    )
    gamma = convert(T, hubbard_stratonovich_alpha(
        problem.U, typed_parameters.dtau,
    ))
    walkers = Vector{_CPWalker{T}}(undef, typed_parameters.walker_count)
    for walker_index in eachindex(walkers)
        walkers[walker_index] = _CPWalker(
            copy(typed_trial.up),
            copy(typed_trial.down),
            zero(T),
            zero(T),
            true,
            copy(typed_trial.up),
            copy(typed_trial.down),
            walker_index,
            Vector{Vector{Int8}}(),
            Int[],
        )
    end
    return CPAFQMCState(
        problem,
        typed_parameters,
        typed_trial,
        walkers,
        Matrix{T}(kinetic_half),
        gamma,
        Xoshiro(typed_parameters.seed),
        collect(1:size(problem.kinetic, 1)),
        0,
        length(walkers) + 1,
        0,
        0,
        0,
        0,
        zero(T),
    )
end

function _cp_kill!(state::CPAFQMCState, walker::_CPWalker)
    walker.alive = false
    walker.log_weight = -typeof(walker.log_weight)(Inf)
    state.killed_walkers += 1
    return false
end

function _cp_apply_kinetic!(state::CPAFQMCState{T}, walker::_CPWalker{T}) where {T}
    new_up = state.kinetic_half * walker.up
    new_down = state.kinetic_half * walker.down
    new_log_overlap, new_sign = _cp_combined_log_overlap(
        state.trial, new_up, new_down,
    )
    new_sign > 0 && isfinite(new_log_overlap) ||
        return _cp_kill!(state, walker)
    walker.log_weight += new_log_overlap - walker.log_overlap
    walker.log_overlap = new_log_overlap
    walker.up = new_up
    walker.down = new_down
    return true
end

function _cp_overlap_inverse(
    state::CPAFQMCState{T},
    trial::AbstractMatrix{T},
    walker::AbstractMatrix{T},
) where {T<:AbstractFloat}
    size(trial, 2) == 0 && return zeros(T, 0, 0)
    overlap = transpose(trial) * walker
    inverse_overlap = try
        inv(overlap)
    catch
        state.overlap_inverse_failures += 1
        return nothing
    end
    if !all(isfinite, inverse_overlap)
        state.overlap_inverse_failures += 1
        return nothing
    end
    condition_estimate = opnorm(overlap, 1) * opnorm(inverse_overlap, 1)
    if !isfinite(condition_estimate)
        state.overlap_inverse_failures += 1
        return nothing
    end
    state.maximum_overlap_condition = max(
        state.maximum_overlap_condition,
        condition_estimate,
    )
    return inverse_overlap
end

function _cp_mixed_diagonal(
    walker::AbstractMatrix{T},
    inverse_overlap::AbstractMatrix{T},
    trial::AbstractMatrix{T},
    index::Int,
) where {T<:AbstractFloat}
    size(walker, 2) == 0 && return zero(T)
    projected_trial_row = inverse_overlap * Vector{T}(@view trial[index, :])
    return dot(@view(walker[index, :]), projected_trial_row)
end

function _cp_scale_row_update!(
    walker::Matrix{T},
    inverse_overlap::Matrix{T},
    trial::Matrix{T},
    index::Int,
    scale::T,
    expected_ratio::T,
) where {T<:AbstractFloat}
    size(walker, 2) == 0 && return inverse_overlap
    old_row = Vector{T}(@view walker[index, :])
    overlap_update = (scale - one(T)) .* Vector{T}(@view trial[index, :])
    left_update = inverse_overlap * overlap_update
    right_update = vec(transpose(old_row) * inverse_overlap)
    denominator = one(T) + dot(old_row, left_update)
    @views walker[index, :] .*= scale
    tolerance = sqrt(eps(T)) * max(one(T), abs(expected_ratio))
    if !isfinite(denominator) || abs(denominator) <= tolerance
        return nothing
    end
    inverse_overlap .-= left_update * transpose(right_update) / denominator
    return inverse_overlap
end

function _cp_positive_importance(ratio::T) where {T<:AbstractFloat}
    return isfinite(ratio) && ratio > zero(T) ? ratio / 2 : zero(T)
end

function _cp_apply_potential!(
    state::CPAFQMCState{T},
    walker::_CPWalker{T},
) where {T}
    trial = state.trial
    inverse_up = _cp_overlap_inverse(state, trial.up, walker.up)
    isnothing(inverse_up) && return nothing
    inverse_down = _cp_overlap_inverse(state, trial.down, walker.down)
    isnothing(inverse_down) && return nothing
    shuffle!(state.rng, state.site_order)
    fields = Vector{Int8}(undef, length(state.site_order))
    exp_gamma = exp(state.gamma)
    exp_minus_gamma = inv(exp_gamma)

    for (update_count, index) in enumerate(state.site_order)
        density_up = _cp_mixed_diagonal(walker.up, inverse_up, trial.up, index)
        density_down = _cp_mixed_diagonal(
            walker.down, inverse_down, trial.down, index,
        )
        ratio_up_plus = one(T) + (exp_gamma - one(T)) * density_up
        ratio_down_plus = one(T) + (exp_minus_gamma - one(T)) * density_down
        ratio_up_minus = one(T) + (exp_minus_gamma - one(T)) * density_up
        ratio_down_minus = one(T) + (exp_gamma - one(T)) * density_down
        total_plus = ratio_up_plus * ratio_down_plus
        total_minus = ratio_up_minus * ratio_down_minus
        importance_plus = _cp_positive_importance(total_plus)
        importance_minus = _cp_positive_importance(total_minus)
        iszero(importance_plus) && (state.constraint_rejections += 1)
        iszero(importance_minus) && (state.constraint_rejections += 1)
        normalization = importance_plus + importance_minus
        isfinite(normalization) && normalization > zero(T) ||
            return nothing

        choose_plus = rand(state.rng) < importance_plus / normalization
        field = choose_plus ? Int8(1) : Int8(-1)
        fields[index] = field
        walker.log_weight += log(normalization)
        if choose_plus
            inverse_up = _cp_scale_row_update!(
                walker.up, inverse_up, trial.up, index,
                exp_gamma, ratio_up_plus,
            )
            inverse_down = _cp_scale_row_update!(
                walker.down, inverse_down, trial.down, index,
                exp_minus_gamma, ratio_down_plus,
            )
        else
            inverse_up = _cp_scale_row_update!(
                walker.up, inverse_up, trial.up, index,
                exp_minus_gamma, ratio_up_minus,
            )
            inverse_down = _cp_scale_row_update!(
                walker.down, inverse_down, trial.down, index,
                exp_gamma, ratio_down_minus,
            )
        end
        if isnothing(inverse_up)
            inverse_up = _cp_overlap_inverse(state, trial.up, walker.up)
            isnothing(inverse_up) && return nothing
        end
        if isnothing(inverse_down)
            inverse_down = _cp_overlap_inverse(state, trial.down, walker.down)
            isnothing(inverse_down) && return nothing
        end
        if update_count % state.parameters.overlap_refresh_every == 0
            inverse_up = _cp_overlap_inverse(state, trial.up, walker.up)
            isnothing(inverse_up) && return nothing
            inverse_down = _cp_overlap_inverse(state, trial.down, walker.down)
            isnothing(inverse_down) && return nothing
        end
    end

    new_log_overlap, new_sign = _cp_combined_log_overlap(
        trial, walker.up, walker.down,
    )
    new_sign > 0 && isfinite(new_log_overlap) || return nothing
    walker.log_overlap = new_log_overlap
    return fields
end

function _cp_apply_slice_matrix(
    matrix::Matrix{T},
    kinetic_half::Matrix{T},
    gamma::T,
    fields::Vector{Int8},
    spin_sign::Int,
) where {T<:AbstractFloat}
    propagated = kinetic_half * matrix
    for index in eachindex(fields)
        @views propagated[index, :] .*= exp(spin_sign * gamma * fields[index])
    end
    return kinetic_half * propagated
end

function _cp_append_history!(
    state::CPAFQMCState{T},
    walker::_CPWalker{T},
    fields::Vector{Int8},
    end_id::Int,
) where {T}
    history_length = state.parameters.back_propagation_steps
    history_length == 0 && return nothing
    if length(walker.fields) == history_length
        oldest = popfirst!(walker.fields)
        walker.anchor_up = _cp_apply_slice_matrix(
            walker.anchor_up, state.kinetic_half, state.gamma, oldest, 1,
        )
        walker.anchor_down = _cp_apply_slice_matrix(
            walker.anchor_down, state.kinetic_half, state.gamma, oldest, -1,
        )
        walker.anchor_up = _cp_canonical_columns(walker.anchor_up)
        walker.anchor_down = _cp_canonical_columns(walker.anchor_down)
        walker.anchor_id = popfirst!(walker.field_end_ids)
    end
    push!(walker.fields, copy(fields))
    push!(walker.field_end_ids, end_id)
    return nothing
end

function _cp_stabilize!(state::CPAFQMCState{T}, walker::_CPWalker{T}) where {T}
    walker.up = _cp_canonical_columns(walker.up)
    walker.down = _cp_canonical_columns(walker.down)
    new_log_overlap, new_sign = _cp_combined_log_overlap(
        state.trial, walker.up, walker.down,
    )
    new_sign > 0 && isfinite(new_log_overlap) ||
        return _cp_kill!(state, walker)
    walker.log_overlap = new_log_overlap
    return true
end

function _cp_normalize_weights!(state::CPAFQMCState{T}) where {T}
    live_logs = T[walker.log_weight for walker in state.walkers if walker.alive]
    isempty(live_logs) && throw(ErrorException(
        "all constrained-path walkers died",
    ))
    largest = maximum(live_logs)
    scaled_sum = sum(exp(value - largest) for value in live_logs)
    shift = largest + log(scaled_sum / length(live_logs))
    for walker in state.walkers
        walker.alive && (walker.log_weight -= shift)
    end
    return length(live_logs)
end

function _cp_copy_walker(walker::_CPWalker{T}) where {T}
    return _CPWalker(
        copy(walker.up),
        copy(walker.down),
        zero(T),
        walker.log_overlap,
        true,
        copy(walker.anchor_up),
        copy(walker.anchor_down),
        walker.anchor_id,
        [copy(fields) for fields in walker.fields],
        copy(walker.field_end_ids),
    )
end

function _cp_population_control!(state::CPAFQMCState{T}) where {T}
    live = [walker for walker in state.walkers if walker.alive]
    isempty(live) && throw(ErrorException("population control has no live walkers"))
    log_weights = T[walker.log_weight for walker in live]
    largest = maximum(log_weights)
    weights = exp.(log_weights .- largest)
    total_weight = sum(weights)
    target = state.parameters.walker_count
    spacing = total_weight / target
    first_target = rand(state.rng) * spacing
    new_walkers = Vector{_CPWalker{T}}(undef, target)
    cumulative = weights[1]
    source = 1
    for destination in 1:target
        point = first_target + (destination - 1) * spacing
        while point > cumulative && source < length(live)
            source += 1
            cumulative += weights[source]
        end
        new_walkers[destination] = _cp_copy_walker(live[source])
    end
    state.walkers = new_walkers
    state.population_controls += 1
    return nothing
end

"""Advance every live walker by one symmetric imaginary-time step."""
function step_cp_afqmc!(state::CPAFQMCState)
    rejected_before = state.constraint_rejections
    killed_before = state.killed_walkers
    for walker in state.walkers
        walker.alive || continue
        _cp_apply_kinetic!(state, walker) || continue
        fields = _cp_apply_potential!(state, walker)
        isnothing(fields) && (_cp_kill!(state, walker); continue)
        _cp_apply_kinetic!(state, walker) || continue
        if (state.step + 1) % state.parameters.orthogonalize_every == 0
            _cp_stabilize!(state, walker) || continue
        end
        end_id = state.next_lineage_id
        state.next_lineage_id += 1
        _cp_append_history!(state, walker, fields, end_id)
    end
    state.step += 1
    live_count = _cp_normalize_weights!(state)
    if state.step % state.parameters.population_control_every == 0
        _cp_population_control!(state)
        live_count = length(state.walkers)
    end
    return (
        step=state.step,
        live_walkers=live_count,
        constraint_rejections=
            state.constraint_rejections - rejected_before,
        killed_walkers=state.killed_walkers - killed_before,
    )
end

function _cp_backpropagated_left(
    state::CPAFQMCState{T},
    walker::_CPWalker{T},
) where {T}
    left_up = copy(state.trial.up)
    left_down = copy(state.trial.down)
    for (count, fields) in enumerate(Iterators.reverse(walker.fields))
        left_up = _cp_apply_slice_matrix(
            left_up, state.kinetic_half, state.gamma, fields, 1,
        )
        left_down = _cp_apply_slice_matrix(
            left_down, state.kinetic_half, state.gamma, fields, -1,
        )
        if count % state.parameters.orthogonalize_every == 0
            left_up = _cp_canonical_columns(left_up)
            left_down = _cp_canonical_columns(left_down)
        end
    end
    return left_up, left_down
end

@inline function _cp_same_spin_density_pair(
    density::AbstractMatrix{T},
    first::Int,
    second::Int,
) where {T}
    return density[first, first] * density[second, second] -
           density[first, second] * density[second, first] +
           (first == second ? density[first, first] : zero(T))
end

function _cp_orbital_spin_structure_factor(
    density_up::AbstractMatrix{T},
    density_down::AbstractMatrix{T},
    L::Int,
) where {T<:AbstractFloat}
    real_space = zeros(T, 2, 2, L, L)
    number_of_cells = L^2
    for orbital_a in 1:2, orbital_b in 1:2
        for dy in 0:(L - 1), dx in 0:(L - 1)
            correlation_sum = zero(T)
            for y in 1:L, x in 1:L
                first = single_particle_index(
                    periodic_coordinate(x + dx, L),
                    periodic_coordinate(y + dy, L),
                    orbital_a,
                    L,
                )
                second = single_particle_index(x, y, orbital_b, L)
                up_up = _cp_same_spin_density_pair(
                    density_up, first, second,
                )
                down_down = _cp_same_spin_density_pair(
                    density_down, first, second,
                )
                up_down = density_up[first, first] *
                          density_down[second, second]
                down_up = density_down[first, first] *
                          density_up[second, second]
                correlation_sum += up_up + down_down - up_down - down_up
            end
            real_space[orbital_a, orbital_b, dx + 1, dy + 1] =
                correlation_sum / number_of_cells
        end
    end
    # FFTW uses exp(-iq*r). Conjugating a transform of real correlations gives
    # the documented exp(+iq*r) convention.
    return conj.(fft(real_space, (3, 4)))
end

function _cp_spin_structure_channels(
    structure::AbstractArray{<:Complex,4},
)
    Lx, Ly = size(structure, 3), size(structure, 4)
    T = typeof(real(zero(eltype(structure))))
    orbital_odd = Matrix{T}(undef, Lx, Ly)
    orbital_even = Matrix{T}(undef, Lx, Ly)
    for qy in 1:Ly, qx in 1:Lx
        block = @view structure[:, :, qx, qy]
        orbital_odd[qx, qy] = real(
            block[1, 1] + block[2, 2] - block[1, 2] - block[2, 1],
        ) / 4
        orbital_even[qx, qy] = real(
            block[1, 1] + block[2, 2] + block[1, 2] + block[2, 1],
        ) / 4
    end
    return (orbital_odd=orbital_odd, orbital_even=orbital_even)
end

struct CPAFQMCMeasurement{T<:AbstractFloat}
    step::Int
    mixed_total_energy::T
    mixed_kinetic_energy::T
    mixed_interaction_energy::T
    mixed_double_occupancy_per_cell::T
    backpropagated_total_energy::Union{Missing,T}
    backpropagated_kinetic_energy::Union{Missing,T}
    backpropagated_interaction_energy::Union{Missing,T}
    backpropagated_double_occupancy_per_cell::Union{Missing,T}
    S_alm_q0::Union{Missing,T}
    S_fm_q0::Union{Missing,T}
    structure_factor::Union{Nothing,Array{Complex{T},4}}
    distinct_backprop_ancestors::Int
end

function _cp_missing_order_measurement(step::Int)
    return (step=step, mx=missing, my=missing, m_fm=missing, delta_alm=missing)
end

"""
Measure the current population without advancing it. With `include_order=true`,
return `(measurement, order_measurement)` including back-propagated, signed
orbital magnetizations. The separate record preserves legacy checkpoint types.
"""
function measure_cp_afqmc(
    state::CPAFQMCState{T};
    include_order::Bool=false,
) where {T}
    live = [walker for walker in state.walkers if walker.alive]
    isempty(live) && throw(ErrorException("there are no live walkers to measure"))
    largest_log_weight = maximum(walker.log_weight for walker in live)
    weights = T[exp(walker.log_weight - largest_log_weight) for walker in live]
    total_weight = sum(weights)
    energy_total = zero(T)
    kinetic_total = zero(T)
    interaction_total = zero(T)
    double_total = zero(T)
    use_back_propagation = state.parameters.back_propagation_steps > 0
    backpropagated_energy_total = zero(T)
    backpropagated_kinetic_total = zero(T)
    backpropagated_interaction_total = zero(T)
    backpropagated_double_total = zero(T)
    magnetization_x_total = zero(T)
    magnetization_y_total = zero(T)
    structure_total = isnothing(state.problem.lattice_size) ||
        !use_back_propagation ? nothing :
        zeros(Complex{T}, 2, 2, state.problem.lattice_size, state.problem.lattice_size)

    for (walker, weight) in zip(live, weights)
        mixed = mixed_local_energy(
            state.problem,
            state.trial.up,
            state.trial.down,
            walker.up,
            walker.down,
        )
        energy_total += weight * mixed.total
        kinetic_total += weight * mixed.kinetic
        interaction_total += weight * mixed.interaction
        double_total += weight * mixed.double_occupancy

        if use_back_propagation
            length(walker.fields) == state.parameters.back_propagation_steps ||
                throw(ErrorException("back-propagation history is not full"))
            left_up, left_down = _cp_backpropagated_left(state, walker)
            density_up = transition_density_matrix(
                left_up, walker.anchor_up,
            )
            density_down = transition_density_matrix(
                left_down, walker.anchor_down,
            )
            backpropagated = _cp_local_energy_from_densities(
                state.problem,
                Matrix{T}(density_up),
                Matrix{T}(density_down),
            )
            backpropagated_energy_total += weight * backpropagated.total
            backpropagated_kinetic_total += weight * backpropagated.kinetic
            backpropagated_interaction_total += weight * backpropagated.interaction
            backpropagated_double_total += weight * backpropagated.double_occupancy

            if !isnothing(structure_total)
                if include_order
                    for cell in 0:(state.problem.cell_count - 1)
                        x = 2 * cell + 1
                        y = x + 1
                        magnetization_x_total += weight *
                            (density_up[x, x] - density_down[x, x])
                        magnetization_y_total += weight *
                            (density_up[y, y] - density_down[y, y])
                    end
                end
                structure_total .+= weight .* _cp_orbital_spin_structure_factor(
                    Matrix{T}(density_up), Matrix{T}(density_down),
                    state.problem.lattice_size,
                )
            end
        end
    end

    structure = isnothing(structure_total) ? nothing : structure_total ./ total_weight
    S_alm = missing
    S_fm = missing
    distinct_ancestors = use_back_propagation ?
        length(unique(walker.anchor_id for walker in live)) : 0
    if use_back_propagation &&
       distinct_ancestors < state.parameters.minimum_backprop_ancestors
        throw(ErrorException(
            "back-propagation ancestry collapsed to $distinct_ancestors distinct " *
            "walkers; minimum_backprop_ancestors=" *
            "$(state.parameters.minimum_backprop_ancestors)",
        ))
    end
    if !isnothing(structure)
        channels = _cp_spin_structure_channels(structure)
        S_alm = channels.orbital_odd[1, 1]
        S_fm = channels.orbital_even[1, 1]
    end
    measurement = CPAFQMCMeasurement(
        state.step,
        energy_total / total_weight,
        kinetic_total / total_weight,
        interaction_total / total_weight,
        double_total / (total_weight * state.problem.cell_count),
        use_back_propagation ? backpropagated_energy_total / total_weight : missing,
        use_back_propagation ? backpropagated_kinetic_total / total_weight : missing,
        use_back_propagation ? backpropagated_interaction_total / total_weight : missing,
        use_back_propagation ?
            backpropagated_double_total / (total_weight * state.problem.cell_count) :
            missing,
        S_alm,
        S_fm,
        structure,
        distinct_ancestors,
    )
    include_order || return measurement
    order_measurement = if isnothing(structure)
        _cp_missing_order_measurement(state.step)
    else
        mx = magnetization_x_total / (total_weight * state.problem.cell_count)
        my = magnetization_y_total / (total_weight * state.problem.cell_count)
        (
            step=state.step,
            mx=mx,
            my=my,
            m_fm=(mx + my) / 2,
            delta_alm=(mx - my) / 2,
        )
    end
    return (measurement=measurement, order_measurement=order_measurement)
end

function _cp_block_statistics(values::Vector{T}, block_size::Int) where {T<:AbstractFloat}
    count = length(values)
    count % block_size == 0 || throw(ArgumentError(
        "block_size must divide the number of measurements",
    ))
    block_count = div(count, block_size)
    block_means = Vector{T}(undef, block_count)
    for block in 1:block_count
        range = ((block - 1) * block_size + 1):(block * block_size)
        block_means[block] = sum(@view values[range]) / block_size
    end
    center = sum(values) / count
    standard_error = if block_count < 2
        missing
    else
        block_center = sum(block_means) / block_count
        deviations = sum((value - block_center)^2 for value in block_means)
        sqrt(deviations / (block_count * (block_count - 1)))
    end
    return (mean=center, standard_error=standard_error, block_means=block_means)
end

function _cp_structure_statistics(
    measurements::Vector{CPAFQMCMeasurement{T}},
    block_size::Int,
) where {T<:AbstractFloat}
    isempty(measurements) && return nothing
    first_structure = first(measurements).structure_factor
    isnothing(first_structure) && return nothing
    Lx, Ly = size(first_structure, 3), size(first_structure, 4)
    sample_count = length(measurements)
    orbital_odd_samples = Array{T}(undef, sample_count, Lx, Ly)
    orbital_even_samples = Array{T}(undef, sample_count, Lx, Ly)
    maximum_imaginary_part = zero(T)
    for (measurement_index, measurement) in enumerate(measurements)
        structure = measurement.structure_factor
        isnothing(structure) && throw(ErrorException(
            "spin structure factors are missing from one measurement",
        ))
        channels = _cp_spin_structure_channels(structure)
        orbital_odd_samples[measurement_index, :, :] .= channels.orbital_odd
        orbital_even_samples[measurement_index, :, :] .= channels.orbital_even
        maximum_imaginary_part = max(
            maximum_imaginary_part,
            maximum(abs, imag.(structure)),
        )
    end

    orbital_odd = zeros(T, Lx, Ly)
    orbital_even = zeros(T, Lx, Ly)
    orbital_odd_standard_error = Matrix{Union{Missing,T}}(missing, Lx, Ly)
    orbital_even_standard_error = Matrix{Union{Missing,T}}(missing, Lx, Ly)
    for qy in 1:Ly, qx in 1:Lx
        odd_statistics = _cp_block_statistics(
            Vector{T}(@view orbital_odd_samples[:, qx, qy]),
            block_size,
        )
        even_statistics = _cp_block_statistics(
            Vector{T}(@view orbital_even_samples[:, qx, qy]),
            block_size,
        )
        orbital_odd[qx, qy] = odd_statistics.mean
        orbital_even[qx, qy] = even_statistics.mean
        orbital_odd_standard_error[qx, qy] = odd_statistics.standard_error
        orbital_even_standard_error[qx, qy] = even_statistics.standard_error
    end
    momenta_x = T[2 * T(pi) * (index - 1) / Lx for index in 1:Lx]
    momenta_y = T[2 * T(pi) * (index - 1) / Ly for index in 1:Ly]
    return (
        momenta_x=momenta_x,
        momenta_y=momenta_y,
        orbital_odd=orbital_odd,
        orbital_odd_standard_error=orbital_odd_standard_error,
        orbital_even=orbital_even,
        orbital_even_standard_error=orbital_even_standard_error,
        maximum_imaginary_part=maximum_imaginary_part,
    )
end

struct CPAFQMCResult{T<:AbstractFloat}
    problem::CPAFQMCProblem{T}
    parameters::CPAFQMCParameters{T}
    trial_label::String
    measurements::Vector{CPAFQMCMeasurement{T}}
    summary::NamedTuple
    diagnostics::NamedTuple
    order_measurements::Vector{NamedTuple}
end

function _cp_checked_order_measurements(measurements, order_measurements)
    if isnothing(order_measurements)
        return NamedTuple[_cp_missing_order_measurement(m.step) for m in measurements]
    end
    length(order_measurements) == length(measurements) || throw(ArgumentError(
        "order-parameter records must match the measurement count",
    ))
    for (measurement, order) in zip(measurements, order_measurements)
        keys(order) == (:step, :mx, :my, :m_fm, :delta_alm) || throw(ArgumentError(
            "invalid order-parameter record fields",
        ))
        order.step == measurement.step || throw(ArgumentError(
            "order-parameter record step does not match its measurement",
        ))
        values = (order.mx, order.my, order.m_fm, order.delta_alm)
        all(ismissing, values) && continue
        all(value -> value isa Real && isfinite(value), values) || throw(
            ArgumentError("orbital magnetizations must be all finite or all missing"),
        )
    end
    return NamedTuple[order for order in order_measurements]
end

"""Build a result from a completed state and its saved measurements."""
function finish_cp_afqmc(
    state::CPAFQMCState{T},
    measurements::Vector{CPAFQMCMeasurement{T}};
    order_measurements=nothing,
) where {T}
    problem = state.problem
    length(measurements) == state.parameters.measurement_count || throw(
        ArgumentError(
            "measurement count must equal parameters.measurement_count",
        ),
    )
    energies = T[measurement.mixed_total_energy for measurement in measurements]
    kinetics = T[measurement.mixed_kinetic_energy for measurement in measurements]
    interactions = T[measurement.mixed_interaction_energy for measurement in measurements]
    doubles = T[
        measurement.mixed_double_occupancy_per_cell for measurement in measurements
    ]
    energy_stats = _cp_block_statistics(
        energies, state.parameters.error_block_size,
    )
    kinetic_stats = _cp_block_statistics(
        kinetics, state.parameters.error_block_size,
    )
    interaction_stats = _cp_block_statistics(
        interactions, state.parameters.error_block_size,
    )
    double_stats = _cp_block_statistics(
        doubles, state.parameters.error_block_size,
    )
    backpropagated_energies = T[
        measurement.backpropagated_total_energy for measurement in measurements
        if !ismissing(measurement.backpropagated_total_energy)
    ]
    backpropagated_kinetics = T[
        measurement.backpropagated_kinetic_energy for measurement in measurements
        if !ismissing(measurement.backpropagated_kinetic_energy)
    ]
    backpropagated_interactions = T[
        measurement.backpropagated_interaction_energy for measurement in measurements
        if !ismissing(measurement.backpropagated_interaction_energy)
    ]
    backpropagated_doubles = T[
        measurement.backpropagated_double_occupancy_per_cell
        for measurement in measurements
        if !ismissing(measurement.backpropagated_double_occupancy_per_cell)
    ]
    backpropagated_energy_stats = isempty(backpropagated_energies) ? nothing :
        _cp_block_statistics(
            backpropagated_energies,
            state.parameters.error_block_size,
        )
    backpropagated_kinetic_stats = isempty(backpropagated_kinetics) ? nothing :
        _cp_block_statistics(
            backpropagated_kinetics,
            state.parameters.error_block_size,
        )
    backpropagated_interaction_stats = isempty(backpropagated_interactions) ? nothing :
        _cp_block_statistics(
            backpropagated_interactions,
            state.parameters.error_block_size,
        )
    backpropagated_double_stats = isempty(backpropagated_doubles) ? nothing :
        _cp_block_statistics(
            backpropagated_doubles,
            state.parameters.error_block_size,
        )
    salm_values = T[
        measurement.S_alm_q0 for measurement in measurements
        if !ismissing(measurement.S_alm_q0)
    ]
    sfm_values = T[
        measurement.S_fm_q0 for measurement in measurements
        if !ismissing(measurement.S_fm_q0)
    ]
    salm_stats = isempty(salm_values) ? nothing : _cp_block_statistics(
        salm_values, state.parameters.error_block_size,
    )
    sfm_stats = isempty(sfm_values) ? nothing : _cp_block_statistics(
        sfm_values, state.parameters.error_block_size,
    )
    structure_stats = _cp_structure_statistics(
        measurements,
        state.parameters.error_block_size,
    )
    orders = _cp_checked_order_measurements(measurements, order_measurements)
    order_count = count(order -> !ismissing(order.delta_alm), orders)
    order_complete = order_count == length(measurements)
    # A legacy checkpoint can have a missing prefix. Do not report its measured
    # tail as an average over the complete run.
    order_stats = map((:mx, :my, :m_fm, :delta_alm)) do field
        order_complete ? _cp_block_statistics(
            T[getproperty(order, field) for order in orders],
            state.parameters.error_block_size,
        ) : (mean=missing, standard_error=missing)
    end
    summary = (
        energy=energy_stats.mean,
        energy_standard_error=energy_stats.standard_error,
        energy_per_cell=energy_stats.mean / problem.cell_count,
        energy_standard_error_per_cell=ismissing(energy_stats.standard_error) ?
            missing : energy_stats.standard_error / problem.cell_count,
        mixed_kinetic_energy=kinetic_stats.mean,
        mixed_kinetic_energy_standard_error=kinetic_stats.standard_error,
        mixed_interaction_energy=interaction_stats.mean,
        mixed_interaction_energy_standard_error=interaction_stats.standard_error,
        mixed_double_occupancy_per_cell=double_stats.mean,
        mixed_double_occupancy_standard_error=double_stats.standard_error,
        backpropagated_energy=isnothing(backpropagated_energy_stats) ? missing :
            backpropagated_energy_stats.mean,
        backpropagated_energy_standard_error=
            isnothing(backpropagated_energy_stats) ? missing :
            backpropagated_energy_stats.standard_error,
        backpropagated_kinetic_energy=
            isnothing(backpropagated_kinetic_stats) ? missing :
            backpropagated_kinetic_stats.mean,
        backpropagated_kinetic_energy_standard_error=
            isnothing(backpropagated_kinetic_stats) ? missing :
            backpropagated_kinetic_stats.standard_error,
        backpropagated_interaction_energy=
            isnothing(backpropagated_interaction_stats) ? missing :
            backpropagated_interaction_stats.mean,
        backpropagated_interaction_energy_standard_error=
            isnothing(backpropagated_interaction_stats) ? missing :
            backpropagated_interaction_stats.standard_error,
        backpropagated_double_occupancy_per_cell=
            isnothing(backpropagated_double_stats) ? missing :
            backpropagated_double_stats.mean,
        backpropagated_double_occupancy_standard_error=
            isnothing(backpropagated_double_stats) ? missing :
            backpropagated_double_stats.standard_error,
        S_alm_q0=isnothing(salm_stats) ? missing : salm_stats.mean,
        S_alm_q0_standard_error=isnothing(salm_stats) ? missing :
            salm_stats.standard_error,
        S_fm_q0=isnothing(sfm_stats) ? missing : sfm_stats.mean,
        S_fm_q0_standard_error=isnothing(sfm_stats) ? missing :
            sfm_stats.standard_error,
        mx=order_stats[1].mean,
        mx_standard_error=order_stats[1].standard_error,
        my=order_stats[2].mean,
        my_standard_error=order_stats[2].standard_error,
        m_fm=order_stats[3].mean,
        m_fm_standard_error=order_stats[3].standard_error,
        delta_alm=order_stats[4].mean,
        delta_alm_standard_error=order_stats[4].standard_error,
        m_alm_squared=isnothing(salm_stats) ? missing :
            salm_stats.mean / problem.cell_count,
        m_alm_squared_standard_error=isnothing(salm_stats) ? missing :
            salm_stats.standard_error / problem.cell_count,
        spin_structure_momenta_x=isnothing(structure_stats) ? nothing :
            structure_stats.momenta_x,
        spin_structure_momenta_y=isnothing(structure_stats) ? nothing :
            structure_stats.momenta_y,
        orbital_odd_spin_structure_factor=
            isnothing(structure_stats) ? nothing : structure_stats.orbital_odd,
        orbital_odd_spin_structure_factor_standard_error=
            isnothing(structure_stats) ? nothing :
            structure_stats.orbital_odd_standard_error,
        orbital_even_spin_structure_factor=
            isnothing(structure_stats) ? nothing : structure_stats.orbital_even,
        orbital_even_spin_structure_factor_standard_error=
            isnothing(structure_stats) ? nothing :
            structure_stats.orbital_even_standard_error,
        density=(problem.Nup + problem.Ndown) / problem.cell_count,
    )
    ancestor_counts = [
        measurement.distinct_backprop_ancestors for measurement in measurements
        if measurement.distinct_backprop_ancestors > 0
    ]
    diagnostics = (
        total_steps=state.step,
        projection_time=state.step * state.parameters.dtau,
        constraint_rejections=state.constraint_rejections,
        killed_walkers=state.killed_walkers,
        population_controls=state.population_controls,
        overlap_inverse_failures=state.overlap_inverse_failures,
        maximum_overlap_condition=state.maximum_overlap_condition,
        trial_pattern=state.trial.pattern,
        trial_field_strength=state.trial.field_strength,
        trial_up_shell_gap=state.trial.up_shell_gap,
        trial_down_shell_gap=state.trial.down_shell_gap,
        constraint_scheme="local positive-overlap; no mirror correction",
        spin_fourier_convention="exp(+i*q*(r_first-r_second))",
        maximum_spin_structure_imaginary_part=
            isnothing(structure_stats) ? missing :
            structure_stats.maximum_imaginary_part,
        minimum_distinct_backprop_ancestors=
            isempty(ancestor_counts) ? missing : minimum(ancestor_counts),
        final_live_walkers=count(walker -> walker.alive, state.walkers),
        order_parameter_measurements=order_count,
        order_parameter_complete=order_complete,
    )
    return CPAFQMCResult(
        problem,
        state.parameters,
        state.trial.label,
        measurements,
        summary,
        diagnostics,
        orders,
    )
end

"""Run warmup, projection measurements, population control, and back propagation."""
function run_cp_afqmc(
    problem::CPAFQMCProblem{T},
    parameters::CPAFQMCParameters;
    trial::SlaterTrial=one_body_trial(problem),
) where {T}
    if parameters.back_propagation_steps >
       parameters.warmup_steps + parameters.steps_between_measurements
        throw(ArgumentError(
            "back_propagation_steps must not exceed warmup_steps + " *
            "steps_between_measurements",
        ))
    end
    state = initialize_cp_afqmc(problem, parameters; trial=trial)
    for _ in 1:state.parameters.warmup_steps
        step_cp_afqmc!(state)
    end
    measurements = CPAFQMCMeasurement{T}[]
    order_measurements = NamedTuple[]
    for _ in 1:state.parameters.measurement_count
        for _ in 1:state.parameters.steps_between_measurements
            step_cp_afqmc!(state)
        end
        sample = measure_cp_afqmc(state; include_order=true)
        push!(measurements, sample.measurement)
        push!(order_measurements, sample.order_measurement)
    end
    return finish_cp_afqmc(state, measurements; order_measurements=order_measurements)
end
