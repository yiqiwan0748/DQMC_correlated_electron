module FixedDensityMuCalibrationPlanner

export ABOVE_TARGET,
       BELOW_TARGET,
       TARGET_COMPATIBLE,
       CalibrationPlan,
       CalibrationProvenance,
       CalibrationRecord,
       CandidateProposal,
       build_candidate_proposal,
       candidate_case_name,
       classify_density,
       next_unused_seed,
       plan_calibration,
       print_plan,
       validate_calibration_record,
       validated_bracket

@enum DensityClassification begin
    BELOW_TARGET
    ABOVE_TARGET
    TARGET_COMPATIBLE
end

Base.@kwdef struct CalibrationProvenance
    phase::Symbol
    L::Int
    beta::Float64
    dtau::Float64
    Ltau::Int
    U::Float64
    matrix_dimension::Int
    stabilization_period::Int
    burnin_sweeps::Int
    measurement_sweeps::Int
    sweeps_between_measurements::Int
    measurement_count::Int
    requested_block_size::Int
    block_count::Int
    minimum_block_length::Int
    maximum_block_length::Int
    attempted_updates::Int
    configured_average_sign_threshold::Float64
    maximum_average_sign_standard_error::Float64
    minimum_block_count::Int
    maximum_block_drift_zscore::Float64
    minimum_sign_signal_to_noise::Float64
    minimum_absolute_average_sign::Float64
    maximum_greens_recompute_error::Float64
    u0_filling_tolerance::Float64
    require_single::Bool
    strict_pilot::Bool
    output_schema::String
end

Base.@kwdef struct CalibrationRecord
    case_name::String
    seed::Int
    mu::Float64
    target_density::Float64
    density::Float64
    standard_error::Float64
    strict_pilot_status::Symbol
    strict_pilot_passed::Bool
    filling_jackknife_valid::Bool
    source_consistent::Bool
    provenance::CalibrationProvenance
    output_directory::String
end

struct CalibrationPlan
    status::Symbol
    successful_calibration::Bool
    target_density::Float64
    records::Vector{CalibrationRecord}
    below::Union{Nothing,CalibrationRecord}
    above::Union{Nothing,CalibrationRecord}
    compatible::Union{Nothing,CalibrationRecord}
    mu_next::Union{Nothing,Float64}
    completed_new_evaluations::Int
    maximum_new_evaluations::Int
    bracket_width_tolerance::Float64
end

struct CandidateProposal
    plan::CalibrationPlan
    case_name::String
    seed::Int
    output_directory::String
    dry_run_command::String
end

function _require_finite(name, value)
    isfinite(value) || throw(ArgumentError("$name must be finite"))
    return value
end

function classify_density(density, standard_error, target_density)
    density_value = _require_finite("density", Float64(density))
    standard_error_value =
        _require_finite("standard error", Float64(standard_error))
    target_value = _require_finite("target density", Float64(target_density))
    standard_error_value >= 0 ||
        throw(ArgumentError("standard error must be nonnegative"))

    lower_bound = density_value - 2 * standard_error_value
    upper_bound = density_value + 2 * standard_error_value
    isfinite(lower_bound) && isfinite(upper_bound) ||
        throw(ArgumentError("two-standard-error interval must be finite"))

    if upper_bound < target_value
        return BELOW_TARGET
    elseif lower_bound > target_value
        return ABOVE_TARGET
    end
    return TARGET_COMPATIBLE
end

function _same_provenance(left::CalibrationProvenance,
                          right::CalibrationProvenance)
    return all(
        isequal(getfield(left, name), getfield(right, name))
        for name in fieldnames(CalibrationProvenance)
    )
end

function _validate_provenance(provenance::CalibrationProvenance)
    provenance.phase == :mu_calibration ||
        throw(ArgumentError("record phase must be mu_calibration"))
    provenance.L > 0 || throw(ArgumentError("L must be positive"))
    provenance.Ltau > 0 || throw(ArgumentError("Ltau must be positive"))
    provenance.matrix_dimension > 0 ||
        throw(ArgumentError("matrix dimension must be positive"))
    provenance.stabilization_period > 0 ||
        throw(ArgumentError("stabilization period must be positive"))
    provenance.burnin_sweeps >= 0 ||
        throw(ArgumentError("burn-in sweeps must be nonnegative"))
    provenance.measurement_sweeps > 0 ||
        throw(ArgumentError("measurement sweeps must be positive"))
    provenance.sweeps_between_measurements > 0 ||
        throw(ArgumentError("sweeps between measurements must be positive"))
    provenance.measurement_count > 0 ||
        throw(ArgumentError("measurement count must be positive"))
    provenance.requested_block_size > 0 ||
        throw(ArgumentError("requested block size must be positive"))
    provenance.block_count > 0 ||
        throw(ArgumentError("block count must be positive"))
    provenance.minimum_block_length > 0 ||
        throw(ArgumentError("minimum block length must be positive"))
    provenance.maximum_block_length >= provenance.minimum_block_length ||
        throw(ArgumentError("maximum block length is smaller than minimum"))
    provenance.attempted_updates > 0 ||
        throw(ArgumentError("attempted update count must be positive"))
    provenance.minimum_block_count > 0 ||
        throw(ArgumentError("minimum block count must be positive"))
    provenance.require_single ||
        throw(ArgumentError("calibration record must use require_single"))
    provenance.strict_pilot ||
        throw(ArgumentError("calibration record must use strict_pilot"))
    isempty(provenance.output_schema) &&
        throw(ArgumentError("output schema must not be empty"))

    for (name, value) in (
        (:beta, provenance.beta),
        (:dtau, provenance.dtau),
        (:U, provenance.U),
        (:configured_average_sign_threshold,
         provenance.configured_average_sign_threshold),
        (:maximum_average_sign_standard_error,
         provenance.maximum_average_sign_standard_error),
        (:maximum_block_drift_zscore,
         provenance.maximum_block_drift_zscore),
        (:minimum_sign_signal_to_noise,
         provenance.minimum_sign_signal_to_noise),
        (:minimum_absolute_average_sign,
         provenance.minimum_absolute_average_sign),
        (:maximum_greens_recompute_error,
         provenance.maximum_greens_recompute_error),
        (:u0_filling_tolerance, provenance.u0_filling_tolerance),
    )
        _require_finite(string(name), value)
    end
    provenance.beta > 0 || throw(ArgumentError("beta must be positive"))
    provenance.dtau > 0 || throw(ArgumentError("dtau must be positive"))
    provenance.beta / provenance.dtau == provenance.Ltau ||
        throw(ArgumentError("beta, dtau, and Ltau are inconsistent"))
    provenance.matrix_dimension == 2 * provenance.L^2 ||
        throw(ArgumentError("matrix dimension is inconsistent with L"))
    provenance.measurement_count == provenance.measurement_sweeps ||
        throw(ArgumentError("measurement count and sweeps differ"))
    provenance.block_count >= provenance.minimum_block_count ||
        throw(ArgumentError("record has fewer blocks than required"))
    return provenance
end

function validate_calibration_record(record::CalibrationRecord,
                                     target_density)
    target_value = _require_finite("target density", Float64(target_density))
    record.source_consistent ||
        throw(ArgumentError("CSV, metadata, and configured case disagree"))
    record.strict_pilot_status == :PASS ||
        throw(ArgumentError("strict-pilot status must be PASS"))
    record.strict_pilot_passed ||
        throw(ArgumentError("strict-pilot passed flag must be true"))
    record.filling_jackknife_valid ||
        throw(ArgumentError("filling jackknife must be valid"))
    record.seed > 0 || throw(ArgumentError("seed must be positive"))
    isempty(record.case_name) && throw(ArgumentError("case name is empty"))
    isempty(record.output_directory) &&
        throw(ArgumentError("output directory is empty"))
    _require_finite("mu", record.mu)
    _require_finite("density", record.density)
    _require_finite("standard error", record.standard_error)
    record.standard_error >= 0 ||
        throw(ArgumentError("standard error must be nonnegative"))
    _require_finite("record target density", record.target_density)
    isequal(record.target_density, target_value) ||
        throw(ArgumentError("record target density does not match planner target"))
    _validate_provenance(record.provenance)
    classify_density(record.density, record.standard_error, target_value)
    return record
end

function _validated_records(records, target_density)
    values = collect(records)
    isempty(values) && throw(ArgumentError("at least one record is required"))
    all(record -> record isa CalibrationRecord, values) ||
        throw(ArgumentError("all inputs must be calibration records"))
    typed_values = CalibrationRecord[values...]
    for record in typed_values
        validate_calibration_record(record, target_density)
    end
    reference = first(typed_values).provenance
    for record in Iterators.drop(typed_values, 1)
        _same_provenance(reference, record.provenance) ||
            throw(ArgumentError(
                "physical or simulation provenance does not match exactly",
            ))
    end
    length(unique(record.seed for record in typed_values)) == length(typed_values) ||
        throw(ArgumentError("calibration record seeds must be unique"))
    return typed_values
end

function validated_bracket(records, target_density)
    values = _validated_records(records, target_density)
    relations = [
        classify_density(record.density, record.standard_error, target_density)
        for record in values
    ]
    any(==(TARGET_COMPATIBLE), relations) &&
        throw(ArgumentError("target-compatible records are stopping records, not endpoints"))

    below_records = values[relations .== BELOW_TARGET]
    above_records = values[relations .== ABOVE_TARGET]
    isempty(below_records) &&
        throw(ArgumentError("validated bracket has no BELOW_TARGET endpoint"))
    isempty(above_records) &&
        throw(ArgumentError("validated bracket has no ABOVE_TARGET endpoint"))

    below = below_records[argmax(record.mu for record in below_records)]
    above = above_records[argmin(record.mu for record in above_records)]
    below.mu < above.mu || throw(ArgumentError(
        "invalid bracket orientation: BELOW_TARGET mu must be less than ABOVE_TARGET mu",
    ))
    return (below=below, above=above)
end

function plan_calibration(records;
                          target_density,
                          completed_new_evaluations=0,
                          maximum_new_evaluations=6,
                          bracket_width_tolerance=0.001)
    completed_new_evaluations isa Integer ||
        throw(ArgumentError("completed evaluation count must be an integer"))
    maximum_new_evaluations isa Integer ||
        throw(ArgumentError("maximum evaluation count must be an integer"))
    completed_new_evaluations >= 0 ||
        throw(ArgumentError("completed evaluation count must be nonnegative"))
    maximum_new_evaluations > 0 ||
        throw(ArgumentError("maximum evaluation count must be positive"))
    tolerance = _require_finite(
        "bracket width tolerance",
        Float64(bracket_width_tolerance),
    )
    tolerance > 0 ||
        throw(ArgumentError("bracket width tolerance must be positive"))
    target_value = _require_finite("target density", Float64(target_density))
    values = _validated_records(records, target_value)

    compatible_records = filter(
        record -> classify_density(
            record.density,
            record.standard_error,
            target_value,
        ) == TARGET_COMPATIBLE,
        values,
    )
    if !isempty(compatible_records)
        compatible = first(sort(compatible_records; by=record -> record.mu))
        return CalibrationPlan(
            :TARGET_COMPATIBLE,
            true,
            target_value,
            values,
            nothing,
            nothing,
            compatible,
            nothing,
            Int(completed_new_evaluations),
            Int(maximum_new_evaluations),
            tolerance,
        )
    end

    bracket = validated_bracket(values, target_value)
    width = bracket.above.mu - bracket.below.mu
    if completed_new_evaluations >= maximum_new_evaluations
        return CalibrationPlan(
            :EVALUATION_CAP_REACHED,
            false,
            target_value,
            values,
            bracket.below,
            bracket.above,
            nothing,
            nothing,
            Int(completed_new_evaluations),
            Int(maximum_new_evaluations),
            tolerance,
        )
    elseif width <= tolerance
        return CalibrationPlan(
            :BRACKET_WIDTH_TOLERANCE_REACHED,
            false,
            target_value,
            values,
            bracket.below,
            bracket.above,
            nothing,
            nothing,
            Int(completed_new_evaluations),
            Int(maximum_new_evaluations),
            tolerance,
        )
    end

    mu_next = bracket.below.mu + width / 2
    isfinite(mu_next) || throw(ArgumentError("midpoint is not finite"))
    return CalibrationPlan(
        :PROPOSE_CANDIDATE,
        false,
        target_value,
        values,
        bracket.below,
        bracket.above,
        nothing,
        mu_next,
        Int(completed_new_evaluations),
        Int(maximum_new_evaluations),
        tolerance,
    )
end

function candidate_case_name(mu)
    value = _require_finite("candidate mu", Float64(mu))
    numeric_text = string(abs(value))
    if endswith(numeric_text, ".0")
        numeric_text = numeric_text[1:(end - 2)]
    end
    numeric_text = replace(numeric_text, '.' => 'p', '+' => 'p', '-' => 'm')
    prefix = signbit(value) ? "m" : "p"
    return "calibrate_target_mu_" * prefix * numeric_text
end

function next_unused_seed(configured_seeds,
                          record_seeds,
                          case_name,
                          output_root;
                          first_candidate=6117,
                          path_exists=ispath)
    first_candidate isa Integer ||
        throw(ArgumentError("first candidate seed must be an integer"))
    first_candidate > 0 ||
        throw(ArgumentError("first candidate seed must be positive"))
    used = Set{Int}()
    for seed in Iterators.flatten((configured_seeds, record_seeds))
        seed isa Integer || throw(ArgumentError("all used seeds must be integers"))
        push!(used, Int(seed))
    end

    seed = Int(first_candidate)
    while true
        output_directory = joinpath(
            output_root,
            "$(case_name)_seed$(seed)_strict_pilot",
        )
        if !(seed in used) && !path_exists(output_directory)
            return (seed=seed, output_directory=output_directory)
        end
        seed == typemax(Int) &&
            throw(ArgumentError("no positive seed remains representable"))
        seed += 1
    end
end

function build_candidate_proposal(plan::CalibrationPlan;
                                  configured_seeds,
                                  record_seeds,
                                  output_root=joinpath(
                                      "results",
                                      "dqmc_sign_feasibility",
                                  ),
                                  first_candidate=6117,
                                  path_exists=ispath)
    plan.status == :PROPOSE_CANDIDATE || throw(ArgumentError(
        "a candidate can be built only for a PROPOSE_CANDIDATE plan",
    ))
    mu_next = something(plan.mu_next)
    case_name = candidate_case_name(mu_next)
    allocation = next_unused_seed(
        configured_seeds,
        record_seeds,
        case_name,
        output_root;
        first_candidate=first_candidate,
        path_exists=path_exists,
    )
    command =
        "julia --project=. scripts/run_dqmc_sign_feasibility.jl " *
        "--phase=mu-calibration --case=$(case_name) " *
        "--seed=$(allocation.seed) --require-single --strict-pilot"
    return CandidateProposal(
        plan,
        case_name,
        allocation.seed,
        allocation.output_directory,
        command,
    )
end

function print_plan(io::IO, plan::CalibrationPlan,
                    proposal::Union{Nothing,CandidateProposal}=nothing)
    println(io, "planner_mode=dry-run")
    println(io, "planner_status=", plan.status)
    println(io, "calibration_success=", plan.successful_calibration)
    println(io, "target_density=", plan.target_density)
    println(io, "validated_record_count=", length(plan.records))
    println(io, "completed_new_evaluations=", plan.completed_new_evaluations)
    println(io, "maximum_new_evaluations=", plan.maximum_new_evaluations)
    println(
        io,
        "remaining_new_evaluations=",
        max(0, plan.maximum_new_evaluations - plan.completed_new_evaluations),
    )
    println(io, "bracket_width_tolerance=", plan.bracket_width_tolerance)

    if !isnothing(plan.compatible)
        compatible = something(plan.compatible)
        println(io, "target_compatible_case=", compatible.case_name)
        println(io, "target_compatible_mu=", compatible.mu)
    end
    if !isnothing(plan.below) && !isnothing(plan.above)
        below = something(plan.below)
        above = something(plan.above)
        println(io, "below_target_case=", below.case_name)
        println(io, "below_target_mu=", below.mu)
        println(io, "below_target_density=", below.density)
        println(io, "below_target_standard_error=", below.standard_error)
        println(io, "above_target_case=", above.case_name)
        println(io, "above_target_mu=", above.mu)
        println(io, "above_target_density=", above.density)
        println(io, "above_target_standard_error=", above.standard_error)
        println(io, "bracket_width=", above.mu - below.mu)
    end

    if isnothing(proposal)
        println(io, "proposed_candidate_count=0")
    else
        proposal_value = something(proposal)
        proposal_value.plan === plan ||
            throw(ArgumentError("proposal does not belong to this plan"))
        provenance = something(plan.below).provenance
        println(io, "mu_next=", something(plan.mu_next))
        println(io, "proposed_candidate_count=1")
        println(io, "proposed_phase=mu_calibration")
        println(io, "proposed_case=", proposal_value.case_name)
        println(io, "proposed_seed=", proposal_value.seed)
        println(io, "proposed_L=", provenance.L)
        println(io, "proposed_beta=", provenance.beta)
        println(io, "proposed_dtau=", provenance.dtau)
        println(io, "proposed_Ltau=", provenance.Ltau)
        println(io, "proposed_U=", provenance.U)
        println(io, "proposed_mu=", something(plan.mu_next))
        println(io, "proposed_target_filling=", plan.target_density)
        println(io, "proposed_stabilization_period=", provenance.stabilization_period)
        println(io, "proposed_burnin_sweeps=", provenance.burnin_sweeps)
        println(io, "proposed_measurement_sweeps=", provenance.measurement_sweeps)
        println(
            io,
            "proposed_sweeps_between_measurements=",
            provenance.sweeps_between_measurements,
        )
        println(io, "proposed_block_size=", provenance.requested_block_size)
        println(io, "proposed_output_directory=", proposal_value.output_directory)
        println(io, "candidate_configuration_status=PROPOSED_NOT_CONFIGURED")
        println(io, "dry_run_command=", proposal_value.dry_run_command)
    end
    println(io, "dqmc_states_constructed=0")
    println(io, "chain_runner_calls=0")
    println(io, "outputs_written=false")
    return nothing
end

print_plan(plan::CalibrationPlan,
           proposal::Union{Nothing,CandidateProposal}=nothing) =
    print_plan(stdout, plan, proposal)

end
