using Test, LinearAlgebra, Random
include(joinpath(@__DIR__,"../scripts/literature_transfer/alm_schmidt_benchmark_20260911.jl"))
using .ALMSchmidtBenchmark

states(m,n)=[UInt64(s) for s in 0:(1<<m)-1 if count_ones(s)==n]

@testset "Fermionic local ordering and exact charge-block round trip" begin
    # Independent inversion count in the explicit target spin-mode labels.
    for u in UInt64(0):UInt64(15),d in UInt64(0):UInt64(15)
        ordering=vcat([2i-1 for i in 1:4 if !iszero(u&(UInt64(1)<<(i-1)))],
                      [2i for i in 1:4 if !iszero(d&(UInt64(1)<<(i-1)))])
        inversions=sum(ordering[i]>ordering[j] for i in eachindex(ordering) for j in i+1:length(ordering);init=0)
        @test fermionic_local_sign(u,d,4)==(-1)^inversions
    end
    @test fermionic_local_sign(0b10,0b01,2)==-1
    @test fermionic_local_sign(0b01,0b10,2)==1
    @test fermionic_local_sign(0b01,0b01,2)==1
    @test fermionic_local_sign(0b11,0b11,2)==-1

    # Source c_up,2^dagger c_down,1^dagger = -c_down,1^dagger c_up,2^dagger.
    us=states(2,1);ds=states(2,1);psi=[0.,0.,1.,0.]
    part=coefficient_blocks(us,ds,psi;nmodes=2,cut=1)
    block=only(filter(b->b.left_charge==(0,1),part.blocks))
    @test block.left_basis==[2] && block.right_basis==[1]
    @test block.matrix==fill(-1.,1,1)
    @test restore_sector_vector(part)==psi

    rng=MersenneTwister(204911)
    # Reverse both input arrays to demonstrate that no accidental numeric sort
    # is substituted for the supplied ED vector ordering.
    us=reverse(states(4,2));ds=reverse(states(4,1))
    psi=randn(rng,ComplexF64,length(us)*length(ds));normalize!(psi)
    for cut in 1:3
        p=coefficient_blocks(us,ds,psi;nmodes=4,cut=cut)
        @test restore_sector_vector(p)==psi
        @test sum(sum(abs2,b.matrix) for b in p.blocks)≈1 atol=2e-14 rtol=2e-14
        for block in p.blocks
            @test block.left_charge.+block.right_charge==(2,1)
        end
    end
end

@testset "Product state and one-electron Bell/W states" begin
    us=states(4,2);ds=states(4,1);psi=zeros(length(us)*length(ds));psi[7]=1
    result=schmidt_analysis(us,ds,psi;nmodes=4)
    @test length(result.cuts)==3
    for cut in result.cuts
        @test cut.entropy≈0 atol=2e-14 rtol=0
        @test cut.numerical_rank==1
        @test all(d==1 for d in values(cut.required_bond_dimensions))
        @test cut.probability_sum≈1 atol=2e-14 rtol=2e-14
    end

    us=states(2,1);ds=states(2,0);psi=fill(1/sqrt(2),2)
    cut=schmidt_cut(us,ds,psi,1;nmodes=2,discarded_weights=(.5,1e-4,1e-10))
    @test cut.probabilities≈[.5,.5] atol=2e-14 rtol=2e-14
    @test cut.entropy≈log(2) atol=2e-14 rtol=2e-14
    @test cut.numerical_rank==2
    @test cut.required_bond_dimensions[.5]==1
    @test cut.required_bond_dimensions[1e-4]==2
    @test length(cut.charge_blocks)==2

    # Tests all seven requested cuts at the hard mode limit using an exact
    # analytic one-particle spectrum, independently of SVD implementation.
    us=states(8,1);ds=states(8,0);psi=fill(1/sqrt(8),8)
    result=schmidt_analysis(us,ds,psi;nmodes=8)
    for c in result.cuts
        prob=c.cut/8
        @test c.numerical_rank==2
        @test sort(c.probabilities,rev=true)[1:2]≈sort([prob,1-prob],rev=true) atol=3e-14 rtol=3e-14
        @test c.entropy≈-prob*log(prob)-(1-prob)*log(1-prob) atol=3e-14 rtol=3e-14
    end
end

@testset "Single-cut charge-preserving truncation error and bond thresholds" begin
    rng=MersenneTwister(309117);us=states(4,2);ds=states(4,1)
    for T in (Float64,ComplexF64)
        psi=randn(rng,T,length(us)*length(ds));normalize!(psi)
        for cut in 1:3
            analysis=schmidt_cut(us,ds,psi,cut;nmodes=4)
            for chi in (1,2,4,8,16,32,64,128,256)
                t=truncate_cut(us,ds,psi,cut;nmodes=4,max_bond=chi)
                @test length(t.vector)==length(psi)
                @test sum(abs2,t.vector-psi)≈t.discarded_weight atol=5e-13 rtol=5e-12
                @test sum(abs2,t.vector)≈1-t.discarded_weight atol=5e-13 rtol=5e-12
                @test sum(values(t.retained_per_charge))==t.retained_bond<=chi
                @test t.discarded_weight≈sum(analysis.probabilities[min(chi,end)+1:end]) atol=5e-13 rtol=5e-12
                if chi>=analysis.numerical_rank
                    @test t.vector≈psi atol=5e-13 rtol=5e-12
                end
            end
            for (threshold,chi) in analysis.required_bond_dimensions
                @test sum(analysis.probabilities[chi+1:end])<=threshold
                @test chi==0 || sum(analysis.probabilities[chi:end])>threshold
            end
        end
        # Non-unit input norm is accounted for, and explicit normalization is
        # separate from the unnormalized optimal-approximation error identity.
        t=truncate_cut(us,ds,2psi,2;nmodes=4,max_bond=2,normalize=true)
        @test t.input_norm2≈4 atol=2e-13 rtol=2e-13
        @test t.output_norm2≈1 atol=2e-13 rtol=2e-13
        @test t.unnormalized_error_norm2≈4t.discarded_weight atol=2e-12 rtol=2e-12
    end
end

@testset "Bounded-oracle input rejection" begin
    @test_throws ArgumentError schmidt_analysis([0],[0],[1.];nmodes=9)
    @test_throws ArgumentError schmidt_analysis([0],[0],[1.];nmodes=true)
    @test_throws ArgumentError coefficient_blocks([0],[0],[1.];nmodes=2,cut=0)
    @test_throws ArgumentError coefficient_blocks([0],[0],[1.];nmodes=2,cut=2)
    @test_throws ArgumentError coefficient_blocks([1,1],[0],[1.,0.];nmodes=2,cut=1)
    @test_throws ArgumentError coefficient_blocks([1],[0],[1.];nmodes=2,cut=1)
    @test_throws ArgumentError coefficient_blocks([0,1],[0],[1.,0.];nmodes=2,cut=1)
    @test_throws ArgumentError coefficient_blocks([4],[0],[1.];nmodes=2,cut=1)
    @test_throws ArgumentError coefficient_blocks([-1],[0],[1.];nmodes=2,cut=1)
    @test_throws ArgumentError coefficient_blocks([0],[0],[NaN];nmodes=2,cut=1)
    @test_throws ArgumentError coefficient_blocks([0],[0],[0.];nmodes=2,cut=1)
    @test_throws ArgumentError truncate_cut([0],[0],[1.],1;nmodes=2,max_bond=0)
    @test_throws ArgumentError schmidt_cut([0],[0],[1.],1;nmodes=2,discarded_weights=(-.1,))
    @test_throws ArgumentError schmidt_cut([0],[0],[1.],1;nmodes=2,discarded_weights=(NaN,))
    @test_throws ArgumentError schmidt_analysis([0],[0],[1.];nmodes=2,cuts=[1,1])
end

# The 2e-14–5e-13 absolute tolerances cover Float64 normalization and small
# LAPACK SVD accumulation. Relative 5e-12 tolerances in truncation comparisons
# do not dominate tiny discarded tails because an explicit absolute bound is
# also present. These are small-matrix identities, not physical error bars.
