using Test, LinearAlgebra
include(joinpath(@__DIR__,"../scripts/literature_transfer/alm_schmidt_target_20260911.jl"))
const ST=ALMSchmidtTarget20260911

@testset "Exact-state integration observable normalization and completion gate" begin
    # Simple analytic occupation fixtures, not new physical Hamiltonian runs.
    oz=ST.odd_z_diagonal(UInt64[1,2],UInt64[0])
    @test oz==[.5,-.5]
    H=Diagonal([-2.,3.])
    p=ST.state_observables([1.,0.],H,oz)
    @test p.energy==-2
    @test p.Delta==.125
    @test p.S_odd_z==.0625
    @test p.S_odd_z_connected==0
    b=ST.state_observables(ComplexF64[1,im]/sqrt(2),H,oz)
    @test b.O_z_mean≈0 atol=2e-15 rtol=0
    @test b.energy≈.5 atol=2e-15 rtol=2e-15
    @test b.S_odd_z_connected≈.0625 atol=2e-15 rtol=2e-15
    scale=ST.state_observables(3 .* ComplexF64[1,im]/sqrt(2),H,oz)
    @test scale.norm2≈9 atol=2e-14 rtol=2e-14
    @test scale.energy≈b.energy atol=2e-15 rtol=2e-15
    @test scale.S_odd_z_connected≈b.S_odd_z_connected atol=2e-15 rtol=2e-15
    @test ST.odd_z_diagonal(UInt64[1,2],UInt64[1,2])==[0.,1.,-1.,0.]
    @test_throws ArgumentError ST.odd_z_diagonal(UInt64[0],UInt64[0];nmodes=9)
    @test_throws ArgumentError ST.state_observables([1.],zeros(1,1),[0.];cells=8)
    mktempdir() do dir
        # Producer must explicitly finish validation before its data are read.
        @test_throws ErrorException ST.run_analysis(input_dir=dir,output_dir=joinpath(dir,"out"))
        @test !ispath(joinpath(dir,"out"))
        write(joinpath(dir,"status.txt"),"FAILED")
        @test_throws ErrorException ST.run_analysis(input_dir=dir,output_dir=joinpath(dir,"out"))
        @test !ispath(joinpath(dir,"out"))
    end
end
# 2e-15–2e-14 tolerances cover normalized two-entry Float64 expectations only.
