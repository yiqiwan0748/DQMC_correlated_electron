module Arxiv09013544NoninteractingTests

using Test
using LinearAlgebra
include(joinpath(@__DIR__, "..", "scripts", "run_arxiv_0901_3544_milestone1.jl"))
const Runner = Arxiv09013544Milestone1
const N = Runner.Arxiv09013544Noninteracting

@testset "arXiv 0901.3544v1 noninteracting Figures 5–8" begin
    @testset "Literal Eq14 convention in the fixed orbital basis" begin
        p = N.Hoppings(1., 2., 3., 4.)
        # Direct bond contributions at X give h_xz_xz=2t2−2t1+4t3=14.
        # Swapping orbital labels or keeping the old PRL t4 sign fails here.
        @test isapprox(N.bloch_hamiltonian(pi, 0., p), [14. 0.; 0. 10.]; atol=1e-12, rtol=0)
        @test isapprox(N.bloch_hamiltonian(pi/2, pi/2, p), [0. -16.; -16. 0.]; atol=1e-12, rtol=0)
        for spec in N.figure_specs()
            checks = N.convention_audit(spec.hoppings)
            # Roundoff tolerances cover trigonometric identities and LAPACK at
            # energy scales through 8 eV; printed parameters are much coarser.
            @test checks.matrix_error <= 1e-12
            @test checks.eigenvalue_error <= 1e-11
            h = N.bloch_hamiltonian(0.47, -1.3, spec.hoppings)
            @test issymmetric(h)
            @test isreal(h)
            @test isapprox(N.bloch_hamiltonian(-1.3, 0.47, spec.hoppings),
                h[[2, 1], [2, 1]]; atol=1e-12, rtol=0)
            @test isapprox(N.bloch_hamiltonian(0.47 + 2pi, -1.3, spec.hoppings), h; atol=1e-12, rtol=0)
        end
        p32 = N.Hoppings(Float32.((0.058, 0.22, -0.21, -0.08))...)
        @test eltype(N.bloch_hamiltonian(0.3f0, 0.7f0, p32)) == Float32
        @test_throws ArgumentError N.Hoppings(0., 1., Inf, 2.)
        @test_throws ArgumentError N.bloch_hamiltonian(NaN, 0., p)
        @test_throws ArgumentError N.convention_audit(p; points=1)
    end

    @testset "Caption parameters, path and energy reference" begin
        specs = N.figure_specs()
        @test getproperty.(specs, :printed_mu) == (-0.03, 0.081, 0.053, nothing)
        @test getproperty.(specs, :figure) == (5, 6, 7, 8)
        p, mu = specs[4].hoppings, 1.54
        path = N.band_path(p, mu; points_per_segment=16)
        @test length(path.kx) == 49
        @test path.tick_indices == [1, 17, 33, 49]
        @test path.path_segment[path.tick_indices] == [0., 1., 2., 3.]
        # Fig8 high-symmetry values independently follow from the caption.
        @test isapprox(path.lower_energy[path.tick_indices], [2.8, -8.0, 4.0, 2.8]; atol=1e-12, rtol=0)
        @test isapprox(path.upper_energy[path.tick_indices], [2.8, 1.2, 4.0, 2.8]; atol=1e-12, rtol=0)
        @test isapprox(path.lower_relative, path.lower_energy .- mu; atol=1e-12, rtol=0)
        @test isapprox(path.coordinate[end], (2 + sqrt(2))pi; atol=1e-12, rtol=0)
        @test_throws ArgumentError N.band_path(p, mu; points_per_segment=0)
        @test_throws ArgumentError N.band_path(p, Inf)
    end

    @testset "Four pockets and independent occupancy counting" begin
        for spec in N.figure_specs()
            p = spec.hoppings
            mu = isnothing(spec.printed_mu) ? 1.54 : spec.printed_mu
            contours = N.fermi_contours(p, mu; angles=64)
            @test length(contours) == 4
            density = N.contour_band_densities(contours)
            audit = N.filling_audit(p, 240, mu)
            # Deliberately coarse test polygons/grid permit 0.005 electrons/Fe.
            # Production separately enforces 1600²/1440-angle convergence gates.
            @test isapprox(density.lower, audit.lower_density_at_reference; atol=0.005, rtol=0)
            @test isapprox(density.upper, audit.upper_density_at_reference; atol=0.005, rtol=0)
            @test audit.density_below_half_mu <= 2 <= audit.density_through_half_mu
            for c in contours
                @test all(>(0), c.radius)
                @test isapprox([c.kx[1], c.ky[1]], [c.kx[end], c.ky[end]]; atol=1e-12, rtol=0)
                for i in 1:8:length(c.theta)
                    eigenvalues = eigvals(Symmetric(N.fourier_bond_hamiltonian(c.kx[i], c.ky[i], p)))
                    @test isapprox(eigenvalues[c.pocket.band], mu; atol=1e-11, rtol=0)
                end
            end
            @test isapprox(contours[3].radius[1], contours[4].radius[17]; atol=1e-12, rtol=0)
        end
        flat = N.filling_audit(N.Hoppings(0., 0., 0., 0.), 8, 0.)
        @test flat.density_below_half_mu == 0.0
        @test flat.density_through_half_mu == 4.0
    end

    @testset "Preserve prior run outputs" begin
        mktempdir() do directory
            keep = joinpath(directory, "keep.txt")
            write(keep, "prior output")
            @test_throws ErrorException Runner.main(["--output-dir=$directory", "--no-plots"])
            @test read(keep, String) == "prior output"
        end
        @test_throws ArgumentError Runner.options(["--unsupported"])
    end
end

end
