module CompareCPAFQMCToGroundEDTests

using Test

include(joinpath(
    @__DIR__, "..", "scripts", "compare_cp_afqmc_to_ground_ed.jl",
))

using .CompareCPAFQMCToGroundED

function _write_synthetic_cp(
    directory;
    U=2.0,
    Nup=3,
    Ndown=3,
    boundary="periodic",
    seed=101,
    trial="free",
    field_strength=0.0,
    dtau=0.02,
    offset=0.0,
    standard_error=0.02,
    omit_quantity=nothing,
)
    mkpath(directory)
    exact = CompareCPAFQMCToGroundED.TwoOrbitalClusterED.
        solve_two_orbital_ground_state(U, Nup + Ndown)
    values = Dict(
        "mixed_energy" => exact.ground_energy + offset,
        "backpropagated_energy" => exact.ground_energy + 2offset,
        "backpropagated_double_occupancy_per_cell" =>
            exact.double_occupancy + offset / 10,
        "S_alm_q0" => exact.o_alm_squared / 4 + offset / 5,
    )
    open(joinpath(directory, "summary.csv"), "w") do io
        println(io, "quantity,value,standard_error")
        for quantity in (
            "mixed_energy",
            "backpropagated_energy",
            "backpropagated_double_occupancy_per_cell",
            "S_alm_q0",
        )
            quantity == omit_quantity && continue
            println(io, quantity, ',', values[quantity], ',', standard_error)
        end
        println(io, "density,", (Nup + Ndown) / 4, ',')
    end
    open(joinpath(directory, "metadata.txt"), "w") do io
        println(io, "method=constrained-path AFQMC")
        println(io, "Hamiltonian=centered repulsive two-orbital Hubbard")
        println(io, "boundary=", boundary)
        println(io, "L=2")
        println(io, "U=", U)
        println(io, "Nup=", Nup)
        println(io, "Ndown=", Ndown)
        println(io, "dtau=", dtau)
        println(io, "walkers=64")
        println(io, "warmup=80")
        println(io, "measurements=20")
        println(io, "steps_between=4")
        println(io, "orthogonalize_every=5")
        println(io, "population_control_every=5")
        println(io, "overlap_refresh_every=16")
        println(io, "back_propagation_steps=20")
        println(io, "minimum_backprop_ancestors=2")
        println(io, "block_size=5")
        println(io, "seed=", seed)
        println(io, "trial=", trial)
        println(io, "field_strength=", field_strength)
        println(io, "realized_density=", (Nup + Ndown) / 4)
    end
    return directory
end

@testset "Saved CP-AFQMC to ground-state ED comparison" begin
    @testset "Options" begin
        @test isnothing(parse_options(["--help"]))
        @test_throws ArgumentError parse_options(String[])
        @test_throws ArgumentError parse_options(["--unknown=x", "input"])
        @test_throws ArgumentError parse_options([
            "--output-dir=a", "--output-dir=b", "input",
        ])
        parsed = parse_options([
            "--output-dir=benchmark-output", "run-a", "run-b",
        ])
        @test parsed.output_dir == abspath("benchmark-output")
        @test parsed.input_dirs == abspath.(["run-a", "run-b"])
        @test_throws ArgumentError parse_options(["run-a", "run-a"])
    end

    @testset "Transparent independent-seed pooling" begin
        pool = pool_independent_estimates([1.1, 0.9], [0.02, 0.04])
        @test pool.mean == 1.0
        @test isapprox(
            pool.within_run_standard_error,
            sqrt(0.02^2 + 0.04^2) / 2;
            atol=1.0e-15,
        )
        @test isapprox(pool.between_seed_standard_error, 0.1; atol=1.0e-15)
        @test isapprox(pool.standard_error, 0.1; atol=1.0e-15)
        singleton = pool_independent_estimates([2.0], [0.3])
        @test singleton.standard_error == 0.3
        @test ismissing(singleton.between_seed_standard_error)
        @test_throws ArgumentError pool_independent_estimates([], [])
        @test_throws DimensionMismatch pool_independent_estimates([1.0], [])
        @test_throws ArgumentError pool_independent_estimates([NaN], [0.1])
        @test_throws ArgumentError pool_independent_estimates([1.0], [-0.1])
    end

    @testset "Read, validate, compare, and atomically write" begin
        mktempdir() do root
            first_dir = _write_synthetic_cp(
                joinpath(root, "seed101"); seed=101, offset=0.1,
                standard_error=0.02,
            )
            second_dir = _write_synthetic_cp(
                joinpath(root, "seed202"); seed=202, offset=-0.1,
                standard_error=0.04,
            )
            first_run = read_cp_output(first_dir)
            @test first_run.L == 2
            @test first_run.N == 6
            @test first_run.density == 1.5
            @test first_run.trial == "free"

            report = compare_cp_afqmc_to_ground_ed([first_dir, second_dir])
            @test report.problem == (
                L=2,
                U=2.0,
                Nup=3,
                Ndown=3,
                N=6,
                density=1.5,
                boundary="periodic",
                hamiltonian="centered repulsive two-orbital Hubbard",
            )
            @test length(report.per_run) == 8
            @test length(report.pools) == 1
            @test length(report.pooled) == 4
            @test report.exact.matched_spin_sector_contains_ground
            @test report.exact.ground_degeneracy > 1
            @test report.exact.S_alm_ensemble_sensitive
            @test report.status == "COMPLETE_WITH_ENSEMBLE_WARNING"
            salm_rows = filter(row -> row.quantity == "S_alm_q0",
                               report.per_run)
            @test length(salm_rows) == 2
            @test all(row -> row.ensemble_sensitive, salm_rows)
            @test all(row -> row.reference_scope ==
                "equal_weight_complete_fixed_N_ground_manifold", salm_rows)
            energy_pool = only(filter(
                row -> row.quantity == "mixed_energy_total", report.pooled,
            ))
            @test energy_pool.run_count == 2
            @test energy_pool.seeds == "101;202"
            @test isapprox(energy_pool.estimate, report.exact.ground_energy;
                           atol=1.0e-13)
            @test isapprox(energy_pool.standard_error, 0.1; atol=1.0e-13)

            output = joinpath(root, "comparison")
            returned = write_comparison(report, output)
            @test returned == abspath(output)
            @test isfile(joinpath(output, "per_run_comparison.csv"))
            @test isfile(joinpath(output, "trial_pooled_comparison.csv"))
            @test isfile(joinpath(output, "exact_ed_reference.csv"))
            @test isfile(joinpath(output, "metadata.txt"))
            @test isfile(joinpath(output, "status.txt"))
            metadata = read(joinpath(output, "metadata.txt"), String)
            @test occursin("accuracy_gate=none", metadata)
            @test occursin("constraint_bias=not removed", metadata)
            @test occursin("S_alm_ensemble_sensitive=true", metadata)
            status = read(joinpath(output, "status.txt"), String)
            @test occursin("comparison_verdict=not_assigned", status)
            @test_throws ArgumentError write_comparison(report, output)
        end
    end

    @testset "Strict input and pooling audits" begin
        mktempdir() do root
            valid = _write_synthetic_cp(joinpath(root, "valid"); seed=11)
            other_U = _write_synthetic_cp(
                joinpath(root, "other-U"); U=3.0, seed=12,
            )
            @test_throws ArgumentError compare_cp_afqmc_to_ground_ed(
                [valid, other_U],
            )

            open_boundary = _write_synthetic_cp(
                joinpath(root, "open"); boundary="open", seed=13,
            )
            @test_throws ArgumentError read_cp_output(open_boundary)

            missing = _write_synthetic_cp(
                joinpath(root, "missing"); seed=14,
                omit_quantity="S_alm_q0",
            )
            @test_throws ArgumentError read_cp_output(missing)

            duplicate_a = _write_synthetic_cp(
                joinpath(root, "duplicate-a"); seed=77,
            )
            duplicate_b = _write_synthetic_cp(
                joinpath(root, "duplicate-b"); seed=77,
            )
            @test_throws ArgumentError compare_cp_afqmc_to_ground_ed(
                [duplicate_a, duplicate_b],
            )

            separate_trial = _write_synthetic_cp(
                joinpath(root, "stripe"); seed=77, trial="stripe_x",
                field_strength=0.1,
            )
            separated = compare_cp_afqmc_to_ground_ed(
                [duplicate_a, separate_trial],
            )
            @test length(separated.pools) == 2
        end
    end
end

end # module
