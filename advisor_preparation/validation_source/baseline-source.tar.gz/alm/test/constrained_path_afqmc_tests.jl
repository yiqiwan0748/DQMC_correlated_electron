using Random: Xoshiro
using Serialization: serialize

@testset "Constrained-path AFQMC" begin
    @testset "Problem and control validation" begin
        kinetic = [0.0 -1.0; -1.0 0.0]
        problem = CPAFQMCProblem(kinetic, 4.0, 1, 1; cell_count=2)
        @test problem.kinetic == kinetic
        @test problem.U == 4.0
        @test (problem.Nup, problem.Ndown) == (1, 1)
        @test_throws DimensionMismatch CPAFQMCProblem(zeros(2, 3), 1.0, 1, 1)
        @test_throws ArgumentError CPAFQMCProblem([0.0 1.0; 0.0 0.0], 1.0, 1, 1)
        @test_throws ArgumentError CPAFQMCProblem(kinetic, -1.0, 1, 1)
        @test_throws ArgumentError CPAFQMCProblem(kinetic, 1.0, 3, 1)
        @test_throws ArgumentError CPAFQMCParameters(walker_count=1)
        @test_throws ArgumentError CPAFQMCParameters(
            measurement_count=5,
            error_block_size=2,
        )

        lattice_problem = two_orbital_cp_afqmc_problem(2, 2.0, 2, 2)
        @test size(lattice_problem.kinetic) == (8, 8)
        @test lattice_problem.lattice_size == 2
        @test lattice_problem.cell_count == 4
        @test one_body_trial(lattice_problem; pattern=:free).label == "free"
        for pattern in (:altermagnetic, :stripe_x, :stripe_y, :neel)
            trial = one_body_trial(
                lattice_problem;
                pattern=pattern,
                field_strength=1.0e-3,
            )
            @test size(trial.up) == (8, 2)
            @test size(trial.down) == (8, 2)
            @test startswith(trial.label, String(pattern) * "(h=")
            @test trial.pattern == pattern
            @test trial.field_strength == 1.0e-3
            @test !ismissing(trial.up_shell_gap)
            @test !ismissing(trial.down_shell_gap)
            @test isapprox(
                transpose(trial.up) * trial.up,
                Matrix{Float64}(I, 2, 2);
                atol=2.0e-13,
                rtol=2.0e-13,
            )
        end

        positive_domain = one_body_trial(
            lattice_problem;
            pattern=:altermagnetic,
            field_strength=1.0e-3,
        )
        negative_domain = one_body_trial(
            lattice_problem;
            pattern=:altermagnetic,
            field_strength=-1.0e-3,
        )
        @test isapprox(
            positive_domain.up * transpose(positive_domain.up),
            negative_domain.down * transpose(negative_domain.down);
            atol=3.0e-12,
            rtol=3.0e-12,
        )
        @test positive_domain.field_strength == -negative_domain.field_strength
    end

    @testset "Discrete auxiliary-field identity" begin
        for U in (0.0, 2.0, 20.0), dtau in (0.01, 0.05)
            gamma = hubbard_stratonovich_alpha(U, dtau)
            for nup in (0, 1), ndown in (0, 1)
                exact = exp(-dtau * U * (nup - 0.5) * (ndown - 0.5))
                field_sum = exp(-dtau * U / 4) * (
                    exp(gamma * (nup - ndown)) +
                    exp(-gamma * (nup - ndown))
                ) / 2
                @test isapprox(exact, field_sum; atol=2.0e-14, rtol=2.0e-14)
            end
        end
    end

    @testset "Complete one-site Fock-space slice" begin
        onsite_energy = 0.7
        U = 3.0
        dtau = 0.037
        kinetic_half, _ = dense_slice_propagators(
            reshape([onsite_energy], 1, 1),
            dtau / 2,
        )
        gamma = hubbard_stratonovich_alpha(U, dtau)
        auxiliary_slice = zeros(4, 4)
        exact_slice = zeros(4, 4)
        for nup in 0:1, ndown in 0:1
            fock_index = 1 + nup + 2 * ndown
            field_sum = 0.0
            for field in (Int8(-1), Int8(1))
                up_factor = only(AltermagnetDQMCTrial._cp_apply_slice_matrix(
                    ones(1, 1),
                    kinetic_half,
                    gamma,
                    Int8[field],
                    1,
                ))
                down_factor = only(AltermagnetDQMCTrial._cp_apply_slice_matrix(
                    ones(1, 1),
                    kinetic_half,
                    gamma,
                    Int8[field],
                    -1,
                ))
                field_sum += up_factor^nup * down_factor^ndown
            end
            auxiliary_slice[fock_index, fock_index] =
                exp(-dtau * U / 4) * field_sum / 2
            exact_energy = onsite_energy * (nup + ndown) +
                U * (nup - 0.5) * (ndown - 0.5)
            exact_slice[fock_index, fock_index] = exp(-dtau * exact_energy)
        end
        @test isapprox(
            auxiliary_slice,
            exact_slice;
            atol=3.0e-14,
            rtol=3.0e-14,
        )
    end

    @testset "Transition density and overlap ratios" begin
        rng = Xoshiro(71)
        left = Matrix(qr(randn(rng, 5, 2)).Q)[:, 1:2]
        right = Matrix(qr(randn(rng, 5, 2)).Q)[:, 1:2]
        density = transition_density_matrix(left, right)
        @test isapprox(density * density, density; atol=2.0e-12, rtol=2.0e-12)
        @test isapprox(tr(density), 2.0; atol=2.0e-12, rtol=2.0e-12)

        left_change = [1.2 0.3; -0.2 0.9]
        right_change = [0.8 -0.1; 0.4 1.1]
        changed = transition_density_matrix(
            left * left_change,
            right * right_change,
        )
        @test isapprox(changed, density; atol=3.0e-12, rtol=3.0e-12)

        site = 3
        scale = 1.37
        old_overlap = det(transpose(left) * right)
        scaled_right = copy(right)
        scaled_right[site, :] .*= scale
        direct_ratio = det(transpose(left) * scaled_right) / old_overlap
        predicted_ratio = 1 + (scale - 1) * density[site, site]
        @test isapprox(
            direct_ratio,
            predicted_ratio;
            atol=2.0e-12,
            rtol=2.0e-12,
        )

        small_left = left[1:3, :]
        small_right = right[1:3, :]
        basis = [state for state in 0:7 if count_ones(state) == 2]
        left_amplitudes = Dict(
            state => det(small_left[
                [mode for mode in 1:3 if !iszero(state & (1 << (mode - 1)))],
                :,
            ]) for state in basis
        )
        right_amplitudes = Dict(
            state => det(small_right[
                [mode for mode in 1:3 if !iszero(state & (1 << (mode - 1)))],
                :,
            ]) for state in basis
        )
        fock_overlap = sum(
            left_amplitudes[state] * right_amplitudes[state] for state in basis
        )
        fock_density = zeros(3, 3)
        for annihilation_site in 1:3, creation_site in 1:3
            numerator = 0.0
            for ket in basis
                annihilation_mask = 1 << (annihilation_site - 1)
                iszero(ket & annihilation_mask) && continue
                annihilation_sign = iseven(count_ones(
                    ket & (annihilation_mask - 1),
                )) ? 1.0 : -1.0
                intermediate = ket & ~annihilation_mask
                creation_mask = 1 << (creation_site - 1)
                !iszero(intermediate & creation_mask) && continue
                creation_sign = iseven(count_ones(
                    intermediate & (creation_mask - 1),
                )) ? 1.0 : -1.0
                bra = intermediate | creation_mask
                numerator += left_amplitudes[bra] * annihilation_sign *
                    creation_sign * right_amplitudes[ket]
            end
            fock_density[annihilation_site, creation_site] =
                numerator / fock_overlap
        end
        @test isapprox(
            transition_density_matrix(small_left, small_right),
            fock_density;
            atol=3.0e-12,
            rtol=3.0e-12,
        )
    end

    @testset "Exact noninteracting projection" begin
        kinetic = [0.0 -1.0; -1.0 0.0]
        problem = CPAFQMCProblem(kinetic, 0.0, 1, 1; cell_count=2)
        controls = CPAFQMCParameters(
            dtau=0.05,
            walker_count=20,
            warmup_steps=5,
            measurement_count=4,
            steps_between_measurements=2,
            orthogonalize_every=2,
            population_control_every=2,
            back_propagation_steps=0,
            error_block_size=2,
            seed=9,
        )
        result = run_cp_afqmc(problem, controls)
        @test isapprox(result.summary.energy, -2.0; atol=2.0e-13, rtol=0.0)
        @test result.summary.energy_standard_error <= 2.0e-13
        @test isapprox(
            result.summary.mixed_double_occupancy_per_cell,
            0.25;
            atol=2.0e-13,
            rtol=0.0,
        )
        @test result.diagnostics.constraint_rejections == 0
        @test result.diagnostics.killed_walkers == 0
        @test result.diagnostics.final_live_walkers == controls.walker_count
        for observable in (:mx, :my, :m_fm, :delta_alm, :m_alm_squared)
            @test ismissing(getproperty(result.summary, observable))
            @test ismissing(getproperty(
                result.summary,
                Symbol(observable, :_standard_error),
            ))
        end
        @test length(result.order_measurements) == controls.measurement_count
        for (measurement, order) in zip(result.measurements, result.order_measurements)
            @test order.step == measurement.step
            @test all(ismissing, (order.mx, order.my, order.m_fm, order.delta_alm))
        end

        repeated = run_cp_afqmc(problem, controls)
        @test isequal(repeated.summary, result.summary)
        @test isequal(repeated.diagnostics, result.diagnostics)
        @test isequal(repeated.measurements, result.measurements)
        @test isequal(repeated.order_measurements, result.order_measurements)
    end

    @testset "Analytic Hubbard dimer through strong coupling" begin
        kinetic = [0.0 -1.0; -1.0 0.0]
        cases = (
            (
                U=4.0,
                dtau=0.02,
                walkers=160,
                warmup=100,
                measurements=20,
                separation=3,
                seed=11,
                tolerance=0.08,
            ),
            (
                U=20.0,
                dtau=0.005,
                walkers=240,
                warmup=250,
                measurements=20,
                separation=4,
                seed=17,
                tolerance=0.12,
            ),
        )
        for case in cases
            problem = CPAFQMCProblem(
                kinetic,
                case.U,
                1,
                1;
                cell_count=2,
            )
            controls = CPAFQMCParameters(
                dtau=case.dtau,
                walker_count=case.walkers,
                warmup_steps=case.warmup,
                measurement_count=case.measurements,
                steps_between_measurements=case.separation,
                orthogonalize_every=5,
                population_control_every=5,
                back_propagation_steps=0,
                error_block_size=5,
                seed=case.seed,
            )
            result = run_cp_afqmc(problem, controls)
            exact_centered_energy = -sqrt(case.U^2 + 16) / 2
            @test isapprox(
                result.summary.energy,
                exact_centered_energy;
                atol=case.tolerance,
                rtol=0.0,
            )
            @test result.diagnostics.final_live_walkers == case.walkers
            @test result.diagnostics.population_controls > 0
        end
    end

    @testset "Fixed high-spin sector with an empty spin determinant" begin
        problem = two_orbital_cp_afqmc_problem(2, 20.0, 4, 0)
        controls = CPAFQMCParameters(
            dtau=0.02,
            walker_count=16,
            warmup_steps=10,
            measurement_count=4,
            steps_between_measurements=2,
            orthogonalize_every=2,
            population_control_every=2,
            back_propagation_steps=0,
            error_block_size=2,
            seed=23,
        )
        result = run_cp_afqmc(problem, controls)
        @test isapprox(result.summary.energy, -14.0; atol=3.0e-12, rtol=0.0)
        @test result.summary.energy_standard_error <= 3.0e-12
        @test iszero(result.summary.mixed_double_occupancy_per_cell)
        @test result.summary.density == 1.0
        @test result.diagnostics.overlap_inverse_failures == 0
    end

    @testset "All orbital and momentum spin channels" begin
        kinetic = [
            0.0 0.0 1.0 0.0 1.75 0.0 0.85 -0.65
            0.0 0.0 0.0 1.75 0.0 1.0 -0.65 0.85
            1.0 0.0 0.0 0.0 0.85 0.65 1.75 0.0
            0.0 1.75 0.0 0.0 0.65 0.85 0.0 1.0
            1.75 0.0 0.85 0.65 0.0 0.0 1.0 0.0
            0.0 1.0 0.65 0.85 0.0 0.0 0.0 1.75
            0.85 -0.65 1.75 0.0 1.0 0.0 0.0 0.0
            -0.65 0.85 0.0 1.0 0.0 1.75 0.0 0.0
        ]
        problem = CPAFQMCProblem(
            kinetic,
            0.0,
            1,
            1;
            lattice_size=2,
            cell_count=4,
        )
        controls = CPAFQMCParameters(
            dtau=0.05,
            walker_count=2,
            warmup_steps=2,
            measurement_count=1,
            steps_between_measurements=1,
            orthogonalize_every=1,
            population_control_every=1,
            back_propagation_steps=2,
            minimum_backprop_ancestors=2,
            error_block_size=1,
            seed=5,
        )
        result = run_cp_afqmc(problem, controls)
        structure = only(result.measurements).structure_factor
        expected_q0 = [0.125 -0.125; -0.125 0.125]
        expected_nonzero_q = [0.25 0.0; 0.0 0.25]
        @test isapprox(structure[:, :, 1, 1], expected_q0; atol=3.0e-12, rtol=0.0)
        for momentum_index in ((2, 1), (1, 2), (2, 2))
            @test isapprox(
                structure[:, :, momentum_index...],
                expected_nonzero_q;
                atol=3.0e-12,
                rtol=0.0,
            )
        end
        @test isapprox(
            result.summary.backpropagated_energy,
            -4.5;
            atol=3.0e-12,
            rtol=0.0,
        )
        @test isapprox(
            result.summary.backpropagated_double_occupancy_per_cell,
            0.03125;
            atol=3.0e-12,
            rtol=0.0,
        )
        @test result.diagnostics.minimum_distinct_backprop_ancestors == 2
    end

    @testset "Back-propagated free spin correlations" begin
        problem = two_orbital_cp_afqmc_problem(2, 0.0, 2, 2)
        trial = one_body_trial(problem; pattern=:free)
        controls = CPAFQMCParameters(
            dtau=0.04,
            walker_count=24,
            warmup_steps=5,
            measurement_count=4,
            steps_between_measurements=2,
            orthogonalize_every=2,
            population_control_every=2,
            back_propagation_steps=3,
            error_block_size=2,
            seed=29,
        )
        result = run_cp_afqmc(problem, controls; trial=trial)
        density = trial.up * transpose(trial.up)
        orbital_sign = Diagonal([isodd(index) ? 1.0 : -1.0 for index in 1:8])
        expected_alm = (
            tr(density) - tr(orbital_sign * density * orbital_sign * density)
        ) / (2 * problem.cell_count)

        @test isapprox(
            result.summary.S_alm_q0,
            expected_alm;
            atol=3.0e-12,
            rtol=3.0e-12,
        )
        @test isapprox(result.summary.S_fm_q0, 0.0; atol=3.0e-12, rtol=0.0)
        @test result.summary.spin_structure_momenta_x == [0.0, pi]
        @test result.summary.spin_structure_momenta_y == [0.0, pi]
        @test size(result.summary.orbital_odd_spin_structure_factor) == (2, 2)
        @test size(
            result.summary.orbital_odd_spin_structure_factor_standard_error,
        ) == (2, 2)
        @test size(result.summary.orbital_even_spin_structure_factor) == (2, 2)
        @test size(
            result.summary.orbital_even_spin_structure_factor_standard_error,
        ) == (2, 2)
        @test result.diagnostics.minimum_distinct_backprop_ancestors > 0
        @test result.diagnostics.overlap_inverse_failures == 0
        for measurement in result.measurements
            structure = measurement.structure_factor
            @test !isnothing(structure)
            @test size(structure) == (2, 2, 2, 2)
            @test maximum(abs, imag.(structure)) <= 3.0e-12
        end
    end

    @testset "Signed Delta in exact atomic states" begin
        problem = CPAFQMCProblem(
            zeros(2, 2), 0.0, 1, 1; lattice_size=1, cell_count=1,
        )
        controls = CPAFQMCParameters(
            walker_count=4,
            warmup_steps=2,
            measurement_count=4,
            steps_between_measurements=1,
            orthogonalize_every=1,
            population_control_every=1,
            back_propagation_steps=1,
            error_block_size=2,
            seed=43,
        )
        orbital_x = reshape([1.0, 0.0], 2, 1)
        orbital_y = reshape([0.0, 1.0], 2, 1)
        balanced = fill(inv(sqrt(2.0)), 2, 1)
        cases = (
            (up=orbital_x, down=orbital_y, delta=1.0, second_moment=1.0),
            (up=orbital_y, down=orbital_x, delta=-1.0, second_moment=1.0),
            (up=balanced, down=balanced, delta=0.0, second_moment=0.5),
        )
        # All these states are stationary at K=U=0. The tolerance covers only
        # roundoff from QR and overlap solves, not Monte Carlo uncertainty.
        for case in cases
            trial = SlaterTrial(case.up, case.down)
            result = run_cp_afqmc(problem, controls; trial=trial)
            expected = (mx=case.delta, my=-case.delta, m_fm=0.0, delta_alm=case.delta)
            @test length(result.order_measurements) == controls.measurement_count
            for (measurement, order) in zip(result.measurements, result.order_measurements)
                @test order.step == measurement.step
                for observable in keys(expected)
                    @test isapprox(
                        getproperty(order, observable),
                        getproperty(expected, observable);
                        atol=3.0e-12,
                        rtol=0.0,
                    )
                end
            end
            for observable in keys(expected)
                @test isapprox(
                    getproperty(result.summary, observable),
                    getproperty(expected, observable);
                    atol=3.0e-12,
                    rtol=0.0,
                )
                @test getproperty(
                    result.summary, Symbol(observable, :_standard_error),
                ) <= 3.0e-12
            end
            @test isapprox(
                result.summary.m_alm_squared,
                case.second_moment;
                atol=3.0e-12,
                rtol=0.0,
            )
            @test result.summary.m_alm_squared_standard_error <= 3.0e-12
            if iszero(case.delta)
                @test result.summary.m_alm_squared > result.summary.delta_alm^2 + 0.4
            end
        end
    end

    @testset "Delta agrees with the DQMC observable convention" begin
        problem = CPAFQMCProblem(
            zeros(8, 8), 0.0, 2, 1; lattice_size=2, cell_count=4,
        )
        rng = Xoshiro(47)
        trial = SlaterTrial(randn(rng, 8, 2), randn(rng, 8, 1))
        controls = CPAFQMCParameters(
            walker_count=4,
            warmup_steps=2,
            measurement_count=4,
            steps_between_measurements=1,
            orthogonalize_every=1,
            population_control_every=1,
            back_propagation_steps=1,
            error_block_size=2,
            seed=49,
        )
        result = run_cp_afqmc(problem, controls; trial=trial)
        expected = AltermagnetDQMCTrial._altermagnetic_observables_from_greens(
            Matrix{Float64}(I, 8, 8) - trial.up * transpose(trial.up),
            Matrix{Float64}(I, 8, 8) - trial.down * transpose(trial.down),
            2,
            1.0,
        )
        for observable in (:mx, :my, :m_fm, :delta_alm, :S_alm_q0, :m_alm_squared)
            @test isapprox(
                getproperty(result.summary, observable),
                getproperty(expected, observable);
                atol=3.0e-12,
                rtol=3.0e-12,
            )
        end
        @test isapprox(result.summary.m_fm, 1 / 8; atol=3.0e-12, rtol=0.0)
        @test isapprox(
            result.summary.m_alm_squared,
            result.summary.S_alm_q0 / 4;
            atol=3.0e-12,
            rtol=0.0,
        )
        @test isapprox(
            result.summary.m_alm_squared_standard_error,
            result.summary.S_alm_q0_standard_error / 4;
            atol=3.0e-12,
            rtol=0.0,
        )
    end

    @testset "Delta weights only live back-propagated walkers" begin
        problem = CPAFQMCProblem(
            zeros(2, 2), 0.0, 1, 1; lattice_size=1, cell_count=1,
        )
        trial = SlaterTrial(ones(2, 1), ones(2, 1))
        controls = CPAFQMCParameters(
            walker_count=3,
            warmup_steps=1,
            measurement_count=2,
            steps_between_measurements=1,
            back_propagation_steps=1,
            error_block_size=1,
            seed=51,
        )
        state = initialize_cp_afqmc(problem, controls; trial=trial)
        step_cp_afqmc!(state)
        orbital_x = reshape([1.0, 0.0], 2, 1)
        orbital_y = reshape([0.0, 1.0], 2, 1)
        for (walker, up, down, weight) in zip(
            state.walkers,
            (orbital_x, orbital_y, orbital_x),
            (orbital_y, orbital_x, orbital_y),
            (1.0, 3.0, 1000.0),
        )
            walker.up .= up
            walker.down .= down
            walker.anchor_up .= up
            walker.anchor_down .= down
            walker.log_weight = log(weight)
        end
        state.walkers[3].alive = false
        order = measure_cp_afqmc(state; include_order=true).order_measurement
        @test isapprox(order.mx, -0.5; atol=3.0e-12, rtol=0.0)
        @test isapprox(order.my, 0.5; atol=3.0e-12, rtol=0.0)
        @test isapprox(order.m_fm, 0.0; atol=3.0e-12, rtol=0.0)
        @test isapprox(order.delta_alm, -0.5; atol=3.0e-12, rtol=0.0)

        # Altering the current ket while keeping the BP anchor unchanged must
        # not change a BP order estimate.
        state.walkers[1].up .= orbital_y
        state.walkers[1].down .= orbital_x
        changed = measure_cp_afqmc(state; include_order=true).order_measurement
        @test isequal(changed, order)
    end

    @testset "Order measurement does not advance the state or RNG" begin
        problem = two_orbital_cp_afqmc_problem(2, 2.0, 2, 2)
        controls = CPAFQMCParameters(
            walker_count=4,
            warmup_steps=2,
            measurement_count=2,
            steps_between_measurements=1,
            back_propagation_steps=2,
            error_block_size=1,
            seed=53,
        )
        state = initialize_cp_afqmc(problem, controls)
        for _ in 1:controls.warmup_steps
            step_cp_afqmc!(state)
        end
        before = IOBuffer()
        serialize(before, state)
        ordinary = measure_cp_afqmc(state)
        augmented = measure_cp_afqmc(state; include_order=true)
        @test augmented.measurement isa CPAFQMCMeasurement
        for field in fieldnames(typeof(ordinary))
            @test isequal(
                getproperty(ordinary, field),
                getproperty(augmented.measurement, field),
            )
        end
        after = IOBuffer()
        serialize(after, state)
        @test take!(before) == take!(after)
        @test augmented.order_measurement.step == ordinary.step
        @test all(isfinite, (
            augmented.order_measurement.mx,
            augmented.order_measurement.my,
            augmented.order_measurement.m_fm,
            augmented.order_measurement.delta_alm,
        ))
    end

    @testset "Signed order requires both back propagation and orbital geometry" begin
        for (L, bp_steps) in ((1, 0), (nothing, 1))
            problem = CPAFQMCProblem(
                zeros(2, 2), 0.0, 1, 1; lattice_size=L, cell_count=1,
            )
            controls = CPAFQMCParameters(
                walker_count=2,
                warmup_steps=1,
                measurement_count=2,
                steps_between_measurements=1,
                back_propagation_steps=bp_steps,
                error_block_size=1,
                seed=59,
            )
            result = run_cp_afqmc(problem, controls)
            for observable in (:mx, :my, :m_fm, :delta_alm, :m_alm_squared)
                @test ismissing(getproperty(result.summary, observable))
                @test ismissing(getproperty(
                    result.summary, Symbol(observable, :_standard_error),
                ))
            end
            for order in result.order_measurements
                @test all(ismissing, (order.mx, order.my, order.m_fm, order.delta_alm))
            end
        end
    end

    @testset "Back-propagation controls fail early" begin
        problem = CPAFQMCProblem([0.0 -1.0; -1.0 0.0], 2.0, 1, 1)
        controls = CPAFQMCParameters(
            walker_count=10,
            warmup_steps=1,
            measurement_count=2,
            steps_between_measurements=1,
            back_propagation_steps=3,
            error_block_size=1,
        )
        @test_throws ArgumentError run_cp_afqmc(problem, controls)
    end
end
