module CorrelatedTrialAFQMCTests

using Test
using LinearAlgebra
using Random: Xoshiro
using Serialization: serialize, deserialize
using AltermagnetDQMCTrial

include(joinpath(@__DIR__, "..", "scripts", "correlated_trial_afqmc.jl"))
const CT = CorrelatedTrialAFQMC
const SJ = CT.SJ
const CP = AltermagnetDQMCTrial

occupied_modes(bits, modes) = [i for i in 1:modes if !iszero(bits & (UInt64(1) << (i - 1)))]

# Independent determinant minors retain the absolute walker amplitude and the
# up-before-down Fock convention; neither QR nor the adapter enters this oracle.
function independent_amplitudes(basis, up, down)
    minor(matrix, rows) = isempty(rows) ? 1.0 : det(matrix[rows, :])
    return [minor(up, occupied_modes(u, basis.nmodes)) *
            minor(down, occupied_modes(d, basis.nmodes))
            for u in basis.up_states for d in basis.down_states]
end

function independent_exterior(matrix, bitstates, modes)
    occupations = [occupied_modes(bits, modes) for bits in bitstates]
    return [isempty(rows) ? 1.0 : det(matrix[rows, columns])
            for rows in occupations, columns in occupations]
end

function independent_fock_propagator(basis, up, down)
    exterior_up = independent_exterior(up, basis.up_states, basis.nmodes)
    exterior_down = independent_exterior(down, basis.down_states, basis.nmodes)
    return kron(exterior_up, exterior_down)
end

function independent_slice(basis, kinetic, dtau, U, fields)
    kinetic_half = exp(-dtau .* kinetic ./ 2)
    gamma = acosh(exp(dtau * U / 2))
    up = kinetic_half * Diagonal(exp.(gamma .* fields)) * kinetic_half
    down = kinetic_half * Diagonal(exp.(-gamma .* fields)) * kinetic_half
    return independent_fock_propagator(basis, up, down)
end

function independent_spin_occupancies(basis, site)
    mask = UInt64(1) << (site - 1)
    nup = [Float64(!iszero(u & mask)) for u in basis.up_states for _ in basis.down_states]
    ndown = [Float64(!iszero(d & mask)) for _ in basis.up_states for d in basis.down_states]
    return nup, ndown
end

function test_parameters(; dtau=0.025, seed=432912, back_propagation_steps=3,
                         walker_count=6, orthogonalize_every=2,
                         population_control_every=3, minimum_backprop_ancestors=1)
    return CPAFQMCParameters(
        dtau=dtau, walker_count=walker_count, warmup_steps=0,
        measurement_count=2, steps_between_measurements=1,
        orthogonalize_every=orthogonalize_every,
        population_control_every=population_control_every,
        back_propagation_steps=back_propagation_steps,
        minimum_backprop_ancestors=minimum_backprop_ancestors,
        error_block_size=1, seed=seed,
    )
end

function initialize_case(kinetic, U, nup, ndown, trial_state, initializer;
                         parameters=test_parameters(), Lx=div(size(kinetic, 1), 2), Ly=1,
                         overlap_tolerance=1e-12)
    H = SJ.benchmark_hamiltonian(kinetic, U, nup, ndown)
    state = CT.initialize_correlated_afqmc(
        H, parameters; trial_state=trial_state, initializer=initializer,
        Lx=Lx, Ly=Ly, overlap_tolerance=overlap_tolerance,
    )
    return H, state
end

@testset "Enumerated correlated-trial AFQMC" begin
    # Tiny deterministic Fock sums use 1e-12-scale tolerances. Sequential
    # projection/QR comparisons allow 1e-10 accumulated Float64 roundoff.
    @testset "Absolute determinant amplitudes and overlap gauges" begin
        rng = Xoshiro(97613)
        for (nup, ndown) in ((0, 0), (1, 1), (2, 2), (3, 3), (4, 4))
            H = SJ.benchmark_hamiltonian(zeros(4, 4), 4.0, nup, ndown)
            left = SlaterTrial(randn(rng, 4, nup), randn(rng, 4, ndown))
            right = SlaterTrial(randn(rng, 4, nup), randn(rng, 4, ndown))
            expected = independent_amplitudes(H.basis, right.up, right.down)
            amplitudes = CT.determinant_amplitudes(H, right.up, right.down)
            @test isapprox(amplitudes, expected; atol=3e-13, rtol=3e-13)
            bare_left = independent_amplitudes(H.basis, left.up, left.down)
            overlap = det(transpose(left.up) * right.up) *
                      det(transpose(left.down) * right.down)
            @test isapprox(dot(bare_left, amplitudes), overlap; atol=4e-13, rtol=4e-13)
            if nup > 0
                changed = copy(right.up)
                changed[:, 1] .*= -2.7
                @test isapprox(CT.determinant_amplitudes(H, changed, right.down),
                               -2.7 .* amplitudes; atol=5e-13, rtol=4e-13)
                @test isapprox(dot(bare_left, CT.determinant_amplitudes(H, changed, right.down)),
                               -2.7 * overlap; atol=5e-13, rtol=4e-13)
            end
        end
    end

    @testset "Slater-limit mixed observables match production" begin
        rng = Xoshiro(162715)
        kinetic = [0.2 -0.8 0.3 -0.4; -0.8 -0.1 0.7 0.2;
                   0.3 0.7 0.4 -0.9; -0.4 0.2 -0.9 -0.3]
        for U in (0.0, 4.0, 20.0)
            H = SJ.benchmark_hamiltonian(kinetic, U, 2, 2)
            left = SlaterTrial(randn(rng, 4, 2), randn(rng, 4, 2))
            trial_state = SJ.onsite_jastrow_state(H, left)
            _, state = initialize_case(kinetic, U, 2, 2, trial_state, left)
            problem = CPAFQMCProblem(kinetic, U, 2, 2; cell_count=2)
            for _ in 1:4
                right = SlaterTrial(randn(rng, 4, 2), randn(rng, 4, 2))
                walker = deepcopy(state.base.walkers[1])
                walker.up, walker.down = copy(right.up), copy(right.down)
                values = CT.mixed_correlated_observables(state, walker)
                production = mixed_local_energy(problem, left.up, left.down, right.up, right.down)
                @test isapprox(values.energy, production.total; atol=3e-11, rtol=3e-12)
                @test isapprox(values.kinetic_energy, production.kinetic; atol=3e-11, rtol=3e-12)
                @test isapprox(values.centered_interaction_energy, production.interaction;
                               atol=3e-11, rtol=3e-12)
                @test isapprox(values.double_occupancy_total, production.double_occupancy;
                               atol=3e-11, rtol=3e-12)
                right_state = independent_amplitudes(H.basis, right.up, right.down)
                denominator = dot(trial_state, right_state)
                diagonal = SJ.diagonal_observables(H; Lx=2, Ly=1)
                for name in keys(diagonal)
                    expected = dot(trial_state, getproperty(diagonal, name) .* right_state) / denominator
                    @test isapprox(getproperty(values, name), expected; atol=3e-11, rtol=3e-12)
                end
            end
        end
    end

    @testset "Correlated HS ratios retain joint spin occupancy" begin
        kinetic = [0.0 -1.0; -1.0 0.0]
        H = SJ.benchmark_hamiltonian(kinetic, 4.0, 1, 1)
        orbital = fill(inv(sqrt(2)), 2, 1)
        initializer = SlaterTrial(orbital, orbital)
        trial = SJ.onsite_jastrow_state(H, initializer; g=1.2)
        _, state = initialize_case(kinetic, 4.0, 1, 1, trial, initializer)
        right = independent_amplitudes(H.basis, initializer.up, initializer.down)
        mixed_weights = state.oracle.trial .* right ./ dot(state.oracle.trial, right)
        gamma = 0.61
        for site in 1:2
            nup, ndown = independent_spin_occupancies(H.basis, site)
            plus, minus = CT._site_ratios(state.oracle, right, site, gamma)
            @test isapprox(plus, dot(mixed_weights, exp.(gamma .* (nup - ndown)));
                           atol=3e-13, rtol=3e-13)
            @test isapprox(minus, dot(mixed_weights, exp.(-gamma .* (nup - ndown)));
                           atol=3e-13, rtol=3e-13)
            mean_up, mean_down = dot(mixed_weights, nup), dot(mixed_weights, ndown)
            joint = dot(mixed_weights, nup .* ndown)
            expansion = 1 + (exp(gamma) - 1) * mean_up + (exp(-gamma) - 1) * mean_down +
                        (exp(gamma) - 1) * (exp(-gamma) - 1) * joint
            factorized = (1 + (exp(gamma) - 1) * mean_up) *
                         (1 + (exp(-gamma) - 1) * mean_down)
            @test isapprox(plus, expansion; atol=3e-13, rtol=3e-13)
            @test abs(plus - factorized) > 0.02
        end
        values = CT.mixed_correlated_observables(state, state.base.walkers[1])
        @test isapprox(values.energy, dot(state.oracle.trial, H * right) /
                       dot(state.oracle.trial, right); atol=3e-13, rtol=3e-13)
        @test isapprox(values.m_alm_squared,
                       dot(mixed_weights, SJ.diagonal_observables(H; Lx=1, Ly=1).m_alm_squared);
                       atol=3e-13, rtol=3e-13)
        @test values.m_alm_squared > values.delta_alm^2 + 0.5
    end

    @testset "Exterior-power kinetic action and complete HS slices" begin
        rng = Xoshiro(267519)
        kinetic = [0.2 -0.8 0.3 -0.4; -0.8 -0.1 0.7 0.2;
                   0.3 0.7 0.4 -0.9; -0.4 0.2 -0.9 -0.3]
        H = SJ.benchmark_hamiltonian(kinetic, 4.0, 2, 2)
        left = SlaterTrial(randn(rng, 4, 2), randn(rng, 4, 2))
        trial = SJ.onsite_jastrow_state(H, left; g=0.7)
        _, state = initialize_case(kinetic, 4.0, 2, 2, trial, left)
        kinetic_half = exp(-state.base.parameters.dtau .* kinetic ./ 2)
        fock_half = independent_fock_propagator(H.basis, kinetic_half, kinetic_half)
        @test isapprox(state.oracle.kinetic_up,
                       independent_exterior(kinetic_half, H.basis.up_states, 4);
                       atol=3e-13, rtol=3e-13)
        @test isapprox(state.oracle.kinetic_down,
                       independent_exterior(kinetic_half, H.basis.down_states, 4);
                       atol=3e-13, rtol=3e-13)
        vector = randn(rng, length(H.basis))
        @test isapprox(CT.apply_kinetic_to_vector(state.oracle, vector), fock_half * vector;
                       atol=3e-12, rtol=3e-12)
        @test isapprox(CT.apply_kinetic_to_vector(state.oracle, vector; transpose=true),
                       transpose(fock_half) * vector; atol=3e-12, rtol=3e-12)
        raw = independent_amplitudes(H.basis, left.up, left.down)
        propagated = CT.determinant_amplitudes(H, kinetic_half * left.up, kinetic_half * left.down)
        @test isapprox(propagated, CT.apply_kinetic_to_vector(state.oracle, raw);
                       atol=3e-12, rtol=3e-12)
        nonsymmetric = copy(kinetic_half)
        nonsymmetric[1, 2] += 0.13
        general_oracle = CT.exact_trial_oracle(H, trial; Lx=2, Ly=1,
                                              kinetic_half=nonsymmetric)
        general_fock = independent_fock_propagator(H.basis, nonsymmetric, nonsymmetric)
        @test norm(general_fock - transpose(general_fock)) > 0.1
        @test isapprox(CT.apply_kinetic_to_vector(general_oracle, vector), general_fock * vector;
                       atol=3e-12, rtol=3e-12)
        @test isapprox(CT.apply_kinetic_to_vector(general_oracle, vector; transpose=true),
                       transpose(general_fock) * vector; atol=3e-12, rtol=3e-12)
        # Summing every HS field restores the centered interaction, including
        # the scalar that cancels from normalized AFQMC population weights.
        for U in (0.0, 4.0, 20.0), dtau in (0.01, 0.05)
            dimer_kinetic = [0.0 -1.0; -1.0 0.0]
            dimer = SJ.benchmark_hamiltonian(dimer_kinetic, U, 1, 1)
            summed = zeros(4, 4)
            dimer_oracle = CT.exact_trial_oracle(dimer, ones(4); Lx=1, Ly=1,
                kinetic_half=exp(-dtau .* dimer_kinetic ./ 2))
            adapter_sum = zeros(4, 4)
            gamma = acosh(exp(dtau * U / 2))
            for first in (-1, 1), second in (-1, 1)
                summed .+= independent_slice(dimer.basis, dimer_kinetic, dtau, U,
                                             Int8[first, second]) ./ 4
                fields = Int8[first, second]
                for column in 1:4
                    vector = zeros(4)
                    vector[column] = 1.0
                    vector = CT.apply_kinetic_to_vector(dimer_oracle, vector)
                    vector .*= exp.(gamma .* (dimer_oracle.spin_occupations * fields))
                    adapter_sum[:, column] .+= CT.apply_kinetic_to_vector(dimer_oracle, vector) ./ 4
                end
            end
            @test isapprox(adapter_sum, summed; atol=5e-13, rtol=5e-13)
            kinetic_fock = SJ.ED.dense_sector_hamiltonian(
                SJ.benchmark_hamiltonian(dimer_kinetic, 0.0, 1, 1),
            )
            interaction = Diagonal(U .* (dimer.double_occupancies .- 0.5))
            kinetic_factor = exp(-dtau .* kinetic_fock ./ 2)
            trotter = kinetic_factor * exp(-dtau .* interaction) * kinetic_factor
            @test isapprox(exp(-dtau * U * dimer.basis.nmodes / 4) .* summed, trotter;
                           atol=5e-13, rtol=5e-13)
            U == 0 && @test isapprox(trotter, exp(-dtau .* kinetic_fock);
                                     atol=5e-13, rtol=5e-13)
        end
    end

    @testset "Exact dimer trial has constant mixed energy through U=20" begin
        kinetic = [0.0 -1.0; -1.0 0.0]
        orbital = fill(inv(sqrt(2)), 2, 1)
        initializer = SlaterTrial(orbital, orbital)
        for U in (0.0, 4.0, 20.0)
            H = SJ.benchmark_hamiltonian(kinetic, U, 1, 1)
            eigensystem = eigen(Symmetric(SJ.ED.dense_sector_hamiltonian(H)))
            analytic_energy = -hypot(U, 4.0) / 2
            @test isapprox(eigensystem.values[1], analytic_energy; atol=2e-12, rtol=2e-13)
            parameters = test_parameters(dtau=0.02, seed=12078, back_propagation_steps=2)
            _, state = initialize_case(kinetic, U, 1, 1, eigensystem.vectors[:, 1], initializer;
                                       parameters=parameters)
            for _ in 1:6
                CT.step_correlated_afqmc!(state)
                measurement = CT.measure_correlated_afqmc(state; backpropagation=false)
                @test isapprox(measurement.mixed.energy, analytic_energy;
                               atol=2e-11, rtol=2e-12)
                @test isnothing(measurement.backpropagated)
                for walker in state.base.walkers
                    walker.alive || continue
                    local_values = CT.mixed_correlated_observables(state, walker)
                    @test isapprox(local_values.energy, analytic_energy;
                                   atol=2e-11, rtol=2e-12)
                end
            end
        end
    end

    @testset "Same-seed Slater path, QR, branching and BP parity" begin
        dimer = [0.0 -1.0; -1.0 0.0]
        chain = [0.0 -1.0 0.0 0.0; -1.0 0.0 -1.0 0.0;
                 0.0 -1.0 0.0 -1.0; 0.0 0.0 -1.0 0.0]
        for (kinetic, U, particles) in ((dimer, 0.0, 1), (dimer, 4.0, 1),
                                        (dimer, 20.0, 1), (chain, 4.0, 2))
            orbital = eigen(Symmetric(kinetic)).vectors[:, 1:particles]
            initializer = SlaterTrial(orbital, orbital)
            parameters = test_parameters(dtau=0.02, seed=571927, back_propagation_steps=3)
            H = SJ.benchmark_hamiltonian(kinetic, U, particles, particles)
            bare = SJ.onsite_jastrow_state(H, initializer)
            _, state = initialize_case(kinetic, U, particles, particles, bare, initializer;
                                       parameters=parameters)
            cells = div(size(kinetic, 1), 2)
            problem = CPAFQMCProblem(kinetic, U, particles, particles;
                                    cell_count=cells, lattice_size=cells == 1 ? 1 : nothing)
            production = initialize_cp_afqmc(problem, parameters; trial=initializer)
            for step in 1:8
                CT.step_correlated_afqmc!(state)
                step_cp_afqmc!(production)
                @test state.base.step == production.step == step
                @test state.base.constraint_rejections == production.constraint_rejections
                @test state.base.killed_walkers == production.killed_walkers
                @test state.base.population_controls == production.population_controls
                @test state.base.site_order == production.site_order
                @test rand(copy(state.base.rng)) == rand(copy(production.rng))
                for (actual, reference) in zip(state.base.walkers, production.walkers)
                    @test actual.alive == reference.alive
                    @test isapprox(actual.up, reference.up; atol=2e-11, rtol=2e-11)
                    @test isapprox(actual.down, reference.down; atol=2e-11, rtol=2e-11)
                    @test isapprox(actual.log_weight, reference.log_weight; atol=2e-11, rtol=2e-11)
                    @test isapprox(actual.log_overlap, reference.log_overlap; atol=2e-11, rtol=2e-11)
                    @test actual.fields == reference.fields
                    @test actual.field_end_ids == reference.field_end_ids
                    @test actual.anchor_id == reference.anchor_id
                    @test isapprox(actual.anchor_up, reference.anchor_up; atol=2e-11, rtol=2e-11)
                    @test isapprox(actual.anchor_down, reference.anchor_down; atol=2e-11, rtol=2e-11)
                end
                mixed = CT.measure_correlated_afqmc(state; backpropagation=false).mixed
                if step >= parameters.back_propagation_steps
                    reference = measure_cp_afqmc(production)
                    measurement = CT.measure_correlated_afqmc(state)
                    @test isapprox(mixed.energy, reference.mixed_total_energy; atol=3e-10, rtol=3e-11)
                    @test isapprox(measurement.backpropagated.energy,
                                   reference.backpropagated_total_energy; atol=3e-10, rtol=3e-11)
                    @test measurement.distinct_backprop_ancestors == reference.distinct_backprop_ancestors
                    for (walker, reference_walker) in zip(state.base.walkers, production.walkers)
                        left_up, left_down = CP._cp_backpropagated_left(production, reference_walker)
                        expected_left = normalize(independent_amplitudes(H.basis, left_up, left_down))
                        actual_left = CT.backpropagated_trial(state, walker)
                        @test isapprox(actual_left, expected_left; atol=3e-11, rtol=3e-11)
                    end
                end
            end
        end
    end

    @testset "Correlated checkpoint replay is deterministic" begin
        kinetic = [0.0 -1.0; -1.0 0.0]
        H = SJ.benchmark_hamiltonian(kinetic, 4.0, 1, 1)
        orbital = fill(inv(sqrt(2)), 2, 1)
        initializer = SlaterTrial(orbital, orbital)
        trial = SJ.onsite_jastrow_state(H, initializer; g=0.8)
        bare = SJ.onsite_jastrow_state(H, initializer)
        @test norm(trial - bare) > 0.1
        parameters = test_parameters(seed=99153, orthogonalize_every=3,
                                     population_control_every=2, back_propagation_steps=3)
        _, uninterrupted = initialize_case(kinetic, 4.0, 1, 1, trial, initializer;
                                            parameters=parameters)
        for _ in 1:3
            CT.step_correlated_afqmc!(uninterrupted)
        end
        checkpoint = IOBuffer()
        serialize(checkpoint, uninterrupted)
        seekstart(checkpoint)
        resumed = deserialize(checkpoint)
        @test resumed isa CT.CorrelatedState
        @test resumed.oracle.trial == uninterrupted.oracle.trial
        @test resumed.oracle.trial !== uninterrupted.oracle.trial
        @test resumed.base.step == uninterrupted.base.step == 3
        for step in 4:8
            expected_step = CT.step_correlated_afqmc!(uninterrupted)
            resumed_step = CT.step_correlated_afqmc!(resumed)
            @test resumed_step == expected_step
            @test resumed.base.step == uninterrupted.base.step == step
            @test rand(copy(resumed.base.rng)) == rand(copy(uninterrupted.base.rng))
            @test resumed.base.site_order == uninterrupted.base.site_order
            @test resumed.base.next_lineage_id == uninterrupted.base.next_lineage_id
            for (actual, expected) in zip(resumed.base.walkers, uninterrupted.base.walkers)
                @test actual.up == expected.up
                @test actual.down == expected.down
                @test actual.log_weight == expected.log_weight
                @test actual.log_overlap == expected.log_overlap
                @test actual.fields == expected.fields
                @test actual.field_end_ids == expected.field_end_ids
                @test actual.anchor_up == expected.anchor_up
                @test actual.anchor_down == expected.anchor_down
                @test actual.anchor_id == expected.anchor_id
                @test actual.alive == expected.alive
            end
            expected_measurement = CT.measure_correlated_afqmc(uninterrupted)
            resumed_measurement = CT.measure_correlated_afqmc(resumed)
            @test resumed_measurement == expected_measurement
            @test resumed_measurement.mixed.m_alm_squared == expected_measurement.mixed.m_alm_squared
            @test resumed_measurement.backpropagated.m_alm_squared ==
                  expected_measurement.backpropagated.m_alm_squared
        end
    end

    @testset "Correlated BP ordering and direct Delta moments" begin
        kinetic = [0.0 -1.0; -1.0 0.0]
        H = SJ.benchmark_hamiltonian(kinetic, 4.0, 1, 1)
        orbital = fill(inv(sqrt(2)), 2, 1)
        initializer = SlaterTrial(orbital, orbital)
        trial = SJ.onsite_jastrow_state(H, initializer; g=0.8)
        parameters = test_parameters(dtau=0.07, back_propagation_steps=3,
                                     minimum_backprop_ancestors=2)
        _, state = initialize_case(kinetic, 4.0, 1, 1, trial, initializer;
                                   parameters=parameters)
        fields = [Int8[1, -1], Int8[-1, -1], Int8[-1, 1]]
        matrices = [independent_slice(H.basis, kinetic, parameters.dtau, 4.0, field)
                    for field in fields]
        expected_left = normalize(matrices[1] * matrices[2] * matrices[3] * state.oracle.trial)
        wrong_order = normalize(matrices[3] * matrices[2] * matrices[1] * state.oracle.trial)
        @test norm(expected_left - wrong_order) > 1e-3
        for (index, walker) in enumerate(state.base.walkers)
            walker.fields = deepcopy(fields)
            walker.field_end_ids = [index + 10, index + 20, index + 30]
            for field in fields
                walker.up = CP._cp_apply_slice_matrix(walker.up, state.base.kinetic_half,
                                                      state.base.gamma, field, 1)
                walker.down = CP._cp_apply_slice_matrix(walker.down, state.base.kinetic_half,
                                                        state.base.gamma, field, -1)
            end
            @test isapprox(CT.backpropagated_trial(state, walker), expected_left;
                           atol=3e-12, rtol=3e-12)
        end
        state.base.step = 3
        anchor = independent_amplitudes(H.basis, initializer.up, initializer.down)
        denominator = dot(expected_left, anchor)
        expected_energy = dot(expected_left, H * anchor) / denominator
        diagonal = SJ.diagonal_observables(H; Lx=1, Ly=1)
        measurement = CT.measure_correlated_afqmc(state)
        @test isapprox(measurement.backpropagated.energy, expected_energy;
                       atol=3e-12, rtol=3e-12)
        for name in keys(diagonal)
            expected = dot(expected_left, getproperty(diagonal, name) .* anchor) / denominator
            @test isapprox(getproperty(measurement.backpropagated, name), expected;
                           atol=3e-12, rtol=3e-12)
        end
        @test measurement.distinct_backprop_ancestors == parameters.walker_count
        @test abs(measurement.backpropagated.m_alm_squared -
                  measurement.backpropagated.delta_alm^2) > 0.1
        for walker in state.base.walkers
            walker.anchor_id = 1
        end
        @test_throws ErrorException CT.measure_correlated_afqmc(state)
        for (index, walker) in enumerate(state.base.walkers)
            walker.anchor_id = index
        end
        state.base.walkers[1].fields = fields[1:2]
        @test_throws ErrorException CT.measure_correlated_afqmc(state)
    end

    @testset "Signed overlap, positive-branch constraint and failure guards" begin
        kinetic = zeros(2, 2)
        H = SJ.benchmark_hamiltonian(kinetic, 4.0, 1, 1)
        orbital = fill(inv(sqrt(2)), 2, 1)
        initializer = SlaterTrial(orbital, orbital)
        bare = independent_amplitudes(H.basis, initializer.up, initializer.down)
        _, phase_state = initialize_case(kinetic, 4.0, 1, 1, -bare, initializer)
        @test phase_state.oracle.trial_phase == -1
        @test isapprox(phase_state.oracle.trial, bare; atol=3e-13, rtol=3e-13)
        overlap = CT._walker_overlap(phase_state, initializer.up, initializer.down)
        negative = CT._walker_overlap(phase_state, -2 .* initializer.up, initializer.down)
        @test overlap.sign == 1
        @test negative.sign == -1
        @test isapprox(negative.log_overlap, overlap.log_overlap + log(2);
                       atol=3e-13, rtol=3e-13)
        trial = normalize([0.0, -1.0, 2.0, 0.0])
        parameters = test_parameters(dtau=2log(cosh(1.0)) / 4, back_propagation_steps=0)
        _, state = initialize_case(kinetic, 4.0, 1, 1, trial, initializer; parameters=parameters)
        ratios = CT._site_ratios(state.oracle, bare, 1, state.base.gamma)
        @test ratios.plus < 0
        @test ratios.minus > 0
        CT.step_correlated_afqmc!(state)
        @test state.base.constraint_rejections >= 1
        @test all(walker -> walker.alive, state.base.walkers)
        @test all(walker -> CT._walker_overlap(state, walker.up, walker.down).sign > 0,
                  state.base.walkers)
        measured = CT.measure_correlated_afqmc(state)
        @test isnothing(measured.backpropagated)
        @test measured.distinct_backprop_ancestors == 0

        # A zero/cancellation-dominated overlap cannot define an importance
        # distribution. It must fail loudly, not become a finite estimator.
        node = normalize([0.0, 1.0, -1.0, 0.0])
        @test_throws ErrorException initialize_case(kinetic, 4.0, 1, 1, node, initializer)
        @test_throws ErrorException initialize_case(kinetic, 4.0, 1, 1,
                                                    normalize(node + 1e-14 .* bare), initializer)
        oracle = phase_state.oracle
        @test_throws ErrorException CT.transition_observables(oracle, node, bare)
        @test_throws ErrorException CT.transition_observables(oracle, zeros(4), bare)
        @test_throws ErrorException CT._site_ratios(oracle, zeros(4), 1, 0.3)
        tiny_overlap = [1e-15, 1.0, 0.0, 0.0]
        @test_throws ErrorException CT.transition_observables(oracle, [1.0, 0.0, 0.0, 0.0], tiny_overlap)

        corrupted = deepcopy(phase_state)
        corrupted.base.walkers[1].up .= NaN
        @test_throws ArgumentError CT.step_correlated_afqmc!(corrupted)
        @test corrupted.numerical_failures == 1
        @test corrupted.numerical_overlap_failures == 0
        @test_throws ErrorException CT.step_correlated_afqmc!(corrupted)
        @test_throws ErrorException CT.measure_correlated_afqmc(corrupted)
        overlap_node = deepcopy(phase_state)
        overlap_node.base.walkers[1].down[:, 1] .= [1.0, -1.0] ./ sqrt(2)
        @test_throws ErrorException CT.step_correlated_afqmc!(overlap_node)
        @test overlap_node.numerical_failures == 1
        @test overlap_node.numerical_overlap_failures == 1
        @test_throws ErrorException CT.step_correlated_afqmc!(overlap_node)
        @test_throws ErrorException CT.measure_correlated_afqmc(overlap_node)
        extinct = deepcopy(phase_state)
        for walker in extinct.base.walkers
            walker.alive = false
        end
        @test_throws ErrorException CT.measure_correlated_afqmc(extinct)
        invalid_weight = deepcopy(phase_state)
        invalid_weight.base.walkers[1].log_weight = Inf
        @test_throws ErrorException CT.measure_correlated_afqmc(invalid_weight)
    end

    @testset "Shapes, sector caps and unsupported inputs" begin
        H = SJ.benchmark_hamiltonian(zeros(2, 2), 4.0, 1, 1)
        orbital = fill(inv(sqrt(2)), 2, 1)
        initializer = SlaterTrial(orbital, orbital)
        bare = independent_amplitudes(H.basis, initializer.up, initializer.down)
        half = Matrix{Float64}(I, 2, 2)
        oracle = CT.exact_trial_oracle(H, bare; Lx=1, Ly=1, kinetic_half=half)
        for invalid in (zeros(4), fill(NaN, 4), fill(Inf, 4), complex.(bare))
            @test_throws ArgumentError CT.exact_trial_oracle(H, invalid; Lx=1, Ly=1,
                                                            kinetic_half=half)
        end
        @test_throws DimensionMismatch CT.exact_trial_oracle(H, ones(3); Lx=1, Ly=1,
                                                             kinetic_half=half)
        @test_throws DimensionMismatch CT.exact_trial_oracle(H, bare; Lx=2, Ly=1,
                                                             kinetic_half=half)
        @test_throws ArgumentError CT.exact_trial_oracle(H, bare; Lx=true, Ly=1,
                                                        kinetic_half=half)
        @test_throws DimensionMismatch CT.exact_trial_oracle(H, bare; Lx=1, Ly=1,
                                                             kinetic_half=ones(3, 3))
        @test_throws ArgumentError CT.exact_trial_oracle(H, bare; Lx=1, Ly=1,
                                                        kinetic_half=fill(NaN, 2, 2))
        for tolerance in (0.0, -1.0, 1.0, NaN, Inf, true)
            @test_throws ArgumentError CT.exact_trial_oracle(H, bare; Lx=1, Ly=1,
                kinetic_half=half, overlap_tolerance=tolerance)
        end
        for invalid in (complex.(orbital), fill(NaN, 2, 1), fill(Inf, 2, 1), zeros(2, 1))
            @test_throws ArgumentError CT.determinant_amplitudes(H, invalid, orbital)
            @test_throws ArgumentError CT.determinant_amplitudes(H, orbital, invalid)
        end
        @test_throws DimensionMismatch CT.determinant_amplitudes(H, ones(3, 1), orbital)
        @test_throws DimensionMismatch CT.determinant_amplitudes(H, orbital, ones(2, 2))
        @test_throws ArgumentError CT.determinant_amplitudes(H, 1e300 .* orbital, 1e300 .* orbital)
        @test_throws ArgumentError CT.determinant_amplitudes(H, 1e-300 .* orbital, 1e-300 .* orbital)
        for invalid in (fill(NaN, 4), fill(Inf, 4), complex.(bare))
            @test_throws ArgumentError CT.apply_kinetic_to_vector(oracle, invalid)
            @test_throws ArgumentError CT.transition_observables(oracle, bare, invalid)
        end
        @test CT.apply_kinetic_to_vector(oracle, zeros(4)) == zeros(4)
        @test_throws DimensionMismatch CT.apply_kinetic_to_vector(oracle, ones(3))
        @test_throws DimensionMismatch CT.transition_observables(oracle, ones(3), bare)
        for site in (0, 3, true, 0.5)
            @test_throws ArgumentError CT._site_ratios(oracle, bare, site, 0.3)
        end
        for gamma in (NaN, Inf)
            @test_throws ArgumentError CT._site_ratios(oracle, bare, 1, gamma)
        end
        for unsupported in (
            SJ.ED.sector_hamiltonian(zeros(2, 2), 4.0, 1, 0),
            SJ.ED.sector_hamiltonian(zeros(2, 2), 4.0, 1, 1; h=0.1),
            SJ.ED.sector_hamiltonian(zeros(10, 10), 4.0, 0, 0),
            SJ.ED.sector_hamiltonian(zeros(10, 10), 4.0, 3, 3),
        )
            @test_throws ArgumentError CT.exact_trial_oracle(unsupported, ones(length(unsupported.basis));
                Lx=div(unsupported.basis.nmodes, 2), Ly=1,
                kinetic_half=Matrix{Float64}(I, unsupported.basis.nmodes, unsupported.basis.nmodes))
        end
        _, state = initialize_case(zeros(2, 2), 4.0, 1, 1, bare, initializer)
        @test_throws ErrorException CT.measure_correlated_afqmc(state)
        for fields in ([Int8[1]], [Int8[1, 0]], [Int8[2, -1]])
            state.base.walkers[1].fields = fields
            @test_throws ArgumentError CT.backpropagated_trial(state, state.base.walkers[1])
        end
    end
end

end # module
