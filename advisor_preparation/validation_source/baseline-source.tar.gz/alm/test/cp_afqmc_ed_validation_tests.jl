module CPAFQMCEDValidationTests

using AltermagnetDQMCTrial
using Test

include(joinpath(@__DIR__, "..", "scripts", "hubbard_ed_benchmarks.jl"))
include(joinpath(@__DIR__, "..", "scripts", "two_orbital_open_cluster_ed.jl"))

using .HubbardEDBenchmarks
using .TwoOrbitalOpenClusterED

@testset "CP-AFQMC against repository exact solvers" begin
    @testset "Dimer energy and back-propagated double occupancy" begin
        U = 4.0
        exact_analytic = analytic_hubbard_dimer(U, 1.0)
        exact_numerical = numerical_hubbard_dimer(U, 1.0)
        problem = CPAFQMCProblem([0.0 -1.0; -1.0 0.0], U, 1, 1; cell_count=2)
        controls = CPAFQMCParameters(
            dtau=0.02,
            walker_count=240,
            warmup_steps=180,
            measurement_count=20,
            steps_between_measurements=4,
            orthogonalize_every=5,
            population_control_every=5,
            back_propagation_steps=60,
            error_block_size=5,
            seed=41,
        )
        result = run_cp_afqmc(problem, controls)

        @test isapprox(
            exact_numerical.ground_singlet_energy,
            exact_analytic.ground_singlet_energy;
            atol=5.0e-13,
            rtol=5.0e-13,
        )
        @test isapprox(
            result.summary.energy,
            exact_analytic.ground_singlet_energy;
            atol=0.08,
            rtol=0.0,
        )
        @test isapprox(
            result.summary.backpropagated_double_occupancy_per_cell,
            exact_analytic.ground_double_occupancy_per_site;
            atol=0.01,
            rtol=0.0,
        )
        @test abs(
            result.summary.mixed_double_occupancy_per_cell -
            exact_analytic.ground_double_occupancy_per_site
        ) > 0.04
    end

    @testset "Periodic two-orbital cluster ground energy" begin
        U = 2.0
        kinetic = realspace_kinetic_matrix(2)
        exact = ground_state_observables(
            kinetic,
            U,
            2,
            2;
            method=:lanczos,
            maxiter=140,
            atol=1.0e-11,
            rtol=1.0e-10,
        )
        problem = two_orbital_cp_afqmc_problem(2, U, 2, 2)
        controls = CPAFQMCParameters(
            dtau=0.02,
            walker_count=192,
            warmup_steps=400,
            measurement_count=20,
            steps_between_measurements=4,
            orthogonalize_every=5,
            population_control_every=5,
            back_propagation_steps=0,
            error_block_size=5,
            seed=7,
        )
        result = run_cp_afqmc(problem, controls)
        tolerance = max(5 * result.summary.energy_standard_error, 0.02)

        @test exact.converged
        @test exact.residual <= 3.0e-9
        @test abs(result.summary.energy - exact.energy) <= tolerance
        @test result.summary.density == 1.0
        @test result.diagnostics.overlap_inverse_failures == 0
    end

    @testset "Open cluster with interorbital hopping at U=0" begin
        kinetic = open_cluster_kinetic_matrix(2, 2)
        exact = ground_state_observables(kinetic, 0.0, 1, 1; method=:dense)
        problem = CPAFQMCProblem(
            kinetic,
            0.0,
            1,
            1;
            lattice_size=2,
            cell_count=4,
        )
        controls = CPAFQMCParameters(
            dtau=0.05,
            walker_count=2,
            warmup_steps=2,
            measurement_count=1,
            steps_between_measurements=1,
            orthogonalize_every=1,
            population_control_every=1,
            back_propagation_steps=2,
            minimum_backprop_ancestors=2,
            error_block_size=1,
            seed=5,
        )
        result = run_cp_afqmc(problem, controls)

        @test maximum(abs, kinetic[1:2:end, 2:2:end]) == 0.65
        @test isapprox(result.summary.energy, exact.energy; atol=3.0e-12, rtol=0.0)
        @test isapprox(
            result.summary.backpropagated_double_occupancy_per_cell,
            exact.double_occupancy / 4;
            atol=3.0e-12,
            rtol=0.0,
        )
        @test isapprox(
            result.summary.S_alm_q0,
            exact.oalm2 / 4;
            atol=3.0e-12,
            rtol=0.0,
        )
    end

    @testset "Interacting doped open two-orbital cluster" begin
        kinetic = open_cluster_kinetic_matrix(2, 2)
        exact = ground_state_observables(
            kinetic,
            2.0,
            3,
            3;
            method=:lanczos,
            maxiter=150,
            atol=1.0e-11,
            rtol=1.0e-10,
        )
        problem = CPAFQMCProblem(kinetic, 2.0, 3, 3; cell_count=4)
        controls = CPAFQMCParameters(
            dtau=0.02,
            walker_count=256,
            warmup_steps=300,
            measurement_count=20,
            steps_between_measurements=4,
            orthogonalize_every=5,
            population_control_every=5,
            back_propagation_steps=0,
            error_block_size=5,
            seed=71,
        )
        result = run_cp_afqmc(problem, controls)
        tolerance = max(5 * result.summary.energy_standard_error, 0.025)

        @test maximum(abs, kinetic[1:2:end, 2:2:end]) == 0.65
        @test exact.converged
        @test exact.residual <= 3.0e-9
        @test abs(result.summary.energy - exact.energy) <= tolerance
        @test result.summary.density == 1.5
        @test result.diagnostics.overlap_inverse_failures == 0
    end
end

end
