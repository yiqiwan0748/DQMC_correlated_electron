module EDStudyTests

using Test

include(joinpath(@__DIR__, "..", "scripts", "run_ed_study.jl"))
using .EDStudy

@testset "Integrated ED study runner" begin
    @test isnothing(parse_options(["--help"]))
    @test_throws ArgumentError parse_options(["--unknown=1"])
    @test_throws ArgumentError parse_options(["--U-min=-1"])
    @test_throws ArgumentError parse_options(["--U-min=0", "--U-max=1", "--U-step=0.3"])
    @test_throws ArgumentError parse_options(["--particles=3"])
    @test_throws ArgumentError parse_options(["--plots=maybe"])
    @test_throws ArgumentError parse_options(["--probe-field-ratio=1"])

    parsed = parse_options([
        "--mode=all",
        "--U-min=0",
        "--U-max=0",
        "--particles=2",
        "--omega-min=-8",
        "--omega-max=8",
        "--omega-points=31",
        "--band-points=4",
        "--dos-Nk=12",
        "--dos-bins=20",
        "--plots=false",
    ])
    @test parsed.mode == :all
    @test parsed.U_values == [0.0]
    @test parsed.particles == 2
    @test !parsed.plots

    mktempdir() do temporary
        destination = joinpath(temporary, "study")
        options = merge(parsed, (; output_dir=destination))
        result = run_study(options)

        @test result.output_dir == destination
        @test result.periodic_scan.first_audit_failure_U === nothing
        @test !result.periodic_scan.any_audit_failure
        @test all(row -> !row.spontaneous_breaking_assessable,
                  result.open_scan.rows)
        @test all(row -> row.spin_flip_energy_max_error < 1.0e-8,
                  result.open_scan.rows)
        @test all(row -> row.reduced_probe_field < row.probe_field,
                  result.open_scan.rows)
        @test occursin("cannot select", result.limitation)

        expected_files = [
            "benchmark_summary.csv",
            "hubbard_dimer_benchmark.csv",
            "square_hubbard_L4_dos_oracle.csv",
            "two_orbital_band_structure.csv",
            "two_orbital_noninteracting_dos.csv",
            "two_orbital_atom_poles.csv",
            "periodic_L2_spin_scan.csv",
            "periodic_L2_dos_U0p0.csv",
            "periodic_L2_spectral_U0p0.csv",
            "open_L2_canonical_scan.csv",
            "open_L2_spin_sectors.csv",
            "metadata.txt",
        ]
        @test all(name -> isfile(joinpath(destination, name)), expected_files)
        @test occursin(
            "periodic first numerical spin-audit failure U=nothing",
            read(joinpath(destination, "metadata.txt"), String),
        )

        # A study directory is immutable by design, preventing accidental loss
        # of an earlier scan while varying physics parameters.
        @test_throws ArgumentError run_study(options)
    end

    mktempdir() do temporary
        atomic_only_band = merge(parsed, (
            output_dir=joinpath(temporary, "invalid"),
            hopping=(t1=0.0, t2=0.0, t3=0.0, t4=0.0),
        ))
        @test_throws ArgumentError run_study(atomic_only_band)
        @test !ispath(atomic_only_band.output_dir)
    end

    # This point has a degenerate balanced-sector ground space. The runner must
    # not export solver-basis-dependent zero-field vector observables.
    mktempdir() do temporary
        degenerate = merge(parsed, (
            mode=:scan,
            output_dir=joinpath(temporary, "degenerate"),
            particles=4,
            open_proxy=true,
        ))
        run_study(degenerate)
        header = first(readlines(joinpath(
            degenerate.output_dir,
            "open_L2_canonical_scan.csv",
        )))
        columns = split(header, ',')
        @test "balanced_oalm_per_cell" ∉ columns
        @test "balanced_S_alm_q0" ∉ columns
        @test "balanced_m_alm_squared" ∉ columns
        @test "double_occupancy_per_cell" ∉ columns
        @test "finite_field_even_double_occupancy_per_cell" ∈ columns
        sector_header = first(readlines(joinpath(
            degenerate.output_dir,
            "open_L2_spin_sectors.csv",
        )))
        @test !occursin("oalm", sector_header)
        @test !occursin("double_occupancy", sector_header)
    end
end

end # module
