module ExtendedGroundStateEDTests

using Test

include(joinpath(@__DIR__, "..", "scripts", "run_extended_ground_state_ed.jl"))
const Runner = ExtendedGroundStateED

@testset "Extended ground-state ED integration" begin
    @test isnothing(Runner.parse_options(["--help"]))
    @test_throws ArgumentError Runner.parse_options(["--unknown=1"])
    @test_throws ArgumentError Runner.parse_options(["--particle-numbers=5,5"])
    @test_throws ArgumentError Runner.parse_options(["--U-step=0"])
    @test_throws ArgumentError Runner.parse_options(["--matsubara=0"])

    mktempdir() do temporary
        output = joinpath(temporary, "study")
        options = Runner.parse_options([
            "--output-dir=$output",
            "--particle-numbers=2",
            "--U-min=0", "--U-max=0", "--U-step=1",
            "--detail-particle-number=2", "--detail-U=0",
            "--twist-particle-numbers=2", "--twist-U=0",
            "--twist-maxiter=120", "--matsubara=0.5",
            "--manifolds=2", "--plots=false",
        ])
        result = Runner.run_extended_study(options)
        @test result.output_dir == output
        @test isdir(output)
        expected = [
            "periodic_ground_scan.csv",
            "ground_symmetry_manifolds.csv",
            "spin_multiplet_gaps.csv",
            "ground_correlation_summary.csv",
            "ground_correlation_lehmann_peaks.csv",
            "matsubara_green_self_energy.csv",
            "twist_single_particle_checks.csv",
            "twist_orbit_ground_summary.csv",
            "twist_orbit_ground_points.csv",
            "tilted_eight_site_momenta.csv",
            "tilted_eight_site_resources.csv",
            "tilted_eight_site_momentum_blocks.csv",
            "tilted_low_filling_lanczos_checks.csv",
            "tilted_target_gate.txt", "metadata.txt", "status.txt",
        ]
        @test all(name -> isfile(joinpath(output, name)), expected)
        status = read(joinpath(output, "status.txt"), String)
        @test occursin("WORKFLOW_COMPLETE", status)
        @test occursin("periodic_spin_audits=PASS", status)
        @test occursin("twist_sector_solves=CONVERGED", status)
        @test occursin("symmetry_projection_audits=PASS", status)
        @test occursin("correlation_lehmann_sum_rules=PASS", status)
        @test occursin("U0_self_energy=PASS", status)
        @test occursin("twist_symmetry_energy_audits=PASS", status)
        @test occursin("twist_ensemble_observables=EXACT", status)
        @test occursin("tilted_low_filling_lanczos_checks=PASS", status)
        @test occursin("tilted_target_N12=NOT_RUN_RESOURCE_GATE", status)
        @test only(result.periodic_rows).spin_audit_passed
        @test only(result.twist_rows).ground_observables_exact
        @test only(result.tilted_resources).fixed_Nup_Ndown_dimension ==
              big(64_128_064)
        @test maximum(row.maximum_spin_audit_error for row in result.periodic_rows) <
              2.0e-10
        @test_throws ArgumentError Runner.run_extended_study(options)
    end
end

end # module ExtendedGroundStateEDTests
