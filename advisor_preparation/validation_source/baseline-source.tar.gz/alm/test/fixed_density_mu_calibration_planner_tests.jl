using Test

const PLANNER_SOURCE = joinpath(
    @__DIR__,
    "..",
    "src",
    "fixed_density_mu_calibration_planner.jl",
)
const PLANNER_SCRIPT = joinpath(
    @__DIR__,
    "..",
    "scripts",
    "plan_fixed_density_mu_calibration.jl",
)

include(PLANNER_SOURCE)
using .FixedDensityMuCalibrationPlanner

module PlannerScriptUnderTest
include(joinpath(
    @__DIR__,
    "..",
    "scripts",
    "plan_fixed_density_mu_calibration.jl",
))
end

const BASE_PROVENANCE = (
    phase=:mu_calibration,
    L=4,
    beta=4.0,
    dtau=0.1,
    Ltau=40,
    U=2.0,
    matrix_dimension=32,
    stabilization_period=5,
    burnin_sweeps=200,
    measurement_sweeps=800,
    sweeps_between_measurements=2,
    measurement_count=800,
    requested_block_size=100,
    block_count=8,
    minimum_block_length=100,
    maximum_block_length=100,
    attempted_updates=2_304_000,
    configured_average_sign_threshold=0.2,
    maximum_average_sign_standard_error=0.02,
    minimum_block_count=8,
    maximum_block_drift_zscore=2.0,
    minimum_sign_signal_to_noise=5.0,
    minimum_absolute_average_sign=1.0e-8,
    maximum_greens_recompute_error=1.0e-8,
    u0_filling_tolerance=1.0e-10,
    require_single=true,
    strict_pilot=true,
    output_schema="target_filling,phase,case,L,beta,dtau,Ltau,U,mu",
)

function make_provenance(; kwargs...)
    values = merge(BASE_PROVENANCE, (; kwargs...))
    return CalibrationProvenance(; values...)
end

const BASE_RECORD = (
    case_name="calibrate_target_mu_m2p55",
    seed=6116,
    mu=-2.55,
    target_density=1.46021875,
    density=1.4393897420342978,
    standard_error=0.0013312914577584202,
    strict_pilot_status=:PASS,
    strict_pilot_passed=true,
    filling_jackknife_valid=true,
    source_consistent=true,
    provenance=make_provenance(),
    output_directory=joinpath(
        "results",
        "dqmc_sign_feasibility",
        "calibrate_target_mu_m2p55_seed6116_strict_pilot",
    ),
)

function make_record(; kwargs...)
    values = merge(BASE_RECORD, (; kwargs...))
    return CalibrationRecord(; values...)
end

function replace_fields(value; kwargs...)
    names = fieldnames(typeof(value))
    original = NamedTuple{names}(Tuple(getfield(value, name) for name in names))
    replacement = merge(original, (; kwargs...))
    return typeof(value)(; replacement...)
end

function current_records()
    below = make_record()
    above = make_record(
        case_name="calibrate_target_mu_m2p497",
        seed=6111,
        mu=-2.497,
        density=1.4764400882679722,
        standard_error=0.0010445205002070845,
        output_directory=joinpath(
            "results",
            "dqmc_sign_feasibility",
            "calibrate_target_mu_m2p497_seed6111_strict_pilot",
        ),
    )
    return (below=below, above=above)
end

function snapshot_tree(root)
    snapshot = Dict{String,Vector{UInt8}}()
    for (directory, _, files) in walkdir(root)
        for filename in sort(files)
            path = joinpath(directory, filename)
            snapshot[relpath(path, root)] = read(path)
        end
    end
    return snapshot
end

@testset "Fixed-density mu-calibration planner" begin
    @testset "Classification and equality boundaries" begin
        @test classify_density(0.5, 0.125, 1.0) == BELOW_TARGET
        @test classify_density(1.5, 0.125, 1.0) == ABOVE_TARGET
        @test classify_density(1.0, 0.125, 1.0) == TARGET_COMPATIBLE
        @test classify_density(0.75, 0.125, 1.0) == TARGET_COMPATIBLE
        @test classify_density(1.25, 0.125, 1.0) == TARGET_COMPATIBLE
        @test classify_density(0.5, 0.0, 1.0) == BELOW_TARGET
        @test_throws ArgumentError classify_density(NaN, 0.1, 1.0)
        @test_throws ArgumentError classify_density(1.0, Inf, 1.0)
        @test_throws ArgumentError classify_density(1.0, -0.1, 1.0)
    end

    @testset "Record gates and valid jackknife" begin
        records = current_records()
        @test validate_calibration_record(records.below, 1.46021875) ===
              records.below
        zero_se = make_record(density=1.4, standard_error=0.0)
        @test validate_calibration_record(zero_se, 1.46021875) === zero_se

        invalid_records = (
            make_record(strict_pilot_status=:FAIL),
            make_record(strict_pilot_passed=false),
            make_record(filling_jackknife_valid=false),
            make_record(source_consistent=false),
            make_record(density=NaN),
            make_record(density=Inf),
            make_record(standard_error=NaN),
            make_record(standard_error=Inf),
            make_record(standard_error=-0.001),
            make_record(target_density=nextfloat(1.46021875)),
            make_record(seed=0),
        )
        for record in invalid_records
            @test_throws ArgumentError validate_calibration_record(
                record,
                1.46021875,
            )
        end
    end

    @testset "Bracket normalization and rejection" begin
        records = current_records()
        bracket = validated_bracket(
            [records.above, records.below],
            1.46021875,
        )
        @test bracket.below === records.below
        @test bracket.above === records.above

        another_below = replace_fields(
            records.above;
            density=records.below.density,
            standard_error=records.below.standard_error,
        )
        @test_throws ArgumentError validated_bracket(
            [records.below, another_below],
            1.46021875,
        )
        equal_mu_above = replace_fields(records.above; mu=records.below.mu)
        @test_throws ArgumentError validated_bracket(
            [records.below, equal_mu_above],
            1.46021875,
        )
        reversed_below = replace_fields(records.below; mu=-2.49)
        reversed_above = replace_fields(records.above; mu=-2.50)
        @test_throws ArgumentError validated_bracket(
            [reversed_below, reversed_above],
            1.46021875,
        )
        compatible = replace_fields(
            records.below;
            density=1.46021875,
            standard_error=0.001,
        )
        @test_throws ArgumentError validated_bracket(
            [compatible, records.above],
            1.46021875,
        )
    end

    @testset "Every provenance field matches exactly" begin
        records = current_records()
        for name in fieldnames(CalibrationProvenance)
            original = getfield(records.above.provenance, name)
            replacement = if original isa Symbol
                :different_phase
            elseif original isa Bool
                !original
            elseif original isa Int
                original + 1
            elseif original isa Float64
                nextfloat(original)
            elseif original isa String
                original * ",different"
            else
                error("unhandled provenance field type")
            end
            changed_provenance = replace_fields(
                records.above.provenance;
                NamedTuple{(name,)}((replacement,))...,
            )
            changed_record = replace_fields(
                records.above;
                provenance=changed_provenance,
            )
            @test_throws ArgumentError plan_calibration(
                [records.below, changed_record];
                target_density=1.46021875,
            )
        end
    end

    @testset "Exact bisection candidate and configuration" begin
        records = current_records()
        plan = plan_calibration(
            [records.below, records.above];
            target_density=1.46021875,
        )
        @test plan.status == :PROPOSE_CANDIDATE
        @test !plan.successful_calibration
        @test plan.completed_new_evaluations == 0
        @test plan.maximum_new_evaluations == 6
        @test plan.mu_next == -2.5235
        @test candidate_case_name(something(plan.mu_next)) ==
              "calibrate_target_mu_m2p5235"

        proposal = build_candidate_proposal(
            plan;
            configured_seeds=[6002, 6111, 6112, 6113, 6114, 6115, 6116,
                              6211, 6212, 6231, 6232],
            record_seeds=[6111, 6116, 6211],
            path_exists=Returns(false),
        )
        @test proposal.case_name == "calibrate_target_mu_m2p5235"
        @test proposal.seed == 6117
        @test proposal.output_directory == joinpath(
            "results",
            "dqmc_sign_feasibility",
            "calibrate_target_mu_m2p5235_seed6117_strict_pilot",
        )
        @test proposal.dry_run_command ==
              "julia --project=. scripts/run_dqmc_sign_feasibility.jl " *
              "--phase=mu-calibration --case=calibrate_target_mu_m2p5235 " *
              "--seed=6117 --require-single --strict-pilot"
        @test !occursin("--run", proposal.dry_run_command)
    end

    @testset "Seed collisions are skipped globally" begin
        case_name = "calibrate_target_mu_m2p5235"
        output_root = joinpath("results", "dqmc_sign_feasibility")
        configured_collision = next_unused_seed(
            [6117, 6232],
            Int[],
            case_name,
            output_root;
            path_exists=Returns(false),
        )
        @test configured_collision.seed == 6118

        record_collision = next_unused_seed(
            Int[],
            [6117],
            case_name,
            output_root;
            path_exists=Returns(false),
        )
        @test record_collision.seed == 6118

        path_collision = next_unused_seed(
            Int[],
            Int[],
            case_name,
            output_root;
            path_exists=path -> occursin("seed6117_", path),
        )
        @test path_collision.seed == 6118

        consecutive = next_unused_seed(
            [6117, 6118],
            [6119],
            case_name,
            output_root;
            path_exists=path -> occursin("seed6120_", path),
        )
        @test consecutive.seed == 6121
        @test_throws ArgumentError next_unused_seed(
            Int[],
            Int[],
            case_name,
            output_root;
            first_candidate=0,
        )
    end

    @testset "Stopping policy" begin
        records = current_records()
        compatible = replace_fields(
            records.below;
            seed=6117,
            case_name="calibrate_target_mu_compatible",
            density=1.46021875,
            standard_error=0.001,
        )
        compatible_plan = plan_calibration(
            [records.below, records.above, compatible];
            target_density=1.46021875,
            completed_new_evaluations=6,
            bracket_width_tolerance=1.0,
        )
        @test compatible_plan.status == :TARGET_COMPATIBLE
        @test compatible_plan.successful_calibration
        @test compatible_plan.compatible === compatible
        @test isnothing(compatible_plan.mu_next)

        capped = plan_calibration(
            [records.below, records.above];
            target_density=1.46021875,
            completed_new_evaluations=6,
        )
        @test capped.status == :EVALUATION_CAP_REACHED
        @test !capped.successful_calibration
        @test isnothing(capped.mu_next)

        width_below = replace_fields(records.below; mu=0.0)
        width_above = replace_fields(records.above; mu=0.001)
        width_stop = plan_calibration(
            [width_below, width_above];
            target_density=1.46021875,
            bracket_width_tolerance=0.001,
        )
        @test width_stop.status == :BRACKET_WIDTH_TOLERANCE_REACHED
        @test !width_stop.successful_calibration
        @test isnothing(width_stop.mu_next)

        width_continue = plan_calibration(
            [width_below, replace_fields(width_above; mu=nextfloat(0.001))];
            target_density=1.46021875,
            bracket_width_tolerance=0.001,
        )
        @test width_continue.status == :PROPOSE_CANDIDATE
        @test !width_continue.successful_calibration
        @test !isnothing(width_continue.mu_next)
    end

    @testset "Real planner invocation is DQMC-free and write-free" begin
        repository_root = normpath(joinpath(@__DIR__, ".."))
        result_root = joinpath(repository_root, "results", "dqmc_sign_feasibility")
        candidate_path = joinpath(
            result_root,
            "calibrate_target_mu_m2p5235_seed6117_strict_pilot",
        )
        @test !ispath(candidate_path)
        before = snapshot_tree(result_root)

        io = IOBuffer()
        result = PlannerScriptUnderTest.main(; io=io)
        output = String(take!(io))
        after = snapshot_tree(result_root)

        @test before == after
        @test !ispath(candidate_path)
        @test result.configured_case_count >= 11
        @test result.available_result_count == 3
        @test result.plan.status == :PROPOSE_CANDIDATE
        @test something(result.plan.mu_next) == -2.5235
        proposed_seed = something(result.proposal).seed
        @test proposed_seed >= 6117
        @test !ispath(joinpath(
            repository_root,
            something(result.proposal).output_directory,
        ))
        @test occursin("proposed_candidate_count=1", output)
        @test occursin("mu_next=-2.5235", output)
        @test occursin("proposed_seed=$(proposed_seed)", output)
        @test occursin("dqmc_states_constructed=0", output)
        @test occursin("chain_runner_calls=0", output)
        @test occursin("outputs_written=false", output)
        @test !occursin(" --run", output)

        implementation = read(PLANNER_SOURCE, String)
        wrapper = read(PLANNER_SCRIPT, String)
        combined = implementation * wrapper
        @test !occursin("DQMCState", combined)
        @test !occursin("initialize_dqmc_state", combined)
        @test !occursin("run_selected_chains", combined)
        @test !occursin("open(", implementation)
        @test !occursin("mkpath", implementation)
        @test !occursin("write(", implementation)
    end
end
