module HubbardEDBenchmarkTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "hubbard_ed_benchmarks.jl"))
using .HubbardEDBenchmarks

# A 16-by-16 symmetric eigensolve accumulates a few dozen Float64 operations.
# These tolerances cover LAPACK roundoff while remaining eleven orders of
# magnitude below the order-one hopping scale used by the benchmark.
const ED_BENCHMARK_ATOL = 5.0e-13
const ED_BENCHMARK_RTOL = 5.0e-13

@testset "One-bond centered Hubbard-dimer benchmark" begin
    @testset "Full 16-level spectrum" begin
        for (U, t) in ((0.0, 1.0), (2.0, 1.0), (7.5, -1.25), (20.0, 1.0))
            numerical = numerical_hubbard_dimer(U, t)
            analytic = analytic_hubbard_dimer(U, t)
            benchmark = benchmark_hubbard_dimer(
                U,
                t;
                atol=ED_BENCHMARK_ATOL,
                rtol=ED_BENCHMARK_RTOL,
            )

            @test size(numerical.hamiltonian) == (16, 16)
            @test issymmetric(numerical.hamiltonian)
            @test length(numerical.spectrum) == 16
            @test length(analytic.spectrum) == 16
            @test sum(level.multiplicity for level in analytic.sector_levels) == 16
            @test isapprox(
                numerical.spectrum,
                analytic.spectrum;
                atol=ED_BENCHMARK_ATOL,
                rtol=ED_BENCHMARK_RTOL,
            )
            @test isapprox(
                numerical.ground_particle_number,
                2.0;
                atol=ED_BENCHMARK_ATOL,
                rtol=0.0,
            )
            @test all(values(benchmark.matches))
            @test benchmark.passed
            @test maximum(values(benchmark.errors)) < 20ED_BENCHMARK_ATOL
        end

        noninteracting = analytic_hubbard_dimer(0.0, 1.0)
        expected = vcat(
            fill(-2.0, 1),
            fill(-1.0, 4),
            fill(0.0, 6),
            fill(1.0, 4),
            fill(2.0, 1),
        )
        @test noninteracting.spectrum == expected

        # Reversing a single-bond hopping is a gauge transformation, so every
        # many-body eigenvalue and scalar ground-state observable is unchanged.
        positive_t = numerical_hubbard_dimer(4.0, 1.3)
        negative_t = numerical_hubbard_dimer(4.0, -1.3)
        @test isapprox(
            positive_t.spectrum,
            negative_t.spectrum;
            atol=ED_BENCHMARK_ATOL,
            rtol=ED_BENCHMARK_RTOL,
        )
        @test isapprox(
            positive_t.ground_double_occupancy_total,
            negative_t.ground_double_occupancy_total;
            atol=ED_BENCHMARK_ATOL,
            rtol=ED_BENCHMARK_RTOL,
        )
    end

    @testset "Ground singlet, spin gap, and double occupancy" begin
        U, t = 4.0, 1.0
        discriminant = sqrt(U^2 + 16t^2)
        expected_ground = -discriminant / 2
        expected_gap = (discriminant - U) / 2
        expected_double_total = (1 - U / discriminant) / 2
        numerical = numerical_hubbard_dimer(U, t)
        analytic = analytic_hubbard_dimer(U, t)

        for result in (numerical, analytic)
            @test isapprox(
                result.ground_singlet_energy,
                expected_ground;
                atol=ED_BENCHMARK_ATOL,
                rtol=ED_BENCHMARK_RTOL,
            )
            @test isapprox(
                result.triplet_energy,
                -U / 2;
                atol=ED_BENCHMARK_ATOL,
                rtol=ED_BENCHMARK_RTOL,
            )
            @test isapprox(
                result.singlet_triplet_gap,
                expected_gap;
                atol=ED_BENCHMARK_ATOL,
                rtol=ED_BENCHMARK_RTOL,
            )
            @test isapprox(
                result.ground_double_occupancy_total,
                expected_double_total;
                atol=ED_BENCHMARK_ATOL,
                rtol=ED_BENCHMARK_RTOL,
            )
            @test isapprox(
                result.ground_double_occupancy_per_site,
                expected_double_total / 2;
                atol=ED_BENCHMARK_ATOL,
                rtol=ED_BENCHMARK_RTOL,
            )
        end

        # At U=20 the exact spin scale is already close to 4t^2/U, but the
        # benchmark retains the exact finite-U result rather than substituting
        # the strong-coupling asymptote.
        strong = analytic_hubbard_dimer(20.0, 1.0)
        @test strong.singlet_triplet_gap > 0
        @test isapprox(strong.singlet_triplet_gap, 4 / 20; atol=0.002, rtol=0.0)
        @test 0 < strong.ground_double_occupancy_per_site < 0.01
    end

    @testset "Dimer input validation" begin
        @test_throws ArgumentError hubbard_dimer_hamiltonian(-1.0, 1.0)
        @test_throws ArgumentError hubbard_dimer_hamiltonian(1.0, 0.0)
        @test_throws ArgumentError hubbard_dimer_hamiltonian(Inf, 1.0)
        @test_throws ArgumentError analytic_hubbard_dimer(1.0, NaN)
        @test_throws ArgumentError numerical_hubbard_dimer(true, 1.0)
        @test_throws ArgumentError benchmark_hubbard_dimer(1.0, 1.0; atol=-1.0)
        @test_throws ArgumentError benchmark_hubbard_dimer(1.0, 1.0; rtol=Inf)
    end
end

@testset "L=4 nearest-neighbor square DOS oracle" begin
    oracle = square_l4_dos_oracle()
    @test oracle.L == 4
    @test oracle.number_of_sites == 16
    @test oracle.momenta == [0.0, pi / 2, pi, 3pi / 2]
    @test oracle.poles == [-4.0, -2.0, 0.0, 2.0, 4.0]
    @test oracle.multiplicities == [1, 4, 6, 4, 1]
    @test sum(oracle.multiplicities) == 16
    @test sum(oracle.spin_summed_multiplicities) == 32
    @test sum(oracle.weights) == 1.0
    @test sum(oracle.spin_summed_weights) == 2.0

    # Independently enumerate all 16 momenta and compare against the oracle's
    # expanded pole list. 2e-15 covers cos(pi/2) roundoff and nothing physical.
    enumerated = sort([
        -2 * (cos(kx) + cos(ky))
        for kx in oracle.momenta for ky in oracle.momenta
    ])
    expanded = sort([
        pole for (pole, multiplicity) in zip(oracle.poles, oracle.multiplicities)
        for _ in 1:multiplicity
    ])
    @test isapprox(enumerated, expanded; atol=2.0e-15, rtol=0.0)

    shifted = square_l4_dos_oracle(2.0; mu=0.5)
    @test shifted.poles == [-8.5, -4.5, -0.5, 3.5, 7.5]
    @test_throws ArgumentError square_l4_dos_oracle(0.0)
    @test_throws ArgumentError square_l4_dos_oracle(1.0; mu=NaN)

    @testset "Normalized Lorentzian broadening" begin
        omega = collect(range(-7.0, 7.0; length=281))
        eta = 0.2
        broadened = lorentzian_broaden(oracle, omega; eta=eta)
        spin_summed = lorentzian_broaden(
            oracle,
            omega;
            eta=eta,
            spin_summed=true,
        )
        independently_broadened = [
            sum(
                weight * eta / (pi * ((frequency - pole)^2 + eta^2))
                for (pole, weight) in zip(oracle.poles, oracle.weights)
            )
            for frequency in omega
        ]
        @test broadened.omega == omega
        @test broadened.eta == eta
        @test broadened.total_weight == 1.0
        @test all(>(0), broadened.density)
        @test isapprox(
            broadened.density,
            independently_broadened;
            atol=2.0e-15,
            rtol=2.0e-15,
        )
        @test isapprox(
            reverse(broadened.density),
            broadened.density;
            atol=2.0e-15,
            rtol=2.0e-15,
        )
        @test spin_summed.total_weight == 2.0
        @test spin_summed.density == 2 .* broadened.density

        @test_throws ArgumentError lorentzian_broaden([], [0.0], [1.0])
        @test_throws ArgumentError lorentzian_broaden([0.0], [], Float64[])
        @test_throws ArgumentError lorentzian_broaden([0.0], [0.0], [1.0, 2.0])
        @test_throws ArgumentError lorentzian_broaden([0.0], [0.0], [-1.0])
        @test_throws ArgumentError lorentzian_broaden([0.0], [0.0], [0.0])
        @test_throws ArgumentError lorentzian_broaden([NaN], [0.0], [1.0])
        @test_throws ArgumentError lorentzian_broaden([0.0], [0.0], [1.0]; eta=0.0)
    end
end

end # module
