module PeriodicL2EDRequestTests

using Test

include(joinpath(@__DIR__, "..", "scripts", "run_periodic_l2_ed_request.jl"))
using .PeriodicL2EDRequest

@testset "Periodic L2 ED request CLI and helpers" begin
    @test isnothing(parse_options(["--help"]))
    defaults = parse_options(String[])
    @test defaults.ensemble == :fixed_mu
    @test defaults.U_values == collect(0.0:1.0:20.0)
    @test defaults.spectral_U == [2.0, 3.0, 4.0]
    @test defaults.full_spectrum_U == [2.0, 3.0, 4.0]
    @test defaults.probe_h == 0.001
    @test defaults.hopping == (t1=-1.0, t2=-1.75, t3=-0.85, t4=-0.65)

    fixed_density = parse_options([
        "--ensemble=fixed-density",
        "--target-density=1.75",
        "--mu-min=-12",
        "--mu-max=9",
        "--spectral-U=2,4",
        "--full-spectrum-U=none",
        "--probe-h=0",
    ])
    @test fixed_density.ensemble == :fixed_density
    @test fixed_density.target_density == 1.75
    @test fixed_density.mu_bounds == (-12.0, 9.0)
    @test fixed_density.spectral_U == [2.0, 4.0]
    @test isempty(fixed_density.full_spectrum_U)
    @test fixed_density.probe_h == 0.0

    @test momentum_label(1, 1) == "Gamma"
    @test momentum_label(2, 1) == "X"
    @test momentum_label(1, 2) == "Y"
    @test momentum_label(2, 2) == "M"
    @test_throws ArgumentError momentum_label(3, 1)

    @test_throws ArgumentError parse_options(["--unknown=1"])
    @test_throws ArgumentError parse_options(["--ensemble=canonical"])
    @test_throws ArgumentError parse_options(["--U-min=-1"])
    @test_throws ArgumentError parse_options([
        "--U-min=0", "--U-max=1", "--U-step=0.3",
    ])
    @test_throws ArgumentError parse_options(["--spectral-U=2,2"])
    @test_throws ArgumentError parse_options(["--spectral-U=2.5"])
    @test_throws ArgumentError parse_options(["--full-spectrum-U=21"])
    @test_throws ArgumentError parse_options(["--probe-h=-0.1"])
    @test_throws ArgumentError parse_options(["--target-density=4"])
    @test_throws ArgumentError parse_options(["--mu-min=1", "--mu-max=1"])
    @test_throws ArgumentError parse_options(["--omega-points=2"])
    @test_throws ArgumentError parse_options([
        "--t1=0", "--t2=0", "--t3=0", "--t4=0",
    ])

    # A one-point fixed-density smoke run exercises the public tuner, h=0 and
    # +/-h roles, spectral exports, and all plot products without paying for the
    # production U=0:20 scan.
    mktempdir() do temporary
        options = parse_options([
            "--output-dir=$(joinpath(temporary, "request"))",
            "--ensemble=fixed-density",
            "--target-density=1.5",
            "--U-min=0",
            "--U-max=0",
            "--U-step=1",
            "--spectral-U=0",
            "--full-spectrum-U=none",
            "--probe-h=0.001",
            "--beta=1",
            "--omega-min=-10",
            "--omega-max=10",
            "--omega-points=5",
        ])
        result = run_request(options)
        @test length(result.zero_field_audit) == 1
        @test length(result.explicit_field_response) == 1
        @test length(result.field_points) == 3
        @test Set(getproperty.(result.field_points, :field_role)) == Set([
            "zero_field_symmetry_audit",
            "explicit_field_plus",
            "explicit_field_minus",
        ])
        @test abs(only(result.zero_field_audit).density_residual) <=
              options.density_tolerance
        @test !only(result.zero_field_audit).numerical_spin_symmetry_audit_failed
        @test only(result.zero_field_audit).many_body_K_Sz_pair_length_mismatch == 0
        @test only(result.zero_field_audit).many_body_K_Sz_pair_energy_max_difference <=
              options.audit_tolerance
        @test only(result.zero_field_audit).many_body_K_Sz_sectors_checked > 0
        @test !only(result.zero_field_audit).spontaneous_breaking_assessable
        @test only(result.zero_field_audit).t4_cancellation_max_abs == 0.0
        response = only(result.explicit_field_response)
        @test response.central_susceptibility_per_cell > 0
        @test !response.spontaneous_breaking_assessable
        @test response.field_reversal_delta_odd_error < 2.0e-10
        @test isfile(joinpath(options.output_dir, "periodic_L2_raw_spectral_poles.csv"))
        @test isfile(joinpath(options.output_dir, "periodic_L2_spin_orbital_Akw.csv"))
        @test isfile(joinpath(options.output_dir, "periodic_L2_spin_resolved_DOS.csv"))
        pole_lines = readlines(joinpath(
            options.output_dir,
            "periodic_L2_raw_spectral_poles.csv",
        ))
        @test Set(split(line, ',')[2] for line in pole_lines[2:end]) == Set([
            "zero_field_symmetry_audit",
            "explicit_field_plus",
            "explicit_field_minus",
        ])
        @test Set(result.plot_filenames) == Set([
            "periodic_L2_zero_field_spin_DOS.png",
            "periodic_L2_positive_field_XY_Akw.png",
            "periodic_L2_U_scan_audit_density.png",
        ])
        for filename in result.plot_filenames
            path = joinpath(options.output_dir, filename)
            @test isfile(path)
            @test filesize(path) > 0
        end
        metadata = read(joinpath(options.output_dir, "metadata.txt"), String)
        @test occursin("symmetry audit", metadata)
        @test occursin("neither determines a bulk Uc", metadata)
        @test occursin("temporary sibling plus atomic rename", metadata)
        @test isempty(filter(
            name -> startswith(name, ".request.tmp-"),
            readdir(temporary),
        ))
        @test_throws ArgumentError run_request(options)

        # The fixed-mu path exports exactly 65,536 labeled many-body levels at
        # a selected U. It still performs the same complete spin-pair audit.
        fixed_mu_options = parse_options([
            "--output-dir=$(joinpath(temporary, "fixed_mu"))",
            "--ensemble=fixed-mu",
            "--mu=-2.5157",
            "--U-min=0",
            "--U-max=0",
            "--U-step=1",
            "--spectral-U=0",
            "--full-spectrum-U=0",
            "--probe-h=0",
            "--beta=1",
            "--omega-min=-10",
            "--omega-max=10",
            "--omega-points=3",
            "--plots=false",
        ])
        fixed_mu_result = run_request(fixed_mu_options)
        @test length(fixed_mu_result.field_points) == 1
        @test isempty(fixed_mu_result.explicit_field_response)
        @test isempty(fixed_mu_result.plot_filenames)
        @test ismissing(only(fixed_mu_result.field_points).density_residual)
        @test !only(fixed_mu_result.zero_field_audit).numerical_spin_symmetry_audit_failed
        @test only(fixed_mu_result.full_spectrum_summary).number_of_levels == 65_536
        levels_path = joinpath(
            fixed_mu_options.output_dir,
            "periodic_L2_full_many_body_levels.csv",
        )
        @test countlines(levels_path) == 65_537
        @test isempty(filter(name -> endswith(name, ".png"), readdir(
            fixed_mu_options.output_dir,
        )))
        @test isempty(filter(
            name -> startswith(name, ".fixed_mu.tmp-"),
            readdir(temporary),
        ))

        # A failure after staging starts must leave neither a published partial
        # directory nor a temporary sibling behind.
        failed_destination = joinpath(temporary, "failed")
        failed_options = merge(fixed_mu_options, (
            output_dir=failed_destination,
            U_values=[-1.0],
            spectral_U=Float64[],
            full_spectrum_U=Float64[],
        ))
        @test_throws ArgumentError run_request(failed_options)
        @test !ispath(failed_destination)
        @test isempty(filter(
            name -> startswith(name, ".failed.tmp-"),
            readdir(temporary),
        ))
    end
end

end # module
