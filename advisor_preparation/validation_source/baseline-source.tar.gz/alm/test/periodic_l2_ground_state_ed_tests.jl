module PeriodicL2GroundStateEDTests

using Test

include(joinpath(
    @__DIR__,
    "..",
    "scripts",
    "run_periodic_l2_ground_state_ed.jl",
))
using .PeriodicL2GroundStateED

module MockGroundED

module ValidatedKinetic
Base.@kwdef struct ModelParameters
    t1::Float64 = -1.0
    t2::Float64 = -1.75
    t3::Float64 = -0.85
    t4::Float64 = -0.65
end
end

function _levels(U)
    rows = NamedTuple[]
    for (nup, ndown, kx, ky, offset) in (
        (4, 2, 2, 1, 0.0),
        (2, 4, 2, 1, 0.0),
        (3, 3, 1, 1, 1.0),
        (3, 3, 2, 1, 1.1),
        (3, 3, 1, 2, 1.1),
        (3, 3, 2, 2, 1.2),
    )
        push!(rows, (
            energy=U / 10 + offset,
            Nup=nup,
            Ndown=ndown,
            N=nup + ndown,
            Sz=(nup - ndown) / 2,
            kx_index=kx,
            ky_index=ky,
        ))
    end
    return rows
end

function _sector_rows(U)
    return [(
        N=level.N,
        Nup=level.Nup,
        Ndown=level.Ndown,
        Sz=level.Sz,
        kx_index=level.kx_index,
        ky_index=level.ky_index,
        energy=level.energy,
        degeneracy=1,
        dimension=1,
    ) for level in _levels(U)]
end

function _pattern(kx, ky)
    (kx, ky) == (2, 1) && return 1.0
    (kx, ky) == (1, 2) && return -1.0
    return 0.0
end

function solve_two_orbital_ground_state(
    U,
    N;
    parameters,
    h_alm,
    degeneracy_tolerance,
    mu_reference,
    include_full_spectrum,
)
    U >= 0 || throw(ArgumentError("mock U must be nonnegative"))
    N == 6 || throw(ArgumentError("mock implements N=6 only"))
    degeneracy_tolerance > 0 || error("invalid tolerance")
    mu_reference == :midgap || error("unsupported mock reference")
    peaks = Array{NamedTuple{(:frequencies, :weights),Tuple{Vector{Float64},Vector{Float64}}}}(
        undef,
        2,
        2,
        2,
        2,
    )
    for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
        sigma = spin == 1 ? 1.0 : -1.0
        frequency = 0.7 + U / 10 + orbital / 5 +
                    h_alm * sigma * _pattern(kx, ky)
        peaks[spin, orbital, kx, ky] = (
            frequencies=[frequency],
            weights=[1.0],
        )
    end
    return (
        L=2,
        U=Float64(U),
        N=N,
        h_alm=Float64(h_alm),
        mu_reference=0.5 + U / 20,
        hopping=(
            t1=parameters.t1,
            t2=parameters.t2,
            t3=parameters.t3,
            t4=parameters.t4,
        ),
        momenta=[0.0, Float64(pi)],
        kinetic=zeros(Float64, 8, 8),
        ground_energy=U / 10 - 2abs(h_alm),
        ground_degeneracy=iszero(h_alm) ? 2 : 1,
        ground_levels=[level for level in _levels(U) if level.energy == U / 10],
        sector_ground_energies=_sector_rows(U),
        excitation_gap=0.25,
        double_occupancy_per_cell=0.1,
        delta_alm_per_cell=iszero(h_alm) ? 0.0 :
            sign(h_alm) * (0.2 + abs(h_alm)),
        o_alm_squared_per_cell_squared=0.04,
        total_spin_z_per_cell=0.0,
        spectral_moment_max_error=0.0,
        spectral_peaks=peaks,
        full_many_body_levels=include_full_spectrum ? _levels(U) : nothing,
        limitation="mock periodic L2 limitation",
    )
end

function broaden_cluster_spectra(result, omega; eta=0.1)
    omega_values = Float64.(collect(omega))
    spectral = zeros(Float64, 2, 2, 2, 2, length(omega_values))
    for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
        channel = result.spectral_peaks[spin, orbital, kx, ky]
        for (frequency, weight) in zip(channel.frequencies, channel.weights)
            @. spectral[spin, orbital, kx, ky, :] +=
                weight * eta / (pi * ((omega_values - frequency)^2 + eta^2))
        end
    end
    spin_trace = dropdims(sum(spectral; dims=2); dims=2)
    dos = dropdims(sum(spin_trace; dims=(2, 3)); dims=(2, 3)) ./ 4
    return (
        omega=omega_values,
        eta=eta,
        spectral=spectral,
        spin_trace=spin_trace,
        dos=dos,
        total_dos=vec(sum(dos; dims=1)),
    )
end

function altermagnetic_xy_diagnostics(result, omega; eta=0.1)
    broadened = broaden_cluster_spectra(result, omega; eta=eta)
    x_up = vec(copy(broadened.spin_trace[1, 2, 1, :]))
    x_down = vec(copy(broadened.spin_trace[2, 2, 1, :]))
    y_up = vec(copy(broadened.spin_trace[1, 1, 2, :]))
    y_down = vec(copy(broadened.spin_trace[2, 1, 2, :]))
    delta_x = x_up - x_down
    delta_y = y_up - y_down
    return (
        x_same_momentum_spin_contrast_max=maximum(abs, delta_x; init=0.0),
        y_same_momentum_spin_contrast_max=maximum(abs, delta_y; init=0.0),
        xy_rotated_partner_max_error=max(
            maximum(abs, x_up - y_down; init=0.0),
            maximum(abs, x_down - y_up; init=0.0),
        ),
        xy_contrast_antisymmetry_max_error=maximum(
            abs,
            delta_x + delta_y;
            init=0.0,
        ),
        dos_spin_max_error=maximum(
            abs,
            broadened.dos[1, :] - broadened.dos[2, :];
            init=0.0,
        ),
        broadened=broadened,
    )
end

end # module MockGroundED

@testset "Periodic L2 canonical ground-state ED runner" begin
    @test isnothing(parse_options(["--help"]))
    defaults = parse_options(String[])
    @test defaults.particle_number == 6
    @test defaults.U_values == collect(0.0:1.0:20.0)
    @test defaults.spectral_U == [2.0, 3.0, 4.0]
    @test defaults.high_U == [8.0, 10.0, 12.0, 20.0]
    @test defaults.spectral_output_U == [2.0, 3.0, 4.0, 8.0, 10.0, 12.0, 20.0]
    @test isempty(defaults.full_spectrum_U)
    @test defaults.probe_h == 0.001
    @test defaults.reduced_field_ratio == 0.1

    @test momentum_label(1, 1) == "Gamma"
    @test momentum_label(2, 1) == "X"
    @test momentum_label(1, 2) == "Y"
    @test momentum_label(2, 2) == "M"
    @test_throws ArgumentError momentum_label(3, 1)

    @test_throws ArgumentError parse_options(["--particle-number=0"])
    @test_throws ArgumentError parse_options(["--particle-number=16"])
    @test_throws ArgumentError parse_options(["--particle-number=6.0"])
    @test_throws ArgumentError parse_options(["--U-min=-1"])
    @test_throws ArgumentError parse_options([
        "--U-min=0", "--U-max=1", "--U-step=0.3",
    ])
    @test_throws ArgumentError parse_options(["--spectral-U=2,2"])
    @test_throws ArgumentError parse_options(["--high-U=7.5"])
    @test_throws ArgumentError parse_options(["--full-spectrum-U=21"])
    @test_throws ArgumentError parse_options(["--probe-h=-0.1"])
    @test_throws ArgumentError parse_options(["--reduced-field-ratio=0"])
    @test_throws ArgumentError parse_options(["--reduced-field-ratio=1"])
    @test_throws ArgumentError parse_options(["--degeneracy-tolerance=0"])
    @test_throws ArgumentError parse_options(["--omega-points=2"])
    @test_throws ArgumentError parse_options(["--plots=maybe"])
    @test_throws ArgumentError parse_options(["--unknown=1"])

    mktempdir() do temporary
        options = parse_options([
            "--output-dir=$(joinpath(temporary, "ground"))",
            "--particle-number=6",
            "--U-min=0",
            "--U-max=0",
            "--U-step=1",
            "--spectral-U=0",
            "--high-U=none",
            "--full-spectrum-U=0",
            "--probe-h=0.01",
            "--reduced-field-ratio=0.1",
            "--omega-min=-2",
            "--omega-max=2",
            "--omega-points=5",
            "--plots=true",
        ])
        result = run_ground_state_request(options; ed_module=MockGroundED)
        @test length(result.zero_field_audit) == 1
        @test length(result.explicit_field_response) == 1
        @test length(result.field_points) == 5
        @test Set(getproperty.(result.field_points, :field_role)) == Set([
            "zero_field_ground_state",
            "explicit_source_plus_h",
            "explicit_source_minus_h",
            "explicit_source_plus_reduced_h",
            "explicit_source_minus_reduced_h",
        ])

        audit = only(result.zero_field_audit)
        @test audit.particle_number == 6
        @test audit.density_per_cell == 1.5
        @test audit.spin_flipped_sector_ground_energy_max_difference == 0.0
        @test audit.spin_flipped_sector_dimension_max_mismatch == 0
        @test audit.ground_manifold_spin_partner_count_max_mismatch == 0
        @test audit.spectral_pole_frequency_max_difference == 0.0
        @test audit.spectral_pole_weight_max_difference == 0.0
        @test audit.broadened_spin_dos_max_difference == 0.0
        @test !audit.numerical_spin_symmetry_audit_failed
        @test !audit.spontaneous_breaking_assessable
        @test audit.t4_cancellation_max_abs == 0.0

        response = only(result.explicit_field_response)
        @test response.symmetric_source_secant_at_h > 0
        @test response.symmetric_source_secant_at_reduced_h > 0
        @test response.field_reversal_delta_odd_error == 0.0
        @test response.reduced_field_reversal_delta_odd_error == 0.0
        @test response.field_reversal_ground_energy_even_error == 0.0
        @test response.field_reversal_spectral_frequency_max_error == 0.0
        @test response.field_reversal_spectral_weight_max_error == 0.0
        @test response.positive_h_XY_rotated_partner_max_error < 1.0e-12
        @test response.positive_h_XY_contrast_antisymmetry_max_error < 1.0e-12
        @test !response.spontaneous_breaking_assessable

        @test only(result.full_spectrum_summary).fixed_N_level_count == 6
        @test isfile(joinpath(
            options.output_dir,
            "periodic_L2_ground_state_raw_spectral_poles.csv",
        ))
        @test isfile(joinpath(
            options.output_dir,
            "periodic_L2_ground_state_spin_orbital_Akw.csv",
        ))
        @test isfile(joinpath(
            options.output_dir,
            "periodic_L2_ground_state_spin_resolved_DOS.csv",
        ))
        @test countlines(joinpath(
            options.output_dir,
            "periodic_L2_ground_state_full_many_body_levels.csv",
        )) == 7
        pole_lines = readlines(joinpath(
            options.output_dir,
            "periodic_L2_ground_state_raw_spectral_poles.csv",
        ))
        @test Set(split(line, ',')[3] for line in pole_lines[2:end]) == Set([
            "zero_field_ground_state",
            "explicit_source_plus_h",
            "explicit_source_minus_h",
            "explicit_source_plus_reduced_h",
            "explicit_source_minus_reduced_h",
        ])

        @test Set(result.plot_filenames) == Set([
            "periodic_L2_ground_state_zero_field_spin_DOS.png",
            "periodic_L2_ground_state_explicit_field_XY_Akw.png",
            "periodic_L2_ground_state_zero_field_U_scan.png",
            "periodic_L2_ground_state_explicit_source_U_scan.png",
        ])
        for filename in result.plot_filenames
            path = joinpath(options.output_dir, filename)
            @test isfile(path)
            @test filesize(path) > 0
        end
        metadata = read(joinpath(options.output_dir, "metadata.txt"), String)
        @test occursin("temperature=T=0", metadata)
        @test occursin("canonical", metadata)
        @test occursin("n=1.42 is unavailable", metadata)
        @test occursin("finite-source secants", metadata)
        @test occursin("not spontaneous order", metadata)
        @test occursin("atomic rename", metadata)
        @test isempty(filter(
            name -> startswith(name, ".ground.tmp-"),
            readdir(temporary),
        ))
        @test_throws ArgumentError run_ground_state_request(
            options;
            ed_module=MockGroundED,
        )

        # Probe-free execution remains a pure zero-field ground-state audit.
        no_probe = parse_options([
            "--output-dir=$(joinpath(temporary, "no_probe"))",
            "--U-min=0",
            "--U-max=0",
            "--spectral-U=0",
            "--high-U=none",
            "--probe-h=0",
            "--omega-min=-1",
            "--omega-max=1",
            "--omega-points=3",
            "--plots=false",
        ])
        no_probe_result = run_ground_state_request(
            no_probe;
            ed_module=MockGroundED,
        )
        @test length(no_probe_result.field_points) == 1
        @test isempty(no_probe_result.explicit_field_response)
        @test isempty(no_probe_result.plot_filenames)
        @test isempty(filter(
            name -> endswith(name, ".png"),
            readdir(no_probe.output_dir),
        ))

        # A solver failure after staging begins publishes no partial directory.
        failed_destination = joinpath(temporary, "failed")
        failed_options = merge(no_probe, (
            output_dir=failed_destination,
            U_values=[-1.0],
            spectral_U=Float64[],
            high_U=Float64[],
            spectral_output_U=Float64[],
            full_spectrum_U=Float64[],
        ))
        @test_throws ArgumentError run_ground_state_request(
            failed_options;
            ed_module=MockGroundED,
        )
        @test !ispath(failed_destination)
        @test isempty(filter(
            name -> startswith(name, ".failed.tmp-"),
            readdir(temporary),
        ))
    end
end

end # module
