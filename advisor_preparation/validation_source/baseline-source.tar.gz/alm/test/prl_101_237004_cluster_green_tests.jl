module PRL101237004ClusterGreenTests

using LinearAlgebra
using Test
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_cluster_green.jl"))
const C = PRL101237004ClusterGreen
const E = C.ED

# Tiny dense resolvents, orthogonal projections and short fermionic sums incur
# Float64 roundoff. 3e-10 resolves pole/sign/mu-shift errors while allowing a
# ground-state residual below 1e-12 amplified by our smallest eta=0.11.
const ATOL = 3e-10

function dense_spin_oracle(Kup,Kdown,U,Nup,Ndown;J=U/4)
    nmodes = size(Kup,1)
    interaction = E.sector_hamiltonian(zeros(nmodes,nmodes),U,Nup,Ndown;J)
    matrix = E.dense_hamiltonian(interaction)
    for (column,state) in enumerate(interaction.basis.states), (K,offset) in ((Kup,0),(Kdown,nmodes))
        for a in 1:nmodes,b in 1:nmodes
            iszero(K[a,b]) && continue
            transition = E.apply_fermion_ops(state,((offset+b,false),(offset+a,true)))
            transition===nothing && continue
            target,sign = transition
            matrix[interaction.basis.indices[target],column] += K[a,b]*sign
        end
    end
    return interaction.basis,matrix
end

function jordan_wigner_annihilator(total_modes,mode)
    identity = Matrix{Float64}(I,2,2)
    parity = [1.0 0;0 -1.0]
    annihilator = [0.0 1;0 0]
    result = ones(1,1)
    for position in total_modes:-1:1
        local_operator = position==mode ? annihilator : position<mode ? parity : identity
        result = kron(result,local_operator)
    end
    return result
end

function dense_green_oracle(Kup,Kdown,U,Nup,Ndown,z;J=U/4,mu_prime=0.0,spin=:up)
    basis,H = dense_spin_oracle(Kup,Kdown,U,Nup,Ndown;J)
    ground = eigen(Symmetric(H))
    energy,vector = ground.values[1],ground.vectors[:,1]
    nmodes = size(Kup,1)
    result,derivative = zeros(ComplexF64,nmodes,nmodes),zeros(ComplexF64,nmodes,nmodes)
    target_energies = Dict{Symbol,Float64}()
    for addition in (true,false)
        delta = addition ? 1 : -1
        sector = spin==:up ? (Nup+delta,Ndown) : (Nup,Ndown+delta)
        all(n->0<=n<=nmodes,sector) || continue
        target_basis,target_H = dense_spin_oracle(Kup,Kdown,U,sector...;J)
        target_energies[addition ? :addition : :removal] = eigmin(Symmetric(target_H))
        source = zeros(Float64,length(target_basis.states),nmodes)
        for orbital in 1:nmodes
            mode = (spin==:up ? 0 : nmodes)+orbital
            annihilation = jordan_wigner_annihilator(2nmodes,mode)
            operator = addition ? transpose(annihilation) : annihilation
            source[:,orbital] .= operator[Int.(target_basis.states).+1,Int.(basis.states).+1]*vector
        end
        denominator = addition ? (z+mu_prime+energy)*I-target_H : (z+mu_prime-energy)*I+target_H
        applied = denominator\source
        contribution = transpose(source)*applied
        derivative_contribution = -transpose(source)*(denominator\applied)
        result .+= addition ? contribution : transpose(contribution)
        derivative .+= addition ? derivative_contribution : transpose(derivative_contribution)
    end
    return (;matrix=result,derivative,energy,target_energies)
end

@testset "Spin-dependent cluster wrapper retains literal full interaction" begin
    Kup = [-0.3 0.12 -0.31 0.07;0.12 0.2 -0.02 -0.19;-0.31 -0.02 0.1 0.08;0.07 -0.19 0.08 0.4]
    Kdown = Kup+Diagonal([0.07,-0.04,-0.03,0.09])
    Kdown[1,3] += 0.025
    Kdown[3,1] += 0.025
    for populations in ((2,2),(1,2),(3,2),(0,1))
        H = C.spin_hamiltonian(Kup,Kdown,0.8,populations...;J=0.17)
        basis,expected = dense_spin_oracle(Kup,Kdown,0.8,populations...;J=0.17)
        @test H.basis.states==basis.states
        @test isapprox(Matrix(H),expected;atol=2e-12,rtol=0)
        vector = [sin(i) for i in axes(H,1)]
        @test isapprox(H*vector,expected*vector;atol=2e-12,rtol=0)
        aliased = copy(vector)
        mul!(aliased,H,aliased,0.7,0.2)
        @test isapprox(aliased,0.7expected*vector+0.2vector;atol=2e-12,rtol=0)
    end
end

@testset "Lehmann resolvents, mu derivatives and moments match dense oracles" begin
    for (Kup,Kdown,Nup,Ndown,U,J) in (
        ([-0.2 0.1;0.1 0.3],[-0.15 0.1;0.1 0.25],1,1,0.5,0.125),
        ([-0.3 0.12 -0.31 0.07;0.12 0.2 -0.02 -0.19;-0.31 -0.02 0.1 0.08;0.07 -0.19 0.08 0.4],
         [-0.23 0.12 -0.285 0.07;0.12 0.16 -0.02 -0.19;-0.285 -0.02 0.07 0.08;0.07 -0.19 0.08 0.49],2,2,0.8,0.17))
        result = C.build_cluster_green(Kup,Kdown,U,Nup,Ndown;J,block_steps=10,
            ground_atol=1e-12,ground_keep=2,ground_krylovdim=40,require_convergence=true)
        @test result.converged
        @test result.ground_residual<1e-12
        for spin in (:up,:down)
            for z in (-0.7+0.11im,0.2+0.31im,2.5+0.8im),mu_prime in (-0.1,0.3)
                oracle = dense_green_oracle(Kup,Kdown,U,Nup,Ndown,z;J,mu_prime,spin)
                green = C.cluster_green(result,z;mu_prime,spin)
                @test isapprox(result.E0,oracle.energy;atol=ATOL,rtol=0)
                @test isapprox(green,oracle.matrix;atol=ATOL,rtol=0)
                @test isapprox(C.green_mu_derivative(result,z;mu_prime,spin),oracle.derivative;atol=ATOL,rtol=0)
                @test eigmin(Hermitian(-imag.(green)))>=-ATOL
                @test isapprox(green,transpose(green);atol=ATOL,rtol=0)
            end
            moments = C.spectral_moments(result;spin)
            @test isapprox(moments.zeroth,I;atol=ATOL,rtol=0)
            shifted = C.spectral_moments(result;spin,mu_prime=0.37)
            @test isapprox(shifted.first,moments.first-0.37I;atol=ATOL,rtol=0)
            @test isapprox(shifted.second,moments.second-0.74moments.first+0.37^2*I;atol=ATOL,rtol=0)
            numerical_moments = C._moments(C.spectral_data(result;spin))
            @test all(isapprox(numerical_moments[i],(moments.zeroth,moments.first,moments.second)[i];atol=ATOL,rtol=0) for i in 1:3)
        end
        @test all(maximum(channel.moment_errors)<ATOL for channel in result.channels)
        @test C.omega_prime(result,0.37)==result.E0-0.37*(Nup+Ndown)
        bounds = C.particle_stability_interval(result)
        @test bounds.scope==:four_neighboring_spin_particle_sectors
        for spin in (:up,:down)
            oracle = dense_green_oracle(Kup,Kdown,U,Nup,Ndown,0.3im;J,spin)
            addition = getproperty(result.channels,spin==:up ? :up_addition : :down_addition)
            removal = getproperty(result.channels,spin==:up ? :up_removal : :down_removal)
            @test isapprox(addition.neighbor_energy,oracle.target_energies[:addition];atol=ATOL,rtol=0)
            @test isapprox(removal.neighbor_energy,oracle.target_energies[:removal];atol=ATOL,rtol=0)
        end
    end
end

@testset "Block depth has an explicit frequency-grid convergence diagnostic" begin
    K = [-0.3 0.12 -0.31 0.07;0.12 0.2 -0.02 -0.19;-0.31 -0.02 0.1 0.08;0.07 -0.19 0.08 0.4]
    shallow = C.build_cluster_green(K,K,0.8,2,2;J=0.17,block_steps=1,
        ground_atol=1e-12,ground_keep=2,ground_krylovdim=40)
    deep = C.build_cluster_green(K,K,0.8,2,2;J=0.17,block_steps=10,
        ground_atol=1e-12,ground_keep=2,ground_krylovdim=40,require_convergence=true)
    @test !shallow.converged
    @test deep.converged
    z = 0.35+0.15im
    oracle = dense_green_oracle(K,K,0.8,2,2,z;J=0.17)
    shallow_error = norm(C.cluster_green(shallow,z)-oracle.matrix)
    deep_error = norm(C.cluster_green(deep,z)-oracle.matrix)
    @test shallow_error>1e-5
    @test deep_error<ATOL
    @test all(channel.krylov_dimension<=channel.sector_dimension for channel in deep.channels)
    @test_throws ErrorException C.build_cluster_green(K,K,0.8,2,2;J=0.17,block_steps=1,
        ground_atol=1e-12,ground_keep=2,ground_krylovdim=40,require_convergence=true)
end

function four_site_open_kinetic()
    coordinates = [(0,0),(1,0),(0,1),(1,1)]
    K = zeros(8,8)
    for a in 1:4,b in (a+1):4
        dx,dy = coordinates[b].-coordinates[a]
        for orbital in 1:2
            value = abs(dx)+abs(dy)==1 ?
                (orbital==1 ? (dx==0 ? -0.11 : -0.17) : (dx==0 ? -0.16 : -0.09)) : -0.05
            i,j = 2a-2+orbital,2b-2+orbital
            K[i,j]=K[j,i]=value
        end
    end
    K += Diagonal([0.021,-0.017,0.007,-0.011,-0.013,0.019,0.003,-0.023])
    return K
end

@testset "Open four-Fe U=0 resolvent and particle sum rules" begin
    K = four_site_open_kinetic()
    Weiss = Diagonal([0.037,0.037,-0.037,-0.037,0.037,0.037,-0.037,-0.037])
    Kup,Kdown = K+Weiss,K-Weiss
    result = C.build_cluster_green(Kup,Kdown,0.0,4,4;block_steps=4,
        ground_atol=1e-12,require_convergence=true)
    @test result.ground_dimension==4900
    @test isapprox(result.E0,sum(eigvals(Symmetric(Kup))[1:4])+sum(eigvals(Symmetric(Kdown))[1:4]);atol=ATOL,rtol=0)
    for (spin,kinetic) in ((:up,Kup),(:down,Kdown)),z in (0.1im,0.31+0.2im,1.0+0.4im)
        @test isapprox(C.cluster_green(result,z;mu_prime=0.13,spin),inv((z+0.13)*I-kinetic);atol=ATOL,rtol=0)
        moments = C.spectral_moments(result;mu_prime=0.13,spin)
        @test isapprox(moments.first,kinetic-0.13I;atol=ATOL,rtol=0)
        @test isapprox(moments.second,(kinetic-0.13I)^2;atol=ATOL,rtol=0)
    end
    for channel in (result.channels.up_removal,result.channels.down_removal)
        @test isapprox(tr(channel.exact_moments[1]),4;atol=ATOL,rtol=0)
    end
end

@testset "Green input and particle-sector boundary checks" begin
    K = [-0.2 0.1;0.1 0.3]
    @test_throws DimensionMismatch C.spin_hamiltonian(K,zeros(4,4),0.5,1,1)
    @test_throws ArgumentError C.spin_hamiltonian([0.0 1;0 0],K,0.5,1,1)
    @test_throws ArgumentError C.build_cluster_green(K,K,0.5,1,1;block_steps=0)
    @test_throws ArgumentError C.build_cluster_green(K,K,0.5,1,1;probe_z=[0.1])
    @test_throws ArgumentError C.build_cluster_green(K,K,0.5,1,1;rank_atol=0)
    vacuum = C.build_cluster_green(K,K,0.0,0,0;block_steps=2,ground_keep=1,require_convergence=true)
    @test vacuum.channels.up_removal.sector_dimension==0
    @test C.particle_stability_interval(vacuum).lower==-Inf
    @test isapprox(C.cluster_green(vacuum,0.3im),inv(0.3im*I-K);atol=ATOL,rtol=0)
    @test_throws ArgumentError C.cluster_green(vacuum,0.3im;spin=:wrong)
    @test_throws ArgumentError C.cluster_green(vacuum,Inf*im)
end

end # module
