module PRL101237004EDTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_ed.jl"))
using .PRL101237004ED

# Matrices in this suite have dimension at most 36 and coefficients of order
# one. 1e-12 permits accumulated Float64 arithmetic/eigensolver roundoff while
# resolving the exchange and pair-transfer splittings, which are >= 0.1.
const ED_ATOL = 1.0e-12
const ED_RTOL = 1.0e-12

@testset "PRL full-interaction sector Hamiltonian" begin
    @testset "Fock ordering and operator signs" begin
        basis = sector_basis(4, 2, 1)
        @test length(basis.states) == 24
        @test issorted(basis.states)
        @test length(unique(basis.states)) == 24
        for (index, state) in enumerate(basis.states)
            @test basis.indices[state] == index
            @test count_ones(state & UInt64(0xf)) == 2
            @test count_ones(state >> 4) == 1
        end
        @test apply_fermion_ops(UInt64(0), ((1, false),)) === nothing
        @test apply_fermion_ops(UInt64(1), ((1, true),)) === nothing
        @test apply_fermion_ops(UInt64(2), ((2, false), (1, true))) == (UInt64(1), 1)
        @test apply_fermion_ops(UInt64(3), ((2, false),)) == (UInt64(1), -1)
        @test apply_fermion_ops(UInt64(1), ((64, true),)) == ((UInt64(1) << 63) | UInt64(1), -1)
        @test_throws ArgumentError apply_fermion_ops(UInt64(0), ((65, true),))
        @test_throws ArgumentError apply_fermion_ops(UInt64(0), ((1, 1),))
        full = sector_basis(32, 32, 32)
        @test full.states == [typemax(UInt64)]
        @test sector_basis(0, 0, 0).states == [UInt64(0)]
    end

    @testset "Atomic multiplets at every filling" begin
        for (U, J) in ((2.0, 0.0), (2.0, 0.3), (2.0, 0.5), (0.0, 0.0))
            reference = (
                [0.0], zeros(4),
                sort([U-3J, U-3J, U-3J, U-J, U-J, U+J]),
                fill(3U-5J, 4), [6U-10J],
            )
            for N in 0:4
                energies = Float64[]
                for Nup in max(0, N-2):min(2, N)
                    h = sector_hamiltonian(zeros(2, 2), U, Nup, N-Nup; J=J)
                    @test h.Uprime == U - 2J
                    dense = Matrix(h)
                    @test issymmetric(dense)
                    append!(energies, eigvals(Symmetric(dense)))
                end
                @test isapprox(sort(energies), reference[N+1]; atol=ED_ATOL, rtol=ED_RTOL)
            end
        end
        # In the global up-then-down Fock convention both off-diagonal entries
        # are +J: spin-state creation ordering supplies the extra exchange sign.
        h = sector_hamiltonian(zeros(2, 2), 2.0, 1, 1; J=0.3)
        index = h.basis.indices
        @test h[index[UInt64(0x9)], index[UInt64(0x6)]] == 0.3
        @test h[index[UInt64(0x5)], index[UInt64(0xa)]] == 0.3
        @test h[index[UInt64(0x9)], index[UInt64(0x9)]] == 1.4
        @test h[index[UInt64(0x5)], index[UInt64(0x5)]] == 2.0
    end

    @testset "Two-Fe free limit and full interaction" begin
        K = [0.2 -0.7 0.3 0.1; -0.7 -0.1 -0.4 0.2;
             0.3 -0.4 0.5 -0.6; 0.1 0.2 -0.6 -0.3]
        single = eigvals(Symmetric(K))
        h0 = sector_hamiltonian(K, 0.0, 1, 1)
        expected = sort([up + down for up in single for down in single])
        @test isapprox(eigvals(Symmetric(Matrix(h0))), expected; atol=ED_ATOL, rtol=ED_RTOL)
        # At J=0 Eq. (2) retains interorbital U, so all two-electron atomic
        # configurations have energy U rather than an intraorbital-only zero.
        atom = sector_hamiltonian(zeros(2, 2), 1.7, 1, 1; J=0)
        @test isapprox(Matrix(atom), 1.7I; atol=ED_ATOL, rtol=ED_RTOL)
        h = sector_hamiltonian(K, 1.6, 2, 2)
        dense = Matrix(h)
        @test size(h) == (36, 36)
        @test size(h, 3) == 1
        @test eltype(h) === Float64
        @test issymmetric(dense)
        @test isapprox([h[i, j] for i in axes(h, 1), j in axes(h, 2)], dense;
                       atol=ED_ATOL, rtol=ED_RTOL)
        for state in h.basis.states
            @test count_ones(state & UInt64(0xf)) == 2
            @test count_ones(state >> 4) == 2
        end
        v = sin.(collect(1:36))
        @test isapprox(h*v, dense*v; atol=ED_ATOL, rtol=ED_RTOL)
        output = cos.(collect(1:36))
        initial = copy(output)
        mul!(output, h, v, 1.2, -0.7)
        @test isapprox(output, 1.2dense*v - 0.7initial; atol=ED_ATOL, rtol=ED_RTOL)
        alias = copy(v)
        mul!(alias, h, alias)
        @test isapprox(alias, dense*v; atol=ED_ATOL, rtol=ED_RTOL)
        complex_v = complex.(v, reverse(v))
        @test isapprox(h*complex_v, dense*complex_v; atol=ED_ATOL, rtol=ED_RTOL)
        @test_throws DimensionMismatch h * zeros(35)
    end

    @testset "Arithmetic and allocation guards" begin
        h32 = sector_hamiltonian(zeros(Float32, 2, 2), Float32(2), 1, 1)
        @test eltype(h32) === Float32
        @test isapprox(sort(eigvals(Symmetric(Matrix(h32)))), Float32[0.5, 1.5, 1.5, 2.5];
                       atol=2f-6, rtol=2f-6) # A few Float32 ulps at atomic scale.
        setprecision(BigFloat, 256) do
            hbig = sector_hamiltonian(zeros(BigFloat, 2, 2), big"2", 1, 1)
            @test eltype(hbig) === BigFloat
            @test hbig * ones(BigFloat, 4) == Matrix(hbig) * ones(BigFloat, 4)
        end
        @test_throws ArgumentError sector_basis(33, 0, 0)
        @test_throws ArgumentError sector_basis(2, 3, 0)
        @test_throws ArgumentError sector_basis(32, 16, 16)
        @test_throws ArgumentError sector_basis(2, 1, 1; max_dimension=3)
        @test_throws ArgumentError sector_basis(2, 1, 1; max_bytes=1)
        @test_throws ArgumentError sector_hamiltonian(zeros(3, 3), 1, 1, 1)
        @test_throws ArgumentError sector_hamiltonian(zeros(2, 3), 1, 1, 1)
        @test_throws ArgumentError sector_hamiltonian([0.0 1; 0 0], 1, 1, 1)
        @test_throws ArgumentError sector_hamiltonian([NaN 0; 0 0], 1, 1, 1)
        @test_throws ArgumentError sector_hamiltonian(zeros(2, 2), Inf, 1, 1)
        @test_throws ArgumentError sector_hamiltonian(zeros(2, 2), 1, 1, 1; J=NaN)
        @test_throws ArgumentError sector_hamiltonian(zeros(16, 16), 1, 8, 8)
        @test_throws ArgumentError sector_hamiltonian(ones(4, 4), 1, 2, 2; max_bytes=20_000)
        @test_throws ArgumentError dense_hamiltonian(h32; max_bytes=63)
        @test h32.estimated_bytes <= 512*1024^2
    end
end

end
