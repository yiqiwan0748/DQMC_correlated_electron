module PRL101237004Fig1Tests

using LinearAlgebra
using Test
include(joinpath(@__DIR__, "..", "scripts", "run_prl_101_237004_fig1.jl"))
const F = PRL101237004Fig1
const M = F.PRL101237004Model

@testset "PRL Fig. 1 filling and Fermi contours" begin
    @testset "Density normalization and degeneracies" begin
        p = M.slater_koster_parameters()
        empty = F.filling_audit(p, 24, -100.0)
        full = F.filling_audit(p, 24, 100.0)
        @test empty.density_at_reference == 0.0
        @test full.density_at_reference == 4.0
        @test full.lower_density_at_reference == 2.0
        @test full.upper_density_at_reference == 2.0
        @test empty.density_below_half_mu <= 2 <= empty.density_through_half_mu
        # A flat band is a maximally degenerate boundary: report the entire
        # allowed filling interval rather than asserting exact half filling.
        flat = F.filling_audit(M.PaperHoppingParameters(0., 0., 0., 0.), 8, 0.)
        @test flat.mu_half == 0.0
        @test flat.density_below_half_mu == 0.0
        @test flat.density_through_half_mu == 4.0
        @test_throws ArgumentError F.filling_audit(p, 0, 0.)
        @test_throws ArgumentError F.filling_audit(p, 16, NaN)
    end
    @testset "All four pockets cross and preserve C4" begin
        for (p, mu) in ((M.slater_koster_parameters(), -0.03), (M.raghu_parameters(), 1.54), (M.raghu_parameters(), 1.45))
            contours = F.fermi_contours(p, mu; angles=32)
            @test length(contours) == 4
            grid = F.filling_audit(p, 200, mu)
            areas = F.contour_band_densities(contours)
            # Coarse 32-sided polygons and 200x200 counting differ at the
            # 0.01 level; the production runner uses much finer grids.
            @test isapprox(areas.lower, grid.lower_density_at_reference; atol=0.01, rtol=0)
            @test isapprox(areas.upper, grid.upper_density_at_reference; atol=0.01, rtol=0)
            for c in contours
                @test all(isfinite, c.radius)
                @test all(>(0), c.radius)
                @test isapprox(c.kx[1], c.kx[end]; atol=1e-12, rtol=0)
                @test isapprox(c.ky[1], c.ky[end]; atol=1e-12, rtol=0)
                for i in eachindex(c.theta)
                    # Independent LAPACK diagonalization validates the
                    # analytic band roots; 1e-11 permits order-one roundoff.
                    energies = eigvals(Symmetric(M.paper_bloch_hamiltonian(c.kx[i], c.ky[i], p)))
                    @test isapprox(energies[c.pocket.band], mu; atol=1e-11, rtol=0)
                end
                @test isapprox(c.radius[1], c.radius[17]; atol=1e-12, rtol=0)
            end
            @test isapprox(contours[3].radius[1], contours[4].radius[9]; atol=1e-12, rtol=0)
        end
        @test_throws ArgumentError F.fermi_contours(M.slater_koster_parameters(), -0.03; angles=1)
        @test_throws ErrorException F.fermi_contours(M.slater_koster_parameters(), 100.0; angles=16)
    end
    @testset "Output does not replace existing work" begin
        mktempdir() do directory
            path = joinpath(directory, "keep.txt")
            write(path, "preserve")
            @test_throws ErrorException F.main(["--output-dir=$directory"])
            @test read(path, String) == "preserve"
        end
    end
end

end
