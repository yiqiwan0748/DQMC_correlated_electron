using Test, LinearAlgebra
if !isdefined(@__MODULE__,:PRL101237004Fig2CAdaptiveFilling)
    include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_adaptive_filling.jl"))
end
const Fig2cAdaptiveTests=PRL101237004Fig2CAdaptiveFilling

@testset "Fig2c adaptive filling domain boundaries" begin
    A=Fig2cAdaptiveTests
    sample(x)=x<.13 ? (;relative_mu=x,valid=true,gradient=.10-x) : (;relative_mu=x,valid=false)
    found=A.refine_validity_boundary(sample,sample(.08),sample(.16);gradient_atol=1e-12)
    @test found.status==:sign_bracket
    @test found.evaluations==1
    @test found.bracket[1].relative_mu<.10<found.bracket[2].relative_mu
    @test all(x.valid for x in found.bracket)
    @test signbit(found.bracket[1].gradient)!=signbit(found.bracket[2].gradient)
    reverse_sample(x)=x>-.13 ? (;relative_mu=x,valid=true,gradient=x+.10) : (;relative_mu=x,valid=false)
    reverse=A.refine_validity_boundary(reverse_sample,reverse_sample(-.08),reverse_sample(-.16);gradient_atol=1e-12)
    @test reverse.status==:sign_bracket
    @test reverse.bracket[1].relative_mu<-.10<reverse.bracket[2].relative_mu
    outside(x)=x<=.09 ? (;relative_mu=x,valid=true,gradient=.12-x) : (;relative_mu=x,valid=false)
    rejected=A.refine_validity_boundary(outside,outside(.08),outside(.16);max_iterations=40,x_atol=1e-10)
    @test rejected.status==:domain_boundary_without_root
    @test rejected.bracket===nothing
    @test rejected.candidate===nothing
    @test rejected.valid_endpoint.gradient>.029
    @test rejected.evaluations<=40
    no_budget=A.refine_validity_boundary(sample,sample(.08),sample(.16);max_iterations=0)
    @test no_budget.evaluations==0
    @test no_budget.status==:iteration_limit
    @test no_budget.bracket===nothing
    exact=A.refine_validity_boundary(sample,sample(.04),sample(.16);gradient_atol=1e-12)
    @test exact.status==:residual_candidate
    @test exact.candidate.valid
    @test abs(exact.candidate.gradient)<=1e-12
    @test_throws ArgumentError A.refine_validity_boundary(sample,sample(.08),sample(.12))
    @test_throws ArgumentError A.refine_validity_boundary(x->(;relative_mu=x,valid=true,gradient=NaN),sample(.08),sample(.16))
    @test_throws ArgumentError A.refine_validity_boundary(sample,sample(.08),sample(.16);max_iterations=-1)

    # The wrapper preserves an already converged result and checks density,
    # without introducing an unnecessary retry or changing the frozen solver.
    F=A.F
    K=Matrix(Diagonal([-.3,.4]))
    reference=F.noninteracting_reference(K,K,1,1)
    lattice=F.LatticeEmbedding([Matrix(Diagonal([-.1,.2]))],1)
    solved=A.solve_filling(reference,lattice;mu_initial=.05,mu_prime_initial=.05)
    @test solved.converged
    @test solved.retry_count==0
    @test length(solved.attempts)==1
    @test isempty(solved.adaptive_boundaries)
    @test abs(solved.choice.data.density-2)<1e-7
    @test abs(solved.choice.data.mu_prime_gradient)<1e-7
    @test_throws ArgumentError A.solve_filling(reference,lattice;mu_initial=.05,adaptive_max_boundaries=-1)
end
