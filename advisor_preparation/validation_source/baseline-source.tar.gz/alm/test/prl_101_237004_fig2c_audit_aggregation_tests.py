"""Synthetic aggregation guards; these do not validate a physical calculation."""

import contextlib
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import aggregate_prl_101_237004_fig2c_audits as A


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def csv_write(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def fixture(root, name, points):
    folder = root / "batches" / name
    sources = {}
    for source in A.REQUIRED_SOURCES:
        text = f"Synthetic source fixture: {source}\n"
        write(folder / "source_snapshot" / source, text)
        sources[source] = hashlib.sha256(text.encode()).hexdigest()
    provenance = ["SYNTHETIC FIXTURE; no numerical audit was performed."]
    provenance.extend(f"{sha}  {source}" for source, sha in sources.items())
    qs, gs, ss = [], [], []
    for index, (ratio, u) in enumerate(points, 1):
        prod = dict(ratio=ratio, U=u, J=u/4, h=.01, mu=2., mu_prime=2., quadrature_order=24)
        original = root / "production" / f"{name}_{index}.csv"
        csv_write(original, [prod])
        copy = folder / "inputs" / f"{index}_{original.name}"
        copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, copy)
        provenance.append(f"{A.digest(original.read_bytes())}  {original}")
        q = {column: 0. for column in A.QUADRATURE_COLUMNS}
        q.update(ratio=ratio, U=u, h=.01, production_order=24, refined_order=48,
                 production_profile="original", field_difference_method="held_potential_Omega",
                 center_refinement_method="fixed_relative_d")
        qs.append(q)
        for spin in ("up", "down"):
            for omega in A.FREQUENCIES:
                gs.append(dict(ratio=ratio, U=u, h=.01, spin=spin, omega=omega,
                    Green_norm_difference=1e-12, Green_relative_difference=1e-13,
                    block48_cache_sha256="a"*64, block96_cache_sha256="b"*64))
        rows = []
        for nu in range(9):
            for nd in range(9):
                rows.append(dict(Nup=nu, Ndown=nd, N=nu+nd,
                    dimension=math.comb(8,nu)*math.comb(8,nd),
                    energy_canonical=2*(nu+nd)+(nu-4)**2+(nd-4)**2,
                    direct_residual=1e-12, matvecs=0, restarts=0, seed=0))
        label = next(label for r, label, _ in A.CURVES if r == ratio)
        tag = f"{label}_U{u}"
        sector = folder / "sectors" / tag
        csv_write(sector / "sectors.csv", rows)
        write(sector / "metadata.toml", f"""sector_count=81
U={u}
J={u/4}
target_energy_canonical=16.0
mu_lower=1.0
mu_upper=3.0
[physical_metadata]
ratio={ratio}
U={u}
h=0.01
mu=2.0
mu_prime=2.0
""")
        for file in ("K_up.csv", "K_down.csv", "particle_minima.csv", "stationary_stability.txt"):
            write(sector / file, "Synthetic fixture, not numerical evidence\n")
        for file in ("refined_center.txt", "depth96_center.txt"):
            write(folder / "point_diagnostics" / tag / file, "Synthetic fixture\n")
        ss.append(dict(ratio=ratio, U=u, h=.01, mu_prime=2., target_E0_difference=0.,
            max_sector_residual=1e-12, all_N_mu_lower=1., all_N_mu_upper=3.,
            minimum_competing_grand_energy_margin=1., target_lowest_at_same_N="true"))
    for filename, rows in zip(A.TABLES, (qs, gs, ss)):
        csv_write(folder / filename, rows)
    write(folder / "provenance.txt", "\n".join(provenance)+"\n")
    write(folder / "completed.txt", f"Completed synthetic fixture; audited points={len(points)}; source and input hashes unchanged.\n")
    return folder


class AggregationGuards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="prl-aggregation-guards-")
        self.root = Path(self.temp.name)
        self.points = [(r, u) for r, _, _ in A.CURVES for u in A.US]
        self.batches = [fixture(self.root, "first_six", self.points[:6]),
                        fixture(self.root, "last_four", self.points[6:])]
        self.output = self.root / "aggregate"

    def tearDown(self):
        self.temp.cleanup()

    def assertRejected(self, pattern):
        with self.assertRaisesRegex(A.ReportError, pattern):
            A.aggregate(self.batches, self.output)
        self.assertFalse(self.output.exists())

    def test_completed_unique_batches_preserve_bytes_and_mixed_archives(self):
        summary = A.aggregate(self.batches, self.output)
        self.assertEqual(summary, dict(batches=2, points=10, sector_calculations=810, green_probes=120))
        for ratio, label, audit in A.CURVES:
            folder = self.output / audit
            with (folder / "quadrature_and_field.csv").open() as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual([float(row["U"]) for row in rows], list(A.US))
            self.assertTrue(all(float(row["ratio"]) == ratio for row in rows))
            manifest = json.loads((folder / "aggregation.json").read_text())
            self.assertEqual(len(manifest["points"]), 5)
            for batch_name, record in manifest["batches"].items():
                for relative, sha in record["files_sha256"].items():
                    self.assertEqual(A.digest((folder/"batches"/batch_name/relative).read_bytes()), sha)
            for point in manifest["points"]:
                tag = f"{label}_U{point['U']}"
                source = self.root / "batches" / point["batch"] / "sectors" / tag / "metadata.toml"
                self.assertEqual((folder/"sectors"/tag/"metadata.toml").read_bytes(), source.read_bytes())
            self.assertIn("audited points=5", (folder / "completed.txt").read_text())

    def test_check_only_does_not_publish(self):
        self.assertEqual(A.aggregate(self.batches, self.output, True)["points"], 10)
        self.assertFalse(self.output.exists())

    def test_incomplete_batch_is_not_silently_skipped(self):
        (self.batches[1] / "completed.txt").unlink()
        self.assertRejected("required final input is missing")

    def test_missing_point_is_not_invented(self):
        self.batches[1] = fixture(self.root, "only_three", self.points[6:9])
        self.assertRejected("ten unique completed points required")

    def test_duplicate_across_batches_is_not_deduplicated(self):
        self.batches.append(fixture(self.root, "duplicate", [self.points[0]]))
        self.assertRejected("duplicate audited point")

    def test_source_tampering_rejected(self):
        write(self.batches[0] / "source_snapshot" / A.REQUIRED_SOURCES[0], "changed")
        self.assertRejected("source snapshot hash differs")

    def test_current_input_tampering_rejected(self):
        original = self.root / "production" / "first_six_1.csv"
        original.write_text(original.read_text().replace("0.01", "0.02"))
        self.assertRejected("copied/current audit input hash differs")

    def test_missing_green_probe_rejected(self):
        path = self.batches[1] / "green_depth.csv"
        path.write_text("\n".join(path.read_text().splitlines()[:-1])+"\n")
        self.assertRejected("incomplete Green-depth probe coverage")

    def test_missing_sector_rejected(self):
        path = next((self.batches[0] / "sectors").glob("*/sectors.csv"))
        path.write_text("\n".join(path.read_text().splitlines()[:-1])+"\n")
        self.assertRejected("incomplete 81-sector audit")

    def test_existing_output_never_overwritten(self):
        path = self.output / "numerical_audit_blue" / "sentinel.txt"
        write(path, "preserve")
        with self.assertRaisesRegex(A.ReportError, "never overwritten"):
            A.aggregate(self.batches, self.output)
        self.assertEqual(path.read_text(), "preserve")
        self.assertFalse((self.output / "numerical_audit_red").exists())

    def test_all_selected_batches_require_distinct_directories(self):
        self.batches.append(self.batches[0])
        self.assertRejected("distinct, uniquely named")

    def test_output_inside_source_batch_rejected(self):
        with self.assertRaisesRegex(A.ReportError, "inside a source batch"):
            A.aggregate(self.batches, self.batches[0] / "recursive_output")
        self.assertFalse((self.batches[0] / "recursive_output").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
