module Fig2cCanonicalFieldTests
using Test
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_canonical_field.jl"))
const Field=PRL101237004Fig2CCanonicalField

@testset "Canonical differences at a partially occupied Fermi shell" begin
    # Eight degenerate levels contain two particles: f=1/4. The chemical
    # potential follows their energy e(h). The canonical energy is smooth,
    # but a symmetric held-mu grand-potential difference chooses f=1/2.
    energy(h)=(h^2-.04^2)^2
    shell(h)=h
    grand(h,mu)=energy(h)-2shell(h)-8max(mu-shell(h),0.)
    center(h)=(;canonical=energy(h),mu=shell(h),mu_prime=.5+2h,density=2.)
    side(h,x)=center(h).canonical
    result=Field.stationary_field(center,side;fields=[0.,.01,.03,.06,.1],
        derivative_step=1e-5,gradient_atol=1e-10)
    @test result.status==:magnetic_minimum
    @test isapprox(result.selected.h,.04;atol=3e-8,rtol=0)
    @test abs(result.selected.derivative.gradient)<=1e-10
    @test result.selected.derivative.curvature>0
    h=.04;d=1e-5
    partial=(grand(h+d,shell(h))-grand(h-d,shell(h)))/(2d)
    @test isapprox(partial,2.;atol=1e-9,rtol=0)
    @test isapprox(grand(h,shell(h))+2shell(h),energy(h);atol=1e-15,rtol=0)

    stable(h)=(;canonical=3h^2+h^4,mu=.7+h,mu_prime=.8-h,density=2.)
    param=Field.stationary_field(stable,(h,x)->stable(h).canonical)
    @test param.status==:paramagnetic_minimum
    @test param.selected.h==0
    # The central curvature has its known O(step^2) quartic correction.
    @test isapprox(param.selected.derivative.curvature,6.;atol=1e-6,rtol=0)
    @test_throws ErrorException Field.stationary_field(
        h->merge(center(h),(density=1.99,)),side)
end
end
