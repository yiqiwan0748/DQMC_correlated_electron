using Test
if !isdefined(@__MODULE__,:PRL101237004Fig2CFermiShell)
    include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_fermi_shell.jl"))
end
const Fig2CShell=PRL101237004Fig2CFermiShell

@testset "Finite-mesh canonical Fermi-shell ensemble" begin
    # Six lower free levels, an eightfold shell, and two upper levels. Eight
    # particles require one-quarter shell occupation, not the half occupation
    # of an imaginary-axis integral evaluated directly at a zero pole.
    energies=vcat(fill(-1.,6),fill(.2,8),fill(1.,2))
    moments=vcat([-3.,-2.,-1.,1.,2.,3.],collect(1.:8.),[0.,0.])
    inertia(mup)=begin
        count=sum(energies.<mup)
        (;mu_prime=mup,mu=mup,relative_mu=0.,mismatch=8-count,offset=(8-count)/4,
          reference_count=8,lattice_count=count,minimum_reduced_eigenvalue=minimum(abs.(energies.-mup)))
    end
    exact(mup)=begin
        occupied=energies.<mup
        (;mu_prime=mup,mu=mup,omega=sum((energies.-mup).*occupied)/4,
          density=sum(occupied)/4,mu_prime_gradient=0.,moment=sum(moments.*occupied)/4)
    end
    initial=(;log=[inertia(.1),inertia(.3)],status=:unresolved_occupation_interval,
        converged=false,choice=nothing,lower=.1,upper=.3,width=.2,kind=:unresolved,evaluations=2,anchor=.15)
    result=Fig2CShell.resolve_fermi_shell(inertia,exact,(0.,.4),0.;initial_region=initial)
    @test result.converged
    @test result.status==:resolved_shell
    @test result.data.shell_fraction==.25
    @test result.data.occupation_policy==:canonical_shell_ensemble
    @test result.data.density≈2 atol=1e-13 rtol=0
    @test result.data.mu_prime_gradient≈0 atol=1e-13 rtol=0
    @test result.data.canonical_energy≈-1.4 atol=1e-12 rtol=0
    @test result.data.moment≈2.25 atol=1e-13 rtol=0
    @test result.data.moment_abs==abs(result.data.moment)
    @test abs(result.occupation_region.shell.canonical_continuity_error)<1e-12
    @test result.functional_evaluations==2
    @test result.occupation_region.common_shift≈.05 atol=1e-12 rtol=0
    @test result.occupation_region.shell.shell_width<=1e-12
    with_decomposition(mup)=merge(exact(mup),(;omega_reference=-1.4-2mup,
        trace_correction=.03,trace_log_integral=(-1.4-2mup+.03-exact(mup).omega)*(4pi)))
    decomposed=Fig2CShell.resolve_fermi_shell(inertia,with_decomposition,(0.,.4),0.;
        initial_region=initial,integration_scale=1/(4pi))
    @test decomposed.converged
    @test decomposed.data.omega_reference+decomposed.data.trace_correction-
        decomposed.data.trace_log_integral/(4pi)≈decomposed.data.omega atol=1e-13 rtol=0
    f=.25
    entropy=-8*(f*log(f)+(1-f)*log(1-f))/4
    for temperature in (.01,.001)
        mu=.2+temperature*log(f/(1-f))
        occupation=1 ./ (1 .+exp.((energies.-mu)./temperature))
        finite_moment=sum(moments.*occupation)/4
        # Stable independent finite-temperature grand potential.
        softplus(z)=max(z,0)+log1p(exp(-abs(z)))
        omega=-temperature*sum(softplus((mu-e)/temperature) for e in energies)/4
        @test sum(occupation)/4≈result.data.density atol=1e-12 rtol=0
        @test finite_moment≈result.data.moment atol=1e-12 rtol=0
        @test omega+2mu+temperature*entropy≈result.data.canonical_energy atol=1e-12 rtol=0
    end

    # A causal-pole-shaped SFT cusp with shell residue Z=.2 has a density
    # jump smaller than its integer auxiliary-pole count jump. The smooth
    # relative-d potential supplies a nontrivial reference-stationarity root.
    # Its finite-T function is F0(d)+.5*(eta-shell)-2T*log(1+exp((eta-shell)/T)).
    # Therefore n-2=F0'(d)-Z*offset, g=F0'(d)+(1-Z)*offset.
    d=.037; root=.037; z=.2; shell=.2+z*d
    correlated_inertia(mup)=merge(inertia(mup-z*d),(;mu_prime=mup,mu=mup-d,relative_mu=d))
    correlated(mup)=begin
        off=mup<shell ? .5 : -1.5
        derivative=2(d-root)
        canonical=(d-root)^2+off*(mup-shell)
        (;mu_prime=mup,mu=mup-d,omega=canonical-2(mup-d),
          density=2+derivative-z*off,mu_prime_gradient=derivative+(1-z)*off,
          moment=mup<shell ? 1. : 3.)
    end
    correlated_initial=merge(initial,(;log=[correlated_inertia(.1),correlated_inertia(.3)]))
    correlated_result=Fig2CShell.resolve_fermi_shell(correlated_inertia,correlated,(0.,.4),d;
        initial_region=correlated_initial)
    @test correlated_result.converged
    @test correlated_result.data.shell_fraction==.25
    @test correlated_result.data.density≈2 atol=1e-13 rtol=0
    @test correlated_result.data.mu_prime_gradient≈0 atol=1e-13 rtol=0
    @test correlated_result.data.moment≈1.5 atol=1e-13 rtol=0
    for temperature in (.01,.001)
        eta=shell+temperature*log(f/(1-f))
        ft=1/(1+exp(-(eta-shell)/temperature))
        offset=.5-2ft
        @test 2+2(d-root)-z*offset≈correlated_result.data.density atol=1e-13 rtol=0
        @test 2(d-root)+(1-z)*offset≈correlated_result.data.mu_prime_gradient atol=1e-13 rtol=0
        @test 1+2ft≈correlated_result.data.moment atol=1e-13 rtol=0
    end

    budget=Fig2CShell.resolve_fermi_shell(inertia,exact,(0.,.4),0.;initial_region=initial,max_iterations=0)
    @test !budget.converged
    @test budget.status==:shell_iteration_limit
    @test budget.functional_evaluations==0
    @test budget.occupation_region.evaluations==2
    bad_identity(mup)=merge(exact(mup),(;mu_prime_gradient=.001))
    wrong=Fig2CShell.resolve_fermi_shell(inertia,bad_identity,(0.,.4),0.;initial_region=initial)
    @test !wrong.converged
    @test wrong.status==:shell_quadrature_identity_unresolved
    bad_energy(mup)=merge(exact(mup),(;omega=exact(mup).omega+(mup<.2 ? 0 : .001)))
    wrong=Fig2CShell.resolve_fermi_shell(inertia,bad_energy,(0.,.4),0.;initial_region=initial)
    @test !wrong.converged
    @test wrong.status==:shell_energy_continuity_unresolved
    missing_negative=merge(initial,(;log=[inertia(.01),inertia(.1)]))
    wrong=Fig2CShell.resolve_fermi_shell(inertia,exact,(0.,.4),0.;initial_region=missing_negative)
    @test !wrong.converged
    @test wrong.status==:shell_no_negative_bracket
    @test_throws ArgumentError Fig2CShell.resolve_fermi_shell(inertia,exact,(0.,.4),0.;
        initial_region=initial,shell_x_atol=0.)
    @test_throws ArgumentError Fig2CShell.resolve_fermi_shell(inertia,
        mup->merge(exact(mup),(;density=NaN)),(0.,.4),0.;initial_region=initial)

    # A genuine finite interval discovered during refinement must retain
    # integer occupations rather than manufacture a fractional shell.
    interval_inertia(mup)=begin
        count=mup<.19 ? 6 : mup>.21 ? 14 : 8
        merge(inertia(mup),(;mismatch=8-count,offset=(8-count)/4,lattice_count=count))
    end
    interval_exact(mup)=(;mu_prime=mup,mu=mup,omega=-1.4-2mup,
        density=2.,mu_prime_gradient=0.,moment=0.)
    interval_initial=merge(initial,(;log=[interval_inertia(.1),interval_inertia(.3)]))
    integer=Fig2CShell.resolve_fermi_shell(interval_inertia,interval_exact,(0.,.4),0.;
        initial_region=interval_initial)
    @test integer.converged
    @test integer.status==:resolved_interval
    @test integer.data.occupation_policy==:integer_interval
    @test integer.functional_evaluations==1
end
