using Test
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_field.jl"))
const Fig2cFieldTests=PRL101237004Fig2cField

@testset "Canonical field stationarity with changing chemical potential" begin
    # A varying physical mu contributes −2mu to Ω. The canonical envelope
    # and fixed-mu partial derivative must remove that irrelevant variation.
    canonical(h)=(h^2-.04^2)^2
    center(h)=(;canonical=canonical(h),mu=.8+4h,mu_prime=.9+3h,density=2.)
    side(h,x)=canonical(h)-2x.mu
    answer=Fig2cFieldTests.stationary_field(center,side;
        fields=[0.,.01,.03,.06,.1],derivative_step=1e-5,gradient_atol=1e-10)
    @test answer.status==:magnetic_minimum
    # Central differences shift this quartic's minimum by O(step²/h).
    @test isapprox(answer.selected.h,.04;atol=3e-8,rtol=0)
    @test abs(answer.selected.derivative.gradient)<=1e-10
    @test answer.selected.center.canonical<answer.cache[0.].canonical
    @test answer.selected.derivative.curvature>0
    # A variational functional can be a saddle. Eliminating a stationary
    # reference parameter changes the second derivative, not the envelope's
    # first derivative. Rejecting negative partial Ω_hh would lose this root.
    saddle_center(h)=(;canonical=canonical(h),mu=.8,mu_prime=2h^2,density=2.)
    saddle_side(h,x)=canonical(h)-(x.mu_prime-2h^2)^2/2-2x.mu
    saddle=Fig2cFieldTests.stationary_field(saddle_center,saddle_side;
        fields=[0.,.01,.03,.06,.1],derivative_step=1e-5,gradient_atol=1e-10)
    @test saddle.status==:magnetic_minimum
    @test isapprox(saddle.selected.h,.04;atol=3e-8,rtol=0)
    @test saddle.selected.derivative.curvature<0
    stable(h)=(;canonical=3h^2+h^4,mu=.7+h,mu_prime=.8-h,density=2.)
    stable_side(h,x)=3h^2+h^4-2x.mu
    param=Fig2cFieldTests.stationary_field(stable,stable_side)
    @test param.status==:paramagnetic_minimum
    @test param.selected.h==0
    @test isapprox(param.selected.derivative.curvature,6.;atol=1e-6,rtol=0)
    @test_throws ArgumentError Fig2cFieldTests.stationary_field(center,side;fields=[.01,.02,.03])
    @test_throws ErrorException Fig2cFieldTests.stationary_field(h->merge(center(h),(density=1.99,)),side)
    @test_throws ErrorException Fig2cFieldTests.stationary_field(
        h->(;canonical=-h^2,mu=.8,mu_prime=.9,density=2.),(h,x)->-h^2-2x.mu)
end
