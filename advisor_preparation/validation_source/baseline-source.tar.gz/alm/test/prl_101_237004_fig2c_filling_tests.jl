using Test, LinearAlgebra
if !isdefined(@__MODULE__,:PRL101237004Fig2CFilling)
    include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_filling.jl"))
end
const Fig2cFillingTests=PRL101237004Fig2CFilling

@testset "Fig2c occupation counts and half filling" begin
    FF=Fig2cFillingTests.F
    kinetic=Matrix(Diagonal([-.3,.4]))
    reference=FF.noninteracting_reference(kinetic,kinetic,1,1)
    lattice=FF.LatticeEmbedding([Matrix(Diagonal([-.1,.2])),Matrix(Diagonal([-.05,.3]))],1)
    # The independent dense one-body occupancy is an exact inertia oracle.
    for mup in (-.2,.05,.25),relative in (-.2,0.,.2)
        mu=mup-relative
        actual=Fig2cFillingTests.occupation_inertia(reference,lattice,relative,mup)
        exact_density=FF.free_lattice_observables(lattice,mu).density
        @test actual.offset≈2-exact_density atol=2e-14 rtol=0
        @test actual.mu==mu
    end
    region=Fig2cFillingTests.occupation_region(reference,lattice,-.3;mu_prime_initial=.05)
    @test region.converged
    @test region.choice.mismatch==0
    @test region.lower<region.choice.mu_prime<region.upper
    @test region.common_shift<0
    @test FF.free_lattice_observables(lattice,region.choice.mu).density==2
    rejected=Fig2cFillingTests.occupation_region(reference,lattice,10.;mu_prime_initial=.05)
    @test !rejected.converged
    @test rejected.status==:no_occupation_bracket
    bounded=Fig2cFillingTests.occupation_region(reference,lattice,-.3;mu_prime_initial=.05,max_iterations=0)
    @test !bounded.converged
    solved=Fig2cFillingTests.solve_filling(reference,lattice;mu_initial=.35,mu_prime_initial=.05,order=24)
    @test solved.converged
    @test abs(solved.choice.data.density-2)<1e-7
    @test abs(solved.choice.data.mu_prime_gradient)<1e-7
    @test solved.choice.data.canonical_energy≈solved.choice.data.omega+2solved.choice.data.mu atol=1e-14 rtol=0

    # Exact atomic two-pole Green function, including G′(0)=0 at μ′=U/2.
    # Compare against the full auxiliary Hamiltonian's negative pole count.
    coupling=1.4
    function atomic_green(z,spin)
        g=.5/z+.5/(z-coupling)
        gd=-.5/z^2-.5/(z-coupling)^2
        Matrix(Diagonal(fill(g,2))),Matrix(Diagonal(fill(gd,2)))
    end
    atomic=FF.ReferenceSystem(0.,2,zeros(2,2),zeros(2,2),atomic_green;mu_interval=(0.,coupling))
    auxiliary_lattice=FF.LatticeEmbedding([Matrix(Diagonal([-.9,.9])),[.3 .2;.2 -.3]],1)
    Q=hcat(Matrix{Float64}(I,2,2),Matrix{Float64}(I,2,2))/sqrt(2)
    poles=[0.,0.,coupling,coupling]
    for mup in (.1,.7,1.2),relative in (-.4,0.,.4)
        actual=Fig2cFillingTests.occupation_inertia(atomic,auxiliary_lattice,relative,mup)
        reference_negative=2count(<(0),poles.-mup)*length(auxiliary_lattice.hoppings)
        embedded_negative=0
        for K in auxiliary_lattice.hoppings
            H=Diagonal(poles.-mup)+Q'*(K+relative*I)*Q
            embedded_negative+=2count(<(0),eigvals(Hermitian(H)))
        end
        @test actual.mismatch==reference_negative-embedded_negative
        @test isfinite(actual.offset)
    end
    central=Fig2cFillingTests.occupation_inertia(atomic,auxiliary_lattice,0.,.7)
    @test central.zero_reference_modes==4
    @test central.mismatch==0
    atomic_solution=Fig2cFillingTests.solve_filling(atomic,auxiliary_lattice;mu_initial=.7,mu_prime_initial=.7)
    @test atomic_solution.converged
    @test abs(atomic_solution.choice.data.density-2)<1e-7
    @test abs(atomic_solution.choice.data.mu_prime_gradient)<1e-7
    @test_throws ArgumentError Fig2cFillingTests.solve_filling(atomic,auxiliary_lattice;mu_initial=NaN)
    @test_throws ArgumentError Fig2cFillingTests.occupation_region(atomic,auxiliary_lattice,0.;edge_fraction=.5)
end
