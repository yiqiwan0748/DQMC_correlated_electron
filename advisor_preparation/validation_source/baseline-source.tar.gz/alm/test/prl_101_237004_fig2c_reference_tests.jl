module PRL101237004Fig2cReferenceTests
using Test
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_reference.jl"))
module IndependentNamespace
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_reference.jl"))
end
const R=PRL101237004Fig2cReference
const Q=IndependentNamespace.PRL101237004Fig2cReference

@testset "Portable canonical reference cache across module namespaces" begin
    mktempdir() do directory
        # This tests lossless cache transport, not depth-eight Green accuracy.
        # The solver's numerical depth is validated independently at final
        # stationary points. Exact equality is appropriate for serialization.
        first=R.reference_state(1.,-.2,.04;block_steps=8,output=directory)
        second=Q.reference_state(1.,-.2,.04;block_steps=8,output=directory)
        @test first.cache==second.cache
        @test first.metadata==second.metadata
        @test first.metadata.cache_format==2
        @test typeof(first.result)!=typeof(second.result)
        @test first.result.E0==second.result.E0
        @test R.C.cluster_green(first.result,.85+.1im)==Q.C.cluster_green(second.result,.85+.1im)
    end
end
end
