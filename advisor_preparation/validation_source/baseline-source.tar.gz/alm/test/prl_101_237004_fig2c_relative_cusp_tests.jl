using Test
if !isdefined(@__MODULE__,:PRL101237004Fig2CFermiShell)
    include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_fermi_shell.jl"))
end
const Fig2cRelativeCuspTests=PRL101237004Fig2CFermiShell

@testset "Relative-potential cusp: independent finite-T two-group oracle" begin
    Shell=Fig2cRelativeCuspTests
    # Local causal-pole contribution to the canonical functional, with
    # eta=mu_prime, d=mu_prime-mu, and two unequal physical pole residues Zj:
    #
    # F_T = E0 + b*(d-d0) + (eta-eta0)
    #       - T*sum_j log(1+exp((eta-eta0-Zj*(d-d0))/T)).
    #
    # Each group has unit auxiliary-pole weight. Its Fermi factor is fj.
    # I = F_eta = 1-f1-f2; n-2 = F_d = b+Z1*f1+Z2*f2;
    # g_muprime = F_eta+F_d. The two zero-T, zero-count windows have
    # (f1,f2)=(0,1) to the left and (1,0) to the right. They close at the
    # same (eta0,d0), with identical self-energy parameters in that limit.
    eta0,d0,E0=.21,.037,-.8
    moment_background=.1
    moment_weights=(.7,-.3)
    epsilon=2e-11
    function endpoint(delta,Z,b;decomposition=false)
        d=d0+delta
        actual_delta=d-d0
        eta=eta0+(Z[1]+Z[2])/2*actual_delta
        mu=eta-d
        occupied=actual_delta<0 ? 2 : 1
        gradient=b+Z[occupied]
        canonical=E0+gradient*actual_delta
        moment=moment_background+moment_weights[occupied]
        data=(;mu,mu_prime=eta,omega=canonical-2mu,canonical_energy=canonical,
            density=2+gradient,mu_prime_gradient=gradient,moment,moment_abs=abs(moment))
        if decomposition
            omega_reference=-.5-2eta
            trace_correction=.1+.3actual_delta
            trace_log_integral=(omega_reference+trace_correction-data.omega)*pi
            data=merge(data,(;omega_reference,trace_correction,trace_log_integral))
        end
        inertia=(;mu,mu_prime=eta,relative_mu=d,mismatch=0,offset=0.,
            reference_count=8,lattice_count=8,minimum_reduced_eigenvalue=abs(actual_delta))
        lower=eta0+min(Z[1]*actual_delta,Z[2]*actual_delta)
        upper=eta0+max(Z[1]*actual_delta,Z[2]*actual_delta)
        region=(;width=upper-lower,lower,upper,anchor=eta0-.01,
            converged=true,choice=inertia,log=[inertia],evaluations=1)
        (;valid=true,relative_mu=d,mu,mu_prime=eta,gradient,data,inertia,
          occupation_region=region,functional_evaluations=0)
    end
    softplus(x)=max(x,0)+log1p(exp(-abs(x)))
    for (Z,b) in (((.2,.8),-.35),((.1,.6),-.475))
        left=endpoint(-epsilon,Z,b)
        right=endpoint(epsilon,Z,b)
        result=Shell.resolve_relative_cusp(left,right)
        @test result.converged
        @test result.status==:resolved_relative_cusp
        choice=result.choice
        @test choice.data.occupation_policy==:canonical_relative_cusp_ensemble
        @test choice.inertia.offset==0
        @test choice.data.density≈2 atol=1e-13 rtol=0
        @test choice.data.mu_prime_gradient≈0 atol=1e-13 rtol=0
        @test choice.data.mu_prime≈eta0 atol=1e-13 rtol=0
        @test choice.relative_mu≈d0 atol=1e-13 rtol=0
        @test choice.data.mu≈eta0-d0 atol=1e-13 rtol=0
        @test choice.data.canonical_energy≈E0 atol=1e-13 rtol=0
        @test choice.data.omega+2choice.data.mu≈E0 atol=1e-13 rtol=0
        @test choice.occupation_region.common_shift≈.01 atol=1e-13 rtol=0
        @test abs(choice.occupation_region.shell.canonical_continuity_error)<1e-13

        # Solve the independent finite-T stationarity equations I=0 and
        # F_d=0 for each group's occupation; then invert Fermi functions.
        # Both chemical-potential changes are O(T), not finite-separated
        # self-energies. Unequal Zj require unequal group occupations.
        f1=(-b-Z[2])/(Z[1]-Z[2])
        f2=1-f1
        logits=(log(f1/(1-f1)),log(f2/(1-f2)))
        d_slope=(logits[1]-logits[2])/(Z[2]-Z[1])
        eta_slope=logits[1]+Z[1]*d_slope
        entropy=-sum(f*log(f)+(1-f)*log(1-f) for f in (f1,f2))
        @test abs(f1-f2)>.4
        @test choice.data.relative_cusp_fraction≈f1 atol=1e-13 rtol=0
        for temperature in (.01,.001,.0001)
            d=d0+temperature*d_slope
            eta=eta0+temperature*eta_slope
            energy=[eta0+z*(d-d0)-eta for z in Z]
            occupation=1 ./ (1 .+exp.(energy./temperature))
            offset=1-sum(occupation)
            density=2+b+sum(Z[j]*occupation[j] for j in 1:2)
            gradient=offset+density-2
            moment=moment_background+sum(moment_weights[j]*occupation[j] for j in 1:2)
            finite_F=E0+b*(d-d0)+(eta-eta0)-
                temperature*sum(softplus(-e/temperature) for e in energy)
            # 1e-11 allows loss of relative precision in the small O(T)
            # shifts. The entropy-corrected energy has only 1e-13 error.
            @test occupation≈[f1,f2] atol=1e-11 rtol=0
            @test offset≈0 atol=1e-11 rtol=0
            @test density≈choice.data.density atol=1e-11 rtol=0
            @test gradient≈choice.data.mu_prime_gradient atol=1e-11 rtol=0
            @test moment≈choice.data.moment atol=1e-11 rtol=0
            @test finite_F+temperature*entropy≈choice.data.canonical_energy atol=1e-13 rtol=0
        end
    end

    Z,b=(.2,.8),-.35
    left=endpoint(-epsilon,Z,b;decomposition=true)
    right=endpoint(epsilon,Z,b;decomposition=true)
    decomposed=Shell.resolve_relative_cusp(left,right;integration_scale=1/pi)
    @test decomposed.converged
    x=decomposed.choice.data
    @test x.omega_reference+x.trace_correction-x.trace_log_integral/pi≈x.omega atol=1e-13 rtol=0
    @test x.moment_abs==abs(x.moment)

    function rejected(a,b,status)
        result=Shell.resolve_relative_cusp(a,b)
        @test !result.converged
        @test result.status==status
        @test result.choice===nothing
    end
    rejected(merge(left,(;valid=false)),right,:cusp_invalid_endpoint)
    rejected(endpoint(-1e-4,Z,b),endpoint(1e-4,Z,b),:cusp_bracket_not_closed)
    rejected(right,left,:cusp_bracket_not_closed)
    rejected(left,merge(right,(;gradient=.15)),:cusp_no_sign_bracket)
    rejected(left,merge(right,(;gradient=-1e-8)),:cusp_jump_not_resolved)
    different_potentials=merge(right.data,(;mu=right.data.mu+.001,
        mu_prime=right.data.mu_prime+.001))
    rejected(left,merge(right,(;data=different_potentials)),:cusp_potentials_do_not_coalesce)
    rejected(left,merge(right,(;occupation_region=merge(right.occupation_region,(;width=.01)))),
        :cusp_occupation_windows_open)
    rejected(left,merge(right,(;inertia=merge(right.inertia,(;offset=.01)))),:cusp_count_not_zero)
    rejected(left,merge(right,(;inertia=merge(right.inertia,(;reference_count=9)))),
        :cusp_reference_zero_ambiguous)
    rejected(left,merge(right,(;data=merge(right.data,(;canonical_energy=right.data.canonical_energy+.001)))),
        :cusp_energy_discontinuous)
    rejected(left,merge(right,(;data=merge(right.data,(;density=right.data.density+.001)))),
        :cusp_mixed_residual_unresolved)
    @test_throws ArgumentError Shell.resolve_relative_cusp(left,right;potential_atol=0.)
end
