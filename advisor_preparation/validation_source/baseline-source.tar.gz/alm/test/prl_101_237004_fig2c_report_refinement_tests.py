"""Synthetic report guards for optional field refinements, not solver tests."""

import csv
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import summarize_prl_101_237004_fig2c as S


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def toml_write(path, values):
    lines = []
    for name, value in values.items():
        if not isinstance(value, dict):
            lines.append(f"{name} = {json.dumps(value)}")
    for name, table in values.items():
        if isinstance(table, dict):
            lines.append(f"[{name}]")
            lines.extend(f"{json.dumps(key)} = {json.dumps(value)}" for key, value in table.items())
    write(path, "\n".join(lines)+"\n")


def csv_write(path, rows):
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
    write(path, buffer.getvalue())


class OptionalRefinementGuards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="prl-report-refinement-guards-")
        self.root = Path(self.temp.name)
        self.audit = self.root / "original_field_refinement"
        self.scans, self.comparisons, self.rows = {}, {}, []
        input_hashes = {}
        source = self.audit / "source_snapshot/scripts/synthetic_fixture.jl"
        write(source, "Synthetic report fixture; no physics calculated.\n")
        for ratio, u in sorted(S.SMOOTH_REFINEMENT_POINTS):
            label = next(label for r, label, _ in S.CURVES if r == ratio)
            prod = dict(ratio=ratio, U=u, h=.02*u, moment_abs_muB_per_Fe=1.23+u/10, F_per_Fe=.1)
            self.scans[ratio,u] = prod
            self.comparisons[ratio,u] = dict(moment_published_muB_per_Fe=prod['moment_abs_muB_per_Fe']-.001999,
                                             moment_difference_muB_per_Fe=.001999)
            point = self.audit / f"points/{label}_U{u}"
            row = dict(ratio=ratio, U=u, production_h=prod['h'], refined_h=prod['h']-1e-6,
                h_change=-1e-6, production_moment_abs=prod['moment_abs_muB_per_Fe'],
                refined_moment_abs=prod['moment_abs_muB_per_Fe']+3e-6, moment_abs_change=3e-6,
                production_F=.1, refined_F=.1-1e-11, F_change=-1e-11,
                refined_density=2., refined_mu_prime_gradient=1e-12, refined_h_gradient=1e-9,
                field_step=5e-5, quadrature_order=48, block_steps=48, physical_L=48,
                field_difference_method='held_potential_Omega',
                summary_path=f"points/{label}_U{u}/summary.toml")
            self.rows.append(row)
            summary = {name:value for name,value in row.items() if name not in ('summary_path','refined_h_gradient')}
            summary.update(converged=True, refined_gradient=row['refined_h_gradient'], initial_bracket_gradients=[-1e-4,1e-4])
            toml_write(point/'summary.toml',summary)
            toml_write(point/'completed.toml',dict(output_sha256={'summary.toml':sha(point/'summary.toml')}))
            for name in ('result.csv','provenance.txt','completed.txt','field_derivatives.csv'):
                relative=f"runs/{label}/U{u}/{name}"
                original=self.root/relative
                if name=='result.csv':csv_write(original,[prod])
                else:write(original,'Synthetic report fixture\n')
                copied=self.audit/'inputs'/relative
                copied.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,copied)
                input_hashes[relative]=sha(original)
        csv_write(self.audit/'refinement_summary.csv',self.rows)
        toml_write(self.audit/'provenance.toml',dict(source_sha256={'scripts/synthetic_fixture.jl':sha(source)},input_sha256=input_hashes))
        self.update_marker()

    def update_marker(self, count=5):
        toml_write(self.audit/'completed.toml',dict(completed_points=count,source_and_input_hashes_unchanged=True,
            output_sha256={name:sha(self.audit/name) for name in ('provenance.toml','refinement_summary.csv')}))

    def tearDown(self):
        self.temp.cleanup()

    def load(self):
        return S.load_smooth_refinement(S.Inputs(self.root),self.scans)

    def test_completed_five_point_audit_and_raw_graph_band(self):
        result=self.load()
        self.assertEqual(result['status'],'complete');self.assertEqual(len(result['rows']),5)
        before=dict(self.scans[-.2,2.])
        text='\n'.join(S.render_smooth_refinement(result,self.comparisons,S.Inputs(self.root),self.root/'report.md'))
        self.assertIn('yes→no',text)
        self.assertIn('refined value is outside the ±0.002',text)
        self.assertIn('production comparison count are unchanged',text)
        self.assertEqual(self.scans[-.2,2.],before)

    def test_incomplete_directory_never_reads_provisional_rows(self):
        (self.audit/'completed.toml').unlink()
        write(self.audit/'refinement_summary.csv','invalid provisional CSV')
        result=self.load();self.assertEqual(result['status'],'incomplete');self.assertEqual(result['rows'],{})
        text='\n'.join(S.render_smooth_refinement(result,self.comparisons,S.Inputs(self.root),self.root/'report.md'))
        self.assertIn('refinement is incomplete',text);self.assertIn('provisional rows are excluded',text)

    def test_absent_optional_audit_is_explicit(self):
        shutil.rmtree(self.audit)
        self.assertEqual(self.load()['status'],'absent')

    def test_wrong_completed_count_rejected(self):
        self.update_marker(count=4)
        with self.assertRaisesRegex(S.ReportError,'five-point completion'):self.load()

    def test_changed_current_input_rejected(self):
        path=next((self.root/'runs').glob('*/U*/result.csv'))
        path.write_text(path.read_text()+'changed\n')
        with self.assertRaisesRegex(S.ReportError,'copied/current input hash differs'):self.load()

    def test_changed_point_summary_rejected(self):
        path=next((self.audit/'points').glob('*/summary.toml'))
        path.write_text(path.read_text()+'changed=true\n')
        with self.assertRaisesRegex(S.ReportError,'output hash differs'):self.load()

    def test_unexpected_five_point_set_rejected(self):
        self.rows[0]['U']=.5
        csv_write(self.audit/'refinement_summary.csv',self.rows);self.update_marker()
        with self.assertRaisesRegex(S.ReportError,'five unique expected points'):self.load()


if __name__=='__main__':
    unittest.main(verbosity=2)
