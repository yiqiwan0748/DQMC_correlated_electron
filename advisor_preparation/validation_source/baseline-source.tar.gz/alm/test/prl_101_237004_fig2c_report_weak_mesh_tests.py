"""Synthetic interpretation checks; no numerical solver is run."""

from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from summarize_prl_101_237004_fig2c import interpret_weak_mesh


def fixture():
    return dict(ratio=-.5, U=.75, h=.03, baseline_L=48, audit_L=96,
        L96_moment_abs=.49, refilled_moment_difference=-.01,
        q48_q96_moment_difference=1e-8, L96_h_derivative_step2e4=.01,
        L96_h_derivative_step1e4=.02, L96_zero_curvature=-1., L96_energy_gain=.02,
        fixed_variable_status="integer_policy_fixed_potentials", nearby_status="local_estimate_only",
        nearby_h=.04, nearby_moment_abs=.485, nearby_h_derivative=.001)


class WeakMeshInterpretation(unittest.TestCase):
    def test_mesh_shift_and_unresolved_minimum_are_distinct(self):
        text="\n".join(interpret_weak_mesh(fixture()))
        self.assertIn("from 0.500000000 on L48 to 0.490000000",text)
        self.assertIn("(-2.000%)",text)
        self.assertIn("only a local estimate, not a converged re-optimized L96 minimum",text)
        self.assertIn("at the saved h",text)

    def test_resolved_nearby_point_has_separate_moment(self):
        row=fixture();row.update(nearby_status="nearby_stationarity_resolved",nearby_h_derivative=1e-7)
        text="\n".join(interpret_weak_mesh(row))
        self.assertIn("local stationary-point check",text)
        self.assertIn("|m|=0.485000000",text)
        self.assertIn("mesh change quoted above remains the comparison at the saved h",text)

    def test_zero_baseline_does_not_create_percentage(self):
        row=fixture();row.update(L96_moment_abs=0.,refilled_moment_difference=0.,nearby_status="not_triggered")
        text="\n".join(interpret_weak_mesh(row))
        self.assertNotIn("%",text)
        self.assertIn("No nearby field re-optimization was triggered",text)

    def test_undefined_fixed_potential_comparison_stays_explicit(self):
        row=fixture();row['fixed_variable_status']="not_evaluated_degenerate_occupation_policy"
        text="\n".join(interpret_weak_mesh(row))
        self.assertIn("fixed-potential comparison is undefined",text)
        self.assertIn("quoted mesh change uses refilled canonical solutions",text)


if __name__=="__main__":
    unittest.main(verbosity=2)
