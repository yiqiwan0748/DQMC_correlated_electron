using Test, LinearAlgebra
if !isdefined(@__MODULE__,:PRL101237004Fig2CResolvedFilling)
    include(joinpath(@__DIR__,"..","scripts","prl_101_237004_fig2c_resolved_filling.jl"))
end
const Fig2cResolvedTests=PRL101237004Fig2CResolvedFilling

@testset "Fig2c resolved integration: independent pole oracles" begin
    A=Fig2cResolvedTests
    O=A.BaseFilling.Original
    F=A.F
    fine=F.imaginary_quadrature(48;breaks=A.FREQUENCY_BREAKS)

    # A two-pole atomic Green function has an independent four-dimensional
    # Hermitian auxiliary Hamiltonian. Its occupied eigenvalues give Ω, while
    # projected eigenvector weights give density. Neither oracle integrates
    # a Green function or uses the functional's derivatives.
    coupling=1.4
    function atomic_green(z,spin)
        g=.5/z+.5/(z-coupling)
        dg=-.5/z^2-.5/(z-coupling)^2
        Matrix(Diagonal(fill(g,2))),Matrix(Diagonal(fill(dg,2)))
    end
    atomic=F.ReferenceSystem(0.,2,zeros(2,2),zeros(2,2),atomic_green;
        mu_interval=(0.,coupling))
    lattice=F.LatticeEmbedding([Matrix(Diagonal([-.9,.9])),[.3 .2;.2 -.3]],1)
    Q=hcat(Matrix{Float64}(I,2,2),Matrix{Float64}(I,2,2))/sqrt(2)
    poles=[0.,0.,coupling,coupling]
    for (mu,mup) in ((.7,.7),(.65,.55),(.55,.8))
        omega=-2mup
        density=0.
        gradient=-2.
        reference_count=count(<(0),poles.-mup)
        lattice_count=0
        for K in lattice.hoppings
            eig=eigen(Hermitian(Diagonal(poles.-mup)+Q'*(K+(mup-mu)*I)*Q))
            occupied=findall(<(0),eig.values)
            residues=[sum(abs2,Q*eig.vectors[:,i]) for i in occupied]
            omega+=2/length(lattice.hoppings)*(sum(eig.values[occupied])-
                sum(min(p-mup,0.) for p in poles))
            density+=2/length(lattice.hoppings)*sum(residues)
            # Hellmann-Feynman: dH_aux/dμ′=-I+Q†Q.
            gradient+=2/length(lattice.hoppings)*
                (sum(residues)-length(occupied)+reference_count)
            lattice_count+=length(occupied)
        end
        x=F.evaluate_functional(atomic,lattice,mu,mup;quadrature=fine,threaded=false)
        inertia=O.occupation_inertia(atomic,lattice,mup-mu,mup)
        exact_mismatch=2*(length(lattice.hoppings)*reference_count-lattice_count)
        @test inertia.mismatch==exact_mismatch
        # Ω includes cancellation of the high-frequency logarithm. 5e-10 is
        # conservative versus the observed <3e-11 integration/cancellation error.
        @test x.omega≈omega atol=5e-10 rtol=0
        @test x.density≈density atol=2e-9 rtol=0
        @test x.mu_prime_gradient≈gradient atol=2e-9 rtol=0
        @test gradient-(density-2)≈inertia.offset atol=2e-14 rtol=0
    end
    central=O.occupation_inertia(atomic,lattice,0.,.7)
    @test central.zero_reference_modes==4
    @test central.mismatch==0
    solved=A.solve_filling(atomic,lattice;mu_initial=.7,mu_prime_initial=.7)
    @test solved.converged
    @test solved.choice.data.occupation_policy==:integer_interval
    @test solved.choice.data.density≈2 atol=2e-9 rtol=0
    @test solved.choice.data.mu_prime_gradient≈0 atol=2e-9 rtol=0
    @test solved.order==48
    @test collect(solved.quadrature_breaks)==collect(A.FREQUENCY_BREAKS)
    @test solved.retry_count==0
end

@testset "Fig2c near-Fermi finite gap requires frequency refinement" begin
    A=Fig2cResolvedTests
    O=A.BaseFilling.Original
    F=A.F
    K=Matrix(Diagonal([-1e-5,1e-5]))
    reference=F.noninteracting_reference(K,K,1,1)
    coarse24=F.imaginary_quadrature(24)
    coarse48=F.imaginary_quadrature(48)
    fine48=F.imaginary_quadrature(48;breaks=A.FREQUENCY_BREAKS)
    @test first(fine48.nodes)<first(coarse48.nodes)/1e5
    for gap_halfwidth in (1e-9,1e-8)
        # Three k points, two orbitals and two spins. At μ=0 all three
        # negative levels are filled. The gap is 2*gap_halfwidth > 0; there
        # is no degenerate Fermi shell or partial occupation in this test.
        e=gap_halfwidth
        lattice=F.LatticeEmbedding([
            Matrix(Diagonal([-e,.3])),
            Matrix(Diagonal([-5e,e])),
            Matrix(Diagonal([-.7,.7]))],1)
        exact_density=2.
        exact_omega=2*(-.7-6e)/3
        counts=O.occupation_inertia(reference,lattice,0.,0.)
        @test counts.mismatch==0
        @test counts.offset==0
        region=O.occupation_region(reference,lattice,0.;mu_prime_initial=0.,
            x_atol=1e-13,max_iterations=64)
        @test region.converged
        @test region.choice.mu==0
        low=F.evaluate_functional(reference,lattice,0.,0.;quadrature=coarse24,threaded=false)
        doubled=F.evaluate_functional(reference,lattice,0.,0.;quadrature=coarse48,threaded=false)
        refined=F.evaluate_functional(reference,lattice,0.,0.;quadrature=fine48,threaded=false)
        # Merely doubling order on the old first interval is insufficient.
        @test abs(low.density-exact_density)>1e-4
        @test abs(doubled.density-exact_density)>1e-6
        @test refined.density≈exact_density atol=2e-8 rtol=0
        @test refined.omega≈exact_omega atol=5e-10 rtol=0
        @test refined.mu_prime_gradient≈0 atol=1e-10 rtol=0
        # A tiny μ′ derivative alone does not establish the correct filling.
        @test abs(low.mu_prime_gradient)<1e-10
        @test abs(low.mu_prime_gradient-(low.density-2)-counts.offset)>1e-4
        @test abs(refined.mu_prime_gradient-(refined.density-2)-counts.offset)<2e-8
    end

    # Exercise the actual resolved wrapper on the finite-gap model. The
    # 1e-13 occupation tolerance resolves its gap rather than invoking shell
    # mixing. The old numerical driver rejects its wrong density; the new
    # grid converges immediately, with the selected grid recorded explicitly.
    e=1e-8
    lattice=F.LatticeEmbedding([Matrix(Diagonal([-e,.3])),
        Matrix(Diagonal([-5e,e])),Matrix(Diagonal([-.7,.7]))],1)
    old=O.solve_filling(reference,lattice;mu_initial=0.,mu_prime_initial=0.,order=24,
        max_bracket_expansions=0,max_iterations=2,occupation_x_atol=1e-13,
        occupation_max_iterations=64)
    @test !old.converged
    @test old.status==:no_relative_bracket
    coarse=A.evaluate_relative(reference,lattice,0.;mu_prime_initial=0.,order=24,
        quadrature_breaks=coarse24.breaks,occupation_x_atol=1e-13,
        occupation_max_iterations=64)
    @test !coarse.valid
    @test coarse.status==:interval_quadrature_identity_unresolved
    solved=A.solve_filling(reference,lattice;mu_initial=0.,mu_prime_initial=0.,
        max_bracket_expansions=0,max_iterations=2,occupation_x_atol=1e-13,
        occupation_max_iterations=64)
    @test solved.converged
    @test solved.choice.data.occupation_policy==:integer_interval
    @test solved.choice.inertia.mismatch==0
    @test solved.choice.data.density≈2 atol=2e-8 rtol=0
    @test solved.choice.data.omega≈2*(-.7-6e)/3 atol=5e-10 rtol=0
    @test solved.choice.data.canonical_energy≈solved.choice.data.omega atol=1e-14 rtol=0
    @test solved.choice.data.mu_prime_gradient≈0 atol=1e-10 rtol=0
    @test solved.order==48
    @test collect(solved.quadrature_breaks)==collect(A.FREQUENCY_BREAKS)
    @test solved.functional_evaluations==1
    @test solved.retry_count==0
    @test_throws ArgumentError A.solve_filling(reference,lattice;mu_initial=0.,
        quadrature_breaks=(0.,1e-5,1e-7,1.))
end
