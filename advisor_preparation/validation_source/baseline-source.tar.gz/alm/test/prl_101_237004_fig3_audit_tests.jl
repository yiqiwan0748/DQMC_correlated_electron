using Test, LinearAlgebra
include(joinpath(@__DIR__,"..","scripts","audit_prl_101_237004_fig3.jl"))
const Fig3Audit=PRL101237004Fig3Audit

@testset "PRL Fig3 independent pole and density audit" begin
    A=Fig3Audit
    # Unequal positive residues and one peak outside the finite plotting
    # window distinguish missing Lorentzian tails from quadrature error.
    poles=[-4.2,-.37,.11,1.3]
    weights=[.2,.3,.8,.7]
    eta=.05
    exact=A.window_weight(poles,weights,-3.,3.,eta)
    coarse=collect(-3.:.01:3.);fine=collect(-3.:.005:3.)
    error_coarse=abs(A.trapz(coarse,A.lorentzian(poles,weights,coarse,eta))-exact)
    error_fine=abs(A.trapz(fine,A.lorentzian(poles,weights,fine,eta))-exact)
    @test sum(weights)-exact>.2
    @test error_fine<error_coarse
    @test error_fine<2e-8 # smooth eta=.05 Lorentzian endpoint quadrature
    @test A.window_weight(poles,weights,-Inf,Inf,eta)≈2 atol=1e-14 rtol=0
    amplitude=ComplexF64[1/sqrt(2) im/sqrt(2);1/sqrt(2) -im/sqrt(2)]
    energies=[-.7,.3];z=.11+.05im
    @test A.pole_green(amplitude,energies,z)≈inv(z*I-amplitude*Diagonal(energies)*amplitude') atol=1e-13 rtol=1e-13
    @test minimum(eigvals(Hermitian((A.pole_green(amplitude,energies,z)'-A.pole_green(amplitude,energies,z))/(2im*pi))))>0
    # U0 exact Bloch embedding supplies an independent density oracle over a
    # small finite lattice. Choose mu within a gap rather than at a shell.
    c=A.R.G.rectangular_cluster();p=A.R.G.Model.slater_koster_parameters(-.2)
    K=A.R.G.open_kinetic(c,p)
    green(z,spin)=begin g=inv(z*I-K);(g,-g*g) end
    ref=(nsites=4,kinetics=(K,K),green=green)
    levels=sort(vcat([eigvals(Hermitian(A.R.G.lattice_kinetic(c,k...,p)))
        for k in A.R.G.reduced_momentum_grid(c,8)]...))
    gaps=findall(diff(levels).>1e-5)
    gap=gaps[argmin(abs.(gaps.-length(levels)/2))]
    mu=(levels[gap]+levels[gap+1])/2
    problem=A.S.SpectralProblem(ref,c,p;mu,mu_prime=.13)
    exact_density=2gap/(8^2)
    @test A.imaginary_density(problem;physical_L=8,order=24)≈exact_density atol=3e-9 rtol=0
    # Common-shift perturbations retain occupation while inside this gap.
    @test A.imaginary_density(problem;physical_L=8,order=24,common_shift=1e-7)≈exact_density atol=3e-9 rtol=0
    data=(;problem,state=nothing)
    selected=A.auxiliary(data,(.31,.23),1)
    @test sum(selected.weights)≈2 atol=2e-13 rtol=0
    @test norm(selected.zeroth-I)<2e-13
    @test A.pole_green(selected.projected,selected.poles,z)≈A.S.periodized_green(problem,.31,.23,z) atol=2e-11 rtol=2e-11
    # The real campaign loader must not require a unique half-filled ground
    # state of the auxiliary free open cluster: its self-energy is zero.
    mktempdir() do temporary
        loaded=A.D.load_case(first(A.D.CASES);output=temporary)
        @test loaded.state===nothing
        @test loaded.problem.mu==loaded.meta["mu"]
        @test A.S.embedded_green(loaded.problem,.31,.23,z)≈
            inv((z+loaded.problem.mu)*I-A.S.G.lattice_kinetic(loaded.problem.cluster,.31,.23,loaded.problem.parameters)) atol=2e-12 rtol=2e-12
    end
end
