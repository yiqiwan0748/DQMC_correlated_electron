module PRL101237004GeometryTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_geometry.jl"))
using .PRL101237004Geometry
const Geometry = PRL101237004Geometry

# These tests compare short sums and products of O(1) hopping amplitudes.
# 2e-12 covers Float64 trigonometric phases and accumulated roundoff while
# remaining far below the hopping differences and exact fermion signs tested.
const ATOL = 2e-12

function small_basis(nmodes, Nup, Ndown)
    # This independent fixture is deliberately restricted to tiny sectors.
    nmodes <= 16 || throw(ArgumentError("test fixture supports at most 16 modes"))
    masks(number) = UInt64[
        state for state in UInt64(0):((UInt64(1) << nmodes) - UInt64(1))
        if count_ones(state) == number
    ]
    states = UInt64[up | (down << nmodes) for down in masks(Ndown) for up in masks(Nup)]
    return (; nmodes, Nup, Ndown, states,
            indices=Dict(state => index for (index, state) in enumerate(states)))
end

function repeated_action(action, vector, power)
    result = copy(vector)
    for _ in 1:power
        result = apply_symmetry(action, result)
    end
    return result
end

# Independent second-quantized one-body action, using elementary removal and
# insertion parity rather than the permutation algorithm under test.
function quadratic_action(kinetic, basis, vector)
    result = zeros(promote_type(eltype(kinetic), eltype(vector)), length(vector))
    for (index, state) in enumerate(basis.states), spin_offset in (0, basis.nmodes)
        for source in 1:basis.nmodes
            source_bit = UInt64(1) << (spin_offset + source - 1)
            iszero(state & source_bit) && continue
            removed = state ⊻ source_bit
            removal_sign = isodd(count_ones(state & (source_bit - UInt64(1)))) ? -1 : 1
            for destination in 1:basis.nmodes
                iszero(kinetic[destination, source]) && continue
                destination_bit = UInt64(1) << (spin_offset + destination - 1)
                iszero(removed & destination_bit) || continue
                sign = isodd(count_ones(removed & (destination_bit - UInt64(1)))) ?
                    -removal_sign : removal_sign
                output = removed | destination_bit
                result[basis.indices[output]] +=
                    kinetic[destination, source] * sign * vector[index]
            end
        end
    end
    return result
end

@testset "PRL finite geometry preserves literal Eq. (1)" begin
    square = periodic_square_torus()
    tilted = standard_eight_site_torus()
    @test (square.a1, square.a2, square.ncells) == ((2, 0), (0, 2), 4)
    @test (tilted.a1, tilted.a2, tilted.ncells) == ((2, 2), (-2, 2), 8)
    @test has_c4_symmetry(square)
    @test has_c4_symmetry(tilted)
    for torus in (square, tilted), parameters in (
        Geometry.PRLModel.slater_koster_parameters(),
        Geometry.PRLModel.raghu_parameters(),
    )
        kinetic = paper_kinetic_matrix(torus, parameters)
        @test issymmetric(kinetic)
        @test eltype(kinetic) == Float64
        for (kx, ky) in allowed_torus_momenta(torus)
            projected = torus_fourier_block(kinetic, torus, kx, ky)
            expected = Geometry.PRLModel.paper_bloch_hamiltonian(kx, ky, parameters)
            @test isapprox(projected, expected; atol=ATOL, rtol=0)
        end
        expected_energies = sort(vcat([
            collect(Geometry.PRLModel.paper_band_energies(kx, ky, parameters))
            for (kx, ky) in allowed_torus_momenta(torus)
        ]...))
        @test isapprox(eigvals(Symmetric(kinetic)), expected_energies; atol=ATOL, rtol=0)
    end

    # Separate periodic images give doubled axial and quadrupled diagonal
    # hopping on the four-site square; interorbital diagonal paths cancel.
    p = Geometry.PRLModel.slater_koster_parameters()
    kinetic = paper_kinetic_matrix(square, p)
    site(r) = Geometry.TorusED._site_index(square, r)
    mode(r, orbital) = 2(site(r) - 1) + orbital
    @test kinetic[mode((0, 0), 1), mode((1, 0), 1)] == -2p.t1
    @test kinetic[mode((0, 0), 1), mode((0, 1), 1)] == -2p.t2
    @test kinetic[mode((0, 0), 1), mode((1, 1), 1)] == -4p.t3
    @test all(iszero, kinetic[1:2:end, 2:2:end])
    projected = torus_fourier_block(paper_kinetic_matrix(tilted, p), tilted, pi / 2, pi / 2)
    @test isapprox(projected[1, 2], 4p.t4; atol=ATOL, rtol=0)
    @test !isapprox(projected[1, 2], -4p.t4; atol=ATOL, rtol=0)

    # Accept parameter containers from the independently namespaced solver and
    # retain generic real arithmetic through the paper-to-repository mapping.
    float32 = (t1=Float32(1), t2=Float32(2), t3=Float32(3), t4=Float32(4))
    @test eltype(paper_kinetic_matrix(square, float32)) == Float32
end

@testset "Fermionic translations and orbital C4 signs" begin
    square = periodic_square_torus()
    for torus in (square, standard_eight_site_torus())
        length_x = torus.ncells == 4 ? 2 : 4
        for (Nup, Ndown) in ((0, 0), (1, 0), (2, 0), (1, 1), (2, 1))
            basis = small_basis(2torus.ncells, Nup, Ndown)
            vector = [complex(sin(i), cos(2i)) for i in eachindex(basis.states)]
            tx = symmetry_action(basis, torus)
            ty = symmetry_action(basis, torus; displacement=(0, 1))
            c4 = symmetry_action(basis, torus; kind=:c4)
            @test sort(tx.destination_indices) == collect(eachindex(vector))
            @test all(sign -> sign in (-1, 1), c4.signs)
            @test repeated_action(tx, vector, length_x) == vector
            @test repeated_action(ty, vector, length_x) == vector
            @test repeated_action(c4, vector, 4) == vector
            @test apply_symmetry(tx, apply_symmetry(ty, vector)) ==
                  apply_symmetry(ty, apply_symmetry(tx, vector))
            @test apply_symmetry(c4, apply_symmetry(tx, repeated_action(c4, vector, 3))) ==
                  apply_symmetry(ty, vector)
            for displacement in (torus.a1, torus.a2)
                @test apply_symmetry(symmetry_action(basis, torus; displacement), vector) == vector
            end
            kinetic = paper_kinetic_matrix(torus)
            kinetic_vector = quadratic_action(kinetic, basis, vector)
            for action in (tx, ty, c4)
                @test isapprox(
                    quadratic_action(kinetic, basis, apply_symmetry(action, vector)),
                    apply_symmetry(action, kinetic_vector); atol=ATOL, rtol=0,
                )
            end
        end
    end

    origin = Geometry.TorusED._site_index(square, (0, 0))
    neighbor = Geometry.TorusED._site_index(square, (1, 0))
    occupied_xz = (UInt64(1) << (2(origin - 1))) | (UInt64(1) << (2(neighbor - 1)))
    two_up = small_basis(8, 2, 0)
    tx = symmetry_action(two_up, square)
    source = two_up.indices[occupied_xz]
    @test tx.destination_indices[source] == source
    @test tx.signs[source] == -1 # A two-fermion exchange must carry parity.

    one_up = small_basis(8, 1, 0)
    c4 = symmetry_action(one_up, square; kind=:c4)
    xz = one_up.indices[UInt64(1) << (2(origin - 1))]
    yz = one_up.indices[UInt64(1) << (2(origin - 1) + 1)]
    @test c4.destination_indices[xz] == yz
    @test c4.destination_indices[yz] == xz
    @test (c4.signs[xz], c4.signs[yz]) == (1, -1)
    @test_throws ArgumentError symmetry_action(one_up, square; kind=:reflection)
    @test_throws ArgumentError symmetry_action(one_up, square; displacement=(0.5, 0))
    @test_throws ArgumentError symmetry_action(one_up, square; max_basis_states=1)
    @test_throws DimensionMismatch apply_symmetry(c4, zeros(2))
    rectangle = Geometry.TorusED.tilted_torus((2, 0), (0, 3))
    @test_throws ArgumentError symmetry_action(small_basis(12, 1, 0), rectangle; kind=:c4)
    @test_throws DimensionMismatch symmetry_action(one_up, rectangle)
    incomplete = (; one_up..., states=one_up.states[1:1], indices=Dict(one_up.states[1] => 1))
    @test_throws ArgumentError symmetry_action(incomplete, square)
end

@testset "Small-sector momentum projectors and exact character counts" begin
    for torus in (periodic_square_torus(), standard_eight_site_torus())
        basis = small_basis(2torus.ncells, 1, 1)
        vector = [complex(sin(i), cos(2i)) for i in eachindex(basis.states)]
        restored = zeros(ComplexF64, length(vector))
        tx = symmetry_action(basis, torus)
        ty = symmetry_action(basis, torus; displacement=(0, 1))
        estimate = Geometry.TorusED.sector_resource_estimate(torus; N=2, Nup=1, Ndown=1)
        actions = [symmetry_action(basis, torus; displacement) for displacement in torus.cells]
        traces = [sum((action.destination_indices[i] == i ? action.signs[i] : 0)
                      for i in eachindex(basis.states)) for action in actions]
        for (block_index, (kx, ky)) in enumerate(allowed_torus_momenta(torus))
            projected = apply_momentum_projector(basis, torus, vector, kx, ky)
            restored .+= projected
            @test isapprox(apply_momentum_projector(basis, torus, projected, kx, ky),
                           projected; atol=ATOL, rtol=0)
            @test isapprox(apply_symmetry(tx, projected), cis(-kx) .* projected; atol=ATOL, rtol=0)
            @test isapprox(apply_symmetry(ty, projected), cis(-ky) .* projected; atol=ATOL, rtol=0)
            dimension = sum(cis(kx * d[1] + ky * d[2]) * trace
                            for (d, trace) in zip(torus.cells, traces)) / torus.ncells
            @test isapprox(dimension,
                estimate.momentum_blocks[block_index].fixed_Nup_Ndown_dimension;
                atol=ATOL, rtol=0)
        end
        @test isapprox(restored, vector; atol=ATOL, rtol=0)
        @test_throws ArgumentError apply_momentum_projector(basis, torus, vector, 0.1, 0.2)
    end
end

@testset "PRL target-sector resource audit never enumerates large bases" begin
    estimates = resource_estimates()
    @test length(estimates) == 4
    half = estimates[1]
    @test (half.N, half.Nup, half.Ndown) == (16, 8, 8)
    @test half.full_dimension == big(165_636_900)
    @test half.largest_momentum_dimension == big(20_706_468)
    @test [(entry.N, entry.Nup, entry.Ndown, entry.Sz) for entry in estimates] ==
          [(16, 8, 8, 0), (18, 9, 9, 0), (18, 10, 8, 1), (18, 11, 7, 2)]
    for entry in estimates
        @test entry.full_dimension == binomial(big(16), entry.Nup) * binomial(big(16), entry.Ndown)
        @test sum(block.fixed_Nup_Ndown_dimension for block in entry.momentum_blocks) == entry.full_dimension
        @test entry.full_vector_bytes == 8entry.full_dimension
        @test entry.reduced_vector_bytes == 8entry.largest_momentum_dimension
        @test entry.full_three_vector_bytes == 3entry.full_vector_bytes
        @test entry.reduced_three_vector_bytes == 3entry.reduced_vector_bytes
        @test entry.full_128_vector_bytes == 128entry.full_vector_bytes
        @test entry.reduced_128_vector_bytes == 128entry.reduced_vector_bytes
        @test entry.full_dense_bytes == 8entry.full_dimension^2
        @test entry.reduced_dense_bytes == 8entry.largest_momentum_dimension^2
        @test !entry.symmetry_reduced_solver_available
    end
    @test_throws ArgumentError resource_estimates(periodic_square_torus())
end

end # module
