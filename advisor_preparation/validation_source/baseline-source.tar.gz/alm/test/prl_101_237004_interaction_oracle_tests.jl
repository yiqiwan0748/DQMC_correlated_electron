module PRL101237004InteractionOracleTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_ed.jl"))
using .PRL101237004ED

# Full Fock spaces here have dimension at most 256 and order-one coefficients.
# 1e-12 admits accumulated Float64 matrix-product/eigensolver roundoff while
# resolving every sign and factor in Eq. (2), including terms linear in density.
const ORACLE_ATOL = 1.0e-12
const ORACLE_RTOL = 1.0e-12

# Independent Jordan-Wigner construction: no production basis generator,
# fermionic sign routine, interaction expansion, or hopping helper is reused.
# The rightmost tensor factor is mode 1 (the lowest integer-state bit).
# Modes are (1x up,1y up,2x up,2y up,...,1x down,1y down,...).
function tensor_fermions(nsites)
    nmodes = 4nsites
    local_annihilation = [0.0 1.0; 0.0 0.0]
    parity = [1.0 0.0; 0.0 -1.0]
    identity2 = Matrix{Float64}(I, 2, 2)
    annihilation = Matrix{Float64}[]
    for mode in 1:nmodes
        factors = [other == mode ? local_annihilation :
                   other < mode ? parity : identity2 for other in nmodes:-1:1]
        push!(annihilation, reduce(kron, factors))
    end
    number = [c' * c for c in annihilation]
    norbitals = 2nsites
    spin_plus = [annihilation[a]' * annihilation[a + norbitals]
                 for a in 1:norbitals]
    spin_z = [(number[a] - number[a + norbitals]) / 2 for a in 1:norbitals]
    total_plus = sum(spin_plus)
    total_z = sum(spin_z)
    spin_squared = total_z * total_z +
                   (total_plus * total_plus' + total_plus' * total_plus) / 2
    return (; annihilation, number, spin_plus, spin_z, spin_squared,
            nup=sum(number[1:norbitals]), ndown=sum(number[norbitals + 1:end]))
end

# Literal printed Eq. (2), with Sx.Sy written using Sz and S+/S-.
# In particular, this does not reuse its density/spin-flip bitwise expansion.
function literal_eq2(operators, U, J)
    (; annihilation, number, spin_plus, spin_z) = operators
    norbitals = length(annihilation) ÷ 2
    result = zeros(size(first(number)))
    Uprime = U - 2J
    for x in 1:2:norbitals
        y = x + 1
        nx = number[x] + number[x + norbitals]
        ny = number[y] + number[y + norbitals]
        result += U * (number[x] * number[x + norbitals] +
                       number[y] * number[y + norbitals])
        result += (Uprime - J / 2) * (nx * ny)
        spin_dot = spin_z[x] * spin_z[y] +
                   (spin_plus[x] * spin_plus[y]' +
                    spin_plus[x]' * spin_plus[y]) / 2
        result -= 2J * spin_dot
        pair_transfer = annihilation[x]' * annihilation[x + norbitals]' *
                        annihilation[y + norbitals] * annihilation[y]
        result += J * (pair_transfer + pair_transfer')
    end
    return result
end

function literal_kinetic(operators, K)
    norbitals = size(K, 1)
    result = zeros(size(first(operators.number)))
    for spin_offset in (0, norbitals), a in 1:norbitals, b in 1:norbitals
        result += K[a, b] * (operators.annihilation[a + spin_offset]' *
                             operators.annihilation[b + spin_offset])
    end
    return result
end

# Compare every fixed-(Nup,Ndown) block and reconstruct the full production
# operator in tensor order. Counting occupancy below is solely a basis-coverage
# check, not an oracle implementation of matrix elements or fermionic signs.
function compare_every_sector(K, U, J, expected)
    norbitals = size(K, 1)
    dimension = size(expected, 1)
    actual_full = zeros(dimension, dimension)
    coverage = zeros(Int, dimension)
    for nup in 0:norbitals, ndown in 0:norbitals
        h = sector_hamiltonian(K, U, nup, ndown; J)
        indices = Int.(h.basis.states) .+ 1
        @test length(indices) == binomial(norbitals, nup) * binomial(norbitals, ndown)
        @test length(unique(indices)) == length(indices)
        low_mask = (UInt64(1) << norbitals) - UInt64(1)
        @test all(count_ones(state & low_mask) == nup &&
                  count_ones(state >> norbitals) == ndown for state in h.basis.states)
        actual = Matrix(h)
        @test isapprox(actual, expected[indices, indices];
                       atol=ORACLE_ATOL, rtol=ORACLE_RTOL)
        @test isapprox(actual, actual'; atol=ORACLE_ATOL, rtol=0.0)
        actual_full[indices, indices] = actual
        coverage[indices] .+= 1
    end
    @test all(==(1), coverage)
    @test isapprox(actual_full, expected; atol=ORACLE_ATOL, rtol=ORACLE_RTOL)
    return actual_full
end

@testset "PRL Eq. (2): independent tensor-operator oracle" begin
    @testset "All one- and two-Fe sectors, hopping and full interaction" begin
        for nsites in (1, 2)
            operators = tensor_fermions(nsites)
            # Distinct diagonal terms and nonzero intra/interorbital hopping
            # prevent conservation tests from succeeding on a diagonal model.
            K = nsites == 1 ? [0.13 -0.29; -0.29 -0.17] :
                [0.13 -0.29 0.31 -0.11;
                 -0.29 -0.17 0.23 0.19;
                 0.31 0.23 0.07 -0.37;
                 -0.11 0.19 -0.37 -0.03]
            kinetic = literal_kinetic(operators, K)
            identity_full = Matrix{Float64}(I, size(kinetic)...)
            # Check the tensor convention's canonical anticommutators before
            # using it as the independent scientific reference.
            for a in eachindex(operators.annihilation)
                c = operators.annihilation[a]
                @test c * c' + c' * c == identity_full
                b = mod1(a + 1, length(operators.annihilation))
                d = operators.annihilation[b]
                @test iszero(c * d' + d' * c)
                @test iszero(c * d + d * c)
            end
            # The second ratio tests U'=U-2J beyond the paper's special U/4.
            for (U, J) in ((1.7, 1.7 / 4), (1.1, 0.17), (0.0, 0.0))
                expected = kinetic + literal_eq2(operators, U, J)
                actual = compare_every_sector(K, U, J, expected)
                for conserved in (operators.nup, operators.ndown, operators.spin_squared)
                    @test isapprox(actual * conserved, conserved * actual;
                                   atol=ORACLE_ATOL, rtol=ORACLE_RTOL)
                end
            end
        end
    end

    @testset "Atomic signs, energies, degeneracies, and physical total spin" begin
        operators = tensor_fermions(1)
        U, J = 1.7, 1.7 / 4
        expected = literal_eq2(operators, U, J)
        actual = compare_every_sector(zeros(2, 2), U, J, expected)

        # Fock order is x-up,y-up,x-down,y-down. The matrix element for
        # exchange is +J: the operator's -J carries another fermionic minus.
        # Checking eigenvalues alone could not distinguish the wrong sign.
        @test isapprox(actual[5 + 1, 10 + 1], J; atol=ORACLE_ATOL, rtol=0.0)
        @test isapprox(actual[9 + 1, 6 + 1], J; atol=ORACLE_ATOL, rtol=0.0)
        @test isapprox(actual[3 + 1, 3 + 1], U - 3J;
                       atol=ORACLE_ATOL, rtol=0.0)
        @test isapprox(actual[9 + 1, 9 + 1], U - 2J;
                       atol=ORACLE_ATOL, rtol=0.0)

        expected_energies = (
            [0.0], zeros(4), [U - 3J, U - 3J, U - 3J, U - J, U - J, U + J],
            fill(3U - 5J, 4), [6U - 10J],
        )
        for nelectrons in 0:4
            indices = [state + 1 for state in 0:15 if count_ones(state) == nelectrons]
            @test isapprox(eigvals(Symmetric(actual[indices, indices])),
                           expected_energies[nelectrons + 1];
                           atol=ORACLE_ATOL, rtol=ORACLE_RTOL)
        end
        two_electron_indices = [state + 1 for state in 0:15 if count_ones(state) == 2]
        eigensystem = eigen(Symmetric(actual[two_electron_indices, two_electron_indices]))
        s2 = operators.spin_squared[two_electron_indices, two_electron_indices]
        @test isapprox(eigensystem.vectors' * s2 * eigensystem.vectors,
                       Diagonal([2.0, 2.0, 2.0, 0.0, 0.0, 0.0]);
                       atol=ORACLE_ATOL, rtol=ORACLE_RTOL)
    end

    @testset "J=0 has full SU(4) repulsion and unshifted printed energies" begin
        U = 1.3
        for nsites in (1, 2)
            operators = tensor_fermions(nsites)
            dimension = size(first(operators.number), 1)
            identity_full = Matrix{Float64}(I, dimension, dimension)
            expected = zeros(dimension, dimension)
            norbitals = 2nsites
            for x in 1:2:norbitals
                nsite = operators.number[x] + operators.number[x + 1] +
                        operators.number[x + norbitals] +
                        operators.number[x + 1 + norbitals]
                expected += U / 2 * nsite * (nsite - identity_full)
            end
            actual = compare_every_sector(zeros(norbitals, norbitals), U, 0.0, expected)
            # A centered intraorbital Hubbard interaction has vacuum constants
            # and misses this interorbital same-spin repulsion.
            @test actual[1, 1] == 0.0
            @test actual[2, 2] == 0.0
            @test isapprox(actual[3 + 1, 3 + 1], U; atol=ORACLE_ATOL, rtol=0.0)
        end
    end
end

end
