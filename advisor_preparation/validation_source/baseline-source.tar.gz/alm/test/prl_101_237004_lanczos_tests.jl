module PRL101237004LanczosTests

using LinearAlgebra
using Random
using Test
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_lanczos.jl"))
using .PRL101237004Lanczos

@testset "PRL small-sector Lanczos" begin
    # Independent dense references, including a degenerate eigenspace. The
    # solver returns an energy/vector only, not a claim of manifold recovery.
    rng = MersenneTwister(42)
    x = randn(rng, 31, 31)
    cases = (Symmetric(x + x'), Diagonal([-2., -2., 0., 1., 5.]),
        Diagonal(fill(0.25, 7)), reshape([3.0], 1, 1))
    for H in cases, seed in (7, 29)
        result = lowest_lanczos(H; seed=seed, maxiter=size(H, 1), atol=1e-11, rtol=1e-12)
        # The energy tolerance covers dense and iterative solver roundoff;
        # the original-operator residual is the primary convergence criterion.
        @test isapprox(result.energy, eigmin(H); atol=1e-10, rtol=1e-12)
        @test result.residual <= result.threshold
        @test isapprox(norm(result.vector), 1; atol=1e-12, rtol=0)
        @test result.converged
        @test !result.ground_manifold_resolved
    end
    H = Symmetric(x + x')
    @test_throws ErrorException lowest_lanczos(H; maxiter=1)
    @test !lowest_lanczos(H; maxiter=1, require_convergence=false).converged
    @test_throws ArgumentError lowest_lanczos(H; max_bytes=1)
    @test_throws ArgumentError lowest_lanczos(H; maxiter=0)
    @test_throws ArgumentError lowest_lanczos(H; atol=NaN)
    @test_throws ArgumentError lowest_lanczos(H; rtol=-1)
    @test_throws ArgumentError lowest_lanczos(zeros(2, 3))
    @test_throws ArgumentError lowest_lanczos(zeros(0, 0))
end

end
