module PRL101237004Milestone2Tests

using LinearAlgebra
using Test
include(joinpath(@__DIR__, "..", "scripts", "run_prl_101_237004_milestone2.jl"))
const M = PRL101237004Milestone2

@testset "PRL milestone 2 validation workflow" begin
    @testset "Complete dense ground manifold" begin
        H = Diagonal([-1., -1., 2., 4.])
        result = M.dense_low_spectrum(H; low_states=3)
        @test result.multiplicity == 2
        @test isapprox(result.gap, 3.; atol=1e-12, rtol=0)
        @test norm(result.ground_vectors' * result.ground_vectors - I) <= 1e-12
        @test maximum(result.residuals) <= 1e-12
        @test_throws ErrorException M.dense_low_spectrum(H; low_states=2)
        @test_throws ArgumentError M.dense_low_spectrum(H; max_bytes=1)
        @test_throws ArgumentError M.dense_low_spectrum(H; degeneracy_atol=-1)
        flat = M.dense_low_spectrum(Diagonal(zeros(3)); low_states=3)
        @test flat.multiplicity == 3
        @test isinf(flat.gap)
    end
    @testset "Atomic and finite-cluster cross-validation" begin
        atoms = M.atomic_validation()
        @test length(atoms) == 32
        @test maximum(row.absolute_error for row in atoms) <= 1e-12
        cluster = M.cluster_validation("test_square_N2", M.Geometry.periodic_square_torus(), 1., 1, 1)
        @test cluster.dimension == 64
        @test all(row.energy_error <= 1e-9 for row in cluster.lanczos)
        @test all(row.residual <= 1e-10 for row in cluster.lanczos)
        @test all(row.commutator_error <= 1e-11 for row in cluster.symmetry.spatial)
        @test all(row.leakage <= 1e-8 for row in cluster.symmetry.spatial)
        # The two-electron atom's ground state is a triplet at J>0. Use the
        # full Sz=0 ground space and the physical S+ normalization.
        atom = M.ED.sector_hamiltonian(zeros(2, 2), 1., 1, 1)
        dense = M.dense_low_spectrum(atom)
        raised = M.raised_spin_vectors(atom.basis, dense.ground_vectors)
        @test isapprox(only(raised' * raised), 2.; atol=1e-12, rtol=0)
    end
    @testset "Preserve existing output" begin
        mktempdir() do directory
            path = joinpath(directory, "keep.txt")
            write(path, "original")
            @test_throws ErrorException M.main(["--output-dir=$directory"])
            @test read(path, String) == "original"
        end
        @test_throws ArgumentError M.main(["--unknown-option"])
    end
end

end
