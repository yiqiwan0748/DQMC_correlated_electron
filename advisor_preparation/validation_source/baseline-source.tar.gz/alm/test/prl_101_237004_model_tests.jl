module PRL101237004ModelTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_model.jl"))
using .PRL101237004Model

# Float64 comparisons allow trigonometric/Fourier-sum/eigensolver roundoff at
# order-one hopping scales; 1e-12 is far below the paper's printed precision.
const PRL_ATOL = 1.0e-12
const PRL_RTOL = 1.0e-12

# An independent literal Fourier transform of Eq. (1)'s bond terms. This
# intentionally does not call the repository's kinetic or Bloch constructors.
function literal_eq1_fourier(kx, ky, p)
    blocks = (
        ((1, 0), [-p.t1 0; 0 -p.t2]),
        ((0, 1), [-p.t2 0; 0 -p.t1]),
        ((1, 1), [-p.t3 -p.t4; -p.t4 -p.t3]),
        ((1, -1), [-p.t3 p.t4; p.t4 -p.t3]),
    )
    result = zeros(ComplexF64, 2, 2)
    for ((dx, dy), block) in blocks
        phase = cis(dx * kx + dy * ky)
        result .+= phase .* block .+ conj(phase) .* transpose(block)
    end
    return result
end

hopping_tuple(p) = (p.t1, p.t2, p.t3, p.t4)

@testset "PRL 101, 237004 noninteracting model" begin
    @testset "Slater-Koster printed coefficients" begin
        p = slater_koster_parameters()
        @test p isa PaperHoppingParameters{Float64}
        # Independently evaluated decimal polynomial values at ratio=-0.2.
        reference = (0.05800016, 0.21960416, -0.20828080, -0.07899972)
        @test isapprox(collect(hopping_tuple(p)), collect(reference);
                       atol=PRL_ATOL, rtol=PRL_RTOL)
        scaled = slater_koster_parameters(-0.2; energy_scale=3.0)
        @test isapprox(collect(hopping_tuple(scaled)), 3 .* collect(reference);
                       atol=PRL_ATOL, rtol=PRL_RTOL)
        p0 = slater_koster_parameters(0)
        @test isapprox(p0.t1, -2 * 0.263^2; atol=PRL_ATOL, rtol=PRL_RTOL)
        @test isapprox(p0.t2, 2 * 0.263^2; atol=PRL_ATOL, rtol=PRL_RTOL)
    end

    @testset "Literal Eq. (1), gauge, and symmetries" begin
        rotation = [0.0 -1.0; 1.0 0.0]
        orbital_gauge = Diagonal([1.0, -1.0])
        for p in (slater_koster_parameters(), raghu_parameters(),
                  PaperHoppingParameters(-0.8, 1.1, 0.4, -0.3))
            mapped = repository_parameters(p)
            @test hopping_tuple(mapped) == (p.t1, p.t2, p.t3, -p.t4)
            for (kx, ky) in ((0.37, -1.11), (-2.2, 0.73), (pi / 3, pi / 7),
                             (0.0, 0.0), (pi, 0.0), (pi, pi), (pi / 2, pi / 2))
                h = paper_bloch_hamiltonian(kx, ky, p)
                fourier = literal_eq1_fourier(kx, ky, p)
                @test issymmetric(h)
                @test eltype(h) <: Real
                @test isapprox(h, fourier; atol=PRL_ATOL, rtol=PRL_RTOL)
                @test maximum(abs, imag.(fourier)) <= PRL_ATOL
                @test isapprox(h[1, 2], 4 * p.t4 * sin(kx) * sin(ky);
                               atol=PRL_ATOL, rtol=PRL_RTOL)
                energies = paper_band_energies(kx, ky, p)
                @test issorted(energies)
                @test isapprox(energies, eigvals(Hermitian(fourier));
                               atol=PRL_ATOL, rtol=PRL_RTOL)
                @test isapprox(paper_bloch_hamiltonian(-ky, kx, p),
                               rotation * h * rotation'; atol=PRL_ATOL, rtol=PRL_RTOL)
                @test isapprox(paper_band_energies(-ky, kx, p), energies;
                               atol=PRL_ATOL, rtol=PRL_RTOL)
                @test isapprox(paper_bloch_hamiltonian(-kx, -ky, p), h;
                               atol=PRL_ATOL, rtol=PRL_RTOL)
                @test isapprox(paper_bloch_hamiltonian(kx + 2pi, ky, p), h;
                               atol=PRL_ATOL, rtol=PRL_RTOL)
                unchanged_t4 = PRL101237004Model.ValidatedBloch.ModelParameters(
                    p.t1, p.t2, p.t3, p.t4,
                )
                other_gauge = PRL101237004Model.ValidatedBloch.bloch_hamiltonian(
                    kx, ky, unchanged_t4,
                )
                @test isapprox(h, orbital_gauge * other_gauge * orbital_gauge;
                               atol=PRL_ATOL, rtol=PRL_RTOL)
            end
        end
    end

    @testset "Ref. [11] original Raghu matrix" begin
        p = raghu_parameters()
        @test hopping_tuple(p) == (-1.0, 1.3, -0.85, 0.85)
        @test hopping_tuple(repository_parameters(p)) == (-1.0, 1.3, -0.85, -0.85)
        for (kx, ky) in ((0.37, -1.11), (pi / 2, pi / 2), (pi, 0.0))
            ex = 2cos(kx) - 2.6cos(ky) + 3.4cos(kx) * cos(ky)
            ey = -2.6cos(kx) + 2cos(ky) + 3.4cos(kx) * cos(ky)
            exy = 3.4sin(kx) * sin(ky)
            @test isapprox(paper_bloch_hamiltonian(kx, ky, p), [ex exy; exy ey];
                           atol=PRL_ATOL, rtol=PRL_RTOL)
        end
        @test isapprox(paper_band_energies(pi, 0.0, p), [-8.0, 1.2];
                       atol=PRL_ATOL, rtol=PRL_RTOL)
        @test isapprox(collect(hopping_tuple(raghu_parameters(energy_scale=2))),
                       2 .* collect(hopping_tuple(p)); atol=PRL_ATOL, rtol=PRL_RTOL)
    end

    @testset "Arithmetic types" begin
        p32 = slater_koster_parameters(Float32(-0.2))
        @test p32 isa PaperHoppingParameters{Float32}
        @test repository_parameters(p32) isa
              PRL101237004Model.ValidatedBloch.ModelParameters{Float32}
        @test raghu_parameters(energy_scale=Float32(1)) isa PaperHoppingParameters{Float32}
        @test PaperHoppingParameters(Float32(1), 2, 3, 4) isa PaperHoppingParameters{Float32}
        h32 = paper_bloch_hamiltonian(Float32(0.37), Float32(-1.11), p32)
        e32 = paper_band_energies(Float32(0.37), Float32(-1.11), p32)
        @test eltype(h32) === Float32
        @test eltype(e32) === Float32
        # Float32 trigonometric and polynomial evaluation needs a few ulps;
        # 2e-6 comfortably covers them on the order-one energy scale.
        @test isapprox(h32, paper_bloch_hamiltonian(0.37, -1.11);
                       atol=2.0e-6, rtol=2.0e-6)
        setprecision(BigFloat, 256) do
            pbig = slater_koster_parameters(parse(BigFloat, "-0.2"))
            @test pbig isa PaperHoppingParameters{BigFloat}
            @test raghu_parameters(energy_scale=big"1") isa PaperHoppingParameters{BigFloat}
            # At 256 bits, 1e-60 admits accumulated roundoff while exposing
            # accidental Float64 rounding of the paper's decimal constants.
            exact_decimal = parse.(BigFloat,
                ("0.05800016", "0.21960416", "-0.20828080", "-0.07899972"))
            @test all(isapprox.(hopping_tuple(pbig), exact_decimal;
                                atol=big"1e-60", rtol=big"1e-60"))
            hbig = paper_bloch_hamiltonian(big"0.37", big"-1.11", pbig)
            ebig = paper_band_energies(big"0.37", big"-1.11", pbig)
            @test eltype(hbig) === BigFloat
            @test eltype(ebig) === BigFloat
            @test isapprox(sum(ebig), tr(hbig); atol=big"1e-60", rtol=big"1e-60")
            @test isapprox(prod(ebig), det(hbig); atol=big"1e-60", rtol=big"1e-60")
        end
    end

    @testset "Invalid numerical inputs" begin
        for invalid in (NaN, Inf, -Inf)
            @test_throws ArgumentError slater_koster_parameters(invalid)
            @test_throws ArgumentError PaperHoppingParameters(1, 2, 3, invalid)
            @test_throws ArgumentError paper_bloch_hamiltonian(invalid, 0.2)
            @test_throws ArgumentError paper_band_energies(0.2, invalid)
        end
        for invalid in (0, -1, NaN, Inf, -Inf)
            @test_throws ArgumentError slater_koster_parameters(energy_scale=invalid)
            @test_throws ArgumentError raghu_parameters(energy_scale=invalid)
        end
    end
end

end
