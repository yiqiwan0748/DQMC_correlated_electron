module PRL101237004MomentumBasisTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_momentum_basis.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_geometry.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_ed.jl"))
using .PRL101237004MomentumBasis
const B = PRL101237004MomentumBasis
const G = PRL101237004Geometry
const E = PRL101237004ED

# Group phases are exact fourth roots in the compact representation. Float64
# independent projectors evaluate sin/cos, so 3e-12 covers their roundoff and
# short dot products without hiding a wrong fermion sign or normalization.
const ATOL = 3e-12

function check_block(torus, nup, ndown, kx, ky)
    basis = build_momentum_basis(torus, nup, ndown, kx, ky)
    full = E.sector_basis(2torus.ncells, nup, ndown)
    @test size(basis.lookup) == (length(basis.down_masks), length(basis.up_reps))
    @test basis.row_offsets[end] == length(basis) + 1
    @test issorted(basis.up_reps)
    @test issorted(basis.row_offsets)
    @test all(g -> 1 <= g <= torus.ncells, basis.orbit_lengths)
    estimate = G.TorusED.sector_resource_estimate(torus; N=nup+ndown, Nup=nup, Ndown=ndown)
    which_momentum = findfirst(k -> k == (kx, ky), G.allowed_torus_momenta(torus))
    @test length(basis) == estimate.momentum_blocks[which_momentum].fixed_Nup_Ndown_dimension

    # Independent signed-permutation projector supplies all full-space
    # coefficients; no production canonicalizer or translation table is reused.
    arbitrary = ComplexF64[complex(sin(i), cos(2i)) for i in eachindex(full.states)]
    arbitrary ./= norm(arbitrary)
    projected = G.apply_momentum_projector(full, torus, arbitrary, kx, ky)
    reduced = zeros(ComplexF64, length(basis))
    for row in eachindex(reduced)
        up, down = representative(basis, row)
        full_row = full.indices[UInt64(up) | (UInt64(down) << basis.nmodes)]
        reduced[row] = projected[full_row] * sqrt(Float64(basis.orbit_lengths[row]))
        @test locate_code(basis, up, down) == (row, UInt8(0))
    end
    expanded = expand_momentum_vector(basis, reduced)
    @test isapprox(expanded, projected; atol=ATOL, rtol=0)
    @test isapprox(norm(expanded), norm(reduced); atol=ATOL, rtol=0)

    # Every raw mask pair must locate the coefficient with the conjugate phase:
    # <s|representative;k> = conj(phase(s -> representative))/sqrt(orbit_length).
    mask = (UInt64(1) << basis.nmodes) - UInt64(1)
    for (full_row, state) in enumerate(full.states)
        up, down = UInt16(state & mask), UInt16(state >> basis.nmodes)
        row, phase = locate(basis, up, down)
        expected = row == 0 ? 0.0im :
            conj(phase) * reduced[row] / sqrt(Float64(basis.orbit_lengths[row]))
        @test isapprox(projected[full_row], expected; atol=ATOL, rtol=0)
    end

    if !isempty(reduced)
        vector = ComplexF64[complex(sin(i), cos(3i)) for i in eachindex(reduced)]
        vector ./= norm(vector)
        expansion = expand_momentum_vector(basis, vector)
        @test isapprox(norm(expansion), 1; atol=ATOL, rtol=0)
        for displacement in ((1, 0), (0, 1))
            action = G.symmetry_action(full, torus; displacement)
            phase = cis(-(kx * displacement[1] + ky * displacement[2]))
            @test isapprox(G.apply_symmetry(action, expansion), phase .* expansion;
                           atol=ATOL, rtol=0)
        end
    end
    return basis
end

@testset "Factorized momentum basis matches independent Fock projectors" begin
    square = G.periodic_square_torus()
    for populations in ((0, 0), (1, 0), (2, 0), (1, 1), (2, 1), (2, 2), (7, 1), (8, 8))
        total = 0
        for (kx, ky) in G.allowed_torus_momenta(square)
            total += length(check_block(square, populations..., kx, ky))
        end
        @test total == binomial(8, populations[1]) * binomial(8, populations[2])
    end
    tilted = G.standard_eight_site_torus()
    for populations in ((1, 1), (2, 0), (2, 1))
        total = 0
        for (kx, ky) in G.allowed_torus_momenta(tilted)
            total += length(check_block(tilted, populations..., kx, ky))
        end
        @test total == binomial(16, populations[1]) * binomial(16, populations[2])
    end
end

@testset "Momentum-basis guards and signed stabilizers" begin
    square = G.periodic_square_torus()
    @test_throws ArgumentError build_momentum_basis(square, -1, 0, 0, 0)
    @test_throws ArgumentError build_momentum_basis(square, 9, 0, 0, 0)
    @test_throws ArgumentError build_momentum_basis(square, 0, 0, Inf, 0)
    @test_throws ArgumentError build_momentum_basis(square, 1, 1, 0.1, 0.2)
    @test_throws ArgumentError build_momentum_basis(square, 1, 1, 0, 0; max_bytes=0)
    @test_throws ArgumentError build_momentum_basis(square, 1, 1, 0, 0; max_bytes=1)
    @test_throws ArgumentError build_momentum_basis(G.TorusED.tilted_torus((3, 0), (0, 3)), 1, 1, 0, 0)
    @test_throws ArgumentError build_momentum_basis(G.TorusED.tilted_torus((3, 0), (0, 1)), 1, 1, 2pi/3, 0)
    basis = build_momentum_basis(square, 1, 1, 0, 0)
    @test_throws ArgumentError locate(basis, UInt16(0), UInt16(1))
    @test_throws ArgumentError locate(basis, UInt16(1), UInt16(0))
    @test_throws BoundsError representative(basis, 0)
    @test_throws BoundsError representative(basis, length(basis) + 1)
    @test_throws DimensionMismatch expand_momentum_vector(basis, zeros(length(basis) + 1))
    @test_throws ArgumentError expand_momentum_vector(basis, zeros(length(basis)); max_dimension=1)

    # Two up fermions exchanged by x translation produce a negative character;
    # one cannot retain their orbit merely because the bit pattern is periodic.
    site0 = G.TorusED._site_index(square, (0, 0))
    sitex = G.TorusED._site_index(square, (1, 0))
    up = (UInt16(1) << (2(site0 - 1))) | (UInt16(1) << (2(sitex - 1)))
    gamma = build_momentum_basis(square, 2, 0, 0, 0)
    xpoint = build_momentum_basis(square, 2, 0, pi, 0)
    @test first(locate_code(gamma, up, UInt16(0))) == 0
    @test first(locate_code(xpoint, up, UInt16(0))) > 0
end

end # module
