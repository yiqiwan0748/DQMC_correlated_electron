module PRL101237004MomentumObservablesTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_momentum_basis.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_momentum_observables.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_geometry.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_ed.jl"))
const B = PRL101237004MomentumBasis
const O = PRL101237004MomentumObservables
const G = PRL101237004Geometry
const E = PRL101237004ED

# Independent full Fock contractions and small Slater determinants accumulate
# Float64 roundoff. 2e-11 is well below a spin quantum or visible S(q) feature.
const ATOL = 2e-11

function full_spin_squared(full, vector)
    output = zeros(ComplexF64, length(vector))
    magnetization = (full.Nup - full.Ndown) / 2
    # S² = M(M+1) + S⁻S⁺, with both monomials explicitly applied in global
    # Fock order. This does not reuse the production diagonal or hop-sign rule.
    for (column, state) in enumerate(full.states)
        output[column] += magnetization * (magnetization + 1) * vector[column]
        for a in 1:full.nmodes, b in 1:full.nmodes
            transition = E.apply_fermion_ops(state, ((full.nmodes + b, false),
                (b, true), (a, false), (full.nmodes + a, true)))
            transition === nothing && continue
            final, sign = transition
            output[full.indices[final]] += sign * vector[column]
        end
    end
    return real(dot(vector, output)) / sum(abs2, vector)
end

function full_structure(full, torus, vector)
    values = zeros(Float64, length(torus.momenta))
    for (row, state) in enumerate(full.states), (q, (qx, qy)) in enumerate(torus.momenta)
        amplitude = 0.0 + 0.0im
        for (site, (x, y)) in enumerate(torus.cells), orbital in 1:2
            mode = 2(site - 1) + orbital - 1
            spin = (Int((state >> mode) & 1) - Int((state >> (full.nmodes + mode)) & 1)) / 2
            amplitude += cis(qx*x + qy*y) * spin
        end
        values[q] += abs2(vector[row]) * abs2(amplitude)
    end
    return values ./ sum(abs2, vector)
end

@testset "Reduced spin observables match full Fock contractions" begin
    for (torus, populations) in ((G.periodic_square_torus(), ((1, 1), (2, 1), (2, 2), (2, 0))),
                                  (G.standard_eight_site_torus(), ((1, 1), (2, 0))))
        for (nup, ndown) in populations, (kx, ky) in torus.momenta
            basis = B.build_momentum_basis(torus, nup, ndown, kx, ky)
            isempty(basis.orbit_lengths) && continue
            full = E.sector_basis(basis.nmodes, nup, ndown)
            vector = ComplexF64[complex(sin(i), cos(3i)) for i in eachindex(basis.orbit_lengths)]
            expanded = B.expand_momentum_vector(basis, vector)
            measured = O.spin_structure_factors(basis, vector)
            @test measured.momenta == torus.momenta
            @test isapprox(measured.norm_squared, sum(abs2, vector); atol=ATOL, rtol=0)
            @test isapprox(measured.szsz_raw, full_structure(full, torus, expanded); atol=ATOL, rtol=0)
            @test isapprox(measured.szsz_per_site * torus.ncells, measured.szsz_raw; atol=ATOL, rtol=0)
            @test isapprox(O.total_spin_squared(basis, vector), full_spin_squared(full, expanded); atol=ATOL, rtol=0)
            q0 = findfirst(==((0.0, 0.0)), torus.momenta)
            @test isapprox(measured.szsz_raw[q0], ((nup-ndown)/2)^2; atol=ATOL, rtol=0)
            if ndown == 0
                spin = nup / 2
                @test isapprox(O.total_spin_squared(basis, vector), spin*(spin+1); atol=ATOL, rtol=0)
            end
        end
    end
end

function full_slater(full, K)
    eigensystem = eigen(Symmetric(K))
    vector = Float64[]
    for state in full.states
        up = Int[a for a in 1:full.nmodes if !iszero((state >> (a - 1)) & 1)]
        down = Int[a for a in 1:full.nmodes if !iszero((state >> (full.nmodes + a - 1)) & 1)]
        up_det = isempty(up) ? 1.0 : det(eigensystem.vectors[up, 1:full.Nup])
        down_det = isempty(down) ? 1.0 : det(eigensystem.vectors[down, 1:full.Ndown])
        push!(vector, up_det * down_det)
    end
    return vector
end

@testset "Free Slater starts are normalized momentum projections" begin
    for (torus, populations) in ((G.periodic_square_torus(), ((0, 0), (1, 1), (2, 2), (3, 1))),
                                  (G.standard_eight_site_torus(), ((1, 1), (2, 0))))
        K = G.paper_kinetic_matrix(torus)
        for (nup, ndown) in populations
            full = E.sector_basis(2torus.ncells, nup, ndown)
            slater = full_slater(full, K)
            H = E.sector_hamiltonian(K, 0.0, nup, ndown)
            weight_sum = 0.0
            for (kx, ky) in torus.momenta
                basis = B.build_momentum_basis(torus, nup, ndown, kx, ky)
                projected = G.apply_momentum_projector(full, torus, slater, kx, ky)
                weight = sum(abs2, projected)
                if weight < 1e-24
                    @test_throws ArgumentError O.free_slater_start(basis, K)
                    continue
                end
                result = O.free_slater_start(basis, K)
                expanded = B.expand_momentum_vector(basis, result.vector)
                projected ./= sqrt(weight)
                @test isapprox(result.projection_weight, weight; atol=ATOL, rtol=0)
                @test isapprox(expanded, projected; atol=ATOL, rtol=0)
                @test isapprox(norm(result.vector), 1; atol=ATOL, rtol=0)
                @test norm(H * expanded - result.unprojected_energy * expanded) < ATOL
                if nup == ndown
                    @test isapprox(O.total_spin_squared(basis, result.vector), 0; atol=ATOL, rtol=0)
                end
                weight_sum += result.projection_weight
            end
            @test isapprox(weight_sum, 1; atol=ATOL, rtol=0)
        end
    end
end

@testset "Observable input validation" begin
    torus = G.periodic_square_torus()
    basis = B.build_momentum_basis(torus, 1, 1, 0, 0)
    n = length(basis.orbit_lengths)
    for observable in (O.spin_structure_factors, O.total_spin_squared)
        @test_throws DimensionMismatch observable(basis, zeros(n + 1))
        @test_throws ArgumentError observable(basis, zeros(n))
        @test_throws ArgumentError observable(basis, fill(NaN, n))
    end
    @test_throws DimensionMismatch O.free_slater_start(basis, zeros(2, 2))
    K = G.paper_kinetic_matrix(torus)
    K[1, 2] += 1
    @test_throws ArgumentError O.free_slater_start(basis, K)
end

end # module
