module PRL101237004MomentumOperatorTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_geometry.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_momentum_basis.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_momentum_operator.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_ed.jl"))
const G = PRL101237004Geometry
const B = PRL101237004MomentumBasis
const M = PRL101237004MomentumOperator
const E = PRL101237004ED

# The largest independent full Fock sector below has 4900 states, with
# order-one couplings and at most order-100 terms per row. These tolerances
# cover summation and projector roundoff while easily resolving a wrong
# orbit-length ratio, fourth-root phase, or Hund/pair-transfer sign.
const ACTION_ATOL = 1e-11
const ACTION_RTOL = 5e-13

function normalized_probe(n, shift=0; complex_values=true)
    n == 0 && return complex_values ? ComplexF64[] : Float64[]
    result = complex_values ?
        [complex(sin(0.71i + shift), cos(1.17i - 0.3shift)) for i in 1:n] :
        [sin(0.71i + shift) for i in 1:n]
    return result ./ norm(result)
end

function check_action(b, H, full; extra_probes=false)
    @test size(H) == (length(b), length(b))
    @test ishermitian(H)
    @test eltype(H) === (all(iseven, b.translation_phases) ? Float64 : ComplexF64)
    @test H.estimated_bytes >= b.estimated_bytes
    for shift in (extra_probes ? (0, 2, 5) : (0,))
        v = normalized_probe(length(b), shift)
        u = normalized_probe(length(b), shift + 3)
        hv = H * v
        hu = H * u
        expanded = B.expand_momentum_vector(b, v)
        expected = full * expanded
        @test isapprox(B.expand_momentum_vector(b, hv), expected;
                       atol=ACTION_ATOL, rtol=ACTION_RTOL)
        # This is an actual bilinear Hermiticity test, independent of the
        # operator's ishermitian declaration. Complex probes test both parts.
        @test isapprox(dot(u, hv), dot(hu, v);
                       atol=ACTION_ATOL, rtol=ACTION_RTOL)
        @test isapprox(dot(v, hv), dot(expanded, expected);
                       atol=ACTION_ATOL, rtol=ACTION_RTOL)
        alpha, beta = 0.31 + 0.27im, -0.4 + 0.19im
        output = copy(u)
        @test mul!(output, H, v, alpha, beta) === output
        @test isapprox(output, alpha .* hv .+ beta .* u;
                       atol=ACTION_ATOL, rtol=ACTION_RTOL)
        # beta=0 must not read uninitialized output (represented by NaNs).
        output .= complex(NaN, NaN)
        mul!(output, H, v)
        @test isapprox(output, hv; atol=ACTION_ATOL, rtol=ACTION_RTOL)
    end
    if eltype(H) === Float64
        v = normalized_probe(length(b), 4; complex_values=false)
        @test eltype(H * v) === Float64
        @test isapprox(B.expand_momentum_vector(b, H*v),
                       full * B.expand_momentum_vector(b, v);
                       atol=ACTION_ATOL, rtol=ACTION_RTOL)
    end
    return nothing
end

@testset "PRL momentum Hamiltonian independent full-Fock action oracle" begin
    @testset "Every 2x2 filling and momentum, including half filling" begin
        torus = G.periodic_square_torus()
        K = G.paper_kinetic_matrix(torus)
        for nup in 0:8, ndown in 0:8
            # U'=U-2J is deliberately away from J=U/4, so accidental
            # coefficient identities at the paper's fixed ratio cannot pass.
            full = E.sector_hamiltonian(K, 0.91, nup, ndown; J=0.17)
            total_dimension = 0
            for (kx, ky) in G.allowed_torus_momenta(torus)
                b = B.build_momentum_basis(torus, nup, ndown, kx, ky)
                H = M.momentum_hamiltonian(b, K, 0.91; J=0.17)
                check_action(b, H, full; extra_probes=(nup == ndown == 4))
                total_dimension += length(b)
            end
            @test total_dimension == length(full.basis.states)
        end
    end

    @testset "Tilted eight-site hopping and interactions in all momenta" begin
        torus = G.standard_eight_site_torus()
        K = G.paper_kinetic_matrix(torus)
        for (nup, ndown) in ((1, 1), (2, 1), (1, 2)), (U, J) in
                ((0.0, 0.0), (0.5, 0.125), (1.0, 0.25), (0.91, 0.17))
            full = E.sector_hamiltonian(K, U, nup, ndown; J)
            for (kx, ky) in G.allowed_torus_momenta(torus)
                b = B.build_momentum_basis(torus, nup, ndown, kx, ky)
                H = M.momentum_hamiltonian(b, K, U; J)
                check_action(b, H, full)
            end
        end
    end

    @testset "Independent atomic multiplet energies" begin
        # With zero hopping, two electrons on different sites have zero
        # interaction energy, while onsite states form exact Hund multiplets.
        # These expected eigenvalues do not use the full-ED implementation.
        torus = G.standard_eight_site_torus()
        U, J = 1.0, 0.19
        for (kx, ky) in G.allowed_torus_momenta(torus)
            b = B.build_momentum_basis(torus, 1, 1, kx, ky)
            H = M.momentum_hamiltonian(b, zeros(16,16), U; J)
            identity = Matrix{eltype(H)}(I, length(b), length(b))
            dense = hcat((H * identity[:,i] for i in 1:length(b))...)
            @test isapprox(dense, dense'; atol=ACTION_ATOL, rtol=ACTION_RTOL)
            @test isapprox(eigvals(Hermitian(dense)),
                           sort(vcat(zeros(28), [U-3J, U-J, U-J, U+J]));
                           atol=ACTION_ATOL, rtol=ACTION_RTOL)
        end
        # A one-site torus checks all local fillings, including vacuum/full.
        atom = G.TorusED.tilted_torus((1,0), (0,1))
        for N in 0:4
            observed = Float64[]
            expected = (zeros(1), zeros(4),
                        sort([U-3J, U-3J, U-3J, U-J, U-J, U+J]),
                        fill(3U-5J, 4), [6U-10J])[N+1]
            for nup in max(0,N-2):min(2,N)
                b = B.build_momentum_basis(atom, nup, N-nup, 0, 0)
                H = M.momentum_hamiltonian(b, zeros(2,2), U; J)
                identity = Matrix{Float64}(I, length(b), length(b))
                dense = hcat((H * identity[:,i] for i in 1:length(b))...)
                append!(observed, eigvals(Symmetric(dense)))
            end
            @test isapprox(sort(observed), expected;
                           atol=ACTION_ATOL, rtol=ACTION_RTOL)
        end
    end

    @testset "Uniform orbital potentials and onsite hybridization" begin
        for torus in (G.periodic_square_torus(), G.standard_eight_site_torus())
            K = G.paper_kinetic_matrix(torus)
            for site in 1:torus.ncells
                x, y = 2site - 1, 2site
                K[x,x], K[y,y] = 0.27, -0.14
                K[x,y] = K[y,x] = 0.23
            end
            for (nup, ndown) in ((2,1), (1,2))
                full = E.sector_hamiltonian(K, 1.3, nup, ndown; J=0.23)
                for (kx, ky) in G.allowed_torus_momenta(torus)
                    b = B.build_momentum_basis(torus, nup, ndown, kx, ky)
                    H = M.momentum_hamiltonian(b, K, 1.3; J=0.23)
                    check_action(b, H, full)
                end
            end
        end
    end

    @testset "Allocation, parameter, and multiplication guards" begin
        torus = G.standard_eight_site_torus()
        b = B.build_momentum_basis(torus, 1, 1, 0, 0)
        K = G.paper_kinetic_matrix(torus)
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, 1; max_bytes=1)
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, 1; max_bytes=0)
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, 1; max_bytes=-1)
        @test_throws DimensionMismatch M.momentum_hamiltonian(b, zeros(4,4), 1)
        @test_throws DimensionMismatch M.momentum_hamiltonian(b, zeros(16,15), 1)
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, Inf)
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, NaN)
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, 1; J=Inf)
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, 1; J=NaN)
        # Finite Real inputs must remain finite in the operator's Float64
        # representation; otherwise a formally valid operator silently has
        # Inf/NaN coefficients and spoils eigensolver convergence diagnostics.
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, big"1e500")
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, 1; J=big"1e500")
        hugeK = zeros(BigFloat,16,16)
        for mode in 1:16
            hugeK[mode,mode] = big"1e500"
        end
        @test_throws ArgumentError M.momentum_hamiltonian(b, hugeK, 1)
        @test_throws ArgumentError M.momentum_hamiltonian(b, K, 1; J=floatmax(Float64))
        bad = copy(K); bad[1,1] = Inf
        @test_throws ArgumentError M.momentum_hamiltonian(b, bad, 1)
        bad = copy(K); bad[1,2] += 0.03
        @test_throws ArgumentError M.momentum_hamiltonian(b, bad, 1)
        bad = copy(K); bad[1,1] += 0.03
        @test_throws ArgumentError M.momentum_hamiltonian(b, bad, 1)
        # A site-local impurity can be symmetric but still violates momentum.
        bad = copy(K); bad[1,2] += 0.03; bad[2,1] += 0.03
        @test_throws ArgumentError M.momentum_hamiltonian(b, bad, 1)
        H = M.momentum_hamiltonian(b, K, 1)
        v = normalized_probe(length(b))
        @test_throws DimensionMismatch H * v[1:end-1]
        @test_throws DimensionMismatch mul!(zeros(ComplexF64,length(b)+1), H, v)
        @test_throws ArgumentError mul!(v, H, v)
        backing = zeros(ComplexF64, length(b)+1)
        @test_throws ArgumentError mul!(view(backing,1:length(b)), H,
                                        view(backing,2:length(b)+1))
        cb = B.build_momentum_basis(torus, 1, 1, pi/2, pi/2)
        complexH = M.momentum_hamiltonian(cb, K, 1)
        @test_throws ArgumentError mul!(zeros(length(cb)), complexH, ones(length(cb)))
    end
end

end # module
