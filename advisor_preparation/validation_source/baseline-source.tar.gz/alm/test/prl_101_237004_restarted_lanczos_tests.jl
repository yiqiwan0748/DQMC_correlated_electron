using Test
using LinearAlgebra
using Random

if !isdefined(Main, :PRL101237004RestartedLanczos)
    include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_restarted_lanczos.jl"))
end
using .PRL101237004RestartedLanczos

# Deliberately does not define indexing or *. The production operator has a
# prohibitively large dense representation and must use only mul!.
struct RestartedLanczosTestOperator{T}
    matrix::Matrix{T}
    calls::Base.RefValue{Int}
end
Base.size(h::RestartedLanczosTestOperator) = size(h.matrix)
Base.eltype(::RestartedLanczosTestOperator{T}) where {T} = T
function LinearAlgebra.mul!(out, h::RestartedLanczosTestOperator, input)
    h.calls[] += 1
    mul!(out, h.matrix, input)
end

@testset "Memory-limited restarted Hermitian eigensolver" begin
    rng = MersenneTwister(104)
    # Dense eigenvalues are an independent oracle. 2e-9 absolute energy error
    # and 2e-8 residual allow accumulated restart/BLAS Float64 roundoff while
    # resolving the 2e-5 separation in the clustered example by three orders.
    for T in (Float64, ComplexF64)
        unitary = Matrix(qr(randn(rng, T, 36, 36)).Q)
        for spectrum in (vcat([-6.0, -4.0], collect(range(-1.0, 4.0; length=34))),
                         vcat([-6.0, -6.0], collect(range(-1.0, 4.0; length=34))),
                         vcat([-6.0, -6.0 + 2e-5], collect(range(-1.0, 4.0; length=34))))
            matrix = Matrix(Hermitian(unitary * Diagonal(spectrum) * unitary'))
            h = RestartedLanczosTestOperator(matrix, Ref(0))
            events = NamedTuple[]
            result = restarted_lowest(h; nev=2, krylovdim=9, keep=4,
                max_matvecs=300, atol=1e-9, rtol=1e-11, progress=info -> push!(events, info))
            @test result.converged
            @test result.restarts > 0
            @test result.matvecs == h.calls[] <= 300
            @test isapprox(result.values, eigvals(Hermitian(matrix))[1:2]; atol=2e-9, rtol=0)
            @test isapprox(result.vectors' * result.vectors, Matrix{T}(I, 2, 2); atol=2e-10, rtol=0)
            for root in 1:2
                residual = norm(matrix * result.vectors[:, root] -
                                result.values[root] * result.vectors[:, root])
                @test residual <= 2e-8
                @test isapprox(result.residuals[root], residual; atol=2e-13, rtol=1e-5)
            end
            @test events[end].converged
            @test events[end].residuals !== nothing
        end
    end

    # All-equal spectra cause exact block breakdown. Both independent members
    # of the repeated eigenspace must be returned with verified residuals.
    for n in (1, 2, 5)
        roots = min(n, 2)
        matrix = Matrix(3.0I, n, n)
        result = restarted_lowest(matrix; nev=roots, atol=1e-12)
        @test result.converged
        @test isapprox(result.values, fill(3.0, roots); atol=2e-13, rtol=0)
        @test maximum(result.residuals) < 1e-12
    end

    matrix = Matrix(Diagonal(collect(-2.0:1.0:27.0)))
    unfinished = restarted_lowest(matrix; nev=2, krylovdim=8, keep=3,
        max_matvecs=7, atol=1e-13, rtol=0)
    @test !unfinished.converged
    @test unfinished.matvecs <= 7
    @test all(isfinite, unfinished.residuals)
    @test maximum(unfinished.residuals) > 1e-5

    start = collect(1.0:30.0)
    warm = restarted_lowest(matrix; initial_vector=start, krylovdim=10,
        max_matvecs=300, atol=1e-9)
    @test warm.converged
    @test isapprox(only(warm.values), -2.0; atol=2e-9, rtol=0)
    @test start == collect(1.0:30.0) # Caller input is never overwritten.
    exact_starts = Matrix{Float64}(I, 30, 30)[:, 1:2]
    warm_block = restarted_lowest(matrix; nev=2, initial_vector=exact_starts,
        krylovdim=8, atol=1e-11)
    @test warm_block.converged
    @test isapprox(warm_block.values, [-2.0, -1.0]; atol=2e-11, rtol=0)

    mktempdir() do directory
        path = joinpath(directory, "run", "checkpoint.bin")
        cold = restarted_lowest(matrix; nev=2, krylovdim=10, keep=3,
            max_matvecs=18, atol=1e-10, checkpoint_path=path,
            checkpoint_every=1, checkpoint_metadata=(model_hash="test-model",))
        saved = read_lanczos_checkpoint(path)
        @test saved.format_version == 1
        @test saved.dimension == 30
        @test saved.scalar_type == "Float64"
        @test saved.metadata.model_hash == "test-model"
        @test saved.matvecs == cold.matvecs
        @test saved.values == cold.values
        @test saved.vectors == cold.vectors
        @test readdir(dirname(path)) == ["checkpoint.bin"]
        resumed = restarted_lowest(matrix; nev=2, krylovdim=10, keep=3,
            initial_vector=saved.vectors, max_matvecs=500, atol=1e-9)
        @test resumed.converged
        @test isapprox(resumed.values, [-2.0, -1.0]; atol=2e-9, rtol=0)
    end

    # A rejected budget must occur before even one matrix-vector application.
    counted = RestartedLanczosTestOperator(matrix, Ref(0))
    @test_throws ArgumentError restarted_lowest(counted; max_bytes=1)
    @test counted.calls[] == 0
    @test_throws ArgumentError restarted_lowest(zeros(2, 3))
    @test_throws ArgumentError restarted_lowest(zeros(0, 0))
    @test_throws ArgumentError restarted_lowest(matrix; nev=0)
    @test_throws ArgumentError restarted_lowest(matrix; nev=2, krylovdim=3)
    @test_throws ArgumentError restarted_lowest(matrix; nev=2, keep=1)
    @test_throws ArgumentError restarted_lowest(matrix; max_matvecs=1)
    @test_throws ArgumentError restarted_lowest(matrix; atol=NaN)
    @test_throws ArgumentError restarted_lowest(matrix; rtol=-1)
    @test_throws ArgumentError restarted_lowest(matrix; atol=0, rtol=0)
    @test_throws ArgumentError restarted_lowest(matrix; checkpoint_every=0)
    @test_throws ArgumentError restarted_lowest(matrix; initial_vector=zeros(30))
    @test_throws ArgumentError restarted_lowest(matrix; initial_vector=ones(29))
    @test_throws ArgumentError restarted_lowest(matrix; initial_vector=fill(NaN, 30))
    @test_throws ArgumentError restarted_lowest(matrix; nev=2, initial_vector=ones(30, 2))
end
