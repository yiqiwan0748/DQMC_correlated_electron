module PRL101237004SpectraTests

using Test, LinearAlgebra
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_spectra.jl"))
const S=PRL101237004Spectra
module ForeignGeometry
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_vca_geometry.jl"))
end
const G=ForeignGeometry.PRL101237004VCAGeometry
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_cluster_green.jl"))
const C=PRL101237004ClusterGreen

function free_reference(cluster,p;h=.037)
    n=2length(cluster.sites)
    K=G.open_kinetic(cluster,p)
    diagonal=[h*(-1)^i for i in 1:n]
    kinetics=(K+Diagonal(diagonal),K-Diagonal(diagonal))
    function green(z,spin)
        value=inv(z*I-kinetics[spin])
        value,-value*value
    end
    (;nsites=n÷2,kinetics,green,mu_interval=(-Inf,Inf))
end

# Literal paper Bloch algebra, independent of the real-space embedding code.
function bloch(kx,ky,p)
    a=-2p.t1*cos(kx)-2p.t2*cos(ky)-4p.t3*cos(kx)*cos(ky)
    d=-2p.t2*cos(kx)-2p.t1*cos(ky)-4p.t3*cos(kx)*cos(ky)
    b=4p.t4*sin(kx)*sin(ky)
    [a b;b d]
end

function auxiliary_reference(cluster,p)
    reference=free_reference(cluster,p)
    n=2reference.nsites
    coupling=[.08sin(2i+3j) for i in 1:n,j in 1:3]
    bath=Diagonal([-1.1,.4,1.7])
    matrices=ntuple(s->Matrix(Symmetric([reference.kinetics[s] coupling;coupling' bath])),2)
    function green(z,spin)
        inv(z*I-matrices[spin])[1:n,1:n]
    end
    (;nsites=reference.nsites,kinetics=reference.kinetics,green,mu_interval=(-Inf,Inf)),matrices
end

function line_quadrature(order)
    beta=[j/sqrt(4j*j-1) for j in 1:order-1]
    e=eigen(SymTridiagonal(zeros(order),beta))
    theta=(pi/2).*e.values
    (;omega=tan.(theta),weights=pi.*abs2.(e.vectors[1,:])./cos.(theta).^2)
end

@testset "Real-axis spectra: exact Bloch and gauge" begin
    points=[(.37,-.91),(2.4,.11),(-pi,.7),(pi/2,-pi/2),(.2+2pi,-.4-2pi)]
    frequencies=[-.7,0.,.8]
    for (lx,ly) in ((1,1),(2,1),(2,2)),ratio in (-.2,-.5)
        c=G.rectangular_cluster(lx,ly);p=G.Model.slater_koster_parameters(ratio)
        ref=free_reference(c,p)
        problem=S.SpectralProblem(ref,c,p;mu=.173,mu_prime=.327)
        @test problem.cluster isa S.G.ReferenceCluster
        @test problem.parameters isa S.G.Model.PaperHoppingParameters
        plan=S.spectral_plan(problem,points)
        grid=S.spectral_grid(plan,frequencies;eta=.05,resolved=true,threaded=false)
        @test size(grid.total)==(3,5)
        @test size(grid.spin_orbital)==(3,5,2,2)
        @test dropdims(sum(grid.spin_orbital;dims=(3,4));dims=(3,4))≈grid.total atol=2e-13 rtol=2e-13
        for (kindex,(kx,ky)) in enumerate(points),(wi,w) in enumerate(frequencies)
            expected=inv((complex(w,.05)+problem.mu)*I-bloch(kx,ky,p))
            for spin in (1,2)
                actual=S.periodized_green(problem,kx,ky,complex(w,.05);spin)
                # η=.05 bounds resolvent amplification; 1e-10 leaves margin
                # for cancellation of distinct μ/μ′ and Weiss matrices.
                @test actual≈expected atol=1e-10 rtol=1e-11
            end
            @test grid.total[wi,kindex]≈-2imag(tr(expected))/pi atol=2e-10 rtol=2e-11
        end
    end
end

@testset "Real-axis spectra: independent auxiliary resolvent and causality" begin
    c=G.rectangular_cluster();p=G.Model.slater_koster_parameters(-.2)
    ref,auxiliary=auxiliary_reference(c,p)
    problem=S.SpectralProblem(ref,c,p;mu=.07,mu_prime=.21)
    points=[(.19,-.37),(1.2,.7),(-2.4,2.1)]
    frequencies=[-1.2,-.4,0.,.35,1.4]
    for (kx,ky) in points,w in frequencies,spin in 1:2
        n=2ref.nsites;z=complex(w,.05)
        q=S.reduced_momentum(c,kx,ky)
        H=complex.(auxiliary[spin])
        H[1:n,1:n].+=G.lattice_kinetic(c,q...,p)-ref.kinetics[spin]+(problem.mu_prime-problem.mu)*I
        H-=problem.mu_prime*I
        full=inv(z*I-H)
        expected=full[1:n,1:n]
        actual=S.embedded_green(problem,kx,ky,z;spin)
        @test actual≈expected atol=1e-10 rtol=1e-11
        @test minimum(eigvals(Hermitian(S.spectral_matrix(actual))))>=-2e-12
        W=S.periodization_matrix(c,kx,ky)
        projected=S.periodized_green(problem,kx,ky,z;spin)
        @test projected≈W'*expected*W atol=1e-10 rtol=1e-11
        # Spectral positivity from η RR† is an independent Hermitian oracle.
        expected_A=(.05/pi).*(full*full')[1:n,1:n]
        @test S.spectral_matrix(projected)≈W'*expected_A*W atol=2e-10 rtol=1e-11
        @test minimum(eigvals(Hermitian(S.spectral_matrix(projected))))>=-2e-12
    end
    plan=S.spectral_plan(problem,points)
    serial=S.spectral_grid(plan,frequencies;resolved=true,threaded=false)
    parallel=S.spectral_grid(plan,frequencies;resolved=true,threaded=true)
    @test serial.total==parallel.total
    @test serial.spin_orbital==parallel.spin_orbital
    @test minimum(serial.spin_orbital)>=-2e-12
    high=1e6im
    for k in points
        weight=sum(real(tr(high*S.periodized_green(problem,k...,high;spin))) for spin in 1:2)
        @test weight≈4 atol=2e-10 rtol=0
    end
    # Integrate the complete real axis using ω=tan θ. This checks the
    # zeroth moment without confusing a finite plotted window with all weight.
    q=line_quadrature(768)
    integrated=S.spectral_grid(plan,q.omega;eta=.05,resolved=true,threaded=false)
    @test vec(q.weights'*integrated.total)≈fill(4.,length(points)) atol=3e-7 rtol=0
    for orbital in 1:2,spin in 1:2
        @test vec(q.weights'*integrated.spin_orbital[:,:,orbital,spin])≈ones(length(points)) atol=1e-7 rtol=0
    end
end

@testset "Real-axis spectra: translation, folded weights, and DOS normalization" begin
    c=G.rectangular_cluster();p=G.Model.slater_koster_parameters(-.5)
    ref,_=auxiliary_reference(c,p)
    problem=S.SpectralProblem(ref,c,p;mu=.03,mu_prime=.11)
    k=(.17,-.28);z=.2+.05im
    matrix=S.embedded_green(problem,k...,z)
    base=S.periodized_green(matrix,c,k...)
    shifted=[(x+3,y-2) for (x,y) in c.sites]
    @test S.periodized_green(matrix,shifted,k...)≈base atol=3e-13 rtol=3e-13
    permutation=[4,2,1,3]
    mode_order=vcat([[2i-1,2i] for i in permutation]...)
    @test S.periodized_green(matrix[mode_order,mode_order],c.sites[permutation],k...)≈base atol=3e-13 rtol=3e-13
    @test S.periodized_green(problem,k[1]+2pi,k[2]-2pi,z)≈base atol=2e-12 rtol=2e-12
    W=S.periodization_matrix(c,k...)
    @test W'*W≈Matrix{ComplexF64}(I,2,2) atol=3e-15 rtol=0
    complete=hcat([S.periodization_matrix(c,k[1]+pi*ix,k[2]+pi*iy) for iy in 0:1 for ix in 0:1]...)
    @test complete*complete'≈Matrix{ComplexF64}(I,8,8) atol=3e-15 rtol=0
    folded=sum(tr(S.periodized_green(matrix,c,k[1]+pi*ix,k[2]+pi*iy)) for ix in 0:1,iy in 0:1)
    @test folded≈tr(matrix) atol=1e-12 rtol=1e-12
    L=8
    full_points=[(-pi+2pi*ix/L,-pi+2pi*iy/L) for iy in 0:L-1 for ix in 0:L-1]
    reduced_points=G.reduced_momentum_grid(c,L)
    frequencies=[-.5,0.,.33]
    full=S.spectral_grid(S.spectral_plan(problem,full_points),frequencies;resolved=true,threaded=false)
    dos=S.dos_spectrum(S.spectral_plan(problem,reduced_points),frequencies;resolved=true,threaded=false)
    @test dos.total≈vec(sum(full.total;dims=2))./L^2 atol=3e-12 rtol=3e-12
    @test dropdims(sum(dos.spin_orbital;dims=(2,3));dims=(2,3))≈dos.total atol=3e-13 rtol=3e-13
    for orbital in 1:2,spin in 1:2
        @test dos.spin_orbital[:,orbital,spin]≈vec(sum(full.spin_orbital[:,:,orbital,spin];dims=2))./L^2 atol=3e-12 rtol=3e-12
    end
end

@testset "Real-axis spectra: full-PRL atomic poles" begin
    K=zeros(2,2)
    result=C.build_cluster_green(K,K,1.,1,1;J=.25,block_steps=8,probe_z=[.875+.05im])
    green(z,spin)=C.cluster_green(result,z;spin=spin==1 ? :up : :down)
    ref=(;nsites=1,kinetics=(K,K),green,mu_interval=result.mu_interval)
    problem=S.SpectralProblem(ref,G.rectangular_cluster(1,1),G.Model.PaperHoppingParameters(0.,0.,0.,0.);mu=.875,mu_prime=.875)
    frequencies=collect(-1.:.025:1.)
    output=S.dos_spectrum(S.spectral_plan(problem,[(0.,0.)]),frequencies;resolved=true,threaded=false)
    # Full Eq.(2): E(N=1)=0, triplet E(N=2)=U−3J=.25,
    # E(N=3)=3U−5J=1.75. Equal residues give poles ±.625 at μ=.875.
    expected=[2*.05/pi*(inv((w-.625)^2+.05^2)+inv((w+.625)^2+.05^2)) for w in frequencies]
    @test result.E0≈.25 atol=2e-13 rtol=0
    @test output.total≈expected atol=2e-10 rtol=2e-11
    @test minimum(output.spin_orbital)>=0
end

@testset "Real-axis spectra: invalid inputs" begin
    c=G.rectangular_cluster();p=G.Model.slater_koster_parameters(-.2);ref=free_reference(c,p)
    problem=S.SpectralProblem(ref,c,p;mu=0.,mu_prime=0.)
    plan=S.spectral_plan(problem,[(0.,0.)])
    @test_throws ArgumentError S.SpectralProblem(ref,c,p;mu=NaN,mu_prime=0.)
    @test_throws ArgumentError S.SpectralProblem(merge(ref,(mu_interval=(.1,.2),)),c,p;mu=0.,mu_prime=0.)
    @test_throws ArgumentError S.spectral_plan(problem,[])
    @test_throws ArgumentError S.spectral_plan(problem,[(NaN,0.)])
    @test_throws ArgumentError S.embedded_green(problem,0.,0.,.1)
    @test_throws ArgumentError S.embedded_green(problem,0.,0.,.1-.05im)
    @test_throws ArgumentError S.embedded_green(problem,0.,0.,.1+.05im;spin=:sum)
    @test_throws ArgumentError S.spectral_grid(plan,[0.];eta=0.)
    @test_throws ArgumentError S.dos_spectrum(plan,[NaN])
    @test_throws DimensionMismatch S.periodized_green(zeros(4,4),c,0.,0.)
end

end
