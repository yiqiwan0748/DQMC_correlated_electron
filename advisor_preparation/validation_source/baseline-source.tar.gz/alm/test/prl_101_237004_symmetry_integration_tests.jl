module PRL101237004SymmetryIntegrationTests

using LinearAlgebra
using Random
using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_ed.jl"))
include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_geometry.jl"))
const E = PRL101237004ED
const G = PRL101237004Geometry

# All operator comparisons below use normalized complex random vectors and
# absolute Euclidean residuals. At dimension <= 4900 and O(1) couplings,
# 1e-11 permits accumulated Float64 arithmetic while resolving missing
# exchange/pair terms and incorrect orbital/fermionic signs by many orders.
const ATOL = 1e-11
const RNG = MersenneTwister(237004)

function random_unit_vector(dimension)
    vector = randn(RNG, dimension) .+ im .* randn(RNG, dimension)
    return vector / norm(vector)
end

function repeated_action(action, vector, power)
    result = copy(vector)
    for _ in 1:power
        result = G.apply_symmetry(action, result)
    end
    return result
end

function total_spin_raising(source, target, vector)
    source.nmodes == target.nmodes || throw(DimensionMismatch("spin bases differ"))
    (target.Nup, target.Ndown) == (source.Nup + 1, source.Ndown - 1) ||
        throw(ArgumentError("target must be the S+ sector"))
    output = zeros(eltype(vector), length(target.states))
    for (index, state) in enumerate(source.states), a in 1:source.nmodes
        # S+ = sum_a c†[a,up] c[a,down]; annihilation acts first.
        transition = E.apply_fermion_ops(state, ((source.nmodes + a, false), (a, true)))
        transition === nothing && continue
        destination, sign = transition
        output[target.indices[destination]] += sign * vector[index]
    end
    return output
end

@testset "Full PRL Hamiltonian respects fermionic lattice symmetries" begin
    for (torus, Nup, Ndown, dimension) in (
        (G.periodic_square_torus(), 4, 4, 4900),
        (G.standard_eight_site_torus(), 1, 1, 256),
    )
        kinetic = G.paper_kinetic_matrix(torus)
        # Both the paper ratio and another nonzero Hund coupling are tested;
        # symmetry must follow from the complete interaction, not a special J.
        for (U, J) in ((0.8, 0.2), (1.3, 0.25))
            h = E.sector_hamiltonian(kinetic, U, Nup, Ndown; J=J)
            @test size(h) == (dimension, dimension)
            vector = random_unit_vector(dimension)
            tx = G.symmetry_action(h.basis, torus; displacement=(1, 0))
            ty = G.symmetry_action(h.basis, torus; displacement=(0, 1))
            c4 = G.symmetry_action(h.basis, torus; kind=:c4)
            hv = h * vector
            for action in (tx, ty, c4)
                @test norm(h * G.apply_symmetry(action, vector) -
                           G.apply_symmetry(action, hv)) <= ATOL
                @test isapprox(norm(G.apply_symmetry(action, vector)), 1; atol=ATOL, rtol=0)
            end
            order = torus.ncells == 4 ? 2 : 4
            @test repeated_action(tx, vector, order) == vector
            @test repeated_action(ty, vector, order) == vector
            @test repeated_action(c4, vector, 4) == vector
            @test G.apply_symmetry(tx, G.apply_symmetry(ty, vector)) ==
                  G.apply_symmetry(ty, G.apply_symmetry(tx, vector))
            @test G.apply_symmetry(c4, G.apply_symmetry(tx, repeated_action(c4, vector, 3))) ==
                  G.apply_symmetry(ty, vector)
            for displacement in (torus.a1, torus.a2)
                @test G.apply_symmetry(G.symmetry_action(h.basis, torus; displacement), vector) == vector
            end
        end
    end
end

@testset "Interacting translation projectors are complete and orthogonal" begin
    for (torus, Nup, Ndown, dimension) in (
        (G.periodic_square_torus(), 2, 2, 784),
        (G.standard_eight_site_torus(), 1, 1, 256),
    )
        h = E.sector_hamiltonian(G.paper_kinetic_matrix(torus), 1.3, Nup, Ndown; J=0.25)
        @test size(h) == (dimension, dimension)
        vector = random_unit_vector(dimension)
        hv = h * vector
        momenta = G.allowed_torus_momenta(torus)
        projections = [G.apply_momentum_projector(h.basis, torus, vector, k...) for k in momenta]
        @test norm(sum(projections) - vector) <= ATOL
        @test isapprox(sum(norm(projected)^2 for projected in projections), 1; atol=ATOL, rtol=0)
        for (i, momentum) in enumerate(momenta)
            projected = projections[i]
            @test norm(h * projected - G.apply_momentum_projector(h.basis, torus, hv, momentum...)) <= ATOL
            @test norm(G.apply_momentum_projector(h.basis, torus, projected, momentum...) - projected) <= ATOL
            for j in 1:(i - 1)
                @test abs(dot(projected, projections[j])) <= ATOL
                @test norm(G.apply_momentum_projector(h.basis, torus, projected, momenta[j]...)) <= ATOL
            end
        end
    end
end

@testset "Hopping plus full PRL interaction commutes with total S+" begin
    for (torus, Nup, Ndown, source_dimension, target_dimension) in (
        (G.periodic_square_torus(), 4, 4, 4900, 3136),
        (G.standard_eight_site_torus(), 1, 1, 256, 120),
    )
        kinetic = G.paper_kinetic_matrix(torus)
        for (U, J) in ((0.8, 0.2), (1.3, 0.25))
            source = E.sector_hamiltonian(kinetic, U, Nup, Ndown; J=J)
            target = E.sector_hamiltonian(kinetic, U, Nup + 1, Ndown - 1; J=J)
            @test size(source) == (source_dimension, source_dimension)
            @test size(target) == (target_dimension, target_dimension)
            vector = random_unit_vector(source_dimension)
            raised = total_spin_raising(source.basis, target.basis, vector)
            @test norm(raised) > 0.1 # Ensure the commutator is tested on a nonzero image.
            raised_hv = total_spin_raising(source.basis, target.basis, source * vector)
            @test norm(target * raised - raised_hv) <= ATOL
        end
    end
end

end # module
