module PRL101237004TopologyTests

using Test

include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_model.jl"))
using .PRL101237004Model

"""Sizes of occupied four-neighbor components on a periodic grid.

The Brillouin zone is a torus: opposite plot edges are neighbors. In
particular, the four corner pieces of an M-centered pocket belong to one
component, not four. No pocket centers or radial contour assumptions enter
this flood-fill calculation.
"""
function periodic_component_sizes(mask::AbstractMatrix{Bool})
    nx, ny = size(mask)
    nx > 0 && ny > 0 || throw(ArgumentError("the periodic grid must be nonempty"))
    visited = falses(nx, ny)
    sizes = Int[]
    queue = Int[]
    for start in eachindex(mask)
        (mask[start] && !visited[start]) || continue
        empty!(queue)
        push!(queue, start)
        visited[start] = true
        cursor = 1
        while cursor <= length(queue)
            index = queue[cursor]
            cursor += 1
            x = mod1(index, nx)
            y = fld(index - 1, nx) + 1
            neighbors = (
                mod1(x + 1, nx) + nx * (y - 1),
                mod1(x - 1, nx) + nx * (y - 1),
                x + nx * (mod1(y + 1, ny) - 1),
                x + nx * (mod1(y - 1, ny) - 1),
            )
            for neighbor in neighbors
                if mask[neighbor] && !visited[neighbor]
                    visited[neighbor] = true
                    push!(queue, neighbor)
                end
            end
        end
        push!(sizes, length(queue))
    end
    return sort!(sizes)
end

"""Occupation regions from the literal Eq. (1) dispersion.

For c_x=cos(k_x), c_y=cos(k_y), the eigenvalue center and squared splitting
follow directly from the printed hoppings:

    center = -(t1+t2)(c_x+c_y) - 4t3*c_x*c_y
    splitting² = ((t2-t1)(c_x-c_y))² + (4t4*sin(k_x)*sin(k_y))².

This independent expression uses the raw paper hopping fields, not the
repository Bloch routine, the runner, or its assumed four pocket centers.
"""
function literal_occupation_regions(parameters, chemical_potential, Nk)
    Nk >= 4 || throw(ArgumentError("Nk must be at least four"))
    momenta = [-pi + 2pi * i / Nk for i in 0:(Nk - 1)]
    cosine = cos.(momenta)
    sine = sin.(momenta)
    lower_band_holes = falses(Nk, Nk)
    upper_band_electrons = falses(Nk, Nk)
    (; t1, t2, t3, t4) = parameters
    for y in 1:Nk, x in 1:Nk
        cx, cy = cosine[x], cosine[y]
        center = -(t1 + t2) * (cx + cy) - 4t3 * cx * cy
        splitting = sqrt(((t2 - t1) * (cx - cy))^2 +
                         (4t4 * sine[x] * sine[y])^2)
        lower_band_holes[x, y] = center - splitting > chemical_potential
        upper_band_electrons[x, y] = center + splitting < chemical_potential
    end
    return lower_band_holes, upper_band_electrons
end

@testset "PRL 101, 237004 Fermi-pocket topology" begin
    @testset "Periodic flood-fill sanity" begin
        @test isempty(periodic_component_sizes(falses(7, 7)))
        @test periodic_component_sizes(trues(7, 7)) == [49]
        corners = falses(7, 7)
        corners[[1, 7], [1, 7]] .= true
        @test periodic_component_sizes(corners) == [4]
        separate = falses(7, 7)
        separate[2, 2] = true
        separate[5, 5] = true
        @test periodic_component_sizes(separate) == [1, 1]
    end

    # The two calculated chemical potentials are the documented Nk=1600
    # half-filling quantiles. The other values are the reported SK value and
    # the Ref. [11] preprint value. This tests a fixed first-milestone target;
    # it does not assume these chemical potentials are exact bulk half filling.
    sk = slater_koster_parameters()
    raghu = raghu_parameters()
    cases = (
        (name="SK printed mu", parameters=sk, mu=-0.03),
        (name="SK calculated half filling", parameters=sk, mu=-0.027449638716078924),
        (name="Raghu calculated half filling", parameters=raghu, mu=1.5425453058312137),
        (name="Raghu Ref. [11] mu", parameters=raghu, mu=1.45),
    )
    for case in cases, Nk in (200, 400)
        @testset "$(case.name), Nk=$Nk" begin
            holes, electrons = literal_occupation_regions(case.parameters, case.mu, Nk)
            hole_sizes = periodic_component_sizes(holes)
            electron_sizes = periodic_component_sizes(electrons)
            @test length(hole_sizes) == 2
            @test length(electron_sizes) == 2
            @test sum(hole_sizes) == count(holes)
            @test sum(electron_sizes) == count(electrons)
        end
    end
    # Component counts are exact integer checks on each sampled torus, so no
    # floating-point comparison tolerance is appropriate. Agreement at both
    # resolutions supports the displayed topology; this does not assert the
    # absence of arbitrarily tiny pockets for other parameters or fillings.
end

end
