using Test, LinearAlgebra
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_vca_functional.jl"))
const PRLVCAFunctionalTests=PRL101237004VCAFunctional

@testset "PRL VCA trace correction and independent chemical potentials" begin
    F=PRLVCAFunctionalTests
    q=F.imaginary_quadrature(32)
    # Piecewise rational-axis quadrature: these isolated levels have finite
    # gaps, so 2e-9 is a conservative integration/Float64 cancellation bound.
    tol=2e-9
    ref=F.noninteracting_reference(diagm([-.7,.5]),diagm([-.6,.8]),1,1)
    lat=F.LatticeEmbedding([diagm([-.2,.9])],1)
    direct=F.free_lattice_observables(lat,.1)
    for mup in (-.2,.2,.4)
        x=F.evaluate_functional(ref,lat,.1,mup;quadrature=q)
        @test isapprox(x.omega,-.6;atol=tol,rtol=tol)
        @test isapprox(x.omega,direct.omega;atol=tol,rtol=tol)
        @test isapprox(x.density,2.0;atol=tol,rtol=tol)
        @test abs(x.mu_prime_gradient)<tol
    end
    x=F.evaluate_functional(ref,lat,.1,.2;quadrature=q)
    @test isapprox(x.trace_correction,.9;atol=tol,rtol=0)
    @test_throws ArgumentError F.evaluate_functional(ref,lat,.1,.8;quadrature=q)
    @test_throws ArgumentError F.imaginary_quadrature(1)
    @test_throws ArgumentError F.imaginary_quadrature(8;breaks=(0.0,.1,.01))

    # SU(4) isolated atom, U=1,J=0,N=2: E0=1, equal-weight ground
    # ensemble gives addition/removal poles 2 and 1 with weight 1/2.
    function atomic_green(z,spin)
        g=.5/(z-1)+.5/(z-2)
        dg=-.5/(z-1)^2-.5/(z-2)^2
        Matrix(Diagonal(fill(g,2))),Matrix(Diagonal(fill(dg,2)))
    end
    atom=F.ReferenceSystem(1.0,2,zeros(2,2),zeros(2,2),atomic_green;mu_interval=(1.0,2.0))
    isolated=F.LatticeEmbedding([zeros(2,2)],1)
    a=F.evaluate_functional(atom,isolated,1.5,1.5;quadrature=q)
    @test isapprox(a.omega,-2.0;atol=tol,rtol=tol)
    @test isapprox(a.density,2.0;atol=tol,rtol=tol)
    @test abs(a.mu_prime_gradient)<tol
    @test abs(a.trace_log_integral)<tol
    # A nontrivial rational self-energy probes both independent derivatives;
    # 2e-7 also covers O(step^2) central-difference truncation.
    lat2=F.LatticeEmbedding([[-.3 .11;.11 .2]],1)
    mu,mup,step=1.45,1.4,2e-4
    y=F.evaluate_functional(atom,lat2,mu,mup;quadrature=q)
    dp=(F.evaluate_functional(atom,lat2,mu,mup+step;quadrature=q).omega-
        F.evaluate_functional(atom,lat2,mu,mup-step;quadrature=q).omega)/(2step)
    dn=-(F.evaluate_functional(atom,lat2,mu+step,mup;quadrature=q).omega-
         F.evaluate_functional(atom,lat2,mu-step,mup;quadrature=q).omega)/(2step)
    @test isapprox(dp,y.mu_prime_gradient;atol=2e-7,rtol=2e-7)
    @test isapprox(dn,y.density;atol=2e-7,rtol=2e-7)
end

@testset "PRL VCA noninteracting cancellation in the physical lattice" begin
    F=PRLVCAFunctionalTests
    G=F.Geometry
    c=G.rectangular_cluster()
    lat=F.LatticeEmbedding(c;physical_L=12)
    # Choose physical mu away from the finite mesh's one-particle poles.
    mu=-.037123
    exact=F.free_lattice_observables(lat,mu)
    q=F.imaginary_quadrature(32)
    for channel in (:stripe_y,:neel),h in (0.0,.03,.08)
        K=G.weiss_kinetics(c,h;channel)
        # The open h=0 cluster has a degenerate shell at reference half
        # filling. Choose a nondegenerate reference charge branch instead;
        # at U=0 the physical result must be independent of this choice.
        mup=-.17
        nu=count(<(mup),eigvals(Symmetric(K.up)))
        nd=count(<(mup),eigvals(Symmetric(K.down)))
        ref=F.noninteracting_reference(K.up,K.down,nu,nd)
        x=F.evaluate_functional(ref,lat,mu,mup;quadrature=q)
        @test isapprox(x.omega,exact.omega;atol=2e-8,rtol=2e-8)
        @test isapprox(x.density,exact.density;atol=2e-8,rtol=2e-8)
        @test abs(x.mu_prime_gradient)<2e-8
        @test abs(x.moment)<2e-8
    end
end
