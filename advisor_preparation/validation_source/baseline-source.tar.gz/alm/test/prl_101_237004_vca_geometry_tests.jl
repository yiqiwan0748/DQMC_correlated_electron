using Test, LinearAlgebra
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_vca_geometry.jl"))
const PRLVCAGeometryTests = PRL101237004VCAGeometry

@testset "PRL VCA open-cluster and lattice embedding geometry" begin
    G=PRLVCAGeometryTests
    # These small one-body matrices contain order-one entries. 3e-12 permits
    # trigonometric/eigensolver roundoff but resolves bond multiplicities/signs.
    tol=3e-12
    for dims in ((1,1),(2,1),(2,2),(4,2)),r in (-0.2,-0.5)
        c=G.rectangular_cluster(dims...)
        p=G.Model.slater_koster_parameters(r)
        K=G.open_kinetic(c,p)
        @test issymmetric(K)
        @test all(iszero,diag(K))
        for (kx,ky) in ((0.0,0.0),(0.137,-0.293),(pi/c.Lx,-pi/c.Ly))
            lattice=G.lattice_kinetic(c,kx,ky,p)
            @test isapprox(lattice,lattice';atol=tol,rtol=tol)
            @test isapprox(eigvals(Hermitian(lattice)),G.folded_band_energies(c,kx,ky,p);atol=tol,rtol=tol)
            @test isapprox(lattice,G.lattice_kinetic(c,kx+2pi/c.Lx,ky-2pi/c.Ly,p);atol=tol,rtol=tol)
        end
        # The reduced-BZ average removes all intercell bonds exactly here.
        momenta=G.reduced_momentum_grid(c,16)
        average=sum(G.lattice_kinetic(c,q...,p) for q in momenta)/length(momenta)
        @test isapprox(average,K;atol=tol,rtol=tol)
    end
    c=G.rectangular_cluster()
    @test length(G.reduced_momentum_grid(c,48))==24^2
    f=G.weiss_kinetics(c,0.07;channel=:stripe_y)
    @test f.pattern==[1,1,1,1,-1,-1,-1,-1]
    @test isapprox(f.up-f.down,Diagonal(0.14.*f.pattern);atol=tol,rtol=tol)
    @test isapprox((f.up+f.down)/2,G.open_kinetic(c);atol=tol,rtol=tol)
    @test_throws ArgumentError G.reduced_momentum_grid(c,47)
    @test_throws ArgumentError G.weiss_kinetics(G.rectangular_cluster(1,1),0.1)
    @test_throws ArgumentError G.weiss_kinetics(c,0.1;channel=:bad)
    @test_throws ArgumentError G.rectangular_cluster(4,4)
end
