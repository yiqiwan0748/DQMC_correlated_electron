module PRL101237004VCAMomentTests

using Test, LinearAlgebra, SHA, TOML, Dates
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_vca_campaign.jl"))
const V=PRL101237004VCACampaign
const F=V.F

"""Independent physical-source trace-log differences at fixed reference.

The physical hopping changes by +λ*s*diag(pattern), s=+1/-1 for up/down.
The reference Green function, its Weiss field, and both chemical potentials
are held fixed. The determinant identity gives
  Ω(λ)-Ω(0) = -Σ_s∫ Re log det[I-λ*s*P*G_lattice] / (π*N_Fe).
The source trace corrections cancel between spins. Computing the log with
complex log1p of the matrix eigenvalues avoids subtracting two large grand
potentials or losing the high-frequency real tail. G_lattice is obtained by
an independent inverse Dyson solve, not the production moment contraction.
"""
function physical_source_differences(ref,lat,mu,mup,lambdas;
                                     pattern=lat.moment_pattern,quadrature=F.imaginary_quadrature(32))
    length(pattern)==2lat.nsites || throw(DimensionMismatch("source pattern differs"))
    P=Diagonal(pattern)
    sums=zeros(length(lambdas),length(quadrature.nodes))
    function frequency(index)
        omega=quadrature.nodes[index]
        for spin in 1:2
            sign=spin==1 ? 1 : -1
            gp=first(ref.green(complex(mup,omega),spin))
            inverse_reference=inv(gp)
            for kinetic in lat.hoppings
                perturbation=kinetic-ref.kinetics[spin]+(mup-mu)*I
                embedded=inv(inverse_reference-perturbation)
                source_eigenvalues=eigvals(sign*P*embedded)
                for (column,lambda) in enumerate(lambdas)
                    sums[column,index]+=sum(real(log1p(-lambda*x)) for x in source_eigenvalues)
                end
            end
        end
    end
    if Threads.nthreads()>1
        Threads.@threads :static for index in eachindex(quadrature.nodes)
            frequency(index)
        end
    else
        for index in eachindex(quadrature.nodes)
            frequency(index)
        end
    end
    return -(sums*quadrature.weights)/(pi*lat.nsites*length(lat.hoppings))
end

function free_source_omega(lat,mu,lambda;pattern=lat.moment_pattern)
    sum(sum(min(e-mu,0.0) for e in eigvals(Hermitian(K+sign*lambda*Diagonal(pattern))))
        for K in lat.hoppings for sign in (-1,1))/(lat.nsites*length(lat.hoppings))
end

function reference_from_cluster(result)
    greens(z,spin)=(V.C.cluster_green(result,z;spin=spin==1 ? :up : :down),
                    V.C.green_mu_derivative(result,z;spin=spin==1 ? :up : :down))
    F.ReferenceSystem(result.E0,result.Nup+result.Ndown,result.K_up,result.K_down,greens;
                      mu_interval=result.mu_interval)
end

function run_moment_tests(;output=nothing)
    BLAS.set_num_threads(1)
    output===nothing || !ispath(output) || error("moment audit already exists; preserve its provenance")
    sources=vcat(V.SCAN_SOURCES,["test/prl_101_237004_vca_moment_tests.jl"])
    hashes=Dict(s=>V.filehash(joinpath(V.ROOT,s)) for s in sources)
    rows=Tuple[]
    @testset "Thermodynamic physical-field moment and normalization" begin
        @testset "Interacting four-Fe stripe anchor" begin
            h,mup=0.04630403476683797,0.8622314233131982
            K=V.G.weiss_kinetics(V.G.rectangular_cluster(),h;channel=:stripe_y)
            # Solve directly with a separate seed; no production checkpoint
            # or digitized moment enters this independent test.
            result=V.C.build_cluster_green(K.up,K.down,1.0,4,4;J=.25,block_steps=48,
                seed=19,probe_z=ComplexF64[mup+im*w for w in (1e-5,.001,.01,.1,1.,10.)])
            @test result.converged
            ref=reference_from_cluster(result)
            lat=F.LatticeEmbedding(V.G.rectangular_cluster();physical_L=48,channel=:stripe_y)
            q=F.imaginary_quadrature(32)
            x=F.evaluate_functional(ref,lat,.85,mup;quadrature=q)
            step=2e-4
            lambdas=[-step,step,-step/2,step/2]
            delta=physical_source_differences(ref,lat,.85,mup,lambdas;quadrature=q)
            coarse=(delta[2]-delta[1])/(2step)
            fine=(delta[4]-delta[3])/step
            richardson=(4fine-coarse)/3
            # O(step²) source differences need the looser tolerance; the
            # Richardson estimate removes that term. Both are well above
            # Float64/quadrature error observed in the controlled comparisons.
            @test isapprox(coarse,x.moment;atol=2e-6,rtol=0)
            @test isapprox(fine,x.moment;atol=2e-6,rtol=0)
            @test isapprox(richardson,x.moment;atol=2e-8,rtol=0)
            @test x.moment < -1.0
            @test -coarse > 1.0 # ∂Ω/∂B for H_B=-B*m has the opposite sign.
            for (label,value,scale) in (("central",coarse,step),("central",fine,step/2),("Richardson",richardson,step/2))
                push!(rows,("interacting_4Fe_U1",h,mup,label,scale,x.moment,value,value-x.moment))
            end
            orbital_one=lat.moment_pattern.*repeat([1.,0.];outer=lat.nsites)
            orbital_two=lat.moment_pattern-orbital_one
            orbital_values=Float64[]
            for (orbital,pattern) in enumerate((orbital_one,orbital_two))
                orbital_lat=F.LatticeEmbedding(lat.hoppings,lat.nsites;moment_pattern=pattern)
                orbital_moment=F.evaluate_functional(ref,orbital_lat,.85,mup;quadrature=q).moment
                d=physical_source_differences(ref,lat,.85,mup,[-step/2,step/2];pattern,quadrature=q)
                derivative=(d[2]-d[1])/step
                @test isapprox(derivative,orbital_moment;atol=2e-6,rtol=0)
                push!(orbital_values,orbital_moment)
                push!(rows,("interacting_orbital_$orbital",h,mup,"central",step/2,orbital_moment,derivative,derivative-orbital_moment))
            end
            @test isapprox(sum(orbital_values),x.moment;atol=2e-12,rtol=0)
            reversed=F.LatticeEmbedding(lat.hoppings,lat.nsites;moment_pattern=-lat.moment_pattern)
            @test isapprox(F.evaluate_functional(ref,reversed,.85,mup;quadrature=q).moment,-x.moment;atol=2e-12,rtol=0)
        end

        @testset "U0 reference Weiss cancellation with a finite physical source" begin
            cluster=V.G.rectangular_cluster()
            lat=F.LatticeEmbedding(cluster;physical_L=12,channel=:stripe_y)
            q=F.imaginary_quadrature(48)
            mu,mup=-.037123,-.17
            lambdas=[-.03,-.01,.01,.03]
            direct=[free_source_omega(lat,mu,l)-free_source_omega(lat,mu,0.) for l in lambdas]
            for h in (.03,.08)
                K=V.G.weiss_kinetics(cluster,h;channel=:stripe_y)
                nu=count(<(mup),eigvals(Symmetric(K.up)))
                nd=count(<(mup),eigvals(Symmetric(K.down)))
                ref=F.noninteracting_reference(K.up,K.down,nu,nd)
                moment=F.evaluate_functional(ref,lat,mu,mup;quadrature=q).moment
                @test abs(moment)<2e-8
                differences=physical_source_differences(ref,lat,mu,mup,lambdas;quadrature=q)
                for (lambda,actual,exact) in zip(lambdas,differences,direct)
                    @test isapprox(actual,exact;atol=2e-8,rtol=0)
                    push!(rows,("U0_source_Omega",h,mup,"lambda",lambda,exact,actual,actual-exact))
                end
                @test abs((differences[3]-differences[2])/.02)<2e-8
            end
        end

        @testset "High-U saturated two-Fe atomic branch: two muB per Fe" begin
            # Two decoupled Fe atoms, two aligned electrons per Fe. At U=4,
            # J=1 the atomic triplet energy is U-3J=1. The small reference
            # field selects opposite Sz=±1 atoms in the Nup=Ndown=2 sector.
            # g=2 gives exactly ±2 muB per Fe, not ±1 or ±4.
            pattern=[1.,1.,-1.,-1.]
            lat=F.LatticeEmbedding([zeros(4,4)],2;moment_pattern=pattern)
            q=F.imaginary_quadrature(32)
            for h in (-.2,.2)
                up=Matrix(Diagonal(h*pattern))
                result=V.C.build_cluster_green(up,-up,4.0,2,2;J=1.0,block_steps=8,
                    probe_z=ComplexF64[3.5+im*w for w in (.01,.1,1.,10.)])
                ref=reference_from_cluster(result)
                expected=-2sign(h)
                @test isapprox(result.E0,2-4abs(h);atol=2e-12,rtol=0)
                @test result.converged
                @test all(norm(V.C.spectral_moments(result;spin).zeroth-I)<2e-12 for spin in (:up,:down))
                moment=F.evaluate_functional(ref,lat,3.5,3.5;quadrature=q).moment
                @test isapprox(moment,expected;atol=2e-9,rtol=0)
                d=physical_source_differences(ref,lat,3.5,3.5,[-.001,.001];quadrature=q)
                derivative=(d[2]-d[1])/.002
                @test isapprox(derivative,expected;atol=2e-9,rtol=0)
                orbital=F.LatticeEmbedding(lat.hoppings,2;moment_pattern=[1.,0.,-1.,0.])
                @test isapprox(F.evaluate_functional(ref,orbital,3.5,3.5;quadrature=q).moment,expected/2;atol=2e-9,rtol=0)
                push!(rows,("atomic_U4",h,3.5,"central",.001,expected,derivative,derivative-expected))
            end
        end
    end
    if output!==nothing
        mkpath(output)
        for (source,hash) in hashes
            destination=joinpath(output,"source_snapshot",source)
            mkpath(dirname(destination));cp(joinpath(V.ROOT,source),destination)
            V.filehash(destination)==hash || error("source changed during snapshot")
        end
        V.write_csv(joinpath(output,"numeric_checks.csv"),
            "case,reference_h,mu_prime,method,step_or_physical_lambda,expected_or_density_moment,source_derivative_or_Omega_difference,error",rows)
        metadata=Dict{String,Any}("created_utc"=>string(now(UTC)),"julia_version"=>string(VERSION),
            "Julia_threads"=>Threads.nthreads(),"BLAS_threads"=>BLAS.get_num_threads(),
            "invocation"=>"PRL_MOMENT_AUDIT_OUTPUT=results/prl_101_237004/fig2c/moment_audit OPENBLAS_NUM_THREADS=1 JULIA_NUM_THREADS=2 julia --startup-file=no --project=. test/prl_101_237004_vca_moment_tests.jl",
            "source_sha256"=>hashes,"numeric_checks_sha256"=>V.filehash(joinpath(output,"numeric_checks.csv")),
            "physical_source"=>"+lambda sum_i,orbital p_i(n_up-n_down) in the physical hopping only",
            "moment_identity"=>"dOmega/dlambda = m/(muB per Fe); with H_B=-B*m, m=-dOmega/dB; g=2 and S_z=(n_up-n_down)/2",
            "fixed_variables"=>"Reference h, canonical reference Green function, physical mu and reference mu_prime remain fixed while lambda changes.",
            "atomic_limit"=>"The reference field selects a saturated symmetry-broken atomic branch. This is a fixed-reference derivative, not the derivative of a globally minimized cusp across opposite atomic orientations.",
            "limits"=>"The U1 anchor and U0/atomic oracles validate moment factors and the physical-source identity; they do not establish convergence or stationarity for all Fig2c U/ratio points.")
        all(V.filehash(joinpath(V.ROOT,s))==hash for (s,hash) in hashes) || error("source changed during tests")
        open(joinpath(output,"provenance.toml"),"w") do io
            TOML.print(io,metadata;sorted=true)
        end
    end
    return rows
end

end

if abspath(PROGRAM_FILE)==abspath(@__FILE__)
    # Standalone tests remain repeatable. Artifact creation is explicit and
    # refuses to overwrite an existing audit, including its source snapshots.
    requested_output=get(ENV,"PRL_MOMENT_AUDIT_OUTPUT","")
    PRL101237004VCAMomentTests.run_moment_tests(output=isempty(requested_output) ? nothing : abspath(requested_output))
else
    PRL101237004VCAMomentTests.run_moment_tests()
end
