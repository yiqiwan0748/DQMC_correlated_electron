using Test
using LinearAlgebra
using TOML
include(joinpath(@__DIR__,"..","scripts","prl_101_237004_vca_reference_audit.jl"))
const ReferenceAudit=PRL101237004VCAReferenceAudit

@testset "All-sector atomic reference grand-ground audit" begin
    # A one-Fe atom has at most four basis states per fixed-spin sector,
    # allowing an independent dense diagonalization of every sector.
    up=[-0.11 0.03;0.03 0.08]
    down=[0.09 -0.01;-0.01 -0.06]
    audit=ReferenceAudit.audit_reference_ground(up,down,1.0,1,1;J=0.25)
    @test length(audit.rows)==9
    @test sum(r.dimension for r in audit.rows)==16
    for row in audit.rows
        H=ReferenceAudit.C.spin_hamiltonian(up,down,1.0,row.Nup,row.Ndown;J=0.25)
        # The 2e-12 tolerance covers roundoff in matrices of dimension <=4.
        @test row.energy ≈ eigmin(Symmetric(Matrix(H))) atol=2e-12 rtol=0
        @test row.residual<2e-12
    end
    @test audit.target_lowest_at_same_N
    @test audit.has_stable_mu_interval
    lo,hi=audit.mu_interval
    @test lo<hi
    @test ReferenceAudit.reference_stability(audit,(lo+hi)/2).stable
    @test !ReferenceAudit.reference_stability(audit,lo-1e-4).stable
    @test !ReferenceAudit.reference_stability(audit,hi+1e-4).stable
    for mu in (lo,hi)
        @test ReferenceAudit.reference_stability(audit,mu).minimum_difference>=-2e-12
    end
    # A polarized target remains an excited state at the same N for these
    # spin fields. No choice of chemical potential can repair that branch.
    wrong=ReferenceAudit.audit_reference_ground(up,down,1.0,2,0;J=0.25)
    @test !wrong.target_lowest_at_same_N
    @test !isempty(wrong.lower_same_N)
    @test !wrong.has_stable_mu_interval
    @test !ReferenceAudit.reference_stability(wrong,(lo+hi)/2).stable
    vacuum=ReferenceAudit.audit_reference_ground(up,down,1.0,0,0;J=0.25)
    @test vacuum.mu_interval[1]==-Inf
    @test ReferenceAudit.reference_stability(vacuum,vacuum.mu_interval[2]-1).stable
    filled=ReferenceAudit.audit_reference_ground(up,down,1.0,2,2;J=0.25)
    @test filled.mu_interval[2]==Inf
    @test ReferenceAudit.reference_stability(filled,filled.mu_interval[1]+1).stable
    mktempdir() do directory
        ReferenceAudit.write_reference_audit(audit,directory;physical_metadata=Dict("case"=>"atomic oracle"))
        metadata=TOML.parsefile(joinpath(directory,"metadata.toml"))
        @test metadata["sector_count"]==9
        @test metadata["mu_lower"]==lo
        @test metadata["physical_metadata"]["case"]=="atomic oracle"
        @test length(readlines(joinpath(directory,"sectors.csv")))==10
        @test length(readlines(joinpath(directory,"particle_minima.csv")))==6
        @test haskey(metadata["source_sha256"],"scripts/prl_101_237004_cluster_green.jl")
    end
    @test_throws ArgumentError ReferenceAudit.audit_reference_ground(zeros(10,10),zeros(10,10),1.0,5,5)
    @test_throws ArgumentError ReferenceAudit.reference_stability(audit,Inf)
end
