using Test

if !isdefined(Main, :PRL101237004VCAStationarity)
    include(joinpath(@__DIR__, "..", "scripts", "prl_101_237004_vca_stationarity.jl"))
end
using .PRL101237004VCAStationarity

@testset "Bounded reference chemical-potential stationarity" begin
    # Analytic scalar functions isolate the search from ED/quadrature errors.
    # 1e-10 gradient and 1e-12 position tolerances are readily resolved in
    # Float64 on these order-one intervals; positions allow local slope effects.
    calls = Float64[]
    function multi(x)
        push!(calls, x)
        g = (x - 0.17) * (x - 0.48) * (x - 0.82)
        (; mu_prime=x, mu_prime_gradient=g, omega=x^2, density=2.0)
    end
    result = stationary_reference_mu(multi, (0.0, 1.0); initial=0.49,
        gradient_atol=1e-10, x_atol=1e-12, max_iterations=48)
    @test result.status == :converged
    @test length(result.roots) == 3
    @test isapprox([r.mu_prime for r in result.roots], [0.17, 0.48, 0.82]; atol=2e-9, rtol=0)
    @test all(r -> r.converged && abs(r.gradient) <= 1e-10, result.roots)
    @test all(r -> r.bracket[1] <= r.mu_prime <= r.bracket[2], result.roots)
    @test length(calls) == length(unique(calls)) == result.evaluations
    @test result.evaluations <= 10 + 3 * 48
    @test all(0.0 .< calls .< 1.0)
    @test result.sample_points[1] == 0.03
    @test result.sample_points[end] == 0.97
    @test 0.49 in result.sample_points
    @test result.representative === nothing
    @test all(r -> result.evaluation_cache[r.mu_prime] == r.data, result.roots)

    datum(x, g; omega=x^2) = (; mu_prime=x, mu_prime_gradient=g, omega, density=2.0)
    flat = stationary_reference_mu(x -> datum(x, 0.0), (0.0, 1.0); initial=0.61)
    @test flat.status == :flat
    @test isempty(flat.roots)
    @test flat.representative.mu_prime == 0.61
    @test flat.representative.status == :flat
    @test flat.evaluations == 10

    absent = stationary_reference_mu(x -> datum(x, 1.0; omega=-x), (0.0, 1.0))
    @test absent.status == :no_root
    @test isempty(absent.roots)
    @test isempty(absent.attempts)
    @test absent.evaluations == 9
    # An extremum of omega at a charge endpoint is not derivative stationarity.
    endpoint = stationary_reference_mu(x -> datum(x, x; omega=x^2 / 2), (0.0, 1.0))
    @test endpoint.status == :no_root
    @test isempty(endpoint.roots)

    # A sign change alone must not certify a discontinuous function as a root.
    jump = stationary_reference_mu(x -> datum(x, x < 0.4321 ? -1.0 : 1.0),
        (0.0, 1.0); x_atol=1e-6)
    @test jump.status == :nonconverged
    @test isempty(jump.roots)
    @test only(jump.attempts).status == :bracket_tolerance_only
    @test jump.evaluations <= 9 + 32

    limited_calls = Ref(0)
    limited = stationary_reference_mu((0.0, 1.0); max_iterations=0) do x
        limited_calls[] += 1
        datum(x, x - 0.4321)
    end
    @test limited.status == :nonconverged
    @test only(limited.attempts).status == :max_iterations
    @test limited.evaluations == limited_calls[] == 9

    # Even-multiplicity roots can be detected when sampled; finite scanning
    # does not otherwise prove their absence.
    tangent = stationary_reference_mu(x -> datum(x, (x - 0.5)^2), (0.0, 1.0))
    @test tangent.status == :converged
    @test only(tangent.roots).mu_prime == 0.5
    @test only(tangent.roots).status == :sampled_zero
    partial = stationary_reference_mu(x -> datum(x, (x - 0.5) * (x - 0.78)),
        (0.0, 1.0); max_iterations=0)
    @test partial.status == :partial
    @test length(partial.roots) == 1
    @test length(partial.attempts) == 2

    plateau = stationary_reference_mu(x -> datum(x, x < 0.3 ? -1.0 : x > 0.7 ? 1.0 : 0.0),
        (0.0, 1.0))
    @test plateau.status == :converged
    @test only(plateau.roots).status == :flat_interval
    @test only(plateau.roots).bracket[1] < only(plateau.roots).bracket[2]
    clamped = stationary_reference_mu(x -> datum(x, x - 0.5), (0.0, 1.0); initial=3.0)
    @test clamped.initial_used == clamped.search_interval[2]
    @test clamped.status == :converged

    strict_points = Float64[]
    strict = stationary_reference_mu((0.0, 1.0); edge_fraction=0) do x
        push!(strict_points, x)
        datum(x, 1.0)
    end
    @test all(0.0 .< strict_points .< 1.0)
    @test strict.status == :no_root

    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, 1.0), (-Inf, Inf))
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, 1.0), (1.0, 0.0))
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, 1.0), (0.0, 1.0); scan_points=1)
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, 1.0), (0.0, 1.0); edge_fraction=0.5)
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, 1.0), (0.0, 1.0); gradient_atol=0)
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, 1.0), (0.0, 1.0); x_atol=NaN)
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, 1.0), (0.0, 1.0); max_iterations=-1)
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, 1.0), (0.0, 1.0); initial=Inf)
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x, NaN), (0.0, 1.0))
    @test_throws ArgumentError stationary_reference_mu(x -> (mu_prime=x,), (0.0, 1.0))
    @test_throws ArgumentError stationary_reference_mu(x -> datum(x + 0.1, 0.0), (0.0, 1.0))
end
