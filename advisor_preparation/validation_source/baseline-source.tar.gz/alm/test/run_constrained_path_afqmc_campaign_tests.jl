module RunConstrainedPathAFQMCCampaignTests

using Test

include(joinpath(
    @__DIR__,
    "..",
    "scripts",
    "run_constrained_path_afqmc_campaign.jl",
))
const Campaign = RunConstrainedPathAFQMCCampaign

function write_jobs(path, text)
    write(path, text)
    return path
end

function publish_fake_output(options)
    mkpath(options.output_dir)
    write(joinpath(options.output_dir, "summary.csv"), "quantity,value\n")
    write(joinpath(options.output_dir, "measurements.csv"), "step,energy\n")
    write(
        joinpath(options.output_dir, "metadata.txt"),
        "method=constrained-path AFQMC\n",
    )
    return options.output_dir
end

@testset "Restartable CP-AFQMC campaign" begin
    @test isnothing(Campaign.parse_options(["--help"]))
    @test_throws ArgumentError Campaign.parse_options(String[])
    @test_throws ArgumentError Campaign.parse_options(["--jobs="])
    @test_throws ArgumentError Campaign.parse_options([
        "--jobs=jobs.csv",
        "--profile=resource-smoke",
    ])
    @test_throws ArgumentError Campaign.parse_options(["--profile=large"])
    @test_throws ArgumentError Campaign.parse_options([
        "--jobs=jobs.csv",
        "--keep-going=yes",
    ])
    @test_throws ArgumentError Campaign.parse_options([
        "--jobs=jobs.csv",
        "--max-jobs=0",
    ])
    @test_throws ArgumentError Campaign.parse_options([
        "--jobs=jobs.csv",
        "--max-jobs=many",
    ])
    @test_throws ArgumentError Campaign.parse_options([
        "--jobs=jobs.csv",
        "--unknown=true",
    ])

    mktempdir() do temporary
        jobs_path = write_jobs(
            joinpath(temporary, "jobs.csv"),
            "job_id,U,seed,trial\n" *
            "first,0,11,free\n" *
            "second,2,12,stripe-x\n",
        )
        jobs = Campaign.read_jobs(jobs_path)
        @test getfield.(jobs, :id) == ["first", "second"]
        @test jobs[2].runner_arguments == [
            "--U=2",
            "--seed=12",
            "--trial=stripe-x",
        ]

        for (name, content) in (
            ("missing_id.csv", "U,seed\n0,1\n"),
            ("unknown.csv", "job_id,bad\na,1\n"),
            ("duplicate.csv", "job_id,U\na,0\na,2\n"),
            ("unsafe.csv", "job_id,U\n../a,0\n"),
            ("quoted.csv", "job_id,U\n\"a\",0\n"),
            ("short.csv", "job_id,U\na\n"),
        )
            path = write_jobs(joinpath(temporary, name), content)
            @test_throws ArgumentError Campaign.read_jobs(path)
        end

        campaign_dir = joinpath(temporary, "fake-campaign")
        options = Campaign.parse_options([
            "--jobs=$jobs_path",
            "--campaign-dir=$campaign_dir",
        ])
        calls = String[]
        executor = function(run_options)
            push!(calls, basename(run_options.output_dir))
            return publish_fake_output(run_options)
        end
        first_run = Campaign.run_campaign(options; executor=executor)
        @test first_run.job_count == 2
        @test first_run.completed == 2
        @test first_run.started == 2
        @test first_run.resumed == 0
        @test first_run.skipped == 0
        @test first_run.failed == 0
        @test calls == ["first", "second"]
        @test isfile(first_run.status_path)
        @test count(
            line -> occursin(",complete,", line),
            readlines(first_run.status_path),
        ) == 2

        second_run = Campaign.run_campaign(options; executor=executor)
        @test second_run.completed == 0
        @test second_run.skipped == 2
        @test calls == ["first", "second"]

        write(
            joinpath(campaign_dir, "outputs", "first", "metadata.txt"),
            "wrong method\n",
        )
        @test_throws ArgumentError Campaign.run_campaign(options; executor=executor)
    end

    mktempdir() do temporary
        jobs_path = write_jobs(
            joinpath(temporary, "jobs.csv"),
            "job_id,U,seed\nfirst,0,11\nsecond,0,12\n",
        )
        options = Campaign.parse_options([
            "--jobs=$jobs_path",
            "--campaign-dir=$(joinpath(temporary, "limited"))",
            "--max-jobs=1",
        ])
        calls = String[]
        executor = function(run_options)
            push!(calls, basename(run_options.output_dir))
            return publish_fake_output(run_options)
        end
        first_run = Campaign.run_campaign(options; executor=executor)
        @test first_run.completed == 1
        @test first_run.remaining == 1
        @test calls == ["first"]

        second_run = Campaign.run_campaign(options; executor=executor)
        @test second_run.completed == 1
        @test second_run.skipped == 1
        @test second_run.remaining == 0
        @test calls == ["first", "second"]
    end

    mktempdir() do temporary
        jobs = Campaign.resource_smoke_jobs()
        @test getfield.(jobs, :id) == [
            "free",
            "alm_plus",
            "alm_minus",
            "stripe_x",
            "stripe_y",
            "neel",
        ]
        parsed = [
            Campaign.RunConstrainedPathAFQMC.parse_options(job.runner_arguments)
            for job in jobs
        ]
        @test all(options -> options.L == 4, parsed)
        @test all(options -> options.U == 12.0, parsed)
        @test all(options -> options.dtau == 0.01, parsed)
        @test all(options -> options.Nup == 12 && options.Ndown == 12, parsed)
        @test all(options -> options.walkers == 64, parsed)
        @test all(options -> options.warmup == 60, parsed)
        @test all(options -> options.measurements == 10, parsed)
        @test all(options -> options.steps_between == 4, parsed)
        @test all(options -> options.back_propagation_steps == 20, parsed)
        @test all(options -> options.minimum_backprop_ancestors == 4, parsed)
        @test all(options -> options.block_size == 2, parsed)
        @test all(options -> options.checkpoint_every_steps == 10, parsed)
        @test [options.trial for options in parsed] == [
            :free,
            :altermagnetic,
            :altermagnetic,
            :stripe_x,
            :stripe_y,
            :neel,
        ]
        @test [options.field_strength for options in parsed] == [
            0.0,
            0.01,
            -0.01,
            0.01,
            0.01,
            0.01,
        ]

        options = Campaign.parse_options([
            "--profile=resource-smoke",
            "--campaign-dir=$(joinpath(temporary, "profile"))",
        ])
        calls = Ref(0)
        fake = function(run_options)
            calls[] += 1
            return publish_fake_output(run_options)
        end
        result = Campaign.run_campaign(options; executor=fake)
        @test calls[] == 6
        @test result.completed == 6
        @test occursin(
            "interpretation=resource_and_restart_smoke_only",
            read(joinpath(options.campaign_dir, "campaign_metadata.txt"), String),
        )
    end

    @testset "Prepared pilot plan" begin
        jobs = Campaign.pilot_jobs()
        @test length(jobs) == 18
        @test length(unique(getfield.(jobs, :id))) == 18
        parsed = [
            Campaign.RunConstrainedPathAFQMC.parse_options(job.runner_arguments)
            for job in jobs
        ]
        @test all(options -> options.L == 4, parsed)
        @test all(options -> options.U == 12.0, parsed)
        @test all(options -> options.Nup == 12 && options.Ndown == 12, parsed)
        @test all(options -> options.dtau == 0.025, parsed)
        @test all(options -> options.walkers == 512, parsed)
        @test all(options -> options.warmup == 320, parsed)
        @test all(options -> options.measurements == 400, parsed)
        @test all(options -> options.steps_between == 4, parsed)
        @test all(options -> options.back_propagation_steps == 80, parsed)
        @test all(options -> options.block_size == 20, parsed)
        @test sort(unique(options.seed for options in parsed)) == [
            12041,
            12042,
            12043,
        ]
        @test [options.seed for options in parsed[1:6]] == fill(12041, 6)
        @test [options.trial for options in parsed[1:6]] == [
            :free,
            :altermagnetic,
            :altermagnetic,
            :stripe_x,
            :stripe_y,
            :neel,
        ]
        @test count(options -> options.trial == :free, parsed) == 3
        @test count(options -> options.trial == :altermagnetic, parsed) == 6
        @test count(options -> options.trial == :stripe_x, parsed) == 3
        @test count(options -> options.trial == :stripe_y, parsed) == 3
        @test count(options -> options.trial == :neel, parsed) == 3
        @test count(options -> options.field_strength == 0.01, parsed) == 12
        @test count(options -> options.field_strength == -0.01, parsed) == 3
        @test count(options -> options.field_strength == 0.0, parsed) == 3

        parsed_cli = Campaign.parse_options(["--profile=pilot"])
        @test parsed_cli.profile == :pilot
        @test endswith(parsed_cli.campaign_dir, "cp_afqmc_pilot")
    end

    @testset "Prepared L6 target-filling pilot" begin
        jobs = Campaign.l6_target_pilot_jobs()
        @test getfield.(jobs, :id) == [
            "alm_plus_seed12041",
            "alm_minus_seed12041",
            "alm_plus_seed12042",
            "alm_minus_seed12042",
            "alm_plus_seed12043",
            "alm_minus_seed12043",
        ]
        @test length(unique(getfield.(jobs, :id))) == 6
        parsed = [
            Campaign.RunConstrainedPathAFQMC.parse_options(job.runner_arguments)
            for job in jobs
        ]
        @test all(options -> options.L == 6, parsed)
        @test all(options -> options.U == 12.0, parsed)
        @test all(options -> options.Nup == 26 && options.Ndown == 26, parsed)
        @test all(options -> options.dtau == 0.025, parsed)
        @test all(options -> options.walkers == 512, parsed)
        @test all(options -> options.warmup == 320, parsed)
        @test all(options -> options.measurements == 400, parsed)
        @test all(options -> options.steps_between == 4, parsed)
        @test all(options -> options.orthogonalize_every == 5, parsed)
        @test all(options -> options.population_control_every == 5, parsed)
        @test all(options -> options.overlap_refresh_every == 16, parsed)
        @test all(options -> options.back_propagation_steps == 80, parsed)
        @test all(options -> options.minimum_backprop_ancestors == 16, parsed)
        @test all(options -> options.block_size == 20, parsed)
        @test all(options -> options.checkpoint_every_steps == 25, parsed)
        @test all(options -> options.trial == :altermagnetic, parsed)
        @test [options.field_strength for options in parsed] == [
            0.01,
            -0.01,
            0.01,
            -0.01,
            0.01,
            -0.01,
        ]
        @test [options.seed for options in parsed] == [
            12041,
            12041,
            12042,
            12042,
            12043,
            12043,
        ]
        @test all(
            options -> options.warmup * options.dtau == 8.0,
            parsed,
        )
        @test all(
            options -> options.back_propagation_steps * options.dtau == 2.0,
            parsed,
        )
        @test all(
            options -> (
                options.warmup +
                options.measurements * options.steps_between
            ) * options.dtau == 48.0,
            parsed,
        )
        @test all(
            options -> (options.Nup + options.Ndown) / options.L^2 == 52 / 36,
            parsed,
        )

        problem = Campaign.RunConstrainedPathAFQMC.two_orbital_cp_afqmc_problem(
            6,
            12.0,
            26,
            26,
        )
        for options in parsed[1:2]
            trial = Campaign.RunConstrainedPathAFQMC.one_body_trial(
                problem;
                pattern=options.trial,
                field_strength=options.field_strength,
            )
            @test isapprox(
                trial.up_shell_gap,
                0.02;
                atol=1.0e-12,
                rtol=0.0,
            )
            @test isapprox(
                trial.down_shell_gap,
                0.02;
                atol=1.0e-12,
                rtol=0.0,
            )
        end

        parsed_cli = Campaign.parse_options(["--profile=l6-target-pilot"])
        @test parsed_cli.profile == :l6_target_pilot
        @test endswith(
            parsed_cli.campaign_dir,
            "cp_afqmc_l6_target_pilot",
        )

        mktempdir() do temporary
            options = Campaign.parse_options([
                "--profile=l6-target-pilot",
                "--campaign-dir=$(joinpath(temporary, "l6-profile"))",
                "--max-jobs=1",
            ])
            calls = String[]
            fake = function(run_options)
                push!(calls, basename(run_options.output_dir))
                return publish_fake_output(run_options)
            end
            first = Campaign.run_campaign(options; executor=fake)
            @test first.job_count == 6
            @test first.completed == 1
            @test first.remaining == 5
            @test calls == ["alm_plus_seed12041"]
            metadata = read(
                joinpath(options.campaign_dir, "campaign_metadata.txt"),
                String,
            )
            @test occursin("profile=l6-target-pilot", metadata)
            @test occursin(
                "interpretation=near_target_filling_size_followup_only",
                metadata,
            )

            second = Campaign.run_campaign(options; executor=fake)
            @test second.completed == 1
            @test second.skipped == 1
            @test second.remaining == 4
            @test calls == [
                "alm_plus_seed12041",
                "alm_minus_seed12041",
            ]
        end
    end

    @testset "Prepared L8 target-filling pilot" begin
        jobs = Campaign.l8_target_pilot_jobs()
        @test getfield.(jobs, :id) == [
            "alm_plus_seed12041",
            "alm_minus_seed12041",
            "alm_plus_seed12042",
            "alm_minus_seed12042",
            "alm_plus_seed12043",
            "alm_minus_seed12043",
        ]
        parsed = [
            Campaign.RunConstrainedPathAFQMC.parse_options(job.runner_arguments)
            for job in jobs
        ]
        @test all(options -> options.L == 8, parsed)
        @test all(options -> options.U == 12.0, parsed)
        @test all(options -> options.Nup == 46 && options.Ndown == 46, parsed)
        @test all(options -> options.dtau == 0.025, parsed)
        @test all(options -> options.walkers == 512, parsed)
        @test all(options -> options.warmup == 320, parsed)
        @test all(options -> options.measurements == 400, parsed)
        @test all(options -> options.steps_between == 4, parsed)
        @test all(options -> options.back_propagation_steps == 80, parsed)
        @test all(options -> options.minimum_backprop_ancestors == 16, parsed)
        @test all(options -> options.block_size == 20, parsed)
        @test all(options -> options.checkpoint_every_steps == 25, parsed)
        @test all(options -> options.trial == :altermagnetic, parsed)
        @test [options.field_strength for options in parsed] == [
            0.01,
            -0.01,
            0.01,
            -0.01,
            0.01,
            -0.01,
        ]
        @test [options.seed for options in parsed] == [
            12041,
            12041,
            12042,
            12042,
            12043,
            12043,
        ]
        @test all(
            options -> options.warmup * options.dtau == 8.0,
            parsed,
        )
        @test all(
            options -> options.back_propagation_steps * options.dtau == 2.0,
            parsed,
        )
        @test all(
            options -> (options.Nup + options.Ndown) / options.L^2 == 92 / 64,
            parsed,
        )

        problem = Campaign.RunConstrainedPathAFQMC.two_orbital_cp_afqmc_problem(
            8,
            12.0,
            46,
            46,
        )
        free_trial = Campaign.RunConstrainedPathAFQMC.one_body_trial(
            problem;
            pattern=:free,
            field_strength=0.0,
        )
        @test abs(free_trial.up_shell_gap) <= 1.0e-12
        @test abs(free_trial.down_shell_gap) <= 1.0e-12
        for options in parsed[1:2]
            trial = Campaign.RunConstrainedPathAFQMC.one_body_trial(
                problem;
                pattern=options.trial,
                field_strength=options.field_strength,
            )
            @test isapprox(
                trial.up_shell_gap,
                0.02;
                atol=1.0e-12,
                rtol=0.0,
            )
            @test isapprox(
                trial.down_shell_gap,
                0.02;
                atol=1.0e-12,
                rtol=0.0,
            )
        end

        parsed_cli = Campaign.parse_options(["--profile=l8-target-pilot"])
        @test parsed_cli.profile == :l8_target_pilot
        @test endswith(
            parsed_cli.campaign_dir,
            "cp_afqmc_l8_target_pilot",
        )

        mktempdir() do temporary
            options = Campaign.parse_options([
                "--profile=l8-target-pilot",
                "--campaign-dir=$(joinpath(temporary, "l8-profile"))",
                "--max-jobs=1",
            ])
            calls = String[]
            fake = function(run_options)
                push!(calls, basename(run_options.output_dir))
                return publish_fake_output(run_options)
            end
            first = Campaign.run_campaign(options; executor=fake)
            @test first.job_count == 6
            @test first.completed == 1
            @test first.remaining == 5
            @test calls == ["alm_plus_seed12041"]
            metadata = read(
                joinpath(options.campaign_dir, "campaign_metadata.txt"),
                String,
            )
            @test occursin("profile=l8-target-pilot", metadata)
            @test occursin(
                "interpretation=near_target_filling_l8_size_followup_only",
                metadata,
            )
        end
    end

    mktempdir() do temporary
        jobs_path = write_jobs(
            joinpath(temporary, "jobs.csv"),
            "job_id,U,seed\nresume_me,2,91\n",
        )
        campaign_dir = joinpath(temporary, "resume-campaign")
        options = Campaign.parse_options([
            "--jobs=$jobs_path",
            "--campaign-dir=$campaign_dir",
            "--keep-going=true",
        ])
        interrupted = function(run_options)
            write(run_options.checkpoint_path, "saved state")
            error("planned interruption")
        end
        failed = Campaign.run_campaign(options; executor=interrupted)
        @test failed.failed == 1
        @test occursin("planned interruption", read(failed.status_path, String))

        saw_resume = Ref(false)
        resumed_executor = function(run_options)
            saw_resume[] = run_options.resume_from == run_options.checkpoint_path
            return publish_fake_output(run_options)
        end
        resumed = Campaign.run_campaign(options; executor=resumed_executor)
        @test saw_resume[]
        @test resumed.resumed == 1
        @test resumed.completed == 1
        @test resumed.failed == 0

        write_jobs(jobs_path, "job_id,U,seed\nresume_me,4,91\n")
        @test_throws ArgumentError Campaign.run_campaign(
            options;
            executor=resumed_executor,
        )
    end

    mktempdir() do temporary
        jobs_path = write_jobs(
            joinpath(temporary, "tiny.csv"),
            "job_id,L,U,Nup,Ndown,dtau,walkers,warmup,measurements," *
            "steps-between,orthogonalize-every,population-control-every," *
            "overlap-refresh-every,back-propagation-steps," *
            "minimum-backprop-ancestors,block-size,seed," *
            "checkpoint-every-steps\n" *
            "tiny,2,0,1,1,0.05,2,1,1,1,1,1,1,0,1,1,8,1\n",
        )
        options = Campaign.parse_options([
            "--jobs=$jobs_path",
            "--campaign-dir=$(joinpath(temporary, "real-campaign"))",
        ])
        run = Campaign.run_campaign(options)
        @test run.completed == 1
        @test run.started == 1
        @test isfile(joinpath(
            options.campaign_dir,
            "outputs",
            "tiny",
            "summary.csv",
        ))
        @test isfile(joinpath(
            options.campaign_dir,
            "checkpoints",
            "tiny.jls",
        ))
        repeated = Campaign.run_campaign(options)
        @test repeated.skipped == 1
        @test repeated.completed == 0
    end
end

end
