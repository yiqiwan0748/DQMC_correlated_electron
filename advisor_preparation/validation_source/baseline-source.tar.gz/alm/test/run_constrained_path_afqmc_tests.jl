module RunConstrainedPathAFQMCTests

using AltermagnetDQMCTrial
using Serialization
using Test

include(joinpath(@__DIR__, "..", "scripts", "run_constrained_path_afqmc.jl"))
using .RunConstrainedPathAFQMC

@testset "CP-AFQMC command-line runner" begin
    defaults = parse_options(String[])
    @test defaults.L == 2
    @test defaults.U == 2.0
    @test defaults.trial == :free
    @test isnothing(parse_options(["--help"]))

    parsed = parse_options([
        "--U=4",
        "--Nup=3",
        "--Ndown=2",
        "--trial=stripe-x",
        "--field-strength=-0.02",
    ])
    @test parsed.U == 4.0
    @test (parsed.Nup, parsed.Ndown) == (3, 2)
    @test parsed.trial == :stripe_x
    @test parsed.field_strength == -0.02
    @test_throws ArgumentError parse_options(["--unknown=1"])
    @test_throws ArgumentError parse_options(["--trial=ferromagnetic"])

    mktempdir() do temporary
        output = joinpath(temporary, "cp-run")
        options = parse_options([
            "--L=2",
            "--U=0",
            "--Nup=1",
            "--Ndown=1",
            "--dtau=0.05",
            "--walkers=2",
            "--warmup=1",
            "--measurements=2",
            "--steps-between=1",
            "--orthogonalize-every=1",
            "--population-control-every=1",
            "--back-propagation-steps=1",
            "--minimum-backprop-ancestors=2",
            "--block-size=1",
            "--seed=8",
            "--output-dir=$output",
        ])
        run = run_calculation(options)
        @test run.output_dir == output
        @test isfile(joinpath(output, "summary.csv"))
        @test isfile(joinpath(output, "measurements.csv"))
        @test isfile(joinpath(output, "spin_structure.csv"))
        @test isfile(joinpath(output, "orbital_spin_structure_measurements.csv"))
        @test isfile(joinpath(output, "metadata.txt"))
        @test isfile(run.checkpoint_path)
        @test occursin(
            "backpropagated_double_occupancy_per_cell",
            read(joinpath(output, "summary.csv"), String),
        )
        measurement_lines = readlines(joinpath(output, "measurements.csv"))
        measurement_header = split(first(measurement_lines), ',')
        @test measurement_header[end-4:end] ==
            ["mx", "my", "m_fm", "delta_alm", "m_alm_squared"]
        @test length(run.result.order_measurements) == 2
        for (line, measurement, order) in zip(
            measurement_lines[2:end],
            run.result.measurements,
            run.result.order_measurements,
        )
            row = Dict(zip(measurement_header, split(line, ',')))
            @test parse(Int, row["step"]) == order.step == measurement.step
            for field in (:mx, :my, :m_fm, :delta_alm)
                @test parse(Float64, row[string(field)]) == getproperty(order, field)
            end
            @test parse(Float64, row["m_alm_squared"]) ==
                measurement.S_alm_q0 / run.result.problem.cell_count
        end
        summary_rows = Dict(
            columns[1] => columns[2:end] for columns in
            split.(readlines(joinpath(output, "summary.csv"))[2:end], ',')
        )
        for field in (:mx, :my, :m_fm, :delta_alm, :m_alm_squared)
            @test parse(Float64, summary_rows[string(field)][1]) ==
                getproperty(run.result.summary, field)
            @test parse(Float64, summary_rows[string(field)][2]) ==
                getproperty(run.result.summary, Symbol(field, :_standard_error))
        end
        payload = open(deserialize, run.checkpoint_path)
        @test isequal(payload.order_measurements, run.result.order_measurements)
        @test run.result.diagnostics.order_parameter_measurements == 2
        @test run.result.diagnostics.order_parameter_complete
        metadata = read(joinpath(output, "metadata.txt"), String)
        @test occursin(
            "constraint_scheme=local positive-overlap; no mirror correction",
            metadata,
        )
        @test occursin("julia_version=$(VERSION)", metadata)
        @test occursin("hostname=", metadata)
        @test occursin("system=$(Sys.KERNEL)", metadata)
        @test occursin("machine=$(Sys.MACHINE)", metadata)
        @test occursin("cpu_name=$(Sys.CPU_NAME)", metadata)
        @test occursin("julia_threads=", metadata)
        @test occursin("blas_threads=", metadata)
        @test occursin("blas_config=", metadata)
        @test_throws ArgumentError run_calculation(options)

        resumed_output = joinpath(temporary, "cp-resumed")
        resumed_options = parse_options([
            "--resume-from=$(run.checkpoint_path)",
            "--output-dir=$resumed_output",
        ])
        resumed = run_calculation(resumed_options)
        @test isequal(resumed.result.summary, run.result.summary)
        @test isequal(resumed.result.order_measurements, run.result.order_measurements)
        @test isfile(joinpath(resumed_output, "summary.csv"))
        @test read(joinpath(resumed_output, "measurements.csv"), String) ==
            read(joinpath(output, "measurements.csv"), String)
        @test read(
            joinpath(resumed_output, "orbital_spin_structure_measurements.csv"),
            String,
        ) == read(
            joinpath(output, "orbital_spin_structure_measurements.csv"),
            String,
        )

        mismatched_options = parse_options([
            "--resume-from=$(run.checkpoint_path)",
            "--output-dir=$(joinpath(temporary, "mismatch"))",
            "--U=3",
        ])
        @test_throws ArgumentError run_calculation(mismatched_options)

        common = [
            "--L=2",
            "--U=2",
            "--Nup=1",
            "--Ndown=1",
            "--dtau=0.04",
            "--walkers=4",
            "--warmup=4",
            "--measurements=3",
            "--steps-between=2",
            "--orthogonalize-every=2",
            "--population-control-every=2",
            "--back-propagation-steps=2",
            "--minimum-backprop-ancestors=1",
            "--block-size=1",
            "--seed=91",
            "--checkpoint-every-steps=1",
        ]
        uninterrupted_output = joinpath(temporary, "uninterrupted")
        uninterrupted_options = parse_options(vcat(
            common,
            [
                "--output-dir=$uninterrupted_output",
                "--checkpoint-path=$(joinpath(temporary, "uninterrupted.jls"))",
            ],
        ))
        uninterrupted = run_calculation(uninterrupted_options)

        interrupted_output = joinpath(temporary, "interrupted-original")
        interrupted_checkpoint = joinpath(temporary, "interrupted.jls")
        interrupted_options = parse_options(vcat(
            common,
            [
                "--output-dir=$interrupted_output",
                "--checkpoint-path=$interrupted_checkpoint",
            ],
        ))
        problem = two_orbital_cp_afqmc_problem(2, 2.0, 1, 1)
        controls = CPAFQMCParameters(
            dtau=0.04,
            walker_count=4,
            warmup_steps=4,
            measurement_count=3,
            steps_between_measurements=2,
            orthogonalize_every=2,
            population_control_every=2,
            back_propagation_steps=2,
            minimum_backprop_ancestors=1,
            error_block_size=1,
            seed=91,
        )
        state = initialize_cp_afqmc(problem, controls)
        step_cp_afqmc!(state)
        step_cp_afqmc!(state)
        RunConstrainedPathAFQMC._write_checkpoint(
            interrupted_checkpoint,
            interrupted_options,
            state,
            CPAFQMCMeasurement{Float64}[],
            2,
            0,
        )
        midrun_output = joinpath(temporary, "resumed-midrun")
        midrun_options = parse_options([
            "--resume-from=$interrupted_checkpoint",
            "--output-dir=$midrun_output",
        ])
        resumed_midrun = run_calculation(midrun_options)
        @test isequal(
            resumed_midrun.result.summary,
            uninterrupted.result.summary,
        )
        @test read(joinpath(midrun_output, "measurements.csv"), String) ==
            read(joinpath(uninterrupted_output, "measurements.csv"), String)

        @testset "Signed order resumes and legacy checkpoints" begin
            # Save after one measurement and halfway to the next one. This
            # exercises both the saved sample and the resumed random sequence.
            for legacy in (false, true)
                saved_state = initialize_cp_afqmc(problem, controls)
                for _ in 1:(controls.warmup_steps + controls.steps_between_measurements)
                    step_cp_afqmc!(saved_state)
                end
                sample = measure_cp_afqmc(saved_state; include_order=true)
                saved_measurements = [sample.measurement]
                saved_orders = NamedTuple[sample.order_measurement]
                step_cp_afqmc!(saved_state)
                label = legacy ? "legacy-measurement" : "signed-measurement"
                checkpoint = joinpath(temporary, "$label.jls")
                destination = joinpath(temporary, label)
                if legacy
                    # Keep this payload independent of the current writer so
                    # it really represents an old file without the sidecar.
                    open(checkpoint, "w") do io
                        serialize(io, (
                            format_version=1,
                            options=interrupted_options,
                            state=saved_state,
                            measurements=saved_measurements,
                            warmup_completed=controls.warmup_steps,
                            separation_completed=1,
                        ))
                    end
                    @test !hasproperty(open(deserialize, checkpoint), :order_measurements)
                else
                    RunConstrainedPathAFQMC._write_checkpoint(
                        checkpoint,
                        interrupted_options,
                        saved_state,
                        saved_measurements,
                        controls.warmup_steps,
                        1;
                        order_measurements=saved_orders,
                    )
                end
                resumed_measurement = run_calculation(parse_options([
                    "--resume-from=$checkpoint",
                    "--output-dir=$destination",
                ]))
                orders = resumed_measurement.result.order_measurements
                @test length(orders) == controls.measurement_count
                @test isequal(orders[2:end], uninterrupted.result.order_measurements[2:end])
                @test isequal(
                    open(deserialize, checkpoint).order_measurements,
                    orders,
                )
                actual_lines = readlines(joinpath(destination, "measurements.csv"))
                expected_lines = readlines(joinpath(uninterrupted_output, "measurements.csv"))
                # The additional estimator must not change any existing sample.
                @test [split(line, ',')[1:12] for line in actual_lines] ==
                    [split(line, ',')[1:12] for line in expected_lines]
                if legacy
                    @test orders[1].step == saved_measurements[1].step
                    for field in (:mx, :my, :m_fm, :delta_alm)
                        @test ismissing(getproperty(orders[1], field))
                        @test ismissing(getproperty(resumed_measurement.result.summary, field))
                        @test ismissing(getproperty(
                            resumed_measurement.result.summary,
                            Symbol(field, :_standard_error),
                        ))
                    end
                    @test resumed_measurement.result.diagnostics.order_parameter_measurements == 2
                    @test !resumed_measurement.result.diagnostics.order_parameter_complete
                    @test resumed_measurement.result.summary.m_alm_squared ==
                        uninterrupted.result.summary.m_alm_squared
                    @test split(actual_lines[2], ',')[13:16] == fill("", 4)
                    @test all(!isempty, split(actual_lines[3], ',')[13:16])
                else
                    @test isequal(orders, uninterrupted.result.order_measurements)
                    @test isequal(
                        resumed_measurement.result.summary,
                        uninterrupted.result.summary,
                    )
                    @test actual_lines == expected_lines
                end
            end
        end

        @testset "Reject misaligned signed-order checkpoint records" begin
            complete_payload = open(deserialize, uninterrupted.checkpoint_path)
            invalid_count = complete_payload.order_measurements[1:end-1]
            invalid_steps = copy(complete_payload.order_measurements)
            invalid_steps[1] = merge(
                invalid_steps[1],
                (step=invalid_steps[1].step + 1,),
            )
            for (label, invalid_orders) in (("count", invalid_count), ("step", invalid_steps))
                checkpoint = joinpath(temporary, "invalid-$label.jls")
                destination = joinpath(temporary, "invalid-$label")
                open(checkpoint, "w") do io
                    serialize(io, merge(complete_payload, (order_measurements=invalid_orders,)))
                end
                @test_throws ArgumentError run_calculation(parse_options([
                    "--resume-from=$checkpoint",
                    "--output-dir=$destination",
                ]))
                @test !ispath(destination)
            end
        end
    end
end

end
