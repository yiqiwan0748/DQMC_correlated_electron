using Test
using LinearAlgebra
using DelimitedFiles

if !isdefined(@__MODULE__, :RunSlaterJastrowStage1)
    include(joinpath(@__DIR__, "..", "scripts", "run_slater_jastrow_stage1.jl"))
end

@testset "Slater-Jastrow stage-one runner helpers" begin
    Run = RunSlaterJastrowStage1

    @testset "CLI validation and help" begin
        defaults = Run.parse_options(String[])
        @test defaults.measurements == 10000
        @test defaults.output_dir == abspath("results/slater_jastrow_stage1")
        @test isnothing(Run.parse_options(["--help"]))
        @test isnothing(Run.parse_options(["-h"]))
        parsed = Run.parse_options(["--measurements=1500", "--output-dir=stage one=check"])
        @test parsed.measurements == 1500
        @test parsed.output_dir == abspath("stage one=check")
        for arguments in (["measurements=1000"], ["--measurements"], ["--unknown=1000"],
                          ["--measurements="], ["--output-dir="],
                          ["--measurements=1000", "--measurements=1500"],
                          ["--output-dir=one", "--output-dir=two"])
            @test_throws ArgumentError Run.parse_options(arguments)
        end
        for value in ("0", "999", "1001", "-1000", "NaN", "1000.0", "true")
            @test_throws ArgumentError Run.parse_options(["--measurements=$value"])
        end
        @test_throws OverflowError Run.parse_options([
            "--measurements=$(big(typemax(Int)) + 1)",
        ])
        @test Run.parse_options(["--measurements=1000"]).measurements == 1000
    end

    @testset "Existing outputs are never overwritten" begin
        mktempdir() do directory
            sentinel = joinpath(directory, "sentinel.txt")
            open(sentinel, "w") do io
                write(io, "preserve existing result\n")
            end
            original = read(sentinel)
            original_entries = readdir(directory)
            @test_throws ArgumentError Run.run_study((output_dir=directory, measurements=1000))
            @test readdir(directory) == original_entries
            @test read(sentinel) == original
            @test_throws ArgumentError Run.run_study((output_dir=sentinel, measurements=1000))
            @test read(sentinel) == original
        end
    end

    @testset "CSV escaping and schema validation" begin
        mktempdir() do directory
            path = joinpath(directory, "roundtrip.csv")
            labels = ["plain", "comma,value", "double\"quote", "line\nbreak", ""]
            rows = [(label=label, number=index, check=index / 4) for (index, label) in enumerate(labels)]
            Run.write_rows(path, rows)
            values, header = readdlm(path, ',', Any, '\n'; header=true)
            @test vec(header) == ["label", "number", "check"]
            @test size(values) == (length(labels), 3)
            @test values[:, 1] == labels
            @test values[:, 2] == collect(1:length(labels))
            @test values[:, 3] == collect(1:length(labels)) ./ 4
            @test occursin("\"comma,value\"", read(path, String))
            @test occursin("\"double\"\"quote\"", read(path, String))
            @test occursin("\"line\nbreak\"", read(path, String))
            @test_throws ArgumentError Run.write_rows(joinpath(directory, "empty.csv"), NamedTuple[])
            @test !isfile(joinpath(directory, "empty.csv"))
            @test_throws ErrorException Run.write_rows(joinpath(directory, "bad.csv"),
                                                       [(x=1, y=2), (y=3, x=4)])
        end
    end

    @testset "Analytic dimer helper" begin
        mktempdir() do directory
            Run.dimer_checks(directory)
            values, header = readdlm(joinpath(directory, "analytic_dimers.csv"), ',', Float64, '\n'; header=true)
            columns = Dict(name => index for (index, name) in enumerate(vec(header)))
            @test size(values) == (4, 9)
            @test values[:, columns["U"]] == [0.0, 4.0, 12.0, 20.0]
            # The optimizer stops at g tolerance 1e-6; energy is stationary
            # there and converges quadratically, while double occupancy does not.
            @test maximum(abs, values[:, columns["g"]] - values[:, columns["analytic_g"]]) < 2e-6
            @test maximum(values[:, columns["absolute_error"]]) <= 2e-10
            @test maximum(values[:, columns["energy_variance"]]) <= 1e-8
            @test maximum(abs, values[:, columns["double_occupancy"]] -
                               values[:, columns["exact_double_occupancy"]]) <= 2e-6
        end
    end

    @testset "Complete ground space and uniform mixture" begin
        # Two zero-energy spatial modes give four ground states in Nup=Ndown=1.
        # The other modes are separated by an exact unit gap. The Hamiltonian
        # is diagonal, so roundoff tolerances of 1e-12 are conservative.
        kinetic = Matrix(Diagonal([0.0, 0.0, 1.0, 1.0, 2.0, 2.0, 3.0, 3.0]))
        H = Run.SJ.benchmark_hamiltonian(kinetic, 0.0, 1, 1)
        ground = Run.exact_ground_space(H)
        @test ground.rank == 4
        @test size(ground.vectors) == (64, 4)
        @test isapprox(ground.energy, 0.0; atol=1e-12, rtol=0)
        @test isapprox(ground.gap, 1.0; atol=1e-12, rtol=1e-12)
        @test ground.residual <= 1e-12
        @test isapprox(transpose(ground.vectors) * ground.vectors, Matrix{Float64}(I, 4, 4);
                       atol=1e-12, rtol=1e-12)
        diagonal = Run.SJ.diagonal_observables(H; Lx=2, Ly=2)
        ground_indices = [1, 2, 9, 10]
        for name in keys(diagonal)
            expected = sum(diagonal[name][ground_indices]) / 4
            @test isapprox(ground.means[name], expected; atol=1e-12, rtol=1e-12)
        end
        @test isapprox(ground.means.delta_alm, 0.0; atol=1e-12, rtol=0)
        @test isapprox(ground.means.m_alm_squared, 1 / 32; atol=1e-12, rtol=1e-12)

        # A larger unresolved ground space must fail, not return a partial mixture.
        fully_degenerate = Run.SJ.benchmark_hamiltonian(zeros(8, 8), 0.0, 1, 1)
        @test_throws ErrorException Run.exact_ground_space(fully_degenerate)
        vacuum = Run.SJ.benchmark_hamiltonian(kinetic, 0.0, 0, 0)
        vacuum_ground = Run.exact_ground_space(vacuum)
        @test vacuum_ground.rank == 1
        @test size(vacuum_ground.vectors) == (1, 1)
        @test isnan(vacuum_ground.gap)
        @test all(iszero, vacuum_ground.means)
    end
end
