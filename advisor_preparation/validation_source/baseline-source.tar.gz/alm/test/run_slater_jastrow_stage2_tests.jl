using Test
using LinearAlgebra

if !isdefined(@__MODULE__, :RunSlaterJastrowStage2)
    include(joinpath(@__DIR__, "..", "scripts", "run_slater_jastrow_stage2.jl"))
end

@testset "Slater-Jastrow spin-stage runner helpers" begin
    Run = RunSlaterJastrowStage2
    SJ, SY = Run.SJ, Run.SY

    @testset "Options and output preservation" begin
        @test isnothing(Run.parse_options(["--help"]))
        @test isnothing(Run.parse_options(["-h"]))
        defaults = Run.parse_options(String[])
        @test defaults.output_dir == abspath("results/slater_jastrow_stage2")
        @test defaults.stage1_dir == abspath("results/slater_jastrow_stage1_20260911_v2")
        parsed = Run.parse_options(["--output-dir=a=b", "--stage1-dir=prior results"])
        @test parsed.output_dir == abspath("a=b")
        @test parsed.stage1_dir == abspath("prior results")
        for args in (["output-dir=x"], ["--output-dir"], ["--output-dir="],
                     ["--output-dir=a", "--output-dir=b"], ["--unknown=x"],
                     ["--stage1-dir="], ["--stage1-dir=x", "--stage1-dir=y"])
            @test_throws ArgumentError Run.parse_options(args)
        end
        mktempdir() do directory
            @test_throws ArgumentError Run.run_study((output_dir=directory,))
            @test isempty(readdir(directory))
        end
    end

    @testset "Vector Jastrow and energy-only optimization" begin
        for U in (0.0, 4.0, 12.0, 20.0)
            H = SJ.benchmark_hamiltonian([0.0 -1.0; -1.0 0.0], U, 1, 1)
            trial = Run.SlaterTrial(ones(2, 1), ones(2, 1))
            base = SJ.onsite_jastrow_state(H, trial)
            make_state = Run.jastrow_on_vector(H, base)
            for g in (0.0, 0.5, 1.0, 1000.0)
                # Identical formulas should differ only by normalization roundoff.
                @test isapprox(make_state(g), SJ.onsite_jastrow_state(H, trial; g=g);
                               atol=2e-14, rtol=2e-14)
            end
            fit = Run.optimize_g(H, make_state)
            # The energy is stationary in g, giving a quadratic tolerance gain.
            @test isapprox(fit.g, asinh(U / 4); atol=2e-6, rtol=0)
            @test isapprox(fit.energy, -hypot(U, 4) / 2; atol=2e-10, rtol=0)
            @test isapprox(norm(fit.state), 1; atol=2e-14, rtol=0)
            @test fit.boundary_hit == iszero(U)
            @test length(fit.history) >= 25
            @test fit.energy == minimum(row.energy for row in fit.history)
        end
        H = SJ.benchmark_hamiltonian(zeros(2, 2), 0.0, 1, 1)
        make_state = Run.jastrow_on_vector(H, [1.0, 2.0, -3.0, 4.0])
        flat = Run.optimize_g(H, make_state)
        @test flat.g == 0.0
        @test length(flat.history) == 25
        for bounds in ((0.0,), (0.0, 0.0), (-1.0, 2.0), (NaN, 2.0), (0.0, Inf))
            @test_throws ArgumentError Run.optimize_g(H, make_state; bounds=bounds)
        end
        for tolerance in (0.0, -1.0, NaN, Inf, true, eps(Float64))
            @test_throws ArgumentError Run.optimize_g(H, make_state; tolerance=tolerance)
        end
        for grid_points in (0, 2, 3.5, true)
            @test_throws ArgumentError Run.optimize_g(H, make_state; grid_points=grid_points)
        end
        @test_throws ArgumentError Run.jastrow_on_vector(H, zeros(4))
        @test_throws DimensionMismatch Run.jastrow_on_vector(H, ones(3))
    end

    @testset "Mixture variance and full degenerate spin resolution" begin
        left = (energy=1.0, energy_variance=0.0, s2_mean=0.0, s2_variance=0.0,
                delta_alm=0.75, m_alm_squared=0.6)
        right = (energy=3.0, energy_variance=0.0, s2_mean=2.0, s2_variance=0.0,
                 delta_alm=-0.75, m_alm_squared=0.6)
        mixed = Run.mixture_evaluation(left, right)
        @test mixed.energy == 2.0
        @test mixed.energy_variance == 1.0
        @test mixed.s2_mean == 1.0
        @test mixed.s2_variance == 1.0
        @test mixed.delta_alm == 0.0
        @test mixed.m_alm_squared == 0.6
        @test mixed == Run.ensemble_evaluation([left, right])
        @test Run.ensemble_evaluation([left]) == left
        @test_throws ArgumentError Run.ensemble_evaluation(NamedTuple[])
        @test_throws ArgumentError Run.mixture_evaluation(left, (energy=1.0,))
        @test_throws ArgumentError Run.ensemble_evaluation([left, (energy=1.0,)])
        H = SJ.benchmark_hamiltonian(zeros(2, 2), 0.0, 1, 1)
        ops = SY.spin_operators(H)
        # Arbitrary orthonormal rotation mixes the three singlets and triplet.
        vectors = Matrix(qr([1.0 2 3 4; 2 0 -1 3; 0 2 1 -1; 1 -3 2 0]).Q)
        resolved = Run.spin_resolved_ground(H, ops, (vectors=vectors,))
        @test sort(getproperty.(resolved.rows, :spin)) == [0, 0, 0, 1]
        @test maximum(getproperty.(resolved.rows, :spin_residual)) < 1e-12
        @test isapprox(transpose(resolved.vectors) * resolved.vectors,
                       Matrix{Float64}(I, 4, 4); atol=2e-14, rtol=2e-14)
        @test all(row -> abs(row.energy) < 1e-14, resolved.rows)
        # A subspace containing a mixture but not its partner cannot resolve S².
        mixed_spin = normalize([0.0, 1.0, 0.0, 0.0])
        @test_throws ErrorException Run.spin_resolved_ground(H, ops,
            (vectors=reshape(mixed_spin, :, 1),))
    end
end
