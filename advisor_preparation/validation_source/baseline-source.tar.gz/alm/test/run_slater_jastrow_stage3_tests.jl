using Test
using LinearAlgebra
using Serialization
using TOML
using Random

if !isdefined(@__MODULE__, :RunSlaterJastrowStage3)
    include(joinpath(@__DIR__, "..", "scripts", "run_slater_jastrow_stage3.jl"))
end

@testset "Correlated AFQMC validation runner" begin
    Run = RunSlaterJastrowStage3
    SJ, CA = Run.SJ, Run.CA

    @testset "Explicit profiles and resume guards" begin
        defaults = Run.parse_options(String[])
        @test defaults.profile == "quick"
        @test !defaults.resume
        @test isnothing(Run.parse_options(["--help"]))
        parsed = Run.parse_options(["--profile=pilot", "--resume=true", "--output-dir=a=b"])
        @test parsed.profile == "pilot" && parsed.resume
        @test parsed.output_dir == abspath("a=b")
        projection_options = Run.parse_options(["--profile=projection", "--resume=true"])
        @test projection_options.profile == "projection"
        @test projection_options.resume
        population_options = Run.parse_options(["--profile=population", "--resume=true"])
        @test population_options.profile == "population"
        @test population_options.resume
        sampling_options = Run.parse_options(["--profile=sampling", "--resume=true"])
        @test sampling_options.profile == "sampling"
        @test sampling_options.resume
        ed_sampling_options = Run.parse_options(["--profile=ed_sampling", "--resume=true"])
        @test ed_sampling_options.profile == "ed_sampling"
        @test ed_sampling_options.resume
        for args in (["--profile=bad"], ["--resume=yes"], ["--resume="], ["--output-dir"],
                     ["--unknown=x"], ["profile=quick"], ["--profile=pilot", "--profile=quick"])
            @test_throws ArgumentError Run.parse_options(args)
        end
        @test_throws ArgumentError Run.validation_plan("unknown")
        for status in ("running", "interrupted", "complete")
            @test isnothing(Run.check_resume_status(Dict("status" => status)))
        end
        for status in ("failed", "interrupted_or_failed", "")
            @test_throws ArgumentError Run.check_resume_status(Dict("status" => status))
        end
        @test_throws ArgumentError Run.check_resume_status(Dict{String,String}())
        @test length(Run.validation_plan("pilot")) == 3
        @test length(Run.validation_plan("quick")) == 19
        @test length(Run.validation_plan("extended")) == 25
        @test length(Run.validation_plan("projection")) == 12
        @test length(Run.validation_plan("population")) == 6
        @test length(Run.validation_plan("sampling")) == 6
        @test length(Run.validation_plan("ed_sampling")) == 6
        @test Run.validation_plan("extended")[1:19] == Run.validation_plan("quick")
        for profile in ("pilot", "quick", "extended", "projection", "population", "sampling", "ed_sampling")
            jobs = Run.validation_plan(profile)
            @test length(unique(row.id for row in jobs)) == length(jobs)
            for job in jobs
                params = Run.parameters(job)
                @test params.warmup_steps >= params.back_propagation_steps
                @test params.measurement_count >= 2params.error_block_size
                @test isapprox(params.warmup_steps * params.dtau, job.warmup_time;
                               atol=1e-12, rtol=1e-12)
            end
        end
        job = first(Run.validation_plan("pilot"))
        @test_throws ArgumentError Run.parameters(merge(job, (warmup_time=0.123,)))
        mktempdir() do directory
            @test_throws ArgumentError Run.run_study((output_dir=directory, resume=false))
            @test_throws ArgumentError Run.run_study((output_dir=joinpath(directory, "missing"), resume=true))
            @test isempty(readdir(directory))
        end
    end

    @testset "Projection-only plan and checkpoint isolation" begin
        quick = Run.validation_plan("quick")
        projection = Run.validation_plan("projection")
        @test Set(job.warmup_time for job in projection) == Set((32.0, 64.0))
        @test Set(job.seed for job in projection) == Set((61411, 61412, 61413))
        @test Set(job.family for job in projection) == Set(("bare", "spin_0"))
        @test isempty(intersect(Set(job.id for job in quick), Set(job.id for job in projection)))
        @test length(unique((job.warmup_time, job.seed, job.family) for job in projection)) == 12
        for job in projection
            original = only(filter(candidate -> candidate.family == job.family &&
                candidate.seed == job.seed && candidate.dtau == job.dtau, quick))
            expected_id = "projection_tau$(job.warmup_time)_$(job.family)_dt0.02_seed$(job.seed)"
            @test job.id == expected_id
            @test job == merge(original, (id=expected_id, warmup_time=job.warmup_time))
            @test job.dtau == 0.02 && job.walkers == 64
            @test job.measurements == 24 && job.spacing == 0.08
            @test job.bp_time == 0.8 && job.block_size == 4
            original_params, params = Run.parameters(original), Run.parameters(job)
            @test params.warmup_steps == (job.warmup_time == 32.0 ? 1600 : 3200)
            for key in fieldnames(typeof(params))
                key == :warmup_steps && continue
                @test getproperty(params, key) == getproperty(original_params, key)
            end
        end

        H = SJ.benchmark_hamiltonian([0.0 -1.0; -1.0 0.0], 0.0, 1, 1)
        initializer = Run.SlaterTrial([1.0; 0.2;;], [0.3; 1.0;;])
        trial_state = SJ.onsite_jastrow_state(H, initializer)
        inputs = (H=H, inputs=Dict("bare" => (state=trial_state,)),
                  hashes=Dict("bare" => "projection-test-input"), initializer=initializer)
        hashes = Dict("test" => "projection-test-source")
        quick_job = only(filter(job -> job.family == "bare" && job.seed == 61411 &&
            job.dtau == 0.02, quick))
        job32 = only(filter(job -> job.family == "bare" && job.seed == 61411 &&
            job.warmup_time == 32.0, projection))
        job64 = only(filter(job -> job.family == "bare" && job.seed == 61411 &&
            job.warmup_time == 64.0, projection))
        function initialized_checkpoint(job)
            state = CA.initialize_correlated_afqmc(H, Run.parameters(job);
                trial_state=trial_state, initializer=initializer, Lx=1, Ly=1)
            return (format="correlated-afqmc-stage3-checkpoint-v1", job=job,
                    state=state, rows=NamedTuple[], source_hashes=hashes,
                    input_hashes=inputs.hashes)
        end
        quick_checkpoint = initialized_checkpoint(quick_job)
        checkpoint32 = initialized_checkpoint(job32)
        checkpoint64 = initialized_checkpoint(job64)
        for (checkpoint, job) in ((quick_checkpoint, quick_job),
                                 (checkpoint32, job32), (checkpoint64, job64))
            @test isnothing(Run.validate_checkpoint(checkpoint, job, inputs, hashes))
        end
        @test_throws ErrorException Run.validate_checkpoint(quick_checkpoint, job32, inputs, hashes)
        @test_throws ErrorException Run.validate_checkpoint(checkpoint32, job64, inputs, hashes)
        @test_throws ErrorException Run.validate_checkpoint(checkpoint64, job32, inputs, hashes)
        # Relabeling a checkpoint cannot bypass its stored propagation parameters.
        @test_throws ErrorException Run.validate_checkpoint(
            merge(quick_checkpoint, (job=job32,)), job32, inputs, hashes)
        @test_throws ErrorException Run.validate_checkpoint(
            merge(checkpoint32, (job=job64,)), job64, inputs, hashes)
        @test_throws ErrorException Run.validate_checkpoint(
            merge(checkpoint64, (job=job32,)), job32, inputs, hashes)
    end

    @testset "Population-only comparison and measurement extension" begin
        population = Run.validation_plan("population")
        expected = [(id="population_W$(walkers)_spin_0_dt0.02_seed$(seed)", family="spin_0",
            seed=seed, dtau=0.02, walkers=walkers, warmup_time=64.0,
            measurements=96, spacing=0.08, bp_time=0.8, block_size=4)
            for walkers in (64, 128) for seed in (61411, 61412, 61413)]
        @test population == expected
        @test length(unique((job.walkers, job.seed) for job in population)) == 6
        projection = Run.validation_plan("projection")
        for profile in ("pilot", "quick", "extended", "projection")
            @test isempty(intersect(Set(job.id for job in Run.validation_plan(profile)),
                                    Set(job.id for job in population)))
        end
        for job in population
            baseline = only(filter(candidate -> candidate.family == job.family &&
                candidate.seed == job.seed && candidate.warmup_time == 64.0, projection))
            @test job == merge(baseline, (id=job.id, walkers=job.walkers, measurements=96))
            params, old_params = Run.parameters(job), Run.parameters(baseline)
            @test params.measurement_count == 96
            @test params.walker_count == job.walkers
            @test params.measurement_count ÷ params.error_block_size == 24
            for key in fieldnames(typeof(params))
                key in (:measurement_count, :walker_count) && continue
                @test getproperty(params, key) == getproperty(old_params, key)
            end
        end
        for seed in (61411, 61412, 61413)
            job64 = only(filter(job -> job.walkers == 64 && job.seed == seed, population))
            job128 = only(filter(job -> job.walkers == 128 && job.seed == seed, population))
            @test job128 == merge(job64, (id=job128.id, walkers=128))
            params64, params128 = Run.parameters(job64), Run.parameters(job128)
            for key in fieldnames(typeof(params64))
                key == :walker_count && continue
                @test getproperty(params64, key) == getproperty(params128, key)
            end
        end

        function expected_job(tag, family, seed, dtau, walkers, warmup, measurements, bp)
            (id="$(tag)_$(family)_dt$(dtau)_seed$(seed)", family=family, seed=seed,
             dtau=dtau, walkers=walkers, warmup_time=warmup, measurements=measurements,
             spacing=0.08, bp_time=bp, block_size=4)
        end
        pilot = [expected_job("pilot", family, 61411, 0.04, 16, 0.8, 8, 0.32)
                 for family in ("bare", "single_jastrow", "spin_0")]
        quick = [expected_job("base", family, seed, dt, 64, 4.0, 24, 0.8)
                 for dt in (0.04, 0.02) for seed in (61411, 61412, 61413)
                 for family in ("bare", "single_jastrow", "spin_0")]
        push!(quick, expected_job("algebraic", "ed_control", 61411, 0.02, 32, 2.0, 12, 0.4))
        extended = vcat(quick, [expected_job("longer", family, seed, 0.02, 128, 8.0, 40, 1.6)
            for seed in (61411, 61412, 61413) for family in ("bare", "spin_0")])
        projected = [expected_job("projection_tau$(warmup)", family, seed, 0.02, 64, warmup, 24, 0.8)
            for warmup in (32.0, 64.0) for seed in (61411, 61412, 61413) for family in ("bare", "spin_0")]
        @test Run.validation_plan("pilot") == pilot
        @test Run.validation_plan("quick") == quick
        @test Run.validation_plan("extended") == extended
        @test projection == projected

        H = SJ.benchmark_hamiltonian([0.0 -1.0; -1.0 0.0], 0.0, 1, 1)
        initializer = Run.SlaterTrial([1.0; 0.2;;], [0.3; 1.0;;])
        trial_state = SJ.onsite_jastrow_state(H, initializer)
        inputs = (H=H, inputs=Dict("spin_0" => (state=trial_state,)),
                  hashes=Dict("spin_0" => "population-test-input"), initializer=initializer)
        hashes = Dict("test" => "population-test-source")
        baseline = only(filter(job -> job.family == "spin_0" && job.seed == 61411 &&
            job.warmup_time == 64.0, projection))
        job64 = only(filter(job -> job.walkers == 64 && job.seed == 61411, population))
        job128 = only(filter(job -> job.walkers == 128 && job.seed == 61411, population))
        function initialized_checkpoint(job)
            state = CA.initialize_correlated_afqmc(H, Run.parameters(job);
                trial_state=trial_state, initializer=initializer, Lx=1, Ly=1)
            (format="correlated-afqmc-stage3-checkpoint-v1", job=job, state=state,
             rows=NamedTuple[], source_hashes=hashes, input_hashes=inputs.hashes)
        end
        baseline_checkpoint = initialized_checkpoint(baseline)
        checkpoint64, checkpoint128 = initialized_checkpoint(job64), initialized_checkpoint(job128)
        for (checkpoint, job) in ((baseline_checkpoint, baseline),
                                 (checkpoint64, job64), (checkpoint128, job128))
            @test isnothing(Run.validate_checkpoint(checkpoint, job, inputs, hashes))
        end
        for (checkpoint, changed_job) in ((baseline_checkpoint, job64),
            (checkpoint64, baseline), (checkpoint64, job128), (checkpoint128, job64))
            @test_throws ErrorException Run.validate_checkpoint(checkpoint, changed_job, inputs, hashes)
            # The stored parameters still reject reuse after only the job label changes.
            @test_throws ErrorException Run.validate_checkpoint(
                merge(checkpoint, (job=changed_job,)), changed_job, inputs, hashes)
        end
    end

    @testset "Longer sampling plan and starting-state isolation" begin
        sampling = Run.validation_plan("sampling")
        expected = [(id="sampling_$(initializer)_spin_0_dt0.02_seed$(seed)", family="spin_0",
            seed=seed, dtau=0.02, walkers=128, warmup_time=64.0,
            measurements=384, spacing=0.08, bp_time=0.8, block_size=4,
            initializer=initializer)
            for initializer in ("common", "weak_field") for seed in (91421, 91422, 91423)]
        @test sampling == expected
        @test length(unique((job.initializer, job.seed) for job in sampling)) == 6
        for profile in ("pilot", "quick", "extended", "projection", "population")
            previous = Run.validation_plan(profile)
            @test all(!hasproperty(job, :initializer) for job in previous)
            @test isempty(intersect(Set(job.seed for job in sampling), Set(job.seed for job in previous)))
            @test isempty(intersect(Set(job.id for job in sampling), Set(job.id for job in previous)))
        end
        population = Run.validation_plan("population")
        baseline = only(filter(job -> job.walkers == 128 && job.seed == 61411, population))
        for job in sampling
            @test job == merge(baseline, (id=job.id, seed=job.seed,
                measurements=384, initializer=job.initializer))
            params, old_params = Run.parameters(job), Run.parameters(baseline)
            @test params.warmup_steps == 3200
            @test params.measurement_count == 384
            @test params.measurement_count ÷ params.error_block_size == 96
            @test params.back_propagation_steps == 40
            @test params.steps_between_measurements == 4
            for key in fieldnames(typeof(params))
                key in (:measurement_count, :seed) && continue
                @test getproperty(params, key) == getproperty(old_params, key)
            end
        end
        for seed in (91421, 91422, 91423)
            common = only(filter(job -> job.initializer == "common" && job.seed == seed, sampling))
            weak = only(filter(job -> job.initializer == "weak_field" && job.seed == seed, sampling))
            @test weak == merge(common, (id=weak.id, initializer="weak_field"))
            @test Run.parameters(common) == Run.parameters(weak)
        end

        H = SJ.benchmark_hamiltonian(SJ.ED.open_cluster_kinetic_matrix(2, 2), 0.0, 1, 1)
        problem = Run.CPAFQMCProblem(H.kinetic, H.U, 1, 1; lattice_size=2, cell_count=4)
        initializer = Run.one_body_trial(problem; pattern=:altermagnetic, field_strength=2.0)
        weak_expected = Run.one_body_trial(problem; pattern=:altermagnetic, field_strength=1.0)
        trial_state = SJ.onsite_jastrow_state(H, initializer)
        inputs = (H=H, inputs=Dict("spin_0" => (state=trial_state,)),
            hashes=Dict("spin_0" => "sampling-test-input"), initializer=initializer)
        hashes = Dict("test" => "sampling-test-source")
        common = sampling[1]
        weak = only(filter(job -> job.initializer == "weak_field" && job.seed == common.seed, sampling))
        @test Run.job_initializer(inputs, baseline) === initializer
        @test Run.job_initializer(inputs, common) === initializer
        weak_actual = Run.job_initializer(inputs, weak)
        @test weak_actual.up == weak_expected.up
        @test weak_actual.down == weak_expected.down
        @test norm(weak_actual.up * weak_actual.up' - initializer.up * initializer.up') > 1e-3
        @test norm(weak_actual.down * weak_actual.down' - initializer.down * initializer.down') > 1e-3
        @test_throws ArgumentError Run.job_initializer(inputs, merge(common, (initializer="unknown",)))

        function initialized_checkpoint(job)
            state = CA.initialize_correlated_afqmc(H, Run.parameters(job);
                trial_state=trial_state, initializer=Run.job_initializer(inputs, job), Lx=2, Ly=2)
            (format="correlated-afqmc-stage3-checkpoint-v1", job=job, state=state,
             rows=NamedTuple[], source_hashes=hashes, input_hashes=inputs.hashes)
        end
        baseline_checkpoint = initialized_checkpoint(baseline)
        common_checkpoint = initialized_checkpoint(common)
        weak_checkpoint = initialized_checkpoint(weak)
        for (checkpoint, job) in ((baseline_checkpoint, baseline),
            (common_checkpoint, common), (weak_checkpoint, weak))
            @test isnothing(Run.validate_checkpoint(checkpoint, job, inputs, hashes))
        end
        for (checkpoint, changed_job) in ((baseline_checkpoint, common),
            (common_checkpoint, baseline), (common_checkpoint, weak), (weak_checkpoint, common))
            @test_throws ErrorException Run.validate_checkpoint(checkpoint, changed_job, inputs, hashes)
            # Equal propagation parameters cannot hide a relabeled starting state.
            @test_throws ErrorException Run.validate_checkpoint(
                merge(checkpoint, (job=changed_job,)), changed_job, inputs, hashes)
        end
        @test common_checkpoint.state.oracle.trial == weak_checkpoint.state.oracle.trial
        @test common_checkpoint.state.base.parameters == weak_checkpoint.state.base.parameters
    end

    @testset "Exact-trial sampling plan and trial-family isolation" begin
        sampling = Run.validation_plan("sampling")
        exact = Run.validation_plan("ed_sampling")
        expected = [(id="ed_sampling_$(initializer)_ed_control_dt0.02_seed$(seed)", family="ed_control",
            seed=seed, dtau=0.02, walkers=128, warmup_time=64.0,
            measurements=384, spacing=0.08, bp_time=0.8, block_size=4,
            initializer=initializer)
            for initializer in ("common", "weak_field") for seed in (91421, 91422, 91423)]
        @test exact == expected
        for profile in ("pilot", "quick", "extended", "projection", "population", "sampling")
            @test isempty(intersect(Set(job.id for job in exact),
                                    Set(job.id for job in Run.validation_plan(profile))))
        end
        for (control, baseline) in zip(exact, sampling)
            @test control == merge(baseline, (id=control.id, family="ed_control"))
            @test Run.parameters(control) == Run.parameters(baseline)
            @test keys(control) == keys(baseline)
        end

        # A connected unfrustrated fixture avoids symmetry-orthogonal one-particle starts.
        kinetic = Matrix(SymTridiagonal(zeros(8), -ones(7)))
        H = SJ.benchmark_hamiltonian(kinetic, 12.0, 1, 1)
        problem = Run.CPAFQMCProblem(H.kinetic, H.U, 1, 1; lattice_size=2, cell_count=4)
        initializer = Run.one_body_trial(problem; pattern=:altermagnetic, field_strength=2.0)
        spin_state = SJ.onsite_jastrow_state(H, initializer)
        ground = Run.Stage1.exact_ground_space(H)
        exact_state = ground.vectors[:, 1]
        @test min(norm(exact_state - spin_state), norm(exact_state + spin_state)) > 1e-3
        inputs = (H=H, inputs=Dict("spin_0" => (state=spin_state,),
            "ed_control" => (state=exact_state,)),
            hashes=Dict("spin_0" => "ed-plan-spin-input", "ed_control" => "ed-plan-exact-input"),
            initializer=initializer)
        hashes = Dict("test" => "ed-plan-source")
        function initialized_checkpoint(job)
            state = CA.initialize_correlated_afqmc(H, Run.parameters(job);
                trial_state=inputs.inputs[job.family].state,
                initializer=Run.job_initializer(inputs, job), Lx=2, Ly=2)
            (format="correlated-afqmc-stage3-checkpoint-v1", job=job, state=state,
             rows=NamedTuple[], source_hashes=hashes, input_hashes=inputs.hashes)
        end
        for (control, baseline) in zip(exact, sampling)
            @test Run.job_initializer(inputs, control).up == Run.job_initializer(inputs, baseline).up
            @test Run.job_initializer(inputs, control).down == Run.job_initializer(inputs, baseline).down
            selected = Run.job_initializer(inputs, control)
            @test abs(dot(exact_state, CA.determinant_amplitudes(H, selected.up, selected.down))) > 1e-6
            checkpoint = initialized_checkpoint(control)
            baseline_checkpoint = initialized_checkpoint(baseline)
            @test isnothing(Run.validate_checkpoint(checkpoint, control, inputs, hashes))
            @test isnothing(Run.validate_checkpoint(baseline_checkpoint, baseline, inputs, hashes))
            @test checkpoint.state.base.parameters == baseline_checkpoint.state.base.parameters
            for (saved, changed_job) in ((checkpoint, baseline), (baseline_checkpoint, control))
                @test_throws ErrorException Run.validate_checkpoint(saved, changed_job, inputs, hashes)
                # The job label alone cannot change the stored correlated trial.
                @test_throws ErrorException Run.validate_checkpoint(
                    merge(saved, (job=changed_job,)), changed_job, inputs, hashes)
            end
            @test min(norm(checkpoint.state.oracle.trial - exact_state),
                      norm(checkpoint.state.oracle.trial + exact_state)) <= 1e-12
        end
    end

    @testset "Both starting states replay and match the U=0 reference" begin
        all_summaries = NamedTuple[]
        originals = Dict{Tuple{String,String},Any}()
        for (family, kinetic) in (("spin_0", SJ.ED.open_cluster_kinetic_matrix(2, 2)),
                                  ("ed_control", Matrix(SymTridiagonal(zeros(8), -ones(7)))))
            H = SJ.benchmark_hamiltonian(kinetic, 0.0, 1, 1)
            problem = Run.CPAFQMCProblem(H.kinetic, H.U, 1, 1; lattice_size=2, cell_count=4)
            initializer = Run.one_body_trial(problem; pattern=:altermagnetic, field_strength=2.0)
            trial_state = SJ.onsite_jastrow_state(H, initializer)
            ground = Run.Stage1.exact_ground_space(H)
            inputs = (H=H, inputs=Dict("spin_0" => (state=trial_state,),
                "ed_control" => (state=ground.vectors[:, 1],)),
                hashes=Dict("spin_0" => "sampling-replay-input", "ed_control" => "ed-replay-input"),
                initializer=initializer)
            hashes = Dict("test" => "sampling-replay-source")
            base_job = (id="sampling_replay", family="spin_0", seed=91421, dtau=0.04, walkers=2,
                warmup_time=0.16, measurements=4, spacing=0.08, bp_time=0.08, block_size=2)
            old_summary_keys = (:job_id, :family, :dtau, :seed, :walkers, :warmup_time, :bp_time,
                :estimator, :quantity, :mean, :error, :blocks, :exact_finite_time_mean,
                :finite_time_reference_drift, :difference_from_finite_time, :difference_error,
                :ed, :difference_from_ed, :minimum_ancestors)
            mktempdir() do root
                for label in ("common", "weak_field")
                    job = merge(base_job, (id="sampling_replay_$(family)_$(label)", family=family, initializer=label))
                    params = Run.parameters(job)
                    selected = Run.job_initializer(inputs, job)
                    @test abs(dot(inputs.inputs[family].state,
                                  CA.determinant_amplitudes(H, selected.up, selected.down))) > 1e-6
                    original_directory = joinpath(root, "original_$(family)_$(label)")
                    original = Run.run_job(job, original_directory, inputs, hashes)
                    originals[(family, label)] = original
                    original_checkpoint = deserialize(joinpath(original_directory, "jobs", job.id, "checkpoint.jls"))
                    for row in original, prefix in ("mixed", "bp"), quantity in
                        (:energy, :delta_alm, :m_alm_squared, :double_occupancy_total,
                         :odd_q0, :odd_qx, :odd_qy, :odd_qxy)
                        key = Symbol(prefix * "_" * string(quantity))
                        reference_key = Symbol("reference_" * string(key))
                        # At U=0 every HS field gives the same exact one-body path;
                        # the tolerance covers QR and Float64 contraction roundoff.
                        @test isapprox(getproperty(row, key), getproperty(row, reference_key);
                                       atol=2e-11, rtol=2e-11)
                    end
                    summaries = Run.summarize(job, original, ground)
                    append!(all_summaries, summaries)
                    legacy_summaries = Run.summarize(merge(base_job, (id=job.id, family=family)), original, ground)
                    @test length(summaries) == length(legacy_summaries) == 16
                    for (summary, legacy) in zip(summaries, legacy_summaries)
                        @test keys(legacy) == old_summary_keys
                        @test summary.initializer == label
                        @test Base.structdiff(summary, (initializer=label,)) == legacy
                    end
                    for completed in (-1, 2)
                        state = CA.initialize_correlated_afqmc(H, params;
                            trial_state=inputs.inputs[family].state, initializer=selected, Lx=2, Ly=2)
                        reference = Run.finite_time_reference(H, state.oracle, selected, params)
                        rows = NamedTuple[]
                        final_step = completed == -1 ? 2 : params.warmup_steps + completed * params.steps_between_measurements
                        for step in 1:final_step
                            CA.step_correlated_afqmc!(state)
                            if step > params.warmup_steps &&
                                (step - params.warmup_steps) % params.steps_between_measurements == 0
                                index = length(rows) + 1
                                push!(rows, Run.measurement_row(job, index,
                                    CA.measure_correlated_afqmc(state), reference[index], state))
                            end
                        end
                        checkpoint = (format="correlated-afqmc-stage3-checkpoint-v1", job=job,
                            state=state, rows=rows, source_hashes=hashes, input_hashes=inputs.hashes)
                        @test isnothing(Run.validate_checkpoint(checkpoint, job, inputs, hashes))
                        directory = joinpath(root, "resumed_$(family)_$(label)_$(completed)")
                        path = joinpath(directory, "jobs", job.id, "checkpoint.jls")
                        mkpath(dirname(path))
                        Run.atomic_serialize(path, checkpoint)
                        resumed = Run.run_job(job, directory, inputs, hashes)
                        @test resumed == original
                        final = deserialize(path)
                        @test final.state.base.step == original_checkpoint.state.base.step
                        @test final.state.base.trial.up == original_checkpoint.state.base.trial.up
                        @test final.state.base.trial.down == original_checkpoint.state.base.trial.down
                        @test rand(deepcopy(final.state.base.rng), 10) == rand(deepcopy(original_checkpoint.state.base.rng), 10)
                        @test final.state.overlap_evaluations == original_checkpoint.state.overlap_evaluations
                        for (a, b) in zip(final.state.base.walkers, original_checkpoint.state.base.walkers)
                            @test a.up == b.up && a.down == b.down
                            @test a.log_weight == b.log_weight && a.log_overlap == b.log_overlap
                            @test a.fields == b.fields && a.field_end_ids == b.field_end_ids
                            @test a.anchor_up == b.anchor_up && a.anchor_down == b.anchor_down
                        end
                        corrupted = deepcopy(checkpoint)
                        corrupted.state.base.trial.up[1, 1] += 1e-4
                        @test_throws ErrorException Run.validate_checkpoint(corrupted, job, inputs, hashes)
                    end
                end
            end
        end
        @test abs(originals[("spin_0", "common")][1].reference_bp_m_alm_squared -
                  originals[("spin_0", "weak_field")][1].reference_bp_m_alm_squared) > 1e-5
        combined = Run.aggregate_seeds(all_summaries)
        @test length(combined) == 64
        @test Set(row.family for row in combined) == Set(("spin_0", "ed_control"))
        @test Set(row.initializer for row in combined) == Set(("common", "weak_field"))
        @test all(row.seeds == 1 for row in combined)
    end

    @testset "U=12 exact-trial energy and independent magnetic reference" begin
        kinetic = Matrix(SymTridiagonal(zeros(8), -ones(7)))
        H = SJ.benchmark_hamiltonian(kinetic, 12.0, 1, 1)
        ground = Run.Stage1.exact_ground_space(H)
        problem = Run.CPAFQMCProblem(kinetic, H.U, 1, 1; lattice_size=2, cell_count=4)
        common = Run.one_body_trial(problem; pattern=:altermagnetic, field_strength=2.0)
        inputs = (H=H, initializer=common)
        params = Run.CPAFQMCParameters(dtau=0.02, walker_count=4, warmup_steps=4,
            measurement_count=4, steps_between_measurements=2, back_propagation_steps=2,
            error_block_size=2, seed=91421)
        dense = SJ.ED.dense_sector_hamiltonian(H)
        h0 = SJ.ED.dense_sector_hamiltonian(SJ.benchmark_hamiltonian(kinetic, 0.0, 1, 1))
        exact_slice = exp(-params.dtau * h0 / 2) *
            exp(-params.dtau * (dense - h0)) * exp(-params.dtau * h0 / 2)
        diagonals = SJ.diagonal_observables(H; Lx=2, Ly=2)
        for label in ("common", "weak_field")
            initializer = Run.job_initializer(inputs, (initializer=label,))
            @test abs(dot(ground.vectors[:, 1],
                          CA.determinant_amplitudes(H, initializer.up, initializer.down))) > 1e-6
            state = CA.initialize_correlated_afqmc(H, params;
                trial_state=ground.vectors[:, 1], initializer=initializer, Lx=2, Ly=2)
            trial = state.oracle.trial
            reference = Run.finite_time_reference(H, state.oracle, initializer, params)
            initial = CA.determinant_amplitudes(H, initializer.up, initializer.down)
            for record in reference
                right = exact_slice^record.step * initial
                anchor = exact_slice^(record.step - params.back_propagation_steps) * initial
                left = transpose(exact_slice)^params.back_propagation_steps * trial
                independent_mixed = Run.exact_transition(H, trial, right, diagonals)
                independent_bp = Run.exact_transition(H, left, anchor, diagonals)
                for quantity in keys(independent_mixed)
                    # Dense 64-state exponentials and normalized wedge propagation
                    # differ only by accumulated Float64 arithmetic here.
                    @test isapprox(getproperty(record.mixed, quantity), getproperty(independent_mixed, quantity);
                                   atol=2e-10, rtol=2e-10)
                    @test isapprox(getproperty(record.backpropagated, quantity), getproperty(independent_bp, quantity);
                                   atol=2e-10, rtol=2e-10)
                end
                @test isapprox(record.mixed.energy, ground.energy; atol=2e-10, rtol=2e-10)
            end
            for _ in 1:12
                CA.step_correlated_afqmc!(state)
                for walker in state.base.walkers
                    walker.alive || continue
                    observed = CA.mixed_correlated_observables(state, walker)
                    # An eigenstate bra gives E0 for every nonzero-overlap ket.
                    # This algebraic check does not establish accurate magnetism.
                    @test isapprox(observed.energy, ground.energy; atol=2e-10, rtol=2e-10)
                    @test isfinite(observed.delta_alm) && isfinite(observed.m_alm_squared)
                end
            end
            @test state.numerical_failures == state.numerical_overlap_failures == 0
        end
    end

    @testset "Interrupted warmup and measurement replay" begin
        H = SJ.benchmark_hamiltonian(SJ.ED.open_cluster_kinetic_matrix(2, 2), 0.0, 1, 1)
        problem = Run.CPAFQMCProblem(H.kinetic, 0.0, 1, 1; lattice_size=2, cell_count=4)
        initializer = Run.one_body_trial(problem; pattern=:altermagnetic, field_strength=2.0)
        trial_state = SJ.onsite_jastrow_state(H, initializer)
        inputs = (H=H, inputs=Dict("bare" => (state=trial_state,)),
                  hashes=Dict("bare" => "test-input"), initializer=initializer)
        hashes = Dict("test" => "fixed-source")
        job = (id="restart_test", family="bare", seed=9183, dtau=0.04, walkers=2,
               warmup_time=0.16, measurements=4, spacing=0.08, bp_time=0.08, block_size=2)
        params = Run.parameters(job)
        mktempdir() do root
            original = Run.run_job(job, joinpath(root, "uninterrupted"), inputs, hashes)
            original_checkpoint = deserialize(joinpath(root, "uninterrupted", "jobs", job.id, "checkpoint.jls"))
            for completed in (-1, 2)
                state = CA.initialize_correlated_afqmc(H, params; trial_state=trial_state,
                    initializer=initializer, Lx=2, Ly=2)
                reference = Run.finite_time_reference(H, state.oracle, initializer, params)
                rows = NamedTuple[]
                final_step = completed == -1 ? 2 : params.warmup_steps + completed * params.steps_between_measurements
                for step in 1:final_step
                    CA.step_correlated_afqmc!(state)
                    if step > params.warmup_steps &&
                       (step - params.warmup_steps) % params.steps_between_measurements == 0
                        index = length(rows) + 1
                        push!(rows, Run.measurement_row(job, index, CA.measure_correlated_afqmc(state),
                                                        reference[index], state))
                    end
                end
                checkpoint = (format="correlated-afqmc-stage3-checkpoint-v1", job=job,
                    state=state, rows=rows, source_hashes=hashes, input_hashes=inputs.hashes)
                @test isnothing(Run.validate_checkpoint(checkpoint, job, inputs, hashes))
                directory = joinpath(root, "resumed_$completed")
                path = joinpath(directory, "jobs", job.id, "checkpoint.jls")
                mkpath(dirname(path))
                Run.atomic_serialize(path, checkpoint)
                resumed = Run.run_job(job, directory, inputs, hashes)
                @test resumed == original
                final = deserialize(path)
                @test final.state.base.step == original_checkpoint.state.base.step
                @test rand(deepcopy(final.state.base.rng), 10) == rand(deepcopy(original_checkpoint.state.base.rng), 10)
                @test final.state.overlap_evaluations == original_checkpoint.state.overlap_evaluations
                for (a, b) in zip(final.state.base.walkers, original_checkpoint.state.base.walkers)
                    @test a.up == b.up && a.down == b.down
                    @test a.log_weight == b.log_weight && a.log_overlap == b.log_overlap
                    @test a.fields == b.fields && a.field_end_ids == b.field_end_ids
                    @test a.anchor_up == b.anchor_up && a.anchor_down == b.anchor_down
                end
                corrupt = deepcopy(checkpoint)
                corrupt.state.base.step += 1 + params.warmup_steps
                @test_throws ErrorException Run.validate_checkpoint(corrupt, job, inputs, hashes)
                @test_throws ErrorException Run.validate_checkpoint(checkpoint, job, inputs, Dict("test" => "changed"))
            end
        end
    end

    @testset "Exact finite-time projection and BP anchors" begin
        kinetic = [0.0 -1.0; -1.0 0.0]
        initializer = Run.SlaterTrial([1.0; 0.2;;], [0.3; 1.0;;])
        trial = normalize([1.0, 0.7, 1.3, 0.5])
        for U in (0.0, 4.0, 20.0)
            H = SJ.benchmark_hamiltonian(kinetic, U, 1, 1)
            dtau = 0.02
            params = Run.CPAFQMCParameters(dtau=dtau, walker_count=8, warmup_steps=5,
                measurement_count=4, steps_between_measurements=2, back_propagation_steps=3,
                error_block_size=2)
            half = exp(-dtau * kinetic / 2)
            oracle = CA.exact_trial_oracle(H, trial; Lx=1, Ly=1, kinetic_half=half)
            records = Run.finite_time_reference(H, oracle, initializer, params)
            dense = SJ.ED.dense_sector_hamiltonian(H)
            h0 = SJ.ED.dense_sector_hamiltonian(SJ.benchmark_hamiltonian(kinetic, 0.0, 1, 1))
            exact_slice = exp(-dtau * h0 / 2) * exp(-dtau * (dense - h0)) * exp(-dtau * h0 / 2)
            initial = CA.determinant_amplitudes(H, initializer.up, initializer.down)
            diagonals = SJ.diagonal_observables(H; Lx=1, Ly=1)
            for (index, record) in enumerate(records)
                @test record.step == params.warmup_steps + index * params.steps_between_measurements
                right = exact_slice^record.step * initial
                anchor = exact_slice^(record.step - params.back_propagation_steps) * initial
                left = transpose(exact_slice)^params.back_propagation_steps * trial
                mixed = Run.exact_transition(H, trial, right, diagonals)
                bp = Run.exact_transition(H, left, anchor, diagonals)
                for quantity in keys(mixed)
                    # Small dense products and repeated normalized vectors differ
                    # by Float64 accumulation, not Monte Carlo uncertainty.
                    @test isapprox(getproperty(record.mixed, quantity), getproperty(mixed, quantity);
                                   atol=2e-11, rtol=2e-11)
                    @test isapprox(getproperty(record.backpropagated, quantity), getproperty(bp, quantity);
                                   atol=2e-11, rtol=2e-11)
                end
            end
        end
    end

    @testset "Blocking, seed groups, and atomic checkpoint files" begin
        stats = Run.blocked_statistics([1.0, 3.0, 2.0, 4.0], 2)
        @test stats.mean == 2.5
        @test isapprox(stats.error, 0.5; atol=1e-14, rtol=0)
        @test stats.blocks == 2
        for block in (0, -1, true, 3, 4)
            @test_throws ArgumentError Run.blocked_statistics([1.0, 2.0, 3.0, 4.0], block)
        end
        @test_throws ArgumentError Run.blocked_statistics([NaN, 2.0], 1)
        long_rows = [(mixed_energy=Float64(index), bp_energy=Float64(index)/2,
                      bp_delta_alm=sin(Float64(index)), m_alm_squared=Float64(index % 7)/8)
                     for index in 1:96]
        long_rows = [merge(row, (bp_m_alm_squared=row.m_alm_squared,)) for row in long_rows]
        diagnostic_job = (id="blocking_test",)
        long_blocking = Run.block_sensitivity(diagnostic_job, long_rows)
        @test length(long_blocking) == 40
        @test sort(unique(row.block_size for row in long_blocking)) == [1, 2, 4, 6, 8, 12, 16, 24, 32, 48]
        for row in long_blocking
            @test row.job_id == diagnostic_job.id
            @test row.blocks == 96 ÷ row.block_size
            expected = Run.blocked_statistics(getproperty.(long_rows, Symbol(row.quantity)), row.block_size)
            @test row.mean == expected.mean
            @test row.error == expected.error
            if row.quantity == "mixed_energy"
                # Equally spaced block means have an analytic standard error;
                # the tolerance covers Float64 square-root rounding only.
                @test isapprox(row.error, row.block_size * sqrt((row.blocks + 1)/12);
                               atol=1e-14, rtol=1e-14)
            end
        end
        short_blocking = Run.block_sensitivity(diagnostic_job, long_rows[1:24])
        @test length(short_blocking) == 24
        @test sort(unique(row.block_size for row in short_blocking)) == [1, 2, 4, 6, 8, 12]
        for row in short_blocking
            expected = Run.blocked_statistics(getproperty.(long_rows[1:24], Symbol(row.quantity)), row.block_size)
            @test row.mean == expected.mean && row.error == expected.error
            @test row.blocks == 24 ÷ row.block_size
        end
        extended_rows = [(mixed_energy=Float64(index), bp_energy=Float64(index)/2,
            bp_delta_alm=sin(Float64(index)), bp_m_alm_squared=Float64(index % 7)/8)
            for index in 1:384]
        extended_blocking = Run.block_sensitivity(diagnostic_job, extended_rows)
        @test length(extended_blocking) == 56
        @test sort(unique(row.block_size for row in extended_blocking)) ==
            [1, 2, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192]
        for row in extended_blocking
            @test row.job_id == diagnostic_job.id
            @test row.blocks == 384 ÷ row.block_size
            expected = Run.blocked_statistics(getproperty.(extended_rows, Symbol(row.quantity)), row.block_size)
            @test row.mean == expected.mean
            @test row.error == expected.error
            if row.quantity == "mixed_energy"
                # The analytic result only needs Float64 square-root tolerance.
                @test isapprox(row.error, row.block_size * sqrt((row.blocks + 1)/12);
                               atol=1e-13, rtol=1e-14)
            end
        end
        for (count, sizes) in ((8, [1, 2, 4]), (12, [1, 2, 4, 6]),
                               (40, [1, 2, 4, 8]))
            diagnostics = Run.block_sensitivity(diagnostic_job, extended_rows[1:count])
            @test sort(unique(row.block_size for row in diagnostics)) == sizes
            @test length(diagnostics) == 4length(sizes)
        end
        row = (family="spin_0", dtau=0.02, walkers=64, warmup_time=4.0, bp_time=0.8,
               estimator="bp", quantity="energy", seed=1, mean=1.0, error=0.2, ed=0.0,
               exact_finite_time_mean=0.1, minimum_ancestors=8)
        second = merge(row, (seed=2, mean=3.0, error=0.4, minimum_ancestors=7))
        combined = only(Run.aggregate_seeds([row, second]))
        @test combined.mean == 2.0
        @test combined.between_seed_error == 1.0
        @test isapprox(combined.within_seed_error, sqrt(0.2^2 + 0.4^2) / 2; atol=1e-14, rtol=0)
        @test combined.minimum_ancestors == 7
        @test combined.seeds == 2
        @test keys(combined) == (:family, :dtau, :walkers, :warmup_time, :bp_time,
            :estimator, :quantity, :seeds, :mean, :within_seed_error, :between_seed_error,
            :ed, :difference_from_ed, :exact_finite_time_mean, :minimum_ancestors)
        @test isnan(only(Run.aggregate_seeds([row])).between_seed_error)
        @test_throws ErrorException Run.aggregate_seeds([row, row])
        common_rows = [merge(item, (initializer="common",)) for item in (row, second)]
        weak_rows = [merge(item, (initializer="weak_field", mean=item.mean + 10.0)) for item in (row, second)]
        separate = Run.aggregate_seeds(vcat(common_rows, weak_rows))
        @test length(separate) == 2
        @test only(filter(item -> item.initializer == "common", separate)).mean == 2.0
        @test only(filter(item -> item.initializer == "weak_field", separate)).mean == 12.0
        @test all(item.seeds == 2 for item in separate)
        @test Base.structdiff(only(filter(item -> item.initializer == "common", separate)),
                             (initializer="common",)) == combined
        @test_throws ErrorException Run.aggregate_seeds(vcat([row], common_rows))
        @test_throws ErrorException Run.aggregate_seeds(vcat(weak_rows, [row]))
        @test_throws ErrorException Run.aggregate_seeds(vcat(common_rows, common_rows))
        @test isempty(Run.aggregate_seeds(NamedTuple[]))
        mktempdir() do directory
            checkpoint = joinpath(directory, "checkpoint.jls")
            Run.atomic_serialize(checkpoint, (step=1, values=[1.0, 2.0]))
            @test deserialize(checkpoint) == (step=1, values=[1.0, 2.0])
            Run.atomic_serialize(checkpoint, (step=2, values=[3.0]))
            @test deserialize(checkpoint) == (step=2, values=[3.0])
            @test !ispath(checkpoint * ".partial")
            metadata = joinpath(directory, "metadata.toml")
            Run.atomic_toml(metadata, Dict("status" => "running", "completed" => ["one"]))
            @test TOML.parsefile(metadata)["completed"] == ["one"]
            Run.atomic_toml(metadata, Dict("status" => "complete"))
            @test TOML.parsefile(metadata)["status"] == "complete"
            @test !ispath(metadata * ".partial")
        end
    end
end
