module SlaterJastrowSymmetryTests

using Test
using LinearAlgebra
using Random: Xoshiro
using AltermagnetDQMCTrial: SlaterTrial

include(joinpath(@__DIR__, "..", "scripts", "slater_jastrow_symmetry.jl"))
const SY = SlaterJastrowSymmetry
const SJ = SY.SJ

# This oracle acts in the full up-then-down Fock ordering. It does not use the
# implementation's spin-exchange signs or its sector-index helpers.
function independent_basis_bits(basis)
    return [
        UInt128(up) | (UInt128(down) << basis.nmodes)
        for up in basis.up_states for down in basis.down_states
    ]
end

function independent_fermion_action(bits::UInt128, mode::Int, creation::Bool)
    mask = UInt128(1) << (mode - 1)
    occupied = !iszero(bits & mask)
    occupied == creation && return nothing
    parity = count_ones(bits & (mask - 1))
    sign = iseven(parity) ? 1.0 : -1.0
    return (bits=bits ⊻ mask, sign=sign)
end

function independent_bilinear(bits, destination, source)
    annihilated = independent_fermion_action(bits, source, false)
    isnothing(annihilated) && return nothing
    created = independent_fermion_action(annihilated.bits, destination, true)
    isnothing(created) && return nothing
    return (bits=created.bits, sign=annihilated.sign * created.sign)
end

function independent_spin_ladder(bits, modes; raising)
    output = Dict{UInt128,Float64}()
    for mode in 1:modes
        destination, source = raising ? (mode, modes + mode) : (modes + mode, mode)
        moved = independent_bilinear(bits, destination, source)
        isnothing(moved) && continue
        output[moved.bits] = get(output, moved.bits, 0.0) + moved.sign
    end
    return output
end

function independent_spin_squared(basis)
    states = independent_basis_bits(basis)
    lookup = Dict(bits => index for (index, bits) in enumerate(states))
    result = zeros(Float64, length(states), length(states))
    magnetization = (basis.Nup - basis.Ndown) / 2
    for (column, bits) in enumerate(states)
        result[column, column] += magnetization^2
        for first_raises in (true, false)
            for (middle, coefficient) in independent_spin_ladder(
                bits, basis.nmodes; raising=first_raises,
            )
                for (final, second_coefficient) in independent_spin_ladder(
                    middle, basis.nmodes; raising=!first_raises,
                )
                    result[lookup[final], column] += coefficient * second_coefficient / 2
                end
            end
        end
    end
    return result
end

function independent_spin_flip(basis)
    states = independent_basis_bits(basis)
    lookup = Dict(bits => index for (index, bits) in enumerate(states))
    result = zeros(Float64, length(states), length(states))
    modes = basis.nmodes
    for (column, bits) in enumerate(states)
        occupied = [i for i in 1:(2modes) if !iszero(bits & (UInt128(1) << (i - 1)))]
        mapped = [i <= modes ? i + modes : i - modes for i in occupied]
        inversions = sum(mapped[i] > mapped[j] for i in eachindex(mapped)
                         for j in (i + 1):length(mapped); init=0)
        target = foldl((state, mode) -> state | (UInt128(1) << (mode - 1)),
                       mapped; init=UInt128(0))
        result[lookup[target], column] = iseven(inversions) ? 1.0 : -1.0
    end
    return result
end

function independent_raising(basis)
    if iszero(basis.Ndown) || basis.Nup == basis.nmodes
        return zeros(Float64, 0, length(basis))
    end
    target = SJ.ED.sector_basis(basis.nmodes, basis.Nup + 1, basis.Ndown - 1)
    target_lookup = Dict(bits => index for (index, bits) in
                         enumerate(independent_basis_bits(target)))
    result = zeros(Float64, length(target), length(basis))
    for (column, bits) in enumerate(independent_basis_bits(basis))
        for (final, coefficient) in independent_spin_ladder(bits, basis.nmodes; raising=true)
            result[target_lookup[final], column] += coefficient
        end
    end
    return result
end

function occupation_state(basis, up_modes, down_modes)
    bitset(modes) = foldl((bits, i) -> bits | (UInt128(1) << (i - 1)),
                         modes; init=UInt128(0))
    bits = bitset(up_modes) | (bitset(down_modes) << basis.nmodes)
    index = findfirst(==(bits), independent_basis_bits(basis))
    isnothing(index) && error("test occupation does not belong to this sector")
    vector = zeros(Float64, length(basis))
    vector[index] = 1.0
    return vector
end

@testset "Slater-Jastrow spin symmetry oracles" begin
    # Operator entries are integers and can be checked exactly on tiny sectors.
    # The 1e-12-scale tolerances below cover short Float64 matrix products and
    # polynomial projector roundoff, not Monte Carlo or model error.
    @testset "Independent Fock signs and sector boundaries" begin
        for modes in (2, 4), particles in 0:modes
            H = SJ.benchmark_hamiltonian(zeros(modes, modes), 3.0, particles, particles)
            ops = SY.spin_operators(H)
            expected_s2 = independent_spin_squared(H.basis)
            expected_flip = independent_spin_flip(H.basis)
            expected_raising = independent_raising(H.basis)
            @test Matrix(ops.s2) == expected_s2
            @test Matrix(ops.raising) == expected_raising
            @test ops.allowed_spins == collect(0:min(particles, modes - particles))
            @test ops.flip_sign == (iseven(particles) ? 1 : -1)
            @test Matrix(ops.s2) == transpose(Matrix(ops.s2))
            @test expected_flip * expected_flip == Matrix{Float64}(I, length(H.basis), length(H.basis))
            for column in 1:length(H.basis)
                input = zeros(length(H.basis))
                input[column] = 1.0
                @test SY.spin_reverse(ops, input) == expected_flip[:, column]
                @test SY.spin_reverse(ops, -3 .* input) == -3 .* expected_flip[:, column]
            end
            @test expected_flip * expected_s2 == expected_s2 * expected_flip
            @test isapprox(eigmin(Symmetric(expected_s2)), 0.0; atol=2e-12, rtol=0.0)
        end
    end

    @testset "Analytic two-mode singlet and triplet" begin
        H = SJ.benchmark_hamiltonian([0.0 -1.0; -1.0 0.0], 4.0, 1, 1)
        ops = SY.spin_operators(H)
        up_down = occupation_state(H.basis, [1], [2])
        down_up = occupation_state(H.basis, [2], [1])
        # Canonical up-before-down ordering includes a minus sign relative to
        # the site-ordered down/up product, so the Fock singlet uses a plus.
        singlet = (up_down + down_up) / sqrt(2)
        triplet = (up_down - down_up) / sqrt(2)
        @test isapprox(ops.s2 * singlet, zeros(4); atol=1e-14, rtol=0.0)
        @test isapprox(ops.s2 * triplet, 2 .* triplet; atol=1e-14, rtol=0.0)
        @test SY.spin_reverse(ops, singlet) == -singlet
        @test SY.spin_reverse(ops, triplet) == triplet
        for (state, spin, flip) in ((singlet, 0, -1), (triplet, 1, 1))
            diagnostics = SY.spin_diagnostics(ops, state)
            @test isapprox(diagnostics.s2_mean, spin * (spin + 1); atol=2e-13, rtol=0.0)
            @test diagnostics.s2_variance <= 1e-25
            @test isapprox(diagnostics.spin_flip_expectation, flip; atol=2e-13, rtol=0.0)
            present = SY.project_total_spin(ops, -7 .* state, spin)
            absent = SY.project_total_spin(ops, state, 1 - spin)
            @test present.present
            @test present.target_spin == spin
            @test isapprox(present.retained_weight, 1.0; atol=2e-13, rtol=0.0)
            @test isapprox(present.state, -state; atol=2e-13, rtol=0.0)
            @test !absent.present
            @test isnothing(absent.state)
            @test absent.retained_weight <= 1e-25
        end
        for U in (0.0, 4.0, 12.0, 20.0)
            dimer = SJ.benchmark_hamiltonian([0.0 -1.0; -1.0 0.0], U, 1, 1)
            ground = eigen(Symmetric(SJ.ED.dense_sector_hamiltonian(dimer))).vectors[:, 1]
            diagnostics = SY.spin_diagnostics(ops, ground)
            @test abs(diagnostics.s2_mean) <= 3e-13
            @test diagnostics.s2_variance <= 1e-24
        end
    end

    @testset "Polynomial projectors are orthogonal and complete" begin
        rng = Xoshiro(381196)
        for particles in (1, 2, 3)
            H = SJ.benchmark_hamiltonian(zeros(4, 4), 4.0, particles, particles)
            ops = SY.spin_operators(H)
            state = normalize(randn(rng, length(H.basis)))
            pieces = [SY.project_total_spin(ops, state, spin) for spin in ops.allowed_spins]
            @test all(piece -> piece.present, pieces)
            reconstructed = zeros(length(state))
            for (spin, piece) in zip(ops.allowed_spins, pieces)
                @test isapprox(norm(piece.state), 1.0; atol=3e-13, rtol=0.0)
                @test isapprox(ops.s2 * piece.state, spin * (spin + 1) .* piece.state;
                               atol=2e-12, rtol=2e-12)
                repeated = SY.project_total_spin(ops, piece.state, spin)
                @test repeated.present
                @test isapprox(repeated.retained_weight, 1.0; atol=3e-13, rtol=0.0)
                @test isapprox(repeated.state, piece.state; atol=3e-13, rtol=0.0)
                reconstructed .+= sqrt(piece.retained_weight) .* piece.state
                for other in ops.allowed_spins
                    other == spin && continue
                    projected_away = SY.project_total_spin(ops, piece.state, other)
                    @test !projected_away.present
                    @test projected_away.retained_weight <= 2e-25
                end
            end
            @test isapprox(sum(piece.retained_weight for piece in pieces), 1.0;
                           atol=3e-13, rtol=0.0)
            @test isapprox(reconstructed, state; atol=2e-12, rtol=2e-12)
            for i in eachindex(pieces), j in (i + 1):length(pieces)
                @test abs(dot(pieces[i].state, pieces[j].state)) <= 2e-12
            end
        end
    end

    @testset "Spin-swap parity alone does not select total spin" begin
        H = SJ.benchmark_hamiltonian(zeros(4, 4), 0.0, 2, 2)
        ops = SY.spin_operators(H)
        input = randn(Xoshiro(159872), length(H.basis))
        singlet = SY.project_total_spin(ops, input, 0).state
        quintet = SY.project_total_spin(ops, input, 2).state
        mixed_spin = (singlet + quintet) / sqrt(2)
        @test isapprox(SY.spin_reverse(ops, singlet), singlet; atol=3e-13, rtol=0.0)
        @test isapprox(SY.spin_reverse(ops, quintet), quintet; atol=3e-13, rtol=0.0)
        @test isapprox(SY.spin_reverse(ops, mixed_spin), mixed_spin; atol=3e-13, rtol=0.0)
        diagnostics = SY.spin_diagnostics(ops, mixed_spin)
        @test isapprox(diagnostics.s2_mean, 3.0; atol=3e-12, rtol=0.0)
        @test isapprox(diagnostics.s2_variance, 9.0; atol=3e-12, rtol=0.0)
        @test isapprox(diagnostics.spin_flip_expectation, 1.0; atol=3e-13, rtol=0.0)
        pair = SY.coherent_pair(H, ops, mixed_spin)
        @test pair.rank == 1
        @test isapprox(SY.spin_diagnostics(ops, pair.state).s2_variance, 9.0;
                       atol=3e-12, rtol=0.0)
    end

    @testset "Hubbard and onsite Jastrow preserve total spin" begin
        kinetic = [0.2 -0.8 0.3 -0.4; -0.8 -0.1 0.7 0.2;
                   0.3 0.7 0.4 -0.9; -0.4 0.2 -0.9 -0.3]
        H = SJ.benchmark_hamiltonian(kinetic, 7.0, 2, 2)
        ops = SY.spin_operators(H)
        dense_h = SJ.ED.dense_sector_hamiltonian(H)
        flip = independent_spin_flip(H.basis)
        @test norm(dense_h * ops.s2 - ops.s2 * dense_h) <= 2e-12
        @test norm(dense_h * flip - flip * dense_h) <= 2e-12
        rng = Xoshiro(709415)
        trial = SlaterTrial(randn(rng, 4, 2), randn(rng, 4, 2))
        bare = SJ.onsite_jastrow_state(H, trial; g=0.0)
        for g in (0.0, 0.5, 3.0)
            jastrow = Diagonal(exp.(-g .* H.double_occupancies))
            @test norm(jastrow * ops.s2 - ops.s2 * jastrow) <= 2e-13
            @test jastrow * flip == flip * jastrow
            dressed = SJ.onsite_jastrow_state(H, trial; g=g)
            @test isapprox(dressed, normalize(jastrow * bare); atol=3e-13, rtol=3e-13)
            for spin in ops.allowed_spins
                first_spin = SY.project_total_spin(ops, bare, spin)
                first_jastrow = SY.project_total_spin(ops, dressed, spin)
                @test first_spin.present
                @test first_jastrow.present
                @test isapprox(normalize(jastrow * first_spin.state), first_jastrow.state;
                               atol=3e-12, rtol=3e-12)
            end
        end
        # The physical open 2x2 sector has 3136 configurations. Matrix-vector
        # commutators check its full operator without a large dense diagonalization.
        physical = SJ.benchmark_hamiltonian(SJ.ED.open_cluster_kinetic_matrix(2, 2), 12.0, 3, 3)
        physical_ops = SY.spin_operators(physical)
        state = normalize(randn(rng, length(physical.basis)))
        @test length(state) == 3136
        @test norm(physical * (physical_ops.s2 * state) -
                   physical_ops.s2 * (physical * state)) <= 2e-11
        @test norm(physical * SY.spin_reverse(physical_ops, state) -
                   SY.spin_reverse(physical_ops, physical * state)) <= 2e-11
        spin_pieces = [SY.project_total_spin(physical_ops, state, spin)
                       for spin in physical_ops.allowed_spins]
        @test isapprox(sum(piece.retained_weight for piece in spin_pieces), 1.0;
                       atol=3e-12, rtol=0.0)
    end

    @testset "Coherent state differs from an incoherent spin average" begin
        H = SJ.benchmark_hamiltonian(zeros(2, 2), 4.0, 1, 1)
        ops = SY.spin_operators(H)
        state = normalize(occupation_state(H.basis, [1], [1]) +
                          occupation_state(H.basis, [1], [2]))
        flipped = SY.spin_reverse(ops, state)
        diagonal = SJ.diagonal_observables(H; Lx=1, Ly=1)
        values = SJ.variational_evaluation(H, state; Lx=1, Ly=1)
        reversed_values = SJ.variational_evaluation(H, flipped; Lx=1, Ly=1)
        @test isapprox(values.delta_alm, -reversed_values.delta_alm; atol=2e-13, rtol=0.0)
        @test isapprox(values.m_alm_squared, reversed_values.m_alm_squared; atol=2e-13, rtol=0.0)
        mixture_probabilities = (abs2.(state) + abs2.(flipped)) / 2
        @test isapprox(dot(mixture_probabilities, diagonal.delta_alm), 0.0; atol=2e-13, rtol=0.0)
        @test isapprox(dot(mixture_probabilities, diagonal.m_alm_squared), 0.5;
                       atol=2e-13, rtol=0.0)
        coherent = SY.coherent_pair(H, ops, state)
        coherent_values = SJ.variational_evaluation(H, coherent.state; Lx=1, Ly=1)
        @test coherent.rank == 2
        @test isapprox(norm(coherent.state), 1.0; atol=2e-13, rtol=0.0)
        @test isapprox(coherent.energy, -2.0; atol=3e-13, rtol=0.0)
        @test isapprox(coherent_values.m_alm_squared, 1.0; atol=3e-13, rtol=0.0)
        @test isapprox(coherent_values.delta_alm, 0.0; atol=3e-13, rtol=0.0)
        @test coherent.energy < values.energy - 1
        reconstructed = hcat(state, flipped) * coherent.coefficients
        @test isapprox(reconstructed, coherent.state; atol=3e-13, rtol=3e-13)
        scaled = SY.coherent_pair(H, ops, -11 .* state)
        @test isapprox(scaled.energy, coherent.energy; atol=3e-13, rtol=0.0)
        @test isapprox(abs(dot(scaled.state, coherent.state)), 1.0; atol=3e-13, rtol=0.0)
    end

    @testset "Dependent pair and zero-weight projection guards" begin
        H = SJ.benchmark_hamiltonian([0.0 -1.0; -1.0 0.0], 4.0, 1, 1)
        ops = SY.spin_operators(H)
        up_down = occupation_state(H.basis, [1], [2])
        down_up = occupation_state(H.basis, [2], [1])
        singlet = (up_down + down_up) / sqrt(2)
        triplet = (up_down - down_up) / sqrt(2)
        for state in (singlet, triplet, normalize(singlet + 1e-7 .* triplet))
            pair = SY.coherent_pair(H, ops, state; overlap_tolerance=1e-10)
            @test pair.rank == 1
            @test all(isfinite, pair.state)
            @test isapprox(norm(pair.state), 1.0; atol=3e-13, rtol=0.0)
            @test all(isfinite, pair.coefficients)
            @test isapprox(pair.energy, dot(pair.state, H * pair.state); atol=3e-13, rtol=0.0)
        end
        distinguishable = normalize(singlet + 1e-4 .* triplet)
        @test SY.coherent_pair(H, ops, distinguishable; overlap_tolerance=1e-10).rank == 2
        tiny_component = normalize(singlet + 1e-7 .* triplet)
        discarded = SY.project_total_spin(ops, tiny_component, 1; support_tolerance=1e-12)
        retained = SY.project_total_spin(ops, tiny_component, 1; support_tolerance=1e-16)
        @test !discarded.present
        @test isnothing(discarded.state)
        @test retained.present
        @test isapprox(retained.retained_weight, 1e-14; atol=2e-22, rtol=1e-8)
        @test isapprox(abs(dot(retained.state, triplet)), 1.0; atol=3e-13, rtol=0.0)
        @test isapprox(retained.retained_weight, discarded.retained_weight; atol=1e-25, rtol=0.0)
    end

    @testset "Invalid inputs" begin
        H = SJ.benchmark_hamiltonian(zeros(2, 2), 4.0, 1, 1)
        ops = SY.spin_operators(H)
        state = normalize(ones(4))
        imbalanced = SJ.benchmark_hamiltonian(zeros(2, 2), 4.0, 1, 0)
        @test_throws ArgumentError SY.spin_operators(imbalanced)
        oversized = SJ.ED.sector_hamiltonian(zeros(10, 10), 4.0, 3, 3)
        @test length(oversized.basis) == 14400
        @test_throws ArgumentError SY.spin_operators(oversized)
        mismatched = SJ.benchmark_hamiltonian(zeros(4, 4), 4.0, 1, 1)
        @test_throws DimensionMismatch SY.coherent_pair(mismatched, ops, state)
        vacuum_two = SJ.benchmark_hamiltonian(zeros(2, 2), 4.0, 0, 0)
        vacuum_four = SJ.benchmark_hamiltonian(zeros(4, 4), 4.0, 0, 0)
        @test_throws DimensionMismatch SY.coherent_pair(
            vacuum_four, SY.spin_operators(vacuum_two), [1.0],
        )
        for invalid in (zeros(4), fill(NaN, 4), fill(Inf, 4), complex.(state))
            @test_throws ArgumentError SY.spin_diagnostics(ops, invalid)
            @test_throws ArgumentError SY.project_total_spin(ops, invalid, 0)
            @test_throws ArgumentError SY.coherent_pair(H, ops, invalid)
        end
        # spin_reverse is linear, so a zero vector is valid for this operation.
        @test SY.spin_reverse(ops, zeros(4)) == zeros(4)
        for invalid in (fill(NaN, 4), fill(Inf, 4), complex.(state))
            @test_throws ArgumentError SY.spin_reverse(ops, invalid)
        end
        for wrong in (ones(3), ones(5))
            @test_throws DimensionMismatch SY.spin_reverse(ops, wrong)
            @test_throws DimensionMismatch SY.spin_diagnostics(ops, wrong)
            @test_throws DimensionMismatch SY.project_total_spin(ops, wrong, 0)
            @test_throws DimensionMismatch SY.coherent_pair(H, ops, wrong)
        end
        for spin in (-1, 2, 0.5, true, NaN, Inf)
            @test_throws ArgumentError SY.project_total_spin(ops, state, spin)
        end
        for tolerance in (-1.0, 1.0, 2.0, NaN, Inf, true)
            @test_throws ArgumentError SY.project_total_spin(ops, state, 0;
                                                           support_tolerance=tolerance)
        end
        for tolerance in (0.0, -1.0, 1.0, 2.0, NaN, Inf, true)
            @test_throws ArgumentError SY.coherent_pair(H, ops, state;
                                                       overlap_tolerance=tolerance)
        end
    end
end

end # module
