module SlaterJastrowTrialsTests

using Test
using LinearAlgebra
using Random: Xoshiro
using AltermagnetDQMCTrial: SlaterTrial

include(joinpath(@__DIR__, "..", "scripts", "slater_jastrow_trials.jl"))
include(joinpath(@__DIR__, "..", "scripts", "hubbard_ed_benchmarks.jl"))
const SJ = SlaterJastrowTrials
const DimerOracle = HubbardEDBenchmarks

# Determinant minors supply an independent occupation-basis amplitude oracle.
# The up-spin block precedes the down-spin block, which varies fastest.
function independent_slater_amplitudes(basis, trial)
    occupied(state) = [
        mode for mode in 1:basis.nmodes
        if !iszero(state & (UInt64(1) << (mode - 1)))
    ]
    minor(matrix, rows) = isempty(rows) ? 1.0 : det(matrix[rows, :])
    return [
        minor(trial.up, occupied(up)) * minor(trial.down, occupied(down))
        for up in basis.up_states for down in basis.down_states
    ]
end

function independent_double_counts(basis)
    return Float64[
        count_ones(up & down)
        for up in basis.up_states for down in basis.down_states
    ]
end

function fixed_occupation_trial(nmodes, up_modes, down_modes)
    identity = Matrix{Float64}(I, nmodes, nmodes)
    return SlaterTrial(identity[:, up_modes], identity[:, down_modes])
end

@testset "Finite-sum Slater-Jastrow trial oracles" begin
    # Absolute tolerances of order 1e-12 cover small dense Float64 determinant
    # and eigensolver roundoff. Optimizer parameters have a looser 1e-6 bound:
    # energy becomes quadratically flat near the optimum.
    @testset "Bare determinants and signed AFQMC overlaps" begin
        rng = Xoshiro(88427)
        kinetic = [
            0.2 -0.8 0.3 -0.4
            -0.8 -0.1 0.7 0.2
            0.3 0.7 0.4 -0.9
            -0.4 0.2 -0.9 -0.3
        ]
        H = SJ.benchmark_hamiltonian(kinetic, 4.0, 2, 1)
        trial = SlaterTrial(randn(rng, 4, 2), randn(rng, 4, 1))
        walker = SlaterTrial(randn(rng, 4, 2), randn(rng, 4, 1))
        bare = independent_slater_amplitudes(H.basis, trial)
        bare_walker = independent_slater_amplitudes(H.basis, walker)
        psi = SJ.onsite_jastrow_state(H, trial; g=0.0)
        @test isapprox(sum(abs2, bare), 1.0; atol=2e-13, rtol=0.0)
        @test isapprox(psi, bare; atol=3e-13, rtol=3e-13)
        determinant_overlap = det(transpose(trial.up) * walker.up) *
                              det(transpose(trial.down) * walker.down)
        @test isapprox(
            SJ.exact_trial_overlap(H, psi, walker), determinant_overlap;
            atol=3e-13, rtol=3e-13,
        )
        @test isapprox(dot(bare, bare_walker), determinant_overlap;
                       atol=3e-13, rtol=3e-13)

        reflected_up = copy(walker.up)
        reflected_up[:, 1] .*= -1
        reflected_walker = SlaterTrial(reflected_up, walker.down)
        @test isapprox(
            SJ.exact_trial_overlap(H, psi, reflected_walker),
            -determinant_overlap; atol=3e-13, rtol=3e-13,
        )

        g = 1.31
        counts = independent_double_counts(H.basis)
        expected = bare .* exp.(-g .* counts)
        expected ./= norm(expected)
        correlated = SJ.onsite_jastrow_state(H, trial; g=g)
        @test isapprox(correlated, expected; atol=3e-13, rtol=3e-13)
        @test all(sign.(correlated) .== sign.(bare))
        @test isapprox(
            SJ.exact_trial_overlap(H, correlated, walker),
            sum(expected .* bare_walker); atol=3e-13, rtol=3e-13,
        )
        @test isapprox(
            SJ.exact_trial_overlap(H, 2 .* correlated, walker),
            2 * dot(expected, bare_walker); atol=5e-13, rtol=3e-13,
        )

        result = SJ.variational_evaluation(H, correlated; Lx=2, Ly=1)
        dense = SJ.ED.dense_sector_hamiltonian(H)
        direct_energy = dot(expected, dense * expected)
        direct_variance = sum(abs2, dense * expected - direct_energy * expected)
        @test isapprox(result.energy, direct_energy; atol=2e-12, rtol=2e-12)
        @test isapprox(result.energy_variance, direct_variance;
                       atol=2e-12, rtol=2e-12)
        @test isapprox(result.double_occupancy_total, dot(abs2.(expected), counts);
                       atol=3e-13, rtol=3e-13)
        @test isapprox(result.energy,
                       result.kinetic_energy + result.centered_interaction_energy;
                       atol=2e-12, rtol=2e-12)
        rescaled = SJ.variational_evaluation(H, -7 .* correlated; Lx=2, Ly=1)
        @test isapprox(rescaled.energy, result.energy; atol=2e-12, rtol=2e-12)
        @test isapprox(rescaled.delta_alm, result.delta_alm;
                       atol=3e-13, rtol=3e-13)
    end

    @testset "Analytic centered Hubbard dimer through U=20" begin
        for t in (1.0, -0.7), U in (0.0, 4.0, 12.0, 20.0)
            kinetic = [0.0 -t; -t 0.0]
            H = SJ.benchmark_hamiltonian(kinetic, U, 1, 1)
            orbital = eigen(Symmetric(kinetic)).vectors[:, 1:1]
            trial = SlaterTrial(orbital, orbital)
            analytic = DimerOracle.analytic_hubbard_dimer(U, t)
            expected_g = asinh(U / (4abs(t)))
            exact_state = SJ.onsite_jastrow_state(H, trial; g=expected_g)
            # Two dimer sites are mapped to the two modes of one formal cell.
            # Only energy and double occupancy have their dimer meanings here.
            values = SJ.variational_evaluation(H, exact_state; Lx=1, Ly=1)
            @test isapprox(values.energy, analytic.ground_singlet_energy;
                           atol=4e-12, rtol=3e-13)
            @test isapprox(values.double_occupancy_total,
                           analytic.ground_double_occupancy_total;
                           atol=3e-13, rtol=3e-12)
            @test values.energy_variance <= 2e-23

            optimized = SJ.optimize_onsite_jastrow(
                H, trial; g_bounds=(0.0, 6.0),
                g_tolerance=1e-8, grid_points=25,
            )
            @test isapprox(optimized.g, expected_g; atol=2e-6, rtol=0.0)
            @test isapprox(optimized.energy, analytic.ground_singlet_energy;
                           atol=4e-12, rtol=3e-13)
            @test isapprox(norm(optimized.state), 1.0; atol=3e-13, rtol=0.0)
            @test optimized.evaluations > 0
            @test optimized.search_converged
            U == 0 && @test optimized.boundary_hit
            bare_energy = SJ.variational_evaluation(
                H, SJ.onsite_jastrow_state(H, trial; g=0.0); Lx=1, Ly=1,
            ).energy
            @test optimized.energy <= bare_energy + 4e-12
            U > 0 && @test optimized.energy < bare_energy - 1e-3
        end

        # The first coarse-grid point wins at this weak coupling, but the true
        # minimum is inside its interval, not exactly at g=0.
        weak_U = 0.01
        H = SJ.benchmark_hamiltonian([0.0 -1.0; -1.0 0.0], weak_U, 1, 1)
        bonding = reshape([1.0, 1.0], 2, 1)
        trial = SlaterTrial(bonding, bonding)
        optimized = SJ.optimize_onsite_jastrow(
            H, trial; g_bounds=(0.0, 6.0), g_tolerance=1e-8, grid_points=25,
        )
        @test optimized.search_converged
        @test !optimized.boundary_hit
        @test isapprox(optimized.g, asinh(weak_U / 4); atol=2e-6, rtol=0.0)
        @test isapprox(
            optimized.energy,
            DimerOracle.analytic_hubbard_dimer(weak_U).ground_singlet_energy;
            atol=4e-12, rtol=3e-13,
        )
        @test optimized.energy < -2.0 - 1e-6
    end

    @testset "Spin sectors, stable weights, and rejected invalid inputs" begin
        kinetic = [0.3 -1.0; -1.0 -0.2]
        orbital = eigen(Symmetric(kinetic)).vectors[:, 1:1]
        for (nup, ndown) in ((0, 0), (0, 1), (1, 0))
            H = SJ.benchmark_hamiltonian(kinetic, 4.0, nup, ndown)
            up = nup == 0 ? zeros(2, 0) : orbital
            down = ndown == 0 ? zeros(2, 0) : orbital
            trial = SlaterTrial(up, down)
            bare = independent_slater_amplitudes(H.basis, trial)
            for g in (0.0, 3.0, 1e6)
                psi = SJ.onsite_jastrow_state(H, trial; g=g)
                @test isapprox(psi, bare; atol=3e-13, rtol=3e-13)
                @test isapprox(SJ.exact_trial_overlap(H, psi, trial), 1.0;
                               atol=3e-13, rtol=0.0)
                obs = SJ.variational_evaluation(H, psi; Lx=1, Ly=1)
                @test isapprox(obs.double_occupancy_total, 0.0;
                               atol=3e-13, rtol=0.0)
            end
        end

        rng = Xoshiro(6221)
        H = SJ.benchmark_hamiltonian(zeros(4, 4), 4.0, 3, 3)
        trial = SlaterTrial(randn(rng, 4, 3), randn(rng, 4, 3))
        # This sector forces at least two double occupancies. Directly forming
        # exp(-g*D) underflows for every configuration; a common shift must cancel.
        psi = SJ.onsite_jastrow_state(H, trial; g=1e6)
        @test all(isfinite, psi)
        @test isapprox(norm(psi), 1.0; atol=3e-13, rtol=0.0)
        @test isapprox(dot(abs2.(psi), independent_double_counts(H.basis)), 2.0;
                       atol=3e-13, rtol=0.0)

        only_doubles = fixed_occupation_trial(4, [1, 2, 3], [1, 2, 3])
        psi_fixed = SJ.onsite_jastrow_state(H, only_doubles; g=1e6)
        @test all(isfinite, psi_fixed)
        @test isapprox(norm(psi_fixed), 1.0; atol=3e-13, rtol=0.0)
        @test isapprox(dot(abs2.(psi_fixed), independent_double_counts(H.basis)), 3.0;
                       atol=3e-13, rtol=0.0)

        @test_throws ArgumentError SJ.onsite_jastrow_state(H, trial; g=NaN)
        @test_throws ArgumentError SJ.onsite_jastrow_state(H, trial; g=Inf)
        wrong_trial = SlaterTrial(ones(4, 1), ones(4, 1))
        @test_throws DimensionMismatch SJ.onsite_jastrow_state(H, wrong_trial)
        @test_throws ArgumentError SJ.variational_evaluation(
            H, zeros(size(H, 1)); Lx=2, Ly=1,
        )
        @test_throws ArgumentError SJ.variational_evaluation(
            H, fill(NaN, size(H, 1)); Lx=2, Ly=1,
        )
        @test_throws DimensionMismatch SJ.variational_evaluation(
            H, psi; Lx=1, Ly=1,
        )
        @test_throws DimensionMismatch SJ.exact_trial_overlap(H, psi[1:end-1], trial)
        @test_throws ArgumentError SJ.benchmark_hamiltonian(
            zeros(8, 8), 4.0, 4, 4; max_dimension=100,
        )
        @test_throws ArgumentError SJ.benchmark_hamiltonian(
            zeros(2, 2), 4.0, 1, 1; max_dimension=5001,
        )
        @test_throws ArgumentError SJ.optimize_onsite_jastrow(
            H, trial; g_bounds=(2.0, 1.0),
        )
        @test_throws ArgumentError SJ.optimize_onsite_jastrow(
            H, trial; g_tolerance=0.0,
        )
        @test_throws ArgumentError SJ.optimize_onsite_jastrow(
            H, trial; g_tolerance=eps(Float64),
        )
    end

    @testset "Atomic Delta and competing wave vectors" begin
        Lx = Ly = 2
        cells = Lx * Ly
        H = SJ.benchmark_hamiltonian(zeros(8, 8), 4.0, 4, 4)
        diagonal = SJ.diagonal_observables(H; Lx=Lx, Ly=Ly)
        for (pattern, signs, expected_q) in (
            (:positive, [1, 1, 1, 1], :odd_q0),
            (:negative, [-1, -1, -1, -1], :odd_q0),
            (:stripe_x, [1, -1, 1, -1], :odd_qx),
            (:stripe_y, [1, 1, -1, -1], :odd_qy),
            (:checkerboard, [1, -1, -1, 1], :odd_qxy),
        )
            up_modes = [2cell - (signs[cell] == 1 ? 1 : 0) for cell in 1:cells]
            down_modes = [2cell - (signs[cell] == -1 ? 1 : 0) for cell in 1:cells]
            trial = fixed_occupation_trial(8, up_modes, down_modes)
            psi = SJ.onsite_jastrow_state(H, trial; g=0.7)
            values = SJ.variational_evaluation(H, psi; Lx=Lx, Ly=Ly)
            expected_delta = sum(signs) / cells
            @test isapprox(values.mx, expected_delta; atol=2e-13, rtol=0.0)
            @test isapprox(values.my, -expected_delta; atol=2e-13, rtol=0.0)
            @test isapprox(values.m_fm, 0.0; atol=2e-13, rtol=0.0)
            @test isapprox(values.delta_alm, expected_delta; atol=2e-13, rtol=0.0)
            @test isapprox(values.m_alm_squared, expected_delta^2;
                           atol=2e-13, rtol=0.0)
            @test isapprox(values.odd_q0 / cells, values.m_alm_squared;
                           atol=2e-13, rtol=0.0)
            for q in (:odd_q0, :odd_qx, :odd_qy, :odd_qxy)
                expected = q == expected_q ? Float64(cells) : 0.0
                @test isapprox(getproperty(values, q), expected;
                               atol=2e-13, rtol=0.0)
                @test isapprox(dot(abs2.(psi), getproperty(diagonal, q)), expected;
                               atol=2e-13, rtol=0.0)
            end
            @test isapprox(values.energy, -8.0; atol=2e-13, rtol=0.0)
            @test isapprox(values.double_occupancy_total, 0.0;
                           atol=2e-13, rtol=0.0)
        end

        plus = SJ.onsite_jastrow_state(
            H, fixed_occupation_trial(8, [1, 3, 5, 7], [2, 4, 6, 8]),
        )
        minus = SJ.onsite_jastrow_state(
            H, fixed_occupation_trial(8, [2, 4, 6, 8], [1, 3, 5, 7]),
        )
        symmetric = (plus + minus) / sqrt(2)
        values = SJ.variational_evaluation(H, symmetric; Lx=Lx, Ly=Ly)
        @test isapprox(values.delta_alm, 0.0; atol=2e-13, rtol=0.0)
        @test isapprox(values.m_alm_squared, 1.0; atol=2e-13, rtol=0.0)
        @test isapprox(values.odd_q0, 4.0; atol=2e-13, rtol=0.0)
    end

    @testset "Open two-orbital cluster retains interorbital hopping" begin
        kinetic = SJ.ED.open_cluster_kinetic_matrix(2, 2)
        @test any(!iszero, kinetic[1:2:end, 2:2:end])
        @test isapprox(kinetic, transpose(kinetic); atol=0.0, rtol=0.0)
        decomposition = eigen(Symmetric(kinetic))
        trial = SlaterTrial(decomposition.vectors[:, 1:1], decomposition.vectors[:, 1:1])
        H0 = SJ.benchmark_hamiltonian(kinetic, 0.0, 1, 1)
        psi0 = SJ.onsite_jastrow_state(H0, trial)
        free = SJ.variational_evaluation(H0, psi0; Lx=2, Ly=2)
        @test isapprox(free.energy, 2first(decomposition.values);
                       atol=3e-12, rtol=3e-13)
        @test free.energy_variance <= 2e-23

        H = SJ.benchmark_hamiltonian(kinetic, 12.0, 1, 1)
        bare = SJ.variational_evaluation(
            H, SJ.onsite_jastrow_state(H, trial); Lx=2, Ly=2,
        )
        optimized = SJ.optimize_onsite_jastrow(H, trial)
        exact_energy = first(eigvals(Symmetric(SJ.ED.dense_sector_hamiltonian(H))))
        @test optimized.energy < bare.energy - 1e-4
        @test optimized.energy >= exact_energy - 4e-12
        @test isfinite(optimized.g)
        @test optimized.search_converged
    end
end

end
