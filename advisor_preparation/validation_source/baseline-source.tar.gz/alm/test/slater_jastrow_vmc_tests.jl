using Test
using LinearAlgebra
using Random
using Statistics
using AltermagnetDQMCTrial

if !isdefined(@__MODULE__, :SlaterJastrowVMC)
    include(joinpath(@__DIR__, "..", "scripts", "sample_slater_jastrow_vmc.jl"))
end

@testset "Enumerated Slater-Jastrow VMC validation" begin
    SJ = SlaterJastrowTrials
    VMC = SlaterJastrowVMC
    kinetic = [0.0 -1.0; -1.0 0.0]
    H = SJ.benchmark_hamiltonian(kinetic, 4.0, 1, 1)
    orbitals = fill(inv(sqrt(2.0)), 2, 1)
    trial = SlaterTrial(orbitals, orbitals)
    g = 0.35
    psi = SJ.onsite_jastrow_state(H, trial; g=g)
    settings = (Lx=1, Ly=1, seed=1841, warmup=1000,
                measurements=40000, steps_between=2, block_size=200)

    @testset "Dimer finite sums and nonzero-variance sampling" begin
        # Four-state sums have roundoff far below 1e-12; the looser MC check
        # uses eight blocked errors and a small absolute floor, not equality.
        hand_psi = [exp(-g), 1.0, 1.0, exp(-g)]
        hand_psi ./= norm(hand_psi)
        @test isapprox(abs(dot(psi, hand_psi)), 1.0; atol=2e-13, rtol=2e-13)
        result = VMC.sample_vmc(H, psi; settings...)
        Hpsi = H * psi
        energy = dot(psi, Hpsi)
        exact_variance = sum(abs2, Hpsi .- energy .* psi)
        hand_energy = (2 * (exp(-2g) - 1) - 4exp(-g)) / (1 + exp(-2g))
        @test isapprox(energy, hand_energy; atol=2e-13, rtol=2e-13)
        @test exact_variance > 0.1
        @test isapprox(result.exact.energy, energy; atol=2e-13, rtol=2e-13)
        @test isapprox(result.exact.energy_variance, exact_variance; atol=2e-13, rtol=2e-13)
        @test isapprox(result.exact.local_energy_variance, exact_variance; atol=2e-13, rtol=2e-13)
        @test result.exact.node_variance_contribution == 0.0
        diagonal = SJ.diagonal_observables(H; Lx=1, Ly=1)
        expected = merge((energy=energy,), map(values -> dot(abs2.(psi), values), diagonal))
        for name in keys(expected)
            @test isapprox(result.exact.means[name], expected[name]; atol=2e-13, rtol=2e-13)
            @test abs(result.means[name] - expected[name]) <= 8result.errors[name] + 2e-3
            samples = result.samples[name]
            block_means = [mean(samples[first:(first + 199)]) for first in 1:200:40000]
            @test isapprox(result.errors[name], std(block_means) / sqrt(200); atol=2e-14, rtol=2e-13)
        end
        expected_local_energies = (Hpsi ./ psi)[result.samples.state_indices]
        @test isapprox(result.samples.energy, expected_local_energies; atol=2e-13, rtol=2e-13)
        @test result.diagnostics.proposals == 81000
        @test result.diagnostics.accepted + result.diagnostics.rejected == 81000
        @test 0 < result.diagnostics.moves < result.diagnostics.accepted < 81000
        @test result.diagnostics.node_proposals == 0
        @test result.diagnostics.blocks == 200
        @test length(result.samples.energy) == 40000
    end

    @testset "Private RNG, replay, and rejection accounting" begin
        short = (Lx=1, Ly=1, seed=14, warmup=7,
                 measurements=40, steps_between=3, block_size=10)
        global_snapshot = copy(Random.default_rng())
        result = VMC.sample_vmc(H, psi; short...)
        @test rand(copy(Random.default_rng()), UInt64) == rand(global_snapshot, UInt64)
        replay = VMC.sample_vmc(H, psi; short...)
        @test result == replay
        other_seed = VMC.sample_vmc(H, psi; merge(short, (seed=15,))...)
        @test result.samples.state_indices != other_seed.samples.state_indices

        # Independent scalar replay verifies every rejected proposal leaves
        # its current state in the chain, including between measurements.
        amplitudes = copy(psi)
        amplitudes ./= maximum(abs, amplitudes)
        amplitudes ./= norm(amplitudes)
        rng = Xoshiro(short.seed)
        current = argmax(abs.(amplitudes))
        expected_indices = Int[]
        accepted = 0
        moves = 0
        for step in 1:(short.warmup + short.measurements * short.steps_between)
            candidate = rand(rng, 1:4)
            uniform = rand(rng)
            log_ratio = 2log(abs(amplitudes[candidate])) - 2log(abs(amplitudes[current]))
            if log(uniform) < min(0.0, log_ratio)
                accepted += 1
                moves += candidate != current
                current = candidate
            end
            if step > short.warmup && (step - short.warmup) % short.steps_between == 0
                push!(expected_indices, current)
            end
        end
        @test result.samples.state_indices == expected_indices
        @test result.diagnostics.accepted == accepted
        @test result.diagnostics.moves == moves
        scaled = VMC.sample_vmc(H, 7 .* psi; short...)
        @test scaled.samples.state_indices == result.samples.state_indices
        @test isapprox(scaled.means.energy, result.means.energy; atol=2e-13, rtol=2e-13)
        sign_flipped = VMC.sample_vmc(H, -psi; short...)
        @test sign_flipped.samples.state_indices == result.samples.state_indices
        @test sign_flipped.means.energy == result.means.energy
    end

    @testset "Nodes and single-state support" begin
        only_one_state = [1.0, 0.0, 0.0, 0.0]
        result = VMC.sample_vmc(H, only_one_state; Lx=1, Ly=1, seed=41,
                                warmup=20, measurements=200, block_size=20)
        @test all(==(1), result.samples.state_indices)
        @test all(==(2.0), result.samples.energy)
        @test result.means.energy == 2.0
        @test result.errors.energy == 0.0
        @test result.diagnostics.moves == 0
        @test result.diagnostics.support_count == 1
        @test result.diagnostics.node_count == 3
        @test result.diagnostics.node_proposals == result.diagnostics.rejected
        @test result.diagnostics.accepted > 0
        @test result.diagnostics.rejected > 0
        @test result.exact.local_energy_variance == 0.0
        @test result.exact.energy_variance == 2.0
        @test result.exact.node_variance_contribution == 2.0

        disconnected = [inv(sqrt(2.0)), 0.0, 0.0, inv(sqrt(2.0))]
        two_states = VMC.sample_vmc(H, disconnected; Lx=1, Ly=1, seed=41,
                                    warmup=20, measurements=200, block_size=20)
        @test Set(two_states.samples.state_indices) == Set((1, 4))
        @test two_states.diagnostics.moves > 0
    end

    @testset "Mixed exchange and global proposals" begin
        mixed_settings = merge(settings, (proposal=:mixed, global_probability=0.1))
        snapshot = copy(Random.default_rng())
        result = VMC.sample_vmc(H, psi; mixed_settings...)
        @test rand(copy(Random.default_rng()), UInt64) == rand(snapshot, UInt64)
        @test result == VMC.sample_vmc(H, psi; mixed_settings...)
        @test result.diagnostics.proposal == :mixed
        @test result.diagnostics.global_probability == 0.1
        @test result.diagnostics.global_proposals + result.diagnostics.exchange_proposals ==
              result.diagnostics.proposals
        @test 0 < result.diagnostics.global_proposals < result.diagnostics.proposals
        @test result.diagnostics.exchange_proposals > 0
        @test result.diagnostics.accepted + result.diagnostics.rejected == result.diagnostics.proposals
        for name in keys(result.means)
            @test abs(result.means[name] - result.exact.means[name]) <= 8result.errors[name] + 2e-3
        end

        # Exchanges alone cannot connect these two configurations: each passes
        # through a zero-amplitude state. Positive global probability connects them.
        disconnected = [inv(sqrt(2.0)), 0.0, 0.0, inv(sqrt(2.0))]
        two_states = VMC.sample_vmc(H, disconnected; Lx=1, Ly=1, seed=717,
                                    warmup=100, measurements=2000, block_size=100,
                                    proposal=:mixed, global_probability=0.1)
        @test Set(two_states.samples.state_indices) == Set((1, 4))
        @test two_states.diagnostics.moves > 0
        @test two_states.diagnostics.node_proposals >= two_states.diagnostics.exchange_proposals
        @test two_states.diagnostics.node_proposals == two_states.diagnostics.rejected

        vacuum = SJ.benchmark_hamiltonian(kinetic, 4.0, 0, 0)
        single = VMC.sample_vmc(vacuum, [1.0]; Lx=1, Ly=1, measurements=200,
                                 block_size=20, proposal=:mixed)
        @test all(==(1), single.samples.state_indices)
        @test single.diagnostics.moves == 0
        @test single.diagnostics.accepted == single.diagnostics.proposals
        @test single.diagnostics.exchange_proposals > 0
        for nup in (0, 2)
            spin_edge = SJ.benchmark_hamiltonian(kinetic, 4.0, nup, 1)
            edge = VMC.sample_vmc(spin_edge, ones(2); Lx=1, Ly=1,
                                  measurements=200, block_size=20, proposal=:mixed)
            @test Set(edge.samples.state_indices) == Set((1, 2))
            @test edge.diagnostics.accepted == edge.diagnostics.proposals
            @test edge.diagnostics.moves > 0
        end
        global_only = VMC.sample_vmc(H, psi; Lx=1, Ly=1, measurements=200,
                                     block_size=20, proposal=:mixed, global_probability=1)
        @test global_only.diagnostics.exchange_proposals == 0
        @test global_only.diagnostics.global_proposals == global_only.diagnostics.proposals
    end

    @testset "Input validation" begin
        minimal = (Lx=1, Ly=1, measurements=20, block_size=10, warmup=0)
        for key in (:seed, :warmup, :measurements, :steps_between, :block_size, :max_dimension)
            @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, NamedTuple{(key,)}((true,)))...)
            @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, NamedTuple{(key,)}((-1,)))...)
        end
        for key in (:measurements, :steps_between, :block_size, :max_dimension)
            @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, NamedTuple{(key,)}((0,)))...)
        end
        @test_throws ArgumentError VMC.sample_vmc(H, zeros(4); minimal...)
        @test_throws ArgumentError VMC.sample_vmc(H, [NaN, 1, 1, 1]; minimal...)
        @test_throws ArgumentError VMC.sample_vmc(H, [Inf, 1, 1, 1]; minimal...)
        @test_throws ArgumentError VMC.sample_vmc(H, [1.0, 1e-200, 1, 1]; minimal...)
        @test_throws DimensionMismatch VMC.sample_vmc(H, ones(3); minimal...)
        @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, (max_dimension=3,))...)
        @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, (measurements=21,))...)
        @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, (measurements=10,))...)
        @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, (seed=big(typemax(Int)) + 1,))...)
        @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, (steps_between=typemax(Int),))...)
        @test_throws DimensionMismatch VMC.sample_vmc(H, psi; merge(minimal, (Lx=2,))...)
        @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, (Ly=0,))...)
        @test_throws ArgumentError VMC.sample_vmc(H, psi; merge(minimal, (Lx=true,))...)
        extreme_H = SJ.benchmark_hamiltonian(kinetic, 1e200, 1, 1)
        @test_throws ArgumentError VMC.sample_vmc(extreme_H, psi; minimal...)
        nonfinite_H = deepcopy(H)
        nonfinite_H.diagonal[1] = Inf
        @test_throws ArgumentError VMC.sample_vmc(nonfinite_H, psi; minimal...)
        for method in (:local, "mixed", false, nothing)
            @test_throws ArgumentError VMC.sample_vmc(H, psi; minimal..., proposal=method)
        end
        for probability in (0.0, -0.1, 1.1, Inf, NaN, true, "0.1", big"1e-500")
            @test_throws ArgumentError VMC.sample_vmc(H, psi; minimal...,
                                                     proposal=:mixed, global_probability=probability)
        end
    end
end
