using Test
using Serialization

include(joinpath(@__DIR__, "..", "scripts", "audit_two_orbital_spins.jl"))
using .TwoOrbitalSpinAudit

# Float64 sums and ratio-jackknife cancellation over eight small synthetic
# blocks need only roundoff tolerance; this is not a Monte Carlo error bound.
const SPIN_AUDIT_ATOL = 2e-12

function spin_audit_fixture()
    L, bins = 4, 8
    tau = collect(0.0:0.1:0.4)
    signs = [10.0, 6.0, -2.0, 8.0, 10.0, 4.0, 6.0, 10.0]
    counts = fill(10, bins)
    greens = zeros(ComplexF64, bins, 2, 2, 2, L, L, length(tau))
    for bin in 1:bins, spin in 1:2, orbital in 1:2, kx in 1:L, ky in 1:L, it in eachindex(tau)
        shift = (kx, ky) == (3,1) ? 0.10 : ((kx, ky) == (1,3) ? -0.07 : 0.0)
        common_noise = 0.01 * (bin - 4) * sin(pi * tau[it] / last(tau))
        raw = 0.5 + common_noise + (spin == 1 ? shift : -shift) * (1 - 2tau[it]/last(tau))
        greens[bin, spin, orbital, orbital, kx, ky, it] = signs[bin] * raw
    end
    metadata = Dict{String,Any}(
        "U"=>2.0, "beta"=>0.4, "dtau"=>0.1, "L"=>L, "Ltau"=>4,
        "mu_measured"=>-2.5157, "bin_count"=>bins, "chain_count"=>2,
        "source_metadata"=>[Dict("bin_count"=>4,"measurements_per_bin"=>50) for _ in 1:2],
    )
    return Dict{String,Any}(
        "schema_version"=>1, "metadata"=>metadata, "tau"=>tau,
        "momenta"=>collect(0:(L-1)) .* (2pi/L),
        "green_axes"=>(:bin,:spin,:destination_orbital,:source_orbital,:kx_index,:ky_index,:tau_index),
        "green_convention"=>"G=<T c(tau)c^dagger(0)>; no leading minus sign",
        "green_signed_momentum_bins"=>greens, "green_sign_sums"=>signs, "green_counts"=>counts,
        "green_maximum_stabilization_errors"=>zeros(bins,2),
        "basic_bins"=>Dict("average_sign"=>signs./counts,"density"=>1.42 .* signs./counts),
    )
end

@testset "Saved spin audit" begin
    mktempdir(@__DIR__) do directory
        path = joinpath(directory,"synthetic.jls")
        serialize(path, spin_audit_fixture())
        data = TwoOrbitalSpinAudit.SC.load_and_validate_payload(path)
        report = audit_spins(data)
        @test report.locations == (X=(3,1),Y=(1,3))
        @test report.analysis_bins == 8
        @test report.scalar.status == "available"
        @test isapprox(report.scalar.density,1.42;atol=SPIN_AUDIT_ATOL,rtol=0)
        for (name, value) in (("average_sign", 2.0), ("average_sign", 0.5 + 0.1im),
                              ("density", NaN), ("density", Inf))
            invalid_payload = deepcopy(data.payload)
            invalid_payload["basic_bins"] = Dict{String,Any}(invalid_payload["basic_bins"])
            invalid_payload["basic_bins"][name] = fill(value, 8)
            @test_throws ErrorException audit_spins(merge(data, (;payload=invalid_payload)))
        end
        for label in ("X","Y","DOS")
            @test report.channels[label].status == "available"
            r = report.channels[label].result
            @test isapprox(r.up_endpoint.value,2;atol=SPIN_AUDIT_ATOL,rtol=0)
            @test isapprox(r.down_endpoint.value,2;atol=SPIN_AUDIT_ATOL,rtol=0)
            @test isapprox(r.total.values,r.up.values+r.down.values;atol=SPIN_AUDIT_ATOL,rtol=0)
        end
        x = report.channels["X"].result
        expected = 0.4 .* (1 .- 2 .* data.tau ./ last(data.tau))
        @test isapprox(x.difference.values,expected;atol=SPIN_AUDIT_ATOL,rtol=0)
        # Shared noise cancels in the paired difference. Adding the two
        # independent variances instead would fail this check.
        @test maximum(x.up.standard_errors) > 1e-3
        @test maximum(x.down.standard_errors) > 1e-3
        @test maximum(x.difference.standard_errors) < SPIN_AUDIT_ATOL
        blocked,groups = rebin_data(data,2)
        @test groups == [1:2,3:4,5:6,7:8]
        @test size(blocked.greens,1) == 4
        @test blocked.counts == fill(20,4)
        blocked_report = audit_spins(data;rebin=2)
        @test isapprox(blocked_report.channels["X"].result.up.values,x.up.values;atol=SPIN_AUDIT_ATOL,rtol=0)
        @test isapprox(blocked_report.sign.value,report.sign.value;atol=SPIN_AUDIT_ATOL,rtol=0)
        @test_throws ErrorException rebin_data(data,3)
        @test_throws ErrorException rebin_data(data,8)
        @test_throws ErrorException rebin_data(merge(data,(counts=[9;fill(10,7)],)),1)
        @test_throws ErrorException momentum_indices(merge(data,(momenta=[0.0,2pi/3,4pi/3],)))
        weak = merge(data,(sign_sums=zeros(8),))
        weak_report = audit_spins(weak)
        @test weak_report.sign.value == 0
        @test all(channel.status=="unavailable" for channel in values(weak_report.channels))
        out = joinpath(directory,"audit")
        redirect_stdout(devnull) do
            TwoOrbitalSpinAudit.main([path,"--output-dir="*out,"--tau-stride=2"])
        end
        @test isfile(joinpath(out,"audit_summary.txt"))
        @test length(readlines(joinpath(out,"X_spin_greens.csv"))) == 4
        @test isfile(joinpath(out,"Y_difference_covariance.csv"))
        @test_throws ErrorException TwoOrbitalSpinAudit.main([path,"--output-dir="*out])
    end
end
