module SpinContinuationTests

using Test
using Serialization
using DelimitedFiles

module Continuation
include(joinpath(@__DIR__, "..", "scripts", "continue_two_orbital_spectrum.jl"))
const LOADED_DEAC_ON_INCLUDE = isdefined(@__MODULE__, :SmoQyDEAC)

# Exercise the wrapper's physical conversion and output contract without
# loading a continuation package or doing a stochastic fit.
module SmoQyDEAC
const calls = Ref(0)
function DEAC_Cov(values, covariance, beta, tau, omega, kernel, bins, runs,
                  output_path, checkpoint_path; kwargs...)
    calls[] += 1
    length(omega) == 3 || error("the test solver uses three energy points")
    open(output_path, "w") do io
        write(io, "test-only solver placeholder")
    end
    return Dict(
        "A" => reshape([0.0, 0.5, 0.0], :, 1),
        "σ" => reshape([0.0, 0.01, 0.0], :, 1),
        "ωs" => omega,
        "zeroth_moment" => 1.0,
    )
end
end
end

module SpectrumPlot
include(joinpath(@__DIR__, "..", "scripts", "plot_spectrum_csv.jl"))
end

const C = Continuation
const P = SpectrumPlot
# Small Float64 kernel sums and ratio jackknifes introduce a few ulps.
# 2e-12 is strict relative to order-one spectral weight and also resolves
# the deliberately different spin energies used below.
const ATOL = 2.0e-12

kernel(energy, tau, beta) = exp(-tau * energy) / (1 + exp(-beta * energy))

function mode_energies(kx, ky, spin, split_spins)
    if split_spins
        magnitude = if kx == 2 && ky == 1
            spin == 1 ? 1.5 : 2.5
        elseif kx == 1 && ky == 2
            spin == 1 ? 2.5 : 1.5
        else
            2.0
        end
        return (-magnitude, magnitude)
    end
    # Exact U=0 full-hopping energies on the 2x2 momentum grid, in the
    # (d_xz,d_yz) basis where sin(kx)sin(ky)=0.
    return kx == ky ? (kx == 1 ? (8.9, 8.9) : (-2.1, -2.1)) :
           (kx == 2 ? (-1.9, -4.9) : (-4.9, -1.9))
end

function fixture(; split_spins=true, noisy=false)
    tau = collect(0.0:0.25:1.0)
    signs = [3.0, -1.0, 2.0]
    counts = [5, 5, 5]
    greens = fill(1000.0 + 3.0im, 3, 2, 2, 2, 2, 2, length(tau))
    noise = noisy ? [0.03, 0.01, -0.02] : zeros(3)
    for bin in 1:3, spin in 1:2, kx in 1:2, ky in 1:2, orbital in 1:2
        energy = mode_energies(kx, ky, spin, split_spins)[orbital]
        for (time_index, time) in pairs(tau)
            greens[bin, spin, orbital, orbital, kx, ky, time_index] =
                signs[bin] * kernel(energy, time, 1.0) +
                noise[bin] * time * (1.0 - time)
        end
    end
    return Dict{String,Any}(
        "schema_version" => 1,
        "green_axes" => (:bin, :spin, :destination_orbital, :source_orbital,
                         :kx_index, :ky_index, :tau_index),
        "green_convention" => "G=<T c(tau)c^dagger(0)>; no leading minus sign",
        "metadata" => Dict("beta" => 1.0, "dtau" => 0.25, "L" => 2,
                           "Ltau" => 4, "bin_count" => 3),
        "tau" => tau,
        "momenta" => [0.0, pi],
        "green_signed_momentum_bins" => greens,
        "green_sign_sums" => signs,
        "green_counts" => counts,
        "green_maximum_stabilization_errors" => zeros(3, 2),
    )
end

function load_fixture(directory; kwargs...)
    path = joinpath(directory, "fixture.jls")
    serialize(path, fixture(; kwargs...))
    return path, C.load_and_validate_payload(path)
end

function normalized_values(data, mode, kx, ky; spin=:both)
    numerators = C.trace_numerator_bins(
        data, mode, kx, ky, eachindex(data.tau); spin=spin,
    )
    return C.sign_reweighted_statistics(
        numerators, data.sign_sums, data.counts, 0.05;
        require_noisy=false,
    ).values
end

@testset "Spin-resolved continuation" begin
    @test !C.RUN_AS_SCRIPT
    @test !C.LOADED_DEAC_ON_INCLUDE
    @test !P.RUN_AS_SCRIPT
    @test !isdefined(P, :Plots)

    @testset "CLI and backward-compatible total contract" begin
        mktempdir(@__DIR__) do directory
            path, _ = load_fixture(directory)
            @test C.parse_options([path]).spin == :both
            for spin in (:both, :up, :down)
                @test C.parse_options([path, "--spin=$spin"]).spin == spin
            end
            @test_throws ErrorException C.parse_options([path, "--spin=sideways"])
            @test_throws ArgumentError C.physical_trace_factor(:sideways)
            @test C.physical_trace_factor(:both) == 4.0
            @test C.physical_trace_factor(:up) == C.physical_trace_factor(:down) == 2.0
            @test C.channel_label(:dos, 1, 1) == "dos"
            @test C.channel_label(:ktrace, 2, 1) == "ktrace_kx2_ky1"
            @test C.channel_label(:ktrace, 2, 1; spin=:down) == "ktrace_kx2_ky1_down"
            @test C.all_k_manifest_name(:both) == "all_k_manifest.csv"
            @test C.all_k_manifest_name(:up) == "all_k_up_manifest.csv"
            @test C.spectrum_csv_header(:both) == [
                "omega", "A_normalized", "A_normalized_deac_se",
                "A_physical_total", "A_physical_total_deac_se",
            ]
            @test C.input_csv_header(:up)[5:6] == ["G_physical_up", "G_physical_up_se"]
            @test C.parse_options(["--help"]) === nothing
        end
    end

    @testset "Known spin-split kernels, paired signs, and orbital trace" begin
        mktempdir(@__DIR__) do directory
            _, data = load_fixture(directory)
            times = eachindex(data.tau)
            legacy = zeros(ComplexF64, 3, length(times))
            # Independent expression for the pre-change default at X.
            for bin in 1:3, time in times
                legacy[bin, time] = sum(
                    data.greens[bin, spin, orbital, orbital, 2, 1, time]
                    for spin in 1:2, orbital in 1:2
                ) / 4
            end
            @test C.trace_numerator_bins(data, :ktrace, 2, 1, times) == legacy
            xup = normalized_values(data, :ktrace, 2, 1; spin=:up)
            xdown = normalized_values(data, :ktrace, 2, 1; spin=:down)
            yup = normalized_values(data, :ktrace, 1, 2; spin=:up)
            ydown = normalized_values(data, :ktrace, 1, 2; spin=:down)
            expected_xup = [(kernel(-1.5, t, 1.0) + kernel(1.5, t, 1.0)) / 2
                            for t in data.tau]
            expected_xdown = [(kernel(-2.5, t, 1.0) + kernel(2.5, t, 1.0)) / 2
                              for t in data.tau]
            @test isapprox(xup, expected_xup; atol=ATOL, rtol=0.0)
            @test isapprox(xdown, expected_xdown; atol=ATOL, rtol=0.0)
            @test abs(xup[3] - xdown[3]) > 0.05
            @test isapprox(xup, ydown; atol=ATOL, rtol=0.0)
            @test isapprox(xdown, yup; atol=ATOL, rtol=0.0)
            for mode in (:ktrace, :dos)
                up = normalized_values(data, mode, 2, 1; spin=:up)
                down = normalized_values(data, mode, 2, 1; spin=:down)
                both = normalized_values(data, mode, 2, 1)
                @test isapprox(4both, 2up + 2down; atol=ATOL, rtol=0.0)
                for (spin, values) in ((:up, up), (:down, down), (:both, both))
                    @test isapprox(first(values) + last(values), 1.0; atol=ATOL, rtol=0.0)
                    @test isapprox(C.physical_trace_factor(spin) * sum(values[[1, end]]),
                                   spin == :both ? 4.0 : 2.0; atol=ATOL, rtol=0.0)
                end
            end
            @test isapprox(normalized_values(data, :dos, 1, 1; spin=:up),
                           normalized_values(data, :dos, 1, 1; spin=:down);
                           atol=ATOL, rtol=0.0)
        end
    end

    @testset "U=0 full-hopping and interacting-atom normalization" begin
        mktempdir(@__DIR__) do directory
            _, data = load_fixture(directory; split_spins=false)
            for kx in 1:2, ky in 1:2
                expected = [sum(kernel(e, t, 1.0) for e in mode_energies(kx, ky, 1, false)) / 2
                            for t in data.tau]
                for spin in (:up, :down, :both)
                    values = normalized_values(data, :ktrace, kx, ky; spin=spin)
                    @test isapprox(values, expected; atol=ATOL, rtol=0.0)
                    @test isapprox(first(values) + last(values), 1.0; atol=ATOL, rtol=0.0)
                end
            end
            # At particle-hole symmetry an isolated Hubbard orbital has two
            # spectral poles at +/-U/2, each of weight 1/2, for either spin.
            atom_U = 4.0
            atom = [(kernel(-atom_U / 2, t, 1.0) + kernel(atom_U / 2, t, 1.0)) / 2
                    for t in data.tau]
            for bin in 1:3, spin in 1:2, orbital in 1:2, kx in 1:2, ky in 1:2
                data.greens[bin, spin, orbital, orbital, kx, ky, :] .= data.sign_sums[bin] .* atom
            end
            for spin in (:up, :down, :both)
                @test isapprox(normalized_values(data, :dos, 1, 1; spin=spin), atom;
                               atol=ATOL, rtol=0.0)
                @test C.physical_trace_factor(spin) == (spin == :both ? 4.0 : 2.0)
            end
        end
    end

    @testset "Mixed-sign jackknife and audit-only relaxations" begin
        numerators = [3.0 6.0; -3.0 -4.0; 10.0 12.0]
        signs = [3.0, -1.0, 2.0]
        counts = [5, 5, 5]
        statistics = C.sign_reweighted_statistics(numerators, signs, counts, 0.05)
        @test statistics.values == [2.5, 3.5]
        @test isapprox(statistics.covariance, fill(1252 / 75, 2, 2); atol=ATOL, rtol=0.0)
        @test statistics.average_sign == 4 / 15
        @test_throws ErrorException C.sign_reweighted_statistics(numerators, signs, counts, 0.15)
        negative = C.sign_reweighted_statistics(-numerators, signs, counts, 0.05;
                                               require_positive=false)
        @test negative.values == -statistics.values
        @test negative.covariance == statistics.covariance
        @test_throws ErrorException C.sign_reweighted_statistics(-numerators, signs, counts, 0.05)
        @test_throws ErrorException C.sign_reweighted_statistics(fill(0.5, 3, 2), ones(3), ones(Int, 3), 0.05)
        exact = C.sign_reweighted_statistics(fill(0.5, 3, 2), ones(3), ones(Int, 3), 0.05;
                                            require_noisy=false)
        @test exact.values == [0.5, 0.5]
        @test iszero(exact.covariance)
        difference = C.sign_reweighted_statistics(zeros(3, 2), ones(3), ones(Int, 3), 0.05;
                                                 require_noisy=false, require_positive=false)
        @test iszero(difference.values)
        @test iszero(difference.covariance)
        @test_throws ErrorException C.sign_reweighted_statistics(zeros(2, 2), [1.0, -1.0], [1, 1], 0.0;
                                                                require_noisy=false, require_positive=false)
    end

    @testset "Physical CSVs, metadata, and up/down plotting inputs" begin
        mktempdir(@__DIR__) do directory
            path, data = load_fixture(directory; noisy=true)
            paths = Dict{Symbol,String}()
            for spin in (:both, :up, :down)
                options = C.parse_options([
                    path, "--mode=ktrace", "--spin=$spin", "--kx-index=2",
                    "--tau-stride=1", "--omega-min=-2", "--omega-max=2",
                    "--omega-points=3", "--output-dir=$directory",
                ])
                result = redirect_stdout(devnull) do
                    C.continue_channel(data, options, :ktrace, 2, 1, 123)
                end
                @test result.status == "complete"
                stem = joinpath(directory, result.label)
                paths[spin] = stem * "_spectrum.csv"
                @test split(readline(paths[spin]), ',') == C.spectrum_csv_header(spin)
                @test split(readline(stem * "_input.csv"), ',') == C.input_csv_header(spin)
                summary = read(stem * "_summary.txt", String)
                @test occursin("spin = $spin\n", summary)
                @test occursin("physical_zeroth_moment_expected = $(C.physical_trace_factor(spin))\n", summary)
                @test occursin("endpoint_moment_consistent = true", summary)
                @test occursin("physical_total_factor", summary) == (spin == :both)
                plotted = P.read_spectrum_csv(paths[spin])
                @test plotted.spin == spin
                @test isapprox(P.trapezoid_integral(plotted.omega, plotted.spectrum),
                               C.physical_trace_factor(spin); atol=ATOL, rtol=0.0)
                before = C.SmoQyDEAC.calls[]
                skipped = redirect_stdout(devnull) do
                    C.continue_channel(data, options, :ktrace, 2, 1, 123)
                end
                @test skipped.status == "skipped"
                @test C.SmoQyDEAC.calls[] == before
            end
            up = P.read_spectrum_csv(paths[:up])
            down = P.read_spectrum_csv(paths[:down])
            both = P.read_spectrum_csv(paths[:both])
            @test P.validate_comparison(up, down) === nothing
            @test_throws ErrorException P.validate_comparison(up, both)
            @test_throws ErrorException P.validate_comparison(up, up)
            @test_throws ErrorException P.validate_comparison(up, merge(down, (; omega=down.omega .+ 0.1)))
            options = P.parse_options([paths[:up], "spins.png", "At X", "--compare=$(paths[:down])"])
            @test options.comparison_path == paths[:down]
            @test options.title == "At X"
            @test_throws ErrorException P.parse_options([paths[:up], "--compare="])
            @test P.parse_options(["--help"]) === nothing
        end
    end
end

end
