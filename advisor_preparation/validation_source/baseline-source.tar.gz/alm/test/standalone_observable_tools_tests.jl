using LinearAlgebra
using Test

include(joinpath(
    @__DIR__,
    "..",
    "scripts",
    "two_orbital_observable_tools.jl",
))
include(joinpath(
    @__DIR__,
    "..",
    "scripts",
    "two_orbital_atom_ed.jl",
))

using .TwoOrbitalObservableTools
using .TwoOrbitalAtomED

const STANDALONE_ATOL = 2.0e-12

@testset "Standalone two-orbital observable tools" begin
    @testset "Eq. 4 product, contact, and Wick terms" begin
        # One d_xz-up particle and one d_yz-down particle give the perfectly
        # ordered one-cell product state O_alm = 1.
        ordered = altermagnetic_observables_from_greens(
            Matrix(Diagonal([0.0, 1.0])),
            Matrix(Diagonal([1.0, 0.0])),
            1,
        )
        @test ordered == (
            mx=1.0,
            my=-1.0,
            m_fm=0.0,
            delta_alm=1.0,
            S_alm_q0=1.0,
            m_alm_squared=1.0,
        )

        # Four independent half-filled modes have <O_alm> = 0 but
        # <O_alm^2> = 1/4. This catches an omitted n_i^2 = n_i contact term.
        half_filled_green = Matrix(0.5I, 2, 2)
        contact = altermagnetic_observables_from_greens(
            half_filled_green,
            half_filled_green,
            1,
        )
        @test contact.delta_alm == 0.0
        @test contact.S_alm_q0 == 0.25
        @test contact.m_alm_squared == 0.25

        # A nonzero one-body coherence contributes the exchange contraction.
        # For C_up = <c^dagger c> below and an empty down sector,
        # Var(O_alm) = 1/4[p(1-p)+q(1-q)] + |c|^2/2.
        density_up = [0.6 0.2; 0.2 0.3]
        coherent = altermagnetic_observables_from_greens(
            Matrix{Float64}(I, 2, 2) - density_up,
            Matrix{Float64}(I, 2, 2),
            1,
        )
        expected_mean = (0.6 - 0.3) / 2
        expected_variance =
            (0.6 * 0.4 + 0.3 * 0.7) / 4 + abs2(0.2) / 2
        expected_second_moment = expected_mean^2 + expected_variance
        @test isapprox(
            coherent.delta_alm,
            expected_mean;
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
        @test isapprox(
            coherent.S_alm_q0,
            expected_second_moment;
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )

        signed_bin = zeros(length(ALTERMAGNETIC_FIELDS))
        raw = accumulate_altermagnetic!(
            signed_bin,
            half_filled_green,
            half_filled_green,
            1,
            -1.0,
        )
        @test signed_bin == -[getproperty(raw, name) for name in ALTERMAGNETIC_FIELDS]
    end

    @testset "Mixed-sign ratio jackknife uses the sign exactly once" begin
        # Each row is already a signed numerator sum. The middle bin has a
        # negative sign sum; multiplying these rows by a sign again would give
        # a different full ratio and is therefore detected by this example.
        sign_sums = [3.0, -1.0, 2.0]
        counts = [5, 5, 5]
        numerator_bins = [
             3.0   6.0
            -3.0  -4.0
            10.0  12.0
        ]
        statistics = sign_reweighted_channel_statistics(
            numerator_bins,
            sign_sums,
            counts;
            minimum_average_sign=0.0,
        )

        @test statistics.values == [2.5, 3.5]
        @test statistics.full_sign_sum == 4.0
        @test statistics.full_count == 15
        @test statistics.full_average_sign == 4 / 15
        @test statistics.full_denominator_usable
        @test statistics.leave_one_out_denominators_usable

        leave_one_out = [
            7.0  8.0
            2.6  3.6
            0.0  1.0
        ]
        center = vec(sum(leave_one_out; dims=1)) / 3
        expected_covariance = zeros(2, 2)
        for bin in axes(leave_one_out, 1)
            deviation = view(leave_one_out, bin, :) .- center
            expected_covariance .+= deviation * transpose(deviation)
        end
        expected_covariance .*= 2 / 3
        @test isapprox(
            statistics.covariance,
            expected_covariance;
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
        @test isapprox(
            statistics.standard_errors,
            sqrt.(diag(expected_covariance));
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )

        gated = sign_reweighted_channel_statistics(
            numerator_bins,
            sign_sums,
            counts;
            minimum_average_sign=0.11,
        )
        @test gated.full_denominator_usable
        @test !gated.leave_one_out_denominators_usable
        @test gated.covariance === missing
        @test gated.standard_errors === missing
    end

    @testset "Finite-grid U=0 oracle and serialization" begin
        beta = 0.7
        mu = -0.2
        tau = collect(range(0.0, beta; length=8))
        momenta = [0.0, pi]
        hopping = (-1.0, -1.75, -0.85, -0.65)
        exact = exact_free_momentum_greens(
            tau,
            momenta,
            beta,
            mu,
            hopping...,
        )
        @test size(exact) == (2, 2, 2, 2, 2, 8)
        endpoint_identity = reshape(
            Matrix{ComplexF64}(I, 2, 2),
            1,
            2,
            2,
            1,
            1,
        )
        @test maximum(abs.(
            exact[:, :, :, :, :, 1] .+
            exact[:, :, :, :, :, end] .-
            endpoint_identity
        )) <= STANDALONE_ATOL

        # Build exact signed sums for two positive-sign bins. Validation must
        # divide their total numerator by their total sign only once.
        green_bins = zeros(ComplexF64, 2, size(exact)...)
        view(green_bins, 1, :, :, :, :, :, :) .= 2 .* exact
        view(green_bins, 2, :, :, :, :, :, :) .= 3 .* exact
        metadata = Dict{String,Any}(
            "U" => 0.0,
            "beta" => beta,
            "mu_measured" => mu,
            "t1" => hopping[1],
            "t2" => hopping[2],
            "t3" => hopping[3],
            "t4" => hopping[4],
        )
        payload = build_observable_payload(
            metadata=metadata,
            tau=tau,
            momenta=momenta,
            basic_bins=Dict{String,Any}(),
            altermagnetic_signed_bins=zeros(2, 6),
            green_sign_sums=[2.0, 3.0],
            green_counts=[2, 3],
            green_signed_momentum_bins=green_bins,
            green_maximum_stabilization_errors=zeros(2, 2),
        )
        validation = validate_u0_green_payload(payload; atol=STANDALONE_ATOL)
        @test validation.passed
        @test validation.maximum_error <= STANDALONE_ATOL
        @test validation.endpoint_error <= STANDALONE_ATOL

        mktempdir() do directory
            path = joinpath(directory, "observables.jls")
            saved_path = save_observable_payload(path, payload)
            @test saved_path == abspath(path)
            loaded = load_observable_payload(path)
            @test loaded["schema_version"] == 1
            @test loaded["metadata"] == metadata
            @test loaded["green_signed_momentum_bins"] == green_bins
            @test_throws ArgumentError save_observable_payload(path, payload)
        end
    end

    @testset "Two-orbital Hubbard atom exact sum rules" begin
        U = 2.0
        mu = 0.0
        beta = 3.0
        tau = [0.0, beta / 2, beta]
        exact = solve_two_orbital_atom(U, mu, beta, tau)

        @test exact.hilbert_dimension == 16
        @test isapprox(exact.density, 2.0; atol=STANDALONE_ATOL, rtol=0.0)
        @test isapprox(
            exact.double_occupancy,
            1 / (1 + exp(beta * U / 2));
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
        expected_S_alm = 1 / (2 * (1 + exp(-beta * U / 2)))
        @test isapprox(
            exact.S_alm_q0,
            expected_S_alm;
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
        @test exact.delta_alm == 0.0
        @test isapprox(
            exact.m_alm_squared,
            exact.S_alm_q0;
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )

        @test isapprox(
            exact.peak_frequencies,
            [-1.0, 1.0];
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
        @test isapprox(
            exact.peak_weights,
            [0.5, 0.5];
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
        @test isapprox(
            exact.spectral_zeroth_moment,
            1.0;
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
        @test isapprox(
            exact.green[1] + exact.green[end],
            1.0;
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
        expected_midpoint = exp(-beta / 2) / (1 + exp(-beta))
        @test isapprox(
            exact.green[2],
            expected_midpoint;
            atol=STANDALONE_ATOL,
            rtol=0.0,
        )
    end
end
