module TwoOrbitalClusterEDTests

using LinearAlgebra
using Serialization
using Test

include(joinpath(@__DIR__, "..", "scripts", "two_orbital_cluster_ed.jl"))
using .TwoOrbitalClusterED
const VK = TwoOrbitalClusterED.ValidatedKinetic

# Sector diagonalizations, matrix-element transformations, and thermal sums
# accumulate more roundoff than a 2x2 Bloch eigensolver. 2e-10 still lies far
# below Monte Carlo uncertainty and order-one physical energy/Green scales.
const ED_ATOL = 2.0e-10

function stable_kernel(omega, tau, beta)
    # Written independently in terms of occupied/unoccupied Fermi weights.
    occupation = omega >= 0 ? exp(-beta * omega) / (1 + exp(-beta * omega)) :
                 1 / (1 + exp(beta * omega))
    return omega >= 0 ? (1 - occupation) * exp(-tau * omega) :
                       occupation * exp((beta - tau) * omega)
end

@testset "Factorized 2x2 exact diagonalization" begin
    model = VK.ModelParameters()

    @testset "U=0 Bloch energies, Green functions, and thermal density" begin
        beta, mu = 1.3, -2.3
        tau = [0.0, 0.3, 0.8, beta]
        exact = solve_two_orbital_cluster(0.0, mu, beta, tau)
        expected_density = 0.0
        for ky in 1:2, kx in 1:2
            bloch = VK.bloch_hamiltonian(exact.momenta[kx], exact.momenta[ky], model)
            @test isapprox(VK.fourier_block(exact.kinetic, 2,
                exact.momenta[kx], exact.momenta[ky]), bloch; atol=ED_ATOL, rtol=0)
            for orbital in 1:2
                omega = bloch[orbital, orbital] - mu
                expected_density += 2 / (1 + exp(beta * omega)) / 4
                for spin in 1:2
                    channel = exact.spectral_peaks[spin, orbital, kx, ky]
                    @test length(channel.frequencies) == 1
                    @test isapprox(only(channel.frequencies), omega; atol=ED_ATOL, rtol=0)
                    @test isapprox(only(channel.weights), 1; atol=ED_ATOL, rtol=0)
                    @test isapprox(exact.green[spin, orbital, kx, ky, :],
                        [stable_kernel(omega, time, beta) for time in tau]; atol=ED_ATOL, rtol=0)
                end
            end
        end
        @test isapprox(exact.density, expected_density; atol=ED_ATOL, rtol=0)
        tuned = tune_cluster_mu(0.0, exact.density, beta)
        @test tuned.converged
        @test abs(tuned.residual) <= 1.0e-10
        @test isapprox(tuned.mu, mu; atol=2.0e-9, rtol=0)
        production_edge = tune_cluster_mu(0.0, 1.42, 10.0; h_alm=0.001)
        @test production_edge.converged
        @test abs(production_edge.residual) <= 1.0e-10
        # Symmetry makes both orbital/spin occupations equal in this model.
        @test isapprox(exact.double_occupancy, 2 * (expected_density / 4)^2; atol=ED_ATOL, rtol=0)
        @test exact.full_grand_spectrum === nothing
        @test exact.h_alm == 0.0
        @test abs(exact.delta_alm) < ED_ATOL
        @test abs(exact.total_spin_z_per_cell) < ED_ATOL
        for orbital in 1:2, spin_sector in ((1, 0), (0, 1))
            levels = [level for level in exact.orbital_levels[orbital]
                      if (level.Nup, level.Ndown) == spin_sector]
            @test length(levels) == 4
            for level in levels
                bloch = VK.bloch_hamiltonian(level.kx, level.ky, model)
                @test isapprox(level.energy, bloch[orbital, orbital] - mu;
                               atol=ED_ATOL, rtol=0)
            end
        end
    end

    @testset "Explicit altermagnetic source and X/Y spin relation" begin
        U, mu, beta, h = 2.0, -2.5, 3.0, 0.01
        tau = [0.0, beta / 2, beta]
        positive = solve_two_orbital_cluster(U, mu, beta, tau; h_alm=h)
        negative = solve_two_orbital_cluster(U, mu, beta, tau; h_alm=-h)
        @test positive.delta_alm > 0
        @test isapprox(positive.delta_alm, -negative.delta_alm; atol=ED_ATOL, rtol=0)
        @test abs(positive.total_spin_z_per_cell) < ED_ATOL
        @test isapprox(positive.orbital_magnetizations[1],
                       -positive.orbital_magnetizations[2]; atol=ED_ATOL, rtol=0)
        @test isapprox(positive.green[1, :, :, :, :],
                       negative.green[2, :, :, :, :]; atol=ED_ATOL, rtol=0)
        # Combined C4 orbital/momentum exchange and spin reversal remains a
        # symmetry of -h*O_alm: A_up(X)=A_down(Y), after tracing orbitals.
        @test isapprox(positive.spin_trace_green[1, 2, 1, :],
                       positive.spin_trace_green[2, 1, 2, :]; atol=ED_ATOL, rtol=0)
        @test isapprox(positive.spin_trace_green[2, 2, 1, :],
                       positive.spin_trace_green[1, 1, 2, :]; atol=ED_ATOL, rtol=0)
        @test positive.o_alm_per_cell == positive.delta_alm
        @test isapprox(positive.o_alm, 4positive.o_alm_per_cell; atol=ED_ATOL, rtol=0)
        omega = collect(-10.0:0.1:10.0)
        diagnostics = altermagnetic_xy_diagnostics(positive, omega; eta=0.1)
        @test diagnostics.xy_rotated_partner_max_error < ED_ATOL
        @test diagnostics.xy_contrast_antisymmetry_max_error < ED_ATOL
        @test diagnostics.dos_spin_max_error < ED_ATOL
        @test diagnostics.x_same_momentum_spin_contrast_max > 1.0e-3
        @test_throws ArgumentError spin_pairing_error(positive)

        free = solve_two_orbital_cluster(0.0, mu, beta, tau; h_alm=h)
        for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
            sigma = spin == 1 ? 1.0 : -1.0
            eta_orbital = orbital == 1 ? 1.0 : -1.0
            bloch = VK.bloch_hamiltonian(
                free.momenta[kx], free.momenta[ky], model,
            )
            expected = bloch[orbital, orbital] - mu - eta_orbital * sigma * h / 2
            @test isapprox(only(free.spectral_peaks[spin, orbital, kx, ky].frequencies),
                           expected; atol=ED_ATOL, rtol=0)
        end
    end

    @testset "Atomic limit agrees with independent four-state formula" begin
        U, mu, beta = 4.0, -0.7, 1.2
        tau = [0.0, 0.4, beta]
        no_hopping = VK.ModelParameters(0.0, 0.0, 0.0, 0.0)
        exact = solve_two_orbital_cluster(U, mu, beta, tau; parameters=no_hopping)
        energies = [U / 4, -U / 4 - mu, -U / 4 - mu, U / 4 - 2mu]
        probabilities = exp.(-beta .* (energies .- minimum(energies)))
        probabilities ./= sum(probabilities)
        expected_n = 2 * (probabilities[2] + probabilities[3] + 2probabilities[4])
        expected_double = 2probabilities[4]
        expected_green = [
            (probabilities[1] + probabilities[2]) * stable_kernel(energies[2] - energies[1], time, beta) +
            (probabilities[3] + probabilities[4]) * stable_kernel(energies[4] - energies[3], time, beta)
            for time in tau
        ]
        @test isapprox(exact.density, expected_n; atol=ED_ATOL, rtol=0)
        @test isapprox(exact.double_occupancy, expected_double; atol=ED_ATOL, rtol=0)
        for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
            @test isapprox(exact.green[spin, orbital, kx, ky, :], expected_green; atol=ED_ATOL, rtol=0)
            @test length(exact.spectral_peaks[spin, orbital, kx, ky].frequencies) == 2
        end
    end

    @testset "Finite U and hopping: independent two-particle matrix and sum rules" begin
        U, mu, beta = 2.0, -2.5, 1.7
        exact = solve_two_orbital_cluster(U, mu, beta, [0.0, beta / 2, beta]; include_full_spectrum=true)
        @test exact.hilbert_dimension == 65_536
        @test exact.largest_full_number_sector_dimension == 4_900
        @test exact.largest_full_momentum_sector_dimension == 1_252
        @test exact.largest_factorized_orbital_number_block == 36
        @test exact.largest_factorized_orbital_momentum_block == 12
        @test exact.largest_number_sector_block == 36
        @test exact.largest_diagonalized_block == 12
        @test length(exact.full_grand_spectrum) == 65_536
        @test length(exact.full_many_body_levels) == 65_536
        @test all(isfinite, exact.full_grand_spectrum)
        @test exact.full_grand_spectrum ==
              [level.energy for level in exact.full_many_body_levels]
        many_body_pairing = many_body_spin_pairing_error(exact)
        @test many_body_pairing.energy < ED_ATOL
        @test many_body_pairing.length_mismatch == 0
        @test many_body_pairing.sectors_checked > 0
        for kx in 1:2, ky in 1:2
            @test count(level -> level.kx_index == kx && level.ky_index == ky,
                        exact.full_many_body_levels) == 16_384
        end
        for N in 0:16
            @test count(level -> level.N == N, exact.full_many_body_levels) ==
                  binomial(16, N)
        end
        for Nup in 0:8, Ndown in 0:8
            @test count(level -> level.Nup == Nup && level.Ndown == Ndown,
                        exact.full_many_body_levels) ==
                  binomial(8, Nup) * binomial(8, Ndown)
        end
        @test exact.spin_green_max_difference < ED_ATOL
        @test exact.spectral_moment_max_error < ED_ATOL
        @test iszero(exact.kinetic[1:2:8, 2:2:8])
        @test 0 < exact.density < 4
        @test 0 < exact.double_occupancy < 2
        # The endpoint separately computed from Lehmann transition matrix
        # elements must reproduce density from Fock-basis number operators.
        @test isapprox(sum(exact.green[:, :, :, :, end]) / 4, exact.density; atol=ED_ATOL, rtol=0)
        @test isapprox(exact.green[:, :, :, :, 1] + exact.green[:, :, :, :, end],
            ones(2, 2, 2, 2); atol=ED_ATOL, rtol=0)
        for channel in exact.spectral_peaks
            @test all(>=(0), channel.weights)
            @test isapprox(sum(channel.weights), 1; atol=ED_ATOL, rtol=0)
        end
        for orbital in 1:2
            levels = exact.orbital_levels[orbital]
            @test length(levels) == 256
            @test all(level -> level.N == level.Nup + level.Ndown &&
                level.Sz == (level.Nup - level.Ndown) / 2, levels)
            k = exact.kinetic[orbital:2:8, orbital:2:8]
            # Distinguishable up/down particles give a tensor-product kinetic
            # operator plus a diagonal U for coincident sites. For N=2 on four
            # orbitals the centered-interaction constant cancels its linear term.
            identity4 = Matrix{Float64}(I, 4, 4)
            independent_two_particle = kron(k, identity4) + kron(identity4, k) +
                Diagonal([U * (x == y) - 2mu for x in 1:4 for y in 1:4])
            actual = [level.energy for level in levels if level.Nup == 1 && level.Ndown == 1]
            @test isapprox(actual, eigvals(Symmetric(independent_two_particle)); atol=ED_ATOL, rtol=0)
            # Equal-spin two-particle levels instead obey Pauli exclusion, with
            # no double occupancy. This independently checks the hopping signs.
            epsilon = eigvals(Symmetric(k))
            expected_equal_spin = sort([epsilon[i] + epsilon[j] - 2mu for i in 1:4 for j in (i + 1):4])
            actual_equal_spin = [level.energy for level in levels if level.Nup == 2 && level.Ndown == 0]
            @test isapprox(actual_equal_spin, expected_equal_spin; atol=ED_ATOL, rtol=0)
            for nup in 0:4, ndown in 0:4
                left = [level.energy for level in levels if level.Nup == nup && level.Ndown == ndown]
                right = [level.energy for level in levels if level.Nup == ndown && level.Ndown == nup]
                @test isapprox(left, right; atol=ED_ATOL, rtol=0)
            end
        end
        orbital_sectors = TwoOrbitalClusterED._orbital_sectors(
            exact.kinetic[1:2:8, 1:2:8], U, mu,
        )
        sample_sector = orbital_sectors[(2, 2)]
        identity_sector = Matrix{Float64}(I, 36, 36)
        # The union of the four translation-resolved blocks must reproduce an
        # independent dense diagonalization of the unreduced number sector.
        @test isapprox(sample_sector.energies,
                       eigvals(Symmetric(sample_sector.hamiltonian));
                       atol=ED_ATOL, rtol=0)
        @test isapprox(sample_sector.translation_x^2, identity_sector;
                       atol=ED_ATOL, rtol=0)
        @test isapprox(sample_sector.translation_y^2, identity_sector;
                       atol=ED_ATOL, rtol=0)
        @test isapprox(sample_sector.translation_x * sample_sector.translation_y,
                       sample_sector.translation_y * sample_sector.translation_x;
                       atol=ED_ATOL, rtol=0)
        @test norm(sample_sector.hamiltonian * sample_sector.translation_x -
                   sample_sector.translation_x * sample_sector.hamiltonian) < ED_ATOL
        @test norm(sample_sector.hamiltonian * sample_sector.translation_y -
                   sample_sector.translation_y * sample_sector.hamiltonian) < ED_ATOL

        # c_k can connect only K_lower to K_upper=K_lower+k. Check both spin
        # channels and every cluster momentum in a representative interacting
        # sector. Forbidden amplitudes should vanish at roundoff scale.
        maximum_forbidden_amplitude = 0.0
        maximum_allowed_amplitude = 0.0
        for spin in 1:2, ny in 0:1, nx in 0:1
            lower_key = spin == 1 ? (1, 2) : (2, 1)
            lower = orbital_sectors[lower_key]
            upper = sample_sector
            operator = TwoOrbitalClusterED._momentum_annihilation(
                lower, upper, spin, nx, ny,
            )
            amplitudes = transpose(lower.vectors) * operator * upper.vectors
            for upper_index in axes(amplitudes, 2), lower_index in axes(amplitudes, 1)
                expected_upper_kx = mod(lower.kx_indices[lower_index] - 1 + nx, 2) + 1
                expected_upper_ky = mod(lower.ky_indices[lower_index] - 1 + ny, 2) + 1
                amplitude = abs(amplitudes[lower_index, upper_index])
                if upper.kx_indices[upper_index] == expected_upper_kx &&
                   upper.ky_indices[upper_index] == expected_upper_ky
                    maximum_allowed_amplitude = max(maximum_allowed_amplitude, amplitude)
                else
                    maximum_forbidden_amplitude = max(maximum_forbidden_amplitude, amplitude)
                end
            end
        end
        @test maximum_forbidden_amplitude < 1.0e-12
        @test maximum_allowed_amplitude > 0.5

        for Nup in 0:8, Ndown in 0:8, kx in 1:2, ky in 1:2
            left = sort([level.energy for level in exact.full_many_body_levels
                         if level.Nup == Nup && level.Ndown == Ndown &&
                            level.kx_index == kx && level.ky_index == ky])
            right = sort([level.energy for level in exact.full_many_body_levels
                          if level.Nup == Ndown && level.Ndown == Nup &&
                             level.kx_index == kx && level.ky_index == ky])
            @test isapprox(left, right; atol=ED_ATOL, rtol=0)
        end
        # Changing t4 cannot change this particular periodic cluster.
        alternative = solve_two_orbital_cluster(U, mu, beta, exact.tau;
            parameters=VK.ModelParameters(t4=0.0))
        @test exact.kinetic == alternative.kinetic
        @test isapprox(exact.green, alternative.green; atol=ED_ATOL, rtol=0)

        @testset "Matched DQMC payload and paired signed-bin comparison" begin
            signs, counts = [3.0, -1.0, 2.0], [4, 4, 4]
            greens = zeros(ComplexF64, 3, 2, 2, 2, 2, 2, length(exact.tau))
            for bin in 1:3, spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2, time in eachindex(exact.tau)
                greens[bin, spin, orbital, orbital, kx, ky, time] =
                    signs[bin] * exact.green[spin, orbital, kx, ky, time]
            end
            metadata = Dict("L" => 2, "U" => U, "mu_measured" => mu, "beta" => beta,
                "t1" => exact.hopping.t1, "t2" => exact.hopping.t2,
                "t3" => exact.hopping.t3, "t4" => exact.hopping.t4)
            payload = Dict{String,Any}(
                "kind" => "two_orbital_dqmc_observables", "schema_version" => 1,
                "metadata" => metadata, "tau" => exact.tau, "momenta" => exact.momenta,
                "green_axes" => (:bin, :spin, :destination_orbital, :source_orbital, :kx_index, :ky_index, :tau_index),
                "green_convention" => "G=<c(tau)c^dagger(0)>; no leading minus sign",
                "green_signed_momentum_bins" => greens, "green_sign_sums" => signs, "green_counts" => counts,
            )
            comparisons = compare_cluster_payload(payload, exact)
            @test length(comparisons) == 8length(exact.tau)
            @test maximum(abs(row.difference) for row in comparisons) < ED_ATOL
            @test all(row -> isapprox(row.average_sign, 1 / 3; atol=ED_ATOL, rtol=0), comparisons)
            # Explicit numerical oracle catches accidental extra sign factors
            # and verifies a nonzero paired delete-one-bin jackknife error.
            statistics = TwoOrbitalClusterED._paired_ratio([3.0, -2.0, 8.0], signs, counts)
            leave_one_out = [6.0, 11 / 5, 0.5]
            center = sum(leave_one_out) / 3
            @test statistics.value == 9 / 4
            @test isapprox(statistics.standard_error,
                sqrt(2 / 3 * sum((leave_one_out .- center).^2)); atol=ED_ATOL, rtol=0)
            @test_throws ArgumentError TwoOrbitalClusterED._paired_ratio([1.0, 2.0], [1.0, -1.0], [2, 2])
            @test_throws ArgumentError TwoOrbitalClusterED._paired_ratio([1.0, 2.0], [3.0, 2.0], [2, 2])
            @test_throws ArgumentError TwoOrbitalClusterED._paired_ratio([1.0, 2.0], [1.0, 1.0], [2.5, 2.5])
            payload["metadata"]["L"] = 4
            @test_throws ErrorException compare_cluster_payload(payload, exact)
            payload["metadata"]["L"] = 2
            mktempdir() do directory
                target = joinpath(directory, "ed")
                save_cluster_result(target, exact; comparison=comparisons)
                saved = open(deserialize, joinpath(target, "exact_cluster.jls"))
                @test saved["kind"] == "two_orbital_L2_cluster_ed"
                @test saved["result"].density == exact.density
                @test isfile(joinpath(target, "dqmc_green_comparison.csv"))
                @test countlines(joinpath(target, "full_many_body_levels.csv")) == 65_537
                @test_throws ArgumentError save_cluster_result(target, exact)
            end
        end
    end

    @testset "Canonical zero-temperature ground state and Lehmann spectrum" begin
        free = solve_two_orbital_ground_state(
            0.0, 6; include_full_spectrum=true,
        )
        single_particle_energies = sort([
            VK.bloch_hamiltonian(
                free.momenta[kx], free.momenta[ky], model,
            )[orbital, orbital]
            for spin in 1:2 for orbital in 1:2 for ky in 1:2 for kx in 1:2
        ])
        @test free.ensemble == "zero-temperature canonical fixed particle number"
        @test free.temperature == 0.0
        @test free.N == 6
        @test free.density == 1.5
        @test free.ground_degeneracy == 6
        @test isapprox(free.ground_energy, sum(single_particle_energies[1:6]);
                       atol=ED_ATOL, rtol=0)
        @test isapprox(free.mu_minus, single_particle_energies[6];
                       atol=ED_ATOL, rtol=0)
        @test isapprox(free.mu_plus, single_particle_energies[7];
                       atol=ED_ATOL, rtol=0)
        @test free.mu_reference == free.midgap_mu
        @test free.mu_reference_scheme == :midgap
        @test length(free.ground_levels) == free.ground_degeneracy
        @test all(level -> level.N == 6 &&
                  abs(level.energy - free.ground_energy) <= free.degeneracy_tolerance,
                  free.ground_levels)
        @test length(free.full_many_body_levels) == 65_536
        @test count(level -> level.N == 6, free.full_many_body_levels) == binomial(16, 6)
        @test free.full_canonical_spectrum ==
              getproperty.(free.full_many_body_levels, :energy)

        for spin in 1:2, orbital in 1:2, ky in 1:2, kx in 1:2
            bloch = VK.bloch_hamiltonian(
                free.momenta[kx], free.momenta[ky], model,
            )
            channel = free.spectral_peaks[spin, orbital, kx, ky]
            @test length(channel.frequencies) == 1
            @test isapprox(only(channel.frequencies),
                           bloch[orbital, orbital] - free.mu_reference;
                           atol=ED_ATOL, rtol=0)
            @test isapprox(only(channel.weights), 1; atol=ED_ATOL, rtol=0)
            @test isapprox(
                sum(free.addition_spectral_peaks[spin, orbital, kx, ky].weights) +
                sum(free.removal_spectral_peaks[spin, orbital, kx, ky].weights),
                1; atol=ED_ATOL, rtol=0,
            )
        end
        @test isapprox(
            sum(sum(channel.weights) for channel in free.removal_spectral_peaks),
            6; atol=ED_ATOL, rtol=0,
        )
        @test isapprox(
            sum(sum(channel.weights) for channel in free.addition_spectral_peaks),
            10; atol=ED_ATOL, rtol=0,
        )
        @test free.spectral_moment_max_error < ED_ATOL
        free_pairing = ground_state_spin_pairing_error(free)
        @test free_pairing.maximum < ED_ATOL
        @test free_pairing.length_mismatch == 0
        @test free_pairing.sectors_checked > 0

        interacting = solve_two_orbital_ground_state(2.0, 6)
        @test interacting.ground_degeneracy == 4
        @test interacting.same_N_gap > 0
        @test interacting.charge_gap >= -ED_ATOL
        @test isapprox(sum(interacting.spin_orbital_numbers), 6;
                       atol=ED_ATOL, rtol=0)
        @test isapprox(interacting.spin_particle_numbers[1],
                       interacting.spin_particle_numbers[2]; atol=ED_ATOL, rtol=0)
        @test abs(interacting.total_spin_z_per_cell) < ED_ATOL
        @test abs(interacting.delta_alm) < ED_ATOL
        @test interacting.o_alm2_per_cell2 > 0
        @test interacting.spectral_moment_max_error < ED_ATOL
        @test ground_state_spin_pairing_error(interacting).maximum < ED_ATOL
        sector_lookup = Dict(
            (row.Nup, row.Ndown, row.kx_index, row.ky_index) => row.energy
            for row in interacting.sector_ground_energies
        )
        for ((nup, ndown, kx, ky), energy) in sector_lookup
            @test isapprox(energy, sector_lookup[(ndown, nup, kx, ky)];
                           atol=ED_ATOL, rtol=0)
        end

        # The source selects opposite spin polarizations in the two orbitals.
        # Reversing it reverses the selected domain, while the combined C4 and
        # spin-reversal symmetry retains crossed X/Y spectral pairing.
        h = 0.01
        positive = solve_two_orbital_ground_state(2.0, 6; h_alm=h)
        negative = solve_two_orbital_ground_state(2.0, 6; h_alm=-h)
        @test positive.delta_alm > 0
        @test isapprox(positive.delta_alm, -negative.delta_alm;
                       atol=ED_ATOL, rtol=0)
        @test isapprox(positive.o_alm2_per_cell2, negative.o_alm2_per_cell2;
                       atol=ED_ATOL, rtol=0)
        @test abs(positive.total_spin_z_per_cell) < ED_ATOL
        @test_throws ArgumentError ground_state_spin_pairing_error(positive)
        omega = collect(-12.0:0.1:12.0)
        positive_broadened = broaden_cluster_spectra(positive, omega; eta=0.1)
        negative_broadened = broaden_cluster_spectra(negative, omega; eta=0.1)
        @test isapprox(positive_broadened.spectral[1, :, :, :, :],
                       negative_broadened.spectral[2, :, :, :, :];
                       atol=ED_ATOL, rtol=0)
        @test isapprox(positive_broadened.spectral[2, :, :, :, :],
                       negative_broadened.spectral[1, :, :, :, :];
                       atol=ED_ATOL, rtol=0)
        diagnostics = altermagnetic_xy_diagnostics(positive, omega; eta=0.1)
        @test diagnostics.xy_rotated_partner_max_error < ED_ATOL
        @test diagnostics.xy_contrast_antisymmetry_max_error < ED_ATOL
        @test diagnostics.dos_spin_max_error < ED_ATOL
        @test diagnostics.x_same_momentum_spin_contrast_max > 1.0e-3

        # Every L=2 allowed momentum makes sin(kx)sin(ky)=0, so changing t4
        # cannot affect the canonical ground state or its spectrum.
        no_t4 = solve_two_orbital_ground_state(
            2.0, 6; parameters=VK.ModelParameters(t4=0.0),
        )
        @test interacting.kinetic == no_t4.kinetic
        @test isapprox(interacting.ground_energy, no_t4.ground_energy;
                       atol=ED_ATOL, rtol=0)
        @test isapprox(
            broaden_cluster_spectra(interacting, omega; eta=0.1).spectral,
            broaden_cluster_spectra(no_t4, omega; eta=0.1).spectral;
            atol=ED_ATOL, rtol=0,
        )
    end

    @testset "Input validation" begin
        @test_throws ArgumentError solve_two_orbital_cluster(-1, 0, 1, [0.0, 1.0])
        @test_throws ArgumentError solve_two_orbital_cluster(2, NaN, 1, [0.0, 1.0])
        @test_throws ArgumentError solve_two_orbital_cluster(2, 0, 0, [0.0])
        @test_throws ArgumentError solve_two_orbital_cluster(2, 0, 1, [0.0, 2.0])
        @test_throws ArgumentError solve_two_orbital_cluster(2, 0, 1, Float64[])
        @test_throws ArgumentError solve_two_orbital_cluster(2, 0, 1, [0.0]; h_alm=Inf)
        @test_throws ArgumentError tune_cluster_mu(2, 0, 1)
        @test_throws ArgumentError tune_cluster_mu(2, 4, 1)
        @test_throws ArgumentError tune_cluster_mu(2, 2, 0)
        @test_throws ArgumentError tune_cluster_mu(2, 2, 1; mu_bounds=(1, -1))
        @test_throws ArgumentError tune_cluster_mu(2, 2, 1; max_iterations=0)
        @test_throws ArgumentError solve_two_orbital_ground_state(-1, 6)
        @test_throws ArgumentError solve_two_orbital_ground_state(2, 0)
        @test_throws ArgumentError solve_two_orbital_ground_state(2, 16)
        @test_throws ArgumentError solve_two_orbital_ground_state(2, true)
        @test_throws ArgumentError solve_two_orbital_ground_state(2, 6; h_alm=Inf)
        @test_throws ArgumentError solve_two_orbital_ground_state(
            2, 6; degeneracy_tolerance=-1,
        )
        @test_throws ArgumentError solve_two_orbital_ground_state(
            2, 6; degeneracy_tolerance=0,
        )
        @test_throws ArgumentError solve_two_orbital_ground_state(
            2, 6; mu_reference=:unsupported,
        )
    end
end

end # module
