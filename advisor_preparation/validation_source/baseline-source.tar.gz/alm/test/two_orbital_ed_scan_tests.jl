module TwoOrbitalEDScanTests

using Test

include(joinpath(@__DIR__, "..", "scripts", "two_orbital_cluster_ed.jl"))
using .TwoOrbitalClusterED

# Lehmann-sector diagonalizations and thermal sums accumulate more roundoff
# than the analytic 2x2 Bloch formulas. This matches the documented ED scale
# while remaining tiny compared with any physical spectral broadening.
const ED_SCAN_ATOL = 2.0e-10

@testset "Periodic 2x2 ED spectra and spin scan" begin
    beta = 1.0
    result = solve_two_orbital_cluster(2.0, -0.5, beta, [0.0, beta / 2, beta])

    pairing = spin_pairing_error(result)
    @test pairing.length_mismatch == 0
    @test pairing.frequency < ED_SCAN_ATOL
    @test pairing.weight < ED_SCAN_ATOL
    @test pairing.green < ED_SCAN_ATOL

    omega = collect(range(-20.0, 20.0; length=81))
    broadened = broaden_cluster_spectra(result, omega; eta=0.2)
    @test broadened.omega == omega
    @test broadened.eta == 0.2
    @test size(broadened.spectral) == (2, 2, 2, 2, length(omega))
    @test size(broadened.spin_trace) == (2, 2, 2, length(omega))
    @test size(broadened.dos) == (2, length(omega))
    @test length(broadened.total_dos) == length(omega)
    @test all(>=(0), broadened.spectral)
    @test isapprox(broadened.dos[1, :], broadened.dos[2, :];
                   atol=ED_SCAN_ATOL, rtol=0)

    scan = scan_spin_degeneracy([0.0, 2.0], -0.5, beta;
        tau=[0.0, beta], omega=omega, eta=0.2)
    @test length(scan.rows) == 2
    @test scan.first_audit_failure_U === nothing
    @test !scan.any_audit_failure
    @test all(row -> !row.spin_pairing_audit_failed, scan.rows)
    @test all(row -> row.maximum_spin_pairing_error < ED_SCAN_ATOL, scan.rows)
    @test scan.rows[1].U == 0.0
    @test scan.rows[2].U == 2.0
    @test occursin("not fixed density", scan.ensemble)
    @test occursin("cancels t4", scan.conclusion)

    # At low temperature the raw Lehmann construction contains numerically
    # null transitions from thermally inaccessible states. Pruning them below
    # machine precision must leave a paired physical spectral measure.
    cold = scan_spin_degeneracy([2.0, 3.0, 12.0], -2.5157, 10.0;
        tau=[0.0, 5.0, 10.0], omega=omega, eta=0.2)
    @test cold.first_audit_failure_U === nothing
    @test all(row -> row.spin_pole_length_mismatch == 0, cold.rows)
    @test all(row -> row.maximum_spin_pairing_error < ED_SCAN_ATOL, cold.rows)

    @test_throws ArgumentError broaden_cluster_spectra(result, Float64[])
    @test_throws ArgumentError broaden_cluster_spectra(result, [0.0, -1.0])
    @test_throws ArgumentError broaden_cluster_spectra(result, omega; eta=0.0)
    @test_throws ArgumentError scan_spin_degeneracy(Float64[], 0.0, beta)
    @test_throws ArgumentError scan_spin_degeneracy([-1.0], 0.0, beta)
    @test_throws ArgumentError scan_spin_degeneracy([0.0], 0.0, beta; tolerance=-1.0)
end

end # module
