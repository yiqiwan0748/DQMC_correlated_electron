module TwoOrbitalGroundObservablesTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "two_orbital_ground_observables.jl"))
using .TwoOrbitalGroundObservables
const ClusterED = TwoOrbitalGroundObservables.ED

# These routines project separately diagonalized, exactly degenerate sectors
# into many-body symmetry representations.  2e-10 is the same conservative
# absolute tolerance used by the underlying ED solver; observed residuals are
# normally 1e-14 or smaller.
const ED_ATOL = 2.0e-10

function spin_dictionary(classification)
    Dict(row.S => row.state_count for row in classification.ground.spin_content)
end

@testset "Ground-state symmetry and dynamical observables" begin
    @testset "Exact S2 multiplets on both sides of the finite-cluster crossing" begin
        weak = classify_ground_symmetries(2.0, 6; manifolds=3)
        strong = classify_ground_symmetries(12.0, 6; manifolds=3)

        @test weak.fixed_N_dimension == binomial(16, 6)
        @test weak.ground.degeneracy == 4
        @test spin_dictionary(weak) == Dict(0.0 => 1, 1.0 => 3)
        @test all(row.irrep_count_is_integer for row in weak.ground.spin_content)
        @test strong.ground.degeneracy == 16
        @test spin_dictionary(strong) ==
              Dict(0.0 => 1, 1.0 => 3, 2.0 => 5, 3.0 => 7)
        @test all(row.irrep_count == 1 for row in strong.ground.spin_content)

        for result in (weak, strong), manifold in result.manifolds
            @test manifold.gram_residual < ED_ATOL
            @test manifold.s2_quantization_residual < ED_ATOL
            @test manifold.c4_unitarity_residual < ED_ATOL
            @test manifold.c4_leakage < ED_ATOL
            @test manifold.c4_spin_commutator < ED_ATOL
            @test sum(row.count for row in manifold.c4_content) ==
                  manifold.degeneracy
            @test sum(row.state_count for row in manifold.spin_content) ==
                  manifold.degeneracy
            @test sum(row.state_count for row in manifold.joint_spin_c4_content) ==
                  manifold.degeneracy
        end
        @test Set(row.manifold for row in weak.sector_levels) == Set(1:3)
        @test count(row -> row.manifold == 1, weak.sector_levels) ==
              weak.ground.degeneracy
    end

    @testset "C4 signed permutation is unitary and has order four" begin
        # Test every basis state, not only selected eigenstates.  A signed
        # permutation must be bijective and C4^4 must be exactly the identity.
        destinations = Set{Int}()
        preserves_particle_number = true
        phases_are_signs = true
        has_order_four = true
        for state in 0:65_535
            rotated, phase = c4_fock_action(state)
            preserves_particle_number &= count_ones(rotated) == count_ones(state)
            phases_are_signs &= phase in (-1.0, 1.0)
            push!(destinations, rotated)
            accumulated_phase = phase
            current = rotated
            for _ in 2:4
                current, next_phase = c4_fock_action(current)
                accumulated_phase *= next_phase
            end
            has_order_four &= current == state && accumulated_phase == 1.0
        end
        @test preserves_particle_number
        @test phases_are_signs
        @test has_order_four
        @test length(destinations) == 65_536

        # Leakage from complete energy manifolds independently tests [H,C4]=0.
        classification = classify_ground_symmetries(4.0, 6; manifolds=4)
        @test maximum(row.c4_leakage for row in classification.manifolds) < ED_ATOL
    end

    @testset "T=0 Lehmann correlations and elastic O_alm weight" begin
        exact = ClusterED.solve_two_orbital_ground_state(2.0, 6)
        oalm = ground_state_dynamical_correlation(2.0, 6)
        @test oalm.operator == :spin_altermagnetic
        @test oalm.momentum_indices == (0, 0)
        @test isapprox(oalm.equal_time, exact.o_alm_squared;
                       atol=ED_ATOL, rtol=0)
        @test abs(oalm.mean - exact.o_alm) < ED_ATOL
        @test abs(oalm.lehmann_sum_rule_residual) < ED_ATOL
        @test oalm.inelastic_weight < ED_ATOL
        @test isapprox(oalm.elastic_weight, oalm.equal_time;
                       atol=ED_ATOL, rtol=0)
        @test oalm.degenerate_elastic_fluctuation > 0
        @test oalm.retarded_commutator_vanishes
        @test oalm.susceptibility_status ==
              :ill_defined_degenerate_ground_manifold

        spin_x = ground_state_dynamical_correlation(
            2.0, 6; operator=:spin_total, q=(1, 0),
            normalization=:sqrt_cells,
        )
        @test abs(spin_x.lehmann_sum_rule_residual) < ED_ATOL
        @test spin_x.inelastic_weight > 0
        @test spin_x.elastic_weight < ED_ATOL
        @test all(>=(0), spin_x.peaks.weights)
        @test all(>=(0), spin_x.peaks.frequencies)

        suite = ground_state_correlation_suite(2.0, 6)
        @test length(suite.channels) == 12
        @test all(abs(channel.lehmann_sum_rule_residual) < ED_ATOL
                  for channel in values(suite.channels))
        @test isapprox(suite.o_alm.equal_time, exact.o_alm_squared;
                       atol=ED_ATOL, rtol=0)
    end

    @testset "Exact Green functions and cluster self-energy" begin
        free = ClusterED.solve_two_orbital_ground_state(0.0, 6)
        matsubara = matsubara_green(free, [1.0, 1.0e8])
        @test !any(matsubara.at_pole)
        # The unit zeroth spectral moment implies lim_|z|->infinity zG(z)=1.
        @test maximum(abs.(1.0e8im .* matsubara.values[:, :, :, :, 2] .- 1)) <
              2.0e-7
        channel = free.spectral_peaks[1, 1, 1, 1]
        manual = sum(weight / (1im - frequency)
                     for (frequency, weight) in
                     zip(channel.frequencies, channel.weights))
        @test isapprox(matsubara.values[1, 1, 1, 1, 1], manual;
                       atol=ED_ATOL, rtol=0)

        retarded = retarded_green(free, [-1.0, 0.0, 1.0]; eta=0.2)
        @test all(isfinite, retarded.values)
        @test all(>=(0), retarded.spectral)

        points = [0.3 + 0.7im, -2.1 + 1.3im]
        self_energy = noninteracting_cluster_self_energy(free, points)
        @test all(self_energy.valid)
        @test maximum(abs, self_energy.values) < ED_ATOL
        expected_bare = zeros(2, 2, 2)
        model = ClusterED.ValidatedKinetic.ModelParameters()
        for ky in 1:2, kx in 1:2
            block = ClusterED.ValidatedKinetic.bloch_hamiltonian(
                free.momenta[kx], free.momenta[ky], model,
            )
            expected_bare[:, kx, ky] = diag(block)
        end
        @test isapprox(bare_cluster_energies(free), expected_bare;
                       atol=ED_ATOL, rtol=0)

        pole = only(channel.frequencies)
        at_pole = evaluate_lehmann_green(free, [pole])
        @test at_pole.at_pole[1, 1, 1, 1, 1]
        @test isnan(real(at_pole.values[1, 1, 1, 1, 1]))
        deliberately_invalid = noninteracting_cluster_self_energy(
            free, [0.3 + 0.7im]; green_zero_tolerance=1.0e6,
        )
        @test !any(deliberately_invalid.valid)
        @test all(deliberately_invalid.near_green_zero)

        # The present scalar Dyson helper uses the zero-source bare
        # dispersion. It must not silently interpret an explicit one-body
        # altermagnetic source as an interaction contribution.
        sourced_free = ClusterED.solve_two_orbital_ground_state(
            0.0, 6; h_alm=0.01,
        )
        @test_throws ArgumentError noninteracting_cluster_self_energy(
            sourced_free, [0.3 + 0.7im],
        )
    end

    @testset "Input validation" begin
        @test_throws ArgumentError classify_ground_symmetries(-1, 6)
        @test_throws ArgumentError classify_ground_symmetries(2, 0)
        @test_throws ArgumentError classify_ground_symmetries(2, 6; manifolds=0)
        @test_throws ArgumentError ground_state_dynamical_correlation(
            2, 6; operator=:o_alm, q=(1, 0),
        )
        @test_throws ArgumentError ground_state_dynamical_correlation(
            2, 6; operator=:unknown,
        )
        free = ClusterED.solve_two_orbital_ground_state(0.0, 6)
        @test_throws ArgumentError retarded_green(free, [0.0]; eta=-1)
        @test_throws ArgumentError evaluate_lehmann_green(free, ComplexF64[])
        @test_throws ArgumentError noninteracting_cluster_self_energy(
            free, [1im]; green_zero_tolerance=0,
        )
    end
end

end # module TwoOrbitalGroundObservablesTests
