module TwoOrbitalOpenClusterEDTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "two_orbital_open_cluster_ed.jl"))
using .TwoOrbitalOpenClusterED

# The dense and fully reorthogonalized Lanczos paths accumulate eigensolver
# roundoff. 1e-9 is still many orders below the hopping and interaction scales
# used here, while allowing the residual-based Lanczos stopping criterion.
const OPEN_ED_ATOL = 1.0e-9

orbital_index(x, y, orbital, Lx) = 2 * ((x - 1) + Lx * (y - 1)) + orbital

@testset "Open-cluster canonical exact diagonalization" begin
    @testset "Open kinetic matrix retains t4" begin
        parameters = ModelParameters(t1=0.0, t2=0.0, t3=0.0, t4=-0.65)
        kinetic = open_cluster_kinetic_matrix(2, 2, parameters)
        @test size(kinetic) == (8, 8)
        @test issymmetric(kinetic)

        plus_diagonal = kinetic[
            orbital_index(1, 1, 1, 2),
            orbital_index(2, 2, 2, 2),
        ]
        minus_diagonal = kinetic[
            orbital_index(1, 2, 1, 2),
            orbital_index(2, 1, 2, 2),
        ]
        @test plus_diagonal == parameters.t4
        @test minus_diagonal == -parameters.t4
        @test maximum(abs, kinetic[1:2:end, 2:2:end]) == abs(parameters.t4)
        @test kinetic != open_cluster_kinetic_matrix(
            2,
            2,
            ModelParameters(t1=0.0, t2=0.0, t3=0.0, t4=0.0),
        )
    end

    @testset "Sector size and centered interaction" begin
        kinetic = open_cluster_kinetic_matrix()
        basis = sector_basis(kinetic, 4, 4)
        @test length(basis) == binomial(8, 4)^2 == 4900

        atomic_kinetic = open_cluster_kinetic_matrix(
            1,
            1,
            ModelParameters(t1=0.0, t2=0.0, t3=0.0, t4=0.0),
        )
        atomic = sector_hamiltonian(atomic_kinetic, 2.0, 1, 1)
        @test size(atomic) == (4, 4)
        # With two spatial orbitals, the centered interaction is
        # U*(double_count - N/2 + M/4) = U*(double_count-1/2).
        @test sort(atomic.diagonal) == [-1.0, -1.0, 1.0, 1.0]
        @test_throws ArgumentError sector_hamiltonian(atomic_kinetic, -1.0, 1, 1)
    end

    @testset "U=0 many-body ground energy" begin
        kinetic = open_cluster_kinetic_matrix()
        one_particle_energies = eigvals(Symmetric(kinetic))
        expected = sum(one_particle_energies[1:2]) + one_particle_energies[1]
        result = ground_state_observables(kinetic, 0.0, 2, 1)
        @test result.N == 3
        @test result.dimension == binomial(8, 2) * binomial(8, 1)
        @test isapprox(result.energy, expected; atol=OPEN_ED_ATOL, rtol=0)
        @test result.residual < OPEN_ED_ATOL

        # Exercise the matrix-free implementation independently of :auto.
        hamiltonian = sector_hamiltonian(kinetic, 1.3, 1, 1)
        dense = ground_state_observables(hamiltonian; method=:dense)
        lanczos = ground_state_observables(
            hamiltonian;
            method=:lanczos,
            maxiter=size(hamiltonian, 1),
        )
        @test lanczos.converged
        @test isapprox(lanczos.energy, dense.energy; atol=OPEN_ED_ATOL, rtol=0)
        @test lanczos.residual < OPEN_ED_ATOL
    end

    @testset "Spin flip and field reversal" begin
        kinetic = open_cluster_kinetic_matrix()
        sectors = canonical_spin_sector_energies(kinetic, 3.0, 2)
        @test [(row.Nup, row.Ndown) for row in sectors] == [(0, 2), (1, 1), (2, 0)]
        @test spin_flip_error(sectors) < OPEN_ED_ATOL
        @test spin_flip_error(kinetic, 3.0, 2) < OPEN_ED_ATOL

        field = 0.37
        up = ground_state_observables(kinetic, 2.0, 1, 0; h=field)
        spin_flipped = ground_state_observables(kinetic, 2.0, 0, 1; h=-field)
        @test isapprox(up.energy, spin_flipped.energy; atol=OPEN_ED_ATOL, rtol=0)
        @test isapprox(up.oalm, -spin_flipped.oalm; atol=OPEN_ED_ATOL, rtol=0)
        @test isapprox(up.oalm2, spin_flipped.oalm2; atol=OPEN_ED_ATOL, rtol=0)
    end

    @testset "Fixed-N U scan" begin
        scan = scan_u([0.0, 2.0])
        @test scan.boundary == :open
        @test scan.N == 2
        @test length(scan.rows) == 2
        @test all(row -> length(row.sector_energies) == 3, scan.rows)
        @test all(row -> row.spin_flip_error < OPEN_ED_ATOL, scan.rows)
        @test all(row -> all(sector -> sector.converged, row.sector_energies), scan.rows)
        @test_throws ArgumentError scan_u([-1.0])
        @test_throws ArgumentError scan_u([true])
    end
end

end # module
