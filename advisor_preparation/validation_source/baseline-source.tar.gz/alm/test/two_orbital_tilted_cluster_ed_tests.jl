module TwoOrbitalTiltedClusterEDTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "two_orbital_tilted_cluster_ed.jl"))
using .TwoOrbitalTiltedClusterED

const ATOL = 2.0e-12

function same_momentum(left, right; atol=ATOL)
    return all(abs(mod(left[index] - right[index] + pi, 2pi) - pi) <= atol for index in 1:2)
end

@testset "General tilted-torus geometry" begin
    torus = standard_eight_site_torus()
    @test torus.a1 == (2, 2)
    @test torus.a2 == (-2, 2)
    @test torus.signed_determinant == 8
    @test torus.ncells == 8
    @test length(torus.cells) == 8
    @test length(unique(torus.signatures)) == 8
    @test length(torus.index_by_signature) == 8
    @test has_c4_symmetry(torus)

    momenta = allowed_torus_momenta(torus)
    @test length(momenta) == torus.ncells
    @test length(unique(momenta)) == torus.ncells
    for target in ((0.0, 0.0), (pi, 0.0), (0.0, pi), (pi, pi))
        @test any(momentum -> same_momentum(momentum, target), momenta)
    end
    active_diagonal_momenta = [
        momentum for momentum in momenta
        if abs(sin(momentum[1]) * sin(momentum[2])) > 0.5
    ]
    @test length(active_diagonal_momenta) == 4
    for momentum in momenta, translation in (torus.a1, torus.a2)
        phase = cis(momentum[1] * translation[1] + momentum[2] * translation[2])
        @test isapprox(phase, 1; atol=ATOL, rtol=0)
    end

    rectangular = tilted_torus((2, 0), (0, 3))
    @test rectangular.ncells == 6
    @test length(allowed_torus_momenta(rectangular)) == 6
    @test !has_c4_symmetry(rectangular)
    reversed = tilted_torus((-2, 2), (2, 2))
    @test reversed.ncells == 8
    @test Set(reversed.momenta) == Set(torus.momenta)
    @test_throws ArgumentError tilted_torus((1, 1), (2, 2))
    @test_throws ArgumentError torus_single_particle_index(torus, 0, 1)
    @test_throws ArgumentError torus_single_particle_index(torus, 1, 3)
end

@testset "Tilted kinetic matrix and Bloch equivalence" begin
    parameters = ModelParameters()
    for torus in (standard_eight_site_torus(), tilted_torus((2, 0), (0, 3)))
        kinetic = tilted_kinetic_matrix(torus, parameters)
        @test size(kinetic) == (2torus.ncells, 2torus.ncells)
        @test issymmetric(kinetic)
        @test eltype(kinetic) == Float64
        for (kx, ky) in allowed_torus_momenta(torus)
            projected = torus_fourier_block(kinetic, torus, kx, ky)
            expected = bloch_hamiltonian(kx, ky, parameters)
            @test isapprox(projected, expected; atol=ATOL, rtol=0)
        end
        @test_throws DimensionMismatch torus_fourier_block(
            zeros(2, 2), torus, 0.0, 0.0,
        )
    end

    torus = standard_eight_site_torus()
    without_t4 = ModelParameters(
        parameters.t1, parameters.t2, parameters.t3, 0.0,
    )
    kinetic = tilted_kinetic_matrix(torus, parameters)
    kinetic_without_t4 = tilted_kinetic_matrix(torus, without_t4)
    @test maximum(abs, kinetic - kinetic_without_t4) > 1
    @test !iszero(kinetic[1:2:end, 2:2:end])
    active = only(filter(
        momentum -> same_momentum(momentum, (pi / 2, pi / 2)),
        allowed_torus_momenta(torus),
    ))
    projected = torus_fourier_block(kinetic, torus, active...)
    @test abs(projected[1, 2]) > 1
    @test isapprox(
        projected[1, 2], -4parameters.t4 * sin(active[1]) * sin(active[2]);
        atol=ATOL, rtol=0,
    )
end

@testset "Exact allocation-free resource accounting" begin
    torus = standard_eight_site_torus()
    estimate = sector_resource_estimate(torus; N=12, Nup=6, Ndown=6)
    @test estimate.ncells == 8
    @test estimate.spatial_orbitals == 16
    @test estimate.spin_orbitals == 32
    @test estimate.full_hilbert_dimension == big(4_294_967_296)
    @test estimate.fixed_N_dimension == big(225_792_840)
    @test estimate.fixed_Nup_Ndown_dimension == big(64_128_064)
    @test estimate.one_sector_vector_bytes == big(513_024_512)
    @test estimate.minimum_krylov_vector_bytes == big(1_539_073_536)
    @test estimate.largest_fixed_Nup_Ndown_momentum_dimension == big(8_017_184)
    @test sum(block.fixed_N_dimension for block in estimate.momentum_blocks) ==
          estimate.fixed_N_dimension
    @test sum(block.fixed_Nup_Ndown_dimension for block in estimate.momentum_blocks) ==
          estimate.fixed_Nup_Ndown_dimension
    @test all(block -> block.vector_bytes == 8block.fixed_Nup_Ndown_dimension,
              estimate.momentum_blocks)

    vacuum = sector_resource_estimate(torus; N=0, Nup=0, Ndown=0)
    @test [block.fixed_Nup_Ndown_dimension for block in vacuum.momentum_blocks] ==
          BigInt[1, 0, 0, 0, 0, 0, 0, 0]
    one_up = sector_resource_estimate(torus; N=1, Nup=1, Ndown=0)
    @test all(==(big(2)),
              [block.fixed_Nup_Ndown_dimension for block in one_up.momentum_blocks])

    feasibility = target_filling_feasibility(torus; filling=1.5)
    @test feasibility.N == 12
    @test feasibility.Nup == feasibility.Ndown == 6
    @test feasibility.realized_filling == 1.5
    @test !feasibility.local_target_sector_feasible
    @test !feasibility.full_spectrum_available
    @test !feasibility.target_Akw_available
    @test feasibility.removal_sector_estimate.fixed_Nup_Ndown_dimension ==
          big(34_978_944)
    @test feasibility.addition_sector_estimate.fixed_Nup_Ndown_dimension ==
          big(91_611_520)
    @test feasibility.three_vector_peak_spectral_bytes == big(2_198_676_480)
    @test occursin("N±1 Krylov", feasibility.recommended_method)
    @test occursin("64 GiB", feasibility.hpc_resource_note)
    @test occursin("full", lowercase(feasibility.full_spectrum_note))

    @test_throws EDResourceLimitError require_feasible_sector(
        torus; Nup=6, Ndown=6,
    )
    @test_throws EDResourceLimitError require_feasible_sector(
        torus; Nup=1, Ndown=1, max_basis_states=1,
    )
    @test_throws EDResourceLimitError dense_sector_hamiltonian(
        torus, 2.0, 1, 1; max_dense_bytes=1,
    )
    # This call must hit the analytic gate before constructing any of the
    # 64-million-state target basis.
    @test_throws EDResourceLimitError lanczos_lowest_sector(
        torus, 2.0, 6, 6; maxiter=10,
    )
    @test_throws ArgumentError sector_resource_estimate(
        torus; N=3, Nup=1, Ndown=1,
    )
end

@testset "Low-filling matrix-free Lanczos proof" begin
    torus = standard_eight_site_torus()
    for (U, Nup, Ndown) in ((0.0, 1, 0), (2.0, 1, 1), (4.0, 2, 0))
        dense = dense_sector_hamiltonian(torus, U, Nup, Ndown)
        expected = eigmin(Symmetric(dense))
        lanczos = lanczos_lowest_sector(
            torus, U, Nup, Ndown; maxiter=size(dense, 1),
        )
        @test lanczos.sector_dimension == size(dense, 1)
        @test lanczos.iterations <= size(dense, 1)
        @test lanczos.converged
        @test lanczos.residual_estimate <= 1.0e-10
        @test isapprox(lanczos.energy, expected; atol=2.0e-10, rtol=0)
    end

    # In the one-particle sector at U=0, the many-body ground energy is exactly
    # the lowest eigenvalue of the validated one-spin kinetic matrix.
    kinetic = tilted_kinetic_matrix(torus)
    one_particle = lanczos_lowest_sector(torus, 0.0, 1, 0; maxiter=16)
    @test isapprox(
        one_particle.energy, eigmin(Symmetric(kinetic)); atol=2.0e-10, rtol=0,
    )
end

end # module
