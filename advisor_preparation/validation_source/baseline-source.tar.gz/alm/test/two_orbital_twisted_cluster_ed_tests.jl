module TwoOrbitalTwistedClusterEDTests

using LinearAlgebra
using Test

include(joinpath(@__DIR__, "..", "scripts", "two_orbital_twisted_cluster_ed.jl"))
using .TwoOrbitalTwistedClusterED

# These checks combine phase accumulation and dense Hermitian eigensolvers.
# 2e-10 is comfortably above Float64 roundoff but far below the model scales.
const TWISTED_ED_ATOL = 2.0e-10

@testset "Twisted-boundary two-orbital ground-state ED" begin
    theta_x = 0.37
    theta_y = -0.61

    @testset "Hermiticity and periodic zero-twist oracle" begin
        kinetic = twisted_cluster_kinetic_matrix(2, theta_x, theta_y)
        @test size(kinetic) == (8, 8)
        @test ishermitian(kinetic)
        @test maximum(abs ∘ imag, kinetic) > 1.0e-3

        # A boundary twist is gauge-equivalent to shifting every allowed
        # periodic momentum by theta/L. This checks all four hopping channels,
        # including the interorbital sign convention, at once.
        shifted_bloch_energies = sort([
            energy
            for ky in (0.0, pi), kx in (0.0, pi)
            for energy in TwoOrbitalTwistedClusterED.ValidatedKinetic.band_energies(
                kx + theta_x / 2,
                ky + theta_y / 2,
                DEFAULT_PARAMETERS,
            )
        ])
        @test isapprox(
            eigvals(Hermitian(kinetic)),
            shifted_bloch_energies;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )

        zero_twist = twisted_cluster_kinetic_matrix(2, 0.0, 0.0)
        periodic_oracle =
            TwoOrbitalTwistedClusterED.ValidatedKinetic.realspace_kinetic_matrix(
                2,
                DEFAULT_PARAMETERS,
            )
        @test zero_twist == complex.(periodic_oracle)
    end

    @testset "A generic twist activates t4" begin
        t4_only = ModelParameters(t1=0.0, t2=0.0, t3=0.0, t4=-0.65)
        zero_twist = twisted_cluster_kinetic_matrix(2, 0.0, 0.0, t4_only)
        generic_twist = twisted_cluster_kinetic_matrix(
            2,
            theta_x,
            theta_y,
            t4_only,
        )
        @test maximum(abs, zero_twist[1:2:end, 2:2:end]) == 0.0
        @test maximum(abs, generic_twist[1:2:end, 2:2:end]) > 0.1
        @test maximum(abs, generic_twist) > 0.1
    end

    @testset "Large-gauge periodicity and time reversal" begin
        kinetic = twisted_cluster_kinetic_matrix(2, theta_x, theta_y)
        shifted_x = twisted_cluster_kinetic_matrix(2, theta_x + 2pi, theta_y)
        shifted_y = twisted_cluster_kinetic_matrix(2, theta_x, theta_y - 2pi)
        gauge_x = large_gauge_unitary(2, 1, 0)
        gauge_y = large_gauge_unitary(2, 0, -1)
        @test isapprox(
            shifted_x,
            gauge_x * kinetic * adjoint(gauge_x);
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
        @test isapprox(
            shifted_y,
            gauge_y * kinetic * adjoint(gauge_y);
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
        @test isapprox(
            eigvals(Hermitian(shifted_x)),
            eigvals(Hermitian(kinetic));
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
        time_reversed = twisted_cluster_kinetic_matrix(2, -theta_x, -theta_y)
        @test time_reversed == conj(kinetic)
        @test isapprox(
            eigvals(Hermitian(time_reversed)),
            eigvals(Hermitian(kinetic));
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
    end

    @testset "C4 covariance includes the orbital representation" begin
        kinetic = twisted_cluster_kinetic_matrix(2, theta_x, theta_y)
        rotated_kinetic = twisted_cluster_kinetic_matrix(2, -theta_y, theta_x)
        c4 = c4_single_particle_unitary(2, theta_x, theta_y)
        @test isapprox(c4 * adjoint(c4), I; atol=TWISTED_ED_ATOL, rtol=0)
        @test isapprox(
            c4 * kinetic * adjoint(c4),
            rotated_kinetic;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
        @test isapprox(
            eigvals(Hermitian(rotated_kinetic)),
            eigvals(Hermitian(kinetic));
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
    end

    @testset "Complex sector Hamiltonian and U=0 oracle" begin
        kinetic = twisted_cluster_kinetic_matrix(2, theta_x, theta_y)
        hamiltonian = sector_hamiltonian(kinetic, 0.0, 2, 1)
        dense = dense_sector_hamiltonian(hamiltonian)
        dimension = binomial(8, 2) * binomial(8, 1)
        @test size(dense) == (dimension, dimension)
        @test ishermitian(dense)

        one_body_energies = eigvals(Hermitian(kinetic))
        expected = sum(one_body_energies[1:2]) + one_body_energies[1]
        result = ground_state_observables(hamiltonian; method=:dense)
        @test isapprox(result.energy, expected; atol=TWISTED_ED_ATOL, rtol=0)
        @test result.residual < TWISTED_ED_ATOL
        @test result.ground_subspace_resolved
        @test isapprox(
            result.kinetic_energy,
            result.energy;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )

        # Independently exercise the matrix-free complex Lanczos path.
        interacting = sector_hamiltonian(kinetic, 1.7, 1, 1)
        dense_result = ground_state_observables(interacting; method=:dense)
        lanczos_result = ground_state_observables(
            interacting;
            method=:lanczos,
            maxiter=size(interacting, 1),
            atol=1.0e-13,
            rtol=1.0e-12,
        )
        @test lanczos_result.converged
        @test lanczos_result.residual < TWISTED_ED_ATOL
        @test isapprox(
            lanczos_result.energy,
            dense_result.energy;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
        @test !lanczos_result.ground_subspace_resolved
    end

    @testset "Spin flip and canonical observables" begin
        kinetic = twisted_cluster_kinetic_matrix(2, theta_x, theta_y)
        up = ground_state_observables(kinetic, 2.3, 2, 0; method=:dense)
        down = ground_state_observables(kinetic, 2.3, 0, 2; method=:dense)
        @test isapprox(up.energy, down.energy; atol=TWISTED_ED_ATOL, rtol=0)
        @test isapprox(up.oalm, -down.oalm; atol=TWISTED_ED_ATOL, rtol=0)
        @test isapprox(up.oalm2, down.oalm2; atol=TWISTED_ED_ATOL, rtol=0)
        @test isapprox(
            up.double_occupancy,
            down.double_occupancy;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )

        canonical = canonical_ground_state(kinetic, 2.3, 2; method=:dense)
        @test canonical.N == 2
        @test canonical.spin_flip_error < TWISTED_ED_ATOL
        @test canonical.max_residual < TWISTED_ED_ATOL
        @test abs(canonical.oalm) < TWISTED_ED_ATOL
        @test canonical.oalm2 >= -TWISTED_ED_ATOL
        @test canonical.double_occupancy >= -TWISTED_ED_ATOL
        @test canonical.ground_observables_exact
        @test isapprox(
            canonical.double_occupancy_total,
            4canonical.double_occupancy_per_cell;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
    end

    @testset "Unresolved N=6 manifold never masquerades as exact" begin
        # The exact periodic solver gives a four-dimensional manifold here:
        # one state in Sz=+/-1 and two states in Sz=0. One-vector Lanczos finds
        # only one of the two Sz=0 irreps, so its lower bound is three and its
        # naive Oalm^2 estimate would be 1/3 instead of the exact 1/2.
        kinetic = twisted_cluster_kinetic_matrix(2, 0.0, 0.0)
        canonical = canonical_ground_state(kinetic, 2.0, 6)
        @test isapprox(
            canonical.ground_energy,
            -23.973134525754286;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
        @test canonical.ground_degeneracy_lower_bound == 3 < 4
        @test !canonical.ground_subspace_resolved
        @test !canonical.ground_observables_exact
        @test ismissing(canonical.oalm)
        @test ismissing(canonical.oalm2)
        @test ismissing(canonical.oalm_variance)
        @test ismissing(canonical.double_occupancy)
        @test ismissing(canonical.double_occupancy_total)
        @test ismissing(canonical.double_occupancy_per_cell)
        @test isapprox(
            canonical.unresolved_estimate_oalm2,
            1 / 3;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
        @test isapprox(
            canonical.unresolved_estimate_double_occupancy_per_cell,
            0.20686260841541015;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
        @test isapprox(
            canonical.unresolved_estimate_double_occupancy_total,
            4canonical.unresolved_estimate_double_occupancy_per_cell;
            atol=TWISTED_ED_ATOL,
            rtol=0,
        )
    end

    @testset "Symmetry-related twist orbit scan" begin
        scan = canonical_twist_orbit_scan(
            1.1,
            2,
            theta_x,
            theta_y;
            method=:dense,
        )
        @test length(scan.rows) == 4
        @test [row.label for row in scan.rows] == [
            :identity,
            :time_reversal,
            :c4,
            :time_reversal_c4,
        ]
        @test scan.time_reversal_energy_error < TWISTED_ED_ATOL
        @test scan.c4_energy_error < TWISTED_ED_ATOL
        @test scan.symmetry_energy_spread < TWISTED_ED_ATOL
        @test scan.symmetry_audit_valid
        @test abs(scan.twist_averaged_oalm) < TWISTED_ED_ATOL
        @test scan.twist_averaged_oalm2 >= -TWISTED_ED_ATOL
        @test scan.twist_averaged_double_occupancy >= -TWISTED_ED_ATOL
        @test !scan.spectral_function_computed
        @test all(row -> row.spin_flip_error < TWISTED_ED_ATOL, scan.rows)
        @test all(row -> row.max_residual < TWISTED_ED_ATOL, scan.rows)

        u_scan = scan_u_twist_orbit(
            [0.0, 1.0],
            1,
            theta_x,
            theta_y;
            method=:dense,
        )
        @test length(u_scan) == 2
        @test all(row -> row.symmetry_energy_spread < TWISTED_ED_ATOL, u_scan)

        # Force the conservative one-vector path even for tiny blocks and
        # verify that missing canonical observables propagate through the
        # twist average instead of becoming apparently exact numbers.
        unresolved = canonical_twist_orbit_scan(
            1.1,
            1,
            theta_x,
            theta_y;
            method=:lanczos,
            maxiter=8,
            atol=1.0e-13,
            rtol=1.0e-12,
        )
        @test !unresolved.ground_observables_exact
        @test all(row -> !row.ground_observables_exact, unresolved.rows)
        @test ismissing(unresolved.twist_averaged_oalm)
        @test ismissing(unresolved.twist_averaged_oalm2)
        @test ismissing(unresolved.twist_averaged_double_occupancy)
        @test ismissing(unresolved.twist_averaged_double_occupancy_total)
        @test ismissing(unresolved.twist_averaged_double_occupancy_per_cell)
        @test isfinite(unresolved.twist_averaged_unresolved_estimate_oalm2)
    end

    @testset "Explicit resource safeguards" begin
        kinetic = twisted_cluster_kinetic_matrix(2, theta_x, theta_y)
        @test_throws ArgumentError sector_hamiltonian(
            kinetic,
            1.0,
            2,
            2;
            max_basis_dimension=100,
        )
        hamiltonian = sector_hamiltonian(kinetic, 1.0, 1, 1)
        @test_throws ArgumentError dense_sector_hamiltonian(
            hamiltonian;
            max_dense_bytes=100,
        )
        @test_throws ArgumentError ground_state_observables(
            hamiltonian;
            method=:lanczos,
            maxiter=20,
            max_krylov_bytes=100,
        )
        @test_throws ArgumentError twisted_cluster_kinetic_matrix(6)
        @test_throws ArgumentError scan_u_twist_orbit(
            [-1.0],
            2,
            theta_x,
            theta_y,
        )
    end
end

end # module
