using Test
using LinearAlgebra

include(joinpath(@__DIR__, "..", "hpc", "isaac", "u0_magnetic_control.jl"))
const U0Magnetic = ISAACU0MagneticControl

# Independent tiny Fock representation: all up modes precede all down modes.
# Slater amplitudes are determinants of occupied rows, not Wick contractions.
function tiny_slater_vector(occupied::AbstractMatrix{<:Real})
    nmodes, number = size(occupied)
    dimension = 1 << (2nmodes)
    vector = zeros(Float64, dimension)
    masks = [mask for mask in 0:((1 << nmodes) - 1) if count_ones(mask) == number]
    for up in masks, down in masks
        up_rows = [p for p in 1:nmodes if !iszero(up & (1 << (p - 1)))]
        down_rows = [p for p in 1:nmodes if !iszero(down & (1 << (p - 1)))]
        vector[(up | (down << nmodes)) + 1] = det(occupied[up_rows, :]) * det(occupied[down_rows, :])
    end
    return vector
end

function tiny_bilinear(vector, create, destroy)
    result = zeros(eltype(vector), length(vector))
    create_bit, destroy_bit = 1 << (create - 1), 1 << (destroy - 1)
    for state in 0:(length(vector) - 1)
        iszero(state & destroy_bit) && continue
        removed = state ⊻ destroy_bit
        iszero(removed & create_bit) || continue
        sign = isodd(count_ones(state & (destroy_bit - 1)) +
                     count_ones(removed & (create_bit - 1))) ? -1 : 1
        destination = removed | create_bit
        result[destination + 1] += sign * vector[state + 1]
    end
    return result
end

function tiny_spin_actions(vector, nmodes)
    sz = [zeros(eltype(vector), length(vector)) for _ in 1:nmodes]
    sp = [tiny_bilinear(vector, p, nmodes + p) for p in 1:nmodes]
    sm = [tiny_bilinear(vector, nmodes + p, p) for p in 1:nmodes]
    for p in 1:nmodes, state in 0:(length(vector) - 1)
        up = !iszero(state & (1 << (p - 1)))
        down = !iszero(state & (1 << (nmodes + p - 1)))
        sz[p][state + 1] = (up - down) * vector[state + 1] / 2
    end
    return (; sz, sp, sm)
end

function tiny_scalar_correlations(vector, nmodes)
    (; sz, sp, sm) = tiny_spin_actions(vector, nmodes)
    return [dot(sz[p], sz[q]) + (dot(sp[p], sp[q]) + dot(sm[p], sm[q])) / 2
            for p in 1:nmodes, q in 1:nmodes]
end

@testset "Exact U=0 scalar magnetic control" begin
    # Matrices below have dimension at most four. Absolute tolerances 2e-13
    # cover QR/determinant/Fock contractions in Float64, while Float32 and
    # 256-bit BigFloat checks use their corresponding arithmetic precision.
    atol = 2.0e-13
    seeds = ([1.0 2.0 -1.0 0.5; -0.3 1.2 2.2 -1.0;
              1.5 0.2 -0.4 1.7; 0.1 -0.8 1.3 2.0],
             [2.0 -0.1 0.4 1.0; 0.2 1.4 -0.8 0.3;
              -1.0 0.7 2.3 -0.2; 0.6 1.8 0.1 1.1])
    @testset "Independent Fock spin-operator agreement" begin
        for seed in seeds, number in 1:4
            occupied = Matrix(qr(seed).Q)[:, 1:number]
            projector = occupied * transpose(occupied)
            vector = tiny_slater_vector(occupied)
            scalar = U0Magnetic.scalar_spin_correlations(projector)
            direct = tiny_scalar_correlations(vector, 4)
            @test isapprox(norm(vector), 1; atol=atol, rtol=0)
            @test isapprox(scalar, direct; atol=atol, rtol=0)
            @test isapprox(sum(direct), 0; atol=atol, rtol=0)
            @test isapprox(diag(direct), (3 / 2) .* (diag(projector) - diag(projector).^2); atol=atol, rtol=0)
            # Double occupancy is measured using explicit Fock probabilities.
            for p in 1:4
                measured_double = sum(abs2(vector[state + 1]) for state in 0:(length(vector) - 1)
                                      if !iszero(state & (1 << (p - 1))) && !iszero(state & (1 << (4 + p - 1))))
                @test isapprox(measured_double, projector[p, p]^2; atol=atol, rtol=0)
            end
        end
    end
    @testset "Real arithmetic and input axes" begin
        projector = [0.5 0.5; 0.5 0.5]
        exact = [0.375 -0.375; -0.375 0.375]
        @test U0Magnetic.scalar_spin_correlations(projector) == exact
        @test U0Magnetic.scalar_spin_correlations(Float32.(projector)) isa Matrix{Float32}
        @test isapprox(U0Magnetic.scalar_spin_correlations(Float32.(projector)), exact; atol=2eps(Float32), rtol=0)
        @test U0Magnetic.scalar_spin_correlations(BigFloat.(projector)) isa Matrix{BigFloat}
        @test isapprox(U0Magnetic.scalar_spin_correlations(BigFloat.(projector)), BigFloat.(exact); atol=2eps(BigFloat), rtol=0)
        @test_throws DimensionMismatch U0Magnetic.scalar_spin_correlations(zeros(2, 3))
    end
    @testset "Translation and momentum normalization against direct pair sum" begin
        torus = U0Magnetic.Geometry.tilted_torus((2, 0), (0, 1))
        occupied = Matrix(qr(first(seeds)).Q)[:, 1:2]
        scalar = tiny_scalar_correlations(tiny_slater_vector(occupied), 4)
        translated = U0Magnetic.translation_correlations(scalar, torus)
        factors = U0Magnetic.momentum_structure_factors(translated, torus)
        channels = U0Magnetic.even_odd_factors(factors)
        for (qindex, (qx, qy)) in enumerate(torus.momenta), a in 1:2, b in 1:2
            direct = sum(cis(qx * (rj[1] - ri[1]) + qy * (rj[2] - ri[2])) * scalar[2i - 2 + a, 2j - 2 + b]
                         for (i, ri) in enumerate(torus.cells) for (j, rj) in enumerate(torus.cells)) / torus.ncells
            @test isapprox(factors[a, b, qindex], direct; atol=atol, rtol=0)
        end
        zero_r = findfirst(==((0, 0)), torus.cells)
        zero_q = findfirst(==((0.0, 0.0)), torus.momenta)
        @test isapprox(dropdims(sum(factors; dims=3); dims=3) / torus.ncells, translated[:, :, zero_r]; atol=atol, rtol=0)
        @test abs(channels.even[zero_q]) <= atol
        for q in eachindex(torus.momenta)
            @test isapprox(factors[:, :, q], adjoint(factors[:, :, q]); atol=atol, rtol=0)
            @test minimum(eigvals(Hermitian(factors[:, :, q]))) >= -atol
            @test isapprox(channels.even[q], dot([1, 1], factors[:, :, q] * [1, 1]); atol=atol, rtol=0)
            @test isapprox(channels.odd[q], dot([1, -1], factors[:, :, q] * [1, -1]); atol=atol, rtol=0)
        end
        @test_throws DimensionMismatch U0Magnetic.translation_correlations(zeros(3, 3), torus)
        @test_throws DimensionMismatch U0Magnetic.momentum_structure_factors(zeros(2, 2, 3), torus)
        @test_throws DimensionMismatch U0Magnetic.even_odd_factors(zeros(3, 2, 2))
    end
end
