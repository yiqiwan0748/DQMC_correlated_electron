module ValidateConstrainedPathAFQMCTests

using AltermagnetDQMCTrial
using Test

include(joinpath(
    @__DIR__, "..", "scripts", "validate_constrained_path_afqmc.jl",
))

using .ValidateConstrainedPathAFQMC

function _validation_thermodynamic_observation(density, internal_energy)
    interaction_energy = 0.125
    kinetic_energy = internal_energy - interaction_energy
    return (
        density=Float64(density),
        doping=(Float64(density) - 2.0) / 4.0,
        kinetic_energy_per_cell=Float64(kinetic_energy),
        shifted_interaction_energy_per_cell=interaction_energy,
        internal_energy_per_cell=Float64(internal_energy),
        grand_energy_per_cell=Float64(internal_energy + 4.0 * density),
    )
end

function _validation_cp_summary(offset=0.0; standard_error=0.01)
    return (
        energy=1.0 + offset,
        energy_standard_error=standard_error,
        backpropagated_kinetic_energy=2.0 + offset,
        backpropagated_kinetic_energy_standard_error=standard_error,
        backpropagated_interaction_energy=3.0 + offset,
        backpropagated_interaction_energy_standard_error=standard_error,
        backpropagated_double_occupancy_per_cell=0.2 + offset,
        backpropagated_double_occupancy_standard_error=standard_error,
        S_alm_q0=0.4 + offset,
        S_alm_q0_standard_error=standard_error,
    )
end

@testset "CP-AFQMC validation driver" begin
    @testset "Options and profiles" begin
        defaults = parse_options(String[])
        @test defaults.profile == :quick
        @test defaults.seed_offset == 0
        @test isabspath(defaults.output_dir)

        parsed = parse_options([
            "--profile=STANDARD",
            "--seed-offset=-7",
            "--output-dir=temporary-validation",
        ])
        @test parsed.profile == :standard
        @test parsed.seed_offset == -7
        @test parsed.output_dir == abspath("temporary-validation")
        @test isnothing(parse_options(["--help"]))

        @test_throws ArgumentError parse_options(["--profile=long"])
        @test_throws ArgumentError parse_options(["--profile"])
        @test_throws ArgumentError parse_options(["--unknown=value"])
        @test_throws ArgumentError parse_options([
            "--profile=quick", "--profile=standard",
        ])
        @test_throws ArgumentError parse_options(["--output-dir="])

        quick = validation_plan(:quick)
        standard = validation_plan("standard")
        @test quick.profile == :quick
        @test length(quick.periodic_trials) >= 3
        @test length(quick.periodic_dtaus) >= 2
        @test length(quick.periodic_seeds) >= 2
        @test 20.0 in keys(quick.dimer_dtaus)
        @test length(quick.dimer_dtaus[20.0]) >= 2
        @test standard.periodic_walkers > quick.periodic_walkers
        @test standard.periodic_projection_time > quick.periodic_projection_time
        @test length(standard.periodic_trials) > length(quick.periodic_trials)
        @test length(
            ValidateConstrainedPathAFQMC._trial_requests(quick, :periodic),
        ) == 12
        @test length(
            ValidateConstrainedPathAFQMC._trial_requests(standard, :periodic),
        ) == 14
        @test length(
            ValidateConstrainedPathAFQMC._trial_requests(standard, :open),
        ) == 11
        @test length(
            ValidateConstrainedPathAFQMC._dimer_requests(standard, 4.0),
        ) == 5
        standard_dimer = ValidateConstrainedPathAFQMC._dimer_requests(
            standard, 20.0,
        )
        @test length(standard_dimer) == 9
        @test Set((request.dtau, request.base_seed)
                  for request in standard_dimer) == Set(
            (dtau, seed) for dtau in standard.dimer_dtaus[20.0]
            for seed in standard.dimer_seeds
        )
        @test length(ValidateConstrainedPathAFQMC._dimer_requests(
            quick, 20.0,
        )) == 2
        dimer_variants =
            ValidateConstrainedPathAFQMC._strong_dimer_convergence_requests(
                standard,
            )
        @test length(dimer_variants) == 12
        @test isempty(
            ValidateConstrainedPathAFQMC._strong_dimer_convergence_requests(
                quick,
            ),
        )
        @test Set(request.variant for request in dimer_variants) == Set((
            "projection8", "walkers960", "population10", "backprop3",
        ))
        @test all(request -> request.dtau == 0.0025, dimer_variants)
        for variant in standard.dimer_convergence_variants
            selected = [request for request in dimer_variants
                        if request.variant == variant.label]
            @test sort([request.base_seed for request in selected]) ==
                collect(standard.dimer_seeds)
            @test all(request -> request.projection_time ==
                variant.projection_time, selected)
            @test all(request -> request.walkers == variant.walkers, selected)
            @test all(request -> request.population_control_every ==
                variant.population_control_every, selected)
            @test all(request -> request.backpropagation_time ==
                variant.backpropagation_time, selected)
        end

        baseline_controls = ValidateConstrainedPathAFQMC._cp_controls(
            standard, :dimer, 0.0025, 317,
        )
        @test baseline_controls.warmup_steps == 1600
        @test baseline_controls.back_propagation_steps == 600
        @test baseline_controls.walker_count == 480
        @test baseline_controls.population_control_every == 5
        @test baseline_controls.measurement_count == 40
        strong_controls = ValidateConstrainedPathAFQMC._cp_controls(
            standard, :dimer, 0.0025, 317;
            measurement_count=standard.strong_dimer_measurements,
        )
        @test strong_controls.measurement_count == 240
        for request in dimer_variants
            controls = ValidateConstrainedPathAFQMC._cp_controls(
                standard, :dimer, request.dtau, request.base_seed;
                walker_count=request.walkers,
                projection_time=request.projection_time,
                measurement_count=standard.strong_dimer_measurements,
                backpropagation_time=request.backpropagation_time,
                population_control_every=request.population_control_every,
            )
            expected = only(filter(
                variant -> variant.label == request.variant,
                standard.dimer_convergence_variants,
            ))
            @test controls.warmup_steps == round(
                Int, expected.projection_time / request.dtau,
            )
            @test controls.back_propagation_steps == round(
                Int, expected.backpropagation_time / request.dtau,
            )
            @test controls.walker_count == expected.walkers
            @test controls.measurement_count == 240
            @test controls.population_control_every ==
                expected.population_control_every
        end

        quick_doped = ValidateConstrainedPathAFQMC._doped_open_requests(quick)
        @test length(quick_doped) == 1
        @test only(quick_doped).trial.label == "free"
        quick_doped_controls = ValidateConstrainedPathAFQMC._cp_controls(
            quick, :open, only(quick_doped).dtau,
            only(quick_doped).base_seed;
            backpropagation_time=only(quick_doped).backpropagation_time,
        )
        @test quick_doped_controls.back_propagation_steps > 0

        standard_doped =
            ValidateConstrainedPathAFQMC._doped_open_requests(standard)
        @test length(standard_doped) == 14
        doped_keys = [
            (request.variant, request.trial.label, request.base_seed)
            for request in standard_doped
        ]
        @test length(unique(doped_keys)) == length(doped_keys)
        @test count(request -> request.variant == "baseline", standard_doped) == 3
        @test count(request -> request.variant == "backprop4", standard_doped) == 3
        @test count(request -> request.variant == "population10", standard_doped) == 3
        nonfree = [request for request in standard_doped
                   if request.trial.label != "free"]
        @test [(request.trial.label, request.trial.pattern, request.trial.field)
               for request in nonfree] == [
            ("alm_plus", :altermagnetic, 0.1),
            ("alm_minus", :altermagnetic, -0.1),
            ("stripe_x", :stripe_x, 0.1),
            ("stripe_y", :stripe_y, 0.1),
            ("neel", :neel, 0.1),
        ]
        @test all(request -> request.base_seed ==
            first(standard.doped_open_seeds), nonfree)
        for request in standard_doped
            controls = ValidateConstrainedPathAFQMC._cp_controls(
                standard, :open, request.dtau, request.base_seed;
                measurement_count=request.measurement_count,
                backpropagation_time=request.backpropagation_time,
                population_control_every=request.population_control_every,
            )
            @test controls.warmup_steps == 800
            @test controls.walker_count == 256
            @test controls.back_propagation_steps ==
                (request.variant == "backprop4" ? 400 : 200)
            @test controls.population_control_every ==
                (request.variant == "population10" ? 10 : 5)
            @test controls.measurement_count ==
                (request.variant == "backprop4" ? 120 : 40)
        end
        standard_requests = ValidateConstrainedPathAFQMC._trial_requests(
            standard, :periodic,
        )
        for dtau in standard.periodic_dtaus, seed in standard.periodic_seeds
            @test any(request -> request.dtau == dtau &&
                request.trial.label == "free" && request.base_seed == seed,
                standard_requests)
        end
        @test standard.dqmc_dtaus == (0.1, 0.05, 0.025)
        @test length(quick.dqmc_dtaus) >= 2
        @test standard.dqmc_warmup_sweeps == 1024
        @test standard.dqmc_measurement_sweeps == 8192
        @test quick.dqmc_minimum_sign_effective_count == 16.0
        @test standard.dqmc_minimum_sign_effective_count == 128.0
        @test standard.dqmc_drift_block_size == 256
        @test standard.dqmc_block_stability_sizes == (64, 128, 256)
        @test standard.dqmc_random_difference_sigma == 3.0
        @test standard.dqmc_block_error_ratio_maximum == 2.0
        @test standard.dqmc_extrapolation_maximum_reduced_chi_squared == 9.0
        @test DQMC_BRIDGE_POINT == (
            L=2,
            U=2.0,
            beta=10.0,
            mu=-4.043283631438571,
            Nup=2,
            Ndown=2,
        )
    end


    @testset "DQMC convergence helper formulas and failures" begin
        finite_ratio = ValidateConstrainedPathAFQMC._finite_positive_ratio(
            [0.01, 0.012, 0.018],
        )
        @test finite_ratio.valid
        @test isapprox(finite_ratio.ratio, 1.8; atol=2.0e-15, rtol=0.0)
        @test ValidateConstrainedPathAFQMC._finite_positive_ratio(
            [0.01, 0.012, 0.021],
        ).ratio > 2.0
        for invalid in ([0.0, 0.01], [NaN, 0.01], [Inf, 0.01])
            result = ValidateConstrainedPathAFQMC._finite_positive_ratio(invalid)
            @test !result.valid
            @test result.ratio == Inf
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._finite_positive_ratio(Float64[])
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._finite_positive_ratio(["bad"])
        end

        difference = ValidateConstrainedPathAFQMC._difference_with_error(
            1.2, 0.03, 1.0, 0.04,
        )
        @test isapprox(difference.difference, 0.2; atol=1.0e-15, rtol=0.0)
        @test isapprox(
            difference.absolute_difference, 0.2; atol=1.0e-15, rtol=0.0,
        )
        @test difference.standard_error == 0.05
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._difference_with_error(
                1.0, -0.1, 1.0, 0.1,
            )
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._difference_with_error(
                NaN, 0.1, 1.0, 0.1,
            )
        end

        common = (
            check_id="strict",
            stage="unit_test",
            profile=:standard,
            system="test",
            boundary="none",
            method="synthetic",
            quantity="difference",
        )
        passing_checks = NamedTuple[]
        @test ValidateConstrainedPathAFQMC._strict_consistency_check!(
            passing_checks;
            common...,
            estimate=0.03,
            reference=0.0,
            standard_error=0.01,
            absolute_cap=0.04,
            sigma=4.0,
            precision_ceiling=0.02,
        )
        @test length(passing_checks) == 2
        @test all(check.passed for check in passing_checks)

        hard_cap_checks = NamedTuple[]
        @test !ValidateConstrainedPathAFQMC._strict_consistency_check!(
            hard_cap_checks;
            common...,
            estimate=0.05,
            reference=0.0,
            standard_error=0.5,
            absolute_cap=0.04,
            sigma=4.0,
            precision_ceiling=1.0,
        )
        @test !hard_cap_checks[1].passed
        statistical_checks = NamedTuple[]
        @test ValidateConstrainedPathAFQMC._statistical_consistency_check!(
            statistical_checks;
            common...,
            estimate=0.05,
            reference=0.0,
            standard_error=0.02,
            sigma=3.0,
            precision_ceiling=0.02,
        )
        @test statistical_checks[1].allowed_error == 0.06
        @test all(check.passed for check in statistical_checks)
        statistical_sigma_failure = NamedTuple[]
        @test !ValidateConstrainedPathAFQMC._statistical_consistency_check!(
            statistical_sigma_failure;
            common...,
            estimate=0.061,
            reference=0.0,
            standard_error=0.02,
            sigma=3.0,
            precision_ceiling=0.02,
        )
        @test !statistical_sigma_failure[1].passed
        @test statistical_sigma_failure[2].passed
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._statistical_consistency_check!(
                NamedTuple[];
                common...,
                estimate=0.0,
                reference=0.0,
                standard_error=0.01,
                sigma=0.0,
                precision_ceiling=0.02,
            )
        end
        zero_error_checks = NamedTuple[]
        @test !ValidateConstrainedPathAFQMC._strict_consistency_check!(
            zero_error_checks;
            common...,
            estimate=0.0,
            reference=0.0,
            standard_error=0.0,
            absolute_cap=0.04,
            sigma=4.0,
            precision_ceiling=0.02,
        )
        @test all(!check.passed for check in zero_error_checks)

        half_observations = [
            begin
                in_second_half = index > 32
                local_index = in_second_half ? index - 32 : index
                block_offset = 0.001 * div(local_index - 1, 8)
                _validation_thermodynamic_observation(
                    1.0 + block_offset + (in_second_half ? 0.002 : 0.0),
                    -4.7 + 10 * block_offset +
                        (in_second_half ? 0.01 : 0.0),
                )
            end for index in 1:64
        ]
        half_drift =
            ValidateConstrainedPathAFQMC._sign_reweighted_half_drift(
                ones(64),
                half_observations,
                :internal_energy_per_cell;
                block_size=8,
                minimum_sign_effective_count=16,
            )
        @test half_drift.valid
        @test half_drift.samples_per_half == 32
        @test half_drift.first_sign_effective_count == 32.0
        @test isapprox(
            half_drift.difference, -0.01; atol=2.0e-14, rtol=0.0,
        )
        invalid_half =
            ValidateConstrainedPathAFQMC._sign_reweighted_half_drift(
                repeat([1.0, -1.0], 32),
                half_observations,
                :density;
                block_size=8,
            )
        @test !invalid_half.valid
        @test ismissing(invalid_half.standard_error)
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._sign_reweighted_half_drift(
                ones(63), half_observations[1:63], :density; block_size=8,
            )
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._sign_reweighted_half_drift(
                ones(64), half_observations, :density; block_size=10,
            )
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._sign_reweighted_half_drift(
                ones(64), half_observations, :density; block_size=0,
            )
        end

        scan_observations = [
            _validation_thermodynamic_observation(
                1.0 + 0.01 * sin(0.13 * index),
                -4.7 + 0.04 * sin(0.07 * index) + 0.01 * cos(0.19 * index),
            ) for index in 1:256
        ]
        scan = ValidateConstrainedPathAFQMC._sign_reweighted_block_error_scan(
            ones(256),
            scan_observations,
            :internal_energy_per_cell,
            (8, 16, 32),
        )
        @test scan.valid
        @test all(isfinite, scan.standard_errors)
        @test scan.ratio >= 1.0
        @test scan.central_spread <= scan.central_tolerance
        constant_observations = fill(
            _validation_thermodynamic_observation(1.0, -4.7), 256,
        )
        zero_scan =
            ValidateConstrainedPathAFQMC._sign_reweighted_block_error_scan(
                ones(256),
                constant_observations,
                :internal_energy_per_cell,
                (32, 64, 128),
            )
        @test !zero_scan.valid
        @test zero_scan.ratio == Inf
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._sign_reweighted_block_error_scan(
                ones(256), scan_observations,
                :internal_energy_per_cell, (32, 32),
            )
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._sign_reweighted_block_error_scan(
                ones(255), scan_observations[1:255],
                :internal_energy_per_cell, (32, 64, 128),
            )
        end

        dtaus = [0.1, 0.05, 0.025]
        intercept = -4.75
        slope = 1.5
        errors = [0.02, 0.03, 0.04]
        values = intercept .+ slope .* abs2.(dtaus)
        fit = ValidateConstrainedPathAFQMC._weighted_dtau_squared_fit(
            dtaus, values, errors,
        )
        @test isapprox(fit.intercept, intercept; atol=2.0e-14, rtol=0.0)
        @test isapprox(fit.slope, slope; atol=2.0e-12, rtol=0.0)
        @test fit.degrees_of_freedom == 1
        @test fit.reduced_chi_squared <= 1.0e-20
        weights = inv.(abs2.(errors))
        x = abs2.(dtaus)
        xcenter = sum(weights .* x) / sum(weights)
        centered_x_sum = sum(weights .* abs2.(x .- xcenter))
        expected_intercept_error = sqrt(
            inv(sum(weights)) + xcenter^2 / centered_x_sum,
        )
        @test isapprox(
            fit.intercept_standard_error,
            expected_intercept_error;
            atol=2.0e-14,
            rtol=0.0,
        )
        permutation = [3, 1, 2]
        permuted_fit =
            ValidateConstrainedPathAFQMC._weighted_dtau_squared_fit(
                dtaus[permutation], values[permutation], errors[permutation],
            )
        @test isapprox(
            permuted_fit.intercept, fit.intercept; atol=2.0e-14, rtol=0.0,
        )
        scaled_fit = ValidateConstrainedPathAFQMC._weighted_dtau_squared_fit(
            dtaus, values, 3 .* errors,
        )
        @test isapprox(
            scaled_fit.intercept_standard_error,
            3 * fit.intercept_standard_error;
            atol=2.0e-14,
            rtol=0.0,
        )
        off_line_values = copy(values)
        off_line_values[2] += 1.0
        off_line_fit =
            ValidateConstrainedPathAFQMC._weighted_dtau_squared_fit(
                dtaus, off_line_values, fill(0.01, 3),
            )
        @test off_line_fit.reduced_chi_squared > 9.0
        @test off_line_fit.variance_scale == off_line_fit.reduced_chi_squared

        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._weighted_dtau_squared_fit(
                dtaus[1:2], values[1:2], errors[1:2],
            )
        end
        @test_throws DimensionMismatch begin
            ValidateConstrainedPathAFQMC._weighted_dtau_squared_fit(
                dtaus, values[1:2], errors,
            )
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._weighted_dtau_squared_fit(
                [0.1, 0.1, 0.05], values, errors,
            )
        end
        for invalid_errors in (
            [0.02, 0.0, 0.04],
            [0.02, NaN, 0.04],
            [0.02, Inf, 0.04],
        )
            @test_throws ArgumentError begin
                ValidateConstrainedPathAFQMC._weighted_dtau_squared_fit(
                    dtaus, values, invalid_errors,
                )
            end
        end
    end

    @testset "Precision gates and independent-seed pooling" begin
        common = (
            check_id="synthetic",
            stage="unit_test",
            profile=:quick,
            system="test",
            boundary="none",
            method="synthetic",
            quantity="energy",
        )
        noisy_checks = NamedTuple[]
        noisy_passed = ValidateConstrainedPathAFQMC._numeric_check!(
            noisy_checks;
            common...,
            estimate=1.0,
            reference=0.0,
            floor=0.1,
            sigma=5.0,
            standard_error=1.0,
            precision_ceiling=0.05,
        )
        @test !noisy_passed
        @test length(noisy_checks) == 2
        @test noisy_checks[1].passed
        @test !noisy_checks[2].passed
        @test noisy_checks[2].check_id == "synthetic:precision"
        @test noisy_checks[2].allowed_error == 0.05

        precise_checks = NamedTuple[]
        precise_passed = ValidateConstrainedPathAFQMC._numeric_check!(
            precise_checks;
            common...,
            estimate=0.04,
            reference=0.0,
            floor=0.1,
            sigma=5.0,
            standard_error=0.02,
            precision_ceiling=0.05,
        )
        @test precise_passed
        @test all(check.passed for check in precise_checks)

        pooled = ValidateConstrainedPathAFQMC._pool_independent_estimates(
            [1.0, 3.0], [0.3, 0.4],
        )
        @test pooled.mean == 2.0
        @test pooled.within_chain_standard_error == 0.25
        @test pooled.between_seed_standard_error == 1.0
        @test pooled.standard_error == 1.0
        @test pooled.count == 2

        singleton = ValidateConstrainedPathAFQMC._pool_independent_estimates(
            [2.0], [0.3],
        )
        @test singleton.mean == 2.0
        @test singleton.standard_error == 0.3
        @test singleton.between_seed_standard_error == 0.0
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._pool_independent_estimates([], [])
        end
        @test_throws DimensionMismatch begin
            ValidateConstrainedPathAFQMC._pool_independent_estimates([1.0], [])
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._pool_independent_estimates([1.0], [Inf])
        end
    end

    @testset "CP capped checks, observable mapping, and matched seeds" begin
        summary = _validation_cp_summary()
        @test ValidateConstrainedPathAFQMC._cp_summary_quantity(
            summary, :energy,
        ) == (estimate=1.0, standard_error=0.01)
        @test ValidateConstrainedPathAFQMC._cp_summary_quantity(
            summary, :backpropagated_double_occupancy_per_cell,
        ) == (estimate=0.2, standard_error=0.01)
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._cp_summary_quantity(summary, :missing)
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._cp_summary_quantity(
                _validation_cp_summary(0.0; standard_error=NaN), :energy,
            )
        end

        records = [
            (seed=11, summary=_validation_cp_summary(0.0)),
            (seed=22, summary=_validation_cp_summary(0.1)),
        ]
        pooled = ValidateConstrainedPathAFQMC._pool_cp_records(records, :energy)
        @test pooled.mean == 1.05
        @test pooled.count == 2
        shifted = [
            (seed=11, summary=_validation_cp_summary(0.02)),
            (seed=22, summary=_validation_cp_summary(0.12)),
        ]
        shift = ValidateConstrainedPathAFQMC._matched_cp_seed_shift(
            records, shifted, (11, 22), :energy,
        )
        @test shift.complete
        @test isapprox(shift.pool.mean, -0.02; atol=2.0e-16, rtol=0.0)
        @test isapprox(
            shift.pool.standard_error, 0.01; atol=2.0e-16, rtol=0.0,
        )
        incomplete = ValidateConstrainedPathAFQMC._matched_cp_seed_shift(
            records[1:1], shifted, (11, 22), :energy,
        )
        @test !incomplete.complete
        @test isnothing(incomplete.pool)
        duplicate = ValidateConstrainedPathAFQMC._matched_cp_seed_shift(
            [records[1], records[1]], shifted, (11, 22), :energy,
        )
        @test !duplicate.complete
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._matched_cp_seed_shift(
                records, shifted, (11, 11), :energy,
            )
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._matched_cp_seed_shift(
                records, shifted, (), :energy,
            )
        end

        paired_first = [
            (
                seed=seed,
                summary=_validation_cp_summary(),
                block_size=2,
                measurements=[
                    (step=index,
                     mixed_total_energy=value + offset,
                     backpropagated_double_occupancy_per_cell=0.1 * value)
                    for (index, value) in enumerate((1.0, 2.0, 5.0, 5.0))
                ],
            ) for (seed, offset) in ((11, 0.0), (22, 10.0))
        ]
        paired_second = [
            (
                seed=seed,
                summary=_validation_cp_summary(),
                block_size=2,
                measurements=[
                    (step=index,
                     mixed_total_energy=value + offset,
                     backpropagated_double_occupancy_per_cell=0.1 * value)
                    for (index, value) in enumerate((0.0, 1.0, 3.0, 4.0))
                ],
            ) for (seed, offset) in ((11, 0.0), (22, 10.0))
        ]
        paired = ValidateConstrainedPathAFQMC._matched_cp_seed_shift(
            paired_first, paired_second, (11, 22), :energy;
            paired_measurements=true,
        )
        @test paired.complete
        @test paired.paired_measurements
        @test paired.pool.mean == 1.25
        @test isapprox(
            paired.pool.standard_error,
            sqrt(0.25^2 + 0.25^2) / 2;
            atol=2.0e-16,
            rtol=0.0,
        )
        identity = ValidateConstrainedPathAFQMC._matched_cp_measurement_identity(
            paired_first, paired_first, (11, 22), :energy,
        )
        @test identity.complete
        @test identity.identical
        @test identity.compared == 8
        @test !ValidateConstrainedPathAFQMC._matched_cp_measurement_identity(
            paired_first, paired_second, (11, 22), :energy,
        ).identical

        fake_exact = (
            energy=-12.0,
            kinetic_energy=-11.0,
            centered_interaction_energy=-1.0,
            double_occupancy=0.8,
            oalm2=0.6,
        )
        standard_specs =
            ValidateConstrainedPathAFQMC._doped_open_quantity_specs(
                :standard, fake_exact,
            )
        @test [spec.quantity for spec in standard_specs] == collect(
            ValidateConstrainedPathAFQMC.CP_VALIDATION_QUANTITIES,
        )
        @test [spec.reference for spec in standard_specs] ==
            [-12.0, -11.0, -1.0, 0.2, 0.15]
        @test [spec.cap for spec in standard_specs] ==
            [0.02, 0.06, 0.03, 0.005, 0.01]
        quick_specs = ValidateConstrainedPathAFQMC._doped_open_quantity_specs(
            :quick, fake_exact,
        )
        @test all(index -> quick_specs[index].cap > standard_specs[index].cap,
                  eachindex(standard_specs))

        synthetic_result = (
            problem=(U=2.0, Nup=1, Ndown=1),
            parameters=(dtau=0.01, seed=7),
            trial_label="free",
            summary=(
                energy=0.05,
                energy_standard_error=0.019,
                backpropagated_double_occupancy_per_cell=missing,
                S_alm_q0=missing,
            ),
        )
        standard_checks = NamedTuple[]
        ValidateConstrainedPathAFQMC._add_cp_comparison!(
            standard_checks, :standard, "fixed_cap", synthetic_result,
            (energy=0.0, double_per_cell=missing);
            system="test", boundary="open", energy_floor=0.04,
            double_floor=0.0,
        )
        @test !standard_checks[1].passed
        @test standard_checks[1].allowed_error == 0.04
        @test standard_checks[2].passed
        quick_checks = NamedTuple[]
        ValidateConstrainedPathAFQMC._add_cp_comparison!(
            quick_checks, :quick, "smoke", synthetic_result,
            (energy=0.0, double_per_cell=missing);
            system="test", boundary="open", energy_floor=0.04,
            double_floor=0.0,
        )
        @test all(check.passed for check in quick_checks)
        @test quick_checks[1].allowed_error == 6 * 0.019

        common = (
            check_id="boundary",
            stage="unit_test",
            profile=:standard,
            system="test",
            boundary="none",
            method="synthetic",
            quantity="shift",
        )
        cap_boundary = NamedTuple[]
        @test ValidateConstrainedPathAFQMC._strict_consistency_check!(
            cap_boundary; common..., estimate=0.04, reference=0.0,
            standard_error=0.02, absolute_cap=0.04, sigma=5.0,
            precision_ceiling=0.02,
        )
        @test cap_boundary[1].allowed_error == 0.04
        over_cap = NamedTuple[]
        @test !ValidateConstrainedPathAFQMC._strict_consistency_check!(
            over_cap; common..., estimate=nextfloat(0.04), reference=0.0,
            standard_error=0.02, absolute_cap=0.04, sigma=5.0,
            precision_ceiling=0.02,
        )
        sigma_boundary = NamedTuple[]
        @test ValidateConstrainedPathAFQMC._strict_consistency_check!(
            sigma_boundary; common..., estimate=0.01, reference=0.0,
            standard_error=0.002, absolute_cap=0.04, sigma=5.0,
            precision_ceiling=0.02,
        )
        @test sigma_boundary[1].allowed_error == 0.01
        precision_failure = NamedTuple[]
        @test !ValidateConstrainedPathAFQMC._strict_consistency_check!(
            precision_failure; common..., estimate=0.0, reference=0.0,
            standard_error=0.021, absolute_cap=0.04, sigma=5.0,
            precision_ceiling=0.02,
        )
        @test precision_failure[1].passed
        @test !precision_failure[2].passed
        for bad_error in (missing, 0.0, -0.1, NaN, Inf)
            bad_checks = NamedTuple[]
            @test !ValidateConstrainedPathAFQMC._strict_consistency_check!(
                bad_checks; common..., estimate=0.0, reference=0.0,
                standard_error=bad_error, absolute_cap=0.04, sigma=5.0,
                precision_ceiling=0.02,
            )
            @test all(check -> !check.passed, bad_checks)
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._strict_consistency_check!(
                NamedTuple[]; common..., estimate=0.0, reference=0.0,
                standard_error=0.01, absolute_cap=-0.1, sigma=5.0,
                precision_ceiling=0.02,
            )
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._strict_consistency_check!(
                NamedTuple[]; common..., estimate=0.0, reference=0.0,
                standard_error=0.01, absolute_cap=0.04, sigma=-1.0,
                precision_ceiling=0.02,
            )
        end
        @test_throws ArgumentError begin
            ValidateConstrainedPathAFQMC._strict_consistency_check!(
                NamedTuple[]; common..., estimate=0.0, reference=0.0,
                standard_error=0.01, absolute_cap=0.04, sigma=5.0,
                precision_ceiling=0.0,
            )
        end

        failed_runs = NamedTuple[]
        failed_checks = NamedTuple[]
        failed_controls = ValidateConstrainedPathAFQMC._cp_controls(
            validation_plan(:standard), :dimer, 0.0025, 317;
            walker_count=960, projection_time=8.0,
            backpropagation_time=3.0, population_control_every=10,
        )
        ValidateConstrainedPathAFQMC._failed_run!(
            failed_runs, failed_checks, :standard, "failed_variant",
            "CP-AFQMC", "hubbard_dimer", "open", ErrorException("planned");
            U=20.0, Nup=1, Ndown=1, trial="free", dtau=0.0025,
            seed=317, variant="audit", controls=failed_controls,
        )
        @test only(failed_runs).status == "error"
        @test only(failed_runs).variant == "audit"
        @test only(failed_runs).walkers == 960
        @test only(failed_runs).planned_warmup_time == 8.0
        @test only(failed_runs).backpropagation_steps == 1200
        @test only(failed_runs).population_control_every == 10
        @test !only(failed_checks).passed
    end

    @testset "Exact thermal bridge conventions" begin
        bridge = exact_thermal_bridge()
        @test isapprox(bridge.density, 1.0; atol=1.0e-6, rtol=0.0)
        @test isapprox(
            bridge.internal_energy_per_cell,
            bridge.grand_energy_per_cell +
                DQMC_BRIDGE_POINT.mu * bridge.density;
            atol=2.0e-14,
            rtol=2.0e-14,
        )
        @test bridge.target_sector_probability > 0.9999
        @test isapprox(
            bridge.target_sector_probability,
            0.9999953002050829;
            atol=5.0e-13,
            rtol=0.0,
        )
        expected_interaction = DQMC_BRIDGE_POINT.U * (
            bridge.double_occupancy_per_cell - bridge.density / 2 + 0.5
        )
        @test isapprox(
            bridge.shifted_interaction_energy_per_cell,
            expected_interaction;
            atol=2.0e-14,
            rtol=2.0e-14,
        )
        @test isapprox(
            bridge.internal_energy_per_cell,
            bridge.kinetic_energy_per_cell +
                bridge.shifted_interaction_energy_per_cell;
            atol=2.0e-14,
            rtol=2.0e-14,
        )
        @test maximum(abs,
            bridge.raw.kinetic - AltermagnetDQMCTrial.realspace_kinetic_matrix(2),
        ) <= 2.0e-14
    end

    @testset "Immutable output and CSV escaping" begin
        mktempdir() do parent
            output = joinpath(parent, "validation")
            options = (
                profile=:quick,
                seed_offset=0,
                output_dir=output,
            )
            plan = validation_plan(:quick)
            checks = [ValidateConstrainedPathAFQMC._check_row(
                check_id="quoted_note",
                stage="writer_test",
                profile=:quick,
                system="test",
                boundary="none",
                method="none",
                quantity="writer",
                estimate=1.0,
                reference=1.0,
                absolute_error=0.0,
                allowed_error=0.0,
                passed=true,
                required=true,
                note="comma, and \"quote\"",
            )]
            run = ValidateConstrainedPathAFQMC._run_row(
                run_id="writer", method="none", system="test",
                boundary="none", variant="population10", trial_pattern="free",
                population_control_every=10, population_controls=7,
                planned_warmup_time=8.0, projection_time=12.0,
                total_projection_time=12.0,
                mixed_kinetic_energy=-2.0,
                mixed_kinetic_energy_standard_error=0.1,
                backpropagated_interaction_energy=-1.0,
                backpropagated_interaction_energy_standard_error=0.2,
                backpropagated_double_per_cell=0.25,
                backpropagated_double_per_cell_standard_error=0.01,
                S_alm_q0=0.3, S_alm_q0_standard_error=0.02,
            )
            @test run.variant == "population10"
            @test run.population_control_every == 10
            @test run.population_controls == 7
            @test run.planned_warmup_time == 8.0
            @test run.projection_time == run.total_projection_time == 12.0
            @test run.backpropagated_interaction_energy_standard_error == 0.2
            runs = [run]
            sample = ValidateConstrainedPathAFQMC._sample_row(
                run_id="writer", sample=1, mixed_kinetic_energy=-2.0,
                mixed_interaction_energy=-1.0,
                backpropagated_kinetic_energy=-2.1,
                backpropagated_interaction_energy=-0.9,
            )
            @test sample.mixed_kinetic_energy == -2.0
            @test sample.backpropagated_interaction_energy == -0.9
            samples = [sample]
            result = ValidateConstrainedPathAFQMC._write_output(
                output, options, plan, checks, runs, samples,
            )
            @test result.passed
            @test read(joinpath(output, "status.txt"), String) == "PASS\n"
            @test occursin(
                "\"comma, and \"\"quote\"\"\"",
                read(joinpath(output, "checks.csv"), String),
            )
            @test occursin(
                "output_policy=refuse_existing_then_atomic_rename",
                read(joinpath(output, "metadata.txt"), String),
            )
            metadata = read(joinpath(output, "metadata.txt"), String)
            @test occursin("format_version=2", metadata)
            @test occursin("cp_standard_accuracy_gate=fixed_absolute_cap", metadata)
            @test occursin("dimer_U20_standard_grid=three_dtau_by_three_seeds", metadata)
            @test occursin("doped_open_standard_grid=free_bp2_three_seeds", metadata)
            @test occursin("dqmc_half_drift_gate=standard_only", metadata)
            @test occursin(
                "dqmc_block_error_stability_gate=standard_only", metadata,
            )
            @test occursin(
                "standard_uses_three_point_dtau_squared_intercept", metadata,
            )
            @test_throws ArgumentError ValidateConstrainedPathAFQMC._write_output(
                output, options, plan, checks, runs, samples,
            )
            @test_throws ArgumentError run_validation(options)
        end
    end
end

end
