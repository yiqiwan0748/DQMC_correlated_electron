#!/usr/bin/env python3
"""Freeze an allowlisted source closure, never credentials or research outputs."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RENYI = Path('/tmp/advisor_renyi_evidence_20261022/HubbardRenyiDQMC')
ALM = Path('/home/yiqiwan/code/AltermagnetDQMCTrial')


def main():
    payload = {}
    for label, source, folders in [
        ('renyi', RENYI, ('src', 'test', 'analysis', 'run', 'parameters',
                          'archive/validated_old_pipeline')),
        ('alm', ALM, ('src', 'test', 'scripts', 'experiments/alm_dmrg_20260911')),
    ]:
        for filename in ('Project.toml', 'Manifest.toml', 'AGENTS.md'):
            path = source / filename
            if path.exists():
                payload[f'{label}/{filename}'] = path.read_bytes()
        for folder in folders:
            for path in (source / folder).rglob('*'):
                if path.is_file() and path.suffix in ('.jl', '.toml', '.py', '.sh'):
                    payload[f'{label}/{path.relative_to(source).as_posix()}'] = path.read_bytes()
    for folder in ('isaac', 'validation_design'):
        for path in (ROOT / folder).rglob('*'):
            if path.is_file() and path.suffix in ('.jl', '.py', '.sh', '.sbatch', '.json', '.csv', '.md'):
                payload[f'{folder}/{path.relative_to(ROOT / folder).as_posix()}'] = path.read_bytes()
    payload['SOURCE_PROVENANCE.json'] = json.dumps({
        'renyi_archive': 'HubbardRenyiDQMC_complete_20260828.tar.gz',
        'renyi_archive_sha256': hashlib.sha256(Path('/mnt/c/Users/神通广大/OneDrive - University of Tennessee/backup/HubbardRenyiDQMC_complete_20260828.tar.gz').read_bytes()).hexdigest(),
        'renyi_git_head': 'b0adedf042304a72bc1aea618abdcda1962242e9',
        'alm_git_head': 'ff6fd1d05a54533c1ea2d81d5c5e81b1dbe7771c',
        'note': 'Both sources may contain working-tree changes. SHA256SUMS identifies the exact files tested. Original raw data and original repos are untouched.'
    }, indent=2).encode()
    payload['SHA256SUMS'] = ''.join(
        f'{hashlib.sha256(data).hexdigest()}  {name}\n'
        for name, data in sorted(payload.items())
    ).encode()
    archive_path = HERE / 'validation-source.tar.gz'
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name, data in sorted(payload.items()):
            member = tarfile.TarInfo(name)
            member.size = len(data)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(data))
    manifest = {'archive': str(archive_path), 'files': len(payload),
                'bytes': archive_path.stat().st_size,
                'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest()}
    (HERE / 'package_receipt.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(manifest))


if __name__ == '__main__':
    main()
